# Диагностика потоков: дамп jcmd Thread.print, findDeadlockedThreads, события JFR о мониторах

Стенд к главе 08, раздел 16. `DiagTarget` - процесс-мишень с взаимной блокировкой на `ReentrantLock`, циклом ожидания на двух `Semaphore` и спящим виртуальным потоком, по которому снимают дамп `jcmd <pid> Thread.print -l` и JSON-дамп `Thread.dump_to_file`; `JfrLock` - восемь потоков бьются за монитор под записью JFR, чтобы увидеть события `jdk.JavaMonitorEnter` с полем `previousOwner`. Выводы автора - `s16-dump-jdk21.txt`, `s16-jfr-monitor.txt`, заметки о запуске - `s16-notes.txt`.

## Что нужно

- JDK 21 (`jcmd` и `jfr` входят в JDK).

## Запуск

В одном терминале мишень, в другом дамп:

```bash
java -Dstdout.encoding=UTF-8 src/DiagTarget.java
```

```bash
jcmd <pid> Thread.print -l > s16-dump-jdk21.txt
```

JFR: `java -XX:StartFlightRecording=settings=profile,filename=lock.jfr src/JfrLock.java`, затем `jfr summary lock.jfr` и `jfr print --events jdk.JavaMonitorEnter lock.jfr`. В IDEA на каждую программу есть конфигурация `java src/<Класс>.java`.

## Что должно получиться

`findDeadlockedThreads` видит два потока на `ReentrantLock` и не видит цикл на семафорах; виртуальный поток `virtual-sleeper` в `Thread.print` отсутствует и есть в JSON-дампе. В записи с настройками `profile` 12 событий `jdk.JavaMonitorEnter` и ни одного `jdk.ThreadSleep`: сны по 2 мс короче порога 10 мс.
