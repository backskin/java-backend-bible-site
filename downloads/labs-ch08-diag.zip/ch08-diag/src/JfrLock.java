/** Восемь потоков бьются за один монитор, внутри захвата короткая пауза: события JavaMonitorEnter в JFR. */
public class JfrLock {
    static final Object LOCK = new Object();
    static long counter;
    public static void main(String[] args) throws Exception {
        Thread[] ts = new Thread[8];
        for (int i = 0; i < ts.length; i++) {
            ts[i] = new Thread(() -> {
                for (int j = 0; j < 200; j++) synchronized (LOCK) { counter++; try { Thread.sleep(2); } catch (InterruptedException e) { return; } }
            }, "limit-worker-" + i);
            ts[i].start();
        }
        for (Thread t : ts) t.join();
        System.out.println("counter=" + counter);
    }
}
