import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Цель для дампа потоков: взаимоблокировка на ReentrantLock, цикл на двух семафорах,
 * поток в чтении сокета без ответа, виртуальный поток во сне. Печатает findDeadlockedThreads и PID, затем ждёт.
 */
public class DiagTarget {
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); } }

    public static void main(String[] args) throws Exception {
        ReentrantLock a = new ReentrantLock(), b = new ReentrantLock();
        new Thread(() -> { a.lock(); sleep(100); b.lock(); }, "transfer-A-to-B").start();
        new Thread(() -> { b.lock(); sleep(100); a.lock(); }, "transfer-B-to-A").start();

        Semaphore s1 = new Semaphore(1), s2 = new Semaphore(1);
        new Thread(() -> { try { s1.acquire(); sleep(100); s2.acquire(); } catch (InterruptedException ignored) { } }, "sem-1-then-2").start();
        new Thread(() -> { try { s2.acquire(); sleep(100); s1.acquire(); } catch (InterruptedException ignored) { } }, "sem-2-then-1").start();

        ServerSocket server = new ServerSocket(0);             // принимает соединение и молчит
        new Thread(() -> {
            try (Socket s = new Socket("localhost", server.getLocalPort()); InputStream in = s.getInputStream()) {
                in.read();                                     // ждём ответа, которого не будет
            } catch (Exception ignored) { }
        }, "antifraud-client-1").start();
        Socket accepted = server.accept();

        Thread.ofVirtual().name("virtual-sleeper").start(() -> sleep(600_000));

        sleep(500);
        long[] ids = ManagementFactory.getThreadMXBean().findDeadlockedThreads();
        System.out.println("findDeadlockedThreads: " + (ids == null ? "null" : ids.length + " потока"));
        System.out.println("PID " + ProcessHandle.current().pid());
        System.out.flush();
        sleep(600_000);
        accepted.close();
    }
}
