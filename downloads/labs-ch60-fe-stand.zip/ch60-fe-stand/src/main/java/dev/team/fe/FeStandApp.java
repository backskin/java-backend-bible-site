package dev.team.fe;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Учебный стенд главы 60: на экране одна надпись «Не удалось загрузить данные», а причины разные.
 *
 * <p>Страница {@code static/index.html} открывается с источника {@code http://127.0.0.1:8081}, а API вызывает по адресу
 * {@code http://localhost:8081}. Сервер один, но для браузера это два разных источника (origin = схема + хост + порт),
 * поэтому каждый вызов API со страницы — междоменный и подчиняется CORS.
 *
 * <p>Настройки CORS по путям:
 * <ul>
 *   <li>{@code /api/cors/**} — разрешён только источник страницы и только GET (так обычно настраивают API);</li>
 *   <li>{@code /api/star/**} — разрешён любой источник ({@code *}) без учётных данных;</li>
 *   <li>{@code /api/nocors/**} и {@code /api/gw/**} — без CORS вовсе;</li>
 *   <li>{@code /api/raw/**} — CORS выставлен вручную фильтром, с буквальным {@code Access-Control-Allow-Headers: *}.</li>
 * </ul>
 * Все запросы к {@code /api} пишутся в журнал, который страница показывает в конце: так видно, что получил сервер.
 */
@SpringBootApplication
public class FeStandApp implements WebMvcConfigurer {

    /** Источник, с которого загружена учебная страница. */
    static final String PAGE_ORIGIN = "http://127.0.0.1:8081";

    /** Журнал сервера: метод, путь, код ответа, время обработки. */
    static final List<String> LOG = new CopyOnWriteArrayList<>();

    public static void main(String[] args) {
        SpringApplication.run(FeStandApp.class, args);
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/cors/**")
                .allowedOrigins(PAGE_ORIGIN)
                .allowedMethods("GET")
                .allowedHeaders("*")          // Spring отвечает не звёздочкой, а перечнем запрошенных заголовков
                .maxAge(600);
        registry.addMapping("/api/star/**")
                .allowedOrigins("*")
                .allowedMethods("GET");
    }

    /** Журнал запросов: стоит первым, чтобы видеть и запросы, которые отклонит CORS. */
    @Bean
    FilterRegistrationBean<OncePerRequestFilter> requestLog() {
        var f = new FilterRegistrationBean<OncePerRequestFilter>(new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
                    throws ServletException, IOException {
                long t0 = System.nanoTime();
                try {
                    chain.doFilter(req, res);
                } finally {
                    String path = req.getRequestURI();
                    if (path.startsWith("/api/") && !path.startsWith("/api/_"))
                        LOG.add(String.format("%-7s %-40s %d  %d мс", req.getMethod(), path, res.getStatus(),
                                (System.nanoTime() - t0) / 1_000_000));
                }
            }
        });
        f.setOrder(Ordered.HIGHEST_PRECEDENCE);
        f.addUrlPatterns("/api/*");
        return f;
    }

    /**
     * CORS «вручную» для /api/raw: так его часто пишут в шлюзах и прокси. Ответ на предварительный запрос разрешает
     * любые заголовки буквальной звёздочкой; по стандарту Fetch она не распространяется на заголовок Authorization.
     */
    @Bean
    FilterRegistrationBean<OncePerRequestFilter> rawCors() {
        var f = new FilterRegistrationBean<OncePerRequestFilter>(new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
                    throws ServletException, IOException {
                res.setHeader("Access-Control-Allow-Origin", PAGE_ORIGIN);
                if ("OPTIONS".equals(req.getMethod())) {
                    res.setHeader("Access-Control-Allow-Methods", "GET");
                    res.setHeader("Access-Control-Allow-Headers", "*");
                    res.setStatus(204);
                    return;
                }
                chain.doFilter(req, res);
            }
        });
        f.setOrder(Ordered.HIGHEST_PRECEDENCE + 1);
        f.addUrlPatterns("/api/raw/*");
        return f;
    }
}
