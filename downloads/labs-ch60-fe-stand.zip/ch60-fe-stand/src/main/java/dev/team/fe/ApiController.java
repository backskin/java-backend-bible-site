package dev.team.fe;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

/** Эндпоинты стенда: каждый воспроизводит одну причину надписи «Не удалось загрузить данные». */
@RestController
@RequestMapping("/api")
public class ApiController {

    /** Лимит клиента: деньги строкой, как и положено отдавать BigDecimal, чтобы не терять точность. */
    private static Map<String, Object> limit() {
        return Map.of("clientId", 1, "dailyLimit", "500000.00", "used", "0.10", "currency", "RUB");
    }

    // 1. Без CORS: сервер отвечает 200, но браузер не отдаст ответ странице с другого источника
    @GetMapping("/nocors/limit")
    Map<String, Object> noCors() { return limit(); }

    // 1б. Тот же ответ с разрешённым источником (настройки в FeStandApp.addCorsMappings)
    @GetMapping("/cors/limit")
    Map<String, Object> withCors() { return limit(); }

    // 2. «Шлюз» вернул 502 со страницей HTML и без заголовков CORS
    @GetMapping("/gw/limit")
    ResponseEntity<String> gateway() {
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY).contentType(MediaType.TEXT_HTML)
                .body("<html><body><h1>502 Bad Gateway</h1></body></html>");
    }

    // 3. Ошибка проверки данных в формате Problem Details (RFC 9457): fetch при этом не отклоняется
    @GetMapping("/cors/problem")
    ResponseEntity<ProblemDetail> problem() {
        ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.valueOf(422), "Сумма превышает дневной лимит");
        p.setProperty("code", "LIMIT_EXCEEDED");
        return ResponseEntity.status(422).contentType(MediaType.APPLICATION_PROBLEM_JSON).body(p);
    }

    // 4. Любой источник (*): работает без куки, но не с credentials: 'include'
    @GetMapping("/star/me")
    Map<String, Object> star() { return Map.of("user", "dev.team"); }

    // 5. CORS вручную с Allow-Headers: * (фильтр в FeStandApp)
    @GetMapping("/raw/secure")
    Map<String, Object> raw() { return limit(); }

    // 6. N+1 на клиенте: список счетов без остатков и остаток каждого отдельным запросом (30 мс на запрос)
    @GetMapping("/cors/accounts")
    List<Map<String, Object>> accounts() {
        return IntStream.rangeClosed(1, 20).mapToObj(i -> Map.<String, Object>of("id", i, "name", "Счёт " + i)).toList();
    }

    @GetMapping("/cors/accounts/{id}/balance")
    Map<String, Object> balance(@PathVariable int id) throws InterruptedException {
        Thread.sleep(30);
        return Map.of("id", id, "balance", BigDecimal.valueOf(id).multiply(new BigDecimal("1000.50")).toPlainString());
    }

    @GetMapping("/cors/accounts-with-balance")
    List<Map<String, Object>> accountsWithBalance() throws InterruptedException {
        Thread.sleep(30);
        return IntStream.rangeClosed(1, 20).mapToObj(i -> Map.<String, Object>of("id", i, "name", "Счёт " + i,
                "balance", BigDecimal.valueOf(i).multiply(new BigDecimal("1000.50")).toPlainString())).toList();
    }

    // 7. Кэш браузера: ETag с no-cache (каждый раз условный запрос) и max-age (повтор не доходит до сервера)
    @GetMapping("/cors/rates-etag")
    ResponseEntity<Map<String, Object>> ratesEtag(@RequestHeader(value = "If-None-Match", required = false) String inm) {
        String etag = "\"rates-v1\"";
        if (etag.equals(inm)) return ResponseEntity.status(HttpStatus.NOT_MODIFIED).eTag(etag).header("Cache-Control", "no-cache").build();
        return ResponseEntity.ok().eTag(etag).header("Cache-Control", "no-cache").body(Map.of("USD", "92.50", "EUR", "100.10"));
    }

    @GetMapping("/cors/rates-maxage")
    ResponseEntity<Map<String, Object>> ratesMaxAge() {
        return ResponseEntity.ok().header("Cache-Control", "max-age=60").body(Map.of("USD", "92.50", "EUR", "100.10"));
    }

    // служебное: журнал сервера для страницы
    @CrossOrigin(origins = FeStandApp.PAGE_ORIGIN)
    @GetMapping("/_log")
    List<String> log() { return FeStandApp.LOG; }

    @CrossOrigin(origins = FeStandApp.PAGE_ORIGIN)
    @GetMapping("/_reset")
    Map<String, Object> reset() { FeStandApp.LOG.clear(); return Map.of("ok", true); }
}
