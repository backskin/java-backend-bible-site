package dev.team.fe;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.cors.CorsConfiguration;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.options;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Что делает с CORS сам сервер на Spring, без браузера. Браузер решает, отдать ли ответ странице;
 * сервер на Spring сверх того сам отклоняет запросы с чужим Origin и неразрешённые preflight-запросы.
 */
@SpringBootTest
@AutoConfigureMockMvc
class CorsTest {

    @Autowired MockMvc mvc;

    @Test void запросБезOriginПроходитКакУCurl() throws Exception {
        mvc.perform(get("/api/cors/limit")).andExpect(status().isOk())
                .andExpect(header().doesNotExist("Access-Control-Allow-Origin"));
    }

    @Test void разрешённыйИсточникПолучаетЗаголовок() throws Exception {
        mvc.perform(get("/api/cors/limit").header("Origin", FeStandApp.PAGE_ORIGIN)).andExpect(status().isOk())
                .andExpect(header().string("Access-Control-Allow-Origin", FeStandApp.PAGE_ORIGIN))
                .andExpect(header().string("Vary", org.hamcrest.Matchers.containsString("Origin")));
    }

    @Test void чужойИсточникSpringОтклоняетСам() throws Exception {
        mvc.perform(get("/api/cors/limit").header("Origin", "https://evil.example")).andExpect(status().isForbidden())
                .andExpect(content().string("Invalid CORS request"));
    }

    @Test void путьБезНастройкиCorsОтвечает200БезЗаголовка() throws Exception {
        mvc.perform(get("/api/nocors/limit").header("Origin", FeStandApp.PAGE_ORIGIN)).andExpect(status().isOk())
                .andExpect(header().doesNotExist("Access-Control-Allow-Origin"));
    }

    @Test void preflightРазрешённогоМетодаИЗаголовка() throws Exception {
        mvc.perform(options("/api/cors/limit").header("Origin", FeStandApp.PAGE_ORIGIN)
                        .header("Access-Control-Request-Method", "GET")
                        .header("Access-Control-Request-Headers", "authorization"))
                .andExpect(status().isOk())
                .andExpect(header().string("Access-Control-Allow-Methods", "GET"))
                .andExpect(header().string("Access-Control-Allow-Headers", "authorization"))   // не «*», а перечень
                .andExpect(header().string("Access-Control-Max-Age", "600"));
    }

    @Test void preflightЗапрещённогоМетода403БезЗаголовковCors() throws Exception {
        mvc.perform(options("/api/cors/limit").header("Origin", FeStandApp.PAGE_ORIGIN)
                        .header("Access-Control-Request-Method", "PUT"))
                .andExpect(status().isForbidden())
                .andExpect(header().doesNotExist("Access-Control-Allow-Origin"))
                .andExpect(content().string("Invalid CORS request"));
    }

    @Test void звёздочкаИУчётныеДанныеНесовместимыВНастройке() {
        CorsConfiguration c = new CorsConfiguration();
        c.addAllowedOrigin("*");
        c.setAllowCredentials(true);
        assertThrows(IllegalArgumentException.class, c::validateAllowCredentials);
    }

    @Test void etagДаёт304НаУсловныйЗапрос() throws Exception {
        mvc.perform(get("/api/cors/rates-etag").header("If-None-Match", "\"rates-v1\"")).andExpect(status().isNotModified());
    }

    @Test void problemDetailsС422() throws Exception {
        mvc.perform(get("/api/cors/problem")).andExpect(status().is(422))
                .andExpect(content().contentTypeCompatibleWith("application/problem+json"))
                .andExpect(jsonPath("$.code").value("LIMIT_EXCEEDED"));
    }
}
