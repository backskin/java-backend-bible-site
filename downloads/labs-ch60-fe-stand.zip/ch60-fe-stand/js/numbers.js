// Глава 60, раздел 4: что делает JavaScript с деньгами, null и большими идентификаторами из JSON.
// Запуск: node js/numbers.js (Node.js на движке V8, том же, что в Chrome)
const limit = JSON.parse('{"dailyLimit":"500000.00","used":"0.10"}');
console.log('dailyLimit + 1                     =', limit.dailyLimit + 1);              // склейка строк
console.log('Number(used) + 0.2                 =', Number(limit.used) + 0.2);          // двоичная дробь
console.log('Number("2000.00") - Number("1500.10") =', Number('2000.00') - Number('1500.10'));
const used = null;                                                                    // поле стало необязательным
console.log('Number(null).toFixed(2)            =', Number(used).toFixed(2));           // 0.00 без ошибки
try { used.toFixed(2); } catch (e) { console.log('null.toFixed(2)                    ->', e.constructor.name + ': ' + e.message); }
console.log('JSON.parse id 9007199254740993     ->', JSON.parse('{"id":9007199254740993}').id);
console.log('Number.MAX_SAFE_INTEGER            =', Number.MAX_SAFE_INTEGER);
console.log('Node', process.version);
