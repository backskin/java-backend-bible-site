package dev.team.vt;

import org.springframework.boot.amqp.autoconfigure.RabbitAutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.data.redis.autoconfigure.DataRedisAutoConfiguration;
import org.springframework.boot.kafka.autoconfigure.KafkaAutoConfiguration;
import org.springframework.boot.pulsar.autoconfigure.PulsarAutoConfiguration;
import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.boot.test.context.runner.ReactiveWebApplicationContextRunner;
import org.springframework.boot.webflux.autoconfigure.WebFluxAutoConfiguration;
import org.springframework.context.ApplicationContext;

import java.lang.reflect.Field;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Function;

/**
 * Какие компоненты переключает spring.threads.virtual.enabled: из бина компонента достаётся исполнитель,
 * на нём запускается задача, и задача сообщает, на каком потоке выполнилась.
 */
public final class VtList {

    public static void main(String[] a) {
        check("Kafka: контейнер слушателей (kafkaListenerContainerFactory)",
                new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(KafkaAutoConfiguration.class)),
                c -> find(c.getBean("kafkaListenerContainerFactory"), 2));
        check("RabbitMQ: контейнер слушателей (rabbitListenerContainerFactory)",
                new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(RabbitAutoConfiguration.class)),
                c -> find(c.getBean("rabbitListenerContainerFactory"), 2));
        check("Pulsar: контейнер слушателей (pulsarListenerContainerFactory)",
                new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(PulsarAutoConfiguration.class)),
                c -> find(c.getBean("pulsarListenerContainerFactory"), 2));
        check("Redis: фабрика соединений Lettuce (redisConnectionFactory)",
                new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(DataRedisAutoConfiguration.class)),
                c -> { System.out.println("   бины RedisConnectionFactory: " + java.util.List.of(c.getBeanNamesForType(org.springframework.data.redis.connection.RedisConnectionFactory.class))); return find(c.getBean(org.springframework.data.redis.connection.RedisConnectionFactory.class), 1); });
        check("WebFlux: исполнитель блокирующих методов контроллера (requestMappingHandlerAdapter)",
                new ReactiveWebApplicationContextRunner().withConfiguration(AutoConfigurations.of(TaskExecutionAutoConfiguration.class, WebFluxAutoConfiguration.class)),
                c -> scheduler(c.getBean("requestMappingHandlerAdapter")));
    }

    interface Runner { void run(String flag, Function<ApplicationContext, Executor> pick); }

    static void check(String label, Object runner, Function<ApplicationContext, Executor> pick) {
        System.out.println("== " + label);
        for (String flag : new String[] {"false", "true"}) {
            if (runner instanceof ApplicationContextRunner r) {
                r.withPropertyValues("spring.threads.virtual.enabled=" + flag).run(c -> report(flag, c.getStartupFailure(), c, pick));
            } else if (runner instanceof ReactiveWebApplicationContextRunner r) {
                r.withPropertyValues("spring.threads.virtual.enabled=" + flag).run(c -> report(flag, c.getStartupFailure(), c, pick));
            }
        }
    }

    static void report(String flag, Throwable failure, ApplicationContext c, Function<ApplicationContext, Executor> pick) {
        if (failure != null) { System.out.println("   virtual=" + flag + ": СБОЙ " + failure); return; }
        Executor e = pick.apply(c);
        if (e == null) { System.out.println("   virtual=" + flag + ": свой исполнитель не задан (поток выбирает библиотека)"); return; }
        CompletableFuture<String> where = new CompletableFuture<>();
        e.execute(() -> where.complete(Thread.currentThread().isVirtual() + ", поток " + Thread.currentThread().getName()));
        System.out.println("   virtual=" + flag + ": " + e.getClass().getSimpleName() + "; задача на виртуальном потоке: " + where.join());
    }

    /** Адаптер WebFlux хранит исполнитель блокирующих методов обёрнутым в планировщик Reactor. */
    static Executor scheduler(Object adapter) {
        try {
            Field f = adapter.getClass().getDeclaredField("scheduler");
            f.setAccessible(true);
            reactor.core.scheduler.Scheduler sch = (reactor.core.scheduler.Scheduler) f.get(adapter);
            return sch == null ? null : sch::schedule;
        } catch (ReflectiveOperationException e) { throw new IllegalStateException(e); }
    }

    /** Ищет в объекте поле-исполнитель, при необходимости на глубине вложенных объектов Spring. */
    static Executor find(Object o, int depth) {
        for (Class<?> k = o.getClass(); k != null && k != Object.class; k = k.getSuperclass()) {
            for (Field f : k.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                try {
                    f.setAccessible(true);
                    Object v = f.get(o);
                    if (v instanceof Executor ex) return ex;
                    if (depth > 1 && v != null && v.getClass().getName().startsWith("org.springframework")) {
                        Executor inner = find(v, depth - 1);
                        if (inner != null) return inner;
                    }
                } catch (RuntimeException | IllegalAccessException ignored) { }
            }
        }
        return null;
    }
}
