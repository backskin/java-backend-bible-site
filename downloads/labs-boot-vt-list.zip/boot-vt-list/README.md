# Что переключает spring.threads.virtual.enabled в Spring Boot 4.1

Стенд к главам 02 и 10. Программа `VtList` поднимает контекст Spring Boot 4.1.1 с `ApplicationContextRunner` дважды, с `spring.threads.virtual.enabled=false` и `true`, и для каждого компонента печатает, какой исполнитель ему достался и выполняется ли его задача на виртуальном потоке: контейнеры слушателей Kafka, RabbitMQ и Pulsar, фабрика соединений Lettuce для Redis, исполнитель блокирующих методов контроллера в WebFlux. Брокеры не нужны: контекст поднимается без подключения. Вывод автора - в `s10-vt-list.txt`.

## Что нужно

- JDK 21 и Maven; зависимости скачаются сами.

## Запуск

```bash
mvn -q compile exec:java -Dexec.mainClass=dev.team.vt.VtList
```

или `mvn -q package` и `java -jar target/vt-list-*.jar`.

## Что должно получиться

При `virtual=false` у всех компонентов "свой исполнитель не задан", при `virtual=true` Kafka получает `SimpleAsyncTaskExecutor` с виртуальными потоками, RabbitMQ - `VirtualThreadTaskExecutor`, и задача каждого выполняется на виртуальном потоке.
