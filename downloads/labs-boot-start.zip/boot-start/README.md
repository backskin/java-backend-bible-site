# Старт Spring Boot по событиям: от ApplicationStartingEvent до ApplicationReadyEvent, сбои и ленивый старт

Стенд к главе 10, раздел о старте приложения. `StartLab` печатает с метками времени все события `SpringApplication`, фазы `SmartLifecycle` веб-сервера и шаги `EnvironmentPostProcessor` (`BikSourcePostProcessor` добавляет источник свойств) в четырех сценариях: обычный старт, исключение в `ApplicationRunner`, исключение в обработчике `ApplicationReadyEvent`, `spring.main.lazy-initialization=true`. Вывод автора - `s10-start.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile exec:java -Dexec.mainClass=dev.team.start.StartLab
```

В IDEA есть конфигурация `StartLab`.

## Что должно получиться

Четыре блока `########`, в каждом - события с отметкой времени от `ApplicationStartingEvent` до последнего, которое успело прийти; по двум сценариям с исключением видно, какие события приходят после сбоя и закрывается ли контекст. Время в миллисекундах зависит от машины.
