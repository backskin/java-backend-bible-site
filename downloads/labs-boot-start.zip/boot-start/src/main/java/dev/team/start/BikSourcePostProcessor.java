package dev.team.start;

import org.springframework.boot.EnvironmentPostProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.StandardEnvironment;

import java.util.Map;

/** Подмешивает свойство до создания контекста; в Boot 4 интерфейс лежит в org.springframework.boot. */
public class BikSourcePostProcessor implements EnvironmentPostProcessor {
    @Override
    public void postProcessEnvironment(ConfigurableEnvironment env, SpringApplication app) {
        // ниже переменных окружения: их и аргументы командной строки это свойство не перекроет
        env.getPropertySources().addAfter(StandardEnvironment.SYSTEM_ENVIRONMENT_PROPERTY_SOURCE_NAME,
                new MapPropertySource("bik-vault", Map.of("bik.source", "хранилище секретов (vault)")));
        StartLab.log("EnvironmentPostProcessor: свойство bik.source добавлено, контекста ещё нет");
    }
}
