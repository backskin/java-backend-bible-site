package dev.team.start;

import jakarta.annotation.PostConstruct;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.availability.ApplicationAvailability;
import org.springframework.boot.availability.AvailabilityChangeEvent;
import org.springframework.boot.context.event.ApplicationFailedEvent;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.context.event.ApplicationStartingEvent;
import org.springframework.boot.context.metrics.buffering.BufferingApplicationStartup;
import org.springframework.boot.context.event.SpringApplicationEvent;
import org.springframework.boot.web.server.context.WebServerInitializedEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.context.SmartLifecycle;
import org.springframework.stereotype.Component;
import java.net.Socket;

import java.time.Duration;
import java.util.Comparator;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Опыт разд. 2: справочник БИК Тундра-Банка при старте загружает данные. Печатает порядок событий,
 * моменты @PostConstruct, исполнителей и ApplicationReadyEvent, состояние готовности и порт в эти моменты.
 * Флаги: --fail=runner | --fail=ready, --spring.main.lazy-initialization=true.
 */
@SpringBootApplication
@EnableScheduling
public class StartLab {
    static final long T0 = System.nanoTime();
    static String at() { return String.format("%5d мс", (System.nanoTime() - T0) / 1_000_000); }
    static void log(String s) { System.out.println(at() + "  " + s); }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(StartLab.class);
        BufferingApplicationStartup startup = new BufferingApplicationStartup(8192);
        app.setApplicationStartup(startup);
        // слушатель, добавленный программно, получает и ранние события, когда контекста ещё нет
        app.addListeners((ApplicationListener<ApplicationEvent>) e -> {
            if (e instanceof SpringApplicationEvent || e instanceof AvailabilityChangeEvent<?>
                    || e instanceof WebServerInitializedEvent || e instanceof ContextRefreshedEvent)
                log("событие " + e.getClass().getSimpleName()
                        + (e instanceof AvailabilityChangeEvent<?> a ? "(" + a.getState() + ")" : "")
                        + (e instanceof WebServerInitializedEvent w ? ", порт " + w.getWebServer().getPort() : ""));
            if (e instanceof ApplicationFailedEvent f) log("   причина: " + f.getException().getMessage());
        });
        try {
            var ctx = app.run(args);
            if (!ctx.getEnvironment().getProperty("spring.main.lazy-initialization", Boolean.class, false)) {
                log("пять самых долгих шагов старта:");
                startup.getBufferedTimeline().getEvents().stream()
                        .sorted(Comparator.comparing(ev -> ev.getDuration(), Comparator.reverseOrder())).limit(5)
                        .forEach(ev -> System.out.printf("        %4d мс  %s %s%n", ev.getDuration().toMillis(), ev.getStartupStep().getName(),
                                ev.getStartupStep().getTags().iterator().hasNext() ? ev.getStartupStep().getTags().iterator().next().getValue() : ""));
            }
            sleep(1200);
            log("контекст жив: " + ctx.isActive() + ", закрываю");
            ctx.close();
        } catch (Exception e) {
            log("run() бросил " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    /** Справочник: грузится в @PostConstruct, то есть посреди создания бинов. */
    @Component
    static class BikDirectory {
        final ApplicationAvailability availability;
        final Environment env;
        BikDirectory(ApplicationAvailability availability, Environment env) { this.availability = availability; this.env = env; }
        @PostConstruct void load() {
            log("@PostConstruct справочника: готовность " + availability.getReadinessState() + ", порт " + env.getProperty("local.server.port"));
        }
    }

    @Bean @Order(1)
    ApplicationRunner loadFromArgs(ApplicationAvailability availability, Environment env) {
        return (ApplicationArguments args) -> {
            log("ApplicationRunner: источник справочника " + env.getProperty("bik.source") + ", файл " + args.getOptionValues("bik-file") + ", готовность "
                    + availability.getReadinessState() + ", порт " + env.getProperty("local.server.port"));
            if (args.getOptionValues("fail") != null && args.getOptionValues("fail").contains("runner"))
                throw new IllegalStateException("файл справочника не найден");
        };
    }

    @Bean @Order(2)
    CommandLineRunner rawArgs() {
        return args -> log("CommandLineRunner: сырые аргументы " + String.join(" ", args));
    }

    @Component
    static class Ready {
        final ApplicationAvailability availability;
        Ready(ApplicationAvailability availability) { this.availability = availability; }
        @EventListener(ApplicationReadyEvent.class) void onReady(ApplicationReadyEvent e) {
            log("@EventListener(ApplicationReadyEvent): готовность " + availability.getReadinessState());
            if (e.getArgs().length > 0 && String.join(" ", e.getArgs()).contains("--fail=ready"))
                throw new IllegalStateException("прогрев кэша упал");
        }
    }

    /** Бин-слушатель самого раннего события: контейнера ещё нет, поэтому он не сработает никогда. */
    @Component
    static class TooEarly implements ApplicationListener<ApplicationStartingEvent> {
        @Override public void onApplicationEvent(ApplicationStartingEvent e) { log("бин получил ApplicationStartingEvent"); }
    }

    /** Ночная выгрузка изменений справочника: проверяем, запускается ли @Scheduled при ленивой инициализации. */
    @Component
    static class Refresh {
        static final AtomicInteger runs = new AtomicInteger();
        @Scheduled(fixedRate = 200) void tick() { if (runs.incrementAndGet() == 1) log("@Scheduled: первый запуск обновления справочника"); }
    }

    /** Прогрев с фазой ниже, чем у веб-сервера: стартует до того, как коннектор начал принимать запросы. */
    @Component
    static class Warmup implements SmartLifecycle {
        final Environment env; volatile boolean running;
        Warmup(Environment env) { this.env = env; }
        public int getPhase() { return SmartLifecycle.DEFAULT_PHASE - 4096; }
        public void start() { running = true; log("SmartLifecycle прогрев (фаза MAX-4096) start: порт принимает? " + accepts(env)); }
        public void stop() { running = false; log("SmartLifecycle прогрев (фаза MAX-4096) stop: порт принимает? " + accepts(env)); }
        public boolean isRunning() { return running; }
    }

    /** Компонент с фазой по умолчанию: стартует после открытия порта и останавливается раньше сервера. */
    @Component
    static class Consumer implements SmartLifecycle {
        final Environment env; volatile boolean running;
        Consumer(Environment env) { this.env = env; }
        public void start() { running = true; log("SmartLifecycle с фазой по умолчанию start: порт принимает? " + accepts(env)); }
        public void stop() { running = false; log("SmartLifecycle с фазой по умолчанию stop: порт принимает? " + accepts(env)); }
        public boolean isRunning() { return running; }
    }

    static boolean accepts(Environment env) {
        String port = env.getProperty("local.server.port");
        if (port == null) return false;
        try (Socket s = new Socket("localhost", Integer.parseInt(port))) { return true; } catch (Exception e) { return false; }
    }
}
