package dev.team.cfg;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.env.Environment;
import org.springframework.util.unit.DataSize;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;
import java.time.Period;
import java.util.List;
import java.util.Map;

/**
 * Приложение опыта разд. 5: платёжный шлюз Тундра-Банка читает настройки и печатает, что получил.
 * Запускается отдельными процессами из ConfigLab с разными переменными окружения, аргументами и файлами.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
@PropertySource("classpath:legacy.properties")
public class GatewayApp {

    enum Mode { ONLINE, READ_ONLY }

    /** Сумма комиссии: тип, которого Boot не знает. */
    record Fee(String currency, String amount) {
        static Fee parse(String s) { String[] p = s.trim().split(" "); return new Fee(p[0], p[1]); }
    }

    @Validated
    @ConfigurationProperties("tundra.gateway")
    record GatewayProperties(
            String baseUrl,
            @DefaultValue("3s") Duration readTimeout,
            @DefaultValue("3") @Min(1) @Max(5) int maxAttempts,
            Period retention,
            DataSize maxBody,
            Mode mode,
            String apiV2Url,
            List<String> fallbackUrls,
            Map<String, String> headers,
            Fee fee,
            String source) { }

    /** Класс свойств на сеттерах: значение по умолчанию задано инициализатором поля. */
    @ConfigurationProperties("tundra.registry")
    static class RegistryProperties {
        private int batchSize = 500;
        public int getBatchSize() { return batchSize; }
        public void setBatchSize(int batchSize) { this.batchSize = batchSize; }
    }

    @Bean
    @ConfigurationPropertiesBinding
    static Converter<String, Fee> feeConverter() { return Fee::parse; }

    /** БИК банка получателя: тип без конвертера для привязки свойств. */
    record Bic(String code) { }

    @ConfigurationProperties("tundra.bic")
    record BicProperties(Bic code) { }

    /** Конвертер объявлен обычным бином, без @ConfigurationPropertiesBinding; включается флагом check-bic. */
    @Configuration(proxyBeanMethods = false)
    @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty("check-bic")
    @org.springframework.boot.context.properties.EnableConfigurationProperties(BicProperties.class)
    static class BicCheck {
        @Bean Converter<String, Bic> bicConverter() { return Bic::new; }
    }

    @Configuration(proxyBeanMethods = false)
    static class Profiles {
        @Bean @Profile({"!prod", "!qa"}) String devDataLoader() { return "загрузчик тестовых данных"; }
        @Bean @Profile("!prod & !qa") String devDataLoaderStrict() { return "загрузчик тестовых данных (строгий)"; }
    }

    @Bean
    ApplicationRunner print(GatewayProperties p, RegistryProperties r, Environment env,
                            @Value("${tundra.gateway.read-timeout:нет}") String valueKebab,
                            @Value("${tundra.gateway.readTimeout:нет}") String valueCamel,
                            org.springframework.context.ApplicationContext ctx) {
        return args -> {
            System.out.println("base-url=" + p.baseUrl() + " | read-timeout=" + p.readTimeout() + " | max-attempts=" + p.maxAttempts()
                    + " | source=" + p.source());
            if (env.getProperty("show-types", Boolean.class, false))
                System.out.println("retention=" + p.retention() + " | max-body=" + p.maxBody() + " | mode=" + p.mode()
                        + " | api-v2-url=" + p.apiV2Url() + " | fallback-urls=" + p.fallbackUrls() + " | headers=" + p.headers()
                        + " | fee=" + p.fee());
            if (env.getProperty("show-value", Boolean.class, false))
                System.out.println("@Value kebab=" + valueKebab + " | @Value camel=" + valueCamel);
            if (env.getProperty("show-defaults", Boolean.class, false))
                System.out.println("tundra.registry.batch-size по умолчанию из инициализатора поля = " + r.getBatchSize());
            if (env.getProperty("show-profiles", Boolean.class, false))
                System.out.println("профили " + List.of(env.getActiveProfiles()) + ": devDataLoader=" + ctx.containsBean("devDataLoader")
                        + ", строгий=" + ctx.containsBean("devDataLoaderStrict"));
        };
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(GatewayApp.class);
        app.setWebApplicationType(WebApplicationType.NONE);
        app.setLogStartupInfo(false);
        app.setBannerMode(org.springframework.boot.Banner.Mode.OFF);
        try {
            app.run(args).close();
        } catch (Exception e) {
            Throwable t = e;
            while (t.getCause() != null) t = t.getCause();
            System.out.println("СТАРТ НЕ УДАЛСЯ: " + t.getClass().getSimpleName() + ": " + t.getMessage().split("\n")[0]);
        }
    }
}
