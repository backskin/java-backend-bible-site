package dev.team.cfg;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Ведущий опыта разд. 5: запускает GatewayApp отдельными процессами с разными источниками свойств. */
public class ConfigLab {
    static final String CP = System.getProperty("java.class.path");
    static final Path WORK = Path.of("target/work");

    public static void main(String[] a) throws Exception {
        Files.createDirectories(WORK.resolve("extra"));
        Files.createDirectories(WORK.resolve("secrets/tundra/gateway"));
        Files.writeString(WORK.resolve("extra/application.properties"), "tundra.gateway.base-url=https://extra-file\n");
        Files.writeString(WORK.resolve("secrets/tundra/gateway/base-url"), "https://from-configtree");

        System.out.println("== порядок источников");
        run("1. только application.properties из jar", Map.of(), List.of(), List.of());
        run("2. + переменная окружения TUNDRA_GATEWAY_BASEURL", Map.of("TUNDRA_GATEWAY_BASEURL", "https://env"), List.of(), List.of());
        run("3. + системное свойство -D", Map.of("TUNDRA_GATEWAY_BASEURL", "https://env"), List.of("-Dtundra.gateway.base-url=https://sysprop"), List.of());
        run("4. + SPRING_APPLICATION_JSON", Map.of("TUNDRA_GATEWAY_BASEURL", "https://env",
                "SPRING_APPLICATION_JSON", "{\"tundra\":{\"gateway\":{\"base-url\":\"https://json\"}}}"), List.of("-Dtundra.gateway.base-url=https://sysprop"), List.of());
        run("5. + аргумент командной строки", Map.of("TUNDRA_GATEWAY_BASEURL", "https://env",
                "SPRING_APPLICATION_JSON", "{\"tundra\":{\"gateway\":{\"base-url\":\"https://json\"}}}"), List.of("-Dtundra.gateway.base-url=https://sysprop"),
                List.of("--tundra.gateway.base-url=https://arg"));
        run("6. @PropertySource против application.properties (source задан в обоих)", Map.of(), List.of(), List.of());
        run("7. spring.config.additional-location", Map.of(), List.of(), List.of("--spring.config.additional-location=optional:file:target/work/extra/"));
        run("8. spring.config.location", Map.of(), List.of(), List.of("--spring.config.location=optional:file:target/work/extra/"));
        run("9. configtree из каталога секретов", Map.of(), List.of(), List.of("--spring.config.import=optional:configtree:target/work/secrets/"));
        run("10. файл целиком в переменной окружения через env:", Map.of("GATEWAY_CONFIG", "tundra.gateway.base-url=https://from-env-import\ntundra.gateway.max-attempts=4"),
                List.of(), List.of("--spring.config.import=optional:env:GATEWAY_CONFIG[.properties]"));

        System.out.println("== типы и нестрогое сопоставление имён");
        run("11. типы из application.properties", Map.of(), List.of(), List.of("--show-types=true"));
        run("12. окружение: API_V2_URL, список через запятую, ключ Map", Map.of(
                "TUNDRA_GATEWAY_APIV2URL", "https://v2-no-dash",
                "TUNDRA_GATEWAY_FALLBACKURLS", "https://a,https://b",
                "TUNDRA_GATEWAY_HEADERS_X_SYSTEM_CODE", "ABC"), List.of(), List.of("--show-types=true"));
        run("13. окружение: API_V2_URL с подчёркиваниями", Map.of("TUNDRA_GATEWAY_API_V2_URL", "https://v2-underscores"), List.of(), List.of("--show-types=true"));
        run("14. окружение: API_V_2_URL", Map.of("TUNDRA_GATEWAY_API_V_2_URL", "https://v-2"), List.of(), List.of("--show-types=true"));
        run("15. @Value с kebab-case и camelCase, свойство задано camelCase", Map.of(), List.of(), List.of("--tundra.gateway.readTimeout=7s", "--show-value=true"));
        run("15б. @Value с kebab-case и camelCase, свойство задано kebab-case", Map.of(), List.of(), List.of("--tundra.gateway.read-timeout=9s", "--show-value=true"));
        run("16. @Value, переменная окружения TUNDRA_GATEWAY_READTIMEOUT", Map.of("TUNDRA_GATEWAY_READTIMEOUT", "8s"), List.of(), List.of("--show-value=true"));
        run("17. списки из двух источников: файл + аргумент", Map.of(), List.of(), List.of("--tundra.gateway.fallback-urls=https://only-arg", "--show-types=true"));
        run("18. max-attempts=9 при @Max(5)", Map.of(), List.of(), List.of("--tundra.gateway.max-attempts=9"));
        run("18б. конвертер без @ConfigurationPropertiesBinding", Map.of(), List.of(), List.of("--check-bic=true", "--tundra.bic.code=044525999"));
        run("19. значения по умолчанию у @ConfigurationProperties", Map.of(), List.of(), List.of("--show-defaults=true"));

        System.out.println("== профили");
        run("20. профиль prod: документ on-profile", Map.of(), List.of(), List.of("--spring.profiles.active=prod"));
        run("21. @Profile({\"!prod\",\"!qa\"}) при активном prod", Map.of(), List.of(), List.of("--spring.profiles.active=prod", "--show-profiles=true"));
        run("22. то же при prod и qa", Map.of(), List.of(), List.of("--spring.profiles.active=prod,qa", "--show-profiles=true"));
        run("23. старый ключ spring.profiles в документе", Map.of(), List.of(), List.of("--spring.config.import=classpath:legacy-profiles.yml"));
        run("24. документ on-profile=stage со spring.profiles.active=prod, профиль stage активен", Map.of(), List.of(),
                List.of("--spring.profiles.active=stage", "--spring.config.import=classpath:stage-invalid.properties", "--show-profiles=true"));
        run("24б. тот же документ, профиль stage не активен", Map.of(), List.of(),
                List.of("--spring.config.import=classpath:stage-invalid.properties", "--show-profiles=true"));
        Files.writeString(WORK.resolve("extra/application-stage.properties"), "spring.profiles.active=prod" + System.lineSeparator());
        run("25. spring.profiles.active в файле application-stage.properties", Map.of(), List.of(),
                List.of("--spring.profiles.active=stage", "--spring.config.additional-location=optional:file:target/work/extra/"));
    }

    static void run(String label, Map<String, String> env, List<String> jvm, List<String> args) throws Exception {
        List<String> cmd = new ArrayList<>(List.of("java", "-Dstdout.encoding=UTF-8", "-cp", CP));
        cmd.addAll(jvm);
        cmd.add("dev.team.cfg.GatewayApp");
        cmd.addAll(args);
        ProcessBuilder pb = new ProcessBuilder(cmd).redirectErrorStream(true).directory(new File("."));
        pb.environment().keySet().removeIf(k -> k.startsWith("TUNDRA_") || k.startsWith("SPRING_") || k.equals("GATEWAY_CONFIG"));
        pb.environment().putAll(env);
        Process p = pb.start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        p.waitFor();
        System.out.println(label);
        for (String line : out.split("\\R"))
            if (line.startsWith("base-url=") || line.startsWith("retention=") || line.startsWith("@Value") || line.startsWith("tundra.registry")
                    || line.startsWith("профили") || line.startsWith("СТАРТ НЕ УДАЛСЯ") || line.contains("Reason:") || line.contains("Property:"))
                System.out.println("   " + line.trim());
    }
}
