import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.StructuredTaskScope;
import java.util.concurrent.StructuredTaskScope.Subtask;

/**
 * Глава 08, 7.8: тот же реестр, что в AllOfOutcomes, через StructuredTaskScope (JDK 25, preview).
 * Собирающий Joiner по образцу A N M Bazlur Rahman, «Modern Concurrency in Java», гл. 4, «Custom Joiners».
 * Запуск: java --enable-preview --source 25 JoinerOutcomes.java
 */
public class JoinerOutcomes {

    static final Queue<String> interrupted = new ConcurrentLinkedQueue<>();

    static String send(String id, long delay, RuntimeException failure) throws InterruptedException {
        try { Thread.sleep(delay); }
        catch (InterruptedException e) { interrupted.add(id); throw e; }
        if (failure != null) throw failure;
        return "ACK-" + id;
    }

    /** Как в книге: успехи и ошибки в двух очередях, в порядке завершения. */
    static final class Collecting implements StructuredTaskScope.Joiner<String, String> {
        final Queue<String> order = new ConcurrentLinkedQueue<>();
        final Queue<String> results = new ConcurrentLinkedQueue<>();
        final Queue<Throwable> errors = new ConcurrentLinkedQueue<>();
        @Override public boolean onComplete(Subtask<? extends String> s) {
            switch (s.state()) {
                case SUCCESS -> { results.add(s.get()); order.add(s.get()); }
                case FAILED -> { errors.add(s.exception()); order.add(s.exception().getMessage()); }
                case UNAVAILABLE -> errors.add(new RuntimeException("подзадача отменена"));
            }
            return false;                       // не останавливать остальные
        }
        @Override public String result() { return results + " / ошибок " + errors.size(); }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("JDK " + Runtime.version());
        var joiner = new Collecting();
        long t0 = System.nanoTime();
        try (var scope = StructuredTaskScope.open(joiner)) {
            Subtask<String> p1 = scope.fork(() -> send("P-1", 200, new IllegalStateException("P-1: счёт заблокирован")));
            Subtask<String> p2 = scope.fork(() -> send("P-2", 10, new IllegalArgumentException("P-2: неверный БИК")));
            Subtask<String> p3 = scope.fork(() -> send("P-3", 300, null));
            Subtask<String> p4 = scope.fork(() -> send("P-4", 50, null) + 1 / 0);
            String r = scope.join();
            System.out.println("join() через " + (System.nanoTime() - t0) / 1_000_000 + " мс, не бросил: " + r);
            System.out.println("порядок onComplete (по времени завершения): " + joiner.order);
            System.out.println("ошибки без идентификаторов: " + joiner.errors.stream().map(e -> e.getClass().getSimpleName()).toList());
            System.out.println("по подзадачам в порядке реестра:");
            for (var e : List.of(List.of("P-1", p1), List.of("P-2", p2), List.of("P-3", p3), List.of("P-4", p4))) {
                Subtask<?> s = (Subtask<?>) e.get(1);
                System.out.println("  " + e.get(0) + "  " + s.state() + "  " + (s.state() == Subtask.State.SUCCESS ? s.get() : s.exception()));
            }
        }

        System.out.println("--- Joiner останавливает область на первой ошибке");
        StructuredTaskScope.Joiner<String, Void> stopOnFailure = new StructuredTaskScope.Joiner<>() {
            @Override public boolean onComplete(Subtask<? extends String> s) { return s.state() == Subtask.State.FAILED; }
            @Override public Void result() { return null; }
        };
        long t1 = System.nanoTime();
        try (var scope = StructuredTaskScope.open(stopOnFailure)) {
            Subtask<String> p1 = scope.fork(() -> send("P-1", 200, new IllegalStateException("P-1: счёт заблокирован")));
            Subtask<String> p2 = scope.fork(() -> send("P-2", 10, new IllegalArgumentException("P-2: неверный БИК")));
            Subtask<String> p3 = scope.fork(() -> send("P-3", 300, null));
            scope.join();
            System.out.println("join() через " + (System.nanoTime() - t1) / 1_000_000 + " мс; P-1 " + p1.state() + ", P-2 " + p2.state() + ", P-3 " + p3.state());
        }
        System.out.println("прерваны во сне: " + interrupted.stream().sorted().toList());
    }
}
