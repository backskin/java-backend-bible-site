#!/bin/sh
# Глава 08, 7.8–7.9. AllOfOutcomes и CfThreads — JDK 19+/21+, JoinerOutcomes — JDK 25 (preview).
cd "$(dirname "$0")" || exit 1
java -Dstdout.encoding=UTF-8 AllOfOutcomes.java > s08-allof.txt 2>&1 && cat s08-allof.txt
java -Dstdout.encoding=UTF-8 CfThreads.java > s08-threads.txt 2>&1 && cat s08-threads.txt
java -Dstdout.encoding=UTF-8 --enable-preview --source 25 JoinerOutcomes.java > s08-joiner-jdk25.txt 2>/dev/null && cat s08-joiner-jdk25.txt
