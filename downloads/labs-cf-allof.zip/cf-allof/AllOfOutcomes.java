import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Глава 08, подраздел 7.8: разбор каждой задачи после allOf.
 * Реестр платежей уходит в процессинг параллельно; после общего ожидания
 * нужно знать по каждому платежу, прошёл он или упал и почему.
 * Запуск: java AllOfOutcomes.java (JDK 19+, зависимостей нет).
 */
public class AllOfOutcomes {

    static final ExecutorService io = Executors.newFixedThreadPool(8);
    static final long T0 = System.nanoTime();

    static long ms() { return (System.nanoTime() - T0) / 1_000_000; }

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    // Отправка одного платежа: спит delay мс, затем отвечает или падает.
    static CompletableFuture<String> send(String id, long delay, RuntimeException failure) {
        return CompletableFuture.supplyAsync(() -> {
            sleep(delay);
            if (failure != null) throw failure;
            return "ACK-" + id;
        }, io);
    }

    static String describe(CompletableFuture<?> f) {
        return switch (f.state()) {
            case SUCCESS -> "SUCCESS  " + f.resultNow();
            case FAILED -> "FAILED   " + f.exceptionNow();
            case CANCELLED -> "CANCELLED";
            case RUNNING -> "RUNNING  (ещё не завершён)";
        };
    }

    public static void main(String[] args) throws Exception {
        System.out.println("JDK " + Runtime.version());

        System.out.println("--- 1. allOf ждёт всех и отдаёт одну ошибку");
        Map<String, CompletableFuture<String>> batch = new LinkedHashMap<>();
        batch.put("P-1", send("P-1", 200, new IllegalStateException("P-1: счёт заблокирован")));      // медленная ошибка, первая в списке
        batch.put("P-2", send("P-2", 10, new IllegalArgumentException("P-2: неверный БИК")));         // быстрая ошибка, вторая в списке
        batch.put("P-3", send("P-3", 300, null));                                                    // самый долгий успех
        batch.put("P-4", send("P-4", 50, null).thenApply(ack -> {                                    // падает в зависимой стадии
            throw new RuntimeException("P-4: ответ процессинга не разобран");
        }));
        CompletableFuture<Void> all = CompletableFuture.allOf(batch.values().toArray(CompletableFuture[]::new));
        long start = ms();
        try {
            all.join();
        } catch (CompletionException e) {
            System.out.println("allOf упал через " + (ms() - start) + " мс; причина: " + e.getCause());
            System.out.println("подавленных исключений у причины: " + e.getCause().getSuppressed().length);
        }

        System.out.println("--- 2. разбор каждой задачи через state()/resultNow()/exceptionNow()");
        batch.forEach((id, f) -> System.out.println(id + "  " + describe(f)));

        System.out.println("--- 3. какая ошибка попадает в allOf: порядок аргументов, а не времени");
        CompletableFuture<String> slow = send("S", 150, new IllegalStateException("медленная"));
        CompletableFuture<String> fast = send("F", 5, new IllegalStateException("быстрая"));
        System.out.println("allOf(slow, fast): " + causeOf(CompletableFuture.allOf(slow, fast)));
        System.out.println("allOf(fast, slow): " + causeOf(CompletableFuture.allOf(fast, slow)));

        System.out.println("--- 4. все ошибки в одном исключении: addSuppressed");
        CompletableFuture<List<String>> report = all.handle((ignored, ex) -> {
            List<String> acks = new ArrayList<>();
            RuntimeException agg = null;
            for (var e : batch.entrySet()) {
                CompletableFuture<String> f = e.getValue();
                switch (f.state()) {
                    case SUCCESS -> acks.add(f.resultNow());
                    case FAILED, CANCELLED -> {
                        Throwable cause = f.state() == Future.State.FAILED ? f.exceptionNow() : new CancellationException(e.getKey());
                        if (agg == null) agg = new RuntimeException("реестр отправлен частично");
                        agg.addSuppressed(cause);
                    }
                    case RUNNING -> throw new AssertionError("после allOf задач в работе не бывает");
                }
            }
            if (agg != null) throw agg;
            return acks;
        });
        try {
            report.join();
        } catch (CompletionException e) {
            System.out.println(e.getCause().getMessage() + ", подавлено: " + e.getCause().getSuppressed().length);
            for (Throwable s : e.getCause().getSuppressed()) System.out.println("  " + s);
        }

        System.out.println("--- 5. CANCELLED и isCompletedExceptionally()");
        CompletableFuture<String> cancelled = send("C", 1_000, null);
        cancelled.cancel(true);
        System.out.println("isCompletedExceptionally=" + cancelled.isCompletedExceptionally()
                + ", isCancelled=" + cancelled.isCancelled() + ", state=" + cancelled.state());
        try { cancelled.exceptionNow(); }
        catch (IllegalStateException e) { System.out.println("exceptionNow() у отменённого: IllegalStateException"); }
        try { batch.get("P-1").resultNow(); }
        catch (IllegalStateException e) { System.out.println("resultNow() у упавшего: IllegalStateException"); }

        System.out.println("--- 6. что разворачивает exceptionNow(), а что нет");
        CompletableFuture<String> manual = new CompletableFuture<>();
        manual.completeExceptionally(new CompletionException(new TimeoutException("вручную обёрнут")));
        System.out.println("completeExceptionally(CompletionException(x)): " + manual.exceptionNow());
        CompletableFuture<String> wrapped = send("W", 1, new IllegalStateException("из supplyAsync"));
        sleep(50);
        System.out.println("supplyAsync бросил:  exceptionNow()=" + wrapped.exceptionNow().getClass().getSimpleName()
                + ", а handle видит " + wrapped.handle((v, ex) -> ex.getClass().getSimpleName()).join());

        System.out.println("--- 7. общий таймаут: кто-то ещё в работе");
        CompletableFuture<String> quick = send("Q-1", 20, null);
        CompletableFuture<String> hung = send("Q-2", 700, null);                 // процессинг завис
        CompletableFuture<Void> bounded = CompletableFuture.allOf(quick, hung).orTimeout(100, TimeUnit.MILLISECONDS);
        System.out.println("allOf + orTimeout(100): " + causeOf(bounded));
        System.out.println("Q-1  " + describe(quick));
        System.out.println("Q-2  " + describe(hung));
        sleep(700);
        System.out.println("Q-2 через 700 мс: " + describe(hung) + "  (таймаут allOf задачу не остановил)");

        System.out.println("--- 8. JDK 8–18: исход в значении до allOf");
        record Outcome(String id, String ack, Throwable error) {}
        List<CompletableFuture<Outcome>> outcomes = batch.entrySet().stream()
                .map(e -> e.getValue().handle((ack, ex) -> new Outcome(e.getKey(), ack, ex == null ? null : unwrap(ex))))
                .toList();
        CompletableFuture.allOf(outcomes.toArray(CompletableFuture[]::new)).join();   // не бросает: ошибки стали значениями
        outcomes.forEach(o -> System.out.println(o.join()));

        io.shutdownNow();
    }

    static Throwable unwrap(Throwable ex) {
        return ex instanceof CompletionException && ex.getCause() != null ? ex.getCause() : ex;
    }

    static String causeOf(CompletableFuture<?> f) {
        try { f.join(); return "успех"; }
        catch (CompletionException e) { return e.getCause().toString(); }
    }
}
