# CompletableFuture.allOf и собственный Joiner: исход каждого платежа из реестра

Стенд к главе 08, разделы 7.8–7.9. Три программы без зависимостей на одном сценарии "реестр из четырех платежей, два падают, один проходит, у одного ломается зависимая стадия": `AllOfOutcomes` показывает, что сообщает `allOf` и как достать исход каждой стадии (`exceptionNow`, `state()`), `CfThreads` - в каком потоке выполняются обработчики `thenApply` и `thenApplyAsync`, `JoinerOutcomes` - то же через `StructuredTaskScope` с собственным `Joiner` на JDK 25 (preview). Выводы автора - `s08-allof.txt`, `s08-allof-jdk25.txt`, `s08-threads.txt`, `s08-joiner-jdk25.txt`.

## Что нужно

- JDK 21 для первых двух программ, JDK 25 для `JoinerOutcomes`.

## Запуск

```bash
sh run.sh
```

или по одной: `java -Dstdout.encoding=UTF-8 AllOfOutcomes.java`, для `Joiner` - `java --enable-preview --source 25 JoinerOutcomes.java`. В IDEA на каждую программу есть конфигурация `java <Класс>.java`.

## Что должно получиться

`allOf` завершается ошибкой первого упавшего платежа, остальные исходы приходится собирать по стадиям; `Joiner` собирает успехи и ошибки в две очереди и `join()` не бросает. Время в выводе (около 300 мс) задано задержками в программе.
