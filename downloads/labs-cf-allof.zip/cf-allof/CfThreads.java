import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Глава 08, 7.9: в каком потоке выполняется не-async стадия.
 * Проверяет совет «начать конвейер с Async-варианта, чтобы задать executor,
 * а дальше идти не-async методами с тем же executor» (Хорстманн, Core Java I, 14-е изд., 10.7.2)
 * и наблюдение «thenApply выполняется в том же потоке, что и future» (Эванс и др., 16.2.1).
 * Запуск: java CfThreads.java (JDK 21+, зависимостей нет).
 */
public class CfThreads {

    static ThreadFactory named(String prefix) {
        AtomicInteger n = new AtomicInteger();
        return r -> { Thread t = new Thread(r, prefix + "-" + n.incrementAndGet()); t.setDaemon(true); return t; };
    }

    static final ExecutorService io = Executors.newFixedThreadPool(2, named("io"));
    static final ExecutorService bank = Executors.newFixedThreadPool(2, named("bank-client"));

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); } }
    static String t() { return Thread.currentThread().getName(); }

    public static void main(String[] args) {
        System.out.println("JDK " + Runtime.version());

        System.out.println("--- 1. thenApply зарегистрирован, пока задача в работе");
        var slow = CompletableFuture.supplyAsync(() -> { sleep(200); return "ACK"; }, io);
        System.out.println("thenApply: " + slow.thenApply(x -> t()).join());

        System.out.println("--- 2. thenApply зарегистрирован после завершения задачи");
        var fast = CompletableFuture.supplyAsync(() -> "ACK", io);
        fast.join();
        System.out.println("thenApply: " + fast.thenApply(x -> t()).join());

        System.out.println("--- 3. конвейер: Async с io, затем thenCompose на чужой future, затем thenApply");
        String where = CompletableFuture.completedFuture(42L)
                .thenComposeAsync(id -> CompletableFuture.supplyAsync(() -> { sleep(100); return "payment " + id; }, bank), io)
                .thenApply(p -> t())
                .join();
        System.out.println("thenApply после thenCompose: " + where);

        System.out.println("--- 4. supplyAsync без executor и с executor");
        System.out.println("без executor: " + CompletableFuture.supplyAsync(CfThreads::t).join());
        System.out.println("с executor:   " + CompletableFuture.supplyAsync(CfThreads::t, io).join());
    }
}
