import java.io.*;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.*;
import java.nio.file.*;
import java.text.*;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Collectors;

/**
 * Опыты главы 04 о тексте. Запуск: java TextLab.java (JDK 21 и 25, без зависимостей).
 * Строки с особыми символами записаны прямо в UTF-8 или escape-последовательностями Unicode; исходник хранится в UTF-8.
 */
public class TextLab {

    static void h(String s) { System.out.println("--- " + s); }

    static String cps(String s) {
        return s.codePoints().mapToObj(c -> String.format("U+%04X", c)).collect(Collectors.joining(" "));
    }

    static int graphemes(String s) {
        BreakIterator it = BreakIterator.getCharacterInstance(Locale.ROOT);
        it.setText(s);
        int n = 0;
        while (it.next() != BreakIterator.DONE) n++;
        return n;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java.version=" + System.getProperty("java.version"));

        h("1. Три уровня: char, кодовая точка, графема");
        String thumbs = "👍";
        String family = "👨‍👩‍👧‍👦";
        String flag = "🇷🇺";
        String eAcute = "é";
        String wave = "👋🏿";
        for (String s : List.of(thumbs, family, flag, eAcute, wave))
            System.out.println(cps(s) + " : length=" + s.length() + " codePoints=" + s.codePointCount(0, s.length())
                    + " graphemes=" + graphemes(s) + " \\X-matches=" + countX(s));
        System.out.println("(int) thumbs.charAt(0)=" + (int) thumbs.charAt(0) + " codePointAt(0)=" + thumbs.codePointAt(0));

        h("2. Обрезка посередине пары и запись в UTF-8");
        String hi = "Привет " + "👋" + " мир";
        String cut = hi.substring(0, 8);
        byte[] bytes = cut.getBytes(StandardCharsets.UTF_8);
        System.out.println("последний char 0x" + Integer.toHexString(cut.charAt(7)) + ", последний байт UTF-8 0x" + Integer.toHexString(bytes[bytes.length - 1] & 0xff));
        try {
            StandardCharsets.UTF_8.newEncoder().onMalformedInput(CodingErrorAction.REPORT).encode(CharBuffer.wrap(cut));
            System.out.println("REPORT: без ошибки");
        } catch (CharacterCodingException e) { System.out.println("REPORT: " + e); }
        System.out.println("по кодовым точкам: " + cps(hi.substring(0, hi.offsetByCodePoints(0, 8))));

        h("3. chars() и codePoints()");
        String ab = "a😀b";
        System.out.println(ab.chars().count() + " " + ab.codePoints().count() + " Character.toString(cp)=" + cps(Character.toString(0x1F600)));
        System.out.println("'.' совпадает с эмодзи целиком: " + "😀".matches(".") + ", семья через '.': " + family.matches(".") + ", через \\X: " + family.matches("\\X"));

        h("4. Обрезка под лимит в байтах");
        String rus = "Оплата по счёту";
        System.out.println("байт UTF-8: " + rus.getBytes(StandardCharsets.UTF_8).length + ", length=" + rus.length());
        System.out.println("наивно 7 байт: " + cps(new String(rus.getBytes(StandardCharsets.UTF_8), 0, 7, StandardCharsets.UTF_8)));
        System.out.println("через декодер 7 байт: " + cps(truncateToBytes(rus, 7)));

        h("5. Нормализация");
        String composed = "é", decomposed = "é";
        System.out.println("equals=" + composed.equals(decomposed) + " lengths " + composed.length() + " " + decomposed.length()
                + " NFC equals=" + Normalizer.normalize(composed, Normalizer.Form.NFC).equals(Normalizer.normalize(decomposed, Normalizer.Form.NFC))
                + " isNormalized(decomposed,NFC)=" + Normalizer.isNormalized(decomposed, Normalizer.Form.NFC));
        System.out.println("NFKC(ﬁle)=" + Normalizer.normalize("ﬁle", Normalizer.Form.NFKC)
                + " NFC(ﬁ)=" + cps(Normalizer.normalize("ﬁ", Normalizer.Form.NFC)));
        System.out.println("NFD(ё)=" + cps(Normalizer.normalize("ё", Normalizer.Form.NFD))
                + " NFD(й)=" + cps(Normalizer.normalize("й", Normalizer.Form.NFD)));
        System.out.println("NFC(U+212B)=" + cps(Normalizer.normalize("Å", Normalizer.Form.NFC))
                + " NFKC(²)=" + Normalizer.normalize("²", Normalizer.Form.NFKC)
                + " NFKC(™)=" + Normalizer.normalize("™", Normalizer.Form.NFKC)
                + " NFKC(ｕｓｅｒ)=" + Normalizer.normalize("ｕｓｅｒ", Normalizer.Form.NFKC));
        String nbsp = " " + "100" + " ";
        System.out.println("NBSP: trim=" + cps(nbsp.trim()) + " | strip=" + cps(nbsp.strip()) + " | isWhitespace=" + Character.isWhitespace(' ')
                + " isSpaceChar=" + Character.isSpaceChar(' ') + " | NFKC=" + cps(Normalizer.normalize(nbsp, Normalizer.Form.NFKC)));
        String nfcTwice = Normalizer.normalize(Normalizer.normalize(decomposed, Normalizer.Form.NFC), Normalizer.Form.NFC);
        System.out.println("идемпотентность: " + nfcTwice.equals(Normalizer.normalize(decomposed, Normalizer.Form.NFC)));
        Pattern canon = Pattern.compile("égal", Pattern.CANON_EQ);
        System.out.println("CANON_EQ: " + canon.matcher("égal").matches() + ", без флага: " + Pattern.compile("égal").matcher("égal").matches());

        h("6. Регистр и турецкая I");
        Locale tr = Locale.forLanguageTag("tr");
        System.out.println(cps("I".toLowerCase(tr)) + " " + cps("i".toUpperCase(tr)) + " TITLE->" + "TITLE".toLowerCase(tr)
                + " title->" + "title".toUpperCase(tr));
        System.out.println("Content-Type tr equals: " + "Content-Type".toLowerCase(tr).equals("content-type")
                + ", If-None-Match tr equals: " + "If-None-Match".toLowerCase(tr).equals("if-none-match")
                + ", ID tr: " + "ID".toLowerCase(tr) + ", point->" + "point".toUpperCase(tr));
        Locale prev = Locale.getDefault();
        Locale.setDefault(tr);
        System.out.println("default=tr: \"TITLE\".toLowerCase().equals(\"title\")=" + "TITLE".toLowerCase().equals("title")
                + ", equalsIgnoreCase(\"TITLE\",\"title\")=" + "TITLE".equalsIgnoreCase("title")
                + ", String.format(%.2f)=" + String.format("%.2f", 1.5));
        Locale.setDefault(Locale.GERMANY);
        String de = String.format("%.2f", 1.234);
        System.out.println("default=de: String.format=" + de + ", parseDouble: " + tryIt(() -> Double.parseDouble(de)));
        Locale.setDefault(prev);
        System.out.println("ß upper=" + "ß".toUpperCase(Locale.ROOT) + " len=" + "ß".toUpperCase(Locale.ROOT).length()
                + " Straße->" + "Straße".toUpperCase(Locale.GERMAN) + " ﬁ upper=" + "ﬁ".toUpperCase(Locale.ROOT)
                + " ß up-low=" + "ß".toUpperCase(Locale.ROOT).toLowerCase(Locale.ROOT));
        System.out.println("Pattern CI ASCII: " + Pattern.compile("счёт", Pattern.CASE_INSENSITIVE).matcher("СЧЁТ").matches()
                + ", CI|UNICODE_CASE: " + Pattern.compile("счёт", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE).matcher("СЧЁТ").matches());

        h("7. Сортировка");
        List<String> l = new ArrayList<>(List.of("Ящик", "яблоко", "Арбуз", "ёлка", "Енот"));
        l.sort(Comparator.naturalOrder());
        System.out.println("compareTo: " + l);
        Collator ru = Collator.getInstance(Locale.forLanguageTag("ru"));
        ru.setStrength(Collator.SECONDARY);
        l.sort(ru);
        System.out.println("Collator: " + l);
        System.out.println("эмодзи compareTo U+FFFD: " + Integer.signum("😀".compareTo("�"))
                + ", по кодовым точкам: " + Integer.signum(Integer.compare(0x1F600, 0xFFFD)));
        Collator prim = Collator.getInstance(Locale.forLanguageTag("ru"));
        prim.setStrength(Collator.PRIMARY);
        System.out.println("PRIMARY е==ё: " + (prim.compare("елка", "ёлка") == 0));
        List<String> big = new ArrayList<>();
        Random r = new Random(1);
        for (int i = 0; i < 200_000; i++) big.add(randomRu(r));
        for (int w = 0; w < 2; w++) {
            List<String> c1 = new ArrayList<>(big), c2 = new ArrayList<>(big), c3 = new ArrayList<>(big);
            long t0 = System.nanoTime(); c1.sort(Comparator.naturalOrder());
            long t1 = System.nanoTime(); c2.sort(ru);
            long t2 = System.nanoTime();
            Map<String, CollationKey> keys = new HashMap<>();
            c3.sort(Comparator.comparing(s -> keys.computeIfAbsent(s, ru::getCollationKey)));
            long t3 = System.nanoTime();
            if (w == 1) System.out.printf("200000 строк: compareTo %d мс, Collator %d мс, CollationKey %d мс%n", (t1 - t0) / 1_000_000, (t2 - t1) / 1_000_000, (t3 - t2) / 1_000_000);
        }

        h("8. Кодировки по умолчанию");
        for (String p : List.of("file.encoding", "native.encoding", "sun.jnu.encoding", "stdout.encoding"))
            System.out.println(p + "=" + System.getProperty(p));
        System.out.println("defaultCharset=" + Charset.defaultCharset());

        h("9. BOM");
        Path csv = Files.createTempFile("bom", ".csv");
        Files.write(csv, new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF, 'i', 'd', ';', 'n', 'a', 'm', 'e', '\n'});
        String first = Files.readAllLines(csv, StandardCharsets.UTF_8).get(0);
        System.out.println("equals(\"id;name\")=" + first.equals("id;name") + " charAt(0)=" + (int) first.charAt(0));
        Files.delete(csv);

        h("10. Кракозябры");
        String privet = "Привет";
        System.out.println("UTF-8 как windows-1251: " + new String(privet.getBytes(StandardCharsets.UTF_8), "windows-1251"));
        System.out.println("UTF-8 как windows-1252: " + new String(privet.getBytes(StandardCharsets.UTF_8), "windows-1252"));
        System.out.println("windows-1251 как ISO-8859-1: " + new String(privet.getBytes("windows-1251"), StandardCharsets.ISO_8859_1));
        System.out.println("в US-ASCII: " + new String(privet.getBytes(StandardCharsets.US_ASCII), StandardCharsets.US_ASCII));
        System.out.println("windows-1251 как UTF-8: " + cps(new String(privet.getBytes("windows-1251"), StandardCharsets.UTF_8)).substring(0, 20));
        String moj = new String(privet.getBytes(StandardCharsets.UTF_8), "windows-1251");
        System.out.println("обратно: " + new String(moj.getBytes("windows-1251"), StandardCharsets.UTF_8));
        byte[] all = new byte[256];
        for (int i = 0; i < 256; i++) all[i] = (byte) i;
        System.out.println("ISO-8859-1 туда-обратно: " + Arrays.equals(all, new String(all, StandardCharsets.ISO_8859_1).getBytes(StandardCharsets.ISO_8859_1))
                + ", UTF-8 туда-обратно: " + Arrays.equals(all, new String(all, StandardCharsets.UTF_8).getBytes(StandardCharsets.UTF_8)));

        h("11. Гомоглифы и невидимые символы");
        System.out.println("single script Иванов=" + singleScript("Иванов")
                + " Ivаnov=" + singleScript("Ivаnov"));
        Pattern inv = Pattern.compile("[\\p{Cf}\\p{Cc}&&[^\\n\\r\\t]]");
        String sneaky = "adm​in";
        System.out.println("adm+ZWSP+in equals admin=" + sneaky.equals("admin") + ", после фильтра=" + inv.matcher(sneaky).replaceAll("").equals("admin")
                + ", RLO категория=" + Character.getType(0x202E) + " (FORMAT=" + Character.FORMAT + ")");

        h("12. \\w, \\d и Unicode-классы");
        String ivanov = "Иванов";
        System.out.println("\\w+ " + ivanov.matches("\\w+") + ", UNICODE_CHARACTER_CLASS " + Pattern.compile("\\w+", Pattern.UNICODE_CHARACTER_CLASS).matcher(ivanov).matches()
                + ", \\d+ на ١٢ " + "١٢".matches("\\d+") + ", \\p{Nd}+ " + "١٢".matches("\\p{Nd}+"));
        Pattern name = Pattern.compile("^[\\p{IsCyrillic}\\p{IsLatin} .'-]{1,100}$");
        System.out.println(name.matcher("Иванов-Петров").matches() + " " + name.matcher("Ivanov O'Brien").matches());
        System.out.println("replaceAll с $: " + tryIt(() -> "price".replaceAll("price", "$5")) + " | quoteReplacement: " + "price".replaceAll("price", Matcher.quoteReplacement("$5")));

        h("13. Перебор с возвратами");
        Pattern bad = Pattern.compile("^(a+)+$");
        for (int n = 16; n <= 28; n += 2) {
            String s = "a".repeat(n) + "!";
            long t0 = System.nanoTime();
            bad.matcher(s).matches();
            System.out.printf("n=%d %d мс%n", n, (System.nanoTime() - t0) / 1_000_000);
        }
        for (String p : List.of("^(a+)++$", "^(?>a+)+$", "^a+$")) {
            long t0 = System.nanoTime();
            boolean m = Pattern.compile(p).matcher("a".repeat(100_000) + "!").matches();
            System.out.printf("%s на 100000: %s %d мс%n", p, m, (System.nanoTime() - t0) / 1_000_000);
        }
        Pattern so = Pattern.compile("^[\\s\\u200c]+|[\\s\\u200c]+$");
        for (int n : new int[]{5_000, 10_000, 20_000}) {
            String post = "x" + " ".repeat(n) + "x";
            long t0 = System.nanoTime();
            so.matcher(post).replaceAll("");
            System.out.printf("обрезка пробелов (как Stack Overflow 2016), %d пробелов внутри: %d мс%n", n, (System.nanoTime() - t0) / 1_000_000);
        }
        Pattern cf = Pattern.compile(".*(?:.*=.*)");
        for (int n : new int[]{1_000, 2_000, 4_000}) {
            String in = "x".repeat(n);
            long t0 = System.nanoTime();
            cf.matcher(in).matches();
            System.out.printf(".*(?:.*=.*) на %d символах без '=': %d мс%n", n, (System.nanoTime() - t0) / 1_000_000);
        }
        String evil = "a".repeat(40) + "!";
        long t0 = System.nanoTime();
        System.out.println("таймаут: " + tryIt(() -> bad.matcher(new TimeLimitedCharSequence(evil, Duration.ofMillis(100))).matches())
                + " за " + (System.nanoTime() - t0) / 1_000_000 + " мс");
        System.out.println("String.matches в цикле и константа:");
        Pattern iso = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");
        long sink = 0;
        for (int w = 0; w < 3; w++) {
            long a0 = System.nanoTime();
            for (int i = 0; i < 1_000_000; i++) if ("2026-09-21".matches("^\\d{4}-\\d{2}-\\d{2}$")) sink++;
            long a1 = System.nanoTime();
            for (int i = 0; i < 1_000_000; i++) if (iso.matcher("2026-09-21").matches()) sink++;
            long a2 = System.nanoTime();
            if (w == 2) System.out.printf("  String.matches %d нс, Pattern-константа %d нс на вызов (sink %d)%n", (a1 - a0) / 1_000_000, (a2 - a1) / 1_000_000, sink % 7);
        }

        h("14. Числа и локали");
        double v = 1234567.89;
        for (String tag : List.of("ru", "en-US", "de-DE", "fr")) {
            String f = NumberFormat.getInstance(Locale.forLanguageTag(tag)).format(v);
            System.out.println(tag + ": " + f + "  [" + cps(f.replaceAll("[0-9]", "")) + "]");
        }
        System.out.println("parse(123abc)=" + NumberFormat.getInstance(Locale.US).parse("123abc"));
        ParsePosition pp = new ParsePosition(0);
        NumberFormat.getInstance(Locale.US).parse("123abc", pp);
        System.out.println("ParsePosition index=" + pp.getIndex() + " из 6");
        NumberFormat cfm = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("ru-RU"));
        cfm.setCurrency(Currency.getInstance("USD"));
        String cur = cfm.format(new BigDecimal("1234.5"));
        System.out.println("ru-RU USD: " + cur + " [" + cps(cur.replaceAll("[0-9]", "")) + "] ; 1234.567 -> " + cfm.format(new BigDecimal("1234.567")));
        DecimalFormat df = (DecimalFormat) NumberFormat.getInstance(Locale.US);
        df.setParseBigDecimal(true);
        System.out.println("setParseBigDecimal: " + df.parse("0.1") + " " + df.parse("0.1").getClass().getSimpleName()
                + "; без него: " + NumberFormat.getInstance(Locale.US).parse("0.1").getClass().getSimpleName());
        NumberFormat de2 = NumberFormat.getInstance(Locale.GERMANY);
        System.out.println("de: \"1.234\" -> " + de2.parse("1.234") + ", US: \"1.234\" -> " + NumberFormat.getInstance(Locale.US).parse("1.234"));

        h("15. MessageFormat и ChoiceFormat");
        System.out.println(MessageFormat.format("Don't {0}", "pay") + " | " + MessageFormat.format("Don''t {0}", "pay"));
        MessageFormat choice = new MessageFormat("{0,choice,0#{0} платежей|1#{0} платёж|2#{0} платежа|5#{0} платежей}", Locale.forLanguageTag("ru"));
        for (int n : new int[]{1, 3, 5, 11, 21, 22}) System.out.print(choice.format(new Object[]{n}) + "; ");
        System.out.println();

        h("16. ResourceBundle: запасная локаль");
        Path dir = Files.createTempDirectory("rb");
        Files.writeString(dir.resolve("msg.properties"), "hello=Hello\n");
        Files.writeString(dir.resolve("msg_ru.properties"), "hello=Привет\n", StandardCharsets.UTF_8);
        try (URLClassLoader cl = new URLClassLoader(new URL[]{dir.toUri().toURL()})) {
            Locale.setDefault(Locale.forLanguageTag("ru"));
            System.out.println("default=ru, запрошен fr: " + ResourceBundle.getBundle("msg", Locale.FRENCH, cl).getString("hello"));
            ResourceBundle.clearCache(cl);
            System.out.println("с NoFallbackControl: " + ResourceBundle.getBundle("msg", Locale.FRENCH, cl,
                    ResourceBundle.Control.getNoFallbackControl(ResourceBundle.Control.FORMAT_DEFAULT)).getString("hello"));
            Locale.setDefault(prev);
        }
    }

    static int countX(String s) {
        Matcher m = Pattern.compile("\\X").matcher(s);
        int n = 0;
        while (m.find()) n++;
        return n;
    }

    static String randomRu(Random r) {
        StringBuilder sb = new StringBuilder();
        int len = 5 + r.nextInt(8);
        for (int i = 0; i < len; i++) sb.append((char) ((r.nextBoolean() ? 0x0410 : 0x0430) + r.nextInt(32)));
        return sb.toString();
    }

    static boolean singleScript(String s) {
        return s.codePoints().mapToObj(Character.UnicodeScript::of)
                .filter(sc -> sc != Character.UnicodeScript.COMMON && sc != Character.UnicodeScript.INHERITED)
                .collect(Collectors.toSet()).size() <= 1;
    }

    static String truncateToBytes(String s, int maxBytes) {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        if (b.length <= maxBytes) return s;
        CharsetDecoder dec = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.IGNORE);
        CharBuffer cb = CharBuffer.allocate(maxBytes);
        dec.decode(ByteBuffer.wrap(b, 0, maxBytes), cb, true);
        dec.flush(cb);
        return cb.flip().toString();
    }

    static final class TimeLimitedCharSequence implements CharSequence {
        private final CharSequence inner;
        private final long deadline;
        TimeLimitedCharSequence(CharSequence inner, Duration limit) { this.inner = inner; this.deadline = System.nanoTime() + limit.toNanos(); }
        private TimeLimitedCharSequence(CharSequence inner, long deadline) { this.inner = inner; this.deadline = deadline; }
        @Override public char charAt(int i) {
            if (System.nanoTime() > deadline) throw new RuntimeException("Regex timeout");
            return inner.charAt(i);
        }
        @Override public int length() { return inner.length(); }
        @Override public CharSequence subSequence(int s, int e) { return new TimeLimitedCharSequence(inner.subSequence(s, e), deadline); }
        @Override public String toString() { return inner.toString(); }
    }

    interface Call { Object run() throws Exception; }

    static String tryIt(Call c) {
        try { return String.valueOf(c.run()); }
        catch (Exception e) { return e.getClass().getSimpleName() + ": " + e.getMessage(); }
    }
}
