import java.text.BreakIterator;
import java.util.List;
import java.util.Locale;

/** Grapheme count by java.text.BreakIterator on different JDKs (extended grapheme clusters came with JDK 20, JDK-8291660). */
public class Grapheme {
    static int graphemes(String s) {
        BreakIterator it = BreakIterator.getCharacterInstance(Locale.ROOT);
        it.setText(s);
        int n = 0;
        while (it.next() != BreakIterator.DONE) n++;
        return n;
    }

    public static void main(String[] args) {
        System.out.println("java.version=" + System.getProperty("java.version"));
        String thumbs = "👍";                                   // thumbs up
        String family = "👨‍👩‍👧‍👦";   // family (ZWJ sequence)
        String flag = "🇷🇺";                          // flag RU (two regional indicators)
        String eAcute = "é";                                         // e + combining acute
        String wave = "👋🏿";                          // waving hand + skin tone
        String[] names = {"thumbs", "family", "flag", "e+acute", "wave+tone"};
        List<String> all = List.of(thumbs, family, flag, eAcute, wave);
        for (int i = 0; i < all.size(); i++) {
            String s = all.get(i);
            System.out.println(names[i] + ": length=" + s.length() + " codePoints=" + s.codePointCount(0, s.length()) + " graphemes=" + graphemes(s));
        }
    }
}
