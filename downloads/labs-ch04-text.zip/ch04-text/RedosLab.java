import java.util.List;
import java.util.regex.Pattern;

/**
 * Какие уязвимые шаблоны взрываются на современном java.util.regex. Запуск: java RedosLab.java.
 * Для каждого шаблона ввод растёт, пока одно сопоставление не займёт больше 2 секунд.
 */
public class RedosLab {
    record Case(String regex, String unit, String tail) {}

    public static void main(String[] args) {
        System.out.println("java.version=" + System.getProperty("java.version"));
        List<Case> cases = List.of(
                new Case("^(a+)+$", "a", "!"),
                new Case("^(a*)*$", "a", "!"),
                new Case("^(a|a)+$", "a", "!"),
                new Case("^(a|aa)+$", "a", "!"),
                new Case("^(\\d+)*$", "1", "x"),
                new Case("^(\\w+\\s?)*$", "a", "!"),
                new Case("^([a-zA-Z0-9]+\\.?)+@", "a", "!"),
                new Case("^(a+)+b", "a", "c"),
                new Case("^(x+x+)+y$", "x", "z"),
                new Case("(.*a){12}", "a", "!"),
                new Case("^(([a-z])+.)+[A-Z]([a-z])+$", "a", "!"),
                new Case("^(a+)\\1*(a+)+$", "a", "!"),
                new Case("^(?=(a+)+)(a+)+!$", "a", "b"),
                new Case("^(a?){25}a{25}$", "a", ""),
                new Case("^(\\s*,)*\\s*$", " ", "x"),
                new Case("^(?:(\\w)\\1?)+$", "a", "!"));
        for (Case c : cases) {
            Pattern p = Pattern.compile(c.regex());
            StringBuilder sb = new StringBuilder();
            for (int n = 10; n <= 40; n += 2) {
                String s = c.unit().repeat(n) + c.tail();
                long t0 = System.nanoTime();
                boolean m = p.matcher(s).find();
                long ms = (System.nanoTime() - t0) / 1_000_000;
                sb.append(" n=").append(n).append(':').append(ms).append("мс");
                if (ms > 2000) break;
            }
            System.out.println(c.regex() + " ->" + sb);
        }
    }
}
