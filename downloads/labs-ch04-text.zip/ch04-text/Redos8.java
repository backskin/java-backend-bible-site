import java.util.regex.Pattern;

/** Тот же шаблон ^(a+)+$ на разных JDK (исходник совместим с Java 8). Запуск: javac Redos8.java && java Redos8. */
public class Redos8 {
    public static void main(String[] args) {
        System.out.println("java.version=" + System.getProperty("java.version"));
        Pattern p = Pattern.compile("^(a+)+$");
        for (int n = 16; n <= 30; n += 2) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n; i++) sb.append('a');
            String s = sb.append('!').toString();
            long t0 = System.nanoTime();
            p.matcher(s).matches();
            long ms = (System.nanoTime() - t0) / 1000000;
            System.out.println("n=" + n + " " + ms + " ms");
            if (ms > 5000) break;
        }
    }
}
