package dev.team.settle;

import org.springframework.aot.hint.MemberCategory;
import org.springframework.aot.hint.RuntimeHints;
import org.springframework.aot.hint.RuntimeHintsRegistrar;
import org.springframework.context.annotation.ImportRuntimeHints;
import org.springframework.stereotype.Service;

/** Отчёт по расчётам: шаблон из ресурсов и строка отчёта, которую библиотека шаблонов читает рефлексией. */
@Service
@ImportRuntimeHints(ReportService.Hints.class)
public class ReportService {
    public record ReportRow(String account, long kopecks) {}

    static class Hints implements RuntimeHintsRegistrar {
        @Override public void registerHints(RuntimeHints hints, ClassLoader cl) {
            hints.resources().registerPattern("templates/settlement-report.ftl");
            hints.reflection().registerType(ReportRow.class, MemberCategory.INVOKE_PUBLIC_METHODS);
        }
    }
}
