package dev.team.settle;

import jakarta.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicInteger;

/** Сервис расчётов для опыта с тестовыми контекстами: каждый новый контекст печатает свой номер. */
@SpringBootApplication
public class SettleApp {
    public static final AtomicInteger CONTEXTS = new AtomicInteger();

    public static void main(String[] args) {
        try (var ctx = SpringApplication.run(SettleApp.class, args)) {
            System.out.println(">>> режим AOT: " + org.springframework.aot.AotDetector.useGeneratedArtifacts()
                    + ", профили: " + java.util.Arrays.toString(ctx.getEnvironment().getActiveProfiles())
                    + ", SbpChannel: " + (ctx.getBeanNamesForType(SbpChannel.class).length == 1)
                    + ", FraudFilter: " + (ctx.getBeanNamesForType(FraudFilter.class).length == 1)
                    + ", settle.batch-size=" + ctx.getEnvironment().getProperty("settle.batch-size"));
        }
    }

    /** Канал СБП нужен только в профиле sbp. */
    @Component @org.springframework.context.annotation.Profile("sbp")
    public static class SbpChannel { }

    /** Антифрод включается свойством. */
    @Component @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty("settle.fraud.enabled")
    public static class FraudFilter { }

    @Component
    public static class ContextCounter {
        @PostConstruct void started() {
            System.out.println(">>> поднят тестовый контекст №" + CONTEXTS.incrementAndGet());
        }
    }

    public interface PaymentGateway { String charge(String account, long kopecks); }

    @Component
    public static class BankGateway implements PaymentGateway {
        @Override public String charge(String account, long kopecks) { return "OK " + account + " " + kopecks; }
    }

    @Component
    public static class Notifier { public String sms(String phone) { return "SMS " + phone; } }

    @Service
    public static class SettlementService {
        private final PaymentGateway gateway; private final Notifier notifier;
        public SettlementService(PaymentGateway gateway, Notifier notifier) { this.gateway = gateway; this.notifier = notifier; }
        public String settle(String account, long kopecks) { return gateway.charge(account, kopecks) + "; " + notifier.sms("+7 900 000-00-01"); }
    }
}
