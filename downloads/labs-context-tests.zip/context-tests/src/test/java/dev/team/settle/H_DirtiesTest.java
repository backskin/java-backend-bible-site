package dev.team.settle;

import dev.team.settle.SettleApp.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class H_DirtiesTest {
    @BeforeAll static void title() { System.out.println("--- " + "H_DirtiesTest"); }
    @Autowired SettlementService service;
    @Test void first() { assertThat(service.settle("40702810900000000008", 1)).startsWith("OK"); }
    @Test void second() { assertThat(service.settle("40702810900000000008", 2)).startsWith("OK"); }
    @Test void third() { assertThat(service.settle("40702810900000000008", 3)).startsWith("OK"); }
}
