package dev.team.settle;

import dev.team.settle.SettleApp.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

@SpringBootTest
class D_MockGatewayTest {
    @BeforeAll static void title() { System.out.println("--- " + "D_MockGatewayTest"); }
    @MockitoBean PaymentGateway gateway;
    @Autowired SettlementService service;
    @Test void declined() { given(gateway.charge("40702810900000000004", 1_000)).willReturn("DECLINED"); assertThat(service.settle("40702810900000000004", 1_000)).startsWith("DECLINED"); }
}
