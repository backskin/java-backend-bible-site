package dev.team.settle;

import dev.team.settle.SettleApp.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

@SpringBootTest
class A_PlainTest {
    @BeforeAll static void title() { System.out.println("--- " + "A_PlainTest"); }
    @Autowired SettlementService service;
    @Test void settles() { assertThat(service.settle("40702810900000000001", 150_000)).startsWith("OK"); }
}
