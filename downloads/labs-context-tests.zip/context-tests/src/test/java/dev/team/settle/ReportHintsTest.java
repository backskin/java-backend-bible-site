package dev.team.settle;

import org.junit.jupiter.api.Test;
import org.springframework.aot.hint.MemberCategory;
import org.springframework.aot.hint.RuntimeHints;
import org.springframework.aot.hint.predicate.RuntimeHintsPredicates;

import static org.assertj.core.api.Assertions.assertThat;

/** Подсказки проверяют модульным тестом, без сборки нативного образа. */
class ReportHintsTest {
    @Test void reportRowAndTemplateAreRegistered() {
        var hints = new RuntimeHints();
        new ReportService.Hints().registerHints(hints, getClass().getClassLoader());
        assertThat(RuntimeHintsPredicates.reflection().onType(ReportService.ReportRow.class)
                .withMemberCategory(MemberCategory.INVOKE_PUBLIC_METHODS)).accepts(hints);
        assertThat(RuntimeHintsPredicates.resource().forResource("templates/settlement-report.ftl")).accepts(hints);
        assertThat(RuntimeHintsPredicates.resource().forResource("templates/other.ftl")).rejects(hints);
    }
}
