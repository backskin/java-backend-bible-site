package dev.team.settle;

import dev.team.settle.SettleApp.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.convention.TestBean;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class J_TestBeanTest {
    @BeforeAll static void title() { System.out.println("--- J_TestBeanTest"); }

    @TestBean PaymentGateway gateway;                                   // подмена настоящей тестовой реализацией
    static PaymentGateway gateway() { return (account, kopecks) -> "STUB-BANK " + account; }

    @Autowired SettlementService service;
    @Test void usesTestImplementation() { assertThat(service.settle("40702810900000000010", 1)).startsWith("STUB-BANK"); }
}
