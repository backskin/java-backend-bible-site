# Кэш тестовых контекстов Spring и обработка AOT на Spring Boot 4.1

Стенд к главе 09, разделы 14–15. Приложение `SettleApp` (сервис расчетов) и десять тестовых классов `A_PlainTest` … `J_TestBeanTest`, которые отличаются профилем, `@MockitoBean`, свойствами, `@DirtiesContext` и `@TestBean`: по статистике кэша из журнала `org.springframework.test.context.cache` видно, сколько контекстов поднялось и какие тесты его разделили. `ReportHintsTest` проверяет подсказки AOT. Результаты - в сносках главы (раздел 14.2 и 15.2).

## Что нужно

- JDK 21 и Maven; Spring Boot 4.1.1, JUnit 6 и Mockito скачаются сами.

## Запуск

```bash
mvn -q test
```

Строка статистики кэша печатается в конце каждого теста (`Spring test ApplicationContext cache statistics`). AOT:

```bash
mvn -q spring-boot:process-aot
```

Затем сгенерированные исходники из `target/spring-aot/main/sources` компилируются и приложение запускается с `-Dspring.aot.enabled=true`, время старта - строка `Started SettleApp`. В IDEA есть конфигурации `SettleApp` и `mvn test`.

## Что должно получиться

Тесты `A`, `B`, `I` используют один контекст, `C`, `D`, `F`, `G`, `H` поднимают свои; `MockBean` и `SpyBean` в `spring-boot-test` 4.x отсутствуют, вместо них `@MockitoBean`.
