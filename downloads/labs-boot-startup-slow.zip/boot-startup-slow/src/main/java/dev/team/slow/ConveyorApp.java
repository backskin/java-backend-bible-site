package dev.team.slow;

import jakarta.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.metrics.buffering.BufferingApplicationStartup;
import org.springframework.core.metrics.StartupStep;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Comparator;
import java.util.stream.StreamSupport;

/**
 * Кредитный конвейер с «медленным» стартом: миграции Flyway, JPA, клиент бюро, ждущий в конструкторе,
 * загрузчик справочника в @PostConstruct. Печатает самые долгие шаги старта с их тегами.
 */
@SpringBootApplication
public class ConveyorApp {

    interface ProductRepository extends JpaRepository<Product, Long> { }

    /** Клиент бюро кредитных историй: «устанавливает соединение» прямо в конструкторе. */
    @Component
    static class BureauClient {
        BureauClient() throws InterruptedException { Thread.sleep(1200); }
    }

    /** Загрузчик справочника тарифов в @PostConstruct. */
    @Component
    static class TariffLoader {
        @PostConstruct
        void load() throws InterruptedException { Thread.sleep(800); }
    }

    public static void main(String[] args) {
        BufferingApplicationStartup startup = new BufferingApplicationStartup(8192);
        SpringApplication app = new SpringApplication(ConveyorApp.class);
        app.setApplicationStartup(startup);
        var ctx = app.run(args);
        System.out.println("   самые долгие шаги без учёта вложенности (мс, имя, теги):");
        startup.getBufferedTimeline().getEvents().stream()
                .filter(e -> !e.getStartupStep().getName().equals("spring.context.refresh")
                        && !e.getStartupStep().getName().startsWith("spring.boot.application"))
                .sorted(Comparator.comparing((org.springframework.boot.context.metrics.buffering.StartupTimeline.TimelineEvent e) -> e.getDuration()).reversed())
                .limit(14)
                .forEach(e -> System.out.printf("   %6d  %-40s %s%n", e.getDuration().toMillis(), e.getStartupStep().getName(), tags(e.getStartupStep())));
        System.out.println("   все имена шагов: " + startup.getBufferedTimeline().getEvents().stream().map(e -> e.getStartupStep().getName()).distinct().sorted().toList());
        startup.getBufferedTimeline().getEvents().stream().filter(e -> e.getStartupStep().getName().contains("scan"))
                .forEach(e -> System.out.println("   " + e.getDuration().toMillis() + " мс " + e.getStartupStep().getName() + " " + tags(e.getStartupStep())));
        ctx.close();
    }

    static String tags(StartupStep s) {
        return StreamSupport.stream(s.getTags().spliterator(), false)
                .map(t -> t.getKey() + "=" + t.getValue()).reduce((a, b) -> a + ", " + b).orElse("");
    }

    static Duration unused() { return Duration.ZERO; }
}
