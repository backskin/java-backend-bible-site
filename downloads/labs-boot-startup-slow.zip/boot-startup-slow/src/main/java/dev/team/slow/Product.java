package dev.team.slow;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

/** Кредитный продукт из справочника, который создаёт миграция V1. */
@Entity
public class Product {
    @Id Long id;
    String name;
}
