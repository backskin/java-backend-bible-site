create table product (id bigint primary key, name varchar(100));
insert into product values (1, 'Потребительский кредит');
insert into product values (2, 'Кредитная карта');
