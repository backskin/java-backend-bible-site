# Медленный старт Spring Boot: самые долгие шаги по BufferingApplicationStartup

Стенд к главе 10, раздел о диагностике старта. Кредитный конвейер `ConveyorApp` (Spring Boot 4.1.1, Spring Data JPA с H2, Flyway) запускается с `BufferingApplicationStartup`, и после подъема контекста печатает самые долгие шаги без учета вложенности с их тегами: фабрика `EntityManager`, миграции, создание Tomcat. Вывод автора - `s10-slow-start.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile exec:java -Dexec.mainClass=dev.team.slow.ConveyorApp
```

В IDEA есть конфигурация `ConveyorApp`.

## Что должно получиться

Наверху списка `spring.beans.instantiate` с тегом `beanName=&entityManagerFactory` (у автора 1945 мс), ниже Flyway и `spring.boot.webserver.create`. Абсолютные значения зависят от машины.
