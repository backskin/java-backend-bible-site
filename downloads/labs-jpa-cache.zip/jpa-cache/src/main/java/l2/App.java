package l2;

import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Immutable;
import org.hibernate.stat.CacheRegionStatistics;
import org.hibernate.stat.Statistics;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Разд. 11.16–11.17 гл. 12: конфигурация из главы (Ehcache 3 через JCache, ehcache.xml, missing_cache_strategy=fail)
 * на Spring Boot 4.1.1 и Hibernate 7.4.5. Аргументы:
 *   (без аргументов) — справочники в кэше, кэш запросов, статистика регионов;
 *   none            — jakarta.persistence.sharedCache.mode=NONE: кэшируются ли сущности с @Cache;
 *   missing         — сущность с регионом, которого нет в ehcache.xml, при missing_cache_strategy=fail.
 */
@SpringBootApplication
public class App {

    @Entity(name = "BankBic") @Immutable @Cacheable
    @Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "dict.bank-bic")
    @Table(name = "bank_bic")
    public static class BankBic {
        @Id String bic;
        String name;
        String correspondentAccount;
        LocalDate validTo;
        protected BankBic() {}
        BankBic(String bic, String name) { this.bic = bic; this.name = name; }
    }

    @Entity(name = "Currency") @Immutable @Cacheable
    @Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "dict.currency")
    @Table(name = "currency")
    public static class Currency {
        @Id String code;
        boolean active = true;
        protected Currency() {}
        Currency(String code) { this.code = code; }
    }

    /** Разд. 11.12: коллекция в кэше, элементы — нет. */
    @Entity(name = "Tariff") @Cacheable @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "tariff") @Table(name = "tariff")
    public static class Tariff {
        @Id Long id;
        String code;
        @OneToMany(mappedBy = "tariff", cascade = CascadeType.PERSIST)
        @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "tariff.rules")
        List<TariffRule> rules = new java.util.ArrayList<>();
    }

    @Entity(name = "TariffRule") @Table(name = "tariff_rule")
    public static class TariffRule {
        @Id Long id;
        @ManyToOne(fetch = FetchType.LAZY) Tariff tariff;
        java.math.BigDecimal feePercent;
    }

    /** Тот же тариф, но правила тоже в кэше. */
    @Entity(name = "TariffC") @Cacheable @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "tariff-cached") @Table(name = "tariff_c")
    public static class TariffC {
        @Id Long id;
        @OneToMany(mappedBy = "tariff", cascade = CascadeType.PERSIST)
        @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "tariff-cached.rules")
        List<TariffRuleC> rules = new java.util.ArrayList<>();
    }

    @Entity(name = "TariffRuleC") @Cacheable @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "tariff-rule-cached") @Table(name = "tariff_rule_c")
    public static class TariffRuleC {
        @Id Long id;
        @ManyToOne(fetch = FetchType.LAZY) TariffC tariff;
        java.math.BigDecimal feePercent;
    }

    /** Разд. 14.13: использование лимита карты, меняется при каждой авторизации. */
    @Entity(name = "CardLimitUsage") @Table(name = "card_limit_usage")
    public static class CardLimitUsage {
        @Id @GeneratedValue Long id;
        Long cardId;
        long used;
    }

    public static void main(String[] args) {
        String mode = args.length > 0 ? args[0] : "";
        Map<String, Object> props = new HashMap<>(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:l2",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        if (mode.equals("none")) props.put("spring.jpa.properties.jakarta.persistence.sharedCache.mode", "NONE");
        if (mode.equals("missing")) props.put("spring.jpa.properties.hibernate.cache.region_prefix", "нет-такого");
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(props);
        System.out.println("режим: " + (mode.isEmpty() ? "конфигурация из главы" : mode) + ", hibernate.javax.cache.uri = "
                + System.getProperty("spring.jpa.properties.hibernate.javax.cache.uri", "classpath://ehcache.xml (из application.yml)"));
        ConfigurableApplicationContext ctx;
        try {
            ctx = app.run();
        } catch (RuntimeException e) {
            Throwable c = e; while (c.getCause() != null) c = c.getCause();
            System.out.println("   приложение не стартовало: " + c.getClass().getSimpleName() + ": " + c.getMessage().lines().findFirst().orElse(""));
            return;
        }
        try (ctx) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            Statistics st = ctx.getBean(EntityManagerFactory.class).unwrap(SessionFactory.class).getStatistics();
            System.out.println("   hibernate-core " + org.hibernate.Version.getVersionString() + ", фабрика регионов: "
                    + ctx.getBean(EntityManagerFactory.class).unwrap(SessionFactory.class).getSessionFactoryOptions()
                        .getServiceRegistry().getService(org.hibernate.cache.spi.RegionFactory.class).getClass().getName());
            tx.executeWithoutResult(s -> {
                em.persist(new BankBic("044525225", "ПАО Тундра-Банк"));
                em.persist(new BankBic("044525974", "АО Банк-Партнёр"));
                for (String c : List.of("RUB", "USD", "EUR", "CNY")) em.persist(new Currency(c));
            });
            st.clear();
            for (int i = 1; i <= 3; i++) {
                tx.executeWithoutResult(s -> em.find(BankBic.class, "044525225"));
            }
            System.out.println("   find одного БИК в трёх транзакциях: запросов к базе " + st.getPrepareStatementCount()
                    + ", кэш: " + region(st, "dict.bank-bic"));
            ctx.getBeanProvider(io.micrometer.core.instrument.MeterRegistry.class).ifAvailable(reg ->
                    System.out.println("   то же в Micrometer: hibernate.second.level.cache.requests{region=dict.bank-bic,result=hit} = "
                            + reg.get("hibernate.second.level.cache.requests").tag("region", "dict.bank-bic").tag("result", "hit").functionCounter().count()));
            st.clear();
            for (int i = 1; i <= 3; i++) {
                tx.executeWithoutResult(s -> em.createQuery("select c from Currency c where c.active = true", Currency.class)
                        .setHint("org.hibernate.cacheable", true)
                        .setHint("org.hibernate.cacheRegion", "dict.active-currencies")
                        .getResultList());
            }
            System.out.println("   кэшируемый запрос активных валют три раза: запросов к базе " + st.getPrepareStatementCount()
                    + ", кэш запросов hit=" + st.getQueryCacheHitCount() + " miss=" + st.getQueryCacheMissCount() + " put=" + st.getQueryCachePutCount());
            System.out.println("   регионы: " + String.join(", ", new java.util.TreeSet<>(List.of(st.getSecondLevelCacheRegionNames()))));
            var registry = ctx.getBeanProvider(io.micrometer.core.instrument.MeterRegistry.class).getIfAvailable();
            if (registry != null) {
                var names = new java.util.TreeMap<String, Integer>();
                registry.getMeters().stream().map(m -> m.getId()).filter(id -> id.getName().startsWith("hibernate."))
                        .forEach(id -> names.merge(id.getName(), 1, Integer::sum));
                System.out.println("   метрик hibernate.* в MeterRegistry: " + names.size() + "; кэш: "
                        + names.keySet().stream().filter(n -> n.contains("cache")).toList());
                System.out.println("   автоконфигурация: " + ctx.getBeanNamesForType(io.micrometer.core.instrument.binder.MeterBinder.class).length + " MeterBinder; "
                        + java.util.Arrays.stream(ctx.getBeanDefinitionNames()).filter(b -> b.toLowerCase().contains("hibernatemetrics")).toList());
            }
            // 11.12 и 14.15: кэш коллекции без кэша элементов
            tx.executeWithoutResult(s -> {
                Tariff tf = new Tariff(); tf.id = 1L; tf.code = "ЭКВ-СТАНДАРТ";
                TariffC tc = new TariffC(); tc.id = 1L;
                for (long i = 1; i <= 40; i++) {
                    TariffRule r = new TariffRule(); r.id = i; r.tariff = tf; r.feePercent = new java.math.BigDecimal("1.8"); tf.rules.add(r);
                    TariffRuleC rc = new TariffRuleC(); rc.id = i; rc.tariff = tc; rc.feePercent = new java.math.BigDecimal("1.8"); tc.rules.add(rc);
                }
                em.persist(tf); em.persist(tc);
            });
            ctx.getBean(EntityManagerFactory.class).unwrap(SessionFactory.class).getCache().evictAllRegions();
            for (int i = 1; i <= 2; i++) {
                st.clear();
                tx.executeWithoutResult(s -> em.find(Tariff.class, 1L).rules.forEach(r -> r.feePercent.signum()));
                System.out.println("   11.12: транзакция " + i + ", правила не в кэше: запросов к базе " + st.getPrepareStatementCount());
            }
            for (int i = 1; i <= 2; i++) {
                st.clear();
                tx.executeWithoutResult(s -> em.find(TariffC.class, 1L).rules.forEach(r -> r.feePercent.signum()));
                System.out.println("   11.12: транзакция " + i + ", правила тоже в кэше: запросов к базе " + st.getPrepareStatementCount());
            }
            // 11.18 и 14.13: кэш запросов по таблице, в которую идёт запись
            String limitQ = "select coalesce(sum(u.used), 0) from CardLimitUsage u where u.cardId = :card";
            java.util.function.Supplier<Long> limit = () -> tx.execute(s -> em.createQuery(limitQ, Long.class).setParameter("card", 77L)
                    .setHint("org.hibernate.cacheable", true).setHint("org.hibernate.cacheRegion", "dict.active-currencies").getSingleResult());
            st.clear();
            for (int i = 0; i < 100; i++) { limit.get(); limit.get(); }
            System.out.println("   14.13: 200 чтений лимита без записей: hit=" + st.getQueryCacheHitCount() + " miss=" + st.getQueryCacheMissCount() + " put=" + st.getQueryCachePutCount());
            st.clear();
            for (int i = 0; i < 100; i++) {
                limit.get();
                tx.executeWithoutResult(s -> { var u = new CardLimitUsage(); u.cardId = 77L; u.used = 1500; em.persist(u); });   // авторизация списала сумму
                limit.get();
            }
            System.out.println("   14.13: 100 авторизаций, перед и после каждой чтение лимита: hit=" + st.getQueryCacheHitCount() + " miss=" + st.getQueryCacheMissCount()
                    + " put=" + st.getQueryCachePutCount() + ", меток таблиц записано " + st.getUpdateTimestampsCachePutCount());
            // открытая транзакция после flush: метка таблицы стоит на 60 с вперёд
            limit.get();
            var flushed = new java.util.concurrent.CountDownLatch(1);
            var release = new java.util.concurrent.CountDownLatch(1);
            Thread writer = new Thread(() -> tx.executeWithoutResult(s -> {
                var u = new CardLimitUsage(); u.cardId = 78L; u.used = 1; em.persist(u); em.flush();
                flushed.countDown();
                try { release.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }));
            writer.start();
            try { flushed.await(); } catch (InterruptedException e) { throw new RuntimeException(e); }
            st.clear();
            for (int i = 0; i < 5; i++) limit.get();
            System.out.println("   11.18: пока другая транзакция открыта после flush, 5 чтений: hit=" + st.getQueryCacheHitCount()
                    + " miss=" + st.getQueryCacheMissCount() + " put=" + st.getQueryCachePutCount() + ", запросов к базе " + st.getPrepareStatementCount());
            release.countDown();
            try { writer.join(); } catch (InterruptedException e) { throw new RuntimeException(e); }
            st.clear();
            try { Thread.sleep(5); } catch (InterruptedException e) { throw new RuntimeException(e); }
            for (int i = 0; i < 5; i++) limit.get();
            System.out.println("   11.18: после её фиксации, 5 чтений: hit=" + st.getQueryCacheHitCount() + " miss=" + st.getQueryCacheMissCount()
                    + " put=" + st.getQueryCachePutCount() + ", запросов к базе " + st.getPrepareStatementCount());
            // 14.14: ручной UPDATE мимо Hibernate — кэш об этом не знает
            var jdbc = ctx.getBean(javax.sql.DataSource.class);
            try (var c = jdbc.getConnection(); var ps = c.createStatement()) {
                ps.executeUpdate("update bank_bic set valid_to = date '2026-10-27' where bic = '044525974'");
            } catch (java.sql.SQLException e) { throw new RuntimeException(e); }
            st.clear();
            LocalDate cached = tx.execute(s -> em.find(BankBic.class, "044525974").validTo);
            System.out.println("   14.14: после UPDATE мимо Hibernate find вернул validTo = " + cached + ", запросов к базе " + st.getPrepareStatementCount());
            ctx.getBean(EntityManagerFactory.class).unwrap(SessionFactory.class).getCache().evictEntityData(BankBic.class);
            st.clear();
            LocalDate fresh = tx.execute(s -> em.find(BankBic.class, "044525974").validTo);
            System.out.println("   14.14: после evictEntityData(BankBic.class) validTo = " + fresh + ", запросов к базе " + st.getPrepareStatementCount());
            CacheRegionStatistics r = st.getDomainDataRegionStatistics("dict.bank-bic");
            if (r != null) System.out.println("   dict.bank-bic: getElementCountInMemory = " + r.getElementCountInMemory()
                    + ", getSizeInMemory = " + r.getSizeInMemory() + " (Long.MIN_VALUE = " + Long.MIN_VALUE + ")");
        }
    }

    static String region(Statistics st, String name) {
        CacheRegionStatistics r = st.getDomainDataRegionStatistics(name);
        return r == null ? "региона нет" : "hit=" + r.getHitCount() + " miss=" + r.getMissCount() + " put=" + r.getPutCount();
    }
}
