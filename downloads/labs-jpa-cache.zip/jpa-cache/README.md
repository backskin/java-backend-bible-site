# Кэш второго уровня Hibernate 7 на Ehcache 3 через JCache: сборка Gradle, sharedCache.mode, регион без настройки, URI конфигурации

Стенд к главе 12, разделы 11.16–11.17. Приложение `l2.App` (Spring Boot 4.1.1, Gradle 9.3.1 с Kotlin DSL, Hibernate 7.4.5, H2) с кэшем сущностей и запросов: три `find` одного БИК не дают ни одного запроса к базе, три кэшируемых запроса - один; режим `none` показывает, что `sharedCache.mode: NONE` не выключает кэш у сущностей с `@Cache`; режим `missing` - падение старта при регионе, которого нет в `ehcache.xml`, с `missing_cache_strategy: fail`; отдельный прогон проверяет три записи `hibernate.javax.cache.uri` (`classpath:` с одним двоеточием не работает). Задача `showCacheArtifacts` печатает, какие артефакты Ehcache и JCache попали в сборку. Выводы автора - `s12-l2*.txt`.

## Что нужно

- JDK 21 (`JAVA_HOME`), Gradle 9.3.1 (путь в `run.sh` через `GRADLE`, по умолчанию из `~/.gradle/wrapper/dists`).

## Запуск

```bash
bash run.sh
```

Один режим: `gradle -q bootJar && java -jar build/libs/jpa-cache.jar none`, или без fat jar `gradle runPlain -Pmode=none`. В IDEA импортируйте как проект Gradle и запускайте `l2.App`; Shell-конфигурация `run` есть.

## Что должно получиться

`s12-l2-deps.txt`: `ehcache-3.12.0-jakarta.jar` и `cache-api-1.1.1.jar`; `s12-l2-old-uri.txt`: `Couldn't load URI from classpath:ehcache.xml`, рабочие варианты - `classpath://ehcache.xml`, `ehcache.xml`, `/ehcache.xml`.
