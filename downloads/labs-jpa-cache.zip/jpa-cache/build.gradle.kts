// Разд. 11.16 гл. 12: кэш второго уровня Hibernate 7 на Ehcache 3 через JCache — зависимости ровно как в главе.
plugins {
    java
    id("org.springframework.boot") version "4.1.1"
    id("io.spring.dependency-management") version "1.1.7"
}

java { toolchain { languageVersion = JavaLanguageVersion.of(21) } }

repositories { mavenCentral() }

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-data-jpa")
    implementation("org.hibernate.orm:hibernate-jcache")
    implementation("org.ehcache:ehcache::jakarta")
    runtimeOnly("com.h2database:h2")
    // для 11.17: метрики кэша в Micrometer
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("org.hibernate.orm:hibernate-micrometer")
}

// Печатает, какие артефакты Ehcache и JCache на самом деле попали в сборку (с классификатором и версией).
tasks.register("showCacheArtifacts") {
    val cp = configurations.runtimeClasspath
    doLast {
        cp.get().resolvedConfiguration.resolvedArtifacts
            .filter { it.moduleVersion.id.group in setOf("org.ehcache", "org.hibernate.orm", "javax.cache", "org.glassfish.jaxb", "jakarta.xml.bind") }
            .sortedBy { it.file.name }
            .forEach { println("   ${it.moduleVersion.id}${it.classifier?.let { c -> " (классификатор $c)" } ?: ""} → ${it.file.name}") }
    }
}
tasks.bootJar { archiveFileName = "jpa-cache.jar" }
tasks.register<JavaExec>("runPlain") {   // то же приложение из каталогов классов, без fat jar
    classpath = sourceSets.main.get().runtimeClasspath
    mainClass = "l2.App"
    args = (project.findProperty("mode") as String?)?.let { listOf(it) } ?: listOf()
    jvmArgs("-Dstdout.encoding=UTF-8")
}
