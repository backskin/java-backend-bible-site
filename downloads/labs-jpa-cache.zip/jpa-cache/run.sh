#!/usr/bin/env bash
# Разд. 11.16–11.17 гл. 12: кэш второго уровня на Ehcache 3 через JCache, сборка Gradle 9.3.1 (Kotlin DSL).
# Вывод: s12-l2-deps.txt (какие артефакты подставил Boot), s12-l2.txt, s12-l2-none.txt, s12-l2-missing.txt, s12-l2-old-uri.txt.
set -uo pipefail
cd "$(dirname "$0")"
export JAVA_HOME="${JAVA_HOME:-$HOME/.jdks/temurin-21.0.10}"
G="${GRADLE:-$(ls -d "$HOME"/.gradle/wrapper/dists/gradle-9.3.1-bin/*/gradle-9.3.1 | head -1)/bin/gradle}"
"$G" -q --no-daemon showCacheArtifacts > s12-l2-deps.txt && cat s12-l2-deps.txt
"$G" -q --no-daemon bootJar || exit 1
for m in "" none missing; do
  "$JAVA_HOME/bin/java" -Dstdout.encoding=UTF-8 -jar build/libs/jpa-cache.jar $m 2>&1 | grep -v "^WARNING" > "s12-l2${m:+-$m}.txt"
  cat "s12-l2${m:+-$m}.txt"
done
# Запись URI в духе Spring (одно двоеточие), как было в главе, и два рабочих варианта
for u in "classpath:ehcache.xml" "ehcache.xml" "/ehcache.xml"; do
  MSYS_NO_PATHCONV=1 "$JAVA_HOME/bin/java" -Dstdout.encoding=UTF-8 -Dspring.jpa.properties.hibernate.javax.cache.uri=$u -jar build/libs/jpa-cache.jar 2>&1 | grep -v "^WARNING"
done > s12-l2-old-uri.txt
cat s12-l2-old-uri.txt
