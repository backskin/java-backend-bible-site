#!/usr/bin/env bash
# Одно и то же приложение с циклом бинов на трех версиях Spring Boot; вывод - в run.txt.
# Нужны JDK 17+ и Maven. На 2.6 и 4.1 дополнительно пробуется spring.main.allow-circular-references=true.
set -u
cd "$(dirname "$0")"
: > run.txt
for v in 2.5.15 2.6.0 4.1.1; do
  mvn -q -Dboot.version="$v" clean compile dependency:build-classpath -Dmdep.outputFile=cp.txt > /dev/null
  sep=":"; case "$(uname -s)" in MINGW*|MSYS*|CYGWIN*) sep=";";; esac
  java -Dstdout.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -cp "target/classes${sep}$(cat cp.txt)" dev.team.cycles.CyclesApp 2>&1 \
    | grep -E "^Spring Boot|^Relying upon" >> run.txt
  if [ "$v" != "2.5.15" ]; then
    java -Dstdout.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -cp "target/classes${sep}$(cat cp.txt)" dev.team.cycles.CyclesApp --spring.main.allow-circular-references=true 2>&1 \
      | grep "^Spring Boot" | sed 's/$/ (allow-circular-references=true)/' >> run.txt
  fi
done
cat run.txt
