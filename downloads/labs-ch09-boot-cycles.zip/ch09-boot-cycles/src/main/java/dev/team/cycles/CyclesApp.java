package dev.team.cycles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

/**
 * Два сервиса ссылаются друг на друга через поля. Spring Framework умеет разорвать такой цикл
 * ранней ссылкой (раздел 6 главы), а Spring Boot начиная с некоторой версии запрещает это по умолчанию.
 * Приложение печатает версию Boot и либо "контекст поднялся", либо сообщение об ошибке старта.
 */
@SpringBootApplication
public class CyclesApp {

    public static void main(String[] args) {
        String version = SpringApplication.class.getPackage().getImplementationVersion();
        try {
            SpringApplication app = new SpringApplication(CyclesApp.class);
            app.setLogStartupInfo(false);
            app.run(args).close();
            System.out.println("Spring Boot " + version + ": контекст поднялся, цикл разорван");
        } catch (Exception e) {
            Throwable root = e;
            while (root.getCause() != null) root = root.getCause();
            System.out.println("Spring Boot " + version + ": старт упал, " + root.getClass().getSimpleName());
        }
    }

    /** Сервис лимитов: ему нужен сервис платежей. */
    @Component
    static class LimitService {
        @Autowired
        PaymentService payments;
    }

    /** Сервис платежей: ему нужен сервис лимитов. */
    @Component
    static class PaymentService {
        @Autowired
        LimitService limits;
    }
}
