package dev.team.sbp;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.actuate.endpoint.annotation.DeleteOperation;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.boot.actuate.web.exchanges.InMemoryHttpExchangeRepository;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.boot.security.autoconfigure.actuate.web.servlet.EndpointRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Приложение опыта разд. 6: шлюз СБП Тундра-Банка с Actuator.
 * ActuatorLab поднимает его в разных режимах и обращается к нему по HTTP.
 */
@SpringBootApplication
public class SbpGatewayApp {

    /** Состояние связи с НСПК, которое опыт меняет между запросами. */
    static volatile String nspkState = "UP";

    /** Пути запросов, которые увидел фильтр основного контекста. */
    static final List<String> seenByFilter = new CopyOnWriteArrayList<>();

    @RestController
    static class PaymentController {
        @GetMapping("/api/payments/{id}")
        Map<String, String> payment(@PathVariable String id) {
            if (!id.startsWith("P-")) throw new ResponseStatusException(org.springframework.http.HttpStatus.NOT_FOUND);
            return Map.of("id", id, "status", "ACCEPTED");
        }
    }

    /** Связь с НСПК: состояние берётся из поля, которое меняет опыт. */
    @Component("nspkHealthIndicator")
    static class NspkHealthIndicator implements HealthIndicator {
        @Override
        public Health health() {
            return switch (nspkState) {
                case "UP" -> Health.up().withDetail("participant", "100000000777").build();
                case "DOWN" -> Health.down(new IllegalStateException(
                        "нет ответа от https://sbp.nspk.test/api/v2/transfer?access_token=eyJhbGciOi-СЕКРЕТ")).build();
                case "THROW" -> throw new IllegalStateException("клиент НСПК не инициализирован");
                case "SLOW" -> { sleep(1500); yield Health.up().build(); }
                default -> Health.status(nspkState).build();
            };
        }
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    /** Очередь исходящих переводов СБП, ожидающих повторной отправки. */
    @Component
    @Endpoint(id = "sbpqueue")
    static class SbpQueueEndpoint {
        private final Map<String, String> queue = new ConcurrentHashMap<>(Map.of(
                "P-1001", "TIMEOUT", "P-1002", "REJECTED_BY_NSPK"));

        @ReadOperation
        public Map<String, Object> summary() { return Map.of("size", queue.size(), "ids", queue.keySet()); }

        @ReadOperation
        public Map<String, String> one(@Selector String id) {
            String reason = queue.get(id);
            return reason == null ? null : Map.of("id", id, "reason", reason);
        }

        @WriteOperation
        public Map<String, String> retry(@Selector String id, String operator) {
            return Map.of("id", id, "resubmittedBy", operator);
        }

        @DeleteOperation
        public void cancel(@Selector String id) { queue.remove(id); }
    }

    /** Эндпоинт с дефисом в идентификаторе: включается флагом lab.dash-id. */
    @Component
    @ConditionalOnProperty("lab.dash-id")
    @Endpoint(id = "nspk-limits")
    static class DashIdEndpoint {
        @ReadOperation public String read() { return "ok"; }
    }

    /** Эндпоинт sbp-queue рядом с sbpqueue: включается флагом lab.collide. */
    @Component
    @ConditionalOnProperty("lab.collide")
    @Endpoint(id = "sbp-queue")
    static class CollideEndpoint {
        @ReadOperation public String read() { return "ok"; }
    }

    /** Эндпоинт с заглавной буквой в начале идентификатора: включается флагом lab.upper-id. */
    @Component
    @ConditionalOnProperty("lab.upper-id")
    @Endpoint(id = "SbpQueue")
    static class UpperIdEndpoint {
        @ReadOperation public String read() { return "ok"; }
    }

    @Component
    static class SeenFilter extends OncePerRequestFilter {
        @Override
        protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
                throws ServletException, IOException {
            seenByFilter.add(req.getRequestURI());
            chain.doFilter(req, res);
        }
    }

    /** Сводка по лимитам НСПК: регистрируется так, как это делает стартер. */
    @Endpoint(id = "nspkstats")
    static class NspkStatsEndpoint {
        @ReadOperation public Map<String, Integer> stats() { return Map.of("rejectedToday", 3); }
    }

    @Bean
    @org.springframework.boot.actuate.autoconfigure.endpoint.condition.ConditionalOnAvailableEndpoint
    NspkStatsEndpoint nspkStatsEndpoint() { return new NspkStatsEndpoint(); }

    @Bean
    @ConditionalOnProperty("lab.exchanges")
    InMemoryHttpExchangeRepository exchanges() { return new InMemoryHttpExchangeRepository(); }

    @Configuration(proxyBeanMethods = false)
    static class Security {

        @Bean
        InMemoryUserDetailsManager users() {
            return new InMemoryUserDetailsManager(
                    User.withUsername("dev.team").password("{noop}lab-pass").roles("ACTUATOR").build(),
                    User.withUsername("operator").password("{noop}lab-pass").roles("OPERATOR").build());
        }

        /** При lab.security=true Actuator закрыт ролью, health и info открыты; иначе всё открыто. */
        @Bean
        @Order(1)
        SecurityFilterChain actuatorChain(HttpSecurity http, Environment env) throws Exception {
            boolean secured = env.getProperty("lab.security", Boolean.class, false);
            boolean csrf = env.getProperty("lab.csrf", Boolean.class, false);
            http.securityMatcher(EndpointRequest.toAnyEndpoint());
            if (secured) {
                http.authorizeHttpRequests(r -> r
                        .requestMatchers(EndpointRequest.to("health", "info")).permitAll()
                        .anyRequest().hasRole("ACTUATOR"));
            } else {
                http.authorizeHttpRequests(r -> r.anyRequest().permitAll());
            }
            http.httpBasic(Customizer.withDefaults());
            if (!csrf) http.csrf(c -> c.disable());
            return http.build();
        }

        @Bean
        @Order(2)
        SecurityFilterChain appChain(HttpSecurity http) throws Exception {
            return http.authorizeHttpRequests(r -> r.anyRequest().permitAll()).csrf(c -> c.disable()).build();
        }
    }
}
