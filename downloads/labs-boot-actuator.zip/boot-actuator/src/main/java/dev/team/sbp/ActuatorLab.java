package dev.team.sbp;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/** Ведущий опыта разд. 6: поднимает SbpGatewayApp в разных режимах и обращается к Actuator по HTTP. */
public class ActuatorLab {
    static final HttpClient HTTP = HttpClient.newHttpClient();
    static ConfigurableApplicationContext ctx;
    static String port, mgmtPort;

    public static void main(String[] a) throws Exception {
        String only = a.length > 0 ? a[0] : null;

        if (on(only, "1")) { start("1. значения по умолчанию");
            get("/actuator"); get("/actuator/health"); get("/actuator/info"); get("/actuator/env"); get("/actuator/health/liveness"); stop(); }

        if (on(only, "2")) { start("2. show-details=always", "management.endpoint.health.show-details=always");
            get("/actuator/health"); stop(); }

        if (on(only, "3")) { start("3. НСПК DOWN с исключением, show-details=always", "management.endpoint.health.show-details=always");
            SbpGatewayApp.nspkState = "DOWN"; get("/actuator/health/nspk"); get("/actuator/health"); stop(); }

        if (on(only, "4")) { start("4. свои статусы без настройки порядка");
            for (String s : List.of("OUT_OF_SERVICE", "UNKNOWN", "DEGRADED")) { SbpGatewayApp.nspkState = s; System.out.print("   nspk=" + s + ": "); get("/actuator/health"); }
            stop();
            start("4б. DEGRADED с порядком и кодом", "management.endpoint.health.status.order=down,out-of-service,degraded,up,unknown",
                    "management.endpoint.health.status.http-mapping.degraded=200");
            SbpGatewayApp.nspkState = "DEGRADED"; get("/actuator/health"); stop(); }

        if (on(only, "5")) { start("5. база недоступна, вне Kubernetes", "spring.datasource.url=jdbc:h2:tcp://localhost:1/nope", "management.endpoint.health.show-details=always");
            get("/actuator/health/db"); get("/actuator/health"); get("/actuator/health/liveness"); stop(); }

        if (on(only, "6")) { start("6. пробы: cloud-platform=kubernetes, база недоступна", "spring.main.cloud-platform=kubernetes",
                    "spring.datasource.url=jdbc:h2:tcp://localhost:1/nope", "management.endpoint.health.show-components=always");
            get("/actuator/health"); get("/actuator/health/liveness"); get("/actuator/health/readiness"); get("/livez"); stop();
            start("6б. пробы включены явно, дополнительные пути", "management.endpoint.health.probes.enabled=true",
                    "management.endpoint.health.probes.add-additional-paths=true");
            get("/actuator/health/liveness"); get("/livez"); get("/readyz"); stop(); }

        if (on(only, "7")) { start("7. своя группа readiness с базой", "management.endpoint.health.probes.enabled=true",
                    "management.endpoint.health.group.readiness.include=readinessState,db",
                    "management.endpoint.health.group.readiness.show-details=always",
                    "spring.datasource.url=jdbc:h2:tcp://localhost:1/nope");
            get("/actuator/health/readiness"); get("/actuator/health/liveness"); stop();
            start("7б. группа deep: все индикаторы, отказ без 503", "management.endpoint.health.group.deep.include=*",
                    "management.endpoint.health.group.deep.status.http-mapping.down=200");
            SbpGatewayApp.nspkState = "DOWN"; get("/actuator/health/deep"); get("/actuator/health"); stop(); }

        if (on(only, "8")) { start("8. info без настройки", "management.endpoints.web.exposure.include=health,info");
            get("/actuator/info"); stop();
            start("8б. info с env, java, os", "management.endpoints.web.exposure.include=health,info",
                    "management.info.env.enabled=true", "management.info.java.enabled=true", "management.info.os.enabled=true", "management.info.process.enabled=true");
            get("/actuator/info"); stop(); }

        if (on(only, "9")) { start("9. exposure.include=*", "management.endpoints.web.exposure.include=*");
            links();
            get("/actuator/heapdump"); get("/actuator/shutdown"); get("/actuator/env/tundra.sbp.access-token"); get("/actuator/configprops/spring.datasource"); stop();
            start("9б. show-values=always", "management.endpoints.web.exposure.include=env", "management.endpoint.env.show-values=always",
                    "--tundra.sbp.base-url=https://sbp-arg");
            get("/actuator/env/tundra.sbp.base-url"); stop();
            start("9в. heapdump с access=read-only", "management.endpoints.web.exposure.include=heapdump", "management.endpoint.heapdump.access=read-only");
            head("/actuator/heapdump"); stop(); }

        if (on(only, "10")) { start("10. loggers: чтение и запись", "management.endpoints.web.exposure.include=loggers");
            get("/actuator/loggers/dev.team.sbp"); post("/actuator/loggers/dev.team.sbp", "{\"configuredLevel\":\"DEBUG\"}"); get("/actuator/loggers/dev.team.sbp"); stop();
            start("10б. то же при max-permitted=read-only", "management.endpoints.web.exposure.include=loggers", "management.endpoints.access.max-permitted=read-only");
            post("/actuator/loggers/dev.team.sbp", "{\"configuredLevel\":\"DEBUG\"}"); get("/actuator/loggers/dev.team.sbp"); stop();
            start("10в. access.default=none, loggers открыт поимённо", "management.endpoints.web.exposure.include=*",
                    "management.endpoints.access.default=none", "management.endpoint.loggers.access=read-only", "management.endpoint.health.access=read-only");
            links(); stop(); }

        if (on(only, "11")) { start("11. httpexchanges без хранилища", "management.endpoints.web.exposure.include=httpexchanges");
            get("/actuator/httpexchanges"); stop();
            start("11б. httpexchanges с InMemoryHttpExchangeRepository", "management.endpoints.web.exposure.include=httpexchanges", "lab.exchanges=true");
            get("/api/payments/P-7"); getAuth("/api/payments/P-8", "dev.team");
            String ex = body("/actuator/httpexchanges");
            System.out.println("   обменов: " + ex.split("\"timestamp\"").length + "; есть Authorization: " + ex.contains("Authorization") + "; есть P-7: " + ex.contains("P-7")); stop(); }

        if (on(only, "12")) { start("12. свой эндпоинт sbpqueue", "management.endpoints.web.exposure.include=sbpqueue");
            get("/actuator/sbpqueue"); get("/actuator/sbpqueue/P-1001"); get("/actuator/sbpqueue/P-9999");
            post("/actuator/sbpqueue/P-1001", "{\"operator\":\"dev.team\"}"); post("/actuator/sbpqueue/P-1001", "{}");
            delete("/actuator/sbpqueue/P-1001"); get("/actuator/sbpqueue"); stop();
            start("12б. sbpqueue при access.default=read-only", "management.endpoints.web.exposure.include=sbpqueue", "management.endpoints.access.default=read-only");
            get("/actuator/sbpqueue"); post("/actuator/sbpqueue/P-1001", "{\"operator\":\"dev.team\"}"); delete("/actuator/sbpqueue/P-1001"); stop();
            start("12в. идентификатор с дефисом", "management.endpoints.web.exposure.include=*", "lab.dash-id=true");
            get("/actuator/nspk-limits"); get("/actuator/nspklimits"); stop();
            start("12г. sbp-queue рядом с sbpqueue", "lab.collide=true"); stop();
            start("12д. идентификатор с заглавной буквы", "lab.upper-id=true"); stop(); }

        if (on(only, "13")) { start("13. Spring Security: health и info открыты, остальное за ролью", "lab.security=true",
                    "management.endpoints.web.exposure.include=*", "management.endpoint.health.show-details=when-authorized");
            get("/actuator/health"); getAuth("/actuator/health", "dev.team"); getAuth("/actuator/health", "operator");
            get("/actuator/env"); getAuth("/actuator/env", "operator"); getAuth("/actuator/beans", "dev.team");
            postAuth("/actuator/loggers/dev.team.sbp", "{\"configuredLevel\":\"DEBUG\"}", "dev.team"); stop();
            start("13б. то же с включённой защитой от CSRF", "lab.security=true", "lab.csrf=true", "management.endpoints.web.exposure.include=*");
            postAuth("/actuator/loggers/dev.team.sbp", "{\"configuredLevel\":\"DEBUG\"}", "dev.team"); stop(); }

        if (on(only, "13")) { start("13в. when-authorized с ролью", "lab.security=true",
                    "management.endpoint.health.show-details=when-authorized", "management.endpoint.health.roles=ACTUATOR");
            getAuth("/actuator/health", "operator"); getAuth("/actuator/health", "dev.team"); stop(); }

        if (on(only, "16")) { start("16. медленный индикатор, порог 1 с", "management.endpoint.health.logging.slow-indicator-threshold=1s");
            SbpGatewayApp.nspkState = "SLOW"; long t = System.nanoTime(); get("/actuator/health");
            System.out.println("   ответ за " + (System.nanoTime() - t) / 1_000_000 + " мс"); stop(); }

        if (on(only, "17")) { start("17. JMX: spring.jmx.enabled=true, остальное по умолчанию", "spring.jmx.enabled=true");
            System.out.println("   MBean-ы Actuator: " + java.lang.management.ManagementFactory.getPlatformMBeanServer()
                    .queryNames(new javax.management.ObjectName("org.springframework.boot:type=Endpoint,*"), null)); stop();
            start("17б. JMX: exposure.include=*", "spring.jmx.enabled=true", "management.endpoints.jmx.exposure.include=*");
            System.out.println("   MBean-ы Actuator: " + java.lang.management.ManagementFactory.getPlatformMBeanServer()
                    .queryNames(new javax.management.ObjectName("org.springframework.boot:type=Endpoint,*"), null).size()); stop(); }

        if (on(only, "18")) { start("18. POST /actuator/env и формат дампа кучи", "management.endpoints.web.exposure.include=env,heapdump",
                    "management.endpoint.heapdump.access=read-only");
            post("/actuator/env", "{\"name\":\"tundra.sbp.base-url\",\"value\":\"https://evil\"}");
            byte[] dump = HTTP.send(HttpRequest.newBuilder(URI.create("http://localhost:" + port + "/actuator/heapdump")).build(),
                    HttpResponse.BodyHandlers.ofByteArray()).body();
            System.out.printf("   дамп: %d байт, первые байты %02x %02x, начало: %s%n", dump.length, dump[0], dump[1],
                    new String(dump, 0, 12, StandardCharsets.US_ASCII)); stop(); }

        if (on(only, "19")) { start("19. состояние доступности из кода", "management.endpoint.health.probes.enabled=true");
            org.springframework.boot.availability.AvailabilityChangeEvent.publish(ctx, org.springframework.boot.availability.ReadinessState.REFUSING_TRAFFIC);
            System.out.print("   REFUSING_TRAFFIC: "); get("/actuator/health/readiness"); System.out.print("   REFUSING_TRAFFIC: "); get("/actuator/health/liveness");
            System.out.print("   REFUSING_TRAFFIC: "); get("/actuator/health");
            org.springframework.boot.availability.AvailabilityChangeEvent.publish(ctx, new IllegalStateException("очередь СБП не восстанавливается"),
                    org.springframework.boot.availability.LivenessState.BROKEN);
            System.out.print("   BROKEN: "); get("/actuator/health/liveness"); stop(); }

        if (on(only, "20")) { start("20. @ConditionalOnAvailableEndpoint: эндпоинт не выставлен");
            System.out.println("   бин nspkStatsEndpoint создан: " + ctx.containsBean("nspkStatsEndpoint")); stop();
            start("20б. эндпоинт выставлен", "management.endpoints.web.exposure.include=nspkstats");
            System.out.println("   бин nspkStatsEndpoint создан: " + ctx.containsBean("nspkStatsEndpoint")); get("/actuator/nspkstats"); stop();
            start("20в. выставлен, но access=none", "management.endpoints.web.exposure.include=nspkstats", "management.endpoint.nspkstats.access=none");
            System.out.println("   бин nspkStatsEndpoint создан: " + ctx.containsBean("nspkStatsEndpoint")); stop(); }

        if (on(only, "24")) { start("24. /actuator/startup: GET и POST", "lab.startup=true", "management.endpoints.web.exposure.include=startup");
            for (String m : List.of("GET", "GET", "POST", "GET")) {
                var r = HTTP.send(HttpRequest.newBuilder(URI.create("http://localhost:" + port + "/actuator/startup"))
                        .method(m, HttpRequest.BodyPublishers.noBody()).build(), HttpResponse.BodyHandlers.ofString());
                System.out.println("   " + m + " /actuator/startup → " + r.statusCode() + ", шагов в ответе: " + (r.body().split("\"startupStep\"").length - 1));
            }
            stop(); }

        if (on(only, "23")) { start("23. Prometheus", "management.endpoints.web.exposure.include=health,prometheus");
            for (int i = 0; i < 3; i++) get("/api/payments/P-" + i, false);
            get("/api/payments/X-1", false);
            var r = HTTP.send(HttpRequest.newBuilder(URI.create("http://localhost:" + port + "/actuator/prometheus")).build(), HttpResponse.BodyHandlers.ofString());
            System.out.println("   GET /actuator/prometheus → " + r.statusCode() + " " + r.headers().firstValue("Content-Type").orElse("") + ", строк " + r.body().lines().count());
            r.body().lines().filter(l -> l.startsWith("http_server_requests_seconds_count") && l.contains("/api/payments") || l.startsWith("# TYPE http_server_requests_seconds ")
                    || l.startsWith("hikaricp_connections_max") || l.startsWith("application_ready_time_seconds"))
                    .forEach(l -> System.out.println("   " + l));
            stop(); }

        if (on(only, "22")) { start("22. индикатор бросает исключение", "management.endpoint.health.show-details=always");
            SbpGatewayApp.nspkState = "THROW"; get("/actuator/health/nspk"); get("/actuator/health"); stop(); }

        if (on(only, "21")) { start("21. старое свойство management.endpoint.heapdump.enabled=true", "management.endpoints.web.exposure.include=heapdump",
                    "management.endpoint.heapdump.enabled=true");
            head("/actuator/heapdump"); get("/api/payments/P-1"); get("/api/payments/P-1/"); stop(); }

        if (on(only, "14")) { start("14. отдельный порт management", "management.server.port=0", "management.endpoints.web.exposure.include=health,info");
            SbpGatewayApp.seenByFilter.clear();
            get("/actuator/health"); getMgmt("/actuator/health"); get("/api/payments/P-1");
            System.out.println("   фильтр основного контекста видел: " + SbpGatewayApp.seenByFilter);
            System.out.println("   контекст management: " + ctx.getEnvironment().getProperty("local.management.port") + " ≠ " + port); stop(); }

        if (on(only, "15")) { start("15. метрики", "management.endpoints.web.exposure.include=metrics");
            for (int i = 0; i < 3; i++) get("/api/payments/P-" + i, false);
            get("/api/payments/X-1", false);
            get("/actuator/metrics/http.server.requests?tag=uri:/api/payments/{id}");
            get("/actuator/metrics/http.server.requests?tag=uri:/api/payments/{id}&tag=status:404");
            String names = body("/actuator/metrics");
            System.out.println("   имён метрик: " + names.split("\",\"").length + "; начало: " + names.substring(0, Math.min(200, names.length())));
            stop(); }
    }

    static void links() throws Exception {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"([\\w.-]+)\":\\{\"href\"").matcher(body("/actuator"));
        List<String> ids = new ArrayList<>();
        while (m.find()) ids.add(m.group(1));
        System.out.println("   ссылки (" + ids.size() + "): " + ids);
    }

    static boolean on(String only, String n) { return only == null || only.equals(n); }

    static void start(String label, String... props) {
        System.out.println("== " + label);
        SbpGatewayApp.nspkState = "UP";
        List<String> args = new ArrayList<>(List.of("--server.port=0"));
        for (String p : props) args.add(p.startsWith("--") ? p : "--" + p);
        try {
            SpringApplication sa = new SpringApplication(SbpGatewayApp.class);
            if (args.contains("--lab.startup=true")) sa.setApplicationStartup(new org.springframework.boot.context.metrics.buffering.BufferingApplicationStartup(4096));
            ctx = sa.run(args.toArray(String[]::new));
            port = ctx.getEnvironment().getProperty("local.server.port");
            mgmtPort = ctx.getEnvironment().getProperty("local.management.port");
        } catch (Exception e) {
            Throwable t = e; while (t.getCause() != null) t = t.getCause();
            System.out.println("   СТАРТ НЕ УДАЛСЯ: " + t.getClass().getSimpleName() + ": " + t.getMessage().split("\n")[0]);
            ctx = null;
        }
    }

    static void stop() { if (ctx != null) ctx.close(); }

    static void get(String path) throws Exception { get(path, true); }
    static void get(String path, boolean print) throws Exception { send(port, "GET", path, null, null, print); }
    static void getMgmt(String path) throws Exception { send(mgmtPort, "GET", path, null, null, true); }
    static void getAuth(String path, String user) throws Exception { send(port, "GET", path, null, user, true); }
    static void post(String path, String json) throws Exception { send(port, "POST", path, json, null, true); }
    static void postAuth(String path, String json, String user) throws Exception { send(port, "POST", path, json, user, true); }
    static void delete(String path) throws Exception { send(port, "DELETE", path, null, null, true); }
    static void head(String path) throws Exception { send(port, "HEAD", path, null, null, true); }

    static String body(String path) throws Exception {
        return HTTP.send(HttpRequest.newBuilder(URI.create("http://localhost:" + port + path)).build(),
                HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)).body();
    }

    static void send(String p, String method, String path, String json, String user, boolean print) throws Exception {
        if (ctx == null) return;
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create("http://localhost:" + p + path.replace("{", "%7B").replace("}", "%7D")));
        if (json != null) b.header("Content-Type", "application/json");
        if (user != null) b.header("Authorization", "Basic " + Base64.getEncoder().encodeToString((user + ":lab-pass").getBytes()));
        b.method(method, json == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(json));
        HttpResponse<String> r = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (!print) return;
        String body = r.body().replaceAll("\"_links\":\\{.*", "\"_links\":{…}");
        if (body.length() > 700) body = body.substring(0, 700) + " …(" + r.body().length() + " байт)";
        String ct = r.headers().firstValue("Content-Type").orElse("");
        System.out.println("   " + method + " " + path + (user != null ? " [" + user + "]" : "") + " → " + r.statusCode()
                + (method.equals("HEAD") ? " " + ct + " " + r.headers().firstValue("Content-Length").orElse("") : "") + " " + body);
    }
}
