package dev.team.flux;

import java.time.Duration;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootVersion;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Гл. 14, разд. 10: сколько потоков цикла событий у Reactor Netty, что делает блокирующий вызов в обработчике
 * и как ведёт себя пример exchangeToMono из «Spring in Action» (6-е изд., разд. 12.4.5). Вывод — s14-flux.txt.
 */
@SpringBootApplication
@RestController
public class FluxLab {
    static final Set<String> THREADS = ConcurrentHashMap.newKeySet();

    record Quote(String isin, String price) {}

    @GetMapping("/quotes/{isin}")
    ResponseEntity<Quote> quote(@PathVariable String isin) {
        THREADS.add(Thread.currentThread().getName());
        var b = ResponseEntity.ok();
        if (isin.startsWith("X")) b.header("X_UNAVAILABLE", "true");
        return b.body(new Quote(isin, "101.25"));
    }

    @GetMapping("/block")
    Mono<String> block(@RequestParam long ms) throws InterruptedException {
        Thread.sleep(ms); // блокирующий вызов прямо в потоке цикла событий — так делать нельзя
        return Mono.just("blocked " + ms + " on " + Thread.currentThread().getName());
    }

    @GetMapping("/fast")
    Mono<String> fast() { return Mono.just("fast on " + Thread.currentThread().getName()); }

    public static void main(String[] args) {
        var app = new SpringApplication(FluxLab.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        try (var ctx = app.run(args)) {
            String base = "http://127.0.0.1:" + ctx.getEnvironment().getProperty("local.server.port");
            System.out.println("spring-boot " + SpringBootVersion.getVersion() + ", reactor-netty "
                    + reactor.netty.http.HttpResources.class.getPackage().getImplementationVersion()
                    + ", availableProcessors=" + Runtime.getRuntime().availableProcessors());
            WebClient wc = WebClient.builder().baseUrl(base).build();

            System.out.println("== Потоки, обслужившие 400 запросов (по 50 одновременно)");
            Flux.range(0, 400).flatMap(i -> wc.get().uri("/quotes/RU000A{n}", i).retrieve().bodyToMono(Quote.class), 50).blockLast();
            System.out.println("   различных потоков: " + THREADS.size() + "; пример имени: " + THREADS.stream().sorted().findFirst().orElse("-"));

            System.out.println("== Блокирующий вызов в обработчике: 2×N запросов /block?ms=1000 одновременно, затем один /fast");
            int n = THREADS.size();
            long t0 = System.nanoTime();
            var blocked = Flux.range(0, 2 * n).flatMap(i -> wc.get().uri("/block?ms=1000").retrieve().bodyToMono(String.class), 2 * n).then().toFuture();
            sleep(100);
            long f0 = System.nanoTime();
            String fast = wc.get().uri("/fast").retrieve().bodyToMono(String.class).block();
            System.out.printf("   /fast ответил через %.2f с (%s)%n", (System.nanoTime() - f0) / 1e9, fast);
            blocked.join();
            System.out.printf("   все %d блокирующих запросов заняли %.2f с%n", 2 * n, (System.nanoTime() - t0) / 1e9);

            System.out.println("== Пример из книги: exchangeToMono(cr -> Mono.just(cr)).flatMap(cr -> cr.bodyToMono(...))");
            try {
                Quote q = wc.get().uri("/quotes/RU000A1").exchangeToMono(cr -> {
                            if (cr.headers().header("X_UNAVAILABLE").contains("true")) return Mono.<ClientResponse>empty();
                            return Mono.just(cr);
                        })
                        .flatMap(cr -> cr.bodyToMono(Quote.class))
                        .block(Duration.ofSeconds(5));
                System.out.println("   результат: " + q);
            } catch (Exception e) {
                System.out.println("   исключение: " + e.getClass().getName() + ": " + e.getMessage());
            }
            System.out.println("== То же, тело читается внутри exchangeToMono");
            Quote q2 = wc.get().uri("/quotes/RU000A1").exchangeToMono(cr ->
                    cr.headers().header("X_UNAVAILABLE").contains("true") ? cr.releaseBody().then(Mono.<Quote>empty()) : cr.bodyToMono(Quote.class))
                    .block(Duration.ofSeconds(5));
            System.out.println("   результат: " + q2);
        }
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); } }
}
