# WebFlux на Reactor Netty: потоки цикла событий, цена блокировки, exchangeToMono и onStatus из книги

Стенд к главе 14, раздел о WebFlux. `FluxLab` (Spring Boot 4.1.1, Reactor Netty 1.3.7) печатает, сколько потоков обслужили 400 запросов по 50 одновременно на 16 ядрах и с `-XX:ActiveProcessorCount=2`, сколько ждет `/fast`, пока 2×N запросов `/block?ms=1000` держат потоки, и чем отличается пример `exchangeToMono` из книги Уоллса от варианта с чтением тела внутри. В `onstatus/` два файла `OnStatusBook.java` и `OnStatusFixed.java`: пример `onStatus` из книги не компилируется против spring-webflux 7.0.9. Выводы автора - `s14-flux.txt`, `s14-onstatus.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile exec:java -Dexec.mainClass=dev.team.flux.FluxLab
```

С двумя процессорами: добавить `-Dexec.jvmArgs=-XX:ActiveProcessorCount=2` или запустить конфигурацию `FluxLab` в IDEA с этим флагом JVM. Проверка книги: `javac -cp "$(cat cp.txt)" onstatus/OnStatusBook.java` после `mvn dependency:build-classpath -Dmdep.outputFile=cp.txt`.

## Что должно получиться

16 потоков `reactor-http-nio-*` на 16 ядрах и 4 при двух процессорах; `/fast` ждет 1,9 с и 2,9 с, пока блокирующие запросы занимают цикл событий; пример книги с `exchangeToMono` возвращает `null`, исправленный - `Quote[isin=RU000A1, price=101.25]`.
