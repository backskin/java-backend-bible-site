import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
/** «Spring in Action», 6-е изд., разд. 12.4.4: onStatus(HttpStatusCode::is4xxClientError, ...) — исправленный вариант. */
class OnStatusFixed {
    Mono<String> call(WebClient wc) {
        return wc.get().uri("/quotes/1").retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, r -> Mono.just(new IllegalStateException()))
                .bodyToMono(String.class);
    }
}
