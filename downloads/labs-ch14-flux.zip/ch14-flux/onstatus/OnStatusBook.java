import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
/** «Spring in Action», 6-е изд., разд. 12.4.4: onStatus(HttpStatus::is4xxClientError, ...) — компилируется ли на Framework 7. */
class OnStatusBook {
    Mono<String> call(WebClient wc) {
        return wc.get().uri("/quotes/1").retrieve()
                .onStatus(HttpStatus::is4xxClientError, r -> Mono.just(new IllegalStateException()))
                .bodyToMono(String.class);
    }
}
