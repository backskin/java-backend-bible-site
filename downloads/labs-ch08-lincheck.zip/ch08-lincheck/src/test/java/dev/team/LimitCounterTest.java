package dev.team;

import org.jetbrains.lincheck.datastructures.ModelCheckingOptions;
import org.jetbrains.lincheck.datastructures.Operation;
import org.jetbrains.lincheck.datastructures.StressOptions;
import org.junit.jupiter.api.Test;

/** A daily limit counter without synchronization: Lincheck must find a non-linearizable interleaving. */
public class LimitCounterTest {
    private long spent = 0;
    private final long limit = 100;

    /** Reserves amount if the limit allows: check-then-act without a lock. */
    @Operation
    public boolean reserve(long amount) {
        if (spent + amount <= limit) {
            spent += amount;
            return true;
        }
        return false;
    }

    @Operation
    public long spent() {
        return spent;
    }

    @Test
    public void stressTest() {
        new StressOptions().iterations(20).invocationsPerIteration(5_000).check(LimitCounterTest.class);
    }

    @Test
    public void modelCheckingTest() {
        new ModelCheckingOptions().iterations(20).check(LimitCounterTest.class);
    }
}
