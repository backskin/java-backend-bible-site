"""Замер задержки от фиксации строки в outbox до записи в Kafka через Debezium.

Запуск из папки стенда: python latency.py [число событий]
Вставляет N строк отдельными транзакциями, затем читает топик и считает
LogAppendTime (метка брокера) минус occurred_at (clock_timestamp() при вставке).
"""
import os, subprocess, sys, re, statistics
from datetime import datetime, timezone

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
os.environ["MSYS_NO_PATHCONV"] = "1"
env = os.environ

def pg(sql):
    return subprocess.run(["docker", "compose", "exec", "-T", "pg", "psql", "-U", "app", "-d", "wallet", "-q", "-c", sql],
                          capture_output=True, text=True, env=env).stdout

pg("TRUNCATE outbox;")
# старые сообщения в топике исказили бы замер: топик удаляем, брокер создаст его заново при первой записи
subprocess.run(["docker", "compose", "exec", "-T", "kafka", "/opt/kafka/bin/kafka-topics.sh", "--bootstrap-server", "localhost:9092", "--delete", "--topic", "outbox.event.payment"], capture_output=True, text=True, env=env)
import time; time.sleep(3)
before = pg("SELECT count(*) FROM outbox;")
# N отдельных транзакций одним вызовом psql: каждая строка - свой INSERT, autocommit
sql = "\n".join(
    f"INSERT INTO outbox (id, aggregatetype, aggregateid, type, payload) VALUES (gen_random_uuid(),'payment','P-{i}','PaymentCreated','{{\"n\": {i}}}');"
    for i in range(N))
subprocess.run(["docker", "compose", "exec", "-T", "pg", "psql", "-U", "app", "-d", "wallet", "-q"], input=sql, capture_output=True, text=True, env=env)

out = subprocess.run(["docker", "compose", "exec", "-T", "kafka", "/opt/kafka/bin/kafka-console-consumer.sh",
                      "--bootstrap-server", "localhost:9092", "--topic", "outbox.event.payment", "--from-beginning",
                      "--max-messages", str(N), "--timeout-ms", "60000",
                      "--formatter-property", "print.timestamp=true", "--formatter-property", "print.headers=true"],
                     capture_output=True, text=True, env=env).stdout
lat = []
for line in out.splitlines():
    m = re.search(r"LogAppendTime:(\d+)\t.*occurredAt:(\S+?)(,|\t)", line)
    if not m:
        continue
    appended = int(m.group(1)) / 1000.0
    occurred = datetime.fromisoformat(m.group(2).replace("Z", "+00:00")).timestamp()
    lat.append((appended - occurred) * 1000)
lat.sort()
if not lat:
    print("сообщений не получено; вывод потребителя:\n", out[:2000]); sys.exit(1)
q = lambda p: lat[min(len(lat) - 1, int(len(lat) * p))]
print(f"событий: {len(lat)} из {N}")
print(f"задержка фиксация -> Kafka, мс: min {lat[0]:.0f}, p50 {q(0.5):.0f}, p90 {q(0.9):.0f}, p99 {q(0.99):.0f}, max {lat[-1]:.0f}, среднее {statistics.mean(lat):.0f}")
