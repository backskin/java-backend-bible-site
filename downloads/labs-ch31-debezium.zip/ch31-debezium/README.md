# Outbox через Debezium: стенд за пять минут

Шаблон к главе 31, раздел 3.3. Поднимает PostgreSQL с логическим декодированием, Kafka (KRaft) и Debezium Connect с преобразованием Outbox Event Router: вставка в таблицу `outbox` превращается в сообщение в топике `outbox.event.<aggregatetype>`.

## Что нужно

- Docker с Compose (проверено на Docker Desktop 29.6.1, Windows 10).
- Свободные порты 55432 (PostgreSQL), 59092 (Kafka с хоста), 58083 (REST Connect).
- Python 3 только для замера задержки (`latency.py`), стенду он не нужен.

## Запуск

```bash
docker compose up -d
```

Через 20–30 секунд Connect отвечает на `curl localhost:58083/`. Коннектор регистрируется одним запросом:

```bash
curl -X POST -H 'Content-Type: application/json' localhost:58083/connectors -d @connector.json
```

Состояние: `curl localhost:58083/connectors/wallet-outbox-connector/status` - у коннектора и задачи `RUNNING`.

## Проверка

Вставить событие в outbox (в Git Bash на Windows перед `docker compose exec` ставьте `export MSYS_NO_PATHCONV=1`, иначе пути внутри контейнера подменяются):

```bash
docker compose exec -T pg psql -U app -d wallet -c "INSERT INTO outbox (id, aggregatetype, aggregateid, type, payload) VALUES (gen_random_uuid(),'wallet','W-1','FundsWithdrawn','{\"amount\": 100}');"
```

Прочитать его из топика с меткой времени брокера и заголовками:

```bash
docker compose exec -T kafka /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic outbox.event.wallet --from-beginning --max-messages 1 --formatter-property print.timestamp=true --formatter-property print.headers=true --formatter-property print.key=true
```

Ключ сообщения - `aggregateid`, заголовки `id`, `eventType`, `occurredAt` взяты из колонок таблицы (настройка `table.fields.additional.placement` в `connector.json`).

## Замер задержки

```bash
python latency.py 1000
```

Скрипт вставляет 1000 строк отдельными транзакциями и считает разницу между меткой брокера (`LogAppendTime`) и `occurred_at`. Результаты автора - в `s31-debezium-latency.txt`; главное, что интервал опроса `poll.interval.ms` (по умолчанию 500) определяет задержку сильнее, чем само декодирование: `connector-config-fast.json` с `poll.interval.ms=100` дает p99 около 200 мс вместо 900.

## Что в файлах

- `docker-compose.yml` - три контейнера; у PostgreSQL `wal_level=logical`, у Kafka метки времени `LogAppendTime`, чтобы мерить задержку по часам брокера.
- `init.sql` - таблица `outbox` с именами колонок, которые Outbox Event Router ожидает по умолчанию (`aggregatetype`, `aggregateid`, `type`, `payload`), роль `debezium` с правом `REPLICATION` без суперпользователя и публикация `outbox_pub`.
- `connector.json` - конфигурация коннектора: плагин `pgoutput`, готовая публикация, маршрутизация в `outbox.event.${routedByValue}`.
- `connector-config-fast.json` - та же конфигурация с `poll.interval.ms=100` и `table.expand.json.payload=true` (jsonb-колонка отдается объектом, а не строкой); применяется `PUT .../connectors/wallet-outbox-connector/config`.

## Остановка

```bash
docker compose down -v
```

`-v` удаляет том PostgreSQL вместе со слотом репликации; без него слот `outbox_slot` остается и после остановки коннектора копит WAL.
