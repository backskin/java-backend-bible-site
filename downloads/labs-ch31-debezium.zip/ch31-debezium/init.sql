-- Таблица outbox как в разделе 3.1 главы 31 (имена колонок под Outbox Event Router по умолчанию)
CREATE TABLE outbox (
    id             uuid        PRIMARY KEY,
    aggregatetype  text        NOT NULL,
    aggregateid    text        NOT NULL,
    type           text        NOT NULL,
    payload        jsonb       NOT NULL,
    occurred_at    timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE TABLE payments (id uuid PRIMARY KEY, amount numeric(19,4) NOT NULL, status text NOT NULL);
CREATE ROLE debezium WITH LOGIN PASSWORD 'debezium' REPLICATION;
GRANT SELECT ON outbox, payments TO debezium;
CREATE PUBLICATION outbox_pub FOR TABLE outbox;
