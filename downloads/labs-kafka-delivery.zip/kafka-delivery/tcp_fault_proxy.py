"""TCP-прокси перед брокером Kafka с внедрением сбоя «потеряли ответ брокера»: запрос доходит до брокера и исполняется, а клиент ответа не получает и видит обрыв соединения.
Слушает 59092 (его брокер объявляет клиентам в advertised.listeners), пересылает на 59094 (port-forward на под kafka).
Управление по HTTP на 59095: GET /drop?on=1 — глотать ответы брокера и рвать соединения клиентов; GET /drop?on=0 — вернуть норму; GET /stats — счётчики."""
import asyncio
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import threading

LISTEN, UPSTREAM, CTL = 59092, 59094, 59095
STATE = {"drop": False, "cut": 0, "conns": 0}


async def pump(reader, writer, to_client, peer_writer):
    try:
        while True:
            data = await reader.read(65536)
            if not data:
                break
            if to_client and STATE["drop"]:
                # ответ брокера «потерян»: клиенту не отдаём, соединение рвём
                STATE["cut"] += 1
                peer_writer.close()
                writer.close()
                return
            writer.write(data)
            await writer.drain()
    except Exception:
        pass
    finally:
        try:
            writer.close()
        except Exception:
            pass


async def handle(client_reader, client_writer):
    STATE["conns"] += 1
    try:
        up_reader, up_writer = await asyncio.open_connection("127.0.0.1", UPSTREAM)
    except Exception:
        client_writer.close()
        return
    await asyncio.gather(pump(client_reader, up_writer, False, client_writer), pump(up_reader, client_writer, True, up_writer))


class Ctl(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path.startswith("/drop"):
            STATE["drop"] = self.path.endswith("on=1")
        body = json.dumps(STATE).encode()
        self.send_response(200)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


async def main():
    threading.Thread(target=lambda: ThreadingHTTPServer(("127.0.0.1", CTL), Ctl).serve_forever(), daemon=True).start()
    server = await asyncio.start_server(handle, "127.0.0.1", LISTEN)
    async with server:
        await server.serve_forever()


asyncio.run(main())
