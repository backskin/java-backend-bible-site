package demo;

import java.sql.*;
import java.time.Duration;
import java.util.*;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;

/**
 * 7.7: потребитель пишет в PostgreSQL. Режимы:
 *   naive — INSERT, commit БД, затем commitSync оффсета Kafka (at-least-once без защиты от дублей);
 *   dedup — то же, но таблица с PRIMARY KEY и INSERT ... ON CONFLICT DO NOTHING (идемпотентный приёмник);
 *   dbofs — оффсет хранится в БД и обновляется в той же транзакции, что и данные; Kafka-коммит не используется, при старте seek на оффсет из БД.
 * Процесс падает (Runtime.halt) на заданном батче сразу после коммита БД и до фиксации в Kafka.
 */
public class DbSink {
    static final String URL = "jdbc:postgresql://localhost:55432/oms?user=postgres&password=x";

    public static void main(String[] a) throws Exception {
        String mode = a[0], in = a[1], group = a[2];
        int crashBatch = Integer.parseInt(a[3]);
        Properties cp = new Properties();
        cp.put("bootstrap.servers", Common.BOOTSTRAP);
        cp.put("group.id", group);
        cp.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        cp.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        cp.put("enable.auto.commit", "false");
        cp.put("auto.offset.reset", "earliest");
        cp.put("max.poll.records", "10");
        cp.put("session.timeout.ms", "6000");
        cp.put("heartbeat.interval.ms", "2000");
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cp); Connection db = DriverManager.getConnection(URL)) {
            db.setAutoCommit(false);
            TopicPartition tp = new TopicPartition(in, 0);
            if (mode.equals("dbofs")) {
                c.assign(List.of(tp));
                try (PreparedStatement q = db.prepareStatement("select next_off from offsets where topic=? and part=0")) {
                    q.setString(1, in);
                    ResultSet rs = q.executeQuery();
                    if (rs.next()) c.seek(tp, rs.getLong(1)); else c.seekToBeginning(List.of(tp));
                }
                db.commit();
            } else {
                c.subscribe(List.of(in));
            }
            String table = mode.equals("naive") ? "sink_naive" : mode.equals("dedup") ? "sink_dedup" : "sink_ofs";
            String sql = mode.equals("dedup") ? "insert into sink_dedup(msg_key, val) values (?,?) on conflict do nothing" : "insert into " + table + "(msg_key, val) values (?,?)";
            int batch = 0, idle = 0;
            while (idle < 40) {
                ConsumerRecords<String, String> recs = c.poll(Duration.ofMillis(500));
                if (recs.isEmpty()) { idle++; continue; }
                idle = 0;
                batch++;
                long last = -1;
                try (PreparedStatement ins = db.prepareStatement(sql)) {
                    for (ConsumerRecord<String, String> r : recs) {
                        ins.setString(1, r.key());
                        ins.setString(2, r.value());
                        ins.executeUpdate();
                        last = r.offset();
                    }
                }
                if (mode.equals("dbofs")) {
                    try (PreparedStatement up = db.prepareStatement("insert into offsets(topic, part, next_off) values (?,0,?) on conflict (topic, part) do update set next_off = excluded.next_off")) {
                        up.setString(1, in);
                        up.setLong(2, last + 1);
                        up.executeUpdate();
                    }
                }
                db.commit();
                if (batch == crashBatch) {
                    System.out.println("  [процесс " + mode + "] падение на батче " + batch + ": БД зафиксирована, в Kafka оффсет не зафиксирован");
                    System.out.flush();
                    Runtime.getRuntime().halt(137);
                }
                if (!mode.equals("dbofs")) c.commitSync();
            }
        }
    }
}
