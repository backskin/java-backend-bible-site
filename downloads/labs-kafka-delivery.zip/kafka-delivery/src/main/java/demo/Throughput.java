package demo;

import java.util.*;
import org.apache.kafka.clients.producer.*;

/** 7.9: цена гарантий на одном брокере (port-forward в kind, поэтому абсолют зависит от машины; интересны отношения). 100 000 записей по 100 байт; синхронная отправка 500 записей для задержки. */
public class Throughput {
    static Properties base(String acks, boolean idem, String txId) {
        Properties p = new Properties();
        p.put("bootstrap.servers", Common.BOOTSTRAP);
        p.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        p.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        p.put("acks", acks);
        p.put("enable.idempotence", String.valueOf(idem));
        p.put("linger.ms", "5");
        p.put("batch.size", "65536");
        if (txId != null) p.put("transactional.id", txId);
        return p;
    }

    static void case_(String label, String acks, boolean idem, String txId, int txEvery) throws Exception {
        String topic = "tp-" + System.nanoTime();
        Common.createTopic(topic, 1);
        String payload = "x".repeat(100);
        int n = 100_000;
        double[] rates = new double[3];
        for (int rep = 0; rep < 3; rep++) {
        double rate;
        try (KafkaProducer<String, String> p = new KafkaProducer<>(base(acks, idem, txId == null ? null : txId + "-" + rep))) {
            if (txId != null) p.initTransactions();
            if (txId != null) p.beginTransaction();
            for (int i = 0; i < 3000; i++) p.send(new ProducerRecord<>(topic, "w", payload));   // прогрев
            if (txId != null) p.commitTransaction();
            p.flush();
            long t0 = System.nanoTime();
            if (txId != null) p.beginTransaction();
            for (int i = 0; i < n; i++) {
                p.send(new ProducerRecord<>(topic, "k" + (i & 1023), payload));
                if (txId != null && (i + 1) % txEvery == 0) { p.commitTransaction(); if (i + 1 < n) p.beginTransaction(); }
            }
            if (txId != null && n % txEvery != 0) p.commitTransaction();
            p.flush();
            rate = n / ((System.nanoTime() - t0) / 1e9);
        }
        rates[rep] = rate;
        }
        Arrays.sort(rates);
        double rate = rates[1];
        // задержка синхронной отправки
        long[] lat = new long[500];
        Properties lp = base(acks, idem, txId == null ? null : txId + "-s");
        lp.put("linger.ms", "0");
        try (KafkaProducer<String, String> p = new KafkaProducer<>(lp)) {
            if (txId != null) p.initTransactions();
            for (int i = 0; i < 100; i++) { if (txId != null) p.beginTransaction(); p.send(new ProducerRecord<>(topic, "w", payload)).get(); if (txId != null) p.commitTransaction(); }
            for (int i = 0; i < 500; i++) {
                long t0 = System.nanoTime();
                if (txId != null) p.beginTransaction();
                p.send(new ProducerRecord<>(topic, "s", payload)).get();
                if (txId != null) p.commitTransaction();
                lat[i] = System.nanoTime() - t0;
            }
        }
        Arrays.sort(lat);
        System.out.printf("  %-58s %9.0f зап./с; синхронная отправка (linger.ms=0)%s: p50 %.1f мс, p99 %.1f мс%n", label, rate, txId != null ? " с commit на каждую" : "", lat[250] / 1e6, lat[495] / 1e6);
    }

    public static void main(String[] a) throws Exception {
        System.out.println("== 7.9 цена гарантий на одном брокере: 100 000 записей по 100 байт, linger.ms=5, batch.size=64 КБ");
        case_("acks=0 (без подтверждения)", "0", false, null, 0);
        case_("acks=1, без идемпотентности", "1", false, null, 0);
        case_("acks=all, без идемпотентности", "all", false, null, 0);
        case_("acks=all + enable.idempotence=true", "all", true, null, 0);
        case_("транзакции, commit каждые 1000 записей", "all", true, "tx-bench-1", 1000);
        case_("транзакции, commit каждые 100 записей", "all", true, "tx-bench-2", 100);
        case_("транзакции, commit каждые 10 записей", "all", true, "tx-bench-3", 10);
    }
}
