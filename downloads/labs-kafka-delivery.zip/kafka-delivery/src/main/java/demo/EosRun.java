package demo;

import java.io.File;
import java.util.*;
import org.apache.kafka.clients.producer.*;

/** Оркестратор опыта 7.6: наполняет входной топик 100 записями, запускает процесс обработки, роняет его, перезапускает и считает результат. */
public class EosRun {
    static void runChild(String... args) throws Exception {
        List<String> cmd = new ArrayList<>(List.of(System.getProperty("java.home") + File.separator + "bin" + File.separator + "java",
                "-Dstdout.encoding=UTF-8", "-Dorg.slf4j.simpleLogger.defaultLogLevel=error", "-cp", System.getProperty("java.class.path"), "demo.Eos"));
        cmd.addAll(Arrays.asList(args));
        Process pr = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        new String(pr.getInputStream().readAllBytes());
        pr.waitFor();
        System.out.println("  процесс завершился с кодом " + pr.exitValue() + (pr.exitValue() == 137 ? " (аварийно)" : ""));
    }

    static String scenario(String mode, String label) throws Exception {
        String id = mode + "-" + System.currentTimeMillis();
        String in = "in-" + id, out = "out-" + id, group = "g-" + id;
        Common.createTopic(in, 1);
        Common.createTopic(out, 1);
        Properties pp = new Properties();
        pp.put("bootstrap.servers", Common.BOOTSTRAP);
        pp.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        pp.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        try (KafkaProducer<String, String> p = new KafkaProducer<>(pp)) {
            for (int i = 0; i < 100; i++) p.send(new ProducerRecord<>(in, "k" + i, "v" + i));
            p.flush();
        }
        System.out.println("-- " + label);
        runChild(mode, in, out, group, "4");        // падает на 4-м батче
        runChild(mode, in, out, group, "0");        // перезапуск без сбоя
        List<String[]> committed = Common.readAll(out, "read_committed");
        List<String[]> uncommitted = Common.readAll(out, "read_uncommitted");
        return "   читатель read_committed: " + Common.stats(committed) + "\n   читатель read_uncommitted: " + Common.stats(uncommitted);
    }

    public static void main(String[] a) throws Exception {
        System.out.println("== 7.6 обработка 100 записей батчами по 10, процесс убит на 4-м батче после записи результата и до фиксации");
        System.out.println(scenario("alo", "at-least-once: send + flush, затем commitSync оффсета"));
        System.out.println(scenario("eos", "транзакция: send + sendOffsetsToTransaction + commitTransaction"));
    }
}
