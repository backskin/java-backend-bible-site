package demo;

import java.time.Duration;
import java.util.*;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.TopicPartition;

/**
 * 7.6: цикл «прочитать — обработать — записать» и «умирающий» процесс. Режимы:
 *   alo — не транзакционно: send в выходной топик, flush, затем commitSync оффсета (at-least-once);
 *   eos — транзакция: send, sendOffsetsToTransaction, commitTransaction (оффсет и результат фиксируются вместе).
 * Процесс падает через Runtime.halt (как kill -9) на заданном батче, после записи результатов и до фиксации. Запуск дочерним процессом из EosRun.
 */
public class Eos {
    public static void main(String[] a) throws Exception {
        String mode = a[0], in = a[1], out = a[2], group = a[3];
        int crashBatch = Integer.parseInt(a[4]);           // 0 — не падать
        int batchSize = 10;
        Properties cp = new Properties();
        cp.put("bootstrap.servers", Common.BOOTSTRAP);
        cp.put("group.id", group);
        cp.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        cp.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        cp.put("enable.auto.commit", "false");
        cp.put("auto.offset.reset", "earliest");
        cp.put("max.poll.records", String.valueOf(batchSize));
        cp.put("isolation.level", "read_committed");
        cp.put("session.timeout.ms", "6000");
        cp.put("heartbeat.interval.ms", "2000");
        Properties pp = new Properties();
        pp.put("bootstrap.servers", Common.BOOTSTRAP);
        pp.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        pp.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        pp.put("acks", "all");
        if (mode.equals("eos")) pp.put("transactional.id", "eos-" + group);
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cp); KafkaProducer<String, String> p = new KafkaProducer<>(pp)) {
            if (mode.equals("eos")) p.initTransactions();          // фенсинг: завершает зависшую транзакцию предыдущего экземпляра
            c.subscribe(List.of(in));
            int batch = 0, idle = 0;
            while (idle < 40) {
                ConsumerRecords<String, String> recs = c.poll(Duration.ofMillis(500));
                if (recs.isEmpty()) { idle++; continue; }
                idle = 0;
                batch++;
                Map<TopicPartition, OffsetAndMetadata> offs = new HashMap<>();
                if (mode.equals("eos")) p.beginTransaction();
                for (ConsumerRecord<String, String> r : recs) {
                    p.send(new ProducerRecord<>(out, r.key(), r.value() + "!"));
                    offs.put(new TopicPartition(r.topic(), r.partition()), new OffsetAndMetadata(r.offset() + 1));
                }
                if (mode.equals("eos")) p.sendOffsetsToTransaction(offs, c.groupMetadata());
                else p.flush();
                if (batch == crashBatch) {
                    if (mode.equals("eos")) p.flush();               // записи уже у брокера, транзакция не завершена
                    System.out.println("  [процесс " + mode + "] падение на батче " + batch + ": результаты записаны, фиксации нет");
                    System.out.flush();
                    Runtime.getRuntime().halt(137);
                }
                if (mode.equals("eos")) p.commitTransaction();
                else c.commitSync(offs);
            }
            System.out.println("  [процесс " + mode + "] обработка закончена, батчей " + batch);
        }
    }
}
