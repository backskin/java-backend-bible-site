package demo;

import java.util.*;
import org.apache.kafka.clients.producer.*;

/**
 * 7.4: подтверждение (ответ брокера на Produce) потерялось, а запись брокер уже добавил. Продюсер повторяет отправку.
 * Без идемпотентности в журнале появляются дубли, с идемпотентностью (PID и номера последовательности) брокер дубль отбрасывает.
 * Запуск: mvn -q compile exec:java -Dexec.mainClass=demo.E1LostAck   (нужны брокер и tcp_fault_proxy.py)
 */
public class E1LostAck {
    static String run(boolean idempotent, int total, int every) throws Exception {
        String topic = "e1-" + (idempotent ? "idem-" : "plain-") + System.currentTimeMillis();
        Common.createTopic(topic, 1);
        Properties p = new Properties();
        p.put("bootstrap.servers", Common.BOOTSTRAP);
        p.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        p.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        p.put("acks", "all");
        p.put("enable.idempotence", String.valueOf(idempotent));
        p.put("request.timeout.ms", "1500");
        p.put("delivery.timeout.ms", "20000");
        p.put("linger.ms", "0");
        if (!idempotent) p.put("max.in.flight.requests.per.connection", "1");   // без идемпотентности порядок при повторах держат единицей
        int errors = 0;
        long retriesSeen = 0;
        try (KafkaProducer<String, String> prod = new KafkaProducer<>(p)) {
            for (int i = 0; i < total; i++) {
                boolean window = i % every == every / 2;
                if (window) Common.proxyDrop(true);
                prod.send(new ProducerRecord<>(topic, "k" + i, "v" + i), (m, e) -> {});
                if (window) {
                    Thread.sleep(400);
                    Common.proxyDrop(false);
                }
                prod.flush();                       // дождаться подтверждения (с повторами) до следующей записи
            }
            for (var e : prod.metrics().entrySet()) if (e.getKey().name().equals("record-retry-total")) retriesSeen = (long) (double) (Double) e.getValue().metricValue();
        }
        List<String[]> recs = Common.readAll(topic, "read_uncommitted");
        return (idempotent ? "enable.idempotence=true " : "enable.idempotence=false") + ": отправлено " + total + ", потерянных подтверждений (окон) " + (total / every) + ", повторов отправки по метрике " + retriesSeen + "; в журнале " + Common.stats(recs);
    }

    public static void main(String[] a) throws Exception {
        System.out.println("== 7.4 потерянное подтверждение: acks=all, request.timeout.ms=1500; каждые 20 записей ответ брокера теряется на 0,4 с");
        for (int r = 1; r <= 3; r++) {
            System.out.println(" прогон " + r + ":");
            System.out.println("   " + run(false, 200, 20));
            System.out.println("   " + run(true, 200, 20));
        }
        System.out.println("прокси: " + Common.proxyStats());
    }
}
