package demo;

import java.io.File;
import java.sql.*;
import java.util.*;
import org.apache.kafka.clients.producer.*;

/** Оркестратор 7.7: три способа записи в PostgreSQL при падении процесса между коммитом БД и коммитом Kafka. */
public class DbRun {
    static void runChild(String... args) throws Exception {
        List<String> cmd = new ArrayList<>(List.of(System.getProperty("java.home") + File.separator + "bin" + File.separator + "java",
                "-Dstdout.encoding=UTF-8", "-Dorg.slf4j.simpleLogger.defaultLogLevel=error", "-cp", System.getProperty("java.class.path"), "demo.DbSink"));
        cmd.addAll(Arrays.asList(args));
        Process pr = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        new String(pr.getInputStream().readAllBytes());
        pr.waitFor();
    }

    public static void main(String[] a) throws Exception {
        try (Connection db = DriverManager.getConnection(DbSink.URL); Statement s = db.createStatement()) {
            s.execute("drop table if exists sink_naive, sink_dedup, sink_ofs, offsets");
            s.execute("create table sink_naive(msg_key text, val text)");
            s.execute("create table sink_dedup(msg_key text primary key, val text)");
            s.execute("create table sink_ofs(msg_key text, val text)");
            s.execute("create table offsets(topic text, part int, next_off bigint, primary key(topic, part))");
        }
        System.out.println("== 7.7 запись в PostgreSQL: 100 сообщений, батчи по 10, процесс убит на 4-м батче после коммита БД");
        for (String mode : new String[]{"naive", "dedup", "dbofs"}) {
            String id = mode + "-" + System.currentTimeMillis();
            String in = "db-in-" + id;
            Common.createTopic(in, 1);
            Properties pp = new Properties();
            pp.put("bootstrap.servers", Common.BOOTSTRAP);
            pp.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            pp.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            try (KafkaProducer<String, String> p = new KafkaProducer<>(pp)) {
                for (int i = 0; i < 100; i++) p.send(new ProducerRecord<>(in, "pay-" + i, "v" + i));
                p.flush();
            }
            runChild(mode, in, "g-" + id, "4");
            runChild(mode, in, "g-" + id, "0");
            String table = mode.equals("naive") ? "sink_naive" : mode.equals("dedup") ? "sink_dedup" : "sink_ofs";
            try (Connection db = DriverManager.getConnection(DbSink.URL); Statement s = db.createStatement()) {
                ResultSet rs = s.executeQuery("select count(*), count(distinct msg_key) from " + table);
                rs.next();
                String label = mode.equals("naive") ? "INSERT + commit БД, затем commitSync" : mode.equals("dedup") ? "PRIMARY KEY + ON CONFLICT DO NOTHING, затем commitSync" : "оффсет в БД в одной транзакции с данными";
                System.out.println("  " + label + ": строк в таблице " + rs.getInt(1) + ", уникальных ключей " + rs.getInt(2) + ", дублей " + (rs.getInt(1) - rs.getInt(2)));
            }
        }
    }
}
