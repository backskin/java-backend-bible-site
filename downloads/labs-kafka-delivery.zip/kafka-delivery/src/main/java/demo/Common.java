package demo;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;
import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;

/** Общие вещи для опытов: адрес брокера, создание тем, подсчёт записей, управление прокси сбоев. */
public final class Common {
    public static final String BOOTSTRAP = "localhost:59092";

    private Common() {}

    public static void createTopic(String name, int partitions) throws Exception {
        try (Admin a = Admin.create(Map.of("bootstrap.servers", BOOTSTRAP))) {
            a.createTopics(List.of(new NewTopic(name, partitions, (short) 1))).all().get();
        }
    }

    /** Все значения темы с начала до конца на момент вызова; isolation = read_committed или read_uncommitted. */
    public static List<String[]> readAll(String topic, String isolation) {
        Properties p = new Properties();
        p.put("bootstrap.servers", BOOTSTRAP);
        p.put("key.deserializer", StringDeserializer.class.getName());
        p.put("value.deserializer", StringDeserializer.class.getName());
        p.put("isolation.level", isolation);
        p.put("enable.auto.commit", "false");
        List<String[]> out = new ArrayList<>();
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(p)) {
            List<TopicPartition> tps = new ArrayList<>();
            c.partitionsFor(topic).forEach(pi -> tps.add(new TopicPartition(topic, pi.partition())));
            c.assign(tps);
            c.seekToBeginning(tps);
            Map<TopicPartition, Long> end = c.endOffsets(tps);
            long deadline = System.currentTimeMillis() + 20_000;
            while (System.currentTimeMillis() < deadline) {
                for (ConsumerRecord<String, String> r : c.poll(Duration.ofMillis(300))) out.add(new String[]{r.key(), r.value()});
                boolean done = true;
                for (TopicPartition tp : tps) if (c.position(tp) < end.get(tp)) done = false;   // read_committed: позиция доходит до LSO, затем до конца
                if (done) break;
            }
        }
        return out;
    }

    public static String stats(List<String[]> recs) {
        Set<String> distinct = new HashSet<>();
        for (String[] r : recs) distinct.add(r[0]);
        return "записей " + recs.size() + ", уникальных ключей " + distinct.size() + ", дублей " + (recs.size() - distinct.size());
    }

    public static void proxyDrop(boolean on) {
        try {
            HttpClient.newHttpClient().send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:59095/drop?on=" + (on ? 1 : 0))).build(), HttpResponse.BodyHandlers.discarding());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String proxyStats() {
        try {
            return HttpClient.newHttpClient().send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:59095/stats")).build(), HttpResponse.BodyHandlers.ofString()).body();
        } catch (Exception e) {
            return "нет прокси";
        }
    }
}
