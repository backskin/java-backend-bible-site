# Опыты по гарантиям доставки Kafka (глава 29, раздел 7)

Проверено 2026-10-21: один брокер Apache Kafka 3.9.1 (KRaft) в кластере kind, клиент Kafka из Spring Boot 4.1.1, JDK 21, Maven 3.9, PostgreSQL 16.15, Windows. Результаты в тексте главы получены именно этим набором.

## Что нужно

- Брокер Kafka, у которого `advertised.listeners` для внешнего слушателя равен `localhost:59092`. Пример манифеста для kind: `tmp/k8s/kafka.yaml` (вне репозитория; ключевое: `KAFKA_ADVERTISED_LISTENERS=INTERNAL://localhost:29092,EXTERNAL://localhost:59092`, одна реплика служебных топиков).
- Доступ к брокеру на `localhost:59092` (`kubectl -n kafka port-forward svc/kafka 59092:9092`).
- PostgreSQL на `localhost:55432`, база `oms`, пользователь `postgres`, пароль `x` (нужен только для `DbRun`; параметры в `DbSink.URL`).
- Для опыта E1: TCP-прокси `tcp_fault_proxy.py` вместо прямого проброса. Порядок: `kubectl port-forward svc/kafka 59094:9092`, затем `python tcp_fault_proxy.py` (слушает 59092, пересылает на 59094, управление на 59095).

## Запуск

```bash
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt
CP="target/classes;$(cat cp.txt)"           # на Linux и macOS разделитель ":"
java -Dorg.slf4j.simpleLogger.defaultLogLevel=error -cp "$CP" demo.E1LostAck     # 7.5: потерянное подтверждение (нужен прокси)
java -Dorg.slf4j.simpleLogger.defaultLogLevel=error -cp "$CP" demo.EosRun        # 7.7: убитый процесс, транзакция против at-least-once
java -Dorg.slf4j.simpleLogger.defaultLogLevel=error -cp "$CP" demo.DbRun         # 7.8: запись в PostgreSQL
java -Dorg.slf4j.simpleLogger.defaultLogLevel=error -cp "$CP" demo.Throughput    # 7.9: цена гарантий (прямой проброс, без прокси)
```

Клиент печатает конфигурации при старте; ключ `-Dorg.slf4j.simpleLogger.defaultLogLevel=error` и фильтр `grep -E "^==|^--|процесс|читатель|строк в таблице|зап\./с"` оставляют только результат.

## Что ожидать

- `E1LostAck`: без `enable.idempotence` в журнале 210 записей при 200 отправленных (10 потерянных подтверждений дают 10 дублей), с идемпотентностью 200.
- `EosRun`: at-least-once дает 110 записей (10 дублей), транзакция дает 100 для читателя `read_committed` и 110 для `read_uncommitted`.
- `DbRun`: наивная запись 110 строк, обе защищенные схемы по 100.
- `Throughput`: транзакции дают пропускную способность, обратно пропорциональную частоте commit (≈3,7 мс на commit); абсолютные значения зависят от машины.

Падение процесса моделируется `Runtime.halt(137)`: JVM завершается без закрытия клиентов, как при `kill -9`.
