# Память, диски и файловые системы: опыты гл. 15

Три набора опытов, выводы которых цитирует глава 15 (сноски b15-30, b15-31, b15-32).

| Скрипт | Где выполняется | Вывод |
|---|---|---|
| `run.sh` → `linux.sh` | контейнер `postgres:15` (Debian), нужны Docker и право `SYS_ADMIN` для `tmpfs` | `linux.txt` |
| `java.sh` → `PreTouch.java`, `MappedDelete.java`, `DurableReplace.java` | контейнер `eclipse-temurin:25-jdk` | `java.txt` |
| `windows.ps1` (PowerShell 5.1, без прав администратора) | Windows 10 с JDK 21+ и Git; `MappedDelete.java` и `DurableReplace.java` запускаются и здесь | `windows.txt` |

Запуск: `bash run.sh`, `bash java.sh`, `powershell -ExecutionPolicy Bypass -File windows.ps1`. Домашний путь пользователя в
`windows.txt` заменяется на `<дом>`.

Что получилось при проверке (2026-11-17, ядро 6.18.33.2-microsoft-standard-WSL2, Docker Desktop, Windows 10 Pro 22H2):

- страница 4096 байт; `vm.overcommit_memory = 1`, `vm.max_map_count = 262144` (ядро по умолчанию задаёт 65 530, значение
  меняет Docker Desktop); прозрачные большие страницы в режиме `madvise`; `vm.dirty_*` - 3000, 1500, 10, 20;
- `inode_ratio = 16384` в `/etc/mke2fs.conf` Debian 13; `umask 0022` даёт файлу `644`, каталогу `755`;
- `tmpfs` с `nr_inodes=200`: создано 199 файлов, `df -h` 8 %, `df -i` 100 %; удалённый открытый файл в 6 МБ держит место,
  пока его не обрезать через `/proc/<pid>/fd`;
- `pg_test_fsync`: запись 8 КБ без синхронизации 1 мкс, с `fdatasync` 352 мкс, 16 записей по 1 КБ с `open_sync` 6,9 мс
  против 0,44 мс одной записью 16 КБ;
- JVM с `-Xms1g -Xmx1g`: RSS на старте 132 МБ, с `-XX:+AlwaysPreTouch` 1,17 ГБ;
- `MappedByteBuffer`: на Linux файл под живым отображением удаляется, на Windows - `AccessDeniedException`;
- на Windows `core.ignoreCase = true`, переименование только регистра Git не видит до `git mv -f`; `javac` требует имя
  файла с учётом регистра; названия в Мониторе ресурсов и на вкладке «Политика» свойств диска есть в русских ресурсах.
