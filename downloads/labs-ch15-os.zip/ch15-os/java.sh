#!/usr/bin/env bash
# PreTouch.java в контейнере eclipse-temurin:25-jdk с кучей 1 ГиБ, без -XX:+AlwaysPreTouch и с ним.
# Там же MappedDelete.java для сравнения с Windows. Вывод - в java.txt.
set -u
cd "$(dirname "$0")"
{
for flags in "-Xms1g -Xmx1g" "-Xms1g -Xmx1g -XX:+AlwaysPreTouch"; do
  echo "== java $flags"
  MSYS_NO_PATHCONV=1 docker run --rm -v "$(pwd)/PreTouch.java:/lab/PreTouch.java:ro" eclipse-temurin:25-jdk \
    sh -c "java -version 2>&1 | head -1; java -Dstdout.encoding=UTF-8 $flags /lab/PreTouch.java"
done
echo "== MappedDelete на Linux (3.4)"
MSYS_NO_PATHCONV=1 docker run --rm -v "$(pwd)/MappedDelete.java:/lab/MappedDelete.java:ro" eclipse-temurin:25-jdk   java -Dstdout.encoding=UTF-8 /lab/MappedDelete.java
echo "== DurableReplace на Linux (5.2)"
MSYS_NO_PATHCONV=1 docker run --rm -v "$(pwd)/DurableReplace.java:/lab/DurableReplace.java:ro" eclipse-temurin:25-jdk   java -Dstdout.encoding=UTF-8 /lab/DurableReplace.java
} > java.txt 2>&1
cat java.txt
