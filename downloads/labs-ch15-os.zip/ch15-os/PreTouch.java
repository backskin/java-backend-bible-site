import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Показывает, когда JVM получает физическую память под кучу: печатает RSS, размер таблиц страниц
 * и число малых страничных прерываний сразу после старта, после выделения массива на 512 МиБ
 * и после его заполнения. Запускается с -XX:+AlwaysPreTouch и без него (см. java.sh).
 */
public class PreTouch {

    public static void main(String[] args) throws Exception {
        print("старт");
        byte[] data = new byte[512 << 20];
        print("массив 512 МиБ выделен");
        for (int i = 0; i < data.length; i += 4096) {
            data[i] = 1;
        }
        print("массив заполнен");
    }

    private static void print(String stage) throws Exception {
        String status = Files.readString(Path.of("/proc/self/status"));
        String rss = field(status, "VmRSS:");
        String pte = field(status, "VmPTE:");
        String[] stat = Files.readString(Path.of("/proc/self/stat")).split("\\) ")[1].split(" ");
        // после имени процесса поля идут с третьего: minflt - 10-е поле, majflt - 12-е
        System.out.printf("%-24s VmRSS=%s VmPTE=%s minflt=%s majflt=%s%n", stage, rss, pte, stat[7], stat[9]);
    }

    private static String field(String status, String name) {
        return status.lines().filter(l -> l.startsWith(name)).findFirst().orElse(name + " ?")
                .substring(name.length()).trim().replaceAll("\\s+", " ");
    }
}
