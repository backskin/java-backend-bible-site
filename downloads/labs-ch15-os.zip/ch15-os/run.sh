#!/usr/bin/env bash
# Запускает linux.sh в одноразовом контейнере postgres:15; вывод - в linux.txt.
# Право SYS_ADMIN нужно для монтирования tmpfs внутри контейнера.
set -u
cd "$(dirname "$0")"
MSYS_NO_PATHCONV=1 docker run --rm --cap-add SYS_ADMIN --security-opt apparmor=unconfined \
  -v "$(pwd)/linux.sh:/lab/linux.sh:ro" postgres:15 bash /lab/linux.sh > linux.txt 2>&1
cat linux.txt
