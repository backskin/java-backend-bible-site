#!/usr/bin/env bash
# Опыты гл. 15 на Linux: выполняется внутри контейнера postgres:15 (Debian), см. run.sh.
# Каждый блок печатает заголовок "== ..." и вывод команд как есть.
set -u
cd /root

echo "== ядро и образ"
uname -r
grep PRETTY_NAME /etc/os-release

echo "== размер страницы (2.3)"
getconf PAGESIZE

echo "== параметры памяти ядра (2.8, 2.9, 3.4, 3.6)"
for f in overcommit_memory overcommit_ratio swappiness max_map_count \
         dirty_expire_centisecs dirty_writeback_centisecs dirty_background_ratio dirty_ratio; do
  echo "vm.$f = $(cat /proc/sys/vm/$f)"
done
echo "transparent_hugepage/enabled: $(cat /sys/kernel/mm/transparent_hugepage/enabled)"
grep -E '^(MemTotal|MemAvailable|CommitLimit|Committed_AS)' /proc/meminfo

echo "== free -h (3.5)"
free -h

echo "== vmstat 1 3 (11.5)"
vmstat 1 3

echo "== inode_ratio по умолчанию в /etc/mke2fs.conf (9.2)"
apt-get -qq update >/dev/null 2>&1 && apt-get -qq install -y e2fsprogs procps >/dev/null 2>&1
grep -E 'inode_ratio|inode_size' /etc/mke2fs.conf | head -5

echo "== umask и права нового файла и каталога (9.5)"
umask
touch newfile && mkdir newdir && stat -c '%A %n' newfile newdir

echo "== жёсткая и символическая ссылки (9.2, 9.4)"
mkdir -p links && cd links
echo "реестр" > registry.csv
ln registry.csv registry-hard.csv
ln -s registry.csv registry-sym.csv
ls -li
stat registry.csv | sed -n '1,3p'
rm registry.csv
echo "после rm исходного имени:"
cat registry-hard.csv
cat registry-sym.csv 2>&1 || true
cd /root

echo "== исчерпание inode на tmpfs nr_inodes=200 (11.4)"
mkdir -p /mnt/t && mount -t tmpfs -o size=10m,nr_inodes=200 tmpfs /mnt/t
n=0
for i in $(seq 1 300); do
  if ! echo x > /mnt/t/f$i 2>/tmp/err; then echo "файл $i: $(cat /tmp/err)"; break; fi
  n=$i
done
echo "создано файлов: $n"
df -h /mnt/t | tail -1
df -i /mnt/t | tail -1
rm -f /mnt/t/f*

echo "== удалённый, но открытый файл (9.4, 11.4)"
dd if=/dev/zero of=/mnt/t/app.log bs=1M count=6 status=none
exec 3</mnt/t/app.log
rm /mnt/t/app.log
echo "после rm:"; df -h /mnt/t | tail -1
ls -l /proc/$$/fd/3 | sed 's/.*-> /fd 3 -> /'
: > /proc/$$/fd/3
echo "после обрезки через /proc/<pid>/fd:"; df -h /mnt/t | tail -1
exec 3<&-
umount /mnt/t

echo "== грязные страницы до и после sync (3.6)"
dd if=/dev/zero of=/root/big bs=1M count=500 status=none
grep -E '^(Dirty|Writeback):' /proc/meminfo
sync
echo "после sync:"
grep -E '^(Dirty|Writeback):' /proc/meminfo
rm -f /root/big

echo "== размеры секторов (4.7)"
lsblk -t 2>/dev/null | head -5 || echo "lsblk недоступен"

echo "== pg_test_fsync (1.3, 5.3)"
/usr/lib/postgresql/15/bin/pg_test_fsync -s 2 -f /root/fsync.test
