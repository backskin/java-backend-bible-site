﻿# Опыты гл. 15 на Windows (PowerShell 5.1, права администратора не нужны). Вывод - в windows.txt.
# Нужны JDK 21+ (java, javac в PATH или в JAVA_HOME) и Git.
$ErrorActionPreference = 'Continue'
$lab = Split-Path -Parent $MyInvocation.MyCommand.Path
$work = Join-Path $env:TEMP 'ch15-os-win'
Remove-Item -Recurse -Force $work -ErrorAction SilentlyContinue
New-Item -ItemType Directory $work | Out-Null
Set-Location $work
$java = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME 'bin\java.exe' } else { 'java' }
$javac = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME 'bin\javac.exe' } else { 'javac' }

& {
'== ОС'
(Get-CimInstance Win32_OperatingSystem).Caption + ' ' + (Get-CimInstance Win32_OperatingSystem).Version
'== Java'
& $java -version 2>&1 | Select-Object -First 1 | ForEach-Object { "$_" }

'== альтернативные потоки данных NTFS (8.7)'
Set-Content -Path .\statement.txt -Value 'statement'
Set-Content -Path .\statement.txt -Stream secret -Value 'hidden-part'
'Length основного файла: ' + (Get-Item .\statement.txt).Length
Get-Item .\statement.txt -Stream * | Select-Object Stream, Length | Format-Table -AutoSize | Out-String -Width 200
'поток secret: ' + (Get-Content .\statement.txt -Stream secret)

'== MappedByteBuffer и удаление файла (3.4)'
& $java '-Dstdout.encoding=UTF-8' (Join-Path $lab 'MappedDelete.java') 2>&1 | ForEach-Object { "$_" }

'== DurableReplace на Windows (5.2)'
& $java '-Dstdout.encoding=UTF-8' (Join-Path $lab 'DurableReplace.java') 2>&1 | ForEach-Object { "$_" }

'== регистр имени, Git и javac (10.5)'
New-Item -ItemType Directory repo | Out-Null
Set-Location repo
git init -q 2>&1 | Out-Null
git config user.name dev.team
git config user.email dev.team@example.invalid
'core.ignoreCase после git init: ' + (git config core.ignoreCase)
Set-Content -Path Paymentservice.java -Value 'public class PaymentService {}' -Encoding ASCII
git add . ; git commit -q -m init
Rename-Item Paymentservice.java PaymentService.java.tmp
Rename-Item PaymentService.java.tmp PaymentService.java
'файл на диске: ' + (Get-ChildItem *.java).Name
'git status --short: [' + ((git status --short) -join ';') + ']'
'git ls-files: ' + (git ls-files)
git mv -f Paymentservice.java PaymentService.java
'после git mv -f, git status --short: ' + ((git status --short) -join ';')
Set-Location ..
New-Item -ItemType Directory wrongname | Out-Null
Set-Content -Path wrongname\Paymentservice.java -Value 'public class PaymentService {}' -Encoding ASCII
'javac для Paymentservice.java с классом PaymentService:'
& $javac -d out wrongname\Paymentservice.java 2>&1 | Select-Object -First 1 | ForEach-Object { "$_" }

'== различение регистра каталогом (10.5)'
fsutil file queryCaseSensitiveInfo $work 2>&1

'== названия в Мониторе ресурсов, русские строки ресурсов (3.8)'
$mui = Join-Path $env:WINDIR 'System32\ru-RU\wdc.dll.mui'
if (Test-Path $mui) {
  $text = [System.Text.Encoding]::Unicode.GetString([System.IO.File]::ReadAllBytes($mui))
  foreach ($w in 'Используется', 'Изменено', 'Ожидание', 'Свободно', 'Зарезервировано аппаратно') {
    "'$w' в wdc.dll.mui: " + ($text.Contains($w))
  }
} else { 'wdc.dll.mui не найден' }

'== вкладка свойств диска с кэшем записи, русские строки ресурсов (4.8)'
$sp = Join-Path $env:WINDIR 'System32\ru-RU\storprop.dll.mui'
if (Test-Path $sp) {
  $text = [System.Text.Encoding]::Unicode.GetString([System.IO.File]::ReadAllBytes($sp))
  foreach ($w in 'Политика', 'Политика кэширования записей', 'Разрешить &кэширование записей для этого устройства', 'О&тключить очистку буфера кэша записей Windows для этого устройства', 'только для устройств с отдельным источником питания') {
    "'$w' в storprop.dll.mui: " + ($text.Contains($w))
  }
} else { 'storprop.dll.mui не найден' }
} *> (Join-Path $lab 'windows.txt')
# домашний путь пользователя в выводе заменяется на <дом>
$out = Join-Path $lab 'windows.txt'
$txt = [IO.File]::ReadAllText($out).Replace($env:USERPROFILE, '<дом>')
[IO.File]::WriteAllText($out, $txt, (New-Object Text.UTF8Encoding $false))
Get-Content $out -Encoding UTF8
