import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/**
 * Проверяет класс DurableFiles из подраздела 5.2: дважды заменяет файл реестра и печатает содержимое.
 * На Linux заодно проверяется, что FileChannel.open на каталоге и force(true) работают,
 * на Windows - что открыть каталог как канал нельзя.
 */
public class DurableReplace {

    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("registry");
        Path target = dir.resolve("registry.csv");
        DurableFiles.replace(target, "v1\n".getBytes(StandardCharsets.UTF_8));
        DurableFiles.replace(target, "v2\n".getBytes(StandardCharsets.UTF_8));
        System.out.println(System.getProperty("os.name") + ": содержимое после двух замен: "
                + Files.readString(target).trim() + ", файлов в каталоге: " + Files.list(dir).count());
        try (FileChannel d = FileChannel.open(dir, StandardOpenOption.READ)) {
            d.force(true);
            System.out.println("FileChannel.open(каталог) и force(true): успех");
        } catch (IOException e) {
            System.out.println("FileChannel.open(каталог): " + e.getClass().getSimpleName());
        }
    }
}

/** Класс из подраздела 5.2 без изменений. */
final class DurableFiles {

    /** Атомарно и надёжно заменяет содержимое файла реестра. */
    static void replace(Path target, byte[] content) throws IOException {
        Path dir = target.toAbsolutePath().getParent();
        Path tmp = Files.createTempFile(dir, target.getFileName().toString(), ".tmp");
        try (FileChannel ch = FileChannel.open(tmp, StandardOpenOption.WRITE)) {
            ByteBuffer buf = ByteBuffer.wrap(content);
            while (buf.hasRemaining()) {
                ch.write(buf);
            }
            ch.force(true);
        }
        Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE,
                   StandardCopyOption.REPLACE_EXISTING);
        if (!System.getProperty("os.name").startsWith("Windows")) {
            try (FileChannel d = FileChannel.open(dir, StandardOpenOption.READ)) {
                d.force(true);
            }
        }
    }
}
