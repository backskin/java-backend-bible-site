import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Отображает временный файл в память, закрывает канал и пытается удалить файл, пока буфер жив.
 * На Windows удаление отображённого файла запрещено, на Linux проходит.
 */
public class MappedDelete {

    public static void main(String[] args) throws Exception {
        Path file = Files.createTempFile("registry", ".bin");
        Files.write(file, new byte[4096]);
        MappedByteBuffer buf;
        try (FileChannel ch = FileChannel.open(file, StandardOpenOption.READ, StandardOpenOption.WRITE)) {
            buf = ch.map(FileChannel.MapMode.READ_WRITE, 0, 4096);
        }
        buf.put(0, (byte) 1);
        try {
            Files.delete(file);
            System.out.println(System.getProperty("os.name") + ": файл удалён, хотя отображение живо");
        } catch (Exception e) {
            System.out.println(System.getProperty("os.name") + ": удалить не удалось: " + e);
        }
        System.out.println("байт из буфера после попытки удаления: " + buf.get(0));
    }
}
