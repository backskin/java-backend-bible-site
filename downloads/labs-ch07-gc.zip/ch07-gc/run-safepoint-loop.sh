#!/usr/bin/env bash
# CountedLoop with and without counted-loop safepoints; jcmd Thread.print every second, time-to-safepoint from -Xlog:safepoint.
cd "$(dirname "$0")"
J21=~/.jdks/temurin-21.0.10/bin
for mode in "+" "-"; do
  rm -f sp.log cl.out
  "$J21/java" "-XX:${mode}UseCountedLoopSafepoints" -Xlog:safepoint:file=sp.log:time,uptime -cp out CountedLoop > cl.out 2>&1 &
  sleep 3
  pid=$(grep -m1 '^pid' cl.out | awk '{print $2}')
  for k in 1 2 3; do "$J21/jcmd" "$pid" Thread.print > /dev/null; sleep 1; done
  taskkill //F //PID "$pid" > /dev/null 2>&1
  sleep 1
  echo "== -XX:${mode}UseCountedLoopSafepoints (Temurin 21.0.10, Windows x64): -Xlog:safepoint lines for Thread.print"
  grep "PrintThreads" sp.log | head -3
done
rm -f sp.log cl.out
