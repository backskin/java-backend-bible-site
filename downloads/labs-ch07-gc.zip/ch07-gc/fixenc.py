# Переводит вывод программ (Windows пишет stdout в cp1251) в UTF-8, строку за строкой.
import sys
for f in sys.argv[1:]:
    out = []
    for line in open(f, 'rb').read().split(b'\n'):
        line = line.rstrip(b'\r')
        try:
            out.append(line.decode('utf-8'))
        except UnicodeDecodeError:
            out.append(line.decode('cp1251'))
    open(f, 'w', encoding='utf-8', newline='\n').write('\n'.join(out))
