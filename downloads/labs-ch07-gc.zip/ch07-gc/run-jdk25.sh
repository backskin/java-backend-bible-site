#!/bin/bash
# Прогоны главы 07 на JDK 25.0.5 (Temurin, Windows 10, 16 логических CPU). Один прогон на конфигурацию.
J=~/.jdks/jdk-25.0.5+8/bin/java
cd "$(dirname "$0")"
mkdir -p out
{
for t in "1 60000000" "8 60000000"; do
  echo "### TLAB on, потоки/объекты: $t"; $J -Xms2g -Xmx2g -XX:-DoEscapeAnalysis src/TlabBench.java $t
  echo "### TLAB off, потоки/объекты: $t"; $J -Xms2g -Xmx2g -XX:-DoEscapeAnalysis -XX:-UseTLAB src/TlabBench.java $t
done
} > s03-tlab-jdk25.txt 2>&1
for n in 5000 600000; do
  $J -Xms512m -Xmx512m -XX:+UseG1GC -Xlog:gc,gc+age=debug,gc+ergo+ihop=debug,gc+marking=debug:file=out/gen-$n.log src/Generational.java $n > out/gen-$n.out 2>&1
done
{
for g in "-XX:+UseSerialGC" "-XX:+UseParallelGC" "-XX:+UseG1GC" "-XX:+UseZGC" "-XX:+UseShenandoahGC" "-XX:+UseShenandoahGC -XX:ShenandoahGCMode=generational"; do
  echo "### $g"; $J -Xms2g -Xmx2g $g -Xlog:gc:file=out/lat-$(echo $g | tr -dc 'A-Za-z').log src/Latency.java
done
echo "### G1, ActiveProcessorCount=2"; $J -Xms2g -Xmx2g -XX:+UseG1GC -XX:ActiveProcessorCount=2 src/Latency.java
echo "### ZGC, ActiveProcessorCount=2"; $J -Xms2g -Xmx2g -XX:+UseZGC -XX:ActiveProcessorCount=2 -Xlog:gc:file=out/lat-zgc-2cpu.log src/Latency.java
} > s04-collectors-jdk25.txt 2>&1
echo done
