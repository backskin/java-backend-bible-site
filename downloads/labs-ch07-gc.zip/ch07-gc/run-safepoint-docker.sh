#!/bin/sh
# runs inside eclipse-temurin:21-jdk: CountedLoop with/without counted-loop safepoints, jcmd Thread.print, time to safepoint
for mode in "+" "-"; do
  rm -f /tmp/sp.log
  java -XX:${mode}UseCountedLoopSafepoints -Xlog:safepoint:file=/tmp/sp.log:time,uptime -cp /out CountedLoop > /tmp/cl.out 2>&1 &
  sleep 3
  pid=$(grep -m1 '^pid' /tmp/cl.out | awk '{print $2}')
  for k in 1 2 3; do jcmd $pid Thread.print > /dev/null 2>/tmp/jcmd.err; sleep 1; done
  kill $pid; sleep 1
  echo "== -XX:${mode}UseCountedLoopSafepoints (Temurin 21 in Docker, Linux x64): -Xlog:safepoint lines for Thread.print"
  grep "PrintThreads" /tmp/sp.log | head -3
  head -2 /tmp/jcmd.err
done
