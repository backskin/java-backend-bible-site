import java.util.ArrayList;
import java.util.List;

/**
 * Запуск (в IntelliJ: VM options + Program arguments):
 *   java -Xms2g -Xmx2g -XX:-DoEscapeAnalysis TlabBench.java 8 20000000
 *   java -Xms2g -Xmx2g -XX:-DoEscapeAnalysis -XX:-UseTLAB TlabBench.java 8 20000000
 * Аргументы: число потоков и число объектов на поток.
 */
public class TlabBench {

    record PaymentOrder(long id, long amountKopecks, int currency, String account) {}

    static volatile PaymentOrder sink;          // не даём JIT выбросить аллокации

    public static void main(String[] args) throws Exception {
        int threads = Integer.parseInt(args[0]);
        long perThread = Long.parseLong(args[1]);
        // прогрев
        run(1, 2_000_000);
        long start = System.nanoTime();
        run(threads, perThread);
        long ms = (System.nanoTime() - start) / 1_000_000;
        System.out.println(threads + " поток(ов) x " + perThread + " объектов: " + ms + " мс");
    }

    static void run(int threads, long perThread) throws Exception {
        List<Thread> ts = new ArrayList<>();
        for (int t = 0; t < threads; t++) {
            Thread th = new Thread(() -> {
                PaymentOrder last = null;
                for (long k = 0; k < perThread; k++) last = new PaymentOrder(k, k * 3, 643, "40702810");
                sink = last;
            });
            ts.add(th);
            th.start();
        }
        for (Thread th : ts) th.join();
    }
}
