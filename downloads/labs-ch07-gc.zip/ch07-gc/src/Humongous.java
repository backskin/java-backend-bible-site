import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** Reads a 5 MB file with readAllBytes: byte[] of 5 MB is a humongous object for G1 with 2 MB regions. */
public class Humongous {
    public static void main(String[] args) throws Exception {
        Path f = Files.createTempFile("blob", ".bin");
        Files.write(f, new byte[5 * 1024 * 1024]);
        long total = 0;
        for (int i = 0; i < 200; i++) {
            try (InputStream in = Files.newInputStream(f)) {
                total += in.readAllBytes().length;
            }
        }
        System.out.println("read " + total + " bytes");
        Files.delete(f);
    }
}
