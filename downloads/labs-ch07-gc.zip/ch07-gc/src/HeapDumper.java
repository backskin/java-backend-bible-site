import com.sun.management.HotSpotDiagnosticMXBean;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;

public final class HeapDumper {
    private static final HotSpotDiagnosticMXBean BEAN =
            ManagementFactory.getPlatformMXBean(HotSpotDiagnosticMXBean.class);

    /** live=true: сначала Full GC, в файл попадают только достижимые объекты, а для поиска утечки нужны именно они. */
    public static Path dump(Path dir, boolean live) throws Exception {
        Files.createDirectories(dir);
        Path file = dir.resolve("heap-" + Instant.now().toEpochMilli() + ".hprof");
        // Если файл уже существует, dumpHeap бросит IOException.
        BEAN.dumpHeap(file.toString(), live);
        return file;
    }
}
