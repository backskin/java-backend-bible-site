import java.lang.management.ManagementFactory;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Что JVM видит в контейнере и как процесс упирается в лимит памяти.
 * Запуск в Docker (образ eclipse-temurin:25-jdk, файл смонтирован в /lab):
 *   docker run --rm --memory=1g --cpus=2 -v $PWD/src:/lab eclipse-temurin:25-jdk java /lab/ContainerMem.java info
 *   docker run --rm --memory=512m -v $PWD/src:/lab eclipse-temurin:25-jdk java -Xmx450m /lab/ContainerMem.java fill 300 160 100
 * Аргументы режима fill: МБ живых массивов в куче, МБ direct-буферов, число спящих потоков.
 */
public class ContainerMem {

    static final List<Object> live = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        Runtime rt = Runtime.getRuntime();
        String gc = ManagementFactory.getGarbageCollectorMXBeans().get(0).getName();
        System.out.printf("CPU: %d, maxMemory (куча): %d МБ, сборщик: %s%n",
                rt.availableProcessors(), rt.maxMemory() >> 20, gc);
        System.out.println("лимит cgroup memory.max: " + read("/sys/fs/cgroup/memory.max"));
        if (args[0].equals("info")) return;

        int heapMb = Integer.parseInt(args[1]), directMb = Integer.parseInt(args[2]), threads = Integer.parseInt(args[3]);
        for (int i = 0; i < heapMb; i++) live.add(new byte[1 << 20]);          // реестр платежей в памяти
        report("после " + heapMb + " МБ в куче");
        for (int i = 0; i < threads; i++) {
            Thread t = new Thread(() -> { try { Thread.sleep(Long.MAX_VALUE); } catch (InterruptedException ignored) {} });
            t.setDaemon(true);
            t.start();
        }
        report("после " + threads + " потоков");
        for (int i = 0; i < directMb; i++) {
            ByteBuffer b = ByteBuffer.allocateDirect(1 << 20);
            for (int p = 0; p < b.capacity(); p += 4096) b.put(p, (byte) 1);   // касаемся страниц, чтобы они попали в RSS
            live.add(b);
            if (i % 40 == 39) report("direct " + (i + 1) + " МБ");
        }
        report("всё выделено");
        Thread.sleep(2000);
        System.out.println("процесс жив");
    }

    static void report(String stage) throws Exception {
        String rss = Files.readAllLines(Path.of("/proc/self/status")).stream()
                .filter(l -> l.startsWith("VmRSS")).findFirst().orElse("VmRSS: ?").replaceAll("\\s+", " ");
        long cg = Long.parseLong(read("/sys/fs/cgroup/memory.current").trim()) >> 20;
        System.out.printf("%-26s %s, cgroup memory.current: %d МБ%n", stage + ":", rss, cg);
    }

    static String read(String f) {
        try { return Files.readString(Path.of(f)).trim(); } catch (Exception e) { return "нет (" + e.getClass().getSimpleName() + ")"; }
    }
}
