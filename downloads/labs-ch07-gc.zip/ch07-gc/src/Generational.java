/**
 * Запуск (в IntelliJ: VM options и Program arguments):
 *   java -Xms512m -Xmx512m -XX:+UseG1GC -Xlog:gc,gc+age=debug Generational.java 5000
 *   java -Xms512m -Xmx512m -XX:+UseG1GC -Xlog:gc,gc+age=debug Generational.java 600000
 * Аргумент: сколько переводов одновременно «в полёте».
 */
public class Generational {

    record Transfer(long from, long to, String route) {}

    static volatile Object sink;

    public static void main(String[] args) {
        int inFlight = Integer.parseInt(args[0]);
        Transfer[] ring = new Transfer[inFlight];
        long deadline = System.nanoTime() + 6_000_000_000L;       // работаем 6 секунд
        long n = 0;
        while (System.nanoTime() < deadline) {
            long from = n, to = n + 1;
            ring[(int) (n % inFlight)] = new Transfer(from, to, from + "->" + to + "/" + n);
            n++;
        }
        sink = ring;
        System.out.println("создано переводов: " + n);
    }
}
