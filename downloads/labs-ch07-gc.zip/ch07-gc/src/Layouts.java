import org.openjdk.jol.info.ClassLayout;
import org.openjdk.jol.info.GraphLayout;
import java.util.HashMap;
import java.util.Map;

public class Layouts {
    public static void main(String[] args) {
        System.out.println(ClassLayout.parseClass(Integer.class).toPrintable());
        System.out.println(ClassLayout.parseInstance("hello").toPrintable());
        System.out.println(ClassLayout.parseInstance(new int[10]).toPrintable());

        Map<Integer, String> map = new HashMap<>();
        for (int i = 0; i < 1000; i++) map.put(i, "v" + i);
        // Весь граф: сама HashMap, её таблица, узлы Node, ключи, значения и их byte[]
        System.out.println(GraphLayout.parseInstance(map).toFootprint());
    }
}
