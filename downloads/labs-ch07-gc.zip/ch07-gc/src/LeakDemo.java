import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Запуск: java -Xmx1g LeakDemo.java  (JDK 21, зависимостей нет) */
public class LeakDemo {

    static final ThreadLocal<StringBuilder> BUF = ThreadLocal.withInitial(StringBuilder::new);

    static long usedMb() {
        System.gc(); System.gc();
        Runtime rt = Runtime.getRuntime();
        return (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
    }

    static void runTasks(ExecutorService pool, boolean remove) throws Exception {
        List<Future<?>> fs = new ArrayList<>();
        for (int t = 0; t < 8; t++) {
            fs.add(pool.submit(() -> {
                StringBuilder sb = BUF.get();
                for (int k = 0; k < 20_000_000; k++) sb.append('x');     // «большой JSON-ответ»
                if (remove) BUF.remove();
            }));
        }
        for (Future<?> f : fs) f.get();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("--- 1. ThreadLocal в пуле потоков");
        System.out.println("до запросов:                          " + usedMb() + " МБ");
        ExecutorService leaky = Executors.newFixedThreadPool(8);
        runTasks(leaky, false);
        System.out.println("без remove(), пул жив:                " + usedMb() + " МБ");
        leaky.shutdown();
        leaky.awaitTermination(10, java.util.concurrent.TimeUnit.SECONDS);
        System.out.println("без remove(), пул остановлен:         " + usedMb() + " МБ");
        ExecutorService clean = Executors.newFixedThreadPool(8);
        runTasks(clean, true);
        System.out.println("с remove() в конце задачи, пул жив:   " + usedMb() + " МБ");
        clean.shutdown();

        System.out.println("--- 2. изменяемый ключ HashMap");
        List<String> key = new ArrayList<>(List.of("client-42"));
        Map<List<String>, String> cache = new HashMap<>();
        cache.put(key, "лимит");
        key.add("810");                                              // изменили ключ после вставки
        System.out.println("get: " + cache.get(key) + ", remove: " + cache.remove(key) + ", size: " + cache.size());
    }
}
