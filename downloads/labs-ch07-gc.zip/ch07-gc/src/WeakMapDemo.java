import java.util.WeakHashMap;

public class WeakMapDemo {
    static class Key { final String name; Key(String n) { name = n; } }
    static class ValueHoldingKey { final Key key; ValueHoldingKey(Key k) { key = k; } }

    public static void main(String[] args) throws Exception {
        WeakHashMap<Key, Object> plain = new WeakHashMap<>();
        WeakHashMap<Key, ValueHoldingKey> leaking = new WeakHashMap<>();
        for (int i = 0; i < 1000; i++) {
            Key k1 = new Key("a" + i);
            plain.put(k1, "значение без ссылки на ключ");
            Key k2 = new Key("b" + i);
            leaking.put(k2, new ValueHoldingKey(k2));        // значение ссылается на свой ключ
        }
        System.gc();
        Thread.sleep(200);
        System.out.println("значение без ссылки на ключ: осталось " + plain.size() + " из 1000");
        System.out.println("значение со ссылкой на ключ: осталось " + leaking.size() + " из 1000");
        Key k3 = new Key("живой");
        plain.put(k3, "x");
        System.gc();
        System.out.println("запись с живым ключом сохраняется: " + plain.containsKey(k3));
        System.out.println("String-литерал как ключ не умирает: " + literalDemo());
    }

    static boolean literalDemo() {
        WeakHashMap<String, String> m = new WeakHashMap<>();
        m.put("литерал", "v");                                // литерал лежит в пуле строк и живёт всё время
        System.gc();
        return m.size() == 1;
    }
}
