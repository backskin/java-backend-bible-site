import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Запуск: java -Xms1g -Xmx1g -XX:NativeMemoryTracking=summary RssDemo.java
 * Нужен jcmd из того же JDK (он лежит в JAVA_HOME/bin).
 */
public class RssDemo {

    public static void main(String[] args) throws Exception {
        List<byte[]> heap = new ArrayList<>();
        for (int i = 0; i < 2400; i++) { byte[] b = new byte[256 * 1024]; java.util.Arrays.fill(b, (byte) 1); heap.add(b); }   // 600 МБ живых данных
        List<ByteBuffer> direct = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            ByteBuffer d = ByteBuffer.allocateDirect(1 << 20);
            while (d.hasRemaining()) d.put((byte) 1);                                                                       // трогаем страницы
            direct.add(d);
        }
        for (int i = 0; i < 200; i++) {
            Thread t = new Thread(() -> { try { Thread.sleep(60_000); } catch (InterruptedException ignored) { } });
            t.setDaemon(true);
            t.start();
        }
        long pid = ProcessHandle.current().pid();
        String jcmd = Path.of(System.getProperty("java.home"), "bin", "jcmd").toString();
        Process p = new ProcessBuilder(jcmd, String.valueOf(pid), "VM.native_memory", "summary").redirectErrorStream(true).start();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("Total:") || line.matches("-\s+(Java Heap|Class|Thread|Code|GC|Other|Symbol|Shared class space)\s.*")
                        || line.contains("Metaspace")) System.out.println(line);
            }
        }
        System.out.println("живых данных в куче: " + heap.size() / 4 + " МБ, direct-буферов: " + direct.size() + " МБ");
    }
}
