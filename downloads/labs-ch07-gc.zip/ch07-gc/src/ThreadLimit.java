import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/** Creates threads until the OS refuses; run in Docker with --pids-limit to see the message from os.hpp. */
public class ThreadLimit {
    public static void main(String[] args) throws Exception {
        CountDownLatch stop = new CountDownLatch(1);
        List<Thread> threads = new ArrayList<>();
        try {
            while (true) {
                Thread t = new Thread(() -> {
                    try { stop.await(); } catch (InterruptedException ignored) { }
                });
                t.start();
                threads.add(t);
            }
        } catch (Throwable e) {
            System.out.println("threads created: " + threads.size());
            System.out.println(e);
        } finally {
            stop.countDown();
        }
    }
}
