import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Утечка через кэш, ключом которого служит номер страницы запроса.
 * Сервис выгрузки реестра платежей кэширует разобранные строки реестра по ключу
 * "реестр + страница + размер страницы", а вытеснения у кэша нет.
 * Запуск: java -Xmx512m -Xlog:safepoint:file=out/safepoint.log RegistryLeak.java
 * Пока программа работает: jcmd <pid> GC.class_histogram, jcmd <pid> GC.heap_dump out/leak.hprof
 */
public class RegistryLeak {

    record PaymentLine(String account, long amountKopecks, String purpose) {}

    static final Map<String, List<PaymentLine>> PAGE_CACHE = new ConcurrentHashMap<>();

    static List<PaymentLine> page(String registry, int page, int size) {
        return PAGE_CACHE.computeIfAbsent(registry + "?page=" + page + "&size=" + size, k -> {
            List<PaymentLine> lines = new ArrayList<>(size);
            for (int i = 0; i < size; i++) {
                long n = (long) page * size + i;
                lines.add(new PaymentLine("40702810" + String.format("%012d", n), 10_000 + n,
                        "Оплата по договору " + n));
            }
            return lines;
        });
    }

    public static void main(String[] args) throws Exception {
        System.out.println("pid " + ProcessHandle.current().pid());
        long requests = 0;
        while (true) {
            int size = (requests % 3 == 0) ? 50 : 20;                    // клиенты просят разные размеры страниц
            page("REG-2026-11-03", (int) (requests % 100_000), size);
            requests++;
            if (requests % 2 == 0) Thread.sleep(1);                       // около 1 тыс. запросов в секунду
        }
    }
}
