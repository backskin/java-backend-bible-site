import java.util.Arrays;
import java.util.SplittableRandom;

/**
 * Сравнение сборщиков. Запуск (в IntelliJ: VM options), каждый раз по одной строке флагов:
 *   java -Xms2g -Xmx2g -XX:+UseSerialGC Latency.java
 *   java -Xms2g -Xmx2g -XX:+UseParallelGC Latency.java
 *   java -Xms2g -Xmx2g -XX:+UseG1GC Latency.java
 *   java -Xms2g -Xmx2g -XX:+UseZGC Latency.java          (на JDK 21 добавить -XX:+ZGenerational)
 *   java -Xms2g -Xmx2g -XX:+UseShenandoahGC -XX:ShenandoahGCMode=generational Latency.java   (JDK 25)
 *   java -Xms2g -Xmx2g -XX:+UseShenandoahGC Latency.java
 * Программа 15 секунд работает с кэшем из 6 млн записей и печатает число операций и задержки пачек по 100 операций.
 */
public class Latency {

    record Limit(long card, long dailyLimit, long usedKopecks) {}

    static final int CACHE = 6_000_000;
    static final int BATCH = 100;
    static volatile String sink;

    public static void main(String[] args) {
        Limit[] cache = new Limit[CACHE];
        for (int i = 0; i < CACHE; i++) cache[i] = new Limit(i, 100_000_00L, 0);

        SplittableRandom rnd = new SplittableRandom(42);
        long deadline = System.nanoTime() + 15_000_000_000L;
        long ops = 0;
        long[] batchNanos = new long[2_000_000];
        int batches = 0;
        while (System.nanoTime() < deadline && batches < batchNanos.length) {
            long t0 = System.nanoTime();
            for (int k = 0; k < BATCH; k++) {
                int idx = rnd.nextInt(CACHE);
                Limit l = cache[idx];
                sink = "card=" + l.card() + ",used=" + l.usedKopecks();       // мусор: строка запроса
                if ((ops & 63) == 0) cache[idx] = new Limit(l.card(), l.dailyLimit(), l.usedKopecks() + 100); // часть кэша переезжает в old
                ops++;
            }
            batchNanos[batches++] = System.nanoTime() - t0;
        }
        long[] sorted = Arrays.copyOf(batchNanos, batches);
        Arrays.sort(sorted);
        System.out.printf("операций: %d млн, p99 пачки: %.1f мкс, p99.99 пачки: %.1f мкс, максимум пачки: %.1f мс%n",
                ops / 1_000_000, sorted[(int) (batches * 0.99)] / 1000.0, sorted[(int) (batches * 0.9999)] / 1000.0,
                sorted[batches - 1] / 1_000_000.0);
        for (var gc : java.lang.management.ManagementFactory.getGarbageCollectorMXBeans())
            System.out.printf("  %s: сборок %d, время %d мс%n", gc.getName(), gc.getCollectionCount(), gc.getCollectionTime());
    }
}
