import groovy.lang.GroovyShell;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.util.ArrayList;
import java.util.List;

/**
 * Evaluates N scripts in fresh GroovyShell instances: every script is a new class in its own class loader.
 * Args: N [sleepMs [keep]]. With "keep" the script classes are retained in a list, so their loaders cannot be unloaded.
 */
public class GroovyMeta {
    public static void main(String[] args) throws Exception {
        int n = Integer.parseInt(args[0]);
        long sleep = args.length > 1 ? Long.parseLong(args[1]) : 0;
        List<Class<?>> keep = args.length > 2 ? new ArrayList<>() : null;
        System.out.println("pid " + ProcessHandle.current().pid() + (keep != null ? ", keeping script classes" : ""));
        Thread.sleep(sleep);   // time for jcmd VM.native_memory baseline
        long t0 = System.nanoTime();
        for (int i = 0; i < n; i++) {
            if (keep != null) {
                keep.add(new GroovyShell().parse("1+1").getClass());
            } else {
                new GroovyShell().evaluate("1+1");
            }
            if (i % 5000 == 0) {
                System.out.println("evaluated " + i + " in " + (System.nanoTime() - t0) / 1_000_000 + " ms");
            }
        }
        System.out.println("done " + n + (keep != null ? ", kept classes: " + keep.size() : ""));
        for (MemoryPoolMXBean pool : ManagementFactory.getMemoryPoolMXBeans()) {
            if (pool.getName().contains("Metaspace") || pool.getName().contains("Class")) {
                System.out.println(pool.getName() + ": used " + pool.getUsage().getUsed() / 1024 / 1024 + " MB, committed " + pool.getUsage().getCommitted() / 1024 / 1024 + " MB");
            }
        }
        Thread.sleep(sleep);   // time for jcmd VM.native_memory summary.diff
    }
}
