/** A long int-counted loop in a separate thread; with -XX:-UseCountedLoopSafepoints it has no safepoint poll. */
public class CountedLoop {
    static volatile long sink;

    public static void main(String[] args) throws Exception {
        Thread worker = new Thread(() -> {
            long sum = 0;
            for (int round = 0; round < 200; round++) {
                for (int i = 0; i < 2_000_000_000; i++) {
                    sum += (i * 31) ^ (sum >>> 7);   // loop-carried dependency: no vectorization, ~1 s per round
                }
                sink = sum;
            }
        }, "counted-loop");
        worker.setDaemon(true);
        worker.start();
        System.out.println("pid " + ProcessHandle.current().pid());
        worker.join();
    }
}
