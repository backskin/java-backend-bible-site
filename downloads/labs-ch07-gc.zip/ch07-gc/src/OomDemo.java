import java.lang.reflect.Proxy;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Запуск: java <флаги> OomDemo.java <режим>, где режим: heap | metaspace | direct | array | overhead
 *   heap       -Xmx256m
 *   metaspace  -XX:MaxMetaspaceSize=32m
 *   direct     -XX:MaxDirectMemorySize=64m
 *   array      (без флагов)
 *   overhead   -Xmx64m -XX:+UseParallelGC
 */
public class OomDemo {

    public interface Marker {}

    public static void main(String[] args) {
        try {
            switch (args[0]) {
                case "heap" -> {
                    List<byte[]> list = new ArrayList<>();
                    while (true) list.add(new byte[1 << 20]);
                }
                case "metaspace" -> {
                    List<Object> keep = new ArrayList<>();
                    while (true) {
                        ClassLoader fresh = new ClassLoader(OomDemo.class.getClassLoader()) {};
                        keep.add(Proxy.newProxyInstance(fresh, new Class<?>[]{Marker.class}, (p, m, a) -> null));
                    }
                }
                case "direct" -> {
                    List<ByteBuffer> keep = new ArrayList<>();
                    while (true) keep.add(ByteBuffer.allocateDirect(1 << 20));
                }
                case "array" -> {
                    int[] a = new int[Integer.MAX_VALUE];
                    System.out.println("создан " + a.length);
                }
                case "overhead" -> {
                    Map<Integer, String> m = new HashMap<>();
                    for (int i = 0; ; i++) m.put(i, "value-" + i);
                }
                default -> System.out.println("неизвестный режим");
            }
        } catch (OutOfMemoryError e) {
            System.out.println(args[0] + ": OutOfMemoryError: " + e.getMessage());
        }
    }
}
