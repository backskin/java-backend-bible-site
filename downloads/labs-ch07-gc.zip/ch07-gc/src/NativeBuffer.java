import java.lang.ref.Cleaner;
import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;

public final class NativeBuffer implements AutoCloseable {
    private static final Cleaner CLEANER = Cleaner.create();

    // Всё, что надо освободить, лежит в статическом вложенном классе:
    // он не держит ссылку на NativeBuffer, иначе NativeBuffer никогда не собрали бы.
    private static final class State implements Runnable {
        private final Arena arena;
        State(Arena arena) { this.arena = arena; }
        @Override public void run() { arena.close(); }
    }

    private final State state;
    private final Cleaner.Cleanable cleanable;
    final MemorySegment segment;

    public NativeBuffer(long bytes) {
        Arena arena = Arena.ofShared();
        this.segment = arena.allocate(bytes);
        this.state = new State(arena);
        this.cleanable = CLEANER.register(this, state);
    }

    @Override public void close() { cleanable.clean(); } // явный вызов идемпотентен: второй раз действие не выполнится
}
