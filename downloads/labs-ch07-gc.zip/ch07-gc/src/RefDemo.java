import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.lang.ref.Cleaner;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Запуск на JDK 21 (FFM API там ещё в preview):
 *   java --enable-preview --source 21 -Xmx256m RefDemo.java
 * В IntelliJ: Project SDK 21, language level 21 (Preview), в VM options -Xmx256m.
 */
public class RefDemo {

    record Rate(String pair, double value) {}

    static final class NativeBuffer implements AutoCloseable {
        private static final Cleaner CLEANER = Cleaner.create();

        // состояние для очистки лежит в статическом классе, который не ссылается на NativeBuffer
        private static final class State implements Runnable {
            private final Arena arena;
            State(Arena arena) { this.arena = arena; }
            @Override public void run() { System.out.println("  [cleaner] нативная память освобождена"); arena.close(); }
        }

        private final Cleaner.Cleanable cleanable;
        NativeBuffer(long bytes) {
            Arena arena = Arena.ofShared();
            MemorySegment segment = arena.allocate(bytes);
            this.cleanable = CLEANER.register(this, new State(arena));
        }
        @Override public void close() { cleanable.clean(); }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("--- 1. WeakReference");
        Rate rate = new Rate("USD/RUB", 90.5);
        WeakReference<Rate> weak = new WeakReference<>(rate);
        System.gc();
        System.out.println("пока есть сильная ссылка:  " + (weak.get() != null));
        rate = null;
        System.gc();
        System.out.println("после rate = null и GC:    " + (weak.get() != null));

        System.out.println("--- 2. PhantomReference");
        ReferenceQueue<Rate> queue = new ReferenceQueue<>();
        Rate r2 = new Rate("EUR/RUB", 98.1);
        PhantomReference<Rate> phantom = new PhantomReference<>(r2, queue);
        System.out.println("phantom.get() при живом объекте: " + phantom.get());
        r2 = null;
        System.gc();
        System.out.println("ссылка попала в очередь:          " + (queue.remove(2000) == phantom));

        System.out.println("--- 3. SoftReference: сильные массивы вытесняют soft");
        List<SoftReference<byte[]>> softs = new ArrayList<>();
        for (int i = 0; i < 40; i++) softs.add(new SoftReference<>(new byte[1_000_000]));
        System.gc(); System.gc();
        System.out.println("после двух GC живо soft:           " + softs.stream().filter(s -> s.get() != null).count() + " из 40");
        List<byte[]> strong = new ArrayList<>();
        try {
            while (true) strong.add(new byte[1_000_000]);
        } catch (OutOfMemoryError e) {
            int mb = strong.size();
            strong.clear();                 // сначала освобождаем память, чтобы было чем считать
            long alive = softs.stream().filter(s -> s.get() != null).count();
            System.out.println("OOM после " + mb + " МБ сильных данных, soft живо: " + alive);
        }

        System.out.println("--- 4. Cleaner: close() и забытая обёртка");
        try (NativeBuffer b = new NativeBuffer(1024)) {
            System.out.println("  работаем с буфером");
        }
        new NativeBuffer(1024);          // ссылку потеряли, close() не вызван
        System.gc();
        Thread.sleep(500);               // Cleaner работает в фоновом потоке
    }
}
