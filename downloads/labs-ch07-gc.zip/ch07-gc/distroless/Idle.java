/** Keeps the JVM alive so a debug container can attach with jcmd. */
public class Idle {
    public static void main(String[] args) throws Exception {
        java.util.List<byte[]> keep = new java.util.ArrayList<>();
        for (int i = 0; i < 10; i++) keep.add(new byte[1024 * 1024]);
        System.out.println("idle, pid " + ProcessHandle.current().pid());
        Thread.sleep(Long.MAX_VALUE);
    }
}
