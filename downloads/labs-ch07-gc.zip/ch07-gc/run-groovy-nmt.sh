#!/usr/bin/env bash
# GroovyMeta: 50 000 GroovyShell scripts, NMT baseline/diff for the Class category, then the same with MaxMetaspaceSize=256m.
cd "$(dirname "$0")"
J21=~/.jdks/temurin-21.0.10/bin
G=$(cygpath -w ~/.m2/repository/org/apache/groovy/groovy/4.0.28/groovy-4.0.28.jar)
CP="out;$G"
echo "== java -XX:NativeMemoryTracking=summary -cp groovy-4.0.28.jar GroovyMeta 50000 (Temurin 21.0.10, Windows x64)"
"$J21/java" -XX:NativeMemoryTracking=summary -cp "$CP" GroovyMeta 50000 180000 > gm.out 2>&1 &
sleep 5
pid=$(grep -m1 '^pid' gm.out | awk '{print $2}')
echo "-- jcmd $pid VM.native_memory baseline: $("$J21/jcmd" "$pid" VM.native_memory baseline | tail -1)"
until grep -q '^done' gm.out; do sleep 5; done
echo "-- app output:"
grep -E "evaluated|done" gm.out | tail -3
echo "-- jcmd VM.native_memory summary.diff, category Class:"
"$J21/jcmd" "$pid" VM.native_memory summary.diff | grep -A4 "^-\s*Class"
taskkill //F //PID "$pid" > /dev/null 2>&1
echo
echo "== java -XX:MaxMetaspaceSize=256m -cp groovy-4.0.28.jar GroovyMeta 50000"
"$J21/java" -XX:MaxMetaspaceSize=256m -cp "$CP" GroovyMeta 50000 2>&1 | grep -E "evaluated|OutOfMemoryError|done" | tail -4
rm -f gm.out
