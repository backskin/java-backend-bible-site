#!/usr/bin/env bash
# GroovyMeta with -XX:MaxMetaspaceSize=256m: loaders unloaded by GC (no OOM) versus script classes retained ("keep", OOM Metaspace).
cd "$(dirname "$0")"
J21=~/.jdks/temurin-21.0.10/bin
G=$(cygpath -w ~/.m2/repository/org/apache/groovy/groovy/4.0.28/groovy-4.0.28.jar)
CP="out;$G"
echo
echo "== java -XX:MaxMetaspaceSize=256m -Xlog:gc,class+unload -cp groovy-4.0.28.jar GroovyMeta 50000 (script classes not retained)"
"$J21/java" -XX:MaxMetaspaceSize=256m -Xlog:gc,class+unload -cp "$CP" GroovyMeta 50000 > gk.out 2>&1
echo "-- lines 'unloading class': $(grep -c 'unloading class' gk.out)"
grep -E "Pause|OutOfMemoryError|^done" gk.out | tail -4
echo
echo "== java -XX:MaxMetaspaceSize=256m -Xlog:gc -cp groovy-4.0.28.jar GroovyMeta 50000 0 keep (script classes retained in a list)"
timeout 900 "$J21/java" -XX:MaxMetaspaceSize=256m -Xlog:gc -cp "$CP" GroovyMeta 50000 0 keep > gk.out 2>&1
grep -E "evaluated|OutOfMemoryError|^done|Metaspace" gk.out | tail -6
rm -f gk.out
