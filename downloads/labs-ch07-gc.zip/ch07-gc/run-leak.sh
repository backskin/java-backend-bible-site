#!/bin/bash
# Утечка в кэше страниц реестра: две гистограммы с интервалом, дамп кучи, thread dump и журнал safepoint. JDK 25.0.5.
cd "$(dirname "$0")"
B=~/.jdks/jdk-25.0.5+8/bin
$B/java -Xmx1g -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=out/oom.hprof -Xlog:gc:file=out/leak-gc.log -Xlog:safepoint:file=out/safepoint.log src/RegistryLeak.java > out/leak.out 2>&1 &
sleep 6
PID=$(head -1 out/leak.out | awk '{print $2}')
{
echo "### GC.class_histogram через 6 с (первые 12 строк)"; $B/jcmd $PID GC.class_histogram | head -14
sleep 10
echo "### GC.class_histogram через 16 с"; $B/jcmd $PID GC.class_histogram | head -14
echo "### GC.heap_info"; $B/jcmd $PID GC.heap_info
echo "### GC.heap_dump"; S=$(date +%s%N); $B/jcmd $PID GC.heap_dump $PWD/out/leak.hprof; E=$(date +%s%N); echo "время jcmd GC.heap_dump: $(( (E-S)/1000000 )) мс"; ls -la out/leak.hprof
echo "### Thread.print (первые 3 строки)"; $B/jcmd $PID Thread.print | head -3
} > s09-leak-histogram.txt 2>&1
kill $PID
