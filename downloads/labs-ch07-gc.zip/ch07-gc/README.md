# Память и сборка мусора: раскладка объектов, TLAB, сборщики, контейнеры, утечки, Metaspace, safepoint

Стенд к главе 07. Программы в `src/` без зависимостей: `Layouts` (размеры объектов, с JOL), `TlabBench`, `Generational` и `Latency` (поколения и сравнение Serial, Parallel, G1, ZGC, Shenandoah), `ContainerMem`, `RssDemo`, `ThreadLimit` (ограничения контейнера), `RegistryLeak`, `LeakDemo`, `WeakMapDemo`, `RefDemo` (утечки и ссылки), `OomDemo`, `Humongous`, `CountedLoop` (safepoint в счетном цикле), `GroovyMeta` (Metaspace при компиляции скриптов). `distroless/` - образ без shell и отладка через `--pid=container`. Скрипты `run-*.sh` собирают серии запусков с нужными флагами. Выводы автора - `sNN-*.txt`, журналы GC - в `out/` после запуска.

## Что нужно

- Temurin JDK 21.0.10 и 25.0.5 в `~/.jdks` (пути в скриптах), bash (Git Bash на Windows), 2 ГБ свободной памяти для `-Xmx2g`.
- Docker для `ContainerMem`, `ThreadLimit`, `distroless/` и `run-safepoint-docker.sh`; Groovy 4.0.28 в `~/.m2` для `run-groovy-*.sh`; JOL 0.17 (`jol-cli`) для `Layouts`.

## Запуск

Серия к разделам 3–5 на JDK 25 (TLAB, поколения, сборщики; занимает несколько минут):

```bash
bash run-jdk25.sh
```

Утечка с гистограммами и дампом кучи:

```bash
bash run-leak.sh
```

Одну программу - из исходника с флагами из шапки соответствующего `*.txt`, например `java -Xmx256m src/RefDemo.java`. В IDEA на каждую программу есть конфигурация `java src/<Класс>.java` (флаги JVM добавьте в нее по файлу вывода) и на каждый скрипт - конфигурация Shell Script.

## Что должно получиться

Абсолютные времена и p99 пауз зависят от машины (у автора 16 логических процессоров, Windows 10), соотношения между сборщиками сохраняются. Результаты в контейнерах сняты в Docker 29.6.1 с cgroup v2.
