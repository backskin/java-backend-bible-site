package dev.team.app;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Приложение-потребитель стартера: в своём пакете, чтобы сканирование не подхватило конфигурации опыта. */
@SpringBootApplication
public class LimitsApp { }
