package dev.team.lab;

import com.sun.net.httpserver.HttpServer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.tundra.limits.autoconfigure.LimitsClientAutoConfiguration;
import ru.tundra.limits.autoconfigure.LimitsHealthAutoConfiguration;
import ru.tundra.limits.client.LimitsClient;

import java.net.InetSocketAddress;
import java.net.http.HttpClient;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;

/** Опыт разд. 4: режимы стартера клиента лимитов через ApplicationContextRunner, индикатор здоровья, FailureAnalyzer, метаданные. */
public class StarterLab {
    static final ApplicationContextRunner RUNNER = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(LimitsClientAutoConfiguration.class, LimitsHealthAutoConfiguration.class))
            .withPropertyValues("tundra.limits.base-url=http://localhost:18990");

    @Configuration(proxyBeanMethods = false)
    static class OwnClient {
        static final LimitsClient INSTANCE = new LimitsClient(HttpClient.newHttpClient(), "http://limits.mock", Duration.ofSeconds(1), 1);
        @Bean LimitsClient limitsClient() { return INSTANCE; }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== пять режимов стартера");
        RUNNER.run(c -> {
            assertThat(c).hasSingleBean(LimitsClient.class);
            System.out.println("1. по умолчанию: клиент есть, попыток " + c.getBean(LimitsClient.class).maxAttempts());
        });
        RUNNER.withUserConfiguration(OwnClient.class).run(c -> {
            assertThat(c).hasSingleBean(LimitsClient.class).getBean(LimitsClient.class).isSameAs(OwnClient.INSTANCE);
            System.out.println("2. свой бин приложения: стартер отступил, клиент " + c.getBean(LimitsClient.class).baseUrl());
        });
        RUNNER.withPropertyValues("tundra.limits.enabled=false").run(c -> {
            assertThat(c).doesNotHaveBean(LimitsClient.class);
            System.out.println("3. tundra.limits.enabled=false: клиента нет, индикатора нет = " + !c.containsBean("limitsHealthIndicator"));
        });
        RUNNER.withClassLoader(new FilteredClassLoader(LimitsClient.class)).run(c -> {
            assertThat(c).doesNotHaveBean("limitsClient");
            System.out.println("4. библиотеки нет в classpath: клиента нет, контекст поднялся = " + (c.getStartupFailure() == null));
        });
        RUNNER.withPropertyValues("tundra.limits.max-attempts=99").run(c -> {
            assertThat(c).hasFailed();
            System.out.println("5. max-attempts=99: контекст не поднялся");
            Throwable t = c.getStartupFailure();
            while (t.getCause() != null) t = t.getCause();
            for (String line : t.getMessage().split("\n")) if (line.contains("maxAttempts") || line.contains("max-attempts") || line.contains("must be")) System.out.println("   " + line.trim());
        });
        new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(LimitsClientAutoConfiguration.class)).run(c -> {
            System.out.println("6. base-url не задан: контекст поднялся = " + (c.getStartupFailure() == null));
            Throwable t = c.getStartupFailure();
            while (t != null && t.getCause() != null) t = t.getCause();
            if (t != null) for (String line : t.getMessage().split("\n")) if (line.contains("baseUrl") || line.contains("blank")) System.out.println("   " + line.trim());
        });

        System.out.println("== индикатор здоровья");
        HttpServer limits = HttpServer.create(new InetSocketAddress("localhost", 18990), 0);
        limits.createContext("/health", ex -> { ex.sendResponseHeaders(200, -1); ex.close(); });
        limits.start();
        RUNNER.run(c -> System.out.println("7. сервис лимитов отвечает: " + ((HealthIndicator) c.getBean("limitsHealthIndicator")).health()));
        limits.stop(0);
        RUNNER.run(c -> System.out.println("8. сервис лимитов не отвечает: " + ((HealthIndicator) c.getBean("limitsHealthIndicator")).health()));
        RUNNER.withPropertyValues("management.health.limits.enabled=false").run(c ->
                System.out.println("9. management.health.limits.enabled=false: клиент есть = " + c.containsBean("limitsClient")
                        + ", индикатор есть = " + c.containsBean("limitsHealthIndicator")));

        System.out.println("== FailureAnalyzer при настоящем старте");
        SpringApplication app = new SpringApplication(dev.team.app.LimitsApp.class);
        app.setWebApplicationType(WebApplicationType.NONE);
        try {
            app.run("--tundra.limits.base-url=http://limits.tundra.local", "--tundra.limits.require-tls=true", "--spring.main.banner-mode=off");
        } catch (Exception e) {
            System.out.println("10. run() бросил " + e.getClass().getSimpleName());
        }

        System.out.println("== метаданные для IDE");
        String json = Files.readString(Path.of("target/classes/META-INF/spring-configuration-metadata.json"));
        for (String line : json.split("\n"))
            if (line.contains("\"name\"") || line.contains("\"defaultValue\"") || line.contains("\"description\"")) System.out.println("   " + line.trim());
    }
}
