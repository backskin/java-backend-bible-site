package ru.tundra.limits.autoconfigure;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import ru.tundra.limits.client.LimitsClient;

import java.net.http.HttpClient;

@AutoConfiguration
@ConditionalOnClass(LimitsClient.class)
@ConditionalOnProperty(prefix = "tundra.limits", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(LimitsClientProperties.class)
public class LimitsClientAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    LimitsClient limitsClient(LimitsClientProperties props) {
        if (props.requireTls() && !props.baseUrl().startsWith("https://"))
            throw new LimitsConfigurationException(props.baseUrl());
        HttpClient http = HttpClient.newBuilder().connectTimeout(props.connectTimeout()).build();
        return new LimitsClient(http, props.baseUrl(), props.readTimeout(), props.maxAttempts());
    }
}
