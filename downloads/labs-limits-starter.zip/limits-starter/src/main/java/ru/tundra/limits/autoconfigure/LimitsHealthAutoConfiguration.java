package ru.tundra.limits.autoconfigure;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.health.autoconfigure.contributor.ConditionalOnEnabledHealthIndicator;
import org.springframework.boot.health.contributor.AbstractHealthIndicator;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.context.annotation.Bean;
import ru.tundra.limits.client.LimitsClient;

/** Индикатор здоровья отдельно от клиента: его можно выключить, не трогая клиент. */
@AutoConfiguration(after = LimitsClientAutoConfiguration.class)
@ConditionalOnClass({ LimitsClient.class, HealthIndicator.class })
@ConditionalOnBean(LimitsClient.class)
@ConditionalOnEnabledHealthIndicator("limits")
public class LimitsHealthAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(name = "limitsHealthIndicator")
    HealthIndicator limitsHealthIndicator(LimitsClient client) {
        return new AbstractHealthIndicator() {
            @Override
            protected void doHealthCheck(Health.Builder b) {
                (client.ping() ? b.up() : b.down()).withDetail("baseUrl", client.baseUrl());
            }
        };
    }
}
