package ru.tundra.limits.autoconfigure;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;

/**
 * Настройки клиента сервиса лимитов.
 *
 * @param baseUrl        Base URL of the limits service.
 * @param connectTimeout Timeout for establishing a connection to the limits service.
 * @param readTimeout    Timeout for reading a response from the limits service.
 * @param maxAttempts    Maximum number of attempts, including the initial one.
 * @param requireTls     Whether only HTTPS addresses are allowed.
 * @param enabled        Whether the limits client is enabled.
 */
@Validated
@ConfigurationProperties("tundra.limits")
public record LimitsClientProperties(
        @NotBlank String baseUrl,
        @DefaultValue("1s") Duration connectTimeout,
        @DefaultValue("3s") Duration readTimeout,
        @DefaultValue("3") @Min(1) @Max(10) int maxAttempts,
        @DefaultValue("false") boolean requireTls,
        @DefaultValue("true") boolean enabled) {
}
