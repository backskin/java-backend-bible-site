package ru.tundra.limits.autoconfigure;

import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
import org.springframework.boot.diagnostics.FailureAnalysis;

/** Превращает исключение старта в описание проблемы и действие для человека. */
public class LimitsFailureAnalyzer extends AbstractFailureAnalyzer<LimitsConfigurationException> {
    @Override
    protected FailureAnalysis analyze(Throwable rootFailure, LimitsConfigurationException cause) {
        return new FailureAnalysis(
                "Адрес сервиса лимитов " + cause.baseUrl + " не использует HTTPS, а tundra.limits.require-tls=true.",
                "Укажите tundra.limits.base-url с https:// или переменную окружения TUNDRA_LIMITS_BASEURL.",
                cause);
    }
}
