package ru.tundra.limits.client;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Клиент общего сервиса лимитов Тундра-Банка: проверяет, укладывается ли операция в лимит клиента. */
public class LimitsClient {
    private final HttpClient http;
    private final String baseUrl;
    private final Duration readTimeout;
    private final int maxAttempts;

    public LimitsClient(HttpClient http, String baseUrl, Duration readTimeout, int maxAttempts) {
        this.http = http; this.baseUrl = baseUrl; this.readTimeout = readTimeout; this.maxAttempts = maxAttempts;
    }

    /** Отвечает ли сервис лимитов: GET {baseUrl}/health. */
    public boolean ping() {
        try {
            var req = HttpRequest.newBuilder(URI.create(baseUrl + "/health")).timeout(readTimeout).GET().build();
            return http.send(req, HttpResponse.BodyHandlers.discarding()).statusCode() == 200;
        } catch (Exception e) {
            return false;
        }
    }

    public String baseUrl() { return baseUrl; }
    public int maxAttempts() { return maxAttempts; }
}
