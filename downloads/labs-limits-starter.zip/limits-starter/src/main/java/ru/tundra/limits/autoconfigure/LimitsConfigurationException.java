package ru.tundra.limits.autoconfigure;

/** Адрес сервиса лимитов не годится для боевого окружения. */
public class LimitsConfigurationException extends RuntimeException {
    final String baseUrl;

    LimitsConfigurationException(String baseUrl) {
        super("адрес сервиса лимитов без TLS: " + baseUrl);
        this.baseUrl = baseUrl;
    }
}
