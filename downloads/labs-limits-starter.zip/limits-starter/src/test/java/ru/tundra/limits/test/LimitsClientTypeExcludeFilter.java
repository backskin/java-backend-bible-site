package ru.tundra.limits.test;

import org.springframework.boot.context.TypeExcludeFilter;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;

/** Слайсу клиента лимитов компоненты приложения не нужны: сканирование не пропускает ни одного. */
public class LimitsClientTypeExcludeFilter extends TypeExcludeFilter {
    @Override
    public boolean match(MetadataReader reader, MetadataReaderFactory factory) { return true; }

    @Override
    public boolean equals(Object o) { return o != null && o.getClass() == getClass(); }

    @Override
    public int hashCode() { return getClass().hashCode(); }
}
