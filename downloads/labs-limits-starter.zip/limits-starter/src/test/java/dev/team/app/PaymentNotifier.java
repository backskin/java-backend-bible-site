package dev.team.app;

import org.springframework.stereotype.Component;

/** Компонент приложения-потребителя: слайс клиента лимитов не должен его поднимать. */
@Component
class PaymentNotifier { }
