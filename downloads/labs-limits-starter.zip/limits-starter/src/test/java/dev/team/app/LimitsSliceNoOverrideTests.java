package dev.team.app;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.TestPropertySource;
import ru.tundra.limits.client.LimitsClient;
import ru.tundra.limits.test.LimitsClientNoOverrideTest;

/** Тот же слайс без @OverrideAutoConfiguration(enabled = false). */
@LimitsClientNoOverrideTest
@TestPropertySource(properties = "tundra.limits.base-url=https://limits.test")
class LimitsSliceNoOverrideTests {

    @Autowired ApplicationContext ctx;

    @Test
    void fullAutoConfiguration() {
        System.out.println("   ► без @OverrideAutoConfiguration(enabled = false): бинов " + ctx.getBeanDefinitionCount()
                + "; LimitsClient=" + ctx.getBeanNamesForType(LimitsClient.class).length
                + ", PaymentNotifier=" + ctx.getBeanNamesForType(PaymentNotifier.class).length
                + ", TaskExecutor=" + ctx.getBeanNamesForType(org.springframework.core.task.TaskExecutor.class).length);
    }
}
