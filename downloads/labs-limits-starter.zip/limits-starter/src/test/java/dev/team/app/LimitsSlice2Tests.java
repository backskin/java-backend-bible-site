package dev.team.app;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.TestPropertySource;
import ru.tundra.limits.client.LimitsClient;
import ru.tundra.limits.test.LimitsClientTest;

/** Свой слайс @LimitsClientTest: клиент лимитов есть, компонентов приложения и чужих автоконфигураций нет. */
@LimitsClientTest
@TestPropertySource(properties = "tundra.limits.base-url=https://limits.test")
class LimitsSlice2Tests {

    @Autowired ApplicationContext ctx;

    @Test
    void sameSliceAgain() {
        System.out.println("   ► второй класс @LimitsClientTest: бинов " + ctx.getBeanDefinitionCount()
                + "; LimitsClient=" + ctx.getBeanNamesForType(LimitsClient.class).length
                + ", PaymentNotifier=" + ctx.getBeanNamesForType(PaymentNotifier.class).length
                + ", TaskExecutor=" + ctx.getBeanNamesForType(org.springframework.core.task.TaskExecutor.class).length
                + ", адрес клиента " + ctx.getBean(LimitsClient.class).baseUrl());
    }
}
