# Свой стартер Spring Boot 4.1: автоконфигурация клиента лимитов, метаданные свойств, индикатор здоровья, свой тестовый слайс

Стенд к главе 10, раздел о стартерах. Библиотека `limits-spring-boot` без родителя Boot (`spring-boot-dependencies` как BOM): автоконфигурация `LimitsClient` с условиями, `@ConfigurationProperties` с метаданными от `spring-boot-configuration-processor`, индикатор здоровья на классах `spring-boot-health` Boot 4, регистрация в `AutoConfiguration.imports`. `StarterLab` проверяет стартер в девяти режимах (по умолчанию, свой бин приложения, `enabled=false`, библиотеки нет в classpath, недопустимое `max-attempts`, не задан `base-url`, сервис лимитов отвечает и не отвечает, индикатор выключен); тесты `LimitsSlice*` показывают свой слайс `@LimitsClientTest` с `@OverrideAutoConfiguration(enabled = false)` и без. Выводы автора - `s10-starter.txt`, `s10-slice.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile exec:java -Dexec.mainClass=dev.team.lab.StarterLab
```

Слайс: `mvn -q test -Dtest='LimitsSlice*'`. В IDEA есть конфигурации `StarterLab` и `mvn test`.

## Что должно получиться

Девять строк с наличием клиента и индикатора; без `@OverrideAutoConfiguration(enabled = false)` в слайс попадают 72 бина, включая `TaskExecutor`, с `@LimitsClientTest` - 19. Фильтр исключения типов без `equals` и `hashCode` ломает кэш контекстов: `TypeExcludeFilter … has not implemented hashCode`.
