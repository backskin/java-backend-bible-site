// JDKS: 25
// OUT: s9-transfer-outcomes
// Результат перевода как sealed-иерархия: сервис и «контроллер» обрабатывают его исчерпывающим switch без исключений.
// Плюс перечисление как разрешённый подтип sealed-интерфейса: полнота switch работает и для такой смеси.
import java.math.BigDecimal;
import java.time.Instant;

public class TransferOutcomes {
    record TransferCommand(String id, String from, String to, BigDecimal amount) {}

    sealed interface LimitCheck permits LimitCheck.Ok, LimitCheck.Exceeded, LimitCheck.Unavailable {
        record Ok() implements LimitCheck {}
        record Exceeded(BigDecimal limit) implements LimitCheck {}
        record Unavailable(String reason) implements LimitCheck {}
    }

    sealed interface TransferOutcome permits Completed, Rejected, Deferred {}
    record Completed(String transactionId, BigDecimal debited) implements TransferOutcome {}
    record Rejected(String code, String detail) implements TransferOutcome {}
    record Deferred(String transactionId, Instant retryAt) implements TransferOutcome {}

    record HttpReply(int status, String body) {}

    static LimitCheck check(TransferCommand cmd) {
        if (cmd.amount().compareTo(new BigDecimal("100000")) > 0) return new LimitCheck.Exceeded(new BigDecimal("100000"));
        if (cmd.to().startsWith("000")) return new LimitCheck.Unavailable("антифрод не ответил");
        return new LimitCheck.Ok();
    }

    static TransferOutcome transfer(TransferCommand cmd, Instant now) {
        return switch (check(cmd)) {
            case LimitCheck.Ok _ -> new Completed("T-" + cmd.id(), cmd.amount());
            case LimitCheck.Exceeded(var limit) -> new Rejected("LIMIT", "limit " + limit);
            case LimitCheck.Unavailable _ -> new Deferred(cmd.id(), now.plusSeconds(30));
        };
    }

    static HttpReply toResponse(TransferOutcome outcome) {
        return switch (outcome) {
            case Completed c -> new HttpReply(200, c.transactionId() + " " + c.debited());
            case Rejected(var code, var detail) -> new HttpReply(422, code + ": " + detail);
            case Deferred d -> new HttpReply(202, "Retry-After " + d.retryAt().getEpochSecond());
        };
    }

    // Перечисление как подтип sealed-интерфейса вместе с записью.
    sealed interface Channel permits StandardChannel, PartnerChannel {}
    enum StandardChannel implements Channel { CARD, SBP }
    record PartnerChannel(String partnerId) implements Channel {}

    static String fee(Channel c) {
        return switch (c) {
            case StandardChannel.CARD -> "1.5%";
            case StandardChannel.SBP -> "0%";
            case PartnerChannel(var id) -> "по договору " + id;
        };
    }

    public static void main(String[] args) {
        var now = Instant.parse("2026-11-02T10:00:00Z");
        System.out.println(toResponse(transfer(new TransferCommand("1", "40817", "40702", new BigDecimal("1500.00")), now)));
        System.out.println(toResponse(transfer(new TransferCommand("2", "40817", "40702", new BigDecimal("250000.00")), now)));
        System.out.println(toResponse(transfer(new TransferCommand("3", "40817", "00099", new BigDecimal("10.00")), now)));
        System.out.println(fee(StandardChannel.CARD) + " | " + fee(StandardChannel.SBP) + " | " + fee(new PartnerChannel("P-7")));
    }
}
