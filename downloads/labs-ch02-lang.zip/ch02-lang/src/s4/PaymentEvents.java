// OUT: s4-payment-events
// JDKS: 25
import java.math.BigDecimal;
import java.time.Instant;

public class PaymentEvents {
    enum RefundReason { CUSTOMER, CHARGEBACK }
    enum Side { HOLD, DEBIT, CREDIT }
    enum Reconciliation { MATCHED, HOLD_WITHOUT_CAPTURE, UNEXPECTED }
    record LedgerRow(String accountId, BigDecimal amount, Side side, Instant at) {}

    sealed interface PaymentEvent {
        Instant at();
        BigDecimal amount();
    }
    record Authorized(String authCode, BigDecimal amount, Instant at) implements PaymentEvent {}
    record Captured(String authCode, BigDecimal amount, Instant at) implements PaymentEvent {}
    record Refunded(String refundId, BigDecimal amount, Instant at, RefundReason reason) implements PaymentEvent {}

    static LedgerRow toLedgerRow(String accountId, PaymentEvent e) {
        return switch (e) {
            case Authorized a -> new LedgerRow(accountId, a.amount(), Side.HOLD, a.at());
            case Captured c -> new LedgerRow(accountId, c.amount(), Side.DEBIT, c.at());
            case Refunded r -> new LedgerRow(accountId, r.amount(), Side.CREDIT, r.at());
        };
    }

    static String metricName(PaymentEvent e) {
        return switch (e) {
            case Authorized _ -> "payment.authorized";
            case Captured _ -> "payment.captured";
            case Refunded(_, _, _, RefundReason reason) when reason == RefundReason.CHARGEBACK -> "payment.chargeback";
            case Refunded _ -> "payment.refunded";
        };
    }

    // Сверка двух событий: в модели Visitor понадобилась бы двойная диспетчеризация.
    static Reconciliation reconcile(PaymentEvent left, PaymentEvent right) {
        return switch (left) {
            case Authorized(var code, var amt, _) when right instanceof Captured c
                    && c.authCode().equals(code) && c.amount().equals(amt) -> Reconciliation.MATCHED;
            case Authorized _ -> Reconciliation.HOLD_WITHOUT_CAPTURE;
            default -> Reconciliation.UNEXPECTED;
        };
    }

    public static void main(String[] args) {
        var now = Instant.parse("2026-11-02T10:00:00Z");
        var auth = new Authorized("A1", new BigDecimal("150.00"), now);
        var cap = new Captured("A1", new BigDecimal("150.00"), now.plusSeconds(60));
        var refund = new Refunded("R1", new BigDecimal("150.00"), now.plusSeconds(3600), RefundReason.CHARGEBACK);
        System.out.println(toLedgerRow("40817", cap));
        System.out.println(metricName(refund));
        System.out.println(reconcile(auth, cap) + " " + reconcile(auth, refund) + " " + reconcile(cap, auth));
    }
}
