// OUT: s4-switch-patterns
// Паттерны в switch: null, охранные условия, record patterns, MatchException.
import java.math.BigDecimal;

public class SwitchPatterns {
    sealed interface PaymentResult permits Approved, Declined, Pending {}
    record Approved(String authCode, BigDecimal amount) implements PaymentResult {}
    record Declined(String reason, int code) implements PaymentResult {}
    record Pending(String acsUrl) implements PaymentResult {}

    static String describe(PaymentResult r) {
        return switch (r) {
            case null -> "нет ответа";
            case Approved(var code, var amount) when amount.signum() == 0 -> "проверка карты, код " + code;
            case Approved(var code, var amount) -> "списано " + amount + ", код " + code;
            case Declined(var reason, var code) when code == 51 -> "недостаточно средств";
            case Declined d -> "отказ: " + d.reason();
            case Pending p -> "ждём 3-D Secure: " + p.acsUrl();
        };
    }

    record Box<T>(T contents) {}
    record Brittle(String id) {
        public String id() { throw new IllegalStateException("accessor failed"); }
    }

    public static void main(String[] args) {
        System.out.println(describe(null));
        System.out.println(describe(new Approved("A1", BigDecimal.ZERO)));
        System.out.println(describe(new Approved("A2", new BigDecimal("150.00"))));
        System.out.println(describe(new Declined("insufficient funds", 51)));
        System.out.println(describe(new Declined("stolen card", 43)));
        System.out.println(describe(new Pending("https://acs.example/3ds")));

        System.out.println("-- switch без case null на значении null");
        Object o = null;
        try {
            String s = switch (o) { case String str -> str; default -> "другое"; };
            System.out.println(s);
        } catch (NullPointerException e) {
            System.out.println("NullPointerException");
        }

        System.out.println("-- вложенный record pattern и null внутри");
        Box<Box<String>> full = new Box<>(new Box<>("R-7"));
        Box<Box<String>> innerNull = new Box<>(new Box<>(null));
        Box<Box<String>> outerNull = new Box<>(null);
        for (var b : java.util.List.of(full, innerNull, outerNull)) {
            try {
                String unboxed = switch (b) { case Box(Box(String s)) -> s; };
                System.out.println(b + " -> " + unboxed);
            } catch (MatchException e) {
                System.out.println(b + " -> MatchException");
            }
        }

        System.out.println("-- исключение в методе доступа при разборе записи");
        Object brittle = new Brittle("x");
        try {
            if (brittle instanceof Brittle(String id)) System.out.println(id);
        } catch (MatchException e) {
            System.out.println("MatchException, причина: " + e.getCause());
        }
    }
}
