// JDKS: 21 25
// PREVIEW: 25
// OUT: s4-primitive-patterns
// Примитивные типы в паттернах: preview в 23–27 (JEP 455, 488, 507, 530, 532).
public class PrimitivePatterns {
    static String fits(long amountKopecks) {
        return switch (amountKopecks) {
            case int i when i >= 0 -> "помещается в int: " + i;
            case int i -> "отрицательное int: " + i;
            case long l -> "нужен long: " + l;
        };
    }

    public static void main(String[] args) {
        System.out.println(fits(150_000));
        System.out.println(fits(-5));
        System.out.println(fits(5_000_000_000L));
        double rate = 92.0;
        if (rate instanceof int whole) System.out.println("курс целый: " + whole);
        double rate2 = 92.5;
        System.out.println("92.5 instanceof int: " + (rate2 instanceof int));
    }
}
