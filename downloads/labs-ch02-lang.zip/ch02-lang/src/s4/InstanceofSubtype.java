// MODE: javac
// JDKS: 17 21 25
// OUT: s4-instanceof-subtype
// instanceof с паттерном, когда статический тип уже подтип проверяемого: ошибка в 16–20, разрешено с 21.
public class InstanceofSubtype {
    static int length(String s) {
        if (s instanceof CharSequence cs) {
            return cs.length();
        }
        return -1;
    }
}
