// MODE: javac
// OUT: s4-guards-exhaustive
// Охранные условия when не учитываются при проверке полноты switch.
public class GuardsExhaustive {
    sealed interface Card permits Debit, Credit {}
    record Debit(String pan) implements Card {}
    record Credit(String pan, long limit) implements Card {}

    static String guardsOnly(Card c) {
        return switch (c) {
            case Debit d -> "дебетовая";
            case Credit cr when cr.limit() > 0 -> "кредитная с лимитом";
            case Credit cr when cr.limit() <= 0 -> "кредитная без лимита";
        };
    }
}
