// MODE: javac
// OUT: s4-weidig-switch
// Пример из книги о функциональном стиле: switch с результатом int и веткой default -> 0.0.
public class WeidigSwitch {
    record Point(int x, int y) {}
    record Point3D(int x, int y, int z) {}

    static int sum(Object anyObject) {
        int result = switch (anyObject) {
            case Point(var x, var y) -> x + y;
            case Point3D(var x, var y, var z) -> x + y + z;
            default -> 0.0;
        };
        return result;
    }
}
