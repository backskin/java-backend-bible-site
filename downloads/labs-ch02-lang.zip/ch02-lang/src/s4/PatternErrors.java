// MODE: javac
// OUT: s4-pattern-errors
// Нарочно некомпилируемый файл: доминирование, полнота, константы в switch по Object.
public class PatternErrors {
    sealed interface Card permits Debit, Credit {}
    record Debit(String pan) implements Card {}
    record Credit(String pan, long limit) implements Card {}

    // 1. Доминирование: Card перекрывает Debit.
    static String dominated(Card c) {
        return switch (c) {
            case Card any -> "карта";
            case Debit d -> "дебетовая";
        };
    }

    // 2. Охранные условия не учитываются при проверке полноты.
    static String guardsOnly(Card c) {
        return switch (c) {
            case Debit d -> "дебетовая";
            case Credit cr when cr.limit() > 0 -> "кредитная с лимитом";
            case Credit cr when cr.limit() <= 0 -> "кредитная без лимита";
        };
    }

    // 3. Числовые и строковые константы недопустимы при селекторе Object.
    static String constants(Object o) {
        return switch (o) {
            case 0 -> "ноль";
            case "" -> "пустая строка";
            default -> "другое";
        };
    }

    // 5. default перед case null.
    static String defaultFirst(Object o) {
        return switch (o) {
            default -> "другое";
            case null -> "null";
        };
    }
}
