// OUT: s4-early-exit
import java.util.Optional;

public class EarlyExit {
    record TransferCommand(String from, String to, long kopecks) {}

    static Optional<String> apply(Object msg) {
        if (!(msg instanceof TransferCommand cmd)) {
            return Optional.empty();
        }
        // сюда доходят только при успешной проверке, поэтому cmd виден
        return Optional.of(cmd.from() + " -> " + cmd.to() + ": " + cmd.kopecks());
    }

    public static void main(String[] args) {
        System.out.println(apply(new TransferCommand("40817", "40702", 15_000)));
        System.out.println(apply("not a command"));
    }
}
