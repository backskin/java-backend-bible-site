// MODE: javac
// JDKS: 25
// OUT: s4-pair-exhaustive
// Полнота вложенных record patterns считается по комбинациям: три из четырёх сочетаний — ошибка.
public class PairExhaustive {
    sealed interface Payment permits Card, Transfer {}
    record Card(String pan) implements Payment {}
    record Transfer(String account) implements Payment {}
    record Pair(Payment left, Payment right) {}

    static String full(Pair p) {
        return switch (p) {
            case Pair(Card _, Card _) -> "карта-карта";
            case Pair(Card _, Transfer _) -> "карта-перевод";
            case Pair(Transfer _, Card _) -> "перевод-карта";
            case Pair(Transfer _, Transfer _) -> "перевод-перевод";
        };
    }

    static String missing(Pair p) {
        return switch (p) {
            case Pair(Card _, Card _) -> "карта-карта";
            case Pair(Card _, Transfer _) -> "карта-перевод";
            case Pair(Transfer _, Card _) -> "перевод-карта";
        };
    }
}
