// MODE: javap SwitchJavap
// JAVAP: -c -p
// OUT: s4-switch-javap
// Во что компилируется switch с паттернами: invokedynamic на SwitchBootstraps.typeSwitch / enumSwitch.
public class SwitchJavap {
    sealed interface PaymentResult permits Approved, Declined {}
    record Approved(String code) implements PaymentResult {}
    record Declined(int code) implements PaymentResult {}
    enum Channel { CARD, SBP, TRANSFER }

    static int status(PaymentResult r) {
        return switch (r) {
            case Approved a -> 200;
            case Declined d when d.code() == 51 -> 402;
            case Declined d -> 422;
        };
    }

    static String channel(Channel c) {
        return switch (c) {
            case CARD -> "карта";
            case Channel ch when ch.ordinal() > 1 -> "перевод";
            case Channel ch -> "СБП";
        };
    }
}
