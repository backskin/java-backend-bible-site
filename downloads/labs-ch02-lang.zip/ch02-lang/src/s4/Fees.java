// OUT: s4-fees
// JDKS: 25
import java.math.BigDecimal;
import java.util.Currency;

public class Fees {
    sealed interface Payment permits CardPayment, Transfer {}
    record Amount(BigDecimal value, Currency currency) {}
    record Account(String bic, String number) {}
    record CardPayment(Amount amount, String maskedPan) implements Payment {}
    record Transfer(Amount amount, Account from, Account to) implements Payment {}

    static final BigDecimal CARD_RATE = new BigDecimal("0.015");
    static final BigDecimal INTERBANK_RATE = new BigDecimal("0.002");

    static BigDecimal fee(Payment p) {
        return switch (p) {
            case CardPayment(Amount(BigDecimal v, Currency _), String _) -> v.multiply(CARD_RATE);
            // перевод между счетами одного банка — без комиссии
            case Transfer(Amount _, Account(String fromBic, String _), Account(String toBic, String _))
                    when fromBic.equals(toBic) -> BigDecimal.ZERO;
            case Transfer(Amount(BigDecimal v, Currency _), Account _, Account _) -> v.multiply(INTERBANK_RATE);
        };
    }

    public static void main(String[] args) {
        var rub = Currency.getInstance("RUB");
        var sum = new Amount(new BigDecimal("1000.00"), rub);
        System.out.println(fee(new CardPayment(sum, "4276****1234")));
        System.out.println(fee(new Transfer(sum, new Account("044525225", "40817"), new Account("044525225", "40702"))));
        System.out.println(fee(new Transfer(sum, new Account("044525225", "40817"), new Account("044525974", "40702"))));
    }
}
