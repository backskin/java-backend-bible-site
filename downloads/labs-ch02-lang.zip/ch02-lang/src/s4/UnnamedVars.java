// JDKS: 21 25
// OUT: s4-unnamed
// Безымянные переменные и паттерны: preview в 21 (JEP 443), финальные с 22 (JEP 456).
import java.util.List;
import java.util.Map;

public class UnnamedVars {
    sealed interface Event permits Paid, Refunded, Chargeback {}
    record Paid(String id, long amount) implements Event {}
    record Refunded(String id, long amount) implements Event {}
    record Chargeback(String id, long amount, String reason) implements Event {}

    static long signedAmount(Event e) {
        return switch (e) {
            case Paid(_, long amount) -> amount;
            case Refunded _, Chargeback _ -> 0;
        };
    }

    public static void main(String[] args) {
        System.out.println(signedAmount(new Paid("P-1", 500)) + " " + signedAmount(new Chargeback("P-2", 300, "fraud")));
        int lines = 0;
        for (var _ : List.of("a", "b", "c")) lines++;
        Map<String, Long> totals = Map.of("RUB", 10L);
        totals.forEach((_, v) -> System.out.println("сумма " + v));
        try {
            Long.parseLong("12x");
        } catch (NumberFormatException _) {
            System.out.println("строк " + lines + ", разбор суммы не удался");
        }
    }
}
