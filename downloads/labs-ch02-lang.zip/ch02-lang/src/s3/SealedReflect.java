// OUT: s3-sealed-reflect
// Список permits без явного permits выводится компилятором; рефлексия видит его.
import java.util.Arrays;

public class SealedReflect {
    sealed interface PaymentResult {}
    record Approved(String authCode) implements PaymentResult {}
    record Declined(String reason) implements PaymentResult {}
    non-sealed interface Pending extends PaymentResult {}
    record AwaitingThreeDs(String acsUrl) implements Pending {}

    public static void main(String[] args) {
        System.out.println("isSealed: " + PaymentResult.class.isSealed());
        System.out.println("permitted: " + Arrays.stream(PaymentResult.class.getPermittedSubclasses()).map(Class::getSimpleName).toList());
        System.out.println("Pending.isSealed: " + Pending.class.isSealed() + ", permitted: " + Pending.class.getPermittedSubclasses());
    }
}
