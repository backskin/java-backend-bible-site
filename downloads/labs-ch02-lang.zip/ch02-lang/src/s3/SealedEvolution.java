// OUT: s3-sealed-evolution
// Раздельная компиляция: switch собран против иерархии из двух вариантов, а в работе их три.
// Программа сама компилирует две версии библиотеки и клиент и запускает клиент на новой версии.
import javax.tools.ToolProvider;
import java.net.URLClassLoader;
import java.nio.file.*;

public class SealedEvolution {
    static final String V1 = """
        package lib;
        public sealed interface PaymentResult permits Approved, Declined {}
        """;
    static final String V2 = """
        package lib;
        public sealed interface PaymentResult permits Approved, Declined, Pending {}
        """;
    static final String APPROVED = "package lib; public record Approved(String code) implements PaymentResult {}";
    static final String DECLINED = "package lib; public record Declined(String reason) implements PaymentResult {}";
    static final String PENDING = "package lib; public record Pending(String acsUrl) implements PaymentResult {}";
    static final String CLIENT = """
        package app;
        import lib.*;
        public class Client {
            public static String describe(PaymentResult r) {
                return switch (r) {
                    case Approved a -> "списано " + a.code();
                    case Declined d -> "отказ " + d.reason();
                };
            }
            public static void main(String[] args) {
                System.out.println(describe(new Approved("A1")));
                System.out.println(describe(new Pending("https://acs")));
            }
        }
        """;

    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("sealed-evo");
        Path v1 = compile(root.resolve("v1"), null, V1, APPROVED, DECLINED);
        Path v2 = compile(root.resolve("v2"), null, V2, APPROVED, DECLINED, PENDING);
        Path app = compile(root.resolve("app"), v1, CLIENT.replace("System.out.println(describe(new Pending(\"https://acs\")));", ""));
        Path app2 = compile(root.resolve("app2"), v1, CLIENT);
        System.out.println("клиент, собранный против v1, где есть Pending: " + (app2 == null ? "не компилируется" : "компилируется"));
        Path appRun = compile(root.resolve("app3"), v2, CLIENT);
        System.out.println("клиент собран против v2: " + (appRun == null ? "не компилируется (switch неполный)" : "компилируется"));
        // Клиент собран против v1 (switch полный), но запускается с библиотекой v2.
        Path old = compile(root.resolve("app4"), v1, CLIENT.replace("new Pending(\"https://acs\")", "pending()")
                .replace("public static void main", "static PaymentResult pending() throws Exception { return (PaymentResult) Class.forName(\"lib.Pending\").getConstructor(String.class).newInstance(\"https://acs\"); }\n    public static void main")
                .replace("String[] args)", "String[] args) throws Exception"));
        try (var cl = new URLClassLoader(new java.net.URL[]{old.toUri().toURL(), v2.toUri().toURL()}, null)) {
            var m = cl.loadClass("app.Client").getMethod("main", String[].class);
            try {
                m.invoke(null, (Object) new String[0]);
            } catch (java.lang.reflect.InvocationTargetException e) {
                System.out.println("запуск на v2: " + e.getCause());
            }
        }
    }

    static Path compile(Path out, Path cp, String... sources) throws Exception {
        Path src = out.resolveSibling(out.getFileName() + "-src");
        Files.createDirectories(src);
        Files.createDirectories(out);
        var files = new java.util.ArrayList<String>();
        int i = 0;
        for (String s : sources) {
            String name = s.contains("interface PaymentResult") ? "PaymentResult" : s.replaceAll("(?s).*(?:record|class) (\\w+).*", "$1");
            String pkg = s.contains("package app") ? "app" : "lib";
            Path f = src.resolve(pkg).resolve(name + ".java");
            Files.createDirectories(f.getParent());
            Files.writeString(f, s);
            files.add(f.toString());
        }
        var args = new java.util.ArrayList<String>(java.util.List.of("-d", out.toString(), "-nowarn", "-XDrawDiagnostics"));
        if (cp != null) { args.add("-cp"); args.add(cp.toString()); }
        args.addAll(files);
        var err = new java.io.ByteArrayOutputStream();
        int rc = ToolProvider.getSystemJavaCompiler().run(null, null, err, args.toArray(String[]::new));
        if (rc != 0) {
            System.out.println("  javac: " + err.toString().lines().filter(l -> l.contains("compiler.err")).map(l -> l.replaceAll(".*(compiler\\.err\\S+).*", "$1")).toList());
            return null;
        }
        return out;
    }
}
