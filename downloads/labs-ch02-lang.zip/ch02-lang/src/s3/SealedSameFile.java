// OUT: s3-sealed-same-file
// sealed без permits: разрешённые подклассы — все в той же единице компиляции, в том числе классы верхнего уровня.
import java.util.Arrays;

public class SealedSameFile {
    public static void main(String[] args) {
        System.out.println("Order.permitted: " + Arrays.stream(Order.class.getPermittedSubclasses()).map(Class::getSimpleName).toList());
        System.out.println("вложенный ли MarketOrder: " + MarketOrder.class.isMemberClass());
    }
}

sealed class Order {}
final class MarketOrder extends Order {}
non-sealed class LimitOrder extends Order {}
