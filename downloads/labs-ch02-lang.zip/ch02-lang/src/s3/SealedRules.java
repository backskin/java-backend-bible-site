// MODE: javac
// OUT: s3-sealed-rules
// Нарочно некомпилируемый файл: нарушения правил sealed (JLS 8.1.1.2, 8.1.6).
public class SealedRules {
    sealed interface PaymentResult permits Approved, Declined, Pending {}
    record Approved(String authCode) implements PaymentResult {}
    record Declined(String reason) implements PaymentResult {}
    // Подкласс без final / sealed / non-sealed:
    static class Pending implements PaymentResult {}

    // Класс не из списка permits:
    record Refunded(String id) implements PaymentResult {}

    // non-sealed у класса, у которого нет sealed-родителя:
    non-sealed static class Orphan {}

    static void localSubclass() {
        // Локальный класс не может расширять sealed-тип.
        final class Local implements PaymentResult {}
    }
}
