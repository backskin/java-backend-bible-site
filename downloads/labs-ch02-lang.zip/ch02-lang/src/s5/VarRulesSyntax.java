// MODE: javac
// OUT: s5-var-rules-syntax
import java.util.function.BiFunction;

public class VarRulesSyntax {
    void cases() {
        BiFunction<Long, Long, Long> sum = (var a, b) -> a + b;
    }
    var field = 1;
}
