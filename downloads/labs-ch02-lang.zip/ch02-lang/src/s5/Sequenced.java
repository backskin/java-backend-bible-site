// JDKS: 17 21 25
// OUT: s5-sequenced
// Упорядоченные коллекции (JEP 431, Java 21).
import java.util.*;

public class Sequenced {
    public static void main(String[] args) {
        List<String> payments = new ArrayList<>(List.of("P-1", "P-2", "P-3"));
        System.out.println("getFirst/getLast: " + payments.getFirst() + " " + payments.getLast());
        List<String> rev = payments.reversed();
        payments.add("P-4");
        System.out.println("reversed() после add в исходный: " + rev);
        rev.addFirst("P-5");
        System.out.println("исходный после rev.addFirst(\"P-5\"): " + payments);

        var recent = new LinkedHashSet<>(List.of("card-1", "card-2", "card-3"));
        recent.addFirst("card-3");
        System.out.println("LinkedHashSet.addFirst существующего: " + recent);

        var cache = new LinkedHashMap<String, Integer>();
        cache.put("a", 1); cache.put("b", 2); cache.put("c", 3);
        cache.putLast("a", 10);
        System.out.println("LinkedHashMap.putLast существующего: " + cache + ", firstEntry=" + cache.firstEntry());

        var sorted = new TreeSet<>(List.of(3, 1, 2));
        System.out.println("TreeSet.getFirst/reversed: " + sorted.getFirst() + " " + sorted.reversed());
        try {
            sorted.addFirst(0);
        } catch (UnsupportedOperationException e) {
            System.out.println("TreeSet.addFirst: UnsupportedOperationException");
        }
        try {
            List.of(1, 2).reversed().addFirst(0);
        } catch (UnsupportedOperationException e) {
            System.out.println("List.of(...).reversed().addFirst: UnsupportedOperationException");
        }
    }
}
