// MODE: classrun HelpfulNpe
// JAVAC: -g
// JDKS: 11 17 21 25
// OUT: s5-helpful-npe
// Подробные сообщения NullPointerException (JEP 358): в 14 по флагу, с 15 по умолчанию.
public class HelpfulNpe {
    static class Account { String currency; String currency() { return currency; } }
    static class Client { Account account; Account account() { return account; } }

    public static void main(String[] args) {
        Client client = new Client();
        try {
            System.out.println(client.account().currency().length());
        } catch (NullPointerException e) {
            System.out.println("message: " + e.getMessage());
        }
        String reference = null;
        try {
            System.out.println(reference.trim());
        } catch (NullPointerException e) {
            System.out.println("message: " + e.getMessage());
        }
    }
}
