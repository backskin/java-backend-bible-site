// OUT: s5-text-blocks
// Отступы, переводы строк и особые последовательности в текстовых блоках (JEP 378).
public class TextBlocks {
    public static void main(String[] args) {
        String a = """
            {
              "id": 1
            }
            """;
        String b = """
            {
              "id": 1
            }""";
        String c = """
                {
                  "id": 1
                }
          """;
        String t = """
            строка с хвостовыми пробелами
            склеено \
            в одну
            табуляция:\tконец\s
            """;
        System.out.println("a: " + show(a));
        System.out.println("b: " + show(b));
        System.out.println("c: " + show(c));
        System.out.println("t: " + show(t));
        String sql = """
            select id, amount
              from payment
             where merchant_id = ?
            """;
        System.out.println("sql: " + show(sql));
        System.out.println("formatted: " + show("""
            {"type": "%s", "amount": %s}
            """.formatted("REFUND", "150.00")));
    }

    static String show(String s) {
        return s.replace("\n", "⏎").replace(" ", "·").replace("\t", "→");
    }
}
