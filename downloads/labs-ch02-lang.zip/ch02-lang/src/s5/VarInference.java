// OUT: s5-var-inference
// Что выводит var: ArrayList<Object> из ромба и доступ к членам анонимного класса.
import java.util.ArrayList;

public class VarInference {
    public static void main(String[] args) {
        var list = new ArrayList<>();
        list.add("RUB");
        list.add(42);
        System.out.println("var list = new ArrayList<>() -> принимает и String, и Integer: " + list);
        var counter = new Object() {
            int processed = 0;
            void inc() { processed++; }
        };
        counter.inc();
        counter.inc();
        System.out.println("член анонимного класса через var: processed=" + counter.processed);
        var var = "переменная по имени var допустима";
        System.out.println(var);
    }
}
