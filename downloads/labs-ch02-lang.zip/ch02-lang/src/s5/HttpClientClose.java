// JDKS: 17 21 25
// OUT: s5-httpclient
// HttpClient: тайм-аута по умолчанию нет, тайм-аут запроса задаётся явно; close() появился в 21.
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;

public class HttpClientClose {
    public static void main(String[] args) throws Exception {
        try (var server = new ServerSocket(0)) {           // принимает соединение и молчит
            var uri = URI.create("http://127.0.0.1:" + server.getLocalPort() + "/limits");
            HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(1)).build();
            System.out.println("connectTimeout у клиента по умолчанию: " + HttpClient.newHttpClient().connectTimeout());
            var request = HttpRequest.newBuilder(uri).timeout(Duration.ofMillis(500)).build();
            System.out.println("тайм-аут запроса по умолчанию: " + HttpRequest.newBuilder(uri).build().timeout());
            long t0 = System.nanoTime();
            try {
                client.send(request, HttpResponse.BodyHandlers.ofString());
            } catch (HttpTimeoutException e) {
                System.out.println("send с timeout(500 мс): " + e.getClass().getSimpleName() + " через ~" + Math.round((System.nanoTime() - t0) / 1e8) * 100 + " мс");
            }
            System.out.println("HttpClient реализует AutoCloseable: " + AutoCloseable.class.isAssignableFrom(HttpClient.class));
        }
    }
}
