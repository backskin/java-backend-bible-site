// JDKS: 21 25
// OUT: s5-compact-source
// Компактный исходный файл, метод main экземпляра, import module и IO (JEP 511, 512 — финальные в 25).
import module java.base;

void main() {
    List<BigDecimal> amounts = List.of(new BigDecimal("100.00"), new BigDecimal("250.50"));
    IO.println("итого " + amounts.stream().reduce(BigDecimal.ZERO, BigDecimal::add));
    IO.println("класс: " + getClass().getName() + ", синтетический: " + getClass().isSynthetic());
}
