// MODE: javac
// OUT: s5-var-rules
// Где var не компилируется (JEP 286, JEP 323).
import java.util.function.BiFunction;

public class VarRules {
    void cases() {
        var nothing = null;
        var lambda = () -> "x";
        var array = {1, 2};
    }
}
