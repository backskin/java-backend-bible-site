// JDKS: 21 25
// OUT: s5-api-additions
// Новые методы стандартной библиотеки 11–21, которые заменяют самописные утилиты.
import java.util.*;
import java.util.random.RandomGenerator;
import java.util.random.RandomGeneratorFactory;
import java.util.stream.*;

public class ApiAdditions {
    public static void main(String[] args) {
        System.out.println("isBlank(\" \\u2003\"): " + " \u2003".isBlank() + ", trim().isEmpty(): " + " \u2003".trim().isEmpty());
        System.out.println("strip() убирает U+2003, trim() нет: [" + "\u2003R-7\u2003".strip() + "] [" + "\u2003R-7\u2003".trim() + "]");
        System.out.println("repeat: " + "=".repeat(5) + ", lines: " + "a\nb\r\nc".lines().count());
        System.out.println("transform: " + " 1500.00 ".transform(String::strip).transform(java.math.BigDecimal::new));
        System.out.println("Stream.toList() неизменяемый: " + tryAdd(Stream.of(1, 2).toList()) + ", collect(toList()): " + tryAdd(Stream.of(1, 2).collect(Collectors.toList())));
        System.out.println("teeing: " + Stream.of(100, 250, 50).collect(Collectors.teeing(Collectors.counting(), Collectors.summingInt(i -> i), (n, s) -> n + " платежа на " + s)));
        System.out.println("Objects.requireNonNullElse: " + Objects.requireNonNullElse(null, "RUB"));
        System.out.println("Optional.isEmpty: " + Optional.empty().isEmpty());
        System.out.println("Math.floorMod(-7, 3) = " + Math.floorMod(-7, 3) + ", -7 % 3 = " + (-7 % 3));
        try {
            Math.addExact(Integer.MAX_VALUE, 1);
        } catch (ArithmeticException e) {
            System.out.println("Math.addExact: " + e.getMessage());
        }
        RandomGenerator g = RandomGeneratorFactory.of("L64X128MixRandom").create(42);
        System.out.println("L64X128MixRandom(42): " + g.nextInt(1000) + " " + g.nextInt(1000) + ", default: " + RandomGenerator.getDefault().getClass().getSimpleName());
        java21();
    }

    static String tryAdd(List<Integer> list) {
        try { list.add(3); return "add прошёл"; } catch (UnsupportedOperationException e) { return "UnsupportedOperationException"; }
    }

    static void java21() {
        System.out.println("-- методы Java 21");
        System.out.println("Math.clamp(150, 0, 100) = " + Math.clamp(150, 0, 100));
        System.out.println("splitWithDelimiters: " + Arrays.toString("100+20-5".splitWithDelimiters("[+-]", 0)));
        System.out.println("indexOf(ch, from, to): " + "RUB;USD;EUR".indexOf(';', 4, 11));
        System.out.println("StringBuilder.repeat: " + new StringBuilder("№").repeat('0', 3));
        System.out.println("Character.isEmoji(0x1F4B3): " + Character.isEmoji(0x1F4B3));
    }
}
