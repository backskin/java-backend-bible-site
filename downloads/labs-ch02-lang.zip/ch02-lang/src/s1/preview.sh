#!/bin/sh
# Опыт 1.2: class-файл с preview-возможностью привязан к версии JDK.
# Запуск: sh src/s1/preview.sh > s1-preview.txt 2>&1
J25=~/.jdks/jdk-25.0.5+8/bin
J21=~/.jdks/temurin-21.0.10/bin
T=$(mktemp -d)
cat > $T/Fits.java <<'J'
public class Fits {
    public static void main(String[] a) {
        long kopecks = 150_000;
        System.out.println(kopecks instanceof int i ? "int " + i : "long");
    }
}
J
cat > $T/Plain.java <<'J'
public class Plain { public static void main(String[] a) { System.out.println("plain ok"); } }
J
cd $T
echo '$ javac --release 25 --enable-preview Fits.java'; $J25/javac -J-Duser.language=en --release 25 --enable-preview Fits.java 2>&1 | sed 's/^Note/Note/'
echo '$ javap -v Fits | grep version'; $J25/javap -v Fits | grep -E "minor version|major version"
echo '$ java Fits   (JDK 25, без --enable-preview)'; $J25/java -Duser.language=en Fits 2>&1 | head -3
echo '$ java --enable-preview Fits   (JDK 25)'; $J25/java --enable-preview Fits 2>&1
echo '$ java --enable-preview Fits   (JDK 21)'; $J21/java -Duser.language=en --enable-preview Fits 2>&1 | head -3
echo '$ javac --release 21 Plain.java (JDK 25); javap -v Plain | grep version'; $J25/javac --release 21 Plain.java; $J25/javap -v Plain | grep -E "minor version|major version"
echo '$ java Plain (JDK 21)'; $J21/java Plain
rm -rf $T
