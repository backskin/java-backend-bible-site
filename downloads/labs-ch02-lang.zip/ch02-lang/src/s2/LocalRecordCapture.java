// MODE: javac
// OUT: s2-local-record-capture
// Локальная запись неявно static: не видит локальные переменные метода.
import java.math.BigDecimal;

public class LocalRecordCapture {
    BigDecimal report(BigDecimal fee) {
        record Line(BigDecimal amount) {
            BigDecimal net() { return amount.subtract(fee); }
        }
        return new Line(BigDecimal.TEN).net();
    }
}
