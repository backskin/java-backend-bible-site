// OUT: s2-record-equality
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class RecordEquality {
    record Rate(double value) {}
    record Money(BigDecimal amount, String currency) {}
    record NormalizedMoney(BigDecimal amount, String currency) {
        NormalizedMoney {
            Objects.requireNonNull(amount, "amount");
            amount = amount.setScale(2, RoundingMode.UNNECESSARY);
        }
    }
    record Signature(byte[] bytes) {}
    record Batch(String registryId, List<String> paymentIds) {}
    record SafeBatch(String registryId, List<String> paymentIds) {
        SafeBatch { paymentIds = List.copyOf(paymentIds); }
    }

    public static void main(String[] args) {
        System.out.println("-- double: сравнение через Double.compare");
        System.out.println("Rate(0.0).equals(Rate(-0.0)) = " + new Rate(0.0).equals(new Rate(-0.0)) + "; 0.0 == -0.0 -> " + (0.0 == -0.0));
        System.out.println("Rate(NaN).equals(Rate(NaN)) = " + new Rate(Double.NaN).equals(new Rate(Double.NaN)) + "; NaN == NaN -> " + (Double.NaN == Double.NaN));

        System.out.println("-- BigDecimal: equals учитывает масштаб");
        var a = new Money(new BigDecimal("1.0"), "RUB");
        var b = new Money(new BigDecimal("1.00"), "RUB");
        System.out.println(a + " equals " + b + " = " + a.equals(b) + "; compareTo = " + a.amount().compareTo(b.amount()));
        Set<Money> seen = new HashSet<>(Set.of(a));
        System.out.println("HashSet[1.0 RUB].contains(1.00 RUB) = " + seen.contains(b));
        var na = new NormalizedMoney(new BigDecimal("1.0"), "RUB");
        var nb = new NormalizedMoney(new BigDecimal("1.00"), "RUB");
        System.out.println("после setScale(2) в компактном конструкторе: " + na + " equals " + nb + " = " + na.equals(nb));
        try {
            new NormalizedMoney(new BigDecimal("1.005"), "RUB");
        } catch (ArithmeticException e) {
            System.out.println("NormalizedMoney(1.005): " + e);
        }

        System.out.println("-- массив в компоненте сравнивается по ссылке");
        var s1 = new Signature(new byte[]{1, 2});
        var s2 = new Signature(new byte[]{1, 2});
        System.out.println("Signature({1,2}).equals(Signature({1,2})) = " + s1.equals(s2));
        System.out.println("toString: " + s1.toString().replaceAll("@[0-9a-f]+", "@<хеш>"));

        System.out.println("-- поверхностная неизменяемость");
        var ids = new ArrayList<>(List.of("P-1"));
        var batch = new Batch("R-7", ids);
        var safe = new SafeBatch("R-7", ids);
        ids.add("P-2");
        System.out.println("Batch после ids.add(\"P-2\"):     " + batch);
        System.out.println("SafeBatch после ids.add(\"P-2\"): " + safe);
        try {
            safe.paymentIds().add("P-3");
        } catch (UnsupportedOperationException e) {
            System.out.println("safe.paymentIds().add(...): " + e.getClass().getSimpleName());
        }
        try {
            new SafeBatch("R-8", Arrays.asList("P-1", null));
        } catch (NullPointerException e) {
            System.out.println("List.copyOf со значением null: NullPointerException");
        }
        System.out.println("-- hashCode совпадает у равных записей: " + (new Batch("R", List.of("x")).hashCode() == new Batch("R", List.of("x")).hashCode()));
    }
}
