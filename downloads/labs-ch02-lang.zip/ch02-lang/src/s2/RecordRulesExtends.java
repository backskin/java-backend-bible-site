// MODE: javac
// OUT: s2-record-rules-extends
public class RecordRulesExtends {
    static class Base {}
    record Child(int x) extends Base {}
}
