// OUT: s2-record-misc
// List.copyOf не копирует уже неизменяемый список; serialVersionUID записи; локальная запись.
import java.io.ObjectStreamClass;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.*;

public class RecordMisc {
    record Limit(String clientId, BigDecimal daily) implements Serializable {}
    static class LimitClass implements Serializable { String clientId; BigDecimal daily; }

    public static void main(String[] args) {
        List<String> immutable = List.of("P-1", "P-2");
        System.out.println("List.copyOf(List.of(...)) — тот же объект: " + (List.copyOf(immutable) == immutable));
        List<String> mutable = new ArrayList<>(immutable);
        System.out.println("List.copyOf(ArrayList) — тот же объект: " + (List.copyOf(mutable) == mutable));
        List<String> unmodifiableView = Collections.unmodifiableList(mutable);
        System.out.println("List.copyOf(Collections.unmodifiableList) — тот же объект: " + (List.copyOf(unmodifiableView) == unmodifiableView));

        System.out.println("serialVersionUID записи без явного поля: " + ObjectStreamClass.lookup(Limit.class).getSerialVersionUID());
        System.out.println("serialVersionUID обычного класса: вычислен по структуре, ненулевой: " + (ObjectStreamClass.lookup(LimitClass.class).getSerialVersionUID() != 0));

        record Bucket(long count, BigDecimal sum) {}
        var payments = List.of(new BigDecimal("100.00"), new BigDecimal("250.50"), new BigDecimal("49.50"));
        Bucket b = payments.stream().collect(Collectors.teeing(
                Collectors.counting(),
                Collectors.reducing(BigDecimal.ZERO, BigDecimal::add),
                Bucket::new));
        System.out.println("локальная запись в teeing: " + b + ", статическая: " + java.lang.reflect.Modifier.isStatic(Bucket.class.getModifiers()));
    }
}
