// MODE: javap RecordJavap$Transfer
// JAVAP: -p -c
// OUT: s2-record-javap
import java.math.BigDecimal;

public class RecordJavap {
    record Transfer(String from, String to, BigDecimal amount) {}
}
