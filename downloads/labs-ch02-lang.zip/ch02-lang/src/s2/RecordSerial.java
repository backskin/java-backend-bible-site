// OUT: s2-record-serial
// Десериализация записи идёт через канонический конструктор, а обычного класса — в обход конструктора.
import java.io.*;
import java.math.BigDecimal;

public class RecordSerial {
    static boolean strict = false;

    record Limit(String clientId, BigDecimal daily) implements Serializable {
        Limit {
            System.out.println("  конструктор Limit(" + clientId + ", " + daily + ")");
            if (strict && daily.signum() < 0) throw new IllegalArgumentException("daily < 0");
        }
        private void readObject(ObjectInputStream in) {
            System.out.println("  readObject записи вызван");
        }
    }

    static class LimitClass implements Serializable {
        final String clientId;
        final BigDecimal daily;
        LimitClass(String clientId, BigDecimal daily) {
            System.out.println("  конструктор LimitClass(" + clientId + ", " + daily + ")");
            if (strict && daily.signum() < 0) throw new IllegalArgumentException("daily < 0");
            this.clientId = clientId;
            this.daily = daily;
        }
        public String toString() { return "LimitClass[" + clientId + ", " + daily + "]"; }
    }

    static byte[] write(Object o) throws IOException {
        var bytes = new ByteArrayOutputStream();
        try (var out = new ObjectOutputStream(bytes)) { out.writeObject(o); }
        return bytes.toByteArray();
    }

    static Object read(byte[] b) throws Exception {
        try (var in = new ObjectInputStream(new ByteArrayInputStream(b))) { return in.readObject(); }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("-- создаём объекты с отрицательным лимитом, пока проверка выключена");
        byte[] rec = write(new Limit("C-1", new BigDecimal("-100")));
        byte[] cls = write(new LimitClass("C-1", new BigDecimal("-100")));
        strict = true;
        System.out.println("-- включили проверку и читаем поток байтов");
        try {
            System.out.println("record: " + read(rec));
        } catch (Exception e) {
            System.out.println("record: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        System.out.println("class:  " + read(cls));
    }
}
