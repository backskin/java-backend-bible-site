// MODE: javac
// OUT: s2-record-rules
// Нарочно некомпилируемый файл: каждая запись нарушает одно правило JLS 8.10.
import java.io.IOException;
import java.math.BigDecimal;

public class RecordRules {
    // 1. Имя компонента equals разрешено, hashCode и toString запрещены.
    record EqualsName(int equals) {}
    record HashName(int hashCode) {}

    // 3. Метод доступа не может объявлять throws.
    record AccessorThrows(String path) {
        public String path() throws IOException { return path; }
    }

    // 4. Канонический конструктор не может объявлять throws.
    record CtorThrows(String path) {
        public CtorThrows(String path) throws IOException { this.path = path; }
    }

    // 5. В компактном конструкторе нельзя присваивать полю.
    record CompactAssign(String currency) {
        CompactAssign { this.currency = currency.toUpperCase(); }
    }

    // 6. Метод доступа должен быть public.
    record NotPublic(String id) {
        String id() { return id; }
    }

}
