// JDKS: 21 25 26
// OUT: s2-record-reflect
// Почему запись не годится в сущность JPA: нет конструктора без аргументов, final-поле записи не меняется даже рефлексией.
import java.lang.reflect.Field;
import java.lang.reflect.RecordComponent;
import java.math.BigDecimal;
import java.util.Arrays;

public class RecordReflect {
    static class PlainLimit {
        private final BigDecimal daily = BigDecimal.ONE;
    }
    record Limit(String clientId, BigDecimal daily) {}

    public static void main(String[] args) throws Exception {
        System.out.println("конструкторы Limit: " + Arrays.toString(Limit.class.getDeclaredConstructors()));
        System.out.println("isRecord: Limit=" + Limit.class.isRecord() + ", PlainLimit=" + PlainLimit.class.isRecord());
        System.out.println("getRecordComponents у обычного класса: " + PlainLimit.class.getRecordComponents());
        for (RecordComponent c : Limit.class.getRecordComponents()) {
            System.out.println("компонент " + c.getName() + ": " + c.getType().getSimpleName() + ", accessor " + c.getAccessor().getName());
        }

        Field pf = PlainLimit.class.getDeclaredField("daily");
        pf.setAccessible(true);
        var plain = new PlainLimit();
        pf.set(plain, BigDecimal.TEN);
        System.out.println("обычный класс: final-поле после setAccessible + set = " + pf.get(plain));

        Field rf = Limit.class.getDeclaredField("daily");
        rf.setAccessible(true);
        try {
            rf.set(new Limit("C-1", BigDecimal.ONE), BigDecimal.TEN);
        } catch (IllegalAccessException e) {
            System.out.println("запись: " + e);
        }
    }
}
