// MODE: javac
// OUT: s2-record-rules-syntax
// Нарочно некомпилируемый файл: эти нарушения javac ловит ещё при разборе.
import java.math.BigDecimal;

public class RecordRulesSyntax {
    // Дополнительное поле экземпляра запрещено, статическое разрешено.
    record WithField(BigDecimal amount) {
        static final String CURRENCY = "RUB";
        private final long createdAt = System.nanoTime();
    }
}
