// OUT: s2-flexible-ctor
// JEP 513 (Java 25): операторы до this(...) в дополнительном конструкторе записи.
import java.math.BigDecimal;

public class FlexibleCtor {
    record Amount(BigDecimal value, String currency) {
        // Дополнительный конструктор принимает строку из реестра вида "1500.00 RUB".
        Amount(String raw) {
            if (raw == null || !raw.matches("\\d+(\\.\\d{1,2})? [A-Z]{3}")) {
                throw new IllegalArgumentException("bad amount: " + raw);
            }
            String[] parts = raw.split(" ");
            this(new BigDecimal(parts[0]), parts[1]);
        }
    }

    public static void main(String[] args) {
        System.out.println(new Amount("1500.00 RUB"));
        try {
            new Amount("15,00 RUB");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
