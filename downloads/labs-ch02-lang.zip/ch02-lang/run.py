"""Опыты главы 02: запускает программы из src/ на нескольких JDK и пишет вывод в <OUT>.txt.

Использование:
    python -X utf8 run.py                    # все программы
    python -X utf8 run.py src/s2/*.java      # выборочно

Заголовок программы (необязательные строки-комментарии в начале файла):
    // MODE: run               — java Файл.java (по умолчанию)
    // MODE: javac             — только компиляция, в вывод попадают сообщения javac
    // MODE: javap Класс       — компиляция и javap -v/-c Класса (флаги в JAVAP:)
    // MODE: classrun Класс    — компиляция в каталог и запуск java -cp Класс
    // JDKS: 17 21 25          — на каких JDK запускать (по умолчанию 21 25)
    // PREVIEW: 21 25          — на каких JDK добавить --enable-preview (и --release N)
    // JAVAC: -Xlint:all       — флаги javac
    // JAVA: -Xmx64m           — флаги java
    // JAVAP: -c -p            — флаги javap (по умолчанию -c -p)
    // ARGS: a b               — аргументы программы
    // OUT: s2-record-equals   — имя файла вывода (без .txt)
Домашний каталог и временные каталоги в выводе заменяются на ~ и <tmp>.
"""
import glob, os, re, shutil, subprocess, sys, tempfile, datetime

HOME = os.path.expanduser('~')
ALL = {
    '11': ('11.0.29', os.path.join(HOME, '.jdks', 'temurin-11.0.29', 'bin')),
    '17': ('17.0.17', os.path.join(HOME, '.jdks', 'temurin-17.0.17', 'bin')),
    '21': ('21.0.10', os.path.join(HOME, '.jdks', 'temurin-21.0.10', 'bin')),
    '25': ('25.0.5', os.path.join(HOME, '.jdks', 'jdk-25.0.5+8', 'bin')),
    '26': ('26.0.2.1', os.path.join(HOME, '.jdks', 'jdk-26.0.2.1+1', 'bin')),
}
ROOT = os.path.dirname(os.path.abspath(__file__))
LAB = os.path.basename(ROOT)


def header(src, key):
    m = re.search(r'^//\s*%s:\s*(.*)$' % key, src, re.M)
    return m.group(1).strip() if m else None


def clean(text, tmp):
    for t in (tmp, tmp.replace('\\', '/')):
        text = text.replace(t, '<tmp>')
    for h in (HOME, HOME.replace('\\', '/')):
        text = text.replace(h, '~')
    text = re.sub(r'[A-Za-z]:\\Users\\[^\\]+\\AppData\\Local\\Temp\\[^\s:]+', '<tmp>', text)
    return text.replace('\r\n', '\n')


def run_one(path):
    src = open(path, encoding='utf-8').read()
    mode = (header(src, 'MODE') or 'run').split()
    jdks = (header(src, 'JDKS') or '21 25').split()
    prev = (header(src, 'PREVIEW') or '').split()
    jflags = (header(src, 'JAVA') or '').split()
    cflags = (header(src, 'JAVAC') or '').split()
    pflags = (header(src, 'JAVAP') or '-c -p').split()
    args = (header(src, 'ARGS') or '').split()
    timeout = int(header(src, 'TIMEOUT') or '600')
    results = {}
    env = dict(os.environ, LANG='C')
    env.pop('JAVA_TOOL_OPTIONS', None)
    env.pop('_JAVA_OPTIONS', None)
    for key in jdks:
        ver, bin_ = ALL[key]
        tmp = tempfile.mkdtemp(prefix='ch02-')
        pv = ['--enable-preview'] if key in prev else []
        pvc = ['--enable-preview', '--release', key] if key in prev else []
        loc = ['-Duser.language=en', '-Duser.country=US', '-Dstdout.encoding=UTF-8', '-Dstderr.encoding=UTF-8']
        try:
            if mode[0] == 'run':
                srcflag = ['--source', key] if pv else []
                cmd = [os.path.join(bin_, 'java'), *loc, *pv, *srcflag, *jflags, os.path.abspath(path), *args]
                out = '$ java %s %s\n' % (' '.join(pv + srcflag + jflags), os.path.basename(path) + ('' if not args else ' ' + ' '.join(args)))
                try:
                    p = subprocess.run(cmd, capture_output=True, cwd=tmp, env=env, timeout=timeout)
                    out += p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
                    out += '' if p.returncode == 0 else '[код возврата %d]\n' % p.returncode
                except subprocess.TimeoutExpired:
                    out += '[прервано по тайм-ауту %d с]\n' % timeout
            else:
                cmd = [os.path.join(bin_, 'javac'), '-J-Duser.language=en', '-J-Dstdout.encoding=UTF-8',
                       '-J-Dstderr.encoding=UTF-8', '-encoding', 'UTF-8', *pvc, *cflags, '-d', tmp, os.path.abspath(path)]
                p = subprocess.run(cmd, capture_output=True, cwd=tmp, env=env)
                out = '$ javac %s %s\n' % (' '.join(pvc + cflags), os.path.basename(path))
                out += p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
                out += '[javac: код возврата %d]\n' % p.returncode
                if mode[0] == 'javap' and p.returncode == 0:
                    for cls in mode[1:]:
                        q = subprocess.run([os.path.join(bin_, 'javap'), '-J-Duser.language=en', *pflags, '-cp', tmp, cls],
                                           capture_output=True)
                        out += '$ javap %s %s\n' % (' '.join(pflags), cls)
                        out += q.stdout.decode('utf-8', 'replace') + q.stderr.decode('utf-8', 'replace')
                if mode[0] == 'classrun' and p.returncode == 0:
                    for cls in mode[1:]:
                        q = subprocess.run([os.path.join(bin_, 'java'), *loc, *pv, *jflags, '-cp', tmp, cls, *args],
                                           capture_output=True, cwd=tmp, env=env, timeout=timeout)
                        out += '$ java %s %s\n' % (' '.join(pv + jflags), cls)
                        out += q.stdout.decode('utf-8', 'replace') + q.stderr.decode('utf-8', 'replace')
                        out += '' if q.returncode == 0 else '[код возврата %d]\n' % q.returncode
            results['%s' % ver] = clean(out, tmp)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    rel = os.path.relpath(path, ROOT).replace('\\', '/')
    name = header(src, 'OUT') or os.path.splitext(os.path.basename(path))[0].lower()
    lines = ['# Запуск %s: labs/%s/%s' % (datetime.date.today().isoformat(), LAB, rel)]
    vals = list(results.values())
    if len(vals) > 1 and all(v == vals[0] for v in vals):
        lines.append('# Temurin JDK %s: вывод одинаковый' % ', '.join(results))
        lines.append(vals[0].rstrip('\n'))
    else:
        for v, o in results.items():
            lines.append('# ---- Temurin JDK %s' % v)
            lines.append(o.rstrip('\n'))
    dst = os.path.join(ROOT, name + '.txt')
    open(dst, 'w', encoding='utf-8', newline='\n').write('\n'.join(lines) + '\n')
    print('==>', os.path.basename(dst))
    print('\n'.join(lines[1:]))


if __name__ == '__main__':
    files = sys.argv[1:] or sorted(glob.glob(os.path.join(ROOT, 'src', '**', '*.java'), recursive=True))
    for f in files:
        for g in sorted(glob.glob(f)) or [f]:
            run_one(g)
