package checks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreFilter;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

/** Разд. 6.8: цена @PostFilter на 10 000 элементах и поведение на неизменяемом списке. */
@SpringBootApplication
public class PostFilterCost {

    public record Payment(long id, String owner) { public String getOwner() { return owner; } }

    @Configuration @EnableMethodSecurity static class Cfg {}

    @Service
    public static class Payments {
        static List<Payment> data(int n) {
            return IntStream.range(0, n).mapToObj(i -> new Payment(i, i % 100 == 0 ? "dev.team" : "client-" + i)).toList();
        }
        public List<Payment> plain(int n) { return new ArrayList<>(data(n)); }

        @PostFilter("filterObject.owner == authentication.name")
        public List<Payment> filtered(int n) { return new ArrayList<>(data(n)); }

        @PostFilter("filterObject.owner == authentication.name")
        public List<Payment> immutable(int n) { return data(n); }          // Stream.toList(): неизменяемый список

        @PostFilter("filterObject.owner == authentication.name")
        public List<Payment> same(List<Payment> in) { return in; }

        @PreFilter("filterObject.owner == authentication.name")
        public List<Payment> sell(List<Payment> in) { return in; }
    }

    public static void main(String[] args) {
        try (ConfigurableApplicationContext ctx = new SpringApplication(PostFilterCost.class).run(
                "--logging.level.root=OFF", "--spring.main.banner-mode=off", "--spring.main.web-application-type=none")) {
            SecurityContextHolder.getContext().setAuthentication(
                    new UsernamePasswordAuthenticationToken("dev.team", "n", AuthorityUtils.createAuthorityList("ROLE_USER")));
            Payments p = ctx.getBean(Payments.class);
            for (int i = 0; i < 30; i++) { p.plain(10_000); p.filtered(10_000); }        // прогрев
            System.out.printf("без @PostFilter, 10 000 элементов: %.2f мс, вернулось %d%n", best(() -> p.plain(10_000).size()), p.plain(10_000).size());
            System.out.printf("с @PostFilter,   10 000 элементов: %.2f мс, вернулось %d%n", best(() -> p.filtered(10_000).size()), p.filtered(10_000).size());
            try { List<Payment> r = p.immutable(100); System.out.println("неизменяемый список (Stream.toList()) на входе фильтра: прошло, вернулось " + r.size() + ", класс " + r.getClass().getName()); }
            catch (RuntimeException e) { System.out.println("неизменяемый список (Stream.toList()): " + e.getClass().getName()); }
            List<Payment> mine = new ArrayList<>(Payments.data(300));
            List<Payment> out = p.same(mine);
            System.out.println("@PostFilter на ArrayList: тот же объект = " + (out == mine) + ", исходный список изменён = " + (mine.size() != 300));
            List<Payment> arg = new ArrayList<>(Payments.data(300));
            List<Payment> sold = p.sell(arg);
            System.out.println("@PreFilter на ArrayList: в метод пришёл тот же объект = " + (sold == arg) + ", элементов " + sold.size());
            try { List<Payment> r = p.sell(List.of(new Payment(1, "dev.team"), new Payment(2, "client-2")));
                  System.out.println("@PreFilter на List.of(...): прошло, элементов " + r.size() + ", класс " + r.getClass().getName()); }
            catch (RuntimeException e) { System.out.println("@PreFilter на List.of(...): " + e.getClass().getName()); }
        }
    }

    static double best(java.util.function.IntSupplier r) {
        double best = Double.MAX_VALUE;
        for (int i = 0; i < 10; i++) { long t = System.nanoTime(); r.getAsInt(); best = Math.min(best, (System.nanoTime() - t) / 1e6); }
        return best;
    }
}
