package checks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

/**
 * Разд. 7.1: делает ли issuer-uri сетевой вызов при старте приложения.
 * IdP нет вовсе: issuer-uri указывает на закрытый порт. Цепочку собирает автоконфигурация Spring Boot.
 */
@SpringBootApplication
public class IssuerStart {

    @RestController
    static class Api {
        @GetMapping("/api/payments") String payments() { return "платежи"; }
    }

    public static void main(String[] args) throws Exception {
        SpringApplication app = new SpringApplication(IssuerStart.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off",
                "spring.security.oauth2.resourceserver.jwt.issuer-uri", "http://127.0.0.1:1/realms/tundra"));
        long t0 = System.nanoTime();
        try (ConfigurableApplicationContext ctx = app.run(args)) {
            System.out.printf("приложение с issuer-uri на недоступный IdP запустилось за %d мс%n", (System.nanoTime() - t0) / 1_000_000);
            String base = "http://localhost:" + ctx.getEnvironment().getProperty("local.server.port");
            HttpClient http = HttpClient.newHttpClient();
            for (int i = 1; i <= 2; i++) {
                HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(base + "/api/payments"))
                        .header("Authorization", "Bearer eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ4In0.c2ln").build(),
                        HttpResponse.BodyHandlers.ofString());
                System.out.printf("запрос %d с Bearer-токеном -> HTTP %d, WWW-Authenticate: %s%n", i, r.statusCode(),
                        r.headers().firstValue("WWW-Authenticate").orElse("нет"));
            }
        }
    }
}
