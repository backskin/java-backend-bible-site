package checks;

import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;

import java.time.Instant;
import java.util.List;

/** Разд. 7.2: что делает JwtClaimValidator, если claim в токене нет, а предикат null не ждёт. */
public class ClaimNull {
    public static void main(String[] args) {
        Jwt noAzp = Jwt.withTokenValue("t").header("alg", "RS256").subject("dev.team")
                .issuedAt(Instant.now()).expiresAt(Instant.now().plusSeconds(300)).build();
        JwtClaimValidator<String> azp = new JwtClaimValidator<>("azp", v -> v.equals("mobile-app"));
        JwtClaimValidator<List<String>> aud = new JwtClaimValidator<>("aud", v -> v.contains("payments-api"));
        for (var e : List.of(java.util.Map.entry("azp", azp), java.util.Map.entry("aud", aud))) {
            try {
                OAuth2TokenValidatorResult r = e.getValue().validate(noAzp);
                System.out.println("нет claim " + e.getKey() + ": hasErrors=" + r.hasErrors() + ", " +
                        r.getErrors().stream().map(x -> x.getErrorCode() + " / " + x.getDescription()).toList());
            } catch (RuntimeException ex) {
                System.out.println("нет claim " + e.getKey() + ": исключение " + ex.getClass().getName());
            }
        }
        System.out.println("spring-security-oauth2-jose: " + Jwt.class.getPackage().getImplementationVersion());
    }
}
