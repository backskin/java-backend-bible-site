package checks;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

/** Разд. 5.5: сколько элементов parallelStream() видят SecurityContext вызывающего потока. */
public class ParallelCtx {
    public static void main(String[] args) {
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken("dev.team", "n", AuthorityUtils.createAuthorityList("ROLE_USER")));
        System.out.println("ядер: " + Runtime.getRuntime().availableProcessors());
        for (int run = 1; run <= 3; run++) {
            AtomicInteger with = new AtomicInteger(), without = new AtomicInteger();
            Set<String> threads = ConcurrentHashMap.newKeySet();
            IntStream.range(0, 1000).parallel().forEach(i -> {
                busy();
                threads.add(Thread.currentThread().getName().replaceAll("\\d+$", "N"));
                if (SecurityContextHolder.getContext().getAuthentication() != null) with.incrementAndGet(); else without.incrementAndGet();
            });
            System.out.printf("прогон %d: с контекстом %d, без контекста %d из 1000; потоки: %s%n", run, with.get(), without.get(), threads);
        }
        long w = IntStream.range(0, 1000).filter(i -> SecurityContextHolder.getContext().getAuthentication() != null).count();
        System.out.println("обычный stream(): с контекстом " + w + " из 1000");
    }

    static void busy() { long x = 0; for (int i = 0; i < 20_000; i++) x += i; if (x == 42) System.out.print(""); }
}
