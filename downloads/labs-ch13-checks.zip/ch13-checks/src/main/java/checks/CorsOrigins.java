package checks;

import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

/** Разд. 9.3: как CorsConfiguration сравнивает Origin из запроса с allowedOrigins (схема входит в origin). */
public class CorsOrigins {
    public static void main(String[] args) {
        String origin = "https://app.example.com";
        for (List<String> allowed : List.of(List.of("app.example.com"), List.of("https://app.example.com"),
                List.of("https://app.example.com/"), List.of("*"))) {
            CorsConfiguration c = new CorsConfiguration();
            c.setAllowedOrigins(allowed);
            String r;
            try { r = String.valueOf(c.checkOrigin(origin)); } catch (RuntimeException e) { r = e.getClass().getSimpleName() + ": " + e.getMessage(); }
            System.out.printf("allowedOrigins=%-28s Origin: %s -> разрешённый origin: %s%n", allowed, origin, r);
        }
        CorsConfiguration star = new CorsConfiguration();
        star.setAllowedOrigins(List.of("*"));
        star.setAllowCredentials(true);
        try { star.checkOrigin(origin); System.out.println("* и allowCredentials=true: прошло"); }
        catch (RuntimeException e) { System.out.println("* и allowCredentials=true: " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
    }
}
