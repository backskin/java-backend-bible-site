package checks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * Разд. 6.4 и 14: старая аннотация @EnableGlobalMethodSecurity без prePostEnabled (как в примере одной из книг о Spring 5)
 * против @EnableMethodSecurity. Пользователь с ролью USER вызывает метод с @PreAuthorize("hasRole('ADMIN')").
 */
@SpringBootApplication
public class GlobalMethod {

    @Service
    public static class Orders {
        @PreAuthorize("hasRole('ADMIN')")
        public String deleteAllOrders() { return "все заказы удалены"; }
    }

    @Configuration @Profile("global") @SuppressWarnings("deprecation") @EnableGlobalMethodSecurity static class Global {}
    @Configuration @Profile("global-prepost") @SuppressWarnings("deprecation") @EnableGlobalMethodSecurity(prePostEnabled = true) static class GlobalPrePost {}
    @Configuration @Profile("method") @EnableMethodSecurity static class Method {}

    public static void main(String[] args) {
        for (String profile : new String[]{"global", "global-prepost", "method"}) {
            SpringApplication app = new SpringApplication(GlobalMethod.class);
            app.setAdditionalProfiles(profile);
            try (ConfigurableApplicationContext ctx = app.run("--logging.level.root=OFF", "--spring.main.banner-mode=off",
                    "--spring.main.web-application-type=none")) {
                SecurityContextHolder.getContext().setAuthentication(
                        new UsernamePasswordAuthenticationToken("dev.team", "n", AuthorityUtils.createAuthorityList("ROLE_USER")));
                String r;
                try { r = ctx.getBean(Orders.class).deleteAllOrders(); }
                catch (RuntimeException e) { r = e.getClass().getSimpleName(); }
                System.out.printf("%-58s -> %s%n", switch (profile) {
                    case "global" -> "@EnableGlobalMethodSecurity (без параметров), роль USER";
                    case "global-prepost" -> "@EnableGlobalMethodSecurity(prePostEnabled = true), роль USER";
                    default -> "@EnableMethodSecurity, роль USER";
                }, r);
                SecurityContextHolder.clearContext();
            } catch (RuntimeException e) {
                Throwable c = e; while (c.getCause() != null) c = c.getCause();
                System.out.printf("%-58s -> приложение не запустилось: %s: %s%n", profile, c.getClass().getSimpleName(), c.getMessage());
            }
        }
    }
}
