package checks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;
import java.util.TreeMap;

/** Разд. 9.4: какие заголовки безопасности ставит HeaderWriterFilter по умолчанию (запрос по HTTP, поэтому без HSTS). */
@SpringBootApplication
public class HeadersDefault {

    @RestController
    static class Api { @GetMapping("/api/rates") String rates() { return "курсы"; } }

    @Bean
    SecurityFilterChain chain(HttpSecurity http) throws Exception {
        return http.authorizeHttpRequests(a -> a.anyRequest().permitAll()).httpBasic(Customizer.withDefaults()).build();
    }

    public static void main(String[] args) throws Exception {
        SpringApplication app = new SpringApplication(HeadersDefault.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run(args)) {
            String base = "http://localhost:" + ctx.getEnvironment().getProperty("local.server.port");
            HttpResponse<String> r = HttpClient.newHttpClient().send(HttpRequest.newBuilder(URI.create(base + "/api/rates")).build(),
                    HttpResponse.BodyHandlers.ofString());
            System.out.println("GET /api/rates (permitAll, HTTP) -> " + r.statusCode());
            new TreeMap<>(r.headers().map()).forEach((k, v) -> {
                if (!k.equalsIgnoreCase("date") && !k.equalsIgnoreCase("content-length") && !k.equalsIgnoreCase("keep-alive")
                        && !k.equalsIgnoreCase("connection")) System.out.println("  " + k + ": " + String.join(", ", v));
            });
        }
    }
}
