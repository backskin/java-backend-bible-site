package checks;

import com.sun.net.httpserver.HttpServer;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.client.AuthorizedClientServiceOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.ClientCredentialsOAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Разд. 8.2–8.4: сколько раз AuthorizedClientServiceOAuth2AuthorizedClientManager ходит в token endpoint.
 * Token endpoint — встроенный HttpServer JDK, отвечает с задержкой 100 мс и считает запросы.
 */
public class ClientRace {

    static final AtomicInteger TOKEN_REQUESTS = new AtomicInteger();
    static volatile int expiresIn = 300;

    public static void main(String[] args) throws Exception {
        HttpServer idp = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        idp.createContext("/token", ex -> {
            int n = TOKEN_REQUESTS.incrementAndGet();
            try { Thread.sleep(100); } catch (InterruptedException ignored) { }
            byte[] body = ("{\"access_token\":\"t-" + n + "\",\"token_type\":\"Bearer\",\"expires_in\":" + expiresIn + "}")
                    .getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().add("Content-Type", "application/json");
            ex.sendResponseHeaders(200, body.length);
            ex.getResponseBody().write(body);
            ex.close();
        });
        idp.setExecutor(Executors.newFixedThreadPool(64));
        idp.start();

        ClientRegistration reg = ClientRegistration.withRegistrationId("limits-svc")
                .clientId("payments-service").clientSecret("secret")
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .tokenUri("http://127.0.0.1:" + idp.getAddress().getPort() + "/token")
                .build();

        System.out.println("--- 1. expires_in = 300 с, 50 одновременных вызовов при пустом хранилище");
        run(reg, null, 50);
        System.out.println("--- 2. expires_in = 300 с, токен получен, затем часы сдвинуты на 301 с, 50 одновременных вызовов");
        Manager m = manager(reg);
        m.authorize();
        TOKEN_REQUESTS.set(0);
        m.clock.set(Clock.offset(Clock.systemUTC(), Duration.ofSeconds(301)));
        parallel(m, 50);
        System.out.println("--- 3. expires_in = 30 с (короче clockSkew по умолчанию 60 с), 10 вызовов подряд");
        expiresIn = 30;
        TOKEN_REQUESTS.set(0);
        Manager seq = manager(reg);
        Set<String> tokens = ConcurrentHashMap.newKeySet();
        for (int i = 0; i < 10; i++) tokens.add(seq.authorize());
        System.out.printf("запросов к token endpoint: %d, разных токенов: %d%n", TOKEN_REQUESTS.get(), tokens.size());
        System.out.println("--- 4. то же, но clockSkew = 5 с");
        TOKEN_REQUESTS.set(0);
        Manager skew = manager(reg);
        skew.provider.setClockSkew(Duration.ofSeconds(5));
        for (int i = 0; i < 10; i++) skew.authorize();
        System.out.printf("запросов к token endpoint: %d%n", TOKEN_REQUESTS.get());
        idp.stop(0);
        System.exit(0);
    }

    record Manager(AuthorizedClientServiceOAuth2AuthorizedClientManager delegate,
                   ClientCredentialsOAuth2AuthorizedClientProvider provider, AtomicReference<Clock> clock) {
        String authorize() {
            OAuth2AuthorizeRequest req = OAuth2AuthorizeRequest.withClientRegistrationId("limits-svc")
                    .principal(new AnonymousAuthenticationToken("svc", "payments-service", AuthorityUtils.createAuthorityList("ROLE_SERVICE")))
                    .build();
            return delegate.authorize(req).getAccessToken().getTokenValue();
        }
    }

    static Manager manager(ClientRegistration reg) {
        var repo = new InMemoryClientRegistrationRepository(reg);
        var service = new InMemoryOAuth2AuthorizedClientService(repo);
        var provider = new ClientCredentialsOAuth2AuthorizedClientProvider();
        AtomicReference<Clock> clock = new AtomicReference<>(Clock.systemUTC());
        provider.setClock(new Clock() {
            @Override public ZoneOffset getZone() { return ZoneOffset.UTC; }
            @Override public Clock withZone(java.time.ZoneId z) { return this; }
            @Override public Instant instant() { return clock.get().instant(); }
        });
        var m = new AuthorizedClientServiceOAuth2AuthorizedClientManager(repo, service);
        m.setAuthorizedClientProvider(provider);
        return new Manager(m, provider, clock);
    }

    static void run(ClientRegistration reg, Clock unused, int threads) throws Exception {
        TOKEN_REQUESTS.set(0);
        parallel(manager(reg), threads);
    }

    static void parallel(Manager m, int threads) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        Set<String> tokens = ConcurrentHashMap.newKeySet();
        CountDownLatch done = new CountDownLatch(threads);
        for (int i = 0; i < threads; i++) pool.submit(() -> {
            try { start.await(); tokens.add(m.authorize()); } catch (Exception e) { System.out.println("ошибка: " + e); }
            finally { done.countDown(); }
        });
        start.countDown();
        done.await();
        pool.shutdown();
        System.out.printf("запросов к token endpoint: %d, разных токенов у вызывающих: %d%n", TOKEN_REQUESTS.get(), tokens.size());
    }
}
