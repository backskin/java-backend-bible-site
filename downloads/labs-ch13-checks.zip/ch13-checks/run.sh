#!/usr/bin/env bash
# Опыты гл. 13 без Docker на Spring Boot 4.1.1 / Spring Security 7.1.x, Temurin 21.
# Запуск: ./run.sh [класс...] — без аргументов все; вывод каждого в sNN-<класс>.txt.
set -uo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt >/dev/null || { mvn -q -DskipTests compile 2>&1 | grep ERROR | head -5; exit 1; }
CP="$(cygpath -w "$PWD/target/classes" 2>/dev/null || echo target/classes);$(cat cp.txt)"
[ "$(uname -o 2>/dev/null)" = "Msys" ] || CP="${CP//;/:}"
declare -A OUT=([ParallelCtx]=s05-parallel-ctx [HeadersDefault]=s09-headers [CorsOrigins]=s09-cors-origins [GlobalMethod]=s06-global-method [IssuerStart]=s07-issuer-start [ClaimNull]=s07-claim-null [ClientRace]=s08-client-race [PostFilterCost]=s06-postfilter)
mains=("$@"); [ ${#mains[@]} -eq 0 ] && mains=(IssuerStart ClaimNull ClientRace PostFilterCost GlobalMethod CorsOrigins HeadersDefault ParallelCtx)
for m in "${mains[@]}"; do
  f="${OUT[$m]}.txt"
  echo "== $m -> $f"
  timeout 300 "$J" -Dstdout.encoding=UTF-8 -cp "$CP" "checks.$m" 2>&1 \
    | grep -v "WARNING.*\(sun.misc\|Unsafe\|restricted method\|native access\)" \
    | sed -e "s#$HOME#~#g" -e 's#C:\\Users\\[^\\]*#~#g' -e "s/$(whoami)/dev.team/g" > "$f"
  cat "$f"
done
