# Spring Security 7.1 без внешнего IdP: старт сервера ресурсов, проверка claim, гонка клиента OAuth2, @PostFilter, CORS, заголовки

Стенд к главе 13 (опыты без Docker). Восемь программ в пакете `checks`: `IssuerStart` (приложение с `issuer-uri` на недоступный IdP стартует, а первый запрос с токеном получает 401 и `resource_metadata` в `WWW-Authenticate`), `ClaimNull` (`JwtClaimValidator` при отсутствующем claim), `ClientRace` (50 одновременных вызовов `OAuth2AuthorizedClientManager` при пустом хранилище - 50 запросов к token endpoint), `PostFilterCost` (`@PostFilter` на 10 000 элементов), `GlobalMethod` (`@EnableGlobalMethodSecurity` на Security 7 с `spring-security-access` и без), `CorsOrigins` (`allowedOrigins` без схемы не совпадает), `HeadersDefault` (заголовки по умолчанию на HTTP и HTTPS), `ParallelCtx` (контекст безопасности в `parallelStream()`). `s14-api-7.1.1.txt` - `javap` по методам DSL, к которым обращаются книги на Security 5. Выводы автора - `sNN-*.txt`.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, bash.

## Запуск

```bash
bash run.sh
```

Один класс: `bash run.sh ClientRace`. В IDEA на каждый класс есть конфигурация.

## Что должно получиться

`ParallelCtx`: контекст виден только в части задач (у автора 124 из 1000 на 16 ядрах); `PostFilterCost`: 5,4 мс против 0,11 мс; `GlobalMethod`: без `spring-security-access` приложение не стартует с подсказкой перейти на `@EnableMethodSecurity`.
