package dev.team.trace;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.CompletableFuture;

/** Скоринг кредитной заявки: контроллер, асинхронный запрос в бюро кредитных историй. */
@SpringBootApplication
@EnableAsync
public class TracingApp {
    public static void main(String[] args) { SpringApplication.run(TracingApp.class, args); }

    /** Переносит свои ключи MDC в поток исполнителя; включается флагом lab.mdc-decorator. */
    @org.springframework.context.annotation.Bean
    @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty("lab.mdc-decorator")
    org.springframework.core.task.TaskDecorator mdcDecorator() {
        return task -> {
            var ctx = org.slf4j.MDC.getCopyOfContextMap();
            return () -> {
                if (ctx != null) ctx.forEach((k, v) -> { if (org.slf4j.MDC.get(k) == null) org.slf4j.MDC.put(k, v); });
                try { task.run(); } finally { org.slf4j.MDC.remove("applicationId"); }
            };
        };
    }

    @Service
    static class Bureau {
        private static final Logger log = LoggerFactory.getLogger(Bureau.class);

        @Async
        public CompletableFuture<Integer> score(String id) {
            log.info("запрос в бюро кредитных историй по заявке {}", id);
            return CompletableFuture.completedFuture(712);
        }
    }

    @RestController
    static class ScoringController {
        private static final Logger log = LoggerFactory.getLogger(ScoringController.class);
        private final Bureau bureau;
        ScoringController(Bureau bureau) { this.bureau = bureau; }

        @GetMapping("/api/scoring/{id}")
        String score(@PathVariable String id) throws Exception {
            org.slf4j.MDC.put("applicationId", id);
            log.info("заявка {} принята на скоринг", id);
            int s = bureau.score(id).get();
            log.info("скоринговый балл {}", s);
            org.slf4j.MDC.remove("applicationId");
            return "score=" + s;
        }
    }
}
