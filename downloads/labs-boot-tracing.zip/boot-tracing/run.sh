#!/usr/bin/env bash
# Опыт разд. 9.5: запуск из labs/boot-tracing: bash run.sh "<заголовок>" [доп. аргументы приложения]
CP="target/classes;$(cat cp.txt)"
label="$1"; shift
java -Dstdout.encoding=UTF-8 -cp "$CP" dev.team.trace.TracingApp "$@" > app.log 2>&1 &
for i in $(seq 1 60); do curl -s localhost:18097/actuator/health > /dev/null && break; sleep 0.5; done
echo "== $label"
curl -s localhost:18097/api/scoring/CR-1 > /dev/null
curl -s -H "traceparent: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01" localhost:18097/api/scoring/CR-2 > /dev/null
sleep 1
grep -aF 'TracingApp$' app.log | sed -E 's/^[0-9T:.+-]+ +INFO [0-9]+ --- //' | sed 's/^/   /'
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='java.exe'\" | Where-Object { \$_.CommandLine -match 'dev.team.trace.TracingApp' } | ForEach-Object { Stop-Process -Id \$_.ProcessId -Force }"
