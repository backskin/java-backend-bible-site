# Трассировка в Spring Boot 4.1 с OpenTelemetry: traceId в журнале, входящий traceparent, структурный журнал ECS

Стенд к главе 10, раздел 9.5. Сервис скоринга `TracingApp` (Spring Boot 4.1.1, Actuator, `spring-boot-starter-opentelemetry`) принимает два запроса, второй с заголовком `traceparent`, и пишет в журнал строки с `traceId` и `spanId`: в шаблоне по умолчанию и в формате ECS с полем `applicationId` из MDC. Скрипт `run.sh` запускает приложение, делает оба запроса и вырезает строки из журнала. Выводы автора - `s10-tracing.txt`, `s10-tracing-ecs.txt`.

## Что нужно

- JDK 21, Maven, bash с `curl` (Git Bash на Windows; остановка процесса в скрипте через PowerShell).

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && bash run.sh "OpenTelemetry, шаблон по умолчанию"
```

Вариант ECS: `bash run.sh "ECS" --logging.structured.format.console=ecs`. Приложение слушает порт 18097. В IDEA есть конфигурация `TracingApp` и Shell-конфигурация `run`.

## Что должно получиться

У второго запроса `traceId` равен `4bf92f3577b34da6a3ce929d0e0e4736` из заголовка `traceparent`, у первого - свой; в ECS те же значения лежат в полях `traceId` и `spanId`.
