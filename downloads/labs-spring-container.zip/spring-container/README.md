# Контейнер Spring Framework 7.0: refresh, жизненный цикл, прокси, AOP, события, настройки, фоновые задачи

Стенд к главе 09, разделы 1–13 и инциденты. Один проект Maven на Spring Framework 7.0.9 (плюс Spring Data JPA, Hibernate, H2 для опытов с транзакциями), в котором каждый опыт главы - отдельный класс с `main` в пакете по теме: `mortgage.lab.ContainerLab` (три способа описать бины), `refresh` (шаги `refresh()`, ранние бины, переопределение), `lifecycle`, `cycles` (циклы и ранние ссылки), `config` (режимы `@Configuration`, `final`), `proxy` и `aop` (JDK-прокси против CGLIB, порядок советов, pointcut), `events` (в том числе `@TransactionalEventListener` после коммита), `env` (источники свойств, профили, условия, SpEL, конверсия), `async` (`@Async`, `@Scheduled`, пулы, остановка), `ext` (расширение контейнера, сканирование), `scopes`, `ltw`, `patterns` (singleton в контексте, гл. 32), `incidents` (разборы 16.1–16.4). Выводы автора - `s09-incidents.txt`, `s09-incidents2.txt`, `s09-tx-trace.txt`; остальные выводы приведены в главе в сносках.

## Что нужно

- JDK 21 и Maven.

## Запуск

Сборка и classpath один раз:

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt
```

Затем любой опыт:

```bash
java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" dev.team.fx.ManualWiring
```

(на Linux и macOS разделитель `:`). Для `IncidentsLab2` журнал транзакций на уровне TRACE включается файлом `logback-tx-trace.xml`: `-Dlogback.configurationFile=logback-tx-trace.xml`. В IDEA на каждый класс с `main` есть своя конфигурация.

## Что должно получиться

Вывод каждого класса приведен в соответствующем разделе главы без изменений, кроме сокращенных имен служебных бинов.
