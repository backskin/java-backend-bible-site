package dev.team.events;

import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.PersistenceContext;
import org.h2.jdbcx.JdbcDataSource;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import javax.sql.DataSource;
import java.util.Properties;

/** Опыт разд. 10.4: запись аудита через JPA в фазе AFTER_COMMIT без новой транзакции и с ней. */
public class JpaAfterCommitLab {
    @Entity(name = "AuditRecord")
    public static class AuditRecord {
        @Id @GeneratedValue Long id;
        long orderId; String note;
        protected AuditRecord() { }
        AuditRecord(long orderId, String note) { this.orderId = orderId; this.note = note; }
    }

    @Entity(name = "PaymentOrder")
    public static class PaymentOrder {
        @Id Long id;
        protected PaymentOrder() { }
        PaymentOrder(long id) { this.id = id; }
    }

    public record OrderAccepted(long orderId) {}

    public static class OrderService {
        @PersistenceContext EntityManager em;
        final ApplicationEventPublisher events;
        public OrderService(ApplicationEventPublisher events) { this.events = events; }
        @Transactional public void accept(long id) { em.persist(new PaymentOrder(id)); events.publishEvent(new OrderAccepted(id)); }
    }

    public static class SameTxAudit {
        @PersistenceContext EntityManager em;
        @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
        public void audit(OrderAccepted e) {
            var r = new AuditRecord(e.orderId(), "без REQUIRES_NEW");
            em.persist(r);
            System.out.println("   AFTER_COMMIT: persist выполнен, id=" + r.id + ", транзакция активна: "
                    + org.springframework.transaction.support.TransactionSynchronizationManager.isActualTransactionActive());
        }
    }

    public static class NewTxAudit {
        @PersistenceContext EntityManager em;
        @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
        @Transactional(propagation = Propagation.REQUIRES_NEW)
        public void audit(OrderAccepted e) { em.persist(new AuditRecord(e.orderId(), "REQUIRES_NEW")); }
    }

    @Configuration @EnableTransactionManagement
    static class Cfg {
        @Bean DataSource dataSource() { var ds = new JdbcDataSource(); ds.setURL("jdbc:h2:mem:jpa;DB_CLOSE_DELAY=-1"); ds.setUser("sa"); return ds; }
        @Bean LocalContainerEntityManagerFactoryBean emf(DataSource ds) {
            var f = new LocalContainerEntityManagerFactoryBean();
            f.setDataSource(ds);
            f.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
            f.setManagedTypes(org.springframework.orm.jpa.persistenceunit.PersistenceManagedTypes.of(AuditRecord.class.getName(), PaymentOrder.class.getName()));
            var p = new Properties(); p.put("hibernate.hbm2ddl.auto", "create"); p.put("hibernate.show_sql", "false");
            f.setJpaProperties(p);
            return f;
        }
        @Bean PlatformTransactionManager tx(EntityManagerFactory emf) { return new JpaTransactionManager(emf); }
        @Bean OrderService orderService(ApplicationEventPublisher p) { return new OrderService(p); }
        @Bean SameTxAudit sameTxAudit() { return new SameTxAudit(); }
        @Bean NewTxAudit newTxAudit() { return new NewTxAudit(); }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            ctx.getBean(OrderService.class).accept(1);
            var em = ctx.getBean(EntityManagerFactory.class).createEntityManager();
            System.out.println("поручений в базе: " + em.createQuery("select count(o) from PaymentOrder o").getSingleResult());
            em.createQuery("select a.note from AuditRecord a", String.class).getResultList()
                    .forEach(n -> System.out.println("аудит в базе: " + n));
            em.close();
        }
    }
}
