package dev.team.refresh;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Опыт 3: два @Bean-метода с одним именем бина в разных конфигурациях. */
public class OverrideLab {
    @Configuration static class LimitsA { @Bean String dailyLimit() { return "из LimitsA: 100 000"; } }
    @Configuration static class LimitsB { @Bean String dailyLimit() { return "из LimitsB: 500 000"; } }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(LimitsA.class, LimitsB.class)) {
            System.out.println("бин dailyLimit = " + ctx.getBean("dailyLimit"));
        }
        try (var ctx = new AnnotationConfigApplicationContext()) {
            ctx.setAllowBeanDefinitionOverriding(false);
            ctx.register(LimitsA.class, LimitsB.class);
            ctx.refresh();
        } catch (Exception e) {
            System.out.println("с запретом переопределения: " + e.getClass().getSimpleName());
        }
    }
}
