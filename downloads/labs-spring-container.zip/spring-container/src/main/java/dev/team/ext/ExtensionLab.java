package dev.team.ext;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.filter.AnnotationTypeFilter;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Proxy;
import java.util.Arrays;

/** Опыт разд. 13.1: своя аннотация @Enable…, ImportSelector, регистратор клиентов из интерфейсов, FactoryBean. */
public class ExtensionLab {
    // ---- ImportSelector: способ расчётов выбирается атрибутом аннотации
    interface Settlement { String name(); }
    @Configuration static class SbpSettlementConfig { @Bean Settlement settlement() { return () -> "СБП, мгновенные переводы"; } }
    @Configuration static class BatchSettlementConfig { @Bean Settlement settlement() { return () -> "пакетный клиринг раз в час"; } }

    @Target(ElementType.TYPE) @Retention(RetentionPolicy.RUNTIME)
    @Import(SettlementModeSelector.class)
    @interface EnableSettlement { String mode() default "batch"; }

    static class SettlementModeSelector implements ImportSelector {
        @Override public String[] selectImports(AnnotationMetadata md) {
            String mode = md.getAnnotations().get(EnableSettlement.class).getString("mode");
            System.out.println("   SettlementModeSelector: mode=" + mode + ", аннотация стоит на " + md.getClassName().replace("dev.team.ext.ExtensionLab$", ""));
            return new String[] {(mode.equals("sbp") ? SbpSettlementConfig.class : BatchSettlementConfig.class).getName()};
        }
    }

    @Configuration @EnableSettlement(mode = "sbp") static class SbpApp { }
    @Configuration @EnableSettlement static class DefaultApp { }

    // ---- ImportBeanDefinitionRegistrar: клиенты к банкам — только интерфейсы, реализации нет
    @Target(ElementType.TYPE) @Retention(RetentionPolicy.RUNTIME)
    public @interface BankClient { String url(); }

    @BankClient(url = "https://acquirer-a.example/api")
    public interface AcquirerAClient { String authorize(String pan, long kopecks); }

    @BankClient(url = "https://fraud.example/api")
    public interface AntifraudClient { String score(String pan, long kopecks); }

    /** Фабрика, которая по интерфейсу делает прокси JDK: вызов метода «уходит» по HTTP. */
    public static class BankClientFactoryBean implements FactoryBean<Object> {
        private Class<?> clientInterface;
        public void setClientInterface(Class<?> c) { clientInterface = c; }
        @Override public Object getObject() {
            String url = clientInterface.getAnnotation(BankClient.class).url();
            return Proxy.newProxyInstance(clientInterface.getClassLoader(), new Class<?>[] {clientInterface},
                    (p, m, a) -> m.getDeclaringClass() == Object.class ? m.invoke(this, a)
                            : "POST " + url + "/" + m.getName() + " " + Arrays.toString(a));
        }
        @Override public Class<?> getObjectType() { return clientInterface; }
    }

    static class BankClientsRegistrar implements ImportBeanDefinitionRegistrar {
        @Override public void registerBeanDefinitions(AnnotationMetadata md, BeanDefinitionRegistry registry) {
            var scanner = new ClassPathScanningCandidateComponentProvider(false) {
                @Override protected boolean isCandidateComponent(AnnotatedBeanDefinition bd) { return bd.getMetadata().isInterface(); }
            };
            scanner.addIncludeFilter(new AnnotationTypeFilter(BankClient.class));
            for (var candidate : scanner.findCandidateComponents("dev.team.ext")) {
                String name = candidate.getBeanClassName();
                var bd = BeanDefinitionBuilder.genericBeanDefinition(BankClientFactoryBean.class)
                        .addPropertyValue("clientInterface", name).getBeanDefinition();
                String beanName = name.substring(name.lastIndexOf('$') + 1);
                registry.registerBeanDefinition(beanName, bd);
                System.out.println("   регистратор: " + beanName + " -> BankClientFactoryBean");
            }
        }
    }

    @Configuration @Import(BankClientsRegistrar.class) static class ClientsApp { }

    public static void main(String[] args) {
        System.out.println("== @EnableSettlement(mode = \"sbp\")");
        try (var ctx = new AnnotationConfigApplicationContext(SbpApp.class)) { System.out.println("   Settlement: " + ctx.getBean(Settlement.class).name()); }
        System.out.println("== @EnableSettlement без атрибута");
        try (var ctx = new AnnotationConfigApplicationContext(DefaultApp.class)) { System.out.println("   Settlement: " + ctx.getBean(Settlement.class).name()); }
        System.out.println("== клиенты к банкам из интерфейсов");
        try (var ctx = new AnnotationConfigApplicationContext(ClientsApp.class)) {
            var a = ctx.getBean(AcquirerAClient.class);
            System.out.println("   " + a.authorize("2200700000000001", 150_000));
            System.out.println("   " + ctx.getBean(AntifraudClient.class).score("2200700000000001", 150_000));
            System.out.println("   getBean(\"AcquirerAClient\"): " + ctx.getBean("AcquirerAClient").getClass().getSimpleName()
                    + ", getBean(\"&AcquirerAClient\"): " + ctx.getBean("&AcquirerAClient").getClass().getSimpleName());
        }
    }
}
