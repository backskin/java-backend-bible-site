package dev.team.env;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;

/** Опыт разд. 11.1: многодокументный YAML, переменные окружения, аргументы командной строки в Spring Boot 4.1.1. */
public class BootConfigLab {
    public static class Tariff {
        @Value("${app.fee-percent}") String percent;
        @Value("${app.fee-max:не задан}") String max;
    }
    public static class Strict { @Value("${app.fee-limit}") String limit; }

    @SpringBootConfiguration @EnableAutoConfiguration
    public static class App { @Bean Tariff tariff() { return new Tariff(); } }

    @SpringBootConfiguration @EnableAutoConfiguration
    public static class StrictApp { @Bean Strict strict() { return new Strict(); } }

    static void run(String title, Class<?> app, String... args) {
        var a = new SpringApplication(app);
        a.setWebApplicationType(WebApplicationType.NONE);
        a.setBannerMode(Banner.Mode.OFF);
        a.setLogStartupInfo(false);
        System.out.print("== " + title + ": ");
        try (var ctx = a.run(args)) {
            if (app == App.class) System.out.println("app.fee-percent=" + ctx.getBean(Tariff.class).percent);
            else System.out.println("app.fee-limit=" + ctx.getBean(Strict.class).limit);
        } catch (Exception e) {
            Throwable r = e; while (r.getCause() != null && !(r.getMessage() != null && r.getMessage().contains("spring.profiles"))) r = r.getCause();
            System.out.println(r.getClass().getSimpleName() + ": " + r.getMessage().replaceAll("\\s+", " "));
        }
    }

    public static void main(String[] args) {
        String oldYml = "--spring.config.location=classpath:bootcfg/old-syntax.yml";
        String newYml = "--spring.config.location=classpath:bootcfg/new-syntax.yml";
        run("старый ключ spring.profiles", App.class, oldYml, "--spring.profiles.active=prod");
        run("spring.config.activate.on-profile, профиль не задан", App.class, newYml);
        run("spring.config.activate.on-profile, профиль prod", App.class, newYml, "--spring.profiles.active=prod");
        run("профиль prod и аргумент --app.fee-percent=2.5", App.class, newYml, "--spring.profiles.active=prod", "--app.fee-percent=2.5");
        run("переменная окружения APP_FEE_PERCENT", App.class, newYml);
        run("заполнитель без значения по умолчанию", StrictApp.class, newYml);
    }
}
