package dev.team.mortgage;

import dev.team.mortgage.service.MortgageCalculatorService;
import org.springframework.stereotype.Component;

@Component
public class App {
    final MortgageCalculatorService calculatorService;

    public App(MortgageCalculatorService calculatorService) {
        this.calculatorService = calculatorService;
    }

    String monthlyPayment() {
        return String.format(java.util.Locale.US, "Monthly Payment: $%,.2f",
                calculatorService.payment(250_000, 6.5, 30));
    }
}
