package dev.team.fx;

import java.math.BigDecimal;

/** Источник курсов: сколько рублей стоит единица валюты. */
public interface RateSource {
    BigDecimal rubPer(String currency);
}
