package dev.team.scopes;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Fallback;

/** Опыт: @Fallback — бин, который выбирается, только если других кандидатов нет. */
public class FallbackLab {
    public interface RateSource { String name(); }

    @Configuration static class Cfg {
        @Bean @Fallback RateSource fixedRates() { return () -> "фиксированные курсы (запасной)"; }
        @Bean RateSource cbrRates() { return () -> "курсы ЦБ"; }
    }
    @Configuration static class OnlyFallback {
        @Bean @Fallback RateSource fixedRates() { return () -> "фиксированные курсы (запасной)"; }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            System.out.println("два кандидата, один @Fallback: внедряется " + ctx.getBean(RateSource.class).name());
        }
        try (var ctx = new AnnotationConfigApplicationContext(OnlyFallback.class)) {
            System.out.println("только @Fallback: внедряется " + ctx.getBean(RateSource.class).name());
        }
    }
}
