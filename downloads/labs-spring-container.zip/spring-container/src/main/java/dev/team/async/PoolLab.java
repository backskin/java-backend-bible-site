package dev.team.async;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/** Опыт разд. 12.1: когда ThreadPoolExecutor создаёт потоки сверх ядра и что делает при насыщении. */
public class PoolLab {
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    /** 50 уведомлений по 100 мс в пул core=2, max=8 с очередью заданной ёмкости. */
    static void burst(String title, int queueCapacity, ThreadPoolExecutor.AbortPolicy policy) throws Exception {
        var pool = new ThreadPoolExecutor(2, 8, 60, TimeUnit.SECONDS,
                queueCapacity == 0 ? new SynchronousQueue<>() : new LinkedBlockingQueue<>(queueCapacity), policy);
        int accepted = 0, rejected = 0, maxSize = 0;
        for (int i = 0; i < 50; i++) {
            try { pool.execute(() -> sleep(100)); accepted++; } catch (RejectedExecutionException e) { rejected++; }
            maxSize = Math.max(maxSize, pool.getPoolSize());
        }
        System.out.printf("%-34s потоков максимум %d, принято %d, отклонено %d, в очереди %d%n", title, maxSize, accepted, rejected, pool.getQueue().size());
        pool.shutdown(); pool.awaitTermination(10, TimeUnit.SECONDS);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== core=2, max=8, 50 задач по 100 мс");
        burst("очередь 500:", 500, new ThreadPoolExecutor.AbortPolicy());
        burst("очередь 10:", 10, new ThreadPoolExecutor.AbortPolicy());
        burst("SynchronousQueue (ёмкость 0):", 0, new ThreadPoolExecutor.AbortPolicy());

        System.out.println("== CallerRunsPolicy при насыщении");
        var pool = new ThreadPoolExecutor(1, 1, 0, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1), new ThreadPoolExecutor.CallerRunsPolicy());
        Set<String> threads = ConcurrentHashMap.newKeySet();
        for (int i = 0; i < 5; i++) pool.execute(() -> { threads.add(Thread.currentThread().getName()); sleep(100); });
        pool.shutdown(); pool.awaitTermination(5, TimeUnit.SECONDS);
        System.out.println("   задачи выполнялись в потоках: " + threads);

        System.out.println("== core=0 и очередь на 100 мест");
        var zero = new ThreadPoolExecutor(0, 4, 60, TimeUnit.SECONDS, new LinkedBlockingQueue<>(100));
        var done = new CountDownLatch(1);
        long t = System.nanoTime();
        zero.execute(done::countDown);
        boolean ran = done.await(2, TimeUnit.SECONDS);
        System.out.printf("   одна задача выполнена: %s, через %d мс, потоков в пуле %d%n", ran, (System.nanoTime() - t) / 1_000_000, zero.getPoolSize());
        zero.shutdown();

        System.out.println("== фабрики Executors");
        for (var e : new ThreadPoolExecutor[] {(ThreadPoolExecutor) Executors.newCachedThreadPool(), (ThreadPoolExecutor) Executors.newFixedThreadPool(4)}) {
            System.out.printf("   core=%d, max=%s, keepAlive=%d с, очередь %s%n", e.getCorePoolSize(),
                    e.getMaximumPoolSize() == Integer.MAX_VALUE ? "Integer.MAX_VALUE" : e.getMaximumPoolSize(),
                    e.getKeepAliveTime(TimeUnit.SECONDS), e.getQueue().getClass().getSimpleName());
            e.shutdown();
        }
    }
}
