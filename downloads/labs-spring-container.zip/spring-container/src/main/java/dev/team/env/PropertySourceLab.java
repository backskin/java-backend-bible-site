package dev.team.env;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.stereotype.Component;

/** Опыт разд. 11.1: источники свойств в «голом» Spring, их порядок и отсутствующие свойства. */
public class PropertySourceLab {
    @Configuration
    @PropertySource("classpath:env/fee.properties")
    @PropertySource("classpath:env/fee-${spring.profiles.active}.properties")
    static class ProfileFiles { }

    @Configuration
    @PropertySource("classpath:env/fee.properties")
    static class OneFile { }

    @Component
    static class Tariff {
        @Value("${fee.percent}") String percent;
        @Value("${fee.min}") String min;
        @Value("${fee.max:не задан}") String max;
    }

    @Component
    static class Strict { @Value("${fee.max}") String max; }

    @Configuration
    static class WithPlaceholderConfigurer {
        @org.springframework.context.annotation.Bean
        static org.springframework.context.support.PropertySourcesPlaceholderConfigurer pspc() {
            return new org.springframework.context.support.PropertySourcesPlaceholderConfigurer();
        }
    }

    static void run(String title, Class<?>... classes) {
        System.out.println("== " + title);
        try (var ctx = new AnnotationConfigApplicationContext(classes)) {
            var t = ctx.getBean(Tariff.class);
            if (ctx.containsBean("strict") || ctx.getBeanNamesForType(Strict.class).length > 0)
                System.out.println("   Strict.max = \"" + ctx.getBean(Strict.class).max + "\"");
            System.out.println("   fee.percent=" + t.percent + ", fee.min=" + t.min + ", fee.max=" + t.max);
            var env = (ConfigurableEnvironment) ctx.getEnvironment();
            System.out.print("   источники по порядку:");
            env.getPropertySources().forEach(ps -> System.out.print(" " + ps.getName().replace("class path resource ", "")));
            System.out.println();
        } catch (Exception e) {
            Throwable r = e; while (r.getCause() != null) r = r.getCause();
            System.out.println("   " + r.getClass().getSimpleName() + ": " + r.getMessage());
        }
    }

    public static void main(String[] args) {
        run("профиль не задан", ProfileFiles.class, Tariff.class);
        System.setProperty("spring.profiles.active", "prod");
        run("-Dspring.profiles.active=prod", ProfileFiles.class, Tariff.class);
        System.setProperty("fee.percent", "2.0");
        run("плюс -Dfee.percent=2.0", ProfileFiles.class, Tariff.class);
        System.clearProperty("fee.percent");
        run("свойство fee.max без значения по умолчанию", OneFile.class, Tariff.class, Strict.class);
        run("то же с PropertySourcesPlaceholderConfigurer", OneFile.class, WithPlaceholderConfigurer.class, Tariff.class, Strict.class);
    }
}
