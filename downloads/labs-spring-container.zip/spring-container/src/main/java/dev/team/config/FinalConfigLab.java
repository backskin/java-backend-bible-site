package dev.team.config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Опыт разд. 7: final-класс конфигурации и private @Bean-метод в полном режиме. */
public class FinalConfigLab {
    @Configuration
    public static final class FinalConfig {
        @Bean public String limits() { return "лимиты"; }
    }

    @Configuration
    public static class PrivateBeanMethod {
        @Bean private String rates() { return "курсы"; }
    }

    static void run(Class<?> cfg) {
        try (var ctx = new AnnotationConfigApplicationContext(cfg)) {
            System.out.println(cfg.getSimpleName() + ": контекст поднялся");
        } catch (Exception e) {
            System.out.println(cfg.getSimpleName() + ": " + e.getClass().getSimpleName() + ": "
                    + e.getMessage().replace("dev.team.config.FinalConfigLab$", "").replaceAll("\\s+", " "));
        }
    }

    public static void main(String[] args) {
        run(FinalConfig.class);
        run(PrivateBeanMethod.class);
    }
}
