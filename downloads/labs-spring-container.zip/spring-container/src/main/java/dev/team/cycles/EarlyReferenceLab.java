package dev.team.cycles;

import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/** Опыт: цикл через сеттеры и постпроцессор, который подменяет бин прокси. */
public class EarlyReferenceLab {

    @Component public static class Payments { Limits limits; public Payments() { System.out.println("   конструктор Payments, поток " + Thread.currentThread().getName()); } @Autowired void setLimits(Limits l) { System.out.println("   Payments.setLimits"); limits = l; } }
    @Component public static class Limits { Payments payments; public Limits() { System.out.println("   конструктор Limits, поток " + Thread.currentThread().getName()); } @Autowired void setPayments(Payments p) { System.out.println("   Limits.setPayments(" + p.getClass().getSimpleName() + ")"); payments = p; } }

    static Object proxyOf(Object bean) {
        ProxyFactory pf = new ProxyFactory(bean);
        pf.setProxyTargetClass(true);
        return pf.getProxy();
    }

    /** Подменяет Payments прокси только после инициализации. */
    public static class LateProxyBpp implements BeanPostProcessor {
        @Override public Object postProcessAfterInitialization(Object bean, String name) {
            return bean instanceof Payments ? proxyOf(bean) : bean;
        }
    }

    /** Подменяет прокси оба бина цикла, только после инициализации. */
    public static class LateProxyBothBpp implements BeanPostProcessor {
        @Override public Object postProcessAfterInitialization(Object bean, String name) {
            return (bean instanceof Payments || bean instanceof Limits) ? proxyOf(bean) : bean;
        }
    }

    /** Умеет отдать прокси раньше — по запросу ранней ссылки. */
    public static class EarlyProxyBpp implements SmartInstantiationAwareBeanPostProcessor {
        private final Map<String, Object> early = new HashMap<>();
        @Override public Object getEarlyBeanReference(Object bean, String name) {
            if (!(bean instanceof Payments)) return bean;
            System.out.println("   getEarlyBeanReference(" + name + "): ранняя ссылка понадобилась, отдаю прокси");
            return early.computeIfAbsent(name, n -> proxyOf(bean));
        }
        @Override public Object postProcessAfterInitialization(Object bean, String name) {
            if (!(bean instanceof Payments)) return bean;
            return early.containsKey(name) ? bean : proxyOf(bean);   // уже отдали прокси раньше — второй не создаём
        }
    }

    static Object target(Object o) {
        try { return o instanceof org.springframework.aop.framework.Advised a ? a.getTargetSource().getTarget() : o; }
        catch (Exception e) { throw new IllegalStateException(e); }
    }

    static void run(String title, Class<?> bpp) {
        try (var ctx = new AnnotationConfigApplicationContext()) {
            ctx.registerBean(bpp);
            ctx.register(Payments.class, Limits.class);
            ctx.refresh();
            Object p = ctx.getBean(Payments.class), l = ctx.getBean(Limits.class);
            Payments pt = (Payments) target(p); Limits lt = (Limits) target(l);
            System.out.println(title + ": контекст поднялся");
            System.out.println("   в контексте: Payments — прокси " + org.springframework.aop.support.AopUtils.isAopProxy(p) + ", Limits — прокси " + org.springframework.aop.support.AopUtils.isAopProxy(l));
            System.out.println("   Limits получил " + (lt.payments == p ? "тот же объект, что в контексте" : "другой объект") + "; Payments получил " + (pt.limits == l ? "тот же объект, что в контексте" : (pt.limits == lt ? "«сырой» Limits без прокси" : "другой объект")));
        } catch (Exception e) {
            Throwable r = e; while (r.getCause() != null) r = r.getCause();
            System.out.println(title + ": " + r.getClass().getSimpleName() + ": " + r.getMessage().replace("dev.team.cycles.EarlyReferenceLab$", ""));
        }
    }

    public static void main(String[] args) {
        run("прокси только после инициализации", LateProxyBpp.class);
        run("прокси по ранней ссылке", EarlyProxyBpp.class);
        run("прокси у обоих бинов только после инициализации", LateProxyBothBpp.class);
    }
}
