package dev.team.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/** Опыт разд. 9.1 и 9.3: пять видов советов, порядок внутри одного аспекта, что может и чего не может каждый. */
public class AdviceLab {
    public static class Receipt {
        private String status;
        public Receipt(String status) { this.status = status; }
        public String getStatus() { return status; }
        public void setStatus(String s) { status = s; }
        @Override public String toString() { return "Receipt(" + status + ")"; }
    }

    public static class TransferService {
        public Receipt transfer(String from, String to, long kopecks) {
            System.out.println("      transfer " + from + " -> " + to + ", " + kopecks + " коп.");
            if (kopecks <= 0) throw new IllegalArgumentException("сумма должна быть положительной");
            return new Receipt("ПРОВЕДЁН");
        }
        public void notifyClient(String account) { System.out.println("      notifyClient " + account); }
    }

    @Aspect
    public static class AuditAspect {
        @Pointcut("execution(* dev.team.aop.AdviceLab.TransferService.transfer(..))")
        void transfer() { }

        @Around("transfer()")
        public Object around(ProceedingJoinPoint pjp) throws Throwable {
            System.out.println("   @Around до, аргументы " + java.util.Arrays.toString(pjp.getArgs()));
            try {
                Object r = pjp.proceed();
                System.out.println("   @Around после, результат " + r);
                return r;
            } catch (Throwable t) {
                System.out.println("   @Around поймал " + t.getClass().getSimpleName());
                throw t;
            }
        }
        @Before("transfer()")
        public void before(JoinPoint jp) { System.out.println("   @Before " + jp.getSignature().getName()); }
        @After("transfer()")
        public void after() { System.out.println("   @After"); }
        @AfterReturning(pointcut = "transfer()", returning = "receipt")
        public void afterReturning(Receipt receipt) {
            System.out.println("   @AfterReturning получил " + receipt + ", меняю статус");
            receipt.setStatus("ПРОВЕДЁН (проверен аудитом)");
        }
        @AfterReturning(pointcut = "transfer()", returning = "receipt")
        public Receipt tryReplace(Receipt receipt) {
            System.out.println("   @AfterReturning пытается вернуть другой объект");
            return new Receipt("ПОДМЕНЁН");
        }
        @AfterThrowing(pointcut = "transfer()", throwing = "error")
        public void afterThrowing(Exception error) { System.out.println("   @AfterThrowing: " + error.getMessage()); }

        @Around("execution(void dev.team.aop.AdviceLab.TransferService.notifyClient(..))")
        public Object aroundVoid(ProceedingJoinPoint pjp) throws Throwable {
            Object r = pjp.proceed();
            System.out.println("   @Around для void: proceed() вернул " + r);
            return r;
        }
    }

    @Configuration
    @EnableAspectJAutoProxy
    static class Cfg {
        @Bean TransferService transferService() { return new TransferService(); }
        @Bean AuditAspect auditAspect() { return new AuditAspect(); }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            var s = ctx.getBean(TransferService.class);
            System.out.println("== успешный перевод");
            System.out.println("вызывающий получил " + s.transfer("40817-001", "40817-002", 150_000));
            System.out.println("== перевод с ошибкой");
            try { s.transfer("40817-001", "40817-002", 0); }
            catch (IllegalArgumentException e) { System.out.println("вызывающий получил исключение: " + e.getMessage()); }
            System.out.println("== метод void");
            s.notifyClient("40817-001");
            System.out.println("== объект, созданный через new, а не контейнером");
            new TransferService().transfer("40817-001", "40817-003", 100);
        }
    }
}
