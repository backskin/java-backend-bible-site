package dev.team.mortgage.service;

public interface MortgageCalculatorService {
    double payment(double principal, double annualInterestRate, int years);
}
