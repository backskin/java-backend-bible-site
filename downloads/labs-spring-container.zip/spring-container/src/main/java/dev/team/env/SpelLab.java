package dev.team.env;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.SimpleEvaluationContext;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;

/** Опыт разд. 11.3: ${...} и #{...} в @Value, ограниченный и стандартный контекст SpEL. */
public class SpelLab {
    public static class Limits { public BigDecimal daily() { return new BigDecimal("500000.00"); } }

    public static class Tariff {
        @Value("${fee.percent}") BigDecimal percent;                                  // заполнитель свойства
        @Value("#{T(java.time.Duration).ofSeconds(30)}") Duration timeout;          // выражение: статический метод
        @Value("#{limits.daily() * 2}") BigDecimal weekly;                          // ссылка на бин
        @Value("#{'${fee.min}' + ' руб.'}") String minText;                          // заполнитель внутри выражения
        @Value("#{systemEnvironment['NO_SUCH_VAR'] ?: 'по умолчанию'}") String env;  // оператор Элвиса
    }

    /** Строка платежа, по которой оператор задаёт фильтр в интерфейсе мониторинга. */
    public record Payment(String payer, BigDecimal amount) {}

    @Configuration @PropertySource("classpath:env/fee.properties")
    static class Cfg {
        @Bean static PropertySourcesPlaceholderConfigurer pspc() { return new PropertySourcesPlaceholderConfigurer(); }
        @Bean Limits limits() { return new Limits(); }
        @Bean Tariff tariff() { return new Tariff(); }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            var t = ctx.getBean(Tariff.class);
            System.out.println("percent=" + t.percent + ", timeout=" + t.timeout + ", weekly=" + t.weekly + ", minText=" + t.minText + ", env=" + t.env);
        }
        var parser = new SpelExpressionParser();
        var row = new Payment("ООО Ромашка", new BigDecimal("750000.00"));
        for (String userFilter : List.of("amount > 600000", "T(java.lang.Runtime).getRuntime().availableProcessors() > 0")) {
            System.out.println("== фильтр оператора: " + userFilter);
            try { System.out.println("   StandardEvaluationContext: " + parser.parseExpression(userFilter).getValue(new StandardEvaluationContext(row), Boolean.class)); }
            catch (Exception e) { System.out.println("   StandardEvaluationContext: " + e.getMessage()); }
            try { System.out.println("   SimpleEvaluationContext:   " + parser.parseExpression(userFilter).getValue(SimpleEvaluationContext.forReadOnlyDataBinding().build(), row, Boolean.class)); }
            catch (Exception e) { System.out.println("   SimpleEvaluationContext:   " + e.getMessage()); }
        }
    }
}
