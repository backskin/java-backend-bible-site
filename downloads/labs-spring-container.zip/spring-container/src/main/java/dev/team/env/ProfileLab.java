package dev.team.env;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.Arrays;

/** Опыт разд. 11.2: массив профилей и выражение профилей в @Profile. */
public class ProfileLab {
    @Configuration @Profile({"!prod", "!qa"}) static class ArrayForm { }
    @Configuration @Profile("!prod & !qa") static class ExpressionForm { }
    @Configuration @Profile({"dev", "qa"}) static class DevOrQa { }

    public static void main(String[] args) {
        System.out.printf("%-14s %-22s %-22s %s%n", "активны", "{\"!prod\", \"!qa\"}", "\"!prod & !qa\"", "{\"dev\", \"qa\"}");
        for (String[] active : new String[][] {{}, {"dev"}, {"prod"}, {"qa"}, {"prod", "qa"}}) {
            var ctx = new AnnotationConfigApplicationContext();
            ctx.getEnvironment().setActiveProfiles(active);
            ctx.register(ArrayForm.class, ExpressionForm.class, DevOrQa.class);
            ctx.refresh();
            System.out.printf("%-14s %-22s %-22s %s%n", Arrays.toString(active),
                    ctx.getBeanNamesForType(ArrayForm.class).length == 1 ? "создан" : "—",
                    ctx.getBeanNamesForType(ExpressionForm.class).length == 1 ? "создан" : "—",
                    ctx.getBeanNamesForType(DevOrQa.class).length == 1 ? "создан" : "—");
            ctx.close();
        }
    }
}
