package dev.team.lifecycle;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.SmartLifecycle;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;

/** Опыт 3: где выполняется код «при старте» в приложении на Spring Boot. */
@Configuration(proxyBeanMethods = false)
public class StartupLab {

    public static class RatesLoader implements SmartInitializingSingleton, SmartLifecycle {
        private boolean running;
        @PostConstruct void post() { System.out.println("1. @PostConstruct — бин создан, другие бины могут быть ещё не созданы"); }
        @Override public void afterSingletonsInstantiated() { System.out.println("2. SmartInitializingSingleton — созданы все синглтоны"); }
        @Override public void start() { running = true; System.out.println("3. SmartLifecycle.start — запуск компонентов"); }
        @Override public void stop() { running = false; System.out.println("при закрытии: SmartLifecycle.stop"); }
        @jakarta.annotation.PreDestroy void destroy() { System.out.println("при закрытии: @PreDestroy"); }
        @Override public boolean isRunning() { return running; }
    }

    @Bean RatesLoader ratesLoader() { return new RatesLoader(); }

    @EventListener void refreshed(ContextRefreshedEvent e) { System.out.println("4. ContextRefreshedEvent — refresh() завершён"); }
    @EventListener void started(ApplicationStartedEvent e) { System.out.println("5. ApplicationStartedEvent — контекст поднят, раннеры ещё не вызваны"); }

    @Bean ApplicationRunner appRunner() { return a -> System.out.println("6. ApplicationRunner.run — аргументы: " + a.getOptionNames()); }
    @Bean CommandLineRunner cliRunner() { return a -> System.out.println("7. CommandLineRunner.run — аргументы: " + String.join(" ", a)); }

    @EventListener void ready(ApplicationReadyEvent e) { System.out.println("8. ApplicationReadyEvent — приложение готово принимать работу"); }

    public static void main(String[] args) {
        var app = new SpringApplication(StartupLab.class);
        app.setBannerMode(org.springframework.boot.Banner.Mode.OFF);
        app.setLogStartupInfo(false);
        app.run("--date=2026-10-23").close();
    }
}
