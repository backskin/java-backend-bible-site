package dev.team.events;

import org.h2.jdbcx.JdbcDataSource;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.event.ApplicationEventMulticaster;
import org.springframework.context.event.EventListener;
import org.springframework.context.event.SimpleApplicationEventMulticaster;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.support.TaskUtils;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import javax.sql.DataSource;

/** Опыт разд. 10.2: исключение синхронного слушателя с обработчиком ошибок мультикастера и без него. */
public class MulticasterLab {
    public record OrderAccepted(long orderId) {}

    public static class OrderService {
        final JdbcTemplate jdbc; final ApplicationEventPublisher events;
        public OrderService(JdbcTemplate jdbc, ApplicationEventPublisher events) { this.jdbc = jdbc; this.events = events; }
        @Transactional public void accept(long id) {
            jdbc.update("insert into payment_order(id) values (?)", id);
            events.publishEvent(new OrderAccepted(id));
        }
    }

    public static class Listeners {
        @EventListener @Order(1) public void sms(OrderAccepted e) { System.out.println("   sms: бросаю исключение"); throw new IllegalStateException("СМС-шлюз недоступен"); }
        @EventListener @Order(2) public void audit(OrderAccepted e) { System.out.println("   audit: вызван"); }
        @TransactionalEventListener(phase = TransactionPhase.AFTER_ROLLBACK) public void rolledBack(OrderAccepted e) { System.out.println("   AFTER_ROLLBACK: вызван"); }
        @TransactionalEventListener public void committed(OrderAccepted e) { System.out.println("   AFTER_COMMIT: вызван"); }
    }

    @Configuration @EnableTransactionManagement
    static class Base {
        @Bean DataSource ds() { var d = new JdbcDataSource(); d.setURL("jdbc:h2:mem:mc" + System.nanoTime() + ";DB_CLOSE_DELAY=-1"); return d; }
        @Bean JdbcTemplate jdbc(DataSource ds) { var j = new JdbcTemplate(ds); j.execute("create table payment_order(id bigint primary key)"); return j; }
        @Bean PlatformTransactionManager tx(DataSource ds) { return new DataSourceTransactionManager(ds); }
        @Bean OrderService service(JdbcTemplate j, ApplicationEventPublisher p) { return new OrderService(j, p); }
        @Bean Listeners listeners() { return new Listeners(); }
    }

    @Configuration @Import(Base.class)
    static class Suppressing {
        @Bean(name = "applicationEventMulticaster") ApplicationEventMulticaster multicaster() {
            var m = new SimpleApplicationEventMulticaster();
            m.setErrorHandler(TaskUtils.LOG_AND_SUPPRESS_ERROR_HANDLER);
            return m;
        }
    }

    static void run(String title, Class<?> cfg) {
        System.out.println("== " + title);
        try (var ctx = new AnnotationConfigApplicationContext(cfg)) {
            try { ctx.getBean(OrderService.class).accept(1); System.out.println("   accept вернул управление без исключения"); }
            catch (Exception e) { System.out.println("   вызывающий получил: " + e.getMessage()); }
            System.out.println("   поручений в базе: " + ctx.getBean(JdbcTemplate.class).queryForObject("select count(*) from payment_order", Integer.class));
        }
    }

    public static void main(String[] args) {
        run("мультикастер по умолчанию", Base.class);
        run("LOG_AND_SUPPRESS_ERROR_HANDLER", Suppressing.class);
    }
}
