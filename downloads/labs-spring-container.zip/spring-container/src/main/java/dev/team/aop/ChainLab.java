package dev.team.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.support.AopUtils;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.SimpleTransactionStatus;

import java.util.Arrays;

/** Опыт разд. 9.4: стек вызовов внутри цепочки, повторный proceed(), бин без советов. */
public class ChainLab {
    static class NoopTxManager implements PlatformTransactionManager {
        @Override public TransactionStatus getTransaction(TransactionDefinition d) { return new SimpleTransactionStatus(); }
        @Override public void commit(TransactionStatus s) { }
        @Override public void rollback(TransactionStatus s) { }
    }

    public static class PostingService {
        int calls;
        @Transactional
        public void post(String entry) {
            calls++;
            System.out.println("   post(" + entry + "), вызов " + calls + "; стек от метода к клиенту:");
            Arrays.stream(Thread.currentThread().getStackTrace()).skip(1).limit(15)
                    .map(f -> "      " + f.getClassName().replace("org.springframework.", "o.s.").replace("dev.team.aop.", "") + "." + f.getMethodName())
                    .forEach(System.out::println);
        }
        public String fee(long kopecks) { calls++; return "комиссия " + kopecks * 15 / 1000 + " коп., вызов " + calls; }
    }

    public static class RateService { public String rate() { return "92.50"; } }

    @Aspect
    public static class TwiceAspect {
        @Around("execution(* dev.team.aop.ChainLab.PostingService.fee(..))")
        public Object twice(ProceedingJoinPoint pjp) throws Throwable {
            Object first = pjp.proceed();
            Object second = pjp.proceed(new Object[] {200_000L});
            System.out.println("   первый proceed(): " + first + "; второй proceed(200000): " + second);
            return second;
        }
    }

    @Configuration @EnableAspectJAutoProxy @EnableTransactionManagement
    static class Cfg {
        @Bean PlatformTransactionManager txManager() { return new NoopTxManager(); }
        @Bean PostingService postingService() { return new PostingService(); }
        @Bean RateService rateService() { return new RateService(); }
        @Bean TwiceAspect twiceAspect() { return new TwiceAspect(); }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            var s = ctx.getBean(PostingService.class);
            s.post("Дт 40817 Кт 30102");
            System.out.println("клиент получил: " + s.fee(150_000));
            var r = ctx.getBean(RateService.class);
            System.out.println("RateService: класс " + r.getClass().getSimpleName() + ", прокси " + AopUtils.isAopProxy(r));
        }
    }
}
