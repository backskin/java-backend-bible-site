package dev.team.ext;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.env.MapPropertySource;

import java.util.Map;

/** Опыт разд. 13.2 и 13.3: стоимость сканирования узкого и широкого пакета, ApplicationContextInitializer. */
public class ScanLab {
    static void scan(String pkg) {
        var scanner = new ClassPathScanningCandidateComponentProvider(true);
        scanner.findCandidateComponents(pkg);                                // прогрев загрузки ресурсов
        long t = System.nanoTime();
        int found = scanner.findCandidateComponents(pkg).size();
        System.out.printf("   %-22s кандидатов %4d, %4d мс%n", pkg, found, (System.nanoTime() - t) / 1_000_000);
    }

    static class InstanceIdInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {
        @Override public void initialize(ConfigurableApplicationContext ctx) {
            System.out.println("   initializer: контекст активен " + ctx.isActive() + ", описаний бинов " + ctx.getBeanFactory().getBeanDefinitionCount());
            ctx.getEnvironment().getPropertySources().addFirst(new MapPropertySource("computed", Map.of("app.instance-id", "settle-7")));
        }
    }

    public static void main(String[] args) {
        System.out.println("== сканирование с фильтрами по умолчанию");
        scan("dev.team.mortgage");
        scan("dev.team");
        scan("org.springframework");
        System.out.println("== ApplicationContextInitializer");
        var ctx = new AnnotationConfigApplicationContext();
        new InstanceIdInitializer().initialize(ctx);
        ctx.refresh();
        System.out.println("   после refresh: app.instance-id=" + ctx.getEnvironment().getProperty("app.instance-id") + ", описаний бинов " + ctx.getBeanDefinitionCount());
        ctx.close();
    }
}
