package dev.team.mortgage.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

// Сканируется весь пакет примера; AppConfig исключён, чтобы его @Bean-методы не продублировали бины
@Configuration
@ComponentScan(basePackages = "dev.team.mortgage",
        excludeFilters = @ComponentScan.Filter(type = FilterType.ANNOTATION, classes = Configuration.class))
public class ScanConfig { }
