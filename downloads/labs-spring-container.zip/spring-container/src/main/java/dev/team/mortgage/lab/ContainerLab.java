package dev.team.mortgage.lab;

import dev.team.mortgage.App;
import dev.team.mortgage.config.AppConfig;
import dev.team.mortgage.config.ScanConfig;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.GenericApplicationContext;

import java.util.Arrays;

/** Опыты раздела 2 главы 09. Запуск: mvn -q compile exec:java или из IDEA, main-класс dev.team.mortgage.lab.ContainerLab. */
public class ContainerLab {

    /** Бин с методом инициализации: показывает, кто вызывает @PostConstruct. */
    public static class RateSource {
        public RateSource() { System.out.println("  [создан RateSource]"); }
        @PostConstruct void load() { System.out.println("  [@PostConstruct RateSource.load]"); }
    }

    /** Объект, созданный не контейнером: получает зависимость и @PostConstruct, но не @PreDestroy. */
    public static class ExternalJob {
        @org.springframework.beans.factory.annotation.Autowired dev.team.mortgage.service.MortgageCalculatorService calc;
        @PostConstruct void init() { System.out.println("  [@PostConstruct ExternalJob, calc внедрён: " + (calc != null) + "]"); }
        @jakarta.annotation.PreDestroy void close() { System.out.println("  [@PreDestroy ExternalJob]"); }
    }

    public static void main(String[] args) {
        System.out.println("1. Три способа описать одни и те же бины (Граци и Боярски, гл. 6)");
        try (var xml = new ClassPathXmlApplicationContext("applicationContext.xml")) {
            System.out.println("  XML:            " + appResult(xml.getBean("app", App.class)));
            System.out.println("  определений бинов: " + xml.getBeanDefinitionCount() + " " + Arrays.toString(xml.getBeanDefinitionNames()));
        }
        try (var java = new AnnotationConfigApplicationContext(AppConfig.class)) {
            System.out.println("  @Configuration: " + appResult(java.getBean(App.class)));
            System.out.println("  определений бинов: " + java.getBeanDefinitionCount() + " " + Arrays.toString(java.getBeanDefinitionNames()));
            System.out.println("  тип определения для @Bean app: " + java.getBeanFactory().getBeanDefinition("app").getClass().getSimpleName());
        }
        try (var scan = new AnnotationConfigApplicationContext(ScanConfig.class)) {
            System.out.println("  сканирование:   " + appResult(scan.getBean(App.class)));
            System.out.println("  тип определения для найденного app: " + scan.getBeanFactory().getBeanDefinition("app").getClass().getSimpleName());
        }

        System.out.println("2. Сначала описание, потом объект: голая фабрика создаёт бин только по getBean");
        var factory = new DefaultListableBeanFactory();
        factory.registerBeanDefinition("rateSource", new RootBeanDefinition(RateSource.class));
        System.out.println("  описание зарегистрировано, containsBean=" + factory.containsBean("rateSource")
                + ", объект создан=" + factory.containsSingleton("rateSource"));
        factory.getBean("rateSource");
        System.out.println("  после getBean объект создан=" + factory.containsSingleton("rateSource")
                + "; @PostConstruct в голой фабрике не вызван (строки выше)");

        System.out.println("3. Контекст создаёт синглтоны на старте и сам подключает постпроцессоры");
        try (var ctx = new GenericApplicationContext()) {
            ctx.registerBean("rateSource", RateSource.class);
            org.springframework.context.annotation.AnnotationConfigUtils.registerAnnotationConfigProcessors(ctx);
            System.out.println("  до refresh объект создан=" + ctx.getBeanFactory().containsSingleton("rateSource"));
            ctx.refresh();
            System.out.println("  после refresh (getBean ещё не вызывали) создан=" + ctx.getBeanFactory().containsSingleton("rateSource"));
        }

        System.out.println("4. BeanFactoryPostProcessor правит описание до создания объекта");
        dev.team.mortgage.service.MortgageCalculatorServiceImpl.CREATED.set(0);
        try (var ctx = new AnnotationConfigApplicationContext()) {
            ctx.register(AppConfig.class);
            ctx.addBeanFactoryPostProcessor((BeanFactoryPostProcessor) bf -> {
                BeanDefinition d = bf.getBeanDefinition("mortgageCalculatorService");
                d.setScope(BeanDefinition.SCOPE_PROTOTYPE);
                System.out.println("  постпроцессор сменил scope mortgageCalculatorService на prototype; объектов MortgageCalculatorServiceImpl создано: " + dev.team.mortgage.service.MortgageCalculatorServiceImpl.CREATED.get());
            });
            ctx.refresh();
            Object a = ctx.getBean("mortgageCalculatorService"), b = ctx.getBean("mortgageCalculatorService");
            System.out.println("  после refresh и двух getBean создано: " + dev.team.mortgage.service.MortgageCalculatorServiceImpl.CREATED.get() + " (один для зависимости синглтона app, два по getBean); разные объекты: " + (a != b));
        }
        System.out.println("6. Внешний объект через AutowireCapableBeanFactory");
        try (var ctx = new AnnotationConfigApplicationContext(AppConfig.class)) {
            var job = new ExternalJob();
            var f = ctx.getAutowireCapableBeanFactory();
            f.autowireBean(job);
            f.initializeBean(job, "externalJob");
            System.out.println("  в реестре: " + ctx.containsBean("externalJob") + "; закрываем контекст:");
        }
        System.out.println("  (строки «@PreDestroy ExternalJob» выше нет)");
        System.out.println("5. Сканирование не загружает классы без аннотаций: строки «статическая инициализация NotABean» выше нет");
    }

    private static String appResult(App app) {
        try {
            var m = App.class.getDeclaredMethod("monthlyPayment");
            m.setAccessible(true);
            return (String) m.invoke(app);
        } catch (ReflectiveOperationException e) { throw new IllegalStateException(e); }
    }
}
