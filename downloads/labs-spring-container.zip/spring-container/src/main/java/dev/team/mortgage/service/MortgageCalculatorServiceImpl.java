package dev.team.mortgage.service;

import org.springframework.stereotype.Service;

@Service
public class MortgageCalculatorServiceImpl implements MortgageCalculatorService {
    public static final java.util.concurrent.atomic.AtomicInteger CREATED = new java.util.concurrent.atomic.AtomicInteger();

    public MortgageCalculatorServiceImpl() {
        CREATED.incrementAndGet();
        System.out.println("  [создан MortgageCalculatorServiceImpl]");
    }

    @Override
    public double payment(double principal, double annualInterestRate, int termInYears) {
        double monthlyInterestRate = annualInterestRate / 12 / 100;
        int numberOfPayments = termInYears * 12;
        // Ипотечная формула: P * R * [(1+R)^N] / [(1+R)^N - 1]
        return principal * (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments))
                / (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1);
    }
}
