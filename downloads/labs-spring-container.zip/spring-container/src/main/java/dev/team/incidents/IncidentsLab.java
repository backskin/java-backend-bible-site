package dev.team.incidents;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/** Опыты к разд. 16: инциденты 16.1 (постпроцессор фабрики забрал бин), 16.3 (кэш внутри транзакции), 16.5 (один поток планировщика). */
public class IncidentsLab {

    // ---------- 16.1 ----------
    public static class LimitService {
        @Transactional public void updateLimit(String client) { }
        public BigDecimal defaultLimit() { return new BigDecimal("300000.00"); }
    }

    @Configuration @EnableTransactionManagement
    static class Base {
        @Bean PlatformTransactionManager txManager() { return new DataSourceTransactionManager(h2("tx16-1", 2)); }
        @Bean LimitService limitService() { return new LimitService(); }
    }

    @Configuration
    static class FactoryPpWithParam {
        @Bean static BeanFactoryPostProcessor tariffDefaults(LimitService limits) {
            return bf -> { /* брал лимит по умолчанию для новых тарифов */ limits.defaultLimit(); };
        }
    }

    @Configuration
    static class BeanPpWithParam {
        @Bean static BeanPostProcessor metrics(LimitService limits) {
            return new BeanPostProcessor() { };
        }
    }

    @Configuration
    static class PriorityBeanPpWithParam {
        @Bean static PriorityMetrics priorityMetrics(LimitService limits) { return new PriorityMetrics(); }
    }

    static class PriorityMetrics implements BeanPostProcessor, org.springframework.core.PriorityOrdered {
        @Override public int getOrder() { return 0; }
    }

    static void incident1() {
        System.out.println("== 16.1 бин, который понадобился постпроцессору до регистрации постпроцессоров бинов");
        for (Class<?> extra : List.of(Object.class, FactoryPpWithParam.class, BeanPpWithParam.class, PriorityBeanPpWithParam.class)) {
            String name = extra == Object.class ? "без постпроцессоров" : extra.getSimpleName();
            System.out.println("   " + name + ":");
            AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
            ctx.register(Base.class);
            if (extra != Object.class) ctx.register(extra);
            ctx.refresh();
            Object bean = ctx.getBean("limitService");
            System.out.printf("      LimitService — прокси: %s, класс: %s%n", AopUtils.isAopProxy(bean), bean.getClass().getSimpleName());
            ctx.close();
        }
    }

    // ---------- 16.3 ----------
    public static class TariffService {
        @Transactional(readOnly = true) @Cacheable("tariffs")
        public BigDecimal fee(String tariff) { return new BigDecimal("15.00"); }
    }

    static final AtomicInteger connections = new AtomicInteger();

    static HikariDataSource h2(String name, int pool) {
        HikariConfig c = new HikariConfig();
        c.setJdbcUrl("jdbc:h2:mem:" + name + ";DB_CLOSE_DELAY=-1");
        c.setMaximumPoolSize(pool);
        c.setConnectionTimeout(250);
        c.setPoolName(name);
        return new HikariDataSource(c) {
            @Override public Connection getConnection() throws java.sql.SQLException { connections.incrementAndGet(); return super.getConnection(); }
        };
    }

    @Configuration @EnableTransactionManagement
    static class TariffBeans {
        @Bean HikariDataSource dataSource() { return h2("tariffs", 2); }
        @Bean PlatformTransactionManager txManager(HikariDataSource ds) { return new DataSourceTransactionManager(ds); }
        @Bean CacheManager cacheManager() { return new ConcurrentMapCacheManager("tariffs"); }
        @Bean TariffService tariffService() { return new TariffService(); }
    }

    @Configuration @EnableCaching static class CacheDefaultOrder { }
    @Configuration @EnableCaching(order = 100) static class CacheOutside { }

    static void incident3() throws Exception {
        System.out.println("== 16.3 справочник тарифов в кэше, пул на 2 соединения, 1000 вызовов в 20 потоков");
        for (Class<?> caching : List.of(CacheDefaultOrder.class, CacheOutside.class)) {
            var ctx = new AnnotationConfigApplicationContext(TariffBeans.class, caching);
            TariffService svc = ctx.getBean(TariffService.class);
            svc.fee("T-1");                                     // наполнить кэш
            List<String> chain = new ArrayList<>();
            for (var a : ((Advised) svc).getAdvisors()) chain.add(a.getAdvice().getClass().getSimpleName());
            connections.set(0);
            AtomicInteger errors = new AtomicInteger();
            ExecutorService pool = Executors.newFixedThreadPool(20);
            CountDownLatch done = new CountDownLatch(1000);
            long t0 = System.nanoTime();
            for (int i = 0; i < 1000; i++) pool.submit(() -> {
                try { svc.fee("T-1"); } catch (Exception e) { errors.incrementAndGet(); } finally { done.countDown(); }
            });
            done.await();
            pool.shutdown();
            long ms = Duration.ofNanos(System.nanoTime() - t0).toMillis();
            String name = caching == CacheDefaultOrder.class ? "@EnableCaching по умолчанию" : "@EnableCaching(order = 100)";
            System.out.printf("   %-28s цепочка %s%n", name, chain);
            System.out.printf("   %-28s соединений взято из пула: %d, отказов пула: %d, за %d мс%n", "", connections.get(), errors.get(), ms);
            ctx.close();
        }
    }

    // ---------- 16.5 ----------
    static final List<String> beats = new ArrayList<>();
    static Instant start;

    static class Jobs {
        @Scheduled(fixedRate = 300) void heartbeat() { synchronized (beats) { beats.add(Duration.between(start, Instant.now()).toMillis() + "@" + Thread.currentThread().getName()); } }
        @Scheduled(initialDelay = 500, fixedDelay = 60_000) void reconcile() throws InterruptedException {
            System.out.println("      сверка началась на потоке " + Thread.currentThread().getName());
            Thread.sleep(2000);
        }
    }

    static class JobsSeparate extends Jobs {
        @Override @Scheduled(initialDelay = 500, fixedDelay = 60_000, scheduler = "heavyScheduler") void reconcile() throws InterruptedException { super.reconcile(); }
    }

    static ThreadPoolTaskScheduler scheduler(String prefix) {
        ThreadPoolTaskScheduler s = new ThreadPoolTaskScheduler();
        s.setPoolSize(1);                                       // как у планировщика Spring Boot по умолчанию
        s.setThreadNamePrefix(prefix);
        return s;
    }

    @Configuration @EnableScheduling
    static class OneScheduler {
        @Bean ThreadPoolTaskScheduler taskScheduler() { return scheduler("scheduling-"); }
        @Bean Jobs jobs() { return new Jobs(); }
    }

    @Configuration @EnableScheduling
    static class TwoSchedulers {
        @Bean ThreadPoolTaskScheduler taskScheduler() { return scheduler("scheduling-"); }
        @Bean ThreadPoolTaskScheduler heavyScheduler() { return scheduler("heavy-"); }
        @Bean Jobs jobs() { return new JobsSeparate(); }
    }

    static void incident5() throws Exception {
        System.out.println("== 16.5 проверка связи раз в 300 мс и сверка на 2 с, планировщик на 1 поток");
        for (Class<?> cfg : List.of(OneScheduler.class, TwoSchedulers.class)) {
            beats.clear();
            start = Instant.now();
            var ctx = new AnnotationConfigApplicationContext(cfg);
            Thread.sleep(3000);
            ctx.close();
            List<Long> at;
            synchronized (beats) { at = beats.stream().map(b -> Long.parseLong(b.substring(0, b.indexOf('@')))).toList(); }
            long gap = 0;
            for (int i = 1; i < at.size(); i++) gap = Math.max(gap, at.get(i) - at.get(i - 1));
            System.out.printf("   %-14s проверок связи за 3 с: %d, самый долгий перерыв: %d мс%n", cfg.getSimpleName(), at.size(), gap);
        }
    }

    public static void main(String[] args) throws Exception {
        incident1();
        incident3();
        incident5();
    }
}
