package dev.team.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Repository;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Опыт разд. 9.2: какие методы выбирает каждый вид pointcut-выражения. */
public class PointcutLab {
    @Retention(RetentionPolicy.RUNTIME) @Target(ElementType.METHOD) public @interface Audited {}

    public interface Payments { void pay(String account, long kopecks); }

    public static class PaymentService implements Payments {
        @Audited @Override public void pay(String account, long kopecks) { }
        public void refund(String account) { }
    }

    @Repository
    public static class AccountRepository {
        public void save(String account) { }
        public void lock(String account, long timeoutMs) { }
    }

    static final Map<String, List<String>> hits = new TreeMap<>();

    @Aspect
    public static class Probe {
        static void hit(String pc, JoinPoint jp) {
            hits.computeIfAbsent(pc, k -> new ArrayList<>()).add(jp.getSignature().getName());
        }
        @Before("execution(* dev.team.aop.PointcutLab.PaymentService.*(..))")
        public void execution(JoinPoint jp) { hit("1 execution(* ..PaymentService.*(..))", jp); }
        @Before("within(dev.team.aop.PointcutLab.AccountRepository)")
        public void within(JoinPoint jp) { hit("2 within(..AccountRepository)", jp); }
        @Before("@annotation(dev.team.aop.PointcutLab.Audited)")
        public void annotation(JoinPoint jp) { hit("3 @annotation(Audited)", jp); }
        @Before("@within(org.springframework.stereotype.Repository)")
        public void atWithin(JoinPoint jp) { hit("4 @within(Repository)", jp); }
        @Before("bean(*Repository)")
        public void bean(JoinPoint jp) { hit("5 bean(*Repository)", jp); }
        @Before("args(String, long)")
        public void args(JoinPoint jp) { hit("6 args(String, long)", jp); }
        @Before("this(dev.team.aop.PointcutLab.PaymentService)")
        public void thisClass(JoinPoint jp) { hit("7 this(PaymentService)", jp); }
        @Before("target(dev.team.aop.PointcutLab.PaymentService)")
        public void targetClass(JoinPoint jp) { hit("8 target(PaymentService)", jp); }
        @Before("this(dev.team.aop.PointcutLab.Payments)")
        public void thisIface(JoinPoint jp) { hit("9 this(Payments)", jp); }
        @Before("(within(dev.team.aop.PointcutLab.PaymentService) || within(dev.team.aop.PointcutLab.AccountRepository)) && !@annotation(dev.team.aop.PointcutLab.Audited)")
        public void combined(JoinPoint jp) { hit("10 (within(..) || within(..)) && !@annotation(Audited)", jp); }
    }

    @Configuration
    @EnableAspectJAutoProxy
    static class Cfg {
        @Bean PaymentService paymentService() { return new PaymentService(); }
        @Bean AccountRepository accountRepository() { return new AccountRepository(); }
        @Bean Probe probe() { return new Probe(); }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            Payments payments = ctx.getBean(Payments.class);
            System.out.println("класс прокси PaymentService: " + payments.getClass().getSimpleName());
            payments.pay("40817-001", 150_000);
            var repo = ctx.getBean(AccountRepository.class);
            repo.save("40817-001");
            repo.lock("40817-001", 500);
        }
        hits.forEach((pc, m) -> System.out.printf("%-44s %s%n", pc, m));
    }
}
