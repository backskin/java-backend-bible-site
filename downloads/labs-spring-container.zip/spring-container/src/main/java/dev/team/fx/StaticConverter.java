package dev.team.fx;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

/** Плохо: статический служебный класс с одной зашитой таблицей курсов на все случаи. */
public final class StaticConverter {
    private static final Map<String, BigDecimal> RATES = Map.of("USD", new BigDecimal("81.20"));
    private StaticConverter() { }
    public static BigDecimal toRub(BigDecimal amount, String currency) {
        return amount.multiply(RATES.get(currency)).setScale(2, RoundingMode.HALF_EVEN);
    }
}
