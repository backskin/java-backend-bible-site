package dev.team.fx;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

/** Конвертер получает источник курсов снаружи: какой именно, решает тот, кто его создаёт. */
public final class CurrencyConverter {
    private final RateSource rates;

    public CurrencyConverter(RateSource rates) {
        this.rates = Objects.requireNonNull(rates);
    }

    public BigDecimal toRub(BigDecimal amount, String currency) {
        return amount.multiply(rates.rubPer(currency)).setScale(2, RoundingMode.HALF_EVEN);
    }
}
