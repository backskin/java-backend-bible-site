package dev.team.incidents;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionalEventListener;

import javax.sql.DataSource;
import java.util.List;
import java.util.Properties;

/** Опыты к разд. 16: инциденты 16.2 (метод сохранения строк перенесли в класс импорта) и 16.4 (слушатель AFTER_COMMIT на JDBC и на Spring Data JPA). */
public class IncidentsLab2 {

    static HikariDataSource h2(String name) { return h2(name, true); }

    static HikariDataSource h2(String name, boolean autoCommit) {
        HikariConfig c = new HikariConfig();
        c.setAutoCommit(autoCommit);
        c.setJdbcUrl("jdbc:h2:mem:" + name + ";DB_CLOSE_DELAY=-1");
        c.setMaximumPoolSize(4);
        c.setPoolName(name);
        return new HikariDataSource(c);
    }

    // ---------- 16.2 ----------
    static final List<String> REGISTRY = List.of("R-1", "R-2", "BAD", "R-4");

    /** Строка реестра пишется отдельным бином со своей транзакционной границей — так было до переноса. */
    public static class RowWriter {
        final JdbcTemplate jdbc;
        RowWriter(JdbcTemplate jdbc) { this.jdbc = jdbc; }
        @Transactional public void saveRow(String row) {
            if (row.equals("BAD")) throw new IllegalArgumentException("строка не прошла проверку: " + row);
            jdbc.update("insert into registry_row(id) values (?)", row);
        }
    }

    /** До переноса: импорт вызывает чужой бин и ловит исключение проверки строки. */
    public static class ImportWithWriter {
        final RowWriter writer;
        ImportWithWriter(RowWriter writer) { this.writer = writer; }
        @Transactional public void importRegistry(List<String> rows) {
            for (String r : rows) try { writer.saveRow(r); } catch (IllegalArgumentException e) { /* пропустить строку */ }
        }
    }

    /** После переноса: тот же метод в классе импорта, вызов идёт через this. */
    public static class ImportSelf {
        final JdbcTemplate jdbc;
        ImportSelf(JdbcTemplate jdbc) { this.jdbc = jdbc; }
        @Transactional public void importRegistry(List<String> rows) {
            for (String r : rows) try { saveRow(r); } catch (IllegalArgumentException e) { /* пропустить строку */ }
        }
        @Transactional public void saveRow(String row) {
            if (row.equals("BAD")) throw new IllegalArgumentException("строка не прошла проверку: " + row);
            jdbc.update("insert into registry_row(id) values (?)", row);
        }
    }

    /** Исправление: отдельный бин и без перехвата исключения. */
    public static class ImportFixed {
        final RowWriter writer;
        ImportFixed(RowWriter writer) { this.writer = writer; }
        @Transactional public void importRegistry(List<String> rows) { for (String r : rows) writer.saveRow(r); }
    }

    @Configuration @EnableTransactionManagement
    static class RegistryBeans {
        @Bean HikariDataSource dataSource() { return h2("registry"); }
        @Bean JdbcTemplate jdbc(DataSource ds) { return new JdbcTemplate(ds); }
        @Bean PlatformTransactionManager txManager(DataSource ds) { return new DataSourceTransactionManager(ds); }
        @Bean RowWriter rowWriter(JdbcTemplate jdbc) { return new RowWriter(jdbc); }
        @Bean ImportWithWriter importWithWriter(RowWriter w) { return new ImportWithWriter(w); }
        @Bean ImportSelf importSelf(JdbcTemplate jdbc) { return new ImportSelf(jdbc); }
        @Bean ImportFixed importFixed(RowWriter w) { return new ImportFixed(w); }
    }

    static void incident2() {
        System.out.println("== 16.2 реестр из 4 строк, третья не проходит проверку");
        var ctx = new AnnotationConfigApplicationContext(RegistryBeans.class);
        JdbcTemplate jdbc = ctx.getBean(JdbcTemplate.class);
        jdbc.execute("create table registry_row(id varchar(10) primary key)");
        record Variant(String title, Runnable call) { }
        for (Variant v : List.of(
                new Variant("до переноса: saveRow в отдельном бине, импорт ловит исключение", () -> ctx.getBean(ImportWithWriter.class).importRegistry(REGISTRY)),
                new Variant("после переноса: saveRow в классе импорта, вызов через this", () -> ctx.getBean(ImportSelf.class).importRegistry(REGISTRY)),
                new Variant("исправление: отдельный бин, исключение не перехватывается", () -> ctx.getBean(ImportFixed.class).importRegistry(REGISTRY)))) {
            jdbc.update("delete from registry_row");
            System.out.println("   " + v.title + ":");
            try {
                v.call.run();
                System.out.println("      импорт завершился без исключения");
            } catch (Exception e) {
                System.out.println("      импорт бросил " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            System.out.println("      строк в таблице: " + jdbc.queryForList("select id from registry_row order by id", String.class));
        }
        System.out.println("   тест в собственной транзакции, как с @DataJpaTest или @Transactional на тесте (до переноса):");
        var tt = new org.springframework.transaction.support.TransactionTemplate(ctx.getBean(PlatformTransactionManager.class));
        jdbc.update("delete from registry_row");
        tt.executeWithoutResult(status -> {
            try {
                ctx.getBean(ImportWithWriter.class).importRegistry(REGISTRY);
                System.out.println("      импорт завершился без исключения");
            } catch (Exception e) {
                System.out.println("      импорт бросил " + e.getClass().getSimpleName());
            }
            System.out.println("      строк, видимых тесту: " + jdbc.queryForList("select id from registry_row order by id", String.class)
                    + ", транзакция помечена к откату: " + status.isRollbackOnly());
            status.setRollbackOnly();                           // так тестовый фреймворк откатывает транзакцию теста
        });
        ctx.close();
    }

    // ---------- 16.4 ----------
    public record OrderAccepted(String id) { }

    @Entity(name = "audit_record")
    public static class AuditRecord {
        @Id @GeneratedValue Long id;
        String orderId;
        protected AuditRecord() { }
        AuditRecord(String orderId) { this.orderId = orderId; }
    }

    public interface AuditRepository extends JpaRepository<AuditRecord, Long> { }

    public static class OrderService {
        final JdbcTemplate jdbc;
        final ApplicationEventPublisher events;
        OrderService(JdbcTemplate jdbc, ApplicationEventPublisher events) { this.jdbc = jdbc; this.events = events; }
        @Transactional public void accept(String id) {
            jdbc.update("insert into payment_order(id) values (?)", id);
            events.publishEvent(new OrderAccepted(id));
        }
    }

    /** Старая версия: аудит через JdbcTemplate без новой транзакции. */
    public static class JdbcAudit {
        final JdbcTemplate jdbc;
        JdbcAudit(JdbcTemplate jdbc) { this.jdbc = jdbc; }
        @TransactionalEventListener public void on(OrderAccepted e) {
            jdbc.update("insert into audit_record(id, order_id) values (next value for audit_record_seq, ?)", e.id());
        }
    }

    /** После перехода: тот же слушатель, запись через репозиторий Spring Data JPA. */
    public static class JpaAudit {
        final AuditRepository repo;
        JpaAudit(AuditRepository repo) { this.repo = repo; }
        @TransactionalEventListener public void on(OrderAccepted e) {
            AuditRecord saved = repo.save(new AuditRecord(e.id()));
            System.out.println("      save() вернул запись с id = " + saved.id);
        }
    }

    /** Исправление: новая транзакция для записи аудита. */
    public static class JpaAuditNew {
        final AuditRepository repo;
        JpaAuditNew(AuditRepository repo) { this.repo = repo; }
        @TransactionalEventListener @Transactional(propagation = Propagation.REQUIRES_NEW)
        public void on(OrderAccepted e) { repo.save(new AuditRecord(e.id())); }
    }

    /** Ошибка конфигурации: @Transactional без REQUIRES_NEW на слушателе. */
    public static class JpaAuditRequired {
        final AuditRepository repo;
        JpaAuditRequired(AuditRepository repo) { this.repo = repo; }
        @TransactionalEventListener @Transactional
        public void on(OrderAccepted e) { repo.save(new AuditRecord(e.id())); }
    }

    @Configuration @EnableTransactionManagement
    @EnableJpaRepositories(basePackageClasses = IncidentsLab2.class, considerNestedRepositories = true)
    static class JpaBeans {
        @Bean HikariDataSource dataSource() { return h2("orders-jpa-" + System.nanoTime()); }
        @Bean JdbcTemplate jdbc(DataSource ds) { return new JdbcTemplate(ds); }
        @Bean LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource ds) {
            var f = new LocalContainerEntityManagerFactoryBean();
            f.setDataSource(ds);
            f.setPackagesToScan(IncidentsLab2.class.getPackageName());
            f.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
            Properties p = new Properties();
            p.put("hibernate.hbm2ddl.auto", "create");
            f.setJpaProperties(p);
            return f;
        }
        @Bean PlatformTransactionManager transactionManager(jakarta.persistence.EntityManagerFactory emf) { return new JpaTransactionManager(emf); }
        @Bean OrderService orderService(JdbcTemplate jdbc, ApplicationEventPublisher ev) { return new OrderService(jdbc, ev); }
    }

    @Configuration @EnableTransactionManagement
    static class JdbcBeans {
        @Bean HikariDataSource dataSource() { return h2("orders-jdbc"); }
        @Bean JdbcTemplate jdbc(DataSource ds) { return new JdbcTemplate(ds); }
        @Bean PlatformTransactionManager transactionManager(DataSource ds) { return new DataSourceTransactionManager(ds); }
        @Bean OrderService orderService(JdbcTemplate jdbc, ApplicationEventPublisher ev) { return new OrderService(jdbc, ev); }
        @Bean JdbcAudit audit(JdbcTemplate jdbc) { return new JdbcAudit(jdbc); }
    }

    /** Проверка механизма: пул без автофиксации, менеджеру транзакций нечего восстанавливать при очистке. */
    @Configuration @EnableTransactionManagement
    static class JdbcNoAutoCommit extends JdbcBeans {
        @Override @Bean HikariDataSource dataSource() { return h2("orders-jdbc-nac", false); }
    }

    @Configuration @Import(JpaBeans.class) static class JpaPlain { @Bean JpaAudit audit(AuditRepository r) { return new JpaAudit(r); } }
    @Configuration @Import(JpaBeans.class) static class JpaNew { @Bean JpaAuditNew audit(AuditRepository r) { return new JpaAuditNew(r); } }
    @Configuration @Import(JpaBeans.class) static class JpaRequired { @Bean JpaAuditRequired audit(AuditRepository r) { return new JpaAuditRequired(r); } }

    static void incident4() {
        System.out.println("== 16.4 слушатель @TransactionalEventListener (AFTER_COMMIT) пишет аудит принятого поручения");
        for (Class<?> cfg : List.of(JdbcBeans.class, JdbcNoAutoCommit.class, JpaPlain.class, JpaNew.class, JpaRequired.class)) {
            String title = switch (cfg.getSimpleName()) {
                case "JdbcBeans" -> "JdbcTemplate, DataSourceTransactionManager, без новой транзакции";
                case "JdbcNoAutoCommit" -> "JdbcTemplate, пул с autoCommit = false, без новой транзакции";
                case "JpaPlain" -> "Spring Data JPA, JpaTransactionManager, без новой транзакции";
                case "JpaNew" -> "Spring Data JPA, слушатель с REQUIRES_NEW";
                default -> "Spring Data JPA, слушатель с @Transactional (REQUIRED)";
            };
            System.out.println("   " + title + ":");
            AnnotationConfigApplicationContext ctx;
            try {
                ctx = new AnnotationConfigApplicationContext(cfg);
            } catch (Exception e) {
                Throwable c = e;
                while (c.getCause() != null) c = c.getCause();
                System.out.println("      контекст не поднялся: " + c.getClass().getSimpleName() + ": " + c.getMessage());
                continue;
            }
            JdbcTemplate jdbc = ctx.getBean(JdbcTemplate.class);
            jdbc.execute("create table payment_order(id varchar(20) primary key)");
            if (cfg == JdbcBeans.class || cfg == JdbcNoAutoCommit.class) {
                jdbc.execute("create sequence audit_record_seq");
                jdbc.execute("create table audit_record(id bigint primary key, order_id varchar(20))");
            }
            ctx.getBean(OrderService.class).accept("PO-1001");
            ctx.getBean(OrderService.class).accept("PO-1002");
            System.out.println("      поручений в базе: " + jdbc.queryForObject("select count(*) from payment_order", Integer.class)
                    + ", записей аудита: " + jdbc.queryForObject("select count(*) from audit_record", Integer.class));
            ctx.close();
        }
    }

    public static void main(String[] args) {
        incident2();
        incident4();
    }
}
