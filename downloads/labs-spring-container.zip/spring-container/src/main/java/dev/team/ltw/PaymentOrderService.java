package dev.team.ltw;

import java.util.List;

/** Обычный класс без Spring: объект создаётся через new, внутренний вызов идёт через this. */
public class PaymentOrderService {
    public void processAll(List<String> orders) { orders.forEach(this::process); }
    public void process(String order) { System.out.println("   проведено " + order); }

    public static void main(String[] args) {
        System.out.println("класс объекта: " + new PaymentOrderService().getClass().getName());
        new PaymentOrderService().processAll(List.of("п/п 19", "п/п 20"));
    }
}
