package dev.team.ltw;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

/** Опыт разд. 9.6: тот же аспект аудита, вплетённый AspectJ при загрузке класса. */
@Aspect
public class AuditAspect {
    @Around("execution(* dev.team.ltw.PaymentOrderService.process(..))")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("   [аудит] " + pjp.getSignature().getName() + "(" + pjp.getArgs()[0] + ")");
        return pjp.proceed();
    }
}
