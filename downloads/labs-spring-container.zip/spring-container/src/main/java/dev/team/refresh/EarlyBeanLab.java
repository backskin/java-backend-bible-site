package dev.team.refresh;

import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashSet;
import java.util.Set;

/** Опыт 2: бин, созданный раньше постпроцессоров, теряет их обработку. */
public class EarlyBeanLab {

    /** Постпроцессор, который «оборачивает» бины, как это делает AOP: отмечает, кого он обработал. */
    static final Set<String> wrapped = new HashSet<>();
    static class AuditingBpp implements BeanPostProcessor {
        @Override public Object postProcessAfterInitialization(Object bean, String name) {
            if (bean instanceof LimitProperties) wrapped.add(name);
            return bean;
        }
    }

    public static class LimitProperties { }

    /** Нестатический BFPP в конфигурации с зависимостью через конструктор: конфигурацию создают на шаге 5. */
    @Configuration
    public static class CtorConfig {
        private final LimitProperties props;
        public CtorConfig(LimitProperties props) { this.props = props; }
        @Bean public BeanFactoryPostProcessor noop() { return bf -> { }; }
        @Bean public static AuditingBpp auditing() { return new AuditingBpp(); }
    }

    /** Статический BFPP, но с параметром: параметр тоже создаётся на шаге 5. */
    @Configuration
    public static class ParamConfig {
        @Bean public static BeanFactoryPostProcessor noop(LimitProperties p) { return bf -> { }; }
        @Bean public static AuditingBpp auditing() { return new AuditingBpp(); }
    }

    /** Постпроцессор бинов зависит от бизнес-бина: бин создаётся на шаге 6, пока регистрируются BPP. */
    @Configuration
    public static class BppDepConfig {
        @Bean public static AuditingBpp auditing() { return new AuditingBpp(); }
        @Bean public static BeanPostProcessor limitsAware(LimitProperties p) { return new BeanPostProcessor() { }; }
    }

    /** Статический BFPP без параметров: ничего раньше времени не создаётся. */
    @Configuration
    public static class GoodConfig {
        @Bean public static BeanFactoryPostProcessor noop() { return bf -> { }; }
        @Bean public static AuditingBpp auditing() { return new AuditingBpp(); }
    }

    static void run(Class<?> config) {
        wrapped.clear();
        try (var ctx = new AnnotationConfigApplicationContext()) {
            ctx.registerBean("limitProperties", LimitProperties.class);
            ctx.register(config);
            ctx.refresh();
            System.out.println(config.getSimpleName() + ": постпроцессор обработал limitProperties = " + wrapped.contains("limitProperties"));
        } catch (Exception e) {
            Throwable root = e; while (root.getCause() != null) root = root.getCause();
            System.out.println(config.getSimpleName() + ": контекст не поднялся — " + root.getClass().getSimpleName() + ": " + root.getMessage());
        }
    }

    public static void main(String[] args) {
        run(CtorConfig.class);
        run(ParamConfig.class);
        run(BppDepConfig.class);
        run(GoodConfig.class);
    }
}
