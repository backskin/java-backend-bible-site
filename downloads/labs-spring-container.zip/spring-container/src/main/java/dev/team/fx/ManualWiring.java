package dev.team.fx;

import java.math.BigDecimal;
import java.util.Map;
import java.util.function.Supplier;

/** Ручное внедрение: всё конструирование собрано в main, остальной код получает готовые объекты. */
public class ManualWiring {

    /** Отчёт создаёт конвертер на каждую дату сам, но как его собрать, решает main: ему передают фабрику. */
    static final class DailyReport {
        private final Supplier<? extends CurrencyConverter> converterFactory;
        DailyReport(Supplier<? extends CurrencyConverter> converterFactory) { this.converterFactory = converterFactory; }
        BigDecimal totalRub(Map<String, BigDecimal> balances) {
            CurrencyConverter c = converterFactory.get();
            return balances.entrySet().stream()
                    .map(e -> c.toRub(e.getValue(), e.getKey()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
        }
    }

    public static void main(String[] args) {
        // рабочая сборка: курсы ЦБ на дату
        RateSource cbr = ccy -> switch (ccy) { case "USD" -> new BigDecimal("81.20"); case "EUR" -> new BigDecimal("94.10"); default -> throw new IllegalArgumentException(ccy); };
        CurrencyConverter prod = new CurrencyConverter(cbr);
        System.out.println("100 USD по курсу ЦБ: " + prod.toRub(new BigDecimal("100"), "USD"));

        // тестовая сборка: тот же класс, другой источник — без изменения кода конвертера
        CurrencyConverter test = new CurrencyConverter(ccy -> BigDecimal.ONE);
        System.out.println("100 USD по курсу-заглушке: " + test.toRub(new BigDecimal("100"), "USD"));

        // статический вариант нельзя перенастроить: курс зашит
        System.out.println("100 USD в StaticConverter: " + StaticConverter.toRub(new BigDecimal("100"), "USD"));

        DailyReport report = new DailyReport(() -> new CurrencyConverter(cbr));
        System.out.println("отчёт по остаткам 100 USD + 50 EUR: " + report.totalRub(Map.of("USD", new BigDecimal("100"), "EUR", new BigDecimal("50"))));
    }
}
