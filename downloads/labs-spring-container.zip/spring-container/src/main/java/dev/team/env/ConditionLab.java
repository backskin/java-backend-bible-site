package dev.team.env;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.util.ClassUtils;

import java.util.Arrays;
import java.util.Map;

/** Опыт разд. 11.2: собственное условие и @ConditionalOnMissingBean в пользовательских конфигурациях. */
public class ConditionLab {
    /** Конфигурация отправки в Kafka включается, если выбран режим kafka и клиент Kafka есть в classpath. */
    static class OnKafkaMode implements Condition {
        @Override public boolean matches(ConditionContext ctx, AnnotatedTypeMetadata md) {
            boolean mode = "kafka".equals(ctx.getEnvironment().getProperty("app.notify.mode"));
            boolean client = ClassUtils.isPresent("org.apache.kafka.clients.producer.KafkaProducer", ctx.getClassLoader());
            System.out.println("   OnKafkaMode: режим kafka " + mode + ", клиент Kafka в classpath " + client);
            return mode && client;
        }
    }

    interface Notifier { String name(); }

    @Configuration @Conditional(OnKafkaMode.class)
    static class KafkaNotifierConfig { @Bean Notifier kafkaNotifier() { return () -> "kafka"; } }

    interface FeeCalculator { String name(); }

    @Configuration
    static class DefaultFeeConfig {
        @Bean @ConditionalOnMissingBean(FeeCalculator.class) FeeCalculator defaultFee() { return () -> "по умолчанию"; }
    }

    @Configuration
    static class CustomFeeConfig {
        @Bean FeeCalculator corporateFee() { return () -> "корпоративный тариф"; }
    }

    static void fee(Class<?>... order) {
        try (var ctx = new AnnotationConfigApplicationContext(order)) {
            Map<String, FeeCalculator> beans = ctx.getBeansOfType(FeeCalculator.class);
            System.out.printf("   порядок %s: бины %s%n", Arrays.stream(order).map(Class::getSimpleName).toList(), beans.keySet());
        }
    }

    public static void main(String[] args) {
        System.out.println("== собственное условие");
        for (String mode : new String[] {"sms", "kafka"}) {
            var ctx = new AnnotationConfigApplicationContext();
            ctx.getEnvironment().getSystemProperties().put("app.notify.mode", mode);
            ctx.register(KafkaNotifierConfig.class);
            ctx.refresh();
            System.out.println("   app.notify.mode=" + mode + ": бинов Notifier " + ctx.getBeanNamesForType(Notifier.class).length);
            ctx.close();
        }
        System.out.println("== @ConditionalOnMissingBean в пользовательских конфигурациях");
        fee(DefaultFeeConfig.class, CustomFeeConfig.class);
        fee(CustomFeeConfig.class, DefaultFeeConfig.class);
    }
}
