package dev.team.env;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.convert.converter.Converter;
import org.springframework.format.support.DefaultFormattingConversionService;

import java.time.Duration;

/** Опыт разд. 11.4: строки из настроек в Duration, номер счёта и enum — в «голом» Spring и в Boot. */
public class ConversionLab {
    /** Номер счёта: двадцать цифр без пробелов. */
    public record AccountNumber(String digits) {
        public AccountNumber { if (!digits.matches("\\d{20}")) throw new IllegalArgumentException("номер счёта: '" + digits + "'"); }
    }

    public enum SettleMode { REAL_TIME, BATCH }

    public static class AccountConverter implements Converter<String, AccountNumber> {
        @Override public AccountNumber convert(String s) { return new AccountNumber(s.replaceAll("\\s", "")); }
    }

    public static class IsoTimeout { @Value("${settle.iso-timeout}") Duration timeout; }
    public static class ShortTimeout { @Value("${settle.timeout}") Duration timeout; }
    public static class SettlementAccount { @Value("${settle.account}") AccountNumber account; }
    public static class SettlementMode { @Value("${settle.mode}") SettleMode mode; }

    @Configuration @PropertySource("classpath:env/settle.properties")
    static class Base { @Bean static PropertySourcesPlaceholderConfigurer pspc() { return new PropertySourcesPlaceholderConfigurer(); } }

    @Configuration
    static class WithConversionService {
        @Bean DefaultFormattingConversionService conversionService() {
            var cs = new DefaultFormattingConversionService();
            cs.addConverter(new AccountConverter());
            return cs;
        }
    }

    static void plain(String title, Class<?>... cfg) {
        System.out.println("== " + title);
        for (Class<?> bean : new Class<?>[] {IsoTimeout.class, ShortTimeout.class, SettlementAccount.class, SettlementMode.class}) {
            Class<?>[] all = java.util.stream.Stream.concat(java.util.Arrays.stream(cfg), java.util.stream.Stream.of(bean)).toArray(Class<?>[]::new);
            try (var ctx = new AnnotationConfigApplicationContext(all)) {
                Object b = ctx.getBean(bean);
                String v = b instanceof IsoTimeout s ? "PT45S -> " + s.timeout : b instanceof ShortTimeout s ? "30s -> " + s.timeout
                        : b instanceof SettlementAccount a ? "account=" + a.account : "mode=" + ((SettlementMode) b).mode;
                System.out.println("   " + bean.getSimpleName() + ": " + v);
            } catch (Exception e) {
                Throwable r = e; while (r.getCause() != null) r = r.getCause();
                System.out.println("   " + bean.getSimpleName() + ": " + r.getClass().getSimpleName() + ": " + r.getMessage());
            }
        }
    }

    @ConfigurationProperties("settle")
    public record SettleProps(Duration timeout, AccountNumber account, SettleMode mode) {}

    @SpringBootConfiguration @EnableAutoConfiguration @EnableConfigurationProperties(SettleProps.class)
    public static class BootWithoutBinding { @Bean AccountConverter accountConverter() { return new AccountConverter(); } }

    @SpringBootConfiguration @EnableAutoConfiguration @EnableConfigurationProperties(SettleProps.class)
    public static class BootWithBinding { @Bean @ConfigurationPropertiesBinding AccountConverter accountConverter() { return new AccountConverter(); } }

    static void boot(String title, Class<?> app) {
        var a = new SpringApplication(app);
        a.setWebApplicationType(WebApplicationType.NONE); a.setBannerMode(Banner.Mode.OFF); a.setLogStartupInfo(false);
        try (var ctx = a.run("--spring.config.location=classpath:env/settle.properties")) {
            System.out.println("== " + title + ": " + ctx.getBean(SettleProps.class));
        } catch (Exception e) {
            Throwable r = e; while (r.getCause() != null) r = r.getCause();
            System.out.println("== " + title + ": " + r.getClass().getSimpleName() + ": " + r.getMessage());
        }
    }

    public static void main(String[] args) {
        plain("«голый» Spring без ConversionService", Base.class);
        plain("«голый» Spring с бином conversionService", Base.class, WithConversionService.class);
        boot("Boot, @ConfigurationProperties, конвертер без @ConfigurationPropertiesBinding", BootWithoutBinding.class);
        boot("Boot, @ConfigurationProperties, конвертер с @ConfigurationPropertiesBinding", BootWithBinding.class);
    }
}
