package dev.team.proxy;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Lazy;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.List;

/** Опыт разд. 8.3: вызов метода того же бина через this, через внедрённый прокси и через AopContext. */
public class SelfInvocationLab {
    @Retention(RetentionPolicy.RUNTIME) @Target(ElementType.METHOD)
    public @interface Audited {}

    @Aspect
    public static class AuditAspect {
        @Around("@annotation(dev.team.proxy.SelfInvocationLab.Audited)")
        public Object around(ProceedingJoinPoint pjp) throws Throwable {
            System.out.println("   [аудит] " + pjp.getSignature().getName() + "(" + pjp.getArgs()[0] + ")");
            return pjp.proceed();
        }
    }

    public static class PaymentOrderService {
        @Autowired @Lazy PaymentOrderService self;

        public void processAll(List<String> orders) {
            System.out.println("1) через this:");
            orders.forEach(this::process);
            System.out.println("2) через внедрённый self:");
            orders.forEach(self::process);
            System.out.println("3) через AopContext.currentProxy():");
            orders.forEach(o -> ((PaymentOrderService) AopContext.currentProxy()).process(o));
        }

        @Audited
        public void process(String order) { System.out.println("   проведено " + order); }
    }

    @Configuration
    @EnableAspectJAutoProxy(exposeProxy = true)
    public static class Cfg {
        @Bean AuditAspect auditAspect() { return new AuditAspect(); }
        @Bean PaymentOrderService paymentOrderService() { return new PaymentOrderService(); }
    }

    @Configuration
    @EnableAspectJAutoProxy
    public static class NoExpose {
        @Bean AuditAspect auditAspect() { return new AuditAspect(); }
        @Bean PaymentOrderService paymentOrderService() { return new PaymentOrderService(); }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            var s = ctx.getBean(PaymentOrderService.class);
            System.out.println("класс бина: " + s.getClass().getSimpleName());
            s.processAll(List.of("п/п 17"));
        }
        System.out.println("без exposeProxy:");
        try (var ctx = new AnnotationConfigApplicationContext(NoExpose.class)) {
            ctx.getBean(PaymentOrderService.class).processAll(List.of("п/п 18"));
        } catch (IllegalStateException e) {
            System.out.println("   " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
