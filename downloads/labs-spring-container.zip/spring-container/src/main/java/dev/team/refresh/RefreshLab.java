package dev.team.refresh;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.SmartLifecycle;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;

/** Опыт 1: в каком порядке срабатывают точки расширения при refresh(). */
public class RefreshLab {
    static int step = 0;
    static void log(String s) { System.out.printf("%2d. %s%n", ++step, s); }

    /** Бин приложения: платёжный сервис. */
    public static class PaymentService implements SmartInitializingSingleton {
        public PaymentService() { log("PaymentService: конструктор"); }
        @PostConstruct void init() { log("PaymentService: @PostConstruct"); }
        @Override public void afterSingletonsInstantiated() { log("PaymentService: afterSingletonsInstantiated — все синглтоны созданы"); }
    }

    /** Потребитель очереди: стартует последним, когда всё готово. */
    public static class QueueConsumer implements SmartLifecycle {
        private boolean running;
        @Override public void start() { running = true; log("QueueConsumer: SmartLifecycle.start — начинаем читать очередь"); }
        @Override public void stop() { running = false; }
        @Override public boolean isRunning() { return running; }
    }

    @Configuration
    public static class AppConfig {
        @Bean static BeanDefinitionRegistryPostProcessor registrar() {
            return new BeanDefinitionRegistryPostProcessor() {
                @Override public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry r) {
                    r.registerBeanDefinition("queueConsumer", new RootBeanDefinition(QueueConsumer.class));
                    log("BeanDefinitionRegistryPostProcessor: добавил описание queueConsumer (объектов приложения ещё нет)");
                }
                @Override public void postProcessBeanFactory(ConfigurableListableBeanFactory bf) { }
            };
        }

        @Bean static BeanFactoryPostProcessor inspector() {
            return bf -> log("BeanFactoryPostProcessor: описаний в реестре " + bf.getBeanDefinitionCount()
                    + ", создан ли paymentService: " + bf.containsSingleton("paymentService"));
        }

        @Bean static BeanPostProcessor tracer() {
            log("BeanPostProcessor tracer: создан (регистрация постпроцессоров)");
            return new BeanPostProcessor() {
                @Override public Object postProcessBeforeInitialization(Object bean, String name) throws BeansException {
                    if (name.equals("paymentService")) log("BeanPostProcessor: before init для " + name);
                    return bean;
                }
                @Override public Object postProcessAfterInitialization(Object bean, String name) throws BeansException {
                    if (name.equals("paymentService")) log("BeanPostProcessor: after init для " + name + " (здесь создаются прокси)");
                    return bean;
                }
            };
        }

        @Bean PaymentService paymentService() { return new PaymentService(); }

        @EventListener void onRefreshed(ContextRefreshedEvent e) { log("ContextRefreshedEvent: контекст поднят"); }
    }

    public static void main(String[] args) {
        var ctx = new AnnotationConfigApplicationContext();
        ctx.register(AppConfig.class);
        log("до refresh(): зарегистрирован только класс конфигурации");
        ctx.refresh();
        log("refresh() вернул управление");
        ctx.close();
    }
}
