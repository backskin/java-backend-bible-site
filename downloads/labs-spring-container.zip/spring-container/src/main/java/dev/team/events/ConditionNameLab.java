package dev.team.events;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.event.EventListener;

import java.math.BigDecimal;

/** Опыт разд. 10.1: как условие слушателя обращается к событию, с флагом компилятора -parameters и без него. */
public class ConditionNameLab {
    public record OrderAccepted(long orderId, BigDecimal amount) {}

    public static class ByName { @EventListener(condition = "#event.amount >= 600000") public void on(OrderAccepted event) { System.out.println("сработал"); } }
    public static class ByIndex { @EventListener(condition = "#a0.amount >= 600000") public void on(OrderAccepted event) { System.out.println("сработал"); } }
    public static class ByRootEvent { @EventListener(condition = "#root.event.amount >= 600000") public void on(OrderAccepted event) { System.out.println("сработал"); } }
    public static class ByRootPayload { @EventListener(condition = "#root.event.payload.amount >= 600000") public void on(OrderAccepted event) { System.out.println("сработал"); } }
    public static class ByRootArgs { @EventListener(condition = "#root.args[0].amount >= 600000") public void on(OrderAccepted event) { System.out.println("сработал"); } }

    public static void main(String[] args) throws Exception {
        System.out.println("имена параметров в байткоде: " + ByName.class.getMethod("on", OrderAccepted.class).getParameters()[0].isNamePresent());
        for (Class<?> c : new Class<?>[] {ByName.class, ByIndex.class, ByRootEvent.class, ByRootPayload.class, ByRootArgs.class}) {
            String cond = c.getMethod("on", OrderAccepted.class).getAnnotation(EventListener.class).condition();
            System.out.printf("   %-38s ", cond);
            try (var ctx = new AnnotationConfigApplicationContext(c)) {
                ctx.publishEvent(new OrderAccepted(2, new BigDecimal("750000.00")));
            } catch (Exception e) { System.out.println(e.getMessage().replaceAll(" - maybe.*", "")); }
        }
    }
}
