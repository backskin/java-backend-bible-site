package dev.team.async;

import jakarta.annotation.PostConstruct;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/** Опыт разд. 12.1: исполнитель @Async в «голом» Spring и в Boot, ошибки, @PostConstruct. */
public class AsyncLab {
    public static class ReceiptService {
        final Set<String> threads = ConcurrentHashMap.newKeySet();
        public Set<String> threads() { return threads; }
        @Async public void sendReceipt(long orderId) { threads.add(Thread.currentThread().toString().replaceAll("@[0-9a-f]+", "")); }
        @Async public void failVoid(long orderId) { throw new IllegalStateException("ОФД недоступен, чек " + orderId); }
        @Async public CompletableFuture<String> fiscalize(long orderId) {
            if (orderId == 2) throw new IllegalStateException("ОФД недоступен, чек " + orderId);
            return CompletableFuture.completedFuture("чек " + orderId + " фискализирован");
        }
        @PostConstruct @Async public void warmUp() { System.out.println("   @PostConstruct @Async warmUp: поток " + Thread.currentThread().getName()); }
    }

    @Configuration @EnableAsync
    static class Plain { @Bean ReceiptService receiptService() { return new ReceiptService(); } }

    @SpringBootConfiguration @EnableAutoConfiguration @EnableAsync
    public static class Boot { @Bean ReceiptService receiptService() { return new ReceiptService(); } }

    static void exercise(ReceiptService s) throws Exception {
        for (int i = 0; i < 20; i++) s.sendReceipt(i);
        Thread.sleep(300);
        var th = s.threads();
        System.out.println("   20 вызовов sendReceipt выполнены в потоках (" + th.size() + "): "
                + th.stream().sorted().limit(3).toList() + (th.size() > 3 ? " …" : ""));
        s.failVoid(1);
        Thread.sleep(100);
        s.fiscalize(2).exceptionally(e -> { System.out.println("   CompletableFuture получил ошибку: " + e.getCause().getMessage()); return null; }).get(1, TimeUnit.SECONDS);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== «голый» Spring, своего исполнителя нет");
        try (var ctx = new AnnotationConfigApplicationContext(Plain.class)) { exercise(ctx.getBean(ReceiptService.class)); }
        for (String[] boot : new String[][] {{}, {"--spring.threads.virtual.enabled=true"}}) {
            System.out.println("== Spring Boot 4.1.1 " + String.join(" ", boot));
            var app = new SpringApplication(Boot.class);
            app.setWebApplicationType(WebApplicationType.NONE); app.setBannerMode(Banner.Mode.OFF); app.setLogStartupInfo(false);
            try (var ctx = app.run(boot)) {
                Object ex = ctx.getBean("applicationTaskExecutor");
                System.out.print("   applicationTaskExecutor: " + ex.getClass().getSimpleName());
                if (ex instanceof ThreadPoolTaskExecutor t)
                    System.out.printf(", core=%d, max=%s, очередь %s%n", t.getCorePoolSize(),
                            t.getMaxPoolSize() == Integer.MAX_VALUE ? "Integer.MAX_VALUE" : t.getMaxPoolSize(),
                            t.getQueueCapacity() == Integer.MAX_VALUE ? "Integer.MAX_VALUE" : t.getQueueCapacity());
                else System.out.println();
                exercise(ctx.getBean(ReceiptService.class));
            }
        }
    }
}
