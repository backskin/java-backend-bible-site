package dev.team.async;

import org.springframework.context.SmartLifecycle;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/** Опыт разд. 12.3: порядок фаз SmartLifecycle и остановка пула с незавершёнными задачами. */
public class ShutdownLab {
    /** Компонент с фазой: потребитель платёжных событий и пул соединений со шлюзом. */
    record Component(String name, int phase) implements SmartLifecycle {
        static final java.util.Map<String, Boolean> running = new java.util.concurrent.ConcurrentHashMap<>();
        @Override public void start() { running.put(name, true); System.out.println("   start " + name + " (фаза " + phase + ")"); }
        @Override public void stop() { running.put(name, false); System.out.println("   stop  " + name + " (фаза " + phase + ")"); }
        @Override public boolean isRunning() { return running.getOrDefault(name, false); }
        @Override public int getPhase() { return phase; }
    }

    @Configuration
    static class Phases {
        @Bean Component consumer() { return new Component("потребитель Kafka", Integer.MAX_VALUE - 100); }
        @Bean Component gatewayPool() { return new Component("пул соединений со шлюзом", -100); }
        @Bean Component cache() { return new Component("прогрев справочников", 0); }
    }

    static void pool(boolean wait) throws Exception {
        var ex = new ThreadPoolTaskExecutor();
        ex.setCorePoolSize(2); ex.setThreadNamePrefix("settle-");
        ex.setWaitForTasksToCompleteOnShutdown(wait);
        if (wait) ex.setAwaitTerminationSeconds(5);
        ex.initialize();
        for (int i = 1; i <= 4; i++) {
            int n = i;
            ex.execute(() -> {
                try { Thread.sleep(500); System.out.println("   проводка " + n + " завершена"); }
                catch (InterruptedException e) { System.out.println("   проводка " + n + " прервана"); }
            });
        }
        Thread.sleep(100);
        long t = System.nanoTime();
        ex.shutdown();
        System.out.printf("   shutdown() вернул управление через %d мс%n", (System.nanoTime() - t) / 1_000_000);
        Thread.sleep(1500);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== фазы SmartLifecycle");
        var ctx = new AnnotationConfigApplicationContext(Phases.class);
        System.out.println("   закрываю контекст");
        ctx.close();
        System.out.println("== пул без ожидания задач, 4 проводки по 500 мс, 2 потока");
        pool(false);
        System.out.println("== waitForTasksToCompleteOnShutdown(true), awaitTermination 5 с");
        pool(true);
    }
}
