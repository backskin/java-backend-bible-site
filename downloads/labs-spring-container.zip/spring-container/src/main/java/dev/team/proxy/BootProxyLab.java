package dev.team.proxy;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;

import java.util.Arrays;

/** Опыт разд. 8.2 и 8.5: тип прокси в Spring Boot и один прокси на несколько механизмов. */
public class BootProxyLab {
    public interface Notifier { void notifyClient(String account); }

    public static class SmsNotifier implements Notifier {
        @Override public void notifyClient(String account) { }
        @Async public void notifyLater(String account) { System.out.println("   notifyLater: поток " + Thread.currentThread().getName()); }
    }

    @Aspect
    public static class TimingAspect {
        @Around("execution(* dev.team.proxy.BootProxyLab.SmsNotifier.*(..))")
        public Object time(ProceedingJoinPoint pjp) throws Throwable {
            if (pjp.getSignature().getName().equals("notifyLater")) System.out.println("   аспект: поток " + Thread.currentThread().getName());
            return pjp.proceed();
        }
    }

    @SpringBootConfiguration
    @EnableAutoConfiguration
    @EnableAsync
    public static class App {
        @Bean SmsNotifier smsNotifier() { return new SmsNotifier(); }
        @Bean TimingAspect timingAspect() { return new TimingAspect(); }
    }

    static void run(String... props) {
        var app = new SpringApplication(App.class);
        app.setWebApplicationType(WebApplicationType.NONE);
        app.setLogStartupInfo(false);
        app.setBannerMode(org.springframework.boot.Banner.Mode.OFF);
        try (var ctx = app.run(props)) {
            Object bean = ctx.getBean("smsNotifier");
            String advisors = Arrays.stream(((Advised) bean).getAdvisors())
                    .map(a -> a.getAdvice().getClass().getSimpleName()).toList().toString();
            System.out.printf("%-40s %s, CGLIB %s; советы %s; цель — прокси: %s%n",
                    props.length == 0 ? "без настроек:" : String.join(" ", props) + ":",
                    bean.getClass().getSimpleName(), AopUtils.isCglibProxy(bean), advisors,
                    AopUtils.isAopProxy(((Advised) bean).getTargetSource().getTarget()));
            if (props.length == 0) { System.out.println("   вызов notifyLater из потока " + Thread.currentThread().getName()); ((SmsNotifier) bean).notifyLater("acc-1"); Thread.sleep(300); }
            try { ctx.getBean("smsNotifier", SmsNotifier.class); System.out.println("   getBean по классу SmsNotifier: найден"); }
            catch (Exception e) { System.out.println("   getBean по классу SmsNotifier: " + e.getClass().getSimpleName() + ": " + e.getMessage().replace("dev.team.proxy.BootProxyLab$", "")); }
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    public static void main(String[] args) {
        run();
        run("--spring.aop.proxy-target-class=false");
    }
}
