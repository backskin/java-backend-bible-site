package dev.team.cycles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

/** Опыты разд. 6: циклические зависимости между сервисом платежей и сервисом лимитов. */
public class CycleLab {

    // --- цикл через конструкторы
    @Component public static class PaymentsCtor { public PaymentsCtor(LimitsCtor l) { } }
    @Component public static class LimitsCtor { public LimitsCtor(PaymentsCtor p) { } }

    // --- цикл через сеттеры
    @Component public static class PaymentsSetter { LimitsSetter limits; @Autowired void setLimits(LimitsSetter l) { limits = l; } }
    @Component public static class LimitsSetter { PaymentsSetter payments; @Autowired void setPayments(PaymentsSetter p) { payments = p; } }

    // --- цикл через сеттеры, один из бинов получает прокси от @Async
    @Configuration @EnableAsync public static class AsyncCfg { }
    @Component public static class PaymentsAsync {
        LimitsAsync limits;
        @Autowired void setLimits(LimitsAsync l) { limits = l; }
        @Async public void notifyAsync() { }
    }
    @Component public static class LimitsAsync { PaymentsAsync payments; @Autowired void setPayments(PaymentsAsync p) { payments = p; } }

    // --- цикл через конструкторы, разорванный @Lazy
    @Component public static class PaymentsLazy { final LimitsLazy limits; public PaymentsLazy(@Lazy LimitsLazy l) { limits = l; } }
    @Component public static class LimitsLazy { final PaymentsLazy payments; public LimitsLazy(PaymentsLazy p) { payments = p; } }

    static String root(Throwable e) {
        String first = e.getMessage();
        Throwable r = e; while (r.getCause() != null) r = r.getCause();
        return r.getClass().getSimpleName() + ": " + r.getMessage().replace("dev.team.cycles.CycleLab$", "").replaceAll("\\s+", " ");
    }

    static void plain(String title, Class<?>... classes) {
        try (var ctx = new AnnotationConfigApplicationContext(classes)) {
            System.out.println(title + ": контекст поднялся");
            if (ctx.containsBean("cycleLab.PaymentsAsync")) {
                Object fromCtx = ctx.getBean("cycleLab.PaymentsAsync");
                Object injected = ctx.getBean(LimitsAsync.class).payments;
                System.out.println("   в контексте PaymentsAsync — прокси: " + org.springframework.aop.support.AopUtils.isAopProxy(fromCtx)
                        + "; в LimitsAsync внедрён прокси: " + org.springframework.aop.support.AopUtils.isAopProxy(injected)
                        + "; это один объект: " + (fromCtx == injected));
            }
            if (ctx.containsBean("cycleLab.PaymentsLazy")) {
                var p = ctx.getBean(PaymentsLazy.class);
                String cls = p.limits.getClass().getSimpleName();
                System.out.println("   в PaymentsLazy внедрён " + cls.substring(Math.max(0, cls.indexOf("$$")))
                        + ", прокси: " + org.springframework.aop.support.AopUtils.isAopProxy(p.limits)
                        + "; настоящий LimitsLazy держит ссылку на PaymentsLazy: " + (ctx.getBean(LimitsLazy.class).payments == p));
            }
        } catch (Exception e) {
            System.out.println(title + ": " + root(e));
        }
    }

    public static void main(String[] args) {
        plain("Spring, цикл через конструкторы", PaymentsCtor.class, LimitsCtor.class);
        plain("Spring, цикл через сеттеры", PaymentsSetter.class, LimitsSetter.class);
        plain("Spring, цикл через сеттеры с @Async", AsyncCfg.class, PaymentsAsync.class, LimitsAsync.class);
        plain("Spring, цикл через конструкторы с @Lazy", PaymentsLazy.class, LimitsLazy.class);
        try {
            var app = new SpringApplication(PaymentsSetter.class, LimitsSetter.class);
            app.setBannerMode(org.springframework.boot.Banner.Mode.OFF);
            app.setLogStartupInfo(false);
            app.run().close();
            System.out.println("Spring Boot, цикл через сеттеры: контекст поднялся");
        } catch (Exception e) {
            System.out.println("Spring Boot, цикл через сеттеры: " + root(e));
        }
    }
}
