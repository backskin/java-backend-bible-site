package dev.team.async;

import org.springframework.scheduling.support.CronExpression;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/** Опыт разд. 12.2: выражение cron из шести полей и переход на летнее время. */
public class CronLab {
    static void next(String cron, String zone, LocalDateTime from, int n) {
        var expr = CronExpression.parse(cron);
        ZonedDateTime t = from.atZone(ZoneId.of(zone));
        System.out.print("   " + cron + " в " + zone + " после " + from + ":");
        for (int i = 0; i < n; i++) { t = expr.next(t); System.out.print(" " + t.toLocalDateTime() + "(" + t.getOffset() + ")"); }
        System.out.println();
    }

    public static void main(String[] args) {
        next("0 30 2 * * *", "Europe/Berlin", LocalDateTime.of(2026, 3, 28, 12, 0), 3);   // 29.03.2026: 02:00 -> 03:00
        next("0 30 2 * * *", "Europe/Berlin", LocalDateTime.of(2026, 10, 24, 12, 0), 3);  // 25.10.2026: 03:00 -> 02:00
        next("0 30 2 * * *", "Europe/Moscow", LocalDateTime.of(2026, 3, 28, 12, 0), 2);
        try { CronExpression.parse("30 2 * * *"); } catch (IllegalArgumentException e) { System.out.println("   пять полей: " + e.getMessage()); }
        next("@daily", "Europe/Moscow", LocalDateTime.of(2026, 10, 26, 12, 0), 1);
    }
}
