package dev.team.proxy;

import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Опыт разд. 8.2, 8.4, 8.5: выбор типа прокси, Objenesis, что перехватывается, как опознать прокси. */
public class SpringProxyLab {
    @Retention(RetentionPolicy.RUNTIME) public @interface Audited {}

    public interface LimitService { BigDecimal remaining(String account); }

    @Audited
    public static class DailyLimitService implements LimitService {
        static int constructed;
        private final BigDecimal dailyLimit = new BigDecimal("500000.00");
        public DailyLimitService() { constructed++; }
        @Audited @Override public BigDecimal remaining(String account) { return dailyLimit.subtract(new BigDecimal("120000.00")); }
        public final BigDecimal limitFinal() { return dailyLimit; }
        protected String prot() { return "prot"; }
        protected final String protFinal() { return "protFinal"; }
        String pkg() { return "pkg"; }
        private String priv() { return "priv"; }
        public static String stat() { return "stat"; }
    }

    public static final class FinalService { public void run() { } }

    static final List<String> seen = new ArrayList<>();
    static final MethodInterceptor recorder = inv -> { seen.add(inv.getMethod().getName()); return inv.proceed(); };

    static Object proxy(Object target, boolean targetClass) {
        ProxyFactory pf = new ProxyFactory(target);
        pf.setProxyTargetClass(targetClass);
        pf.addAdvice(recorder);
        return pf.getProxy();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== выбор типа прокси");
        Object jdk = proxy(new DailyLimitService(), false);
        System.out.println("по умолчанию: " + jdk.getClass().getName() + ", JDK " + AopUtils.isJdkDynamicProxy(jdk)
                + ", instanceof DailyLimitService " + (jdk instanceof DailyLimitService));
        DailyLimitService.constructed = 0;
        DailyLimitService target = new DailyLimitService();
        DailyLimitService cglib = (DailyLimitService) proxy(target, true);
        System.out.println("proxyTargetClass=true: " + cglib.getClass().getName() + ", CGLIB " + AopUtils.isCglibProxy(cglib)
                + ", instanceof DailyLimitService " + (cglib instanceof DailyLimitService));
        System.out.println("конструктор DailyLimitService вызван раз: " + DailyLimitService.constructed);

        System.out.println("== поля прокси");
        var f = DailyLimitService.class.getDeclaredField("dailyLimit"); f.setAccessible(true);
        System.out.println("поле dailyLimit: у целевого объекта " + f.get(target) + ", у прокси " + f.get(cglib));
        System.out.println("remaining() через прокси: " + cglib.remaining("acc-1"));
        System.out.println("limitFinal() через прокси: " + cglib.limitFinal());

        System.out.println("== что перехвачено");
        seen.clear();
        cglib.remaining("acc-1"); cglib.prot(); cglib.pkg(); cglib.limitFinal(); DailyLimitService.stat();
        var priv = DailyLimitService.class.getDeclaredMethod("priv"); priv.setAccessible(true); priv.invoke(cglib);
        System.out.println("вызваны remaining, prot, pkg, limitFinal, stat, priv; перехвачены: " + seen);
        try { proxy(new FinalService(), true); }
        catch (Exception e) { Throwable r = e; while (r.getCause() != null) r = r.getCause();
            System.out.println("final-класс: " + e.getClass().getSimpleName() + ", причина " + r.getClass().getSimpleName() + ": " + r.getMessage().replace("dev.team.proxy.", "")); }

        System.out.println("== как опознать прокси");
        Class<?> pc = cglib.getClass();
        System.out.println("getClass() == DailyLimitService.class: " + (pc == DailyLimitService.class));
        System.out.println("@Audited на классе прокси: " + pc.isAnnotationPresent(Audited.class)
                + ", на методе remaining прокси: " + pc.getMethod("remaining", String.class).isAnnotationPresent(Audited.class));
        System.out.println("AopUtils.isAopProxy: " + AopUtils.isAopProxy(cglib) + ", ultimateTargetClass: "
                + AopProxyUtils.ultimateTargetClass(cglib).getSimpleName());
        System.out.println("@Audited на ultimateTargetClass: " + AopProxyUtils.ultimateTargetClass(cglib).isAnnotationPresent(Audited.class));
        System.out.println("советы: " + ((Advised) cglib).getAdvisors().length + ", цель из Advised — тот же объект: "
                + (((Advised) cglib).getTargetSource().getTarget() == target));
        // прокси поверх прокси
        Object outer = proxy(cglib, true);
        System.out.println("прокси поверх прокси: getTargetClass " + AopUtils.getTargetClass(outer).getSimpleName()
                + ", ultimateTargetClass " + AopProxyUtils.ultimateTargetClass(outer).getSimpleName());
    }
}
