package dev.team.scopes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/** Опыты разд. 5.1: способы внедрения, правило единственного конструктора, коллекции. */
public class InjectionLab {

    public interface FraudRule { String name(); }
    @Component @Order(2) public static class VelocityRule implements FraudRule { public String name() { return "частота операций"; } }
    @Component @Order(1) public static class BlacklistRule implements FraudRule { public String name() { return "чёрный список"; } }
    @Component @Order(3) public static class AmountRule implements FraudRule { public String name() { return "крупная сумма"; } }

    /** Поле с @Autowired: вне контейнера остаётся null. */
    public static class FieldInjected { @Autowired List<FraudRule> rules; int count() { return rules.size(); } }

    /** Все правила списком в порядке @Order и отображением «имя бина -> бин». */
    @Component public static class AntiFraud {
        final List<FraudRule> rules; final Map<String, FraudRule> byName;
        public AntiFraud(List<FraudRule> rules, Map<String, FraudRule> byName) { this.rules = rules; this.byName = byName; }
    }

    /** Два конструктора без @Autowired, один из них без параметров. */
    @Component public static class TwoCtors {
        final String how;
        public TwoCtors() { how = "конструктор без параметров"; }
        public TwoCtors(List<FraudRule> rules) { how = "конструктор с правилами (" + rules.size() + ")"; }
    }

    /** Два конструктора с параметрами, без @Autowired и без конструктора по умолчанию. */
    public static class TwoArgCtors {
        public TwoArgCtors(List<FraudRule> r) { }
        public TwoArgCtors(Map<String, FraudRule> m) { }
    }

    public static void main(String[] args) {
        try {
            new FieldInjected().count();
        } catch (NullPointerException e) {
            System.out.println("поле с @Autowired вне контейнера: NullPointerException");
        }
        try (var ctx = new AnnotationConfigApplicationContext(VelocityRule.class, BlacklistRule.class, AmountRule.class, AntiFraud.class, TwoCtors.class)) {
            var af = ctx.getBean(AntiFraud.class);
            System.out.println("List<FraudRule> в порядке @Order: " + af.rules.stream().map(FraudRule::name).toList());
            System.out.println("Map<String, FraudRule>, ключи: " + af.byName.keySet());
            System.out.println("TwoCtors создан через: " + ctx.getBean(TwoCtors.class).how);
        }
        try (var ctx = new AnnotationConfigApplicationContext()) {
            ctx.register(VelocityRule.class, TwoArgCtors.class);
            ctx.refresh();
        } catch (Exception e) {
            Throwable r = e;
            while (r.getCause() != null) r = r.getCause();
            System.out.println("TwoArgCtors: " + r.getClass().getSimpleName() + ": " + r.getMessage().replace("dev.team.scopes.InjectionLab$", ""));
        }
    }
}
