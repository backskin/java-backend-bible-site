package dev.team.events;

import org.h2.jdbcx.JdbcDataSource;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import javax.sql.DataSource;
import java.math.BigDecimal;

/** Опыт разд. 10: события Spring при приёме платёжного поручения, H2 и DataSourceTransactionManager. */
public class EventsLab {
    public record OrderAccepted(long orderId, String payer, BigDecimal amount) {}
    public record FraudCheckRequested(long orderId) {}

    public static class OrderService {
        final JdbcTemplate jdbc; final ApplicationEventPublisher events;
        public OrderService(JdbcTemplate jdbc, ApplicationEventPublisher events) { this.jdbc = jdbc; this.events = events; }

        @Transactional
        public void accept(long id, String payer, String amount) {
            jdbc.update("insert into payment_order(id, payer, amount) values (?, ?, ?)", id, payer, new BigDecimal(amount));
            System.out.println("   сервис: поручение " + id + " сохранено, публикую событие, поток " + Thread.currentThread().getName());
            long t = System.nanoTime();
            events.publishEvent(new OrderAccepted(id, payer, new BigDecimal(amount)));
            System.out.printf("   сервис: publishEvent вернул управление через %d мс%n", (System.nanoTime() - t) / 1_000_000);
        }

        public void acceptWithoutTx(long id) {
            events.publishEvent(new OrderAccepted(id, "без транзакции", BigDecimal.ONE));
        }
    }

    public static class Listeners {
        final JdbcTemplate jdbc;
        public Listeners(JdbcTemplate jdbc) { this.jdbc = jdbc; }

        @EventListener @Order(1)
        public void audit(OrderAccepted e) { System.out.println("   слушатель audit, поток " + Thread.currentThread().getName()); }

        @EventListener @Order(2)
        public void notifyPayer(OrderAccepted e) {
            sleep(200);
            System.out.println("   слушатель notifyPayer: СМС плательщику " + e.payer() + " (200 мс)");
            if (e.payer().equals("сбой СМС")) throw new IllegalStateException("СМС-шлюз недоступен");
        }

        @EventListener(condition = "#a0.amount >= 600000")
        @Order(3)
        public FraudCheckRequested largeAmount(OrderAccepted e) {
            System.out.println("   слушатель largeAmount: сумма " + e.amount() + ", возвращаю FraudCheckRequested");
            return new FraudCheckRequested(e.orderId());
        }

        @EventListener
        public void fraud(FraudCheckRequested e) { System.out.println("   слушатель fraud: проверка поручения " + e.orderId()); }

        @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
        public void beforeCommit(OrderAccepted e) { System.out.println("   BEFORE_COMMIT " + e.orderId()); }

        @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
        public void afterCommit(OrderAccepted e) {
            System.out.println("   AFTER_COMMIT " + e.orderId() + ": пишу аудит в той же синхронизации");
            jdbc.update("insert into audit(order_id, note) values (?, 'AFTER_COMMIT')", e.orderId());
        }

        @TransactionalEventListener(phase = TransactionPhase.AFTER_ROLLBACK)
        public void afterRollback(OrderAccepted e) { System.out.println("   AFTER_ROLLBACK " + e.orderId()); }

        @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
        public void fallback(OrderAccepted e) { System.out.println("   AFTER_COMMIT с fallbackExecution " + e.orderId()); }
    }

    /** Тот же аудит, но с новой транзакцией. */
    public static class NewTxAudit {
        final JdbcTemplate jdbc;
        public NewTxAudit(JdbcTemplate jdbc) { this.jdbc = jdbc; }
        @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
        @Transactional(propagation = Propagation.REQUIRES_NEW)
        public void audit(OrderAccepted e) { jdbc.update("insert into audit(order_id, note) values (?, 'REQUIRES_NEW')", e.orderId()); }
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ex) { Thread.currentThread().interrupt(); } }

    @Configuration @EnableTransactionManagement
    static class Cfg {
        @Bean DataSource dataSource() {
            var ds = new JdbcDataSource(); ds.setURL("jdbc:h2:mem:events;DB_CLOSE_DELAY=-1"); ds.setUser("sa"); return ds;
        }
        @Bean JdbcTemplate jdbc(DataSource ds) {
            var j = new JdbcTemplate(ds);
            j.execute("create table if not exists payment_order(id bigint primary key, payer varchar(100), amount numeric(18,2))");
            j.execute("create table if not exists audit(order_id bigint, note varchar(30))");
            return j;
        }
        @Bean PlatformTransactionManager tx(DataSource ds) { return new DataSourceTransactionManager(ds); }
        @Bean OrderService orderService(JdbcTemplate j, ApplicationEventPublisher p) { return new OrderService(j, p); }
        @Bean Listeners listeners(JdbcTemplate j) { return new Listeners(j); }
        @Bean NewTxAudit newTxAudit(JdbcTemplate j) { return new NewTxAudit(j); }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            var s = ctx.getBean(OrderService.class);
            var jdbc = ctx.getBean(JdbcTemplate.class);
            System.out.println("== 1. обычное поручение на 15 000,00, поток " + Thread.currentThread().getName());
            s.accept(1, "ООО Ромашка", "15000.00");
            System.out.println("== 2. крупное поручение на 750 000,00");
            s.accept(2, "ООО Ромашка", "750000.00");
            System.out.println("== 3. слушатель СМС бросает исключение");
            try { s.accept(3, "сбой СМС", "1000.00"); }
            catch (IllegalStateException e) { System.out.println("   вызывающий получил: " + e.getMessage()); }
            System.out.println("   поручение 3 в базе: " + jdbc.queryForObject("select count(*) from payment_order where id = 3", Integer.class));
            System.out.println("== 4. публикация без транзакции");
            s.acceptWithoutTx(4);
            System.out.println("== аудит в базе:");
            jdbc.query("select order_id, note from audit order by order_id, note", rs -> { System.out.println("   " + rs.getLong(1) + " " + rs.getString(2)); });
        }
    }
}
