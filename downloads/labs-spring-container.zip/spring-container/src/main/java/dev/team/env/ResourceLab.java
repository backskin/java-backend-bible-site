package dev.team.env;

import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.nio.charset.StandardCharsets;

/** Опыт разд. 11.5: classpath: и classpath*:, getFile() и getInputStream() для ресурса внутри jar. */
public class ResourceLab {
    public static void main(String[] args) throws Exception {
        var resolver = new PathMatchingResourcePatternResolver();
        System.out.println("classpath:META-INF/spring.factories  — найдено: " + resolver.getResources("classpath:META-INF/spring.factories").length);
        System.out.println("classpath*:META-INF/spring.factories — найдено: " + resolver.getResources("classpath*:META-INF/spring.factories").length);

        Resource r = new DefaultResourceLoader().getResource("classpath:" + args[0]);
        System.out.println("ресурс " + args[0] + ": " + r.getClass().getSimpleName() + ", URL " + r.getURL().getProtocol() + ":…");
        try (var in = r.getInputStream()) { System.out.println("   getInputStream(): " + new String(in.readAllBytes(), StandardCharsets.UTF_8).lines().findFirst().orElse("")); }
        try { System.out.println("   getFile(): " + r.getFile().getName()); }
        catch (Exception e) { System.out.println("   getFile(): " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
    }
}
