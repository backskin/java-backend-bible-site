package dev.team.proxy;

import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.ProxyFactory;

/** Опыт разд. 8.2: порядок стоимости вызова через прокси. Не JMH, только порядок величин. */
public class ProxyCostLab {
    public interface Fee { long fee(long amount); }
    public static class PercentFee implements Fee { @Override public long fee(long amount) { return amount * 15 / 1000; } }

    static Fee proxy(boolean cglib, int advices) {
        ProxyFactory pf = new ProxyFactory(new PercentFee());
        pf.setProxyTargetClass(cglib);
        if (!cglib) pf.setInterfaces(Fee.class);
        for (int i = 0; i < advices; i++) pf.addAdvice((MethodInterceptor) inv -> inv.proceed());
        return (Fee) pf.getProxy();
    }

    static volatile long sink;

    static double measure(Fee f) {
        long s = 0;
        for (int r = 0; r < 3; r++) for (int i = 0; i < 2_000_000; i++) s += f.fee(i);   // прогрев
        int n = 20_000_000;
        long t = System.nanoTime();
        for (int i = 0; i < n; i++) s += f.fee(i);
        long dt = System.nanoTime() - t;
        sink = s;
        return (double) dt / n;
    }

    public static void main(String[] args) {
        System.out.printf("прямой вызов:            %5.1f нс%n", measure(new PercentFee()));
        for (int k : new int[] {0, 1, 3, 5}) System.out.printf("CGLIB, советов %d:        %5.1f нс%n", k, measure(proxy(true, k)));
        System.out.printf("JDK, советов 1:          %5.1f нс%n", measure(proxy(false, 1)));
    }
}
