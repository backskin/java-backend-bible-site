package dev.team.patterns;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Опыт гл. 32, разд. 2.5: бин-синглтон единственен в пределах одного контекста, но не JVM. */
public class SpringSingletonLab {
    public static class DocumentNumerator { }

    @Configuration
    static class Cfg { @Bean DocumentNumerator documentNumerator() { return new DocumentNumerator(); } }

    public static void main(String[] args) {
        try (var a = new AnnotationConfigApplicationContext(Cfg.class); var b = new AnnotationConfigApplicationContext(Cfg.class)) {
            System.out.println("в одном контексте getBean дважды — один объект: " + (a.getBean(DocumentNumerator.class) == a.getBean(DocumentNumerator.class)));
            System.out.println("в двух контекстах — один объект: " + (a.getBean(DocumentNumerator.class) == b.getBean(DocumentNumerator.class)));
            System.out.println("а new DocumentNumerator() по-прежнему доступен: " + (new DocumentNumerator() != null));
        }
    }
}
