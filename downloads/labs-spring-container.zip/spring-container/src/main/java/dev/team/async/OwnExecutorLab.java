package dev.team.async;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.CompletableFuture;

/** Опыт разд. 12.2: свой бин-исполнитель в Boot — остаётся ли applicationTaskExecutor и куда идёт @Async без имени. */
public class OwnExecutorLab {
    public static class Fiscal {
        @Async public CompletableFuture<String> unnamed() { return CompletableFuture.completedFuture(Thread.currentThread().getName()); }
        @Async("fiscalExecutor") public CompletableFuture<String> named() { return CompletableFuture.completedFuture(Thread.currentThread().getName()); }
    }

    @SpringBootConfiguration @EnableAutoConfiguration @EnableAsync
    public static class App {
        @Bean Fiscal fiscal() { return new Fiscal(); }
        @Bean ThreadPoolTaskExecutor fiscalExecutor() { var e = new ThreadPoolTaskExecutor(); e.setThreadNamePrefix("fiscal-"); return e; }
    }

    public static void main(String[] args) throws Exception {
        var app = new SpringApplication(App.class);
        app.setWebApplicationType(WebApplicationType.NONE); app.setBannerMode(Banner.Mode.OFF); app.setLogStartupInfo(false);
        try (var ctx = app.run()) {
            System.out.println("бин applicationTaskExecutor есть: " + ctx.containsBean("applicationTaskExecutor"));
            var f = ctx.getBean(Fiscal.class);
            System.out.println("@Async без имени выполнен в потоке: " + f.unnamed().get());
            System.out.println("@Async(\"fiscalExecutor\") выполнен в потоке: " + f.named().get());
        }
    }
}
