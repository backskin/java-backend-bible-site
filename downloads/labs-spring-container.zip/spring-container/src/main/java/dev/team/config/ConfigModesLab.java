package dev.team.config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;

/** Опыт разд. 7: вызов одного @Bean-метода из другого в полном и облегчённом режиме. */
public class ConfigModesLab {
    static final AtomicInteger created = new AtomicInteger();

    public static class InventoryService { final int no = created.incrementAndGet(); }
    public static class ProductService { final InventoryService inventory; public ProductService(InventoryService i) { inventory = i; } }

    @Configuration
    public static class FullConfig {
        @Bean public InventoryService inventoryService() { return new InventoryService(); }
        @Bean public ProductService productService() { return new ProductService(inventoryService()); }
    }

    @Configuration(proxyBeanMethods = false)
    public static class LiteConfig {
        @Bean public InventoryService inventoryService() { return new InventoryService(); }
        @Bean public ProductService productService() { return new ProductService(inventoryService()); }
    }

    @Configuration(proxyBeanMethods = false)
    public static class LiteByParam {
        @Bean public InventoryService inventoryService() { return new InventoryService(); }
        @Bean public ProductService productService(InventoryService inventory) { return new ProductService(inventory); }
    }

    @Component
    public static class ComponentWithBeans {
        @Bean public InventoryService inventoryService() { return new InventoryService(); }
        @Bean public ProductService productService() { return new ProductService(inventoryService()); }
    }

    static void run(String title, Class<?> cfg) {
        created.set(0);
        try (var ctx = new AnnotationConfigApplicationContext(cfg)) {
            var inCtx = ctx.getBean(InventoryService.class);
            var inProduct = ctx.getBean(ProductService.class).inventory;
            String cls = ctx.getBean(cfg).getClass().getSimpleName();
            System.out.printf("%-34s класс конфигурации %-40s InventoryService создан %d раз(а); в ProductService тот же бин, что в контексте: %s%n",
                    title + ":", cls, created.get(), inCtx == inProduct);
        } catch (Exception e) {
            Throwable r = e; while (r.getCause() != null) r = r.getCause();
            System.out.println(title + ": " + r.getMessage());
        }
    }

    public static void main(String[] args) {
        run("@Configuration (полный режим)", FullConfig.class);
        run("proxyBeanMethods = false", LiteConfig.class);
        run("proxyBeanMethods = false, параметр", LiteByParam.class);
        run("@Component с @Bean-методами", ComponentWithBeans.class);
    }
}
