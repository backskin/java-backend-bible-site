package dev.team.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.Advisor;
import org.springframework.aop.framework.Advised;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.resilience.annotation.EnableResilientMethods;
import org.springframework.resilience.annotation.Retryable;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.SimpleTransactionStatus;

import java.math.BigDecimal;

/** Опыт разд. 9.5: порядок своих аспектов, транзакций, кэша и повторов на одном бине. */
public class OrderLab {
    static class PrintingTxManager implements PlatformTransactionManager {
        @Override public TransactionStatus getTransaction(TransactionDefinition d) { System.out.println("      begin"); return new SimpleTransactionStatus(); }
        @Override public void commit(TransactionStatus s) { System.out.println("      commit"); }
        @Override public void rollback(TransactionStatus s) { System.out.println("      rollback"); }
    }

    public static class LimitService {
        int attempts;
        @Transactional @Cacheable("limits")
        public BigDecimal dailyLimit(String account) {
            System.out.println("         dailyLimit: чтение из базы");
            return new BigDecimal("500000.00");
        }
        @Transactional @Retryable(includes = IllegalStateException.class, maxRetries = 2, delay = 10)
        public String reserve(String account) {
            attempts++;
            System.out.println("         reserve, попытка " + attempts);
            if (attempts == 1) throw new IllegalStateException("конфликт блокировки");
            return "зарезервировано";
        }
        @Transactional
        public void close(String account) { System.out.println("         close " + account); }
    }

    @Aspect @Order(1)
    public static class Outer {
        @Around("execution(* dev.team.aop.OrderLab.LimitService.close(..))")
        public Object around(ProceedingJoinPoint pjp) throws Throwable {
            System.out.println("   Outer(@Order 1) вход"); try { return pjp.proceed(); } finally { System.out.println("   Outer(@Order 1) выход"); }
        }
    }

    @Aspect @Order(2)
    public static class Inner {
        @Around("execution(* dev.team.aop.OrderLab.LimitService.close(..))")
        public Object around(ProceedingJoinPoint pjp) throws Throwable {
            System.out.println("    Inner(@Order 2) вход"); try { return pjp.proceed(); } finally { System.out.println("    Inner(@Order 2) выход"); }
        }
    }

    @Configuration
    static class Beans {
        @Bean PlatformTransactionManager txManager() { return new PrintingTxManager(); }
        @Bean CacheManager cacheManager() { return new ConcurrentMapCacheManager("limits"); }
        @Bean LimitService limitService() { return new LimitService(); }
        @Bean Outer outer() { return new Outer(); }
        @Bean Inner inner() { return new Inner(); }
    }

    @Configuration @EnableAspectJAutoProxy @EnableTransactionManagement @EnableCaching @EnableResilientMethods @Import(Beans.class)
    static class Defaults { }

    @Configuration @EnableAspectJAutoProxy @EnableTransactionManagement @EnableCaching(order = 100) @EnableResilientMethods @Import(Beans.class)
    static class CacheOutside { }

    static void dump(Object bean) {
        int i = 0;
        for (Advisor a : ((Advised) bean).getAdvisors()) {
            String order = a instanceof Ordered o ? String.valueOf(o.getOrder()) : "—";
            System.out.printf("   [%d] order=%-11s %s%n", i++, order, a.getAdvice().getClass().getSimpleName());
        }
    }

    static void run(String title, Class<?> cfg) {
        System.out.println("== " + title);
        try (var ctx = new AnnotationConfigApplicationContext(cfg)) {
            var s = ctx.getBean(LimitService.class);
            if (cfg == Defaults.class) System.out.println("создатель прокси: " + ctx.getBean("org.springframework.aop.config.internalAutoProxyCreator").getClass().getSimpleName());
            dump(s);
            System.out.println("dailyLimit дважды:");
            s.dailyLimit("40817-001"); s.dailyLimit("40817-001");
            if (cfg == Defaults.class) {
                System.out.println("reserve с повтором:");
                System.out.println("   результат: " + s.reserve("40817-001"));
                System.out.println("close через два аспекта:");
                s.close("40817-001");
            }
        }
    }

    public static void main(String[] args) {
        run("значения по умолчанию", Defaults.class);
        run("@EnableCaching(order = 100)", CacheOutside.class);
    }
}
