package dev.team.proxy;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.SimpleTransactionStatus;

/** Опыт разд. 8.3 и 8.4: настоящий @Transactional на методах разной видимости и при вызове через this. */
public class TxVisibilityLab {
    /** Менеджер транзакций без базы: печатает начало и фиксацию. */
    static class PrintingTxManager implements PlatformTransactionManager {
        static final ThreadLocal<Boolean> active = ThreadLocal.withInitial(() -> false);
        @Override public TransactionStatus getTransaction(TransactionDefinition d) {
            System.out.println("   begin " + d.getName().replace("dev.team.proxy.TxVisibilityLab$", ""));
            active.set(true);
            return new SimpleTransactionStatus();
        }
        @Override public void commit(TransactionStatus s) { active.set(false); System.out.println("   commit"); }
        @Override public void rollback(TransactionStatus s) { active.set(false); System.out.println("   rollback"); }
    }

    public static class TransferService {
        @Transactional public void transfer() { report("transfer"); }
        @Transactional protected void refund() { report("refund"); }
        @Transactional void hold() { report("hold"); }
        public void transferAll() { report("transferAll"); transfer(); }
        static void report(String m) {
            System.out.println("   " + m + ": транзакция " + (PrintingTxManager.active.get() ? "есть" : "нет"));
        }
    }

    @Configuration
    @EnableTransactionManagement
    static class Cfg {
        @Bean PlatformTransactionManager txManager() { return new PrintingTxManager(); }
        @Bean TransferService transferService() { return new TransferService(); }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            var s = ctx.getBean(TransferService.class);
            System.out.println("класс бина: " + s.getClass().getSimpleName());
            System.out.println("public:");          s.transfer();
            System.out.println("protected:");       s.refund();
            System.out.println("package-private:"); s.hold();
            System.out.println("public без @Transactional, внутри this.transfer():"); s.transferAll();
        }
    }
}
