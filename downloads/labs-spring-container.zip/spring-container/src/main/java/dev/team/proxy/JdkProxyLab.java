package dev.team.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;

/** Опыт разд. 8.1: прокси JDK, написанный вручную, и свойства сгенерированного класса. */
public class JdkProxyLab {
    public interface PaymentGateway { String pay(String account, long kopecks); }

    public static class BankGateway implements PaymentGateway {
        @Override public String pay(String account, long kopecks) { return "принято: " + account + ", " + kopecks + " коп."; }
    }

    /** Обработчик вызовов: печатает метод и время, потом вызывает настоящий объект. */
    static class TimingHandler implements InvocationHandler {
        private final Object target;
        TimingHandler(Object target) { this.target = target; }
        @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            long start = System.nanoTime();
            Object result = method.invoke(target, args);
            System.out.printf("   [обработчик] %s, %d мкс%n", method.getName(), (System.nanoTime() - start) / 1000);
            return result;
        }
    }

    static PaymentGateway wrap(PaymentGateway target) {
        return (PaymentGateway) Proxy.newProxyInstance(PaymentGateway.class.getClassLoader(),
                new Class<?>[] {PaymentGateway.class}, new TimingHandler(target));
    }

    public static void main(String[] args) {
        PaymentGateway gw = wrap(new BankGateway());
        System.out.println("pay: " + gw.pay("40817810000000000001", 150_000));
        Class<?> c = gw.getClass();
        System.out.println("класс прокси: " + c.getName());
        System.out.println("Proxy.isProxyClass: " + Proxy.isProxyClass(c) + ", public final: "
                + (Modifier.isPublic(c.getModifiers()) && Modifier.isFinal(c.getModifiers()))
                + ", суперкласс: " + c.getSuperclass().getName());
        System.out.println("второй прокси того же интерфейса того же класса: " + (wrap(new BankGateway()).getClass() == c));
        System.out.println("instanceof BankGateway: " + (gw instanceof BankGateway));
        System.out.println("toString через прокси:");
        String s = gw.toString();
        System.out.println("   " + s);
        System.out.println("getClass через прокси (обработчик молчит): " + gw.getClass().getSimpleName());
    }
}
