package dev.team.events;

import org.slf4j.MDC;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Опыт разд. 10.3: асинхронный слушатель — поток, исключение, MDC, ThreadLocal, возвращённое событие. */
public class AsyncEventsLab {
    public record OrderAccepted(long orderId) {}
    public record ReceiptRequested(long orderId) {}

    static final ThreadLocal<String> currentClient = new ThreadLocal<>();
    static CountDownLatch done;

    public static class Listeners {
        @Async @EventListener
        public void sendSms(OrderAccepted e) {
            try {
                System.out.printf("   @Async слушатель: поток %s, MDC requestId=%s, клиент=%s%n",
                        Thread.currentThread().getName(), MDC.get("requestId"), currentClient.get());
                if (e.orderId() == 2) throw new IllegalStateException("СМС-шлюз недоступен");
            } finally { done.countDown(); }
        }
    }

    /** Асинхронный слушатель, который пытается вернуть следующее событие. */
    public static class Returning {
        @Async @EventListener
        public ReceiptRequested sendSms(OrderAccepted e) { System.out.println("   Returning.sendSms вызван"); return new ReceiptRequested(e.orderId()); }
    }

    /** Переносит MDC и «текущего клиента» в поток пула и обязательно очищает их после задачи. */
    static class ContextCopyingDecorator implements TaskDecorator {
        @Override public Runnable decorate(Runnable task) {
            Map<String, String> mdc = MDC.getCopyOfContextMap();
            String client = currentClient.get();
            return () -> {
                try { if (mdc != null) MDC.setContextMap(mdc); currentClient.set(client); task.run(); }
                finally { MDC.clear(); currentClient.remove(); }
            };
        }
    }

    @Configuration @EnableAsync
    static class Plain {
        @Bean Listeners listeners() { return new Listeners(); }
        @Bean(name = "taskExecutor") ThreadPoolTaskExecutor taskExecutor() { var e = new ThreadPoolTaskExecutor(); e.setThreadNamePrefix("events-"); return e; }
    }

    @Configuration @EnableAsync
    static class Decorated {
        @Bean Listeners listeners() { return new Listeners(); }
        @Bean(name = "taskExecutor") ThreadPoolTaskExecutor taskExecutor() {
            var e = new ThreadPoolTaskExecutor(); e.setThreadNamePrefix("events-"); e.setTaskDecorator(new ContextCopyingDecorator()); return e;
        }
    }

    static void run(String title, Class<?> cfg) throws Exception {
        System.out.println("== " + title);
        try (var ctx = new AnnotationConfigApplicationContext(cfg)) {
            MDC.put("requestId", "req-7f3a");
            currentClient.set("dev.team");
            for (long id : new long[] {1, 2}) {
                done = new CountDownLatch(1);
                try {
                    ctx.publishEvent(new OrderAccepted(id));
                    System.out.println("   publishEvent(" + id + ") вернул управление, поток " + Thread.currentThread().getName());
                } catch (Exception ex) { System.out.println("   публикатор получил исключение: " + ex.getMessage()); }
                done.await(2, TimeUnit.SECONDS);
                Thread.sleep(100);
            }
            MDC.clear(); currentClient.remove();
        }
    }

    @Configuration @EnableAsync
    static class WithReturning { @Bean Returning returning() { return new Returning(); } }

    public static void main(String[] args) throws Exception {
        System.out.println("== @Async-слушатель возвращает событие");
        try (var ctx = new AnnotationConfigApplicationContext(WithReturning.class)) {
            ctx.publishEvent(new OrderAccepted(9));
        } catch (Exception ex) { System.out.println("   публикатор получил " + ex.getClass().getSimpleName() + ": " + ex.getMessage().replace("dev.team.events.AsyncEventsLab$", "")); }
        run("@Async без переноса контекста", Plain.class);
        run("@Async с TaskDecorator", Decorated.class);
    }
}
