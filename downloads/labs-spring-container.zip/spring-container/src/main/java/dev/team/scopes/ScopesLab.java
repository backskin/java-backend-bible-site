package dev.team.scopes;

import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.context.support.SimpleThreadScope;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;

/** Опыты разд. 5.2–5.4: области видимости, прототип в синглтоне, @PreDestroy у прототипа, свой scope. */
public class ScopesLab {
    static final AtomicInteger created = new AtomicInteger(), destroyed = new AtomicInteger();

    /** Черновик платёжного поручения: у каждой операции свой. */
    public static class PaymentDraft {
        final int no = created.incrementAndGet();
        public int no() { return no; }
        @PreDestroy void close() { destroyed.incrementAndGet(); }
    }

    /** Синглтон, которому прототип внедрили один раз. */
    public static class StuckService {
        final PaymentDraft draft;
        public StuckService(PaymentDraft draft) { this.draft = draft; }
        int draftNo() { return draft.no(); }
    }

    public static class ProviderService {
        final ObjectProvider<PaymentDraft> drafts;
        public ProviderService(ObjectProvider<PaymentDraft> drafts) { this.drafts = drafts; }
        int draftNo() { return drafts.getObject().no(); }
    }

    /** @Lookup работает только у бина, который контейнер создаёт сам (сканированием), а не в @Bean-методе. */
    @Component
    public static abstract class LookupService {
        @Lookup protected abstract PaymentDraft draft();
        int draftNo() { return draft().no(); }
    }

    public static abstract class LookupViaBean {
        @Lookup protected abstract PaymentDraft draft();
    }

    public static class ProxyService {
        final PaymentDraft draft;   // на самом деле прокси
        public ProxyService(PaymentDraft draft) { this.draft = draft; }
        String twoCalls() { return draft.no() + " и " + draft.no(); }
        String draftClass() { return draft.getClass().getSimpleName(); }
    }

    @Configuration
    public static class Cfg {
        @Bean @Scope("prototype") PaymentDraft paymentDraft() { return new PaymentDraft(); }
        @Bean StuckService stuckService(PaymentDraft d) { return new StuckService(d); }
        @Bean ProviderService providerService(ObjectProvider<PaymentDraft> p) { return new ProviderService(p); }
        @Bean LookupViaBean lookupViaBean() { return new LookupViaBean() { @Override protected PaymentDraft draft() { return null; } }; }
    }

    @Configuration
    public static class ProxyCfg {
        @Bean @Scope(value = "prototype", proxyMode = ScopedProxyMode.TARGET_CLASS) PaymentDraft paymentDraft() { return new PaymentDraft(); }
        @Bean ProxyService proxyService(PaymentDraft d) { return new ProxyService(d); }
    }

    private static String shortName(Object o) {
        String n = o.getClass().getSimpleName();
        int i = n.indexOf("$$");
        return i < 0 ? n : n.substring(i);
    }

    public static void main(String[] args) throws Exception {
        try (var ctx = new AnnotationConfigApplicationContext()) {
            ctx.register(Cfg.class, LookupService.class);
            ctx.refresh();
            System.out.println("singleton: один объект на контекст — " + (ctx.getBean(StuckService.class) == ctx.getBean(StuckService.class)));
            System.out.println("prototype: новый объект на каждый getBean — " + (ctx.getBean(PaymentDraft.class) != ctx.getBean(PaymentDraft.class)));
            var stuck = ctx.getBean(StuckService.class);
            System.out.println("прототип в синглтоне: номера черновиков " + stuck.draftNo() + ", " + stuck.draftNo() + ", " + stuck.draftNo());
            var prov = ctx.getBean(ProviderService.class);
            System.out.println("ObjectProvider: номера " + prov.draftNo() + ", " + prov.draftNo() + ", " + prov.draftNo());
            var lk = ctx.getBean(LookupService.class);
            System.out.println("@Lookup, подкласс " + shortName(lk) + ": номера " + lk.draftNo() + ", " + lk.draftNo());
            System.out.println("@Lookup на объекте из @Bean-метода: draft() = " + ctx.getBean(LookupViaBean.class).draft());
        }
        try (var ctx = new AnnotationConfigApplicationContext(ProxyCfg.class)) {
            var ps = ctx.getBean(ProxyService.class);
            System.out.println("scoped proxy: внедрён " + ps.draftClass() + ", два обращения подряд дали номера " + ps.twoCalls());
        }
        created.set(0); destroyed.set(0);
        var ctx = new AnnotationConfigApplicationContext(Cfg.class);
        for (int i = 0; i < 5; i++) ctx.getBean(PaymentDraft.class);
        int before = created.get();
        ctx.close();
        System.out.println("прототипов создано " + before + " (один из них для синглтона StuckService), @PreDestroy вызван у " + destroyed.get());

        try (var tctx = new AnnotationConfigApplicationContext()) {
            tctx.getBeanFactory().registerScope("thread", new SimpleThreadScope());
            tctx.registerBean("threadDraft", PaymentDraft.class, bd -> bd.setScope("thread"));
            tctx.refresh();
            Object main1 = tctx.getBean("threadDraft"), main2 = tctx.getBean("threadDraft");
            Object[] other = new Object[1];
            Thread t = new Thread(() -> other[0] = tctx.getBean("threadDraft"));
            t.start(); t.join();
            System.out.println("scope thread: в одном потоке тот же объект — " + (main1 == main2) + ", в другом потоке другой — " + (main1 != other[0]));
        }
    }
}
