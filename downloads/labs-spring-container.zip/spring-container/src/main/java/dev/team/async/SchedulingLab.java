package dev.team.async;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** Опыт разд. 12.2: планировщик Boot, долгая задача, исключения и fixedRate. */
public class SchedulingLab {
    static final AtomicInteger pings = new AtomicInteger(), failing = new AtomicInteger(), rate = new AtomicInteger();
    static final Set<String> threads = ConcurrentHashMap.newKeySet();
    static volatile long lastRateStart;
    static final java.util.List<Long> rateGaps = java.util.Collections.synchronizedList(new java.util.ArrayList<>());

    public static class Jobs {
        @Scheduled(fixedDelay = 100_000, initialDelay = 100)
        public void reconciliation() { threads.add("reconciliation:" + Thread.currentThread().getName()); sleep(1500); }   // ночная сверка, «долгая»
        @Scheduled(fixedDelay = 100)
        public void ping() { threads.add("ping:" + Thread.currentThread().getName()); pings.incrementAndGet(); }               // проверка связи со шлюзом
        @Scheduled(fixedDelay = 200)
        public void failingExport() { if (failing.incrementAndGet() <= 3) throw new IllegalStateException("выгрузка упала"); }
        @Scheduled(fixedRate = 200)
        public void slowRate() {
            long now = System.nanoTime();
            if (lastRateStart != 0) rateGaps.add((now - lastRateStart) / 1_000_000);
            lastRateStart = now; rate.incrementAndGet(); sleep(500);
        }
    }

    @SpringBootConfiguration @EnableAutoConfiguration @EnableScheduling
    public static class App { @Bean Jobs jobs() { return new Jobs(); } }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    static void run(String... args) {
        pings.set(0); failing.set(0); rate.set(0); threads.clear(); rateGaps.clear(); lastRateStart = 0;
        var app = new SpringApplication(App.class);
        app.setWebApplicationType(WebApplicationType.NONE); app.setBannerMode(Banner.Mode.OFF); app.setLogStartupInfo(false);
        try (var ctx = app.run(args)) { sleep(3000); }
        System.out.println("== " + (args.length == 0 ? "по умолчанию" : String.join(" ", args)));
        System.out.println("   потоки: " + new java.util.TreeSet<>(threads));
        System.out.println("   ping за 3 с: " + pings.get() + " раз; failingExport вызван " + failing.get() + " раз (первые 3 упали)");
        System.out.println("   fixedRate=200 мс при задаче 500 мс: запусков " + rate.get() + ", интервалы между началами, мс: " + rateGaps);
    }

    public static void main(String[] args) throws Exception {
        run();
        run("--spring.task.scheduling.pool.size=4");
        System.out.println("== ScheduledExecutorService.scheduleAtFixedRate и исключение");
        var ses = Executors.newSingleThreadScheduledExecutor();
        var n = new AtomicInteger();
        var f = ses.scheduleAtFixedRate(() -> { if (n.incrementAndGet() == 2) throw new IllegalStateException("сбой"); }, 0, 100, TimeUnit.MILLISECONDS);
        sleep(600);
        System.out.println("   запусков за 600 мс: " + n.get() + ", задача отменена: " + f.isDone());
        ses.shutdown();
    }
}
