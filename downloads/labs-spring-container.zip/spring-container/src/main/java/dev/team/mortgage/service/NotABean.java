package dev.team.mortgage.service;

/** Класс без аннотаций в сканируемом пакете: сканирование не должно его загружать. */
public class NotABean {
    static { System.out.println("  [!!! статическая инициализация NotABean]"); }
}
