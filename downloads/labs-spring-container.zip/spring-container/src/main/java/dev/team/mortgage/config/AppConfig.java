package dev.team.mortgage.config;

import dev.team.mortgage.App;
import dev.team.mortgage.service.MortgageCalculatorService;
import dev.team.mortgage.service.MortgageCalculatorServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean
    MortgageCalculatorService mortgageCalculatorService() {
        return new MortgageCalculatorServiceImpl();
    }

    @Bean
    App app(MortgageCalculatorService mortgageCalculatorService) {
        return new App(mortgageCalculatorService);
    }
}
