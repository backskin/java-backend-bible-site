package dev.team.proxy;

import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.lang.ArchRule;
import org.springframework.transaction.annotation.Transactional;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.methods;

/** Опыт разд. 8.4: правило ArchUnit находит @Transactional на методах, которые прокси не перехватит. */
public class ProxyRulesLab {
    public static class TransferService {
        @Transactional public void transfer(String from, String to, long kopecks) { }
        @Transactional protected void refund(String account, long kopecks) { }
        @Transactional private void writeOff(String account, long kopecks) { }
        @Transactional public final void close(String account) { }
        @Transactional public static void audit(String account) { }
    }

    static final ArchRule rule = methods().that().areAnnotatedWith(Transactional.class)
            .should().notBePrivate()
            .andShould().notBeFinal()
            .andShould().notBeStatic()
            .because("прокси Spring не перехватывает private, final и static методы");

    public static void main(String[] args) {
        var classes = new ClassFileImporter().importClasses(TransferService.class);
        System.out.println(rule.evaluate(classes).getFailureReport().toString()
                .replace("dev.team.proxy.ProxyRulesLab$", ""));
    }
}
