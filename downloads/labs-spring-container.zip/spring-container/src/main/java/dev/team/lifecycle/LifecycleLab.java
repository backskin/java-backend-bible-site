package dev.team.lifecycle;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Proxy;

/** Опыт 1: порядок обратных вызовов. Опыт 2: постпроцессор подменяет бин прокси, а @PostConstruct видит исходный объект. */
public class LifecycleLab {

    public interface LimitChecker { boolean allowed(long amountKop); }

    public static class LimitsDirectory { }

    public static class LimitService implements LimitChecker, BeanNameAware, InitializingBean, DisposableBean {
        public LimitService() { System.out.println(" 1. конструктор"); }
        @Autowired void setDirectory(LimitsDirectory d) { System.out.println(" 2. внедрение через @Autowired-сеттер"); }
        @Override public void setBeanName(String n) { System.out.println(" 3. BeanNameAware: " + n); }
        @PostConstruct void post() { System.out.println(" 5. @PostConstruct, this — " + getClass().getSimpleName()); }
        @Override public void afterPropertiesSet() { System.out.println(" 6. afterPropertiesSet"); }
        void customInit() { System.out.println(" 7. initMethod"); }
        @Override public boolean allowed(long amountKop) { return amountKop <= 15_000_000; }
        @PreDestroy void pre() { System.out.println(" 9. @PreDestroy"); }
        @Override public void destroy() { System.out.println("10. DisposableBean.destroy"); }
        void customDestroy() { System.out.println("11. destroyMethod"); }
    }

    /** Класс без аннотаций с публичным close(): контейнер должен вызвать его сам. */
    public static class RatesPool { public void close() { System.out.println("12. RatesPool.close — вызван автоматически"); } }

    @Configuration
    public static class Cfg {
        @Bean RatesPool ratesPool() { return new RatesPool(); }

        @Bean LimitsDirectory limitsDirectory() { return new LimitsDirectory(); }

        @Bean(initMethod = "customInit", destroyMethod = "customDestroy")
        LimitService limitService() { return new LimitService(); }

        /** Постпроцессор, который оборачивает LimitChecker в прокси с журналом вызовов, как это делает AOP. */
        @Bean static BeanPostProcessor auditProxy() {
            return new BeanPostProcessor() {
                @Override public Object postProcessBeforeInitialization(Object bean, String name) {
                    if (bean instanceof LimitService) System.out.println(" 4. BeanPostProcessor.before");
                    return bean;
                }
                @Override public Object postProcessAfterInitialization(Object bean, String name) {
                    if (!(bean instanceof LimitChecker target)) return bean;
                    System.out.println(" 8. BeanPostProcessor.after: возвращаю прокси вместо бина");
                    return Proxy.newProxyInstance(LimitChecker.class.getClassLoader(), new Class<?>[]{LimitChecker.class},
                            (proxy, method, args) -> {
                                System.out.println("    [аудит] " + method.getName() + "(" + args[0] + ")");
                                return method.invoke(target, args);
                            });
                }
            };
        }
    }

    public static void main(String[] args) {
        var ctx = new AnnotationConfigApplicationContext(Cfg.class);
        System.out.println("--- контекст готов ---");
        ((org.springframework.beans.factory.support.AbstractBeanFactory) ctx.getBeanFactory()).getBeanPostProcessors()
                .forEach(p -> System.out.println("    постпроцессор: " + p.getClass().getName().replace("org.springframework.", "o.s.")));
        LimitChecker checker = ctx.getBean(LimitChecker.class);
        System.out.println("из контекста получен " + (Proxy.isProxyClass(checker.getClass()) ? "прокси " : "") + checker.getClass().getSimpleName());
        System.out.println("перевод 120 000 ₽ разрешён: " + checker.allowed(12_000_000));
        System.out.println("--- закрываем контекст ---");
        ctx.close();
    }
}
