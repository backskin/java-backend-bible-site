# Project Reactor по книгам и по запуску: операторы, спрос, планировщики, backpressure, Context, тесты, инциденты

Стенд к главе 11, разделы 3–10 и 13. Проект Maven на reactor-core 3.8.7, Reactor Netty 1.3.7 и spring-webflux, в котором каждый опыт - класс с `main` в `dev.team.rx`: `BooksLab` (16 сценариев, сверенных с книгами: число операторов `Flux` и `Mono`, потоки Netty при `ActiveProcessorCount`, `cache()` на ветвлении), `CreateLab` (`just`, `fromCallable`, `defer`: когда вычисляется значение), `OpsLab` (спрос к источнику через разные операторы), `SchedDefaults` и `SchedLab2` (значения по умолчанию планировщиков и `boundedElastic` на виртуальных потоках), `PressureLab` (`onBackpressureDrop`, `buffer`, `latest`), `CtxLab` и `MdcLab` (Context, `ThreadLocal` и MDC через `publishOn`), `TestLab` (`withVirtualTime` и `Retry.backoff`), `TimeoutFallbackLab`, `DebugCost` (трасса сборки и `ReactorDebugAgent`), `ClientPerCallLab` (`WebClient` на каждый вызов против общего), `IncidentLab` (`onErrorContinue` внутри `flatMap`). Выводы автора - `s11-*.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" dev.team.rx.OpsLab
```

В IDEA на каждый класс есть конфигурация. `DebugCost` запускают по две серии в отдельных JVM на режим, как в сноске главы.

## Что должно получиться

Выводы совпадают с файлами, кроме времени: например, `Retry.backoff(3, 100 мс)` дает четыре вызова за ~1,4 с, а `timeout(200 мс, Mono.empty())` перед `retryWhen` отменяет повторы вовсе; `onBackpressureDrop` при источнике 100 мкс и обработке 10 мс отбрасывает около 99 % элементов.
