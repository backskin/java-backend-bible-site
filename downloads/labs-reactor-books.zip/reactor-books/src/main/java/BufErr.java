import java.time.Duration; import java.util.concurrent.atomic.*; import reactor.core.publisher.Flux; import reactor.core.scheduler.Schedulers;
public class BufErr { public static void main(String[] a){
  AtomicLong t0=new AtomicLong(System.nanoTime()); AtomicInteger done=new AtomicInteger(); AtomicLong overflowAt=new AtomicLong(-1);
  try{ Flux.interval(Duration.ofNanos(100_000)).onBackpressureBuffer(1000, x -> {}, reactor.core.publisher.BufferOverflowStrategy.ERROR)
     .doOnError(e->overflowAt.compareAndSet(-1,(System.nanoTime()-t0.get())/1_000_000))
     .publishOn(Schedulers.boundedElastic())
     .doOnNext(x->{try{Thread.sleep(10);}catch(Exception e){} done.incrementAndGet();}).blockLast(Duration.ofSeconds(40));
  }catch(Exception e){ System.out.printf("   переполнение внутри цепочки на %d мс; подписчик получил ошибку на %d мс, успев обработать %d; %s: %s%n", overflowAt.get(), (System.nanoTime()-t0.get())/1_000_000, done.get(), e.getClass().getName(), e.getMessage()); }
}}
