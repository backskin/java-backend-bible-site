package dev.team.rx;

import java.time.Duration;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

/**
 * Разд. 5.7 и 5.9 гл. 11: потолок одновременных блокирующих вызовов у boundedElastic на платформенных
 * и виртуальных потоках и у своего планировщика на newVirtualThreadPerTaskExecutor; имена потоков;
 * какой из нескольких subscribeOn побеждает; сколько стоит создать виртуальный поток.
 * Запуск: с -Dreactor.schedulers.defaultBoundedElasticOnVirtualThreads=true и без.
 */
public final class SchedLab2 {

    static String peak(String name, Scheduler s, int tasks, long ms) {
        AtomicInteger now = new AtomicInteger(), max = new AtomicInteger();
        Set<String> names = ConcurrentHashMap.newKeySet();
        long t0 = System.nanoTime();
        Flux.range(1, tasks).flatMap(i -> Mono.fromCallable(() -> {
            int c = now.incrementAndGet(); max.accumulateAndGet(c, Math::max);
            names.add(Thread.currentThread().getName().replaceAll("\\d+$", "N"));
            Thread.sleep(ms);                        // блокирующий вызов в базу
            now.decrementAndGet(); return i;
        }).subscribeOn(s), tasks).blockLast(Duration.ofMinutes(2));
        return String.format("   %-34s задач %d по %d мс: одновременно максимум %d, за %d мс, имена потоков %s",
                name, tasks, ms, max.get(), (System.nanoTime() - t0) / 1_000_000, names);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== 5.7. ядер " + Runtime.getRuntime().availableProcessors()
                + ", defaultBoundedElasticOnVirtualThreads=" + System.getProperty("reactor.schedulers.defaultBoundedElasticOnVirtualThreads"));
        System.out.println(peak("Schedulers.boundedElastic()", Schedulers.boundedElastic(), 400, 200));
        Scheduler vt = Schedulers.fromExecutorService(Executors.newVirtualThreadPerTaskExecutor(), "jdbc-vt");
        System.out.println(peak("fromExecutorService(VT-executor)", vt, 400, 200));
        vt.dispose();

        System.out.println("== 5.9. несколько subscribeOn: на каком потоке стартует источник");
        String[] where = new String[1];
        Mono.fromCallable(() -> where[0] = Thread.currentThread().getName())
                .subscribeOn(Schedulers.newSingle("A"))
                .map(x -> x)
                .subscribeOn(Schedulers.newSingle("B"))
                .subscribeOn(Schedulers.newSingle("C"))
                .block();
        System.out.println("   источник выполнился на потоке: " + where[0]);

        System.out.println("== 5.7. цена создания виртуального потока (100 000 штук, пустая задача, после прогрева)");
        for (int round = 0; round < 3; round++) {
            long t0 = System.nanoTime();
            Thread[] ts = new Thread[100_000];
            for (int i = 0; i < ts.length; i++) ts[i] = Thread.ofVirtual().start(() -> { });
            for (Thread t : ts) t.join();
            long ns = System.nanoTime() - t0;
            if (round == 2) System.out.printf("   %.2f мкс на поток (создать, запустить, дождаться)%n", ns / 1000.0 / ts.length);
        }
    }
}
