package dev.team.rx;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import reactor.core.publisher.Mono;

/**
 * Разд. 3.3 и 3.7 гл. 11: когда вычисляется значение у разных способов создать Mono.
 * Для каждого способа: сколько раз вызван «дорогой» метод после сборки (без подписки) и после двух подписок.
 * И отдельно: что пишет subscribe() без обработчика ошибок.
 */
public final class CreateLab {

    static final AtomicInteger calls = new AtomicInteger();

    static Integer compute() { return calls.incrementAndGet(); }   // «дорогой» вызов: подписать токен, сходить в базу

    static void probe(String name, Function<Void, Mono<Integer>> build) {
        calls.set(0);
        Mono<Integer> m = build.apply(null);
        int afterAssembly = calls.get();
        Integer a = m.block(), b = m.block();
        System.out.printf("   %-42s после сборки: %d, после двух подписок: %d, значения: %d и %d%n",
                name, afterAssembly, calls.get(), a, b);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== 3.7. сколько раз вычисляется значение");
        probe("Mono.just(compute())", v -> Mono.just(compute()));
        probe("Mono.fromCallable(CreateLab::compute)", v -> Mono.fromCallable(CreateLab::compute));
        probe("Mono.fromSupplier(CreateLab::compute)", v -> Mono.fromSupplier(CreateLab::compute));
        probe("Mono.defer(() -> Mono.just(compute()))", v -> Mono.defer(() -> Mono.just(compute())));
        probe("Mono.fromCallable(...).cache()", v -> Mono.fromCallable(CreateLab::compute).cache());
        calls.set(0);
        Mono<Integer> ttl = Mono.fromCallable(CreateLab::compute).cache(Duration.ofMillis(50));
        Integer t1 = ttl.block(), t2 = ttl.block();
        Thread.sleep(80);
        Integer t3 = ttl.block();
        System.out.printf("   %-42s подписки сразу: %d и %d, через 80 мс: %d, вызовов всего: %d%n",
                "Mono.fromCallable(...).cache(50 мс)", t1, t2, t3, calls.get());

        System.out.println("== 3.3. subscribe() без обработчика ошибок");
        Mono.error(new IllegalStateException("банк-эмитент недоступен")).subscribe();
        System.out.println("   (выше — что напечатал Reactor)");
    }
}
