package dev.team.rx;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.test.publisher.PublisherProbe;
import reactor.test.publisher.TestPublisher;
import reactor.util.retry.Retry;

/**
 * Разд. 10.2–10.3 гл. 11: пример withVirtualTime из главы как есть; тот же тест с готовым Mono вместо Supplier;
 * expectNoEvent без expectSubscription; что видит тест, когда TestPublisher нарушает спрос; PublisherProbe.
 */
public final class TestLab {

    static final AtomicInteger calls = new AtomicInteger();

    /** Поставщик котировок, который всегда отвечает 503. */
    static Mono<String> fetch() { return Mono.defer(() -> { calls.incrementAndGet(); return Mono.error(new IllegalStateException("503 от поставщика котировок")); }); }

    static void run(String name, Runnable r) {
        calls.set(0);
        long t0 = System.nanoTime();
        try { r.run(); System.out.printf("   %-52s прошёл за %d мс, вызовов %d%n", name, (System.nanoTime() - t0) / 1_000_000, calls.get()); }
        catch (Throwable e) { System.out.printf("   %-52s УПАЛ за %d мс: %s%n", name, (System.nanoTime() - t0) / 1_000_000, String.valueOf(e.getMessage()).lines().findFirst().orElse("")); }
    }

    public static void main(String[] args) {
        System.out.println("== 10.2. withVirtualTime: повторы backoff(3, 5 с), jitter 0");
        run("пример из главы (Supplier)", () ->
                StepVerifier.withVirtualTime(() -> fetch().retryWhen(Retry.backoff(3, Duration.ofSeconds(5)).jitter(0)))
                        .expectSubscription()
                        .expectNoEvent(Duration.ofSeconds(5))
                        .thenAwait(Duration.ofSeconds(5))
                        .expectNoEvent(Duration.ofSeconds(10))
                        .thenAwait(Duration.ofSeconds(60))
                        .expectError(IllegalStateException.class)
                        .verify(Duration.ofSeconds(5)));
        run("какой класс у ошибки после исчерпания", () -> {
            Throwable[] got = new Throwable[1];
            StepVerifier.withVirtualTime(() -> fetch().retryWhen(Retry.backoff(3, Duration.ofSeconds(5)).jitter(0)))
                    .thenAwait(Duration.ofMinutes(2)).consumeErrorWith(e -> got[0] = e).verify(Duration.ofSeconds(5));
            System.out.println("      " + got[0].getClass().getName() + " extends " + got[0].getClass().getSuperclass().getSimpleName() + ": " + got[0].getMessage());
        });
        Mono<String> prebuilt = fetch().retryWhen(Retry.backoff(3, Duration.ofSeconds(5)).jitter(0));
        run("готовый Mono вместо Supplier, verify(5 с)", () ->
                StepVerifier.withVirtualTime(() -> prebuilt)
                        .expectSubscription()
                        .thenAwait(Duration.ofMinutes(2))
                        .expectError(IllegalStateException.class)
                        .verify(Duration.ofSeconds(5)));
        Mono<Long> prebuiltDelay = Mono.delay(Duration.ofSeconds(30));
        run("готовый Mono.delay(30 с) вместо Supplier, verify(3 с)", () ->
                StepVerifier.withVirtualTime(() -> prebuiltDelay)
                        .expectSubscription()
                        .thenAwait(Duration.ofSeconds(30))
                        .expectNext(0L).verifyComplete());
        run("Mono.delay(30 с) внутри Supplier", () ->
                StepVerifier.withVirtualTime(() -> Mono.delay(Duration.ofSeconds(30)))
                        .expectSubscription()
                        .thenAwait(Duration.ofSeconds(30))
                        .expectNext(0L).verifyComplete());
        run("expectNoEvent без expectSubscription", () ->
                StepVerifier.withVirtualTime(() -> Mono.delay(Duration.ofSeconds(5)))
                        .expectNoEvent(Duration.ofSeconds(5))
                        .expectNext(0L).verifyComplete());

        System.out.println("== 10.3. TestPublisher.createNoncompliant(REQUEST_OVERFLOW): тест запросил 1, издатель отдал 3");
        TestPublisher<Integer> bad = TestPublisher.createNoncompliant(TestPublisher.Violation.REQUEST_OVERFLOW);
        run("map без защиты", () -> StepVerifier.create(bad.flux().map(x -> x * 10), 1)
                .then(() -> bad.next(1, 2, 3)).expectNext(10).thenCancel().verify(Duration.ofSeconds(2)));
        TestPublisher<Integer> bad2 = TestPublisher.createNoncompliant(TestPublisher.Violation.REQUEST_OVERFLOW);
        run("publishOn-подобный буфер: limitRate(1)", () -> StepVerifier.create(bad2.flux().limitRate(1), 1)
                .then(() -> bad2.next(1, 2, 3)).expectNext(1).thenCancel().verify(Duration.ofSeconds(2)));
        TestPublisher<Integer> good = TestPublisher.create();
        run("обычный TestPublisher, next сверх спроса", () -> StepVerifier.create(good.flux(), 1)
                .then(() -> good.next(1, 2, 3)).expectNext(1).thenCancel().verify(Duration.ofSeconds(2)));

        System.out.println("== 10.3. все сигналы подписчика, который запросил 1, когда издатель отдал 3");
        for (String kind : new String[] {"compliant", "noncompliant"}) {
            TestPublisher<Integer> p = kind.equals("compliant") ? TestPublisher.create()
                    : TestPublisher.createNoncompliant(TestPublisher.Violation.REQUEST_OVERFLOW);
            java.util.List<String> sig = new java.util.ArrayList<>();
            p.flux().subscribe(new reactor.core.publisher.BaseSubscriber<Integer>() {
                protected void hookOnSubscribe(org.reactivestreams.Subscription s) { request(1); }
                protected void hookOnNext(Integer v) { sig.add("onNext(" + v + ")"); }
                protected void hookOnError(Throwable e) { sig.add("onError(" + e.getClass().getSimpleName() + ": " + e.getMessage() + ")"); }
                protected void hookOnComplete() { sig.add("onComplete"); }
            });
            String thrown = "";
            try { p.next(1, 2, 3); } catch (Throwable e) { thrown = " — next() бросил " + e.getClass().getSimpleName() + ": " + e.getMessage(); }
            System.out.println("   " + kind + ": " + sig + thrown);
        }
        System.out.println("== 10.3. PublisherProbe: сработал ли запасной путь");
        PublisherProbe<String> fallback = PublisherProbe.of(Mono.just("курс из кэша"));
        Mono.just("курс от поставщика").switchIfEmpty(fallback.mono()).block();
        System.out.println("   основной источник непустой: fallback подписан? " + fallback.wasSubscribed());
        PublisherProbe<String> fallback2 = PublisherProbe.of(Mono.just("курс из кэша"));
        Mono.<String>empty().switchIfEmpty(fallback2.mono()).block();
        System.out.println("   основной источник пустой: fallback подписан? " + fallback2.wasSubscribed() + ", запрошено " + fallback2.wasRequested());
    }
}
