package dev.team.rx;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import reactor.core.publisher.BufferOverflowStrategy;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

/**
 * Разд. 6.3 гл. 11: стратегии переполнения на потоке котировок 10 000 в секунду (пример Базлура Рахмана, гл. 6):
 * сколько элементов обработано, сколько отброшено, чем заканчивается ограниченный буфер.
 */
public final class PressureLab {

    static void work(int ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    public static void main(String[] args) throws Exception {
        AtomicLong emitted = new AtomicLong();
        Flux<Long> feed = Flux.interval(Duration.ofNanos(100_000)).doOnNext(i -> emitted.incrementAndGet());

        System.out.println("== 6.3. источник: interval(100 мкс), подписчик обрабатывает элемент 10 мс, окно 2 с");
        AtomicInteger dropped = new AtomicInteger(), done = new AtomicInteger();
        emitted.set(0);
        feed.onBackpressureDrop(x -> dropped.incrementAndGet()).publishOn(Schedulers.boundedElastic())
                .take(Duration.ofSeconds(2)).doOnNext(x -> { work(10); done.incrementAndGet(); }).blockLast();
        System.out.printf("   onBackpressureDrop: источник выдал %d, обработано %d, отброшено %d%n", emitted.get(), done.get(), dropped.get());

        done.set(0); emitted.set(0);
        AtomicLong lastSeen = new AtomicLong(), maxGap = new AtomicLong();
        feed.onBackpressureLatest().publishOn(Schedulers.boundedElastic(), 1)
                .take(Duration.ofSeconds(2)).doOnNext(x -> { long g = x - lastSeen.getAndSet(x); maxGap.accumulateAndGet(g, Math::max); work(10); done.incrementAndGet(); }).blockLast();
        System.out.printf("   onBackpressureLatest (publishOn prefetch 1): выдано %d, обработано %d, максимальный скачок номера %d%n", emitted.get(), done.get(), maxGap.get());

        done.set(0); emitted.set(0);
        long n = feed.sample(Duration.ofMillis(100)).take(Duration.ofSeconds(2)).doOnNext(x -> done.incrementAndGet()).count().block();
        System.out.printf("   sample(100 мс): выдано %d, получено %d снимков%n", emitted.get(), n);

        done.set(0); emitted.set(0);
        try {
            feed.onBackpressureBuffer(1000).publishOn(Schedulers.boundedElastic())
                    .take(Duration.ofSeconds(2)).doOnNext(x -> { work(10); done.incrementAndGet(); }).blockLast();
            System.out.println("   onBackpressureBuffer(1000): ошибки нет");
        } catch (Exception e) {
            System.out.printf("   onBackpressureBuffer(1000): после %d обработанных — %s: %s%n", done.get(), e.getClass().getName(), e.getMessage());
        }

        done.set(0); emitted.set(0); dropped.set(0);
        AtomicLong first = new AtomicLong(-1);
        feed.onBackpressureBuffer(1000, x -> dropped.incrementAndGet(), BufferOverflowStrategy.DROP_OLDEST)
                .publishOn(Schedulers.boundedElastic())
                .take(Duration.ofSeconds(2)).doOnNext(x -> { first.compareAndSet(-1, x); work(10); done.incrementAndGet(); }).blockLast();
        System.out.printf("   onBackpressureBuffer(1000, DROP_OLDEST): выдано %d, обработано %d, вытеснено старых %d%n", emitted.get(), done.get(), dropped.get());
    }
}
