package dev.team.rx;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Hooks;
import reactor.core.publisher.Mono;
import reactor.tools.agent.ReactorDebugAgent;

/**
 * 14. Цена отладочных режимов: сборка и выполнение цепочки проверки платежа 200 000 раз.
 * Режим — первый аргумент: none, hook, agent, checkpoint.
 */
public final class DebugCost {

    public static void main(String[] a) {
        String mode = a.length > 0 ? a[0] : "none";
        if (mode.equals("hook")) Hooks.onOperatorDebug();
        if (mode.equals("agent")) { ReactorDebugAgent.init(); ReactorDebugAgent.processExistingClasses(); }
        boolean cp = mode.equals("checkpoint");
        for (int warm = 0; warm < 3; warm++) run(50_000, cp);
        long t = System.nanoTime();
        long sum = run(200_000, cp);
        long ms = (System.nanoTime() - t) / 1_000_000;
        System.out.println("   режим " + mode + ": 200 000 сборок и прогонов за " + ms + " мс (контрольная сумма " + sum + ")");
        String trace = "";
        try {
            failingChain();
        } catch (ArithmeticException e) {
            var s = e.getSuppressed();
            String first = java.util.Arrays.stream(s).map(x -> x.getMessage() == null ? x.getClass().getSimpleName() : x.getMessage()).flatMap(String::lines)
                    .filter(l -> l.contains("Assembly") || l.contains("DebugCost") || l.contains("checkpoint")).limit(3).reduce((x, y) -> x + " | " + y).orElse("нет трассы сборки");
            System.out.println("   подавленное исключение с трассой сборки: " + first + trace);
        }
    }

    /** Отдельный метод: агент перестраивает класс, но уже выполняющийся main остаётся старым кодом. */
    static void failingChain() {
        Flux.just(100, 0).map(x -> 1000 / x).filter(x -> x > 0).blockLast();
    }

    static long run(int n, boolean checkpoint) {
        long sum = 0;
        for (int i = 0; i < n; i++) {
            Flux<Integer> f = Flux.range(1, 5).map(x -> x * 100).filter(x -> x > 100);
            if (checkpoint) f = f.checkpoint("сумма платежей", false);
            Integer r = f.reduce(0, Integer::sum).block();
            sum += r == null ? 0 : r;
        }
        return sum;
    }
}
