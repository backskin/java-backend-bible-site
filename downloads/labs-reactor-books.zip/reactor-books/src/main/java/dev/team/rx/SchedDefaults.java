package dev.team.rx;

import reactor.core.scheduler.Schedulers;

/** Значения по умолчанию планировщиков Reactor (разд. 5.2). */
public final class SchedDefaults {
    public static void main(String[] a) {
        System.out.println("   ядер JVM: " + Runtime.getRuntime().availableProcessors());
        System.out.println("   DEFAULT_BOUNDED_ELASTIC_SIZE = " + Schedulers.DEFAULT_BOUNDED_ELASTIC_SIZE);
        System.out.println("   DEFAULT_BOUNDED_ELASTIC_QUEUESIZE = " + Schedulers.DEFAULT_BOUNDED_ELASTIC_QUEUESIZE);
        System.out.println("   DEFAULT_POOL_SIZE (parallel) = " + Schedulers.DEFAULT_POOL_SIZE);
        System.out.println("   boundedElastic: " + Schedulers.boundedElastic());
        System.out.println("   виртуальные потоки в boundedElastic по умолчанию (reactor.schedulers.defaultBoundedElasticOnVirtualThreads): "
                + System.getProperty("reactor.schedulers.defaultBoundedElasticOnVirtualThreads", "не задано"));
    }
}
