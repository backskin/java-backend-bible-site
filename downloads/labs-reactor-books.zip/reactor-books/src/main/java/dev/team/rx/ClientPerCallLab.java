package dev.team.rx;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.http.server.HttpServer;
import reactor.netty.resources.ConnectionProvider;

/**
 * Разд. 13.2 гл. 11: сколько TCP-соединений открывает flatMap(… , 1000) при трёх способах создавать WebClient:
 * один общий; новый WebClient.builder().build() на каждый вызов; новый WebClient со своим ConnectionProvider на каждый вызов.
 * Сервер отвечает через 300 мс и считает принятые соединения.
 */
public final class ClientPerCallLab {

    static final AtomicInteger OPEN = new AtomicInteger(), PEAK = new AtomicInteger();
    static final java.util.Map<String, Integer> ERR = new java.util.concurrent.ConcurrentHashMap<>();

    public static void main(String[] args) {
        AtomicInteger accepted = new AtomicInteger();
        var server = HttpServer.create().port(0).doOnChannelInit((obs, ch, addr) -> {   // один раз на TCP-соединение (doOnConnection у сервера — на каждый запрос)
                    accepted.incrementAndGet(); OPEN.incrementAndGet(); PEAK.accumulateAndGet(OPEN.get(), Math::max);
                    ch.closeFuture().addListener(f -> OPEN.decrementAndGet()); })
                .handle((req, res) -> res.sendString(Mono.just("ok").delayElement(Duration.ofMillis(300)))).bindNow();
        String url = "http://127.0.0.1:" + server.port() + "/status";
        int calls = 1000;

        accepted.set(0);
        WebClient shared = WebClient.builder().build();
        run("один общий WebClient.builder().build()", calls, () -> shared, url, accepted);

        accepted.set(0);
        WebClient capped = WebClient.builder().clientConnector(new ReactorClientHttpConnector(
                HttpClient.create(ConnectionProvider.builder("контроль").maxConnections(100).pendingAcquireMaxCount(-1).build()))).build();
        run("контроль: общий WebClient со своим пулом на 100", calls, () -> capped, url, accepted);

        accepted.set(0);
        run("новый WebClient.builder().build() на каждый вызов", calls, () -> WebClient.builder().build(), url, accepted);

        accepted.set(0);
        run("новый WebClient со своим ConnectionProvider на каждый вызов", calls,
                () -> WebClient.builder().clientConnector(new ReactorClientHttpConnector(
                        HttpClient.create(ConnectionProvider.create("партнёр-" + System.nanoTime(), 500)))).build(), url, accepted);
        server.disposeNow();
        System.exit(0);
    }

    static void run(String name, int calls, java.util.function.Supplier<WebClient> client, String url, AtomicInteger accepted) {
        PEAK.set(OPEN.get()); ERR.clear(); int before = OPEN.get();
        long t0 = System.nanoTime();
        long ok = Flux.range(1, calls)
                .flatMap(i -> client.get().get().uri(url).retrieve().bodyToMono(String.class)
                        .onErrorResume(e -> { ERR.merge(e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()).lines().findFirst().orElse("").replaceAll("[0-9]+", "N"), 1, Integer::sum); return Mono.empty(); }), 1000)
                .count().block(Duration.ofSeconds(120));
        System.out.printf("   %-62s ответов %d за %d мс, сервер принял соединений: %d%n", name, ok, (System.nanoTime() - t0) / 1_000_000, accepted.get());
        System.out.println("      новых соединений на пике: " + (PEAK.get() - before) + (ERR.isEmpty() ? "" : "; ошибки: " + ERR));
    }
}
