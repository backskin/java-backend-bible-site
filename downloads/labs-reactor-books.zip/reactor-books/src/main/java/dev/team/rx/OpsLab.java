package dev.team.rx;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Sinks;
import reactor.core.scheduler.Schedulers;

/**
 * Разд. 4.8–4.9 гл. 11: какой спрос операторы посылают своему источнику, как завершаются zip и combineLatest,
 * что делает zip с быстрым и медленным источником и теряет ли concat события горячего потока на стыке.
 */
public final class OpsLab {

    /** Источник на 1000 элементов, который запоминает каждый пришедший к нему request. */
    static Flux<Integer> recorded(List<Long> log) {
        return Flux.range(1, 1000).doOnRequest(log::add);
    }

    static String head(List<Long> l) {
        List<String> s = new ArrayList<>();
        for (int i = 0; i < Math.min(5, l.size()); i++) s.add(l.get(i) == Long.MAX_VALUE ? "MAX" : String.valueOf(l.get(i)));
        return s + (l.size() > 5 ? " … всего " + l.size() : "");
    }

    /** Подписчик забирает 10 элементов по одному и отменяет подписку. */
    static void demand(String name, Function<Flux<Integer>, Flux<?>> op) {
        List<Long> log = Collections.synchronizedList(new ArrayList<>());
        op.apply(recorded(log)).take(10, true).blockLast(Duration.ofSeconds(10));
        System.out.printf("   %-40s источник получил: %s%n", name, head(log));
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== 4.9. спрос к источнику (подписчик берёт 10 элементов через take(10, limitRequest))");
        demand("map", f -> f.map(x -> x));
        demand("concatMap(Mono.just)", f -> f.concatMap(Mono::just));
        demand("concatMap(Mono.just, 4)", f -> f.concatMap(Mono::just, 4));
        demand("flatMap(Mono.just)", f -> f.flatMap(Mono::just));
        demand("flatMapSequential(Mono.just)", f -> f.flatMapSequential(Mono::just));
        demand("publishOn(single)", f -> f.publishOn(Schedulers.single()));
        demand("buffer(5)", f -> f.buffer(5));
        demand("groupBy(x % 3).flatMap", f -> f.groupBy(x -> x % 3).flatMap(g -> g));
        demand("cache()", Flux::cache);
        demand("share()", Flux::share);
        demand("onBackpressureBuffer(100)", f -> f.onBackpressureBuffer(100));
        demand("limitRate(50)", f -> f.limitRate(50));
        demand("sample(1 мс)", f -> f.sample(Duration.ofMillis(1)));
        demand("delayElements(1 мс)", f -> f.delayElements(Duration.ofMillis(1)));
        demand("parallel(4).runOn(parallel).sequential", f -> f.parallel(4).runOn(Schedulers.parallel()).sequential());
        demand("mergeWith(Flux.never())", f -> f.mergeWith(Flux.never()));

        System.out.println("== 4.8. zip и combineLatest: спрос, завершение, пустой источник");
        List<Long> za = Collections.synchronizedList(new ArrayList<>()), zb = Collections.synchronizedList(new ArrayList<>());
        Flux.zip(recorded(za), recorded(zb)).take(10, true).blockLast();
        System.out.println("   zip: источник A получил " + head(za) + ", источник B " + head(zb));
        System.out.println("   zip(1..3, 1..10): " + Flux.zip(Flux.range(1, 3), Flux.range(1, 10)).count().block() + " пар");
        System.out.println("   combineLatest(1..3, 1..10): " + Flux.combineLatest(Flux.range(1, 3), Flux.range(1, 10), (a, b) -> a + b).count().block() + " значений");
        System.out.println("   zip с пустым: " + Flux.zip(Flux.range(1, 3), Flux.<Integer>empty()).count().block()
                + ", combineLatest с пустым: " + Flux.combineLatest(Flux.range(1, 3), Flux.<Integer>empty(), Integer::sum).count().block());

        System.out.println("== 4.8. zip быстрого источника с медленным (100 мс на элемент), 1,5 с");
        AtomicInteger made = new AtomicInteger();
        Flux<Integer> fast = Flux.<Integer>generate(s -> s.next(made.incrementAndGet()));   // уважает спрос
        long n = Flux.zip(fast, Flux.range(1, 1000).delayElements(Duration.ofMillis(100)))
                .take(Duration.ofMillis(1500)).count().block();
        System.out.println("   generate (уважает спрос): пар " + n + ", быстрый источник выдал всего " + made.get());
        try {
            Flux.zip(Flux.interval(Duration.ofMillis(1)), Flux.range(1, 1000).delayElements(Duration.ofMillis(100)))
                    .take(Duration.ofMillis(1500)).count().block();
            System.out.println("   interval(1 мс): ошибки нет");
        } catch (Exception e) {
            System.out.println("   interval(1 мс): " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }

        System.out.println("== 4.8. concat(история, горячий поток): что теряется на стыке");
        Sinks.Many<String> live = Sinks.many().multicast().directBestEffort();
        Flux<String> history = Flux.just("история-1", "история-2").delayElements(Duration.ofMillis(50))
                .doOnComplete(() -> live.tryEmitNext("онлайн-в-разрыве"));   // событие ровно в момент стыка
        List<String> got = Collections.synchronizedList(new ArrayList<>());
        Flux.concat(history, live.asFlux()).subscribe(got::add);
        Thread.sleep(300);
        live.tryEmitNext("онлайн-после");
        Thread.sleep(50);
        System.out.println("   concat получил: " + got);

        Sinks.Many<String> live2 = Sinks.many().replay().limit(Duration.ofSeconds(1));
        List<String> got2 = Collections.synchronizedList(new ArrayList<>());
        Flux<String> history2 = Flux.just("история-1", "история-2").delayElements(Duration.ofMillis(50))
                .doOnComplete(() -> live2.tryEmitNext("онлайн-в-разрыве"));
        Flux.concat(history2, live2.asFlux()).subscribe(got2::add);
        Thread.sleep(300);
        live2.tryEmitNext("онлайн-после");
        Thread.sleep(50);
        System.out.println("   concat с replay-буфером у горячего: " + got2);
    }
}
