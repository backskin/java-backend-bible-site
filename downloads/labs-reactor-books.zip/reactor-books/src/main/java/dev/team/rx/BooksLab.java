package dev.team.rx;

import com.sun.net.httpserver.HttpServer;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Hooks;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.netty.DisposableServer;
import reactor.netty.ReactorNetty;
import reactor.util.retry.Retry;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.InetSocketAddress;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/** Утверждения книг о Reactor и WebFlux, проверенные запуском. Номера сценариев — по списку в tmp/ch11/books-notes.md. */
public final class BooksLab {

    public static void main(String[] a) throws Exception {
        System.out.println("== версии: reactor-core " + Flux.class.getPackage().getImplementationVersion()
                + ", reactor-netty " + ReactorNetty.class.getPackage().getImplementationVersion()
                + ", ядер " + Runtime.getRuntime().availableProcessors());
        elastic();
        backoff();
        timeoutRetryOrder();
        webClient404();
        nettyLoops();
        restTemplate();
        operatorCount();
        doubleSubscription();
        flatMapPrefetch();
    }

    /** 1. Schedulers.elastic() из таблицы книги. */
    static void elastic() {
        System.out.println("== 1. Schedulers: какие фабрики есть");
        Set<String> names = Arrays.stream(Schedulers.class.getMethods())
                .filter(m -> Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0)
                .map(Method::getName).collect(Collectors.toCollection(TreeSet::new));
        System.out.println("   фабрики без аргументов: " + names);
        System.out.println("   elastic() есть: " + names.contains("elastic"));
    }

    /** 2. Retry.backoff: линейный или экспоненциальный рост задержки. */
    static void backoff() {
        System.out.println("== 2. Retry.backoff(4, 100 мс), jitter 0 и по умолчанию");
        for (double jitter : new double[] {0.0, 0.5}) {
            List<Long> at = new CopyOnWriteArrayList<>();
            long t0 = System.nanoTime();
            Retry spec = jitter == 0.0 ? Retry.backoff(4, Duration.ofMillis(100)).jitter(0.0) : Retry.backoff(4, Duration.ofMillis(100));
            Mono.defer(() -> { at.add((System.nanoTime() - t0) / 1_000_000); return Mono.error(new IllegalStateException("бюро недоступно")); })
                    .retryWhen(spec).onErrorResume(e -> Mono.empty()).block();
            List<Long> gaps = new ArrayList<>();
            for (int i = 1; i < at.size(); i++) gaps.add(at.get(i) - at.get(i - 1));
            System.out.println("   jitter " + (jitter == 0.0 ? "0" : "по умолчанию") + ": попыток " + at.size() + ", паузы между попытками, мс: " + gaps);
        }
    }

    /** 3. retryWhen после timeout и до него. */
    static void timeoutRetryOrder() {
        System.out.println("== 3. ответ через 300 мс, timeout 200 мс, retry(2)");
        AtomicInteger calls = new AtomicInteger();
        Mono<String> slow = Mono.defer(() -> { calls.incrementAndGet(); return Mono.just("лимит").delayElement(Duration.ofMillis(300)); });
        calls.set(0); long t = System.nanoTime();
        String r1 = slow.timeout(Duration.ofMillis(200)).retry(2).map(x -> "ответ").onErrorResume(e -> Mono.just(e.getClass().getSimpleName())).block();
        System.out.println("   timeout, затем retry: " + r1 + ", вызовов " + calls.get() + ", за " + (System.nanoTime() - t) / 1_000_000 + " мс");
        calls.set(0); t = System.nanoTime();
        String r2 = slow.retry(2).timeout(Duration.ofMillis(200)).map(x -> "ответ").onErrorResume(e -> Mono.just(e.getClass().getSimpleName())).block();
        System.out.println("   retry, затем timeout: " + r2 + ", вызовов " + calls.get() + ", за " + (System.nanoTime() - t) / 1_000_000 + " мс");
        calls.set(0); t = System.nanoTime();
        String r3 = slow.timeout(Duration.ofMillis(200)).retry(2).timeout(Duration.ofMillis(500)).map(x -> "ответ").onErrorResume(e -> Mono.just(e.getClass().getSimpleName())).block();
        System.out.println("   timeout 200 на попытку, retry, общий timeout 500: " + r3 + ", вызовов " + calls.get() + ", за " + (System.nanoTime() - t) / 1_000_000 + " мс");
    }

    /** 4. WebClient.retrieve() на 404. */
    static void webClient404() throws Exception {
        System.out.println("== 4. WebClient.retrieve().bodyToMono на ответ 404");
        HttpServer http = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        http.createContext("/books/", ex -> { ex.sendResponseHeaders(404, -1); ex.close(); });
        http.start();
        String base = "http://127.0.0.1:" + http.getAddress().getPort();
        try {
            WebClient wc = WebClient.create(base);
            Object r = wc.get().uri("/books/{isbn}", "978-5-4461").retrieve().bodyToMono(String.class)
                    .map(s -> (Object) ("тело: " + s)).onErrorResume(e -> Mono.just("ошибка " + e.getClass().getName() + ": " + e.getMessage())).block();
            System.out.println("   " + r);
            Object r2 = wc.get().uri("/books/{isbn}", "978-5-4461").retrieve()
                    .onStatus(s -> s.value() == 404, resp -> Mono.just(new NoSuchElementException("книги нет в каталоге")))
                    .bodyToMono(String.class).map(s -> (Object) s).onErrorResume(e -> Mono.just("с onStatus: " + e.getClass().getSimpleName() + ": " + e.getMessage())).block();
            System.out.println("   " + r2);
            Method onStatus = WebClient.ResponseSpec.class.getMethod("onStatus", java.util.function.Predicate.class, java.util.function.Function.class);
            System.out.println("   onStatus принимает Predicate<" + ((java.lang.reflect.ParameterizedType) onStatus.getGenericParameterTypes()[0]).getActualTypeArguments()[0].getTypeName() + ">");
        } finally { http.stop(0); }
    }

    /** 5. Сколько потоков цикла событий у Reactor Netty. */
    static void nettyLoops() {
        System.out.println("== 5. потоки цикла событий Reactor Netty");
        System.out.println("   ReactorNetty.IO_WORKER_COUNT по умолчанию: формула max(ядра, 4) = " + Math.max(Runtime.getRuntime().availableProcessors(), 4));
        Set<String> threads = ConcurrentHashMap.newKeySet();
        DisposableServer server = reactor.netty.http.server.HttpServer.create().host("127.0.0.1").port(0)
                .handle((req, res) -> { threads.add(Thread.currentThread().getName()); return res.sendString(Mono.just("ok")); })
                .bindNow();
        try {
            reactor.netty.http.client.HttpClient client = reactor.netty.http.client.HttpClient.create(
                    reactor.netty.resources.ConnectionProvider.newConnection());
            Flux.range(0, 200).flatMap(i -> client.get().uri("http://127.0.0.1:" + server.port() + "/").responseContent().aggregate().asString(), 200).blockLast();
            Set<String> server_ = threads.stream().filter(n -> n.startsWith("reactor-http")).collect(Collectors.toCollection(TreeSet::new));
            System.out.println("   200 запросов по отдельным соединениям обслужили потоков сервера: " + server_.size() + " " + server_);
        } finally { server.disposeNow(); }
    }

    /** 11. RestTemplate в Spring Framework 7. */
    static void restTemplate() {
        System.out.println("== 11. RestTemplate в spring-web " + RestTemplate.class.getPackage().getImplementationVersion());
        System.out.println("   @Deprecated на классе: " + RestTemplate.class.isAnnotationPresent(Deprecated.class));
    }

    /** 12. Сколько операторов у Flux и Mono. */
    static void operatorCount() {
        System.out.println("== 12. публичные методы Flux и Mono");
        for (Class<?> c : List.of(Flux.class, Mono.class)) {
            Method[] ms = Arrays.stream(c.getMethods()).filter(m -> m.getDeclaringClass() == c).toArray(Method[]::new);
            long names = Arrays.stream(ms).map(Method::getName).distinct().count();
            System.out.println("   " + c.getSimpleName() + ": методов с перегрузками " + ms.length + ", различных имён " + names);
        }
        Set<String> all = new TreeSet<>();
        for (Class<?> c : List.of(Flux.class, Mono.class))
            Arrays.stream(c.getMethods()).filter(m -> m.getDeclaringClass() == c).forEach(m -> all.add(m.getName()));
        System.out.println("   различных имён у обоих вместе: " + all.size());
    }

    /** 13. Пример расчёта кредита: Mono.fromSupplier и два map из одного Mono. */
    static void doubleSubscription() {
        System.out.println("== 13. personMono = Mono.fromSupplier(getPerson), активы и обязательства через map, затем zip");
        AtomicInteger getPerson = new AtomicInteger();
        Set<String> where = ConcurrentHashMap.newKeySet();
        Mono<String> personMono = Mono.fromSupplier(() -> { getPerson.incrementAndGet(); where.add(Thread.currentThread().getName()); sleep(100); return "клиент 42"; });
        Mono<Integer> assets = personMono.map(p -> { where.add(Thread.currentThread().getName()); sleep(100); return 900_000; });
        Mono<Integer> liabilities = personMono.map(p -> { where.add(Thread.currentThread().getName()); sleep(100); return 250_000; });
        long t = System.nanoTime();
        Integer credit = Mono.zip(assets, liabilities).map(x -> x.getT1() - x.getT2()).block();
        System.out.println("   кредитный лимит " + credit + "; getPerson вызван " + getPerson.get() + " раза; потоки " + where + "; за " + (System.nanoTime() - t) / 1_000_000 + " мс");
        getPerson.set(0); where.clear();
        Mono<String> cached = personMono.subscribeOn(Schedulers.boundedElastic()).cache();
        Mono<Integer> a2 = cached.publishOn(Schedulers.boundedElastic()).map(p -> { where.add(Thread.currentThread().getName()); sleep(100); return 900_000; });
        Mono<Integer> l2 = cached.publishOn(Schedulers.boundedElastic()).map(p -> { where.add(Thread.currentThread().getName()); sleep(100); return 250_000; });
        t = System.nanoTime();
        credit = Mono.zip(a2, l2).map(x -> x.getT1() - x.getT2()).block();
        System.out.println("   с cache() и boundedElastic: лимит " + credit + "; getPerson вызван " + getPerson.get() + " раз; потоков " + where.size() + "; за " + (System.nanoTime() - t) / 1_000_000 + " мс");
    }

    /** 16. Что запрашивает flatMap у внутренних издателей. */
    static void flatMapPrefetch() {
        System.out.println("== 16. запросы request(n) вокруг flatMap");
        List<String> outer = new CopyOnWriteArrayList<>(), inner = new CopyOnWriteArrayList<>();
        Flux.range(1, 3).doOnRequest(n -> outer.add(String.valueOf(n)))
                .flatMap(i -> Flux.range(i * 10, 2).doOnRequest(n -> inner.add(String.valueOf(n))))
                .blockLast();
        System.out.println("   flatMap у источника запросил: " + outer + "; у каждого внутреннего: " + inner);
        outer.clear(); inner.clear();
        Flux.range(1, 3).doOnRequest(n -> outer.add(String.valueOf(n)))
                .flatMap(i -> Flux.range(i * 10, 2).doOnRequest(n -> inner.add(String.valueOf(n))), 8, 4)
                .blockLast();
        System.out.println("   flatMap(…, 8, 4): у источника " + outer + "; у внутренних " + inner);
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
}
