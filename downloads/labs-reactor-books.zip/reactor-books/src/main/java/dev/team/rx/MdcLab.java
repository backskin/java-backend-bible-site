package dev.team.rx;

import io.micrometer.context.ContextRegistry;
import org.slf4j.MDC;
import reactor.core.publisher.Hooks;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.util.context.Context;

/**
 * Разд. 13.5 гл. 11: регрессионный тест из главы на перенос MDC через publishOn, буквально.
 * Аргументы: [accessor] [hook] — регистрировать ли метод доступа «traceId» и включать ли автоматический режим.
 * MDC — настоящий, через logback-classic.
 */
public final class MdcLab {
    public static void main(String[] a) {
        boolean accessor = java.util.Arrays.asList(a).contains("accessor"), hook = java.util.Arrays.asList(a).contains("hook");
        if (accessor) ContextRegistry.getInstance().registerThreadLocalAccessor("traceId",
                () -> MDC.get("traceId"), v -> MDC.put("traceId", v), () -> MDC.remove("traceId"));
        if (hook) Hooks.enableAutomaticContextPropagation();
        String v = Mono.deferContextual(ctx -> Mono.just(1))
                .publishOn(Schedulers.parallel())
                .map(i -> String.valueOf(MDC.get("traceId")))
                .contextWrite(Context.of("traceId", "T-1"))
                .block();
        System.out.printf("   метод доступа: %-3s хук: %-3s → MDC.get(\"traceId\") после publishOn = %s; адаптер MDC: %s%n",
                accessor ? "да" : "нет", hook ? "да" : "нет", v, MDC.getMDCAdapter().getClass().getSimpleName());
    }
}
