package dev.team.rx;

import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Гл. 11, раздел 7.5: timeout с запасным Mono.empty() перед retryWhen (листинг книги Vitale, разд. 8.4.2).
 * Сервис каталога отвечает через 300 мс, тайм-аут 200 мс, Retry.backoff(3, 100 мс).
 */
public class TimeoutFallbackLab {

    static Mono<String> slowCatalog(AtomicInteger calls) {
        return Mono.defer(() -> { calls.incrementAndGet(); return Mono.delay(Duration.ofMillis(300)).thenReturn("book"); });
    }

    static void run(String title, Mono<String> chain, AtomicInteger calls) {
        long t0 = System.nanoTime();
        String result;
        try {
            result = String.valueOf(chain.block());
        } catch (Exception e) {
            result = e.getClass().getSimpleName();
        }
        System.out.printf("%-60s вызовов %d, результат %s, за %d мс%n", title, calls.get(), result, (System.nanoTime() - t0) / 1_000_000);
    }

    public static void main(String[] args) {
        AtomicInteger c1 = new AtomicInteger();
        run("timeout(200 мс, Mono.empty()).retryWhen(backoff(3, 100 мс))",
                slowCatalog(c1).timeout(Duration.ofMillis(200), Mono.empty()).retryWhen(Retry.backoff(3, Duration.ofMillis(100))), c1);
        AtomicInteger c2 = new AtomicInteger();
        run("timeout(200 мс).retryWhen(backoff(3, 100 мс))",
                slowCatalog(c2).timeout(Duration.ofMillis(200)).retryWhen(Retry.backoff(3, Duration.ofMillis(100))), c2);
        AtomicInteger c3 = new AtomicInteger();
        run("timeout(200 мс).retryWhen(backoff(3, 100 мс)).onErrorResume(empty)",
                slowCatalog(c3).timeout(Duration.ofMillis(200)).retryWhen(Retry.backoff(3, Duration.ofMillis(100)))
                        .onErrorResume(e -> Mono.empty()), c3);
    }
}
