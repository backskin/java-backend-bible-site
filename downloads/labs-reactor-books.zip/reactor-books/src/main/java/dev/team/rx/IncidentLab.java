package dev.team.rx;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.publisher.PublisherProbe;

/**
 * Разд. 13.4 и 13.6 гл. 11.
 * 13.4: onErrorContinue ниже по цепочке и onErrorResume внутри flatMap — кто перехватывает ошибку map во внутренней цепочке.
 * 13.6: switchIfEmpty(archive.find(id)) без defer — вызов метода происходит всегда; ловит ли это PublisherProbe.
 */
public final class IncidentLab {

    static int enrich(int x) { if (x % 10 == 0) throw new IllegalArgumentException("битая запись " + x); return x; }

    public static void main(String[] args) {
        System.out.println("== 13.4. 100 записей, каждая десятая «битая»; внутри flatMap — onErrorResume с заглушкой -1");
        List<Integer> plain = Flux.range(1, 100)
                .flatMap(x -> Mono.just(x).map(IncidentLab::enrich).onErrorResume(e -> Mono.just(-1)))
                .collectList().block();
        System.out.println("   без onErrorContinue: элементов " + plain.size() + ", заглушек -1: " + plain.stream().filter(v -> v == -1).count());
        AtomicInteger skipped = new AtomicInteger();
        List<Integer> withContinue = Flux.range(1, 100)
                .flatMap(x -> Mono.just(x).map(IncidentLab::enrich).onErrorResume(e -> Mono.just(-1)))
                .onErrorContinue((e, o) -> skipped.incrementAndGet())
                .collectList().block();
        System.out.println("   с onErrorContinue ниже: элементов " + withContinue.size() + ", заглушек -1: "
                + withContinue.stream().filter(v -> v == -1).count() + ", вызовов onErrorContinue: " + skipped.get());

        System.out.println("== 13.6. switchIfEmpty без defer, основной источник непустой");
        AtomicInteger archiveCalls = new AtomicInteger();
        PublisherProbe<String> probe = PublisherProbe.empty();
        java.util.function.Supplier<Mono<String>> archiveFind = () -> { archiveCalls.incrementAndGet(); return probe.mono(); };
        String r = Mono.just("счёт 40817").switchIfEmpty(archiveFind.get()).block();
        System.out.println("   результат: " + r + "; метод архива вызван раз: " + archiveCalls.get() + "; PublisherProbe подписан: " + probe.wasSubscribed());
        archiveCalls.set(0);
        PublisherProbe<String> probe2 = PublisherProbe.empty();
        java.util.function.Supplier<Mono<String>> archiveFind2 = () -> { archiveCalls.incrementAndGet(); return probe2.mono(); };
        Mono.just("счёт 40817").switchIfEmpty(Mono.defer(archiveFind2)).block();
        System.out.println("   с Mono.defer: метод архива вызван раз: " + archiveCalls.get() + "; PublisherProbe подписан: " + probe2.wasSubscribed());
    }
}
