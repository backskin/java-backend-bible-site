package dev.team.rx;

import io.micrometer.context.ContextRegistry;
import io.micrometer.context.ThreadLocalAccessor;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.MDC;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Hooks;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/**
 * Разд. 8.4–8.6 гл. 11: что видит лямбда в ограниченном и автоматическом режиме context-propagation,
 * и сколько стоит автоматический режим на сигнал при 0, 1 и 4 методах доступа и при MDC.
 * Запуск: java ... CtxLab limited | auto
 */
public final class CtxLab {

    static final List<ThreadLocal<String>> LOCALS = new ArrayList<>();

    static void register(int n) {
        for (int i = LOCALS.size(); i < n; i++) {
            ThreadLocal<String> tl = new ThreadLocal<>();
            LOCALS.add(tl);
            String key = "k" + i;
            ContextRegistry.getInstance().registerThreadLocalAccessor(new ThreadLocalAccessor<String>() {
                public Object key() { return key; }
                public String getValue() { return tl.get(); }
                public void setValue(String v) { tl.set(v); }
                public void setValue() { tl.remove(); }
            });
        }
    }

    /** ns на элемент цепочки из пяти map на миллионе элементов, с контекстом на n ключей. */
    static double cost(int keys) {
        Flux<Integer> f = Flux.range(1, 1_000_000);
        for (int i = 0; i < 5; i++) f = f.map(x -> x + 1);
        Flux<Integer> chain = f.contextWrite(c -> { for (int i = 0; i < keys; i++) c = c.put("k" + i, "v" + i); return c; });
        long best = Long.MAX_VALUE;
        for (int r = 0; r < 7; r++) { long t0 = System.nanoTime(); chain.blockLast(); best = Math.min(best, System.nanoTime() - t0); }
        return best / 1_000_000.0;
    }

    public static void main(String[] args) {
        boolean auto = args.length > 0 && args[0].equals("auto");
        if (auto) Hooks.enableAutomaticContextPropagation();
        int acc = args.length > 1 ? Integer.parseInt(args[1]) : 4;
        register(Math.max(acc, 2));
        if (acc < 2) { /* для проверки утечки нужны два ThreadLocal; лишний аксессор снимаем */ }
        ContextRegistry.getInstance().loadThreadLocalAccessors();   // штатные, если есть на пути классов (MDC через Slf4j — нет)
        System.out.println("== 8.4. режим " + (auto ? "auto (Hooks.enableAutomaticContextPropagation)" : "limited") + ", зарегистрировано методов доступа: " + LOCALS.size());

        String inMap = Mono.just(1).publishOn(Schedulers.parallel()).map(x -> String.valueOf(LOCALS.get(0).get()))
                .contextWrite(c -> c.put("k0", "платёж-77")).block();
        String inHandle = Mono.just(1).publishOn(Schedulers.parallel()).<String>handle((x, sink) -> sink.next(String.valueOf(LOCALS.get(0).get())))
                .contextWrite(c -> c.put("k0", "платёж-77")).block();
        System.out.println("   ThreadLocal внутри map: " + inMap + "; внутри handle: " + inHandle);

        LOCALS.get(1).set("осталось от прошлой задачи");
        String leaked = Mono.fromCallable(() -> String.valueOf(LOCALS.get(1).get())).contextWrite(c -> c.put("k0", "x")).block();
        String leakedMap = Mono.just(1).map(x -> String.valueOf(LOCALS.get(1).get())).contextWrite(c -> c.put("k0", "x")).block();
        System.out.println("   значение, оставленное в ThreadLocal до подписки, в fromCallable: " + leaked + "; в map на том же потоке: " + leakedMap);
        LOCALS.get(1).remove();
        reactor.core.scheduler.Scheduler w = Schedulers.newSingle("worker");
        w.schedule(() -> LOCALS.get(1).set("осталось на рабочем потоке"));          // «грязный» поток пула
        try { Thread.sleep(50); } catch (InterruptedException e) { }
        String hop = Mono.just(1).publishOn(w).map(x -> String.valueOf(LOCALS.get(1).get())).contextWrite(c -> c.put("k0", "x")).block();
        String hopNoCtx = Mono.just(1).publishOn(w).map(x -> String.valueOf(LOCALS.get(1).get())).block();
        System.out.println("   после publishOn на поток, где ThreadLocal остался от чужой задачи: с Context " + hop + ", без Context " + hopNoCtx);
        w.dispose();

        System.out.println("== 8.6. миллион элементов, пять map, лучшая из 7 серий, нс на элемент на оператор");
        for (int keys : new int[] {0, 1, 4}) {
            double ns = cost(keys);
            System.out.printf("   ключей в Context: %d  →  %.1f нс на элемент, %.1f нс на сигнал одного map%n", keys, ns, ns / 5);
        }
        MDC.put("traceId", "abc");
    }
}
