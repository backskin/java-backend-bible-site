package dev.team.ch04;

import org.javamoney.moneta.FastMoney;
import org.javamoney.moneta.Money;

import javax.money.Monetary;
import javax.money.MonetaryAmount;
import javax.money.convert.MonetaryConversions;
import javax.money.format.MonetaryAmountFormat;
import javax.money.format.MonetaryFormats;
import java.math.BigDecimal;
import java.util.Locale;

/** JSR-354 (javax.money 1.1) with Moneta: the chapter's listing plus rounding by currency, FastMoney and rate providers. */
public class MonetaDemo {
    public static void main(String[] args) {
        MonetaryAmount m = Monetary.getDefaultAmountFactory()
                .setCurrency("RUB").setNumber(new BigDecimal("100.00")).create();
        MonetaryAmount rounded = m.with(Monetary.getDefaultRounding());
        MonetaryAmountFormat fmt = MonetaryFormats.getAmountFormat(Locale.forLanguageTag("ru"));
        System.out.println("listing: " + fmt.format(m) + "  class=" + m.getClass().getSimpleName() + "  rounded=" + rounded);

        MonetaryAmount third = Money.of(new BigDecimal("100.00"), "RUB").divide(3);
        System.out.println("100.00 RUB / 3 = " + third + "  -> default rounding (by currency, 2 digits): " + third.with(Monetary.getDefaultRounding()));
        MonetaryAmount kwd = Money.of(new BigDecimal("100"), "KWD").divide(3).with(Monetary.getDefaultRounding());
        System.out.println("100 KWD / 3 rounded by currency (3 digits): " + kwd);
        System.out.println("rounding JPY: " + Money.of(new BigDecimal("1234.56"), "JPY").with(Monetary.getDefaultRounding()));

        FastMoney fast = FastMoney.of(new BigDecimal("19.99"), "RUB");
        System.out.println("FastMoney 19.99 RUB * 3 = " + fast.multiply(3) + "  (long with 5 decimals)");
        try {
            FastMoney.of(new BigDecimal("0.000001"), "RUB");
        } catch (ArithmeticException e) {
            System.out.println("FastMoney 0.000001 RUB -> " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        System.out.println("Money.equals ignores scale? " + Money.of(new BigDecimal("1.0"), "RUB").equals(Money.of(new BigDecimal("1.00"), "RUB"))
                + "; Money vs FastMoney equal? " + Money.of(1, "RUB").equals(FastMoney.of(1, "RUB"))
                + "; isEqualTo: " + Money.of(1, "RUB").isEqualTo(FastMoney.of(1, "RUB")));
        System.out.println("rate providers in the default chain: " + MonetaryConversions.getDefaultConversionProviderChain());
        System.out.println("formatted for de: " + MonetaryFormats.getAmountFormat(Locale.GERMANY).format(Money.of(new BigDecimal("1234567.891"), "EUR")));
    }
}
