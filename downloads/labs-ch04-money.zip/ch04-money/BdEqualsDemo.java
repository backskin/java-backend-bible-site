import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class BdEqualsDemo {

    /** Фабрика нормализует scale по валюте: UNNECESSARY бросает исключение, если знаков больше допустимого. */
    static BigDecimal money(String amount, String currency) {
        int digits = Currency.getInstance(currency).getDefaultFractionDigits();
        return new BigDecimal(amount).setScale(digits, RoundingMode.UNNECESSARY);
    }

    public static void main(String[] args) {
        BigDecimal a = new BigDecimal("2.0"), b = new BigDecimal("2.00");
        System.out.println("--- 1. два понятия равенства");
        System.out.println("a.equals(b):                " + a.equals(b));
        System.out.println("a.compareTo(b) == 0:        " + (a.compareTo(b) == 0));
        System.out.println("hashCode: " + a.hashCode() + " и " + b.hashCode());
        System.out.println("scale: " + a.scale() + " и " + b.scale() + ", unscaled: " + a.unscaledValue() + " и " + b.unscaledValue());

        System.out.println("--- 2. коллекции");
        Set<BigDecimal> hash = new HashSet<>(List.of(a));
        System.out.println("HashSet{2.0}.contains(2.00): " + hash.contains(b));
        Set<BigDecimal> hs = new HashSet<>(List.of(a, b));
        Set<BigDecimal> ts = new TreeSet<>(List.of(a, b));
        System.out.println("размер HashSet: " + hs.size() + ", размер TreeSet: " + ts.size());
        System.out.println("List.of(2.0).contains(2.00): " + List.of(a).contains(b));

        System.out.println("--- 3. сравнение с нулём");
        BigDecimal zero = new BigDecimal("0.00");
        System.out.println("0.00.equals(ZERO):          " + zero.equals(BigDecimal.ZERO));
        System.out.println("0.00.signum() == 0:         " + (zero.signum() == 0));
        System.out.println("0.00.compareTo(ZERO) == 0:  " + (zero.compareTo(BigDecimal.ZERO) == 0));

        System.out.println("--- 4. нормализация scale при создании суммы");
        System.out.println("money(\"2.0\", \"RUB\").equals(money(\"2.00\", \"RUB\")): " + money("2.0", "RUB").equals(money("2.00", "RUB")));
        try { money("2.005", "RUB"); } catch (ArithmeticException e) { System.out.println("money(\"2.005\", \"RUB\"): ArithmeticException: " + e.getMessage()); }
        System.out.println("money(\"1000\", \"JPY\") = " + money("1000", "JPY") + " (у иены знаков нет)");
    }
}
