import java.math.BigDecimal;
import java.math.RoundingMode;

public class BdCtorDemo {

    static void p(String label, Object v) { System.out.println(String.format("%-46s %s", label, v)); }

    public static void main(String[] args) {
        System.out.println("--- 1. фабрики на числе 0,1");
        p("new BigDecimal(0.1)", new BigDecimal(0.1));
        p("new BigDecimal(\"0.1\")", new BigDecimal("0.1") + ", scale=" + new BigDecimal("0.1").scale());
        p("BigDecimal.valueOf(0.1)", BigDecimal.valueOf(0.1) + ", scale=" + BigDecimal.valueOf(0.1).scale());
        p("BigDecimal.valueOf(10, 2)", BigDecimal.valueOf(10, 2) + ", unscaled=10, scale=2");
        p("new BigDecimal(0.1f)", new BigDecimal(0.1f));
        p("цифр в new BigDecimal(0.1)", new BigDecimal(0.1).precision() + " значащих");

        System.out.println("--- 2. ничья округления: комиссия 1,5 % и сумма 2,675");
        p("new BigDecimal(0.015) HALF_UP до 2 знаков", new BigDecimal(0.015).setScale(2, RoundingMode.HALF_UP));
        p("new BigDecimal(\"0.015\") HALF_UP до 2 знаков", new BigDecimal("0.015").setScale(2, RoundingMode.HALF_UP));
        p("new BigDecimal(2.675) HALF_UP до 2 знаков", new BigDecimal(2.675).setScale(2, RoundingMode.HALF_UP));
        p("BigDecimal.valueOf(2.675) HALF_UP до 2 знаков", BigDecimal.valueOf(2.675).setScale(2, RoundingMode.HALF_UP));

        System.out.println("--- 3. valueOf не лечит ошибку, возникшую до вызова");
        p("BigDecimal.valueOf(0.1 + 0.2)", BigDecimal.valueOf(0.1 + 0.2));
        p("BigDecimal.valueOf(1.0)", BigDecimal.valueOf(1.0) + ", scale=" + BigDecimal.valueOf(1.0).scale());
        p("BigDecimal.valueOf(100.0)", BigDecimal.valueOf(100.0));

        System.out.println("--- 4. кеш valueOf(long)");
        p("valueOf(5) == valueOf(5)", BigDecimal.valueOf(5) == BigDecimal.valueOf(5));
        p("valueOf(10) == valueOf(10)", BigDecimal.valueOf(10) == BigDecimal.valueOf(10));
        p("valueOf(11) == valueOf(11)", BigDecimal.valueOf(11) == BigDecimal.valueOf(11));
    }
}
