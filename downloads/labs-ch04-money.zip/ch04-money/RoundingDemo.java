import java.math.BigDecimal;
import java.math.RoundingMode;

public class RoundingDemo {

    public static void main(String[] args) {
        System.out.println("--- 1. setScale(0, режим) для разных значений");
        RoundingMode[] modes = {RoundingMode.UP, RoundingMode.DOWN, RoundingMode.CEILING, RoundingMode.FLOOR,
                RoundingMode.HALF_UP, RoundingMode.HALF_DOWN, RoundingMode.HALF_EVEN};
        System.out.printf("%-6s", "");
        for (RoundingMode m : modes) System.out.printf("%-10s", m);
        System.out.println();
        for (String v : new String[]{"5.5", "2.5", "1.6", "1.1", "-1.1", "-2.5"}) {
            System.out.printf("%-6s", v);
            for (RoundingMode m : modes) System.out.printf("%-10s", new BigDecimal(v).setScale(0, m));
            System.out.println();
        }

        System.out.println("--- 2. комиссия 0,5 % с ста тысяч платежей от 0,10 до 10 000,00");
        BigDecimal rate = new BigDecimal("0.005");
        BigDecimal exact = BigDecimal.ZERO, up = BigDecimal.ZERO, even = BigDecimal.ZERO;
        for (int c = 1; c <= 100_000; c++) {
            BigDecimal fee = BigDecimal.valueOf(c * 10L, 2).multiply(rate);
            exact = exact.add(fee);
            up = up.add(fee.setScale(2, RoundingMode.HALF_UP));
            even = even.add(fee.setScale(2, RoundingMode.HALF_EVEN));
        }
        System.out.println("точная сумма: " + exact);
        System.out.println("HALF_UP:      " + up);
        System.out.println("HALF_EVEN:    " + even);

        System.out.println("--- 3. миллион сумм вида x.xx5, где каждая является ничьей");
        BigDecimal upSum = BigDecimal.ZERO, evenSum = BigDecimal.ZERO;
        for (int i = 0; i < 1_000_000; i++) {
            BigDecimal v = BigDecimal.valueOf(i * 10L + 5, 3);
            upSum = upSum.add(v.setScale(2, RoundingMode.HALF_UP));
            evenSum = evenSum.add(v.setScale(2, RoundingMode.HALF_EVEN));
        }
        System.out.println("HALF_UP минус HALF_EVEN: " + upSum.subtract(evenSum));

        System.out.println("--- 4. UNNECESSARY на сумме с лишними знаками");
        try { new BigDecimal("10.005").setScale(2, RoundingMode.UNNECESSARY); }
        catch (ArithmeticException e) { System.out.println("ArithmeticException: " + e.getMessage()); }
    }
}
