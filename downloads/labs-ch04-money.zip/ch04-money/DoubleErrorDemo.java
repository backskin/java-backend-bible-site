import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;
import java.util.stream.DoubleStream;

public class DoubleErrorDemo {

    public static void main(String[] args) {
        System.out.println("--- 1. десять миллионов копеек");
        double sum = 0.0;
        for (int i = 0; i < 10_000_000; i++) sum += 0.01;
        System.out.println(sum + "   (ожидалось 100000.0), sum == 100000.0: " + (sum == 100000.0));
        System.out.println(new BigDecimal(sum).setScale(2, RoundingMode.HALF_UP));

        System.out.println("--- 2. сложение не ассоциативно");
        System.out.println((0.1 + 0.2) + 0.3);
        System.out.println(0.1 + (0.2 + 0.3));

        System.out.println("--- 3. миллион платежей: прямой и обратный порядок");
        Random r = new Random(42);
        double[] p = new double[1_000_000];
        for (int i = 0; i < p.length; i++) p[i] = (r.nextInt(1_000_000) + 1) / 100.0;
        double forward = 0, backward = 0;
        for (int i = 0; i < p.length; i++) forward += p[i];
        for (int i = p.length - 1; i >= 0; i--) backward += p[i];
        System.out.println(forward);
        System.out.println(backward);
        System.out.println("forward == backward: " + (forward == backward));

        System.out.println("--- 4. слагаемое, которое теряется целиком");
        double[] v = {1e16, 1.0, -1e16};
        System.out.println(v[0] + v[1] + v[2]);
        System.out.println(v[0] + v[2] + v[1]);

        System.out.println("--- 5. DoubleStream.sum(): последовательно и параллельно");
        System.out.println(DoubleStream.generate(() -> 0.01).limit(10_000_000).sum());
        System.out.println(DoubleStream.generate(() -> 0.01).limit(10_000_000).parallel().sum());

        System.out.println("--- 6. комиссия 1,5 % с суммы 11,00: точно и через double");
        BigDecimal exact = new BigDecimal("11.00").multiply(new BigDecimal("0.015")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal viaDouble = BigDecimal.valueOf(11.00 * 0.015).setScale(2, RoundingMode.HALF_UP);
        System.out.println(exact + " против " + viaDouble + "   (11.00 * 0.015 = " + (11.00 * 0.015) + ")");

        System.out.println("--- 7. перебор сумм 0,01 .. 1000,00 с шагом в копейку");
        BigDecimal rate = new BigDecimal("0.015");
        int diff = 0, down = 0, total = 100_000;
        for (int kop = 1; kop <= total; kop++) {
            BigDecimal amount = BigDecimal.valueOf(kop, 2);                            // сумма в рублях с точностью до копейки
            BigDecimal e = amount.multiply(rate).setScale(2, RoundingMode.HALF_UP);
            BigDecimal d = BigDecimal.valueOf(amount.doubleValue() * 0.015).setScale(2, RoundingMode.HALF_UP);
            if (e.compareTo(d) != 0) { diff++; if (d.compareTo(e) < 0) down++; }
        }
        System.out.println("расхождений " + diff + " из " + total + " (" + String.format("%.2f", 100.0 * diff / total) + " %), из них double давал меньше: " + down);
    }
}
