import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;

/**
 * Сверка двух реестров комиссий: построчное округление HALF_UP и HALF_EVEN против округления по итогу.
 * Запуск: java ReconcileDemo.java (JDK 21, без зависимостей). Данные учебные.
 */
public class ReconcileDemo {

    public static void main(String[] args) {
        Random r = new Random(42);
        int n = 10_000;
        BigDecimal[] amounts = new BigDecimal[n];
        for (int i = 0; i < n; i++) amounts[i] = BigDecimal.valueOf(r.nextInt(900_000 - 100) + 100, 2);   // 1,00 .. 9 000,00

        for (String rateStr : new String[]{"0.015", "0.0175"}) {
            BigDecimal rate = new BigDecimal(rateStr);
            BigDecimal rowUp = BigDecimal.ZERO, rowEven = BigDecimal.ZERO, exact = BigDecimal.ZERO;
            int diff0 = 0, diff1 = 0;
            for (BigDecimal a : amounts) {
                BigDecimal fee = a.multiply(rate);
                BigDecimal up = fee.setScale(2, RoundingMode.HALF_UP);
                BigDecimal even = fee.setScale(2, RoundingMode.HALF_EVEN);
                rowUp = rowUp.add(up); rowEven = rowEven.add(even); exact = exact.add(fee);
                BigDecimal d = up.subtract(even).abs();
                if (d.signum() != 0) diff0++;
                if (d.compareTo(new BigDecimal("0.01")) > 0) diff1++;
            }
            BigDecimal byTotal = exact.setScale(2, RoundingMode.HALF_UP);
            System.out.println("ставка " + rateStr + ": построчно HALF_UP " + rowUp + ", построчно HALF_EVEN " + rowEven + ", по итогу " + byTotal);
            System.out.println("   расхождение построчно HALF_UP / итог: " + rowUp.subtract(byTotal) + ", HALF_EVEN / итог: " + rowEven.subtract(byTotal));
            System.out.println("   сверка реестра HALF_UP с реестром HALF_EVEN по строкам: допуск 0 -> расхождений " + diff0 + " из " + n
                    + ", допуск 0,01 -> расхождений " + diff1 + " из " + n);
        }
    }
}
