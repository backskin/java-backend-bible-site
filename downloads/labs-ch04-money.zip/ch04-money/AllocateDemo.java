import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Currency;
import java.util.List;

public class AllocateDemo {

    record Money(long minor, Currency currency) {

        static Money of(String amount, String code) {
            Currency c = Currency.getInstance(code);
            return new Money(new BigDecimal(amount).movePointRight(c.getDefaultFractionDigits()).longValueExact(), c);
        }

        long toMinor() { return minor; }

        @Override public String toString() { return BigDecimal.valueOf(minor, currency.getDefaultFractionDigits()) + " " + currency; }

        /** Разделить на n равных частей; остаток раздаётся по одной минорной единице первым частям. */
        List<Money> allocate(int n) {
            if (n <= 0) throw new IllegalArgumentException("n must be positive");
            long total = toMinor();
            long base = total / n;
            long rem = Math.abs(total % n);
            long sign = total < 0 ? -1 : 1;
            List<Money> result = new ArrayList<>(n);
            for (int i = 0; i < n; i++) result.add(new Money(base + (i < rem ? sign : 0), currency));
            return result;
        }

        /** Разделить пропорционально весам; нулевой вес остатка не получает. */
        List<Money> allocate(long... weights) {
            long totalWeight = 0;
            for (long w : weights) {
                if (w < 0) throw new IllegalArgumentException("weight must be non-negative");
                totalWeight = Math.addExact(totalWeight, w);
            }
            if (totalWeight == 0) throw new IllegalArgumentException("total weight is zero");
            long total = toMinor();
            long allocated = 0;
            long[] parts = new long[weights.length];
            for (int i = 0; i < weights.length; i++) {
                parts[i] = Math.multiplyExact(total, weights[i]) / totalWeight;      // усечение к нулю
                allocated += parts[i];
            }
            long rem = total - allocated;
            for (int i = 0; rem != 0; i = (i + 1) % parts.length) {
                if (weights[i] == 0) continue;
                parts[i] += Long.signum(rem);
                rem -= Long.signum(rem);
            }
            return Arrays.stream(parts).mapToObj(p -> new Money(p, currency)).toList();
        }

        /** Прежняя версия без проверки нулевого веса: оставлена, чтобы показать ошибку. */
        List<Money> allocateBuggy(long... weights) {
            long totalWeight = Arrays.stream(weights).sum();
            long total = toMinor(), allocated = 0;
            long[] parts = new long[weights.length];
            for (int i = 0; i < weights.length; i++) { parts[i] = total * weights[i] / totalWeight; allocated += parts[i]; }
            long rem = total - allocated;
            for (int i = 0; rem != 0; i = (i + 1) % parts.length) { parts[i] += Long.signum(rem); rem -= Long.signum(rem); }
            return Arrays.stream(parts).mapToObj(p -> new Money(p, currency)).toList();
        }
    }

    static long sumMinor(List<Money> parts) { return parts.stream().mapToLong(Money::minor).sum(); }

    public static void main(String[] args) {
        System.out.println("--- 1. равные части");
        System.out.println("100.00 RUB на 3: " + Money.of("100.00", "RUB").allocate(3) + ", сумма " + sumMinor(Money.of("100.00", "RUB").allocate(3)) + " коп.");
        System.out.println("0.05 RUB на 3:   " + Money.of("0.05", "RUB").allocate(3));
        System.out.println("-100.00 RUB на 3: " + Money.of("-100.00", "RUB").allocate(3));

        System.out.println("--- 2. по весам");
        System.out.println("100.00 RUB, веса 1:1:2:   " + Money.of("100.00", "RUB").allocate(1, 1, 2));
        System.out.println("1000.10 RUB, веса 95:5:   " + Money.of("1000.10", "RUB").allocate(95, 5));

        System.out.println("--- 3. нулевой вес");
        System.out.println("0.01 RUB, веса 0:1:1, прежняя версия: " + Money.of("0.01", "RUB").allocateBuggy(0, 1, 1));
        System.out.println("0.01 RUB, веса 0:1:1, исправленная:   " + Money.of("0.01", "RUB").allocate(0, 1, 1));

        System.out.println("--- 4. что даёт независимое округление долей");
        BigDecimal total = new BigDecimal("1000.10");
        BigDecimal part1 = total.multiply(new BigDecimal("0.95")).setScale(2, java.math.RoundingMode.HALF_UP);
        BigDecimal part2 = total.multiply(new BigDecimal("0.05")).setScale(2, java.math.RoundingMode.HALF_UP);
        System.out.println("95 % = " + part1 + ", 5 % = " + part2 + ", сумма = " + part1.add(part2) + " (платёж был " + total + ")");

        System.out.println("--- 5. переполнение при больших весах");
        try { Money.of("1000.00", "RUB").allocate(Long.MAX_VALUE / 2, Long.MAX_VALUE / 2); }
        catch (ArithmeticException e) { System.out.println("ArithmeticException: " + e.getMessage()); }
    }
}
