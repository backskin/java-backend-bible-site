import java.math.BigDecimal;
import java.math.RoundingMode;

public class ChainRoundingDemo {

    public static void main(String[] args) {
        System.out.println("--- 1. комиссия 0,35 % и НДС 20 % с платежа 1234,56");
        BigDecimal amount = new BigDecimal("1234.56");
        BigDecimal feeRaw = amount.multiply(new BigDecimal("0.0035"));
        BigDecimal vatRaw = feeRaw.multiply(new BigDecimal("0.20"));
        System.out.println("точная комиссия " + feeRaw + ", точный НДС " + vatRaw);
        System.out.println("округлили один раз в конце:   " + feeRaw.add(vatRaw).setScale(2, RoundingMode.HALF_UP));
        BigDecimal fee = feeRaw.setScale(2, RoundingMode.HALF_UP);
        BigDecimal vat = fee.multiply(new BigDecimal("0.20")).setScale(2, RoundingMode.HALF_UP);
        System.out.println("округлили комиссию и НДС:     " + fee + " + " + vat + " = " + fee.add(vat));

        System.out.println("--- 2. НДС по позициям и от итога");
        BigDecimal[] lines = {new BigDecimal("33.33"), new BigDecimal("33.33"), new BigDecimal("33.34")};
        BigDecimal vatLines = BigDecimal.ZERO, totalNet = BigDecimal.ZERO;
        BigDecimal rate = new BigDecimal("0.20");
        for (BigDecimal l : lines) { vatLines = vatLines.add(l.multiply(rate).setScale(2, RoundingMode.HALF_UP)); totalNet = totalNet.add(l); }
        System.out.println("сумма НДС по позициям: " + vatLines + ", НДС от итога " + totalNet + ": " + totalNet.multiply(rate).setScale(2, RoundingMode.HALF_UP));

        System.out.println("--- 3. платёж 1000,10: независимые доли 95 % и 5 %");
        BigDecimal total = new BigDecimal("1000.10");
        BigDecimal seller = total.multiply(new BigDecimal("0.95")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal platform = total.multiply(new BigDecimal("0.05")).setScale(2, RoundingMode.HALF_UP);
        System.out.println("продавец " + seller + " + площадка " + platform + " = " + seller.add(platform) + " при платеже " + total);
        BigDecimal platformByDiff = total.subtract(seller);
        System.out.println("площадка как разность: " + platformByDiff + ", сумма " + seller.add(platformByDiff));

        System.out.println("--- 4. перебор всех платежей от 0,01 до 10 000,00 с шагом в копейку");
        int mismatches = 0, n = 1_000_000;
        BigDecimal r95 = new BigDecimal("0.95"), r05 = new BigDecimal("0.05");
        for (int kop = 1; kop <= n; kop++) {
            BigDecimal t = BigDecimal.valueOf(kop, 2);
            BigDecimal a = t.multiply(r95).setScale(2, RoundingMode.HALF_UP);
            BigDecimal b = t.multiply(r05).setScale(2, RoundingMode.HALF_UP);
            if (a.add(b).compareTo(t) != 0) mismatches++;
        }
        System.out.println("расхождений " + mismatches + " из " + n + " (" + (100.0 * mismatches / n) + " %)");
        BigDecimal t999 = new BigDecimal("999.99");
        BigDecimal x = t999.multiply(r95).setScale(2, RoundingMode.HALF_UP), y = t999.multiply(r05).setScale(2, RoundingMode.HALF_UP);
        System.out.println("платёж 999.99: " + x + " + " + y + " = " + x.add(y));
    }
}
