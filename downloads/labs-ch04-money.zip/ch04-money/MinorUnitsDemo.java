import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.Currency;

public class MinorUnitsDemo {

    /** Деньги в минорных единицах: целые копейки плюс валюта. */
    record Money(long minor, Currency currency) {
        Money plus(Money o) {
            if (!currency.equals(o.currency)) throw new IllegalArgumentException("разные валюты: " + currency + " и " + o.currency);
            return new Money(Math.addExact(minor, o.minor), currency);          // overflow -> исключение
        }
        @Override public String toString() {
            int d = currency.getDefaultFractionDigits();
            return BigDecimal.valueOf(minor, d) + " " + currency;
        }
    }

    static String digits(String code) {
        try { return String.valueOf(Currency.getInstance(code).getDefaultFractionDigits()); }
        catch (IllegalArgumentException e) { return "IllegalArgumentException (JDK не знает код)"; }
    }

    public static void main(String[] args) {
        Currency rub = Currency.getInstance("RUB");

        System.out.println("--- 1. переполнение: оператор + и addExact");
        System.out.println("Long.MAX_VALUE + 1 = " + (Long.MAX_VALUE + 1));
        try { new Money(Long.MAX_VALUE, rub).plus(new Money(1, rub)); }
        catch (ArithmeticException e) { System.out.println("Money.plus: ArithmeticException: " + e.getMessage()); }

        System.out.println("--- 2. число знаков зависит от валюты");
        for (String c : new String[]{"RUB", "JPY", "KWD", "CLF", "UYW", "XAU", "XXX"}) System.out.println(c + ": " + digits(c));
        System.out.println("12345 минорных единиц RUB = " + new Money(12345, rub) + ", JPY = " + new Money(12345, Currency.getInstance("JPY")) + ", KWD = " + new Money(12345, Currency.getInstance("KWD")));

        System.out.println("--- 3. вместимость long");
        BigInteger wei = BigInteger.TEN.pow(18);
        System.out.println("ETH в Long.MAX_VALUE wei: " + BigInteger.valueOf(Long.MAX_VALUE).divide(wei) + " целых (чуть больше девяти)");
        System.out.println("максимум в копейках: " + BigDecimal.valueOf(Long.MAX_VALUE, 2) + " руб.");

        System.out.println("--- 4. комиссия 0,35 % с тысячи платежей по 1 рубль (100 копеек)");
        long perPaymentRounded = 0;
        BigDecimal rate = new BigDecimal("0.0035");
        for (int i = 0; i < 1000; i++) {
            BigDecimal feeKop = BigDecimal.valueOf(100).multiply(rate);                 // 0,35 копейки
            perPaymentRounded += feeKop.setScale(0, RoundingMode.HALF_UP).longValueExact();
        }
        BigDecimal total = BigDecimal.valueOf(100L * 1000).multiply(rate).setScale(0, RoundingMode.HALF_UP);
        System.out.println("округляя каждый платёж до копейки: " + perPaymentRounded + " коп.");
        System.out.println("округляя итог в конце:             " + total + " коп. (3,50 руб.)");
    }
}
