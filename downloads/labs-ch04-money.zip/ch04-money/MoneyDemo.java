import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class MoneyDemo {

    static final class CurrencyMismatchException extends RuntimeException {
        CurrencyMismatchException(Currency a, Currency b) { super("разные валюты: " + a + " и " + b); }
    }

    public record Money(BigDecimal amount, Currency currency) implements Comparable<Money> {

        public Money {
            Objects.requireNonNull(amount);
            Objects.requireNonNull(currency);
            int digits = currency.getDefaultFractionDigits();
            if (digits < 0) throw new IllegalArgumentException("Псевдовалюта: " + currency);
            amount = amount.setScale(digits, RoundingMode.UNNECESSARY);     // нормализация scale
        }

        public static Money of(String amount, String code) { return new Money(new BigDecimal(amount), Currency.getInstance(code)); }
        public static Money ofMinor(long minor, Currency c) { return new Money(BigDecimal.valueOf(minor, c.getDefaultFractionDigits()), c); }
        public static Money zero(Currency c) { return ofMinor(0, c); }

        public Money plus(Money o)  { check(o); return new Money(amount.add(o.amount), currency); }
        public Money minus(Money o) { check(o); return new Money(amount.subtract(o.amount), currency); }
        public Money negated()      { return new Money(amount.negate(), currency); }
        public Money abs()          { return new Money(amount.abs(), currency); }

        /** Умножение на безразмерный коэффициент (ставка, количество) с явным округлением. */
        public Money multiply(BigDecimal factor, RoundingMode mode) {
            return new Money(amount.multiply(factor).setScale(currency.getDefaultFractionDigits(), mode), currency);
        }

        public long toMinor() { return amount.movePointRight(currency.getDefaultFractionDigits()).longValueExact(); }

        public boolean isZero()     { return amount.signum() == 0; }
        public boolean isPositive() { return amount.signum() > 0; }
        public boolean isNegative() { return amount.signum() < 0; }

        @Override public int compareTo(Money o) { check(o); return amount.compareTo(o.amount); }

        private void check(Money o) { if (!currency.equals(o.currency)) throw new CurrencyMismatchException(currency, o.currency); }
        @Override public String toString() { return amount.toPlainString() + " " + currency; }
    }

    public static void main(String[] args) {
        System.out.println("--- 1. нормализация scale и equals");
        System.out.println(Money.of("100", "RUB") + " equals " + Money.of("100.00", "RUB") + ": " + Money.of("100", "RUB").equals(Money.of("100.00", "RUB")));
        Set<Money> set = new HashSet<>(Set.of(Money.of("100", "RUB")));
        System.out.println("HashSet.contains(100.00 RUB): " + set.contains(Money.of("100.00", "RUB")));

        System.out.println("--- 2. умножение с явным округлением");
        System.out.println("1234.56 RUB x 0.015 HALF_UP = " + Money.of("1234.56", "RUB").multiply(new BigDecimal("0.015"), RoundingMode.HALF_UP));

        System.out.println("--- 3. защита типа");
        try { Money.of("0.123", "RUB"); } catch (ArithmeticException e) { System.out.println("0.123 RUB: ArithmeticException: " + e.getMessage()); }
        try { Money.of("1", "RUB").plus(Money.of("1", "USD")); } catch (CurrencyMismatchException e) { System.out.println("RUB + USD: CurrencyMismatchException: " + e.getMessage()); }
        try { new Money(BigDecimal.ONE, Currency.getInstance("XXX")); } catch (IllegalArgumentException e) { System.out.println("XXX: IllegalArgumentException: " + e.getMessage()); }

        System.out.println("--- 4. минорные единицы и другие валюты");
        System.out.println("12345 копеек = " + Money.ofMinor(12345, Currency.getInstance("RUB")) + ", toMinor = " + Money.ofMinor(12345, Currency.getInstance("RUB")).toMinor());
        System.out.println("1000 иен     = " + Money.of("1000", "JPY") + " (знаков нет)");
        System.out.println("1.234 динара = " + Money.of("1.234", "KWD") + " (три знака)");
        System.out.println("100 RUB > 50.5 RUB: " + (Money.of("100", "RUB").compareTo(Money.of("50.5", "RUB")) > 0));
    }
}
