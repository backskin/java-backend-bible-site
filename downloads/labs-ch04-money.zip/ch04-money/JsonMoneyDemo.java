import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

import java.math.BigDecimal;
import java.util.Map;

/** Нужен jackson-databind 2.18.x (в Maven: com.fasterxml.jackson.core:jackson-databind:2.18.3). */
public class JsonMoneyDemo {

    public record TypedDto(BigDecimal amount, String currency) {}

    public record ToStringDto(@JsonSerialize(using = ToStringSerializer.class) BigDecimal amount, String currency) {}

    public record FormatDto(@JsonFormat(shape = JsonFormat.Shape.STRING) BigDecimal amount, String currency) {}

    public static void main(String[] args) throws Exception {
        ObjectMapper plain = new ObjectMapper();

        System.out.println("--- 1. чтение JSON с суммой 0.10");
        String json = "{\"amount\": 0.10, \"currency\": \"RUB\"}";
        System.out.println("в типизированное поле BigDecimal: " + plain.readValue(json, TypedDto.class).amount());
        Map<?, ?> asMap = plain.readValue(json, Map.class);
        System.out.println("в Map<String,Object>:             " + asMap.get("amount") + " (" + asMap.get("amount").getClass().getSimpleName() + ")");
        JsonNode node = plain.readTree(json);
        System.out.println("в JsonNode, по умолчанию:         " + node.get("amount") + " (" + node.get("amount").getClass().getSimpleName() + ")");
        ObjectMapper big = new ObjectMapper().enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
        Map<?, ?> bigMap = big.readValue(json, Map.class);
        System.out.println("в Map с USE_BIG_DECIMAL_FOR_FLOATS: " + bigMap.get("amount") + " (" + bigMap.get("amount").getClass().getSimpleName() + ")");

        System.out.println("--- 2. запись суммы строкой");
        BigDecimal thousand = new BigDecimal("1E+3");
        System.out.println("ToStringSerializer, сумма 1234.56: " + plain.writeValueAsString(new ToStringDto(new BigDecimal("1234.56"), "RUB")));
        System.out.println("ToStringSerializer, сумма 1E+3:    " + plain.writeValueAsString(new ToStringDto(thousand, "RUB")));
        ObjectMapper asPlain = new ObjectMapper().enable(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN);
        System.out.println("@JsonFormat(STRING) + AS_PLAIN, 1E+3: " + asPlain.writeValueAsString(new FormatDto(thousand, "RUB")));
        System.out.println("число без AS_PLAIN, 1E+3:          " + plain.writeValueAsString(new TypedDto(thousand, "RUB")));
    }
}
