import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class BdDivideDemo {

    static void p(String label, Object v) { System.out.println(String.format("%-52s %s", label, v)); }

    static String tryDivide(String a, String b) {
        try { return new BigDecimal(a).divide(new BigDecimal(b)).toString(); }
        catch (ArithmeticException e) { return "ArithmeticException: " + e.getMessage(); }
    }

    public static void main(String[] args) {
        System.out.println("--- 1. divide без режима: зависит от данных");
        p("10 / 2", tryDivide("10", "2"));
        p("1 / 8", tryDivide("1", "8"));
        p("10 / 3", tryDivide("10", "3"));

        System.out.println("--- 2. scale результата берётся от делимого");
        p("100.00 / 3 (RoundingMode.HALF_UP)", new BigDecimal("100.00").divide(new BigDecimal("3"), RoundingMode.HALF_UP));
        p("100 / 3 (RoundingMode.HALF_UP)", new BigDecimal("100").divide(new BigDecimal("3"), RoundingMode.HALF_UP));
        p("100 / 3 (явный scale 2, HALF_UP)", new BigDecimal("100").divide(new BigDecimal("3"), 2, RoundingMode.HALF_UP));

        System.out.println("--- 3. MathContext считает значащие цифры");
        p("new MathContext(2) для 1234.56", new BigDecimal("1234.56").round(new MathContext(2)));
        p("MathContext.DECIMAL128: 1 / 3", BigDecimal.ONE.divide(new BigDecimal("3"), MathContext.DECIMAL128));
        p("DECIMAL128 с последующим setScale(2, HALF_EVEN)", BigDecimal.ONE.divide(new BigDecimal("3"), MathContext.DECIMAL128).setScale(2, RoundingMode.HALF_EVEN));
    }
}
