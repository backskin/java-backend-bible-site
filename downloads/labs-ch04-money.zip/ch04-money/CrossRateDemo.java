import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Random;

/**
 * Кросс-курс EUR/USD, округлённый до 4 и до 2 знаков, против точного расчёта через EUR/RUB.
 * Запуск: java CrossRateDemo.java (JDK 21, без зависимостей). Курсы учебные.
 */
public class CrossRateDemo {

    public static void main(String[] args) {
        BigDecimal usdRub = new BigDecimal("92.4731");
        BigDecimal eurRub = new BigDecimal("101.2864");
        BigDecimal eurUsdExact = eurRub.divide(usdRub, MathContext.DECIMAL128);     // 1.09530...
        BigDecimal eurUsd4 = eurUsdExact.setScale(4, RoundingMode.HALF_UP);
        BigDecimal eurUsd2 = eurUsdExact.setScale(2, RoundingMode.HALF_UP);
        System.out.println("EUR/USD точный " + eurUsdExact.setScale(10, RoundingMode.HALF_UP)
                + ", до 4 знаков " + eurUsd4 + ", до 2 знаков " + eurUsd2);

        Random r = new Random(42);
        int n = 20_000, diff4 = 0, diff2 = 0, diffFloat = 0;
        BigDecimal max4 = BigDecimal.ZERO, max2 = BigDecimal.ZERO;
        for (int i = 0; i < n; i++) {
            BigDecimal eur = BigDecimal.valueOf(r.nextInt(5_000_000) + 1, 2);             // 0,01 .. 50 000,00 EUR
            BigDecimal exact = eur.multiply(eurRub).setScale(2, RoundingMode.HALF_UP);      // прямой курс, один раз в конце
            BigDecimal via4 = eur.multiply(eurUsd4).multiply(usdRub).setScale(2, RoundingMode.HALF_UP);
            BigDecimal via2 = eur.multiply(eurUsd2).multiply(usdRub).setScale(2, RoundingMode.HALF_UP);
            if (via4.compareTo(exact) != 0) { diff4++; max4 = max4.max(via4.subtract(exact).abs()); }
            if (via2.compareTo(exact) != 0) { diff2++; max2 = max2.max(via2.subtract(exact).abs()); }
            if (i < 5_000) {
                double viaDouble = Math.round(eur.doubleValue() * 101.2864 * 100.0) / 100.0;   // расчёт во double с округлением
                if (BigDecimal.valueOf(viaDouble).setScale(2, RoundingMode.HALF_UP).compareTo(exact) != 0) diffFloat++;
            }
        }
        System.out.println("кросс-курс до 4 знаков: расхождений " + diff4 + " из " + n + ", наибольшее " + max4);
        System.out.println("кросс-курс до 2 знаков: расхождений " + diff2 + " из " + n + ", наибольшее " + max2);
        System.out.println("double с округлением до копейки: расхождений " + diffFloat + " из 5000");
    }
}
