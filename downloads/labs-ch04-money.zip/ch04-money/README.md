# Деньги в Java: double против BigDecimal, округление, деление без потери копейки, курсы, сверка

Стенд к главе 04, разделы 6–8. Каждая программа - один файл без зависимостей, который можно вставить в пустой проект целиком: `DoubleErrorDemo` (ошибки `double` на суммах), `BdCtorDemo`, `BdEqualsDemo`, `BdDivideDemo`, `RoundingDemo`, `ChainRoundingDemo` (устройство и ловушки `BigDecimal`), `MoneyDemo`, `MinorUnitsDemo`, `AllocateDemo` (модель денег с валютой, копейки в `long`, деление на части), `CrossRateDemo` и `ReconcileDemo` (курсы и сверка построчного и итогового округления), `JsonMoneyDemo`, `BdPerf` (грубый замер). `moneta/` - то же на JSR 354 (`org.javamoney:moneta` 1.4.5). Выводы автора - `s04-<Класс>-jdk21.txt` и `-jdk25.txt`, `s04-moneta.txt`.

## Что нужно

- JDK 21 (и 25 для сравнения); для `moneta/` - Maven.

## Запуск

Любая программа запускается из исходника:

```bash
java -Dstdout.encoding=UTF-8 AllocateDemo.java
```

В IDEA на каждую программу есть конфигурация `java <Класс>.java`. Moneta:

```bash
cd moneta && mvn -q compile exec:java
```

## Что должно получиться

Вывод совпадает с файлами `*.txt` на обоих JDK, кроме `BdPerf` (время зависит от машины). Числа в главе взяты из этих файлов: `100.00 RUB на 3` дает `33.34, 33.33, 33.33`, построчное округление комиссии и округление по итогу расходятся на копейки.
