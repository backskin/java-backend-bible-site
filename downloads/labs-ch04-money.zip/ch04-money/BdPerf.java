import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Грубый замер стоимости операций BigDecimal против long и double (не JMH: прогрев и среднее по 10 млн операций).
 * Плюс поведение stripTrailingZeros и toString. Запуск: java BdPerf.java
 */
public class BdPerf {
    public static void main(String[] args) {
        System.out.println("java.version=" + System.getProperty("java.version"));
        System.out.println(new BigDecimal("2.5000").setScale(2, RoundingMode.HALF_UP) + " " + new BigDecimal("2.5000").stripTrailingZeros()
                + " " + new BigDecimal("100.00").stripTrailingZeros() + " " + new BigDecimal("100.00").stripTrailingZeros().toPlainString()
                + " scale=" + new BigDecimal("100.00").stripTrailingZeros().scale()
                + " " + new BigDecimal("0.0000001") + " " + new BigDecimal("0.0000001").toPlainString() + " " + new BigDecimal("0.000001")
                + " ZERO.strip=" + new BigDecimal("0.000").stripTrailingZeros());
        System.out.println("1E+3 unscaled=" + new BigDecimal("1E+3").unscaledValue() + " scale=" + new BigDecimal("1E+3").scale() + " precision(12.345)=" + new BigDecimal("12.345").precision());
        int n = 10_000_000;
        long[] la = new long[1024];
        double[] da = new double[1024];
        BigDecimal[] ba = new BigDecimal[1024];
        String[] sa = new String[1024];
        for (int i = 0; i < 1024; i++) { la[i] = 1000 + i * 37L; da[i] = la[i] / 100.0; ba[i] = BigDecimal.valueOf(la[i], 2); sa[i] = ba[i].toPlainString(); }
        BigDecimal three = BigDecimal.valueOf(3), rate = new BigDecimal("0.015");
        for (int w = 0; w < 3; w++) {
            long t0 = System.nanoTime(); long ls = 0; for (int i = 0; i < n; i++) ls += la[i & 1023];
            long t1 = System.nanoTime(); double ds = 0; for (int i = 0; i < n; i++) ds += da[i & 1023];
            long t2 = System.nanoTime(); BigDecimal bs = BigDecimal.ZERO; for (int i = 0; i < n; i++) bs = bs.add(ba[i & 1023]);
            long t3 = System.nanoTime(); BigDecimal bm = BigDecimal.ZERO; int chk = 0; for (int i = 0; i < n; i++) { bm = ba[i \& 1023].multiply(rate); chk ^= bm.scale(); }
            long t4 = System.nanoTime(); BigDecimal bd = BigDecimal.ZERO; for (int i = 0; i < n; i++) { bd = ba[i \& 1023].divide(three, 2, RoundingMode.HALF_EVEN); chk ^= bd.signum(); }
            long t5 = System.nanoTime(); BigDecimal bp = BigDecimal.ZERO; for (int i = 0; i < n; i++) { bp = new BigDecimal(sa[i \& 1023]); chk ^= bp.scale(); }   // каждый результат потребляется (chk), чтобы JIT не выбросил работу
            long t6 = System.nanoTime();
            if (w == 2) System.out.printf("на операцию: long add %.1f нс, double add %.1f нс, BigDecimal add %.1f нс, multiply %.1f нс, divide(scale,mode) %.1f нс, new BigDecimal(String) %.1f нс (%d %.0f %s %s %s %s)%n",
                    (t1 - t0) / (double) n, (t2 - t1) / (double) n, (t3 - t2) / (double) n, (t4 - t3) / (double) n, (t5 - t4) / (double) n, (t6 - t5) / (double) n,
                    ls % 7, ds % 7, bs.signum(), bm.signum(), bd.signum(), bp.signum() + chk);
        }
    }
}
