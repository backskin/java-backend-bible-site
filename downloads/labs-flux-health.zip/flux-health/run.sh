#!/usr/bin/env bash
# Разд. 13.1 гл. 11: приложение WebFlux с -XX:ActiveProcessorCount=4 (четыре потока цикла событий),
# 16 одновременных запросов /limits блокируют каждый поток на 2 с; во время нагрузки меряем /actuator/health/liveness
# на отдельном порту управления. Вывод — s11-health.txt.
set -euo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
for port in 18120 18121; do
  pid=$(netstat -ano 2>/dev/null | awk -v p=":$port" '$2 ~ p"$" && $4=="LISTENING" {print $5; exit}')
  [ -n "${pid:-}" ] && taskkill //F //PID "$pid" >/dev/null 2>&1 || true
done
"$J" -XX:ActiveProcessorCount=4 -jar target/flux-health-1.0.0.jar > app.log 2>&1 &
APP=$!
until curl -s -o /dev/null http://127.0.0.1:18121/actuator/health/liveness; do sleep 1; done
{
  echo "== 13.1. WebFlux, 4 потока цикла событий, Actuator на отдельном порту; 16 запросов /limits по 2 с блокировки"
  "$J" -Dstdout.encoding=UTF-8 Probe.java 16
  echo "-- то же, 3 блокирующих запроса (меньше, чем потоков цикла событий)"
  "$J" -Dstdout.encoding=UTF-8 Probe.java 3
  echo "-- потоки Reactor Netty в процессе (jcmd Thread.print): оба сервера — основной и порт управления"
  JC="$(dirname "$J")/jcmd"; WPID=$("$JC" -l | awk '/flux-health/ {print $1; exit}')
  "$JC" "$WPID" Thread.print 2>/dev/null | grep -o '"reactor-http-[a-z]*-[0-9]*"' | sort -u | paste -sd' ' -
} | tee s11-health.txt
kill $APP
