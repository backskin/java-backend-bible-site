package dev.team.health;

import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * Разд. 13.1 гл. 11: обработчик /limits блокирует поток цикла событий на 2 с (как JDBC-вызов в лямбде flatMap),
 * /whoami сообщает, на каком потоке обслужен запрос. Actuator — на отдельном порту (management.server.port).
 */
@SpringBootApplication
@RestController
public class HealthApp {

    @GetMapping("/limits")
    Mono<Map<String, String>> limits() {
        return Mono.just("счёт").flatMap(a -> Mono.just(legacyCheck(a)));   // блокировка прямо на цикле событий
    }

    @GetMapping("/whoami")
    Mono<String> whoami() { return Mono.fromSupplier(() -> Thread.currentThread().getName()); }

    static Map<String, String> legacyCheck(String a) {
        try { Thread.sleep(2000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return Map.of("account", a, "thread", Thread.currentThread().getName());
    }

    public static void main(String[] args) { SpringApplication.run(HealthApp.class, args); }
}
