# Приватность данных сервиса на правах PostgreSQL

Стенд к главе 33, раздел 6.1. Встроенный PostgreSQL из `io.zonky.test:embedded-postgres:2.0.7` (на Windows - 14.10), JDK 21.

```bash
mvn compile exec:java
```

`PrivacyDemo` создает две схемы (`payments`, `limits`) и две роли с правами только на свою схему, затем по шагам выдает и отзывает права и печатает результат каждого запроса. Вывод, приведенный в главе: `s33-privacy.txt`.
