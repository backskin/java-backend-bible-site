import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Приватность данных сервиса на уровне прав PostgreSQL 15: две схемы, две роли, что видно и чего не видно.
 * Зависимости Maven: io.zonky.test:embedded-postgres:2.0.7, бинарники сервера под вашу ОС (io.zonky.test.postgres:embedded-postgres-binaries-*), org.postgresql:postgresql.
 * Запуск: main.
 */
public class PrivacyDemo {

    static final String SCRIPT = """
            SELECT version();
            CREATE SCHEMA payments;
            CREATE SCHEMA limits;
            CREATE TABLE payments.payment(id int PRIMARY KEY, client text, amount int);
            CREATE TABLE limits.client_limit(client text PRIMARY KEY, daily int);
            INSERT INTO payments.payment VALUES (1, 'c-1', 500);
            INSERT INTO limits.client_limit VALUES ('c-1', 1000);
            CREATE ROLE svc_payments LOGIN PASSWORD 'x';
            CREATE ROLE svc_limits LOGIN PASSWORD 'x';
            GRANT USAGE ON SCHEMA payments TO svc_payments;
            GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA payments TO svc_payments;
            GRANT USAGE ON SCHEMA limits TO svc_limits;
            GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA limits TO svc_limits;
            SET ROLE svc_payments;
            SELECT count(*) AS own_table FROM payments.payment;
            SELECT count(*) AS foreign_table FROM limits.client_limit;
            RESET ROLE;
            SET ROLE svc_limits;
            CREATE VIEW limits.paid_view AS SELECT * FROM payments.payment;
            RESET ROLE;
            GRANT SELECT ON payments.payment TO svc_limits;
            SET ROLE svc_limits;
            SELECT count(*) AS only_table_grant FROM payments.payment;
            RESET ROLE;
            GRANT USAGE ON SCHEMA payments TO svc_limits;
            SET ROLE svc_limits;
            SELECT count(*) AS table_and_schema_grant FROM payments.payment;
            RESET ROLE;
            REVOKE SELECT ON payments.payment FROM svc_limits;
            SET ROLE svc_limits;
            SELECT count(*) AS schema_grant_only FROM payments.payment;
            """;

    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.builder().start();
             Connection c = pg.getPostgresDatabase().getConnection()) {
            for (String stmt : SCRIPT.split(";\\s*\\n")) {
                System.out.println("> " + stmt.strip());
                try (Statement st = c.createStatement()) {
                    if (st.execute(stmt)) {
                        try (ResultSet r = st.getResultSet()) {
                            while (r.next()) System.out.println("  " + r.getMetaData().getColumnLabel(1) + " = " + r.getString(1));
                        }
                    }
                } catch (SQLException e) {
                    System.out.println("  ОШИБКА: " + e.getMessage().replace("\n", " "));
                }
            }
        }
    }
}
