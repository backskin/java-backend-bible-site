package s15

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume

private val t0 = System.nanoTime()
private fun ms() = (System.nanoTime() - t0) / 1_000_000
private fun log(s: String) = println("[%5d мс] %s".format(ms(), s))
private fun section(t: String) = println("\n== $t")

/** Соединение с внешней системой, которое нужно закрыть. */
class Conn(val id: Int) : AutoCloseable {
    override fun close() = log("соединение $id закрыто")
}

/** Источник котировок с обратными вызовами. */
class QuoteSource {
    var listener: ((Int) -> Unit)? = null
    fun subscribe(l: (Int) -> Unit) { listener = l; log("подписка на источник") }
    fun unsubscribe() { listener = null; log("отписка от источника") }
}

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class, DelicateCoroutinesApi::class)
fun main() = runBlocking {
    section("1 режимы CoroutineStart: отмена до старта (однопоточный runBlocking)")
    for (mode in listOf(CoroutineStart.DEFAULT, CoroutineStart.ATOMIC)) {
        val j = launch(start = mode) {
            println("  $mode: тело началось, isActive=$isActive")
            try { delay(100); println("  $mode: после delay") } catch (e: CancellationException) { println("  $mode: delay бросил отмену") }
        }
        j.cancel(); j.join()
        println("  $mode: отменена до старта, isCancelled=${j.isCancelled}")
    }
    val lazyJob = launch(start = CoroutineStart.LAZY) { println("  LAZY: тело началось") }
    delay(50)
    println("  LAZY: через 50 мс isActive=${lazyJob.isActive}, isCompleted=${lazyJob.isCompleted}")
    lazyJob.join()
    println("  LAZY: после join isCompleted=${lazyJob.isCompleted}")
    withContext(Dispatchers.Default) {
        val caller = Thread.currentThread().name
        val order = mutableListOf<String>()
        launch(Dispatchers.IO, start = CoroutineStart.UNDISPATCHED) {
            order += "тело до приостановки на ${if (Thread.currentThread().name == caller) "потоке вызывающего" else "другом потоке"}"
            delay(10)
            order += "тело после приостановки на ${if (Thread.currentThread().name == caller) "потоке вызывающего" else "другом потоке"}"
        }
        order += "вызывающий код после launch"
        delay(50)
        println("  UNDISPATCHED: $order")
        val order2 = mutableListOf<String>()
        launch(Dispatchers.IO) { order2 += "тело" }
        order2 += "вызывающий код после launch"
        delay(50)
        println("  DEFAULT: $order2")
    }

    section("2 состояние Completing: тело закончилось, ребенок работает")
    val parent = launch {
        launch { delay(200); log("ребенок закончил") }
        log("тело родителя закончилось")
    }
    delay(50)
    println("  через 50 мс: isActive=${parent.isActive}, isCompleted=${parent.isCompleted}")
    parent.join()
    println("  после join: isCompleted=${parent.isCompleted}")

    section("3 канал RENDEZVOUS: send ждет receive")
    val rv = Channel<Int>()
    launch { for (i in 1..2) { log("send $i начат"); rv.send(i); log("send $i завершен") } ; rv.close() }
    delay(300); log("receive ${rv.receive()}"); delay(300); log("receive ${rv.receive()}")
    println("  после close: ${rv.receiveCatching()}")

    section("4 ёмкость по умолчанию BUFFERED и UNLIMITED")
    val buf = Channel<Int>(Channel.BUFFERED)
    var ok = 0; while (buf.trySend(ok).isSuccess) ok++
    println("  BUFFERED: без получателя принято $ok элементов, следующий trySend: ${buf.trySend(-1)}")
    val unl = Channel<Int>(Channel.UNLIMITED)
    repeat(100_000) { unl.trySend(it) }
    println("  UNLIMITED: принято 100000 без получателя, isEmpty=${unl.isEmpty}")

    section("5 CONFLATED: получатель видит последнее")
    val conf = Channel<Int>(Channel.CONFLATED)
    for (i in 1..5) conf.send(i)
    println("  отправлены 1..5, получено ${conf.receive()}, tryReceive дальше: ${conf.tryReceive()}")

    section("6 for по каналу без close висит")
    val notClosed = Channel<Int>(2); notClosed.send(1); notClosed.send(2)
    val got = mutableListOf<Int>()
    val r = withTimeoutOrNull(300) { for (x in notClosed) got += x; "цикл закончился" }
    println("  получено $got, результат цикла через 300 мс: $r")

    section("7 produce и разветвление на трех обработчиков")
    val payments = produce(capacity = 10) { for (i in 1..30) send(i) }
    val perWorker = (1..3).map { w ->
        async(Dispatchers.Default) { var n = 0; var sum = 0; for (p in payments) { n++; sum += p; delay(1) }; Triple(w, n, sum) }
    }.awaitAll()
    perWorker.forEach { (w, n, s) -> println("  обработчик $w: $n платежей, сумма номеров $s") }
    println("  всего ${perWorker.sumOf { it.second }}, сумма ${perWorker.sumOf { it.third }} (у 1..30 сумма 465), канал закрыт: ${payments.isClosedForReceive}")
    val shared = MutableSharedFlow<Int>()
    val subs = (1..3).map { w -> async { shared.take(3).toList() } }
    yield(); delay(10)
    for (i in 1..3) shared.emit(i)
    println("  SharedFlow для сравнения: ${subs.awaitAll()}")

    section("8 onUndeliveredElement при отмене канала")
    val conns = Channel<Conn>(5) { it.close() }
    for (i in 1..3) conns.send(Conn(i))
    conns.cancel()

    section("9 callbackFlow без awaitClose")
    val bad = runCatching { callbackFlow<Int> { trySend(1) }.toList() }
    println("  ${bad.exceptionOrNull()?.javaClass?.simpleName}: ${bad.exceptionOrNull()?.message}")

    section("10 callbackFlow c awaitClose и отменой сборщика")
    val src = QuoteSource()
    val quotes = callbackFlow {
        src.subscribe { q -> trySend(q) }
        awaitClose { src.unsubscribe() }
    }
    val job = launch { quotes.take(2).collect { log("котировка $it") } }
    delay(20); src.listener?.invoke(101); src.listener?.invoke(102); src.listener?.invoke(103)
    job.join()
    println("  слушатель после завершения сборщика: ${src.listener}")

    section("11 trySend в callbackFlow при полном буфере")
    val sent = AtomicInteger(); val lost = AtomicInteger()
    val burst = callbackFlow {
        repeat(100) { if (trySend(it).isSuccess) sent.incrementAndGet() else lost.incrementAndGet() }
        close(); awaitClose { }
    }
    val received = burst.toList().size
    println("  trySend: принято ${sent.get()}, потеряно ${lost.get()}, получено сборщиком $received")

    section("12 channelFlow: send из нескольких корутин")
    val merged = channelFlow {
        launch { repeat(3) { delay(30); send("АБС-$it") } }
        launch { repeat(3) { delay(45); send("антифрод-$it") } }
    }.toList()
    println("  $merged")

    section("13 flatMapMerge: параллелизм по умолчанию и заданный")
    for (conc in listOf<Int?>(null, 4)) {
        val now = AtomicInteger(); val max = AtomicInteger()
        val f = (1..40).asFlow()
        val start = System.nanoTime()
        val inner: suspend (Int) -> Flow<Int> = { i -> flow { val c = now.incrementAndGet(); max.accumulateAndGet(c) { a, b -> maxOf(a, b) }; delay(50); now.decrementAndGet(); emit(i) } }
        val n = (if (conc == null) f.flatMapMerge { inner(it) } else f.flatMapMerge(conc) { inner(it) }).count()
        println("  concurrency=${conc ?: "по умолчанию"}: элементов $n, одновременно не больше ${max.get()}, ${(System.nanoTime() - start) / 1_000_000} мс")
    }
    val latest = flow { emit("40"); delay(20); emit("408"); delay(20); emit("40817") }
        .flatMapLatest { prefix -> flow { log("поиск по $prefix начат"); delay(50); emit("результат для $prefix") } }
        .toList()
    println("  flatMapLatest: $latest")

    section("14 SharedFlow.tryEmit")
    val noSubs = MutableSharedFlow<Int>()
    println("  без подписчиков, replay=0: tryEmit=${noSubs.tryEmit(1)}")
    val busy = MutableSharedFlow<Int>()
    val slow = launch { busy.collect { delay(1000) } }
    delay(10)
    println("  есть подписчик, буфер 0: первый tryEmit=${busy.tryEmit(1)}, второй tryEmit=${busy.tryEmit(2)}")
    slow.cancel()

    section("15 suspendCancellableCoroutine: ресурс, пришедший после отмены")
    var callback: ((Conn) -> Unit)? = null
    val waiter = launch {
        suspendCancellableCoroutine<Conn> { cont ->
            callback = { c -> cont.resume(c) { _, res, _ -> log("onCancellation: закрываю ресурс"); res.close() } }
        }
    }
    delay(20); waiter.cancel(); delay(20)
    log("колбэк пришел после отмены")
    callback?.invoke(Conn(7))
    waiter.join()

    section("16 Reactor flatMap для сравнения: параллелизм по умолчанию")
    val active = AtomicInteger(); val peak = AtomicInteger()
    reactor.core.publisher.Flux.range(1, 600).flatMap { i ->
        reactor.core.publisher.Mono.fromCallable { peak.accumulateAndGet(active.incrementAndGet()) { a, b -> maxOf(a, b) }; i }
            .delayElement(java.time.Duration.ofMillis(50)).doOnNext { active.decrementAndGet() }
    }.blockLast()
    println("  Flux.flatMap без параметра: одновременно не больше ${peak.get()}")
}
