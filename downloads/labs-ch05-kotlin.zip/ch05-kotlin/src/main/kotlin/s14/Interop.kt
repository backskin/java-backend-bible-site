@file:JvmName("Interop")

package s14

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.future.future
import java.io.IOException
import java.math.BigDecimal
import java.nio.file.Files
import java.nio.file.Path
import java.util.concurrent.CompletableFuture

/** Тариф комиссии: companion с разными способами публикации членов для Java. */
class FeeRule(val percent: BigDecimal) {
    companion object {
        /** Без аннотаций: из Java доступен как FeeRule.Companion.parse. */
        fun parse(v: String) = FeeRule(BigDecimal(v))

        /** С @JvmStatic: из Java доступен как FeeRule.of. */
        @JvmStatic
        fun of(v: String) = FeeRule(BigDecimal(v))

        /** С @JvmField: публичное статическое поле без метода чтения. */
        @JvmField
        val ZERO = FeeRule(BigDecimal.ZERO)

        /** Обычное свойство: из Java доступно через FeeRule.Companion.getDEFAULT(). */
        val DEFAULT = FeeRule(BigDecimal.ONE)

        /** Константа времени компиляции: статическое final-поле. */
        const val CURRENCY = "RUB"
    }

    override fun toString() = "FeeRule($percent)"
}

/** Читает реестр и объявляет IOException для Java. */
@Throws(IOException::class)
fun readRegistry(p: Path): String = Files.readString(p)

/** Читает реестр без @Throws: Java не знает, что метод бросает IOException. */
fun readRegistryNoThrows(p: Path): String = Files.readString(p)

/** Функция, которая никогда не возвращает управление. */
fun fail(msg: String): Nothing = throw IllegalStateException(msg)

/** Принимает функциональный тип Kotlin с результатом Unit. */
fun onEvent(handler: (String) -> Unit) = handler("payment-1")

/** Функциональный интерфейс Kotlin: Java и Kotlin передают в него обычную лямбду. */
fun interface PaymentListener {
    fun onPayment(id: String)
}

/** Обычный интерфейс Kotlin с одним методом, без fun. */
interface PlainListener {
    fun onPayment(id: String)
}

/** Принимает функциональный интерфейс. */
fun onPayment(l: PaymentListener) = l.onPayment("payment-2")

/** Две функции с одинаковой сигнатурой после стирания типов различаются через @JvmName. */
@JvmName("totalKop")
fun total(xs: List<Long>): Long = xs.sum()

/** Сумма в рублях. */
@JvmName("totalRub")
fun total(xs: List<BigDecimal>): BigDecimal = xs.fold(BigDecimal.ZERO, BigDecimal::add)

/** Перевод: data class со значением по умолчанию. */
data class Transfer(val from: String, val to: String, val amountKop: Long, val currency: String = "RUB")

/** Функция с reified-параметром. */
inline fun <reified T> typeName(): String = T::class.java.simpleName

/** Лимит по счету: suspend-функция. */
suspend fun limit(account: String): Long {
    delay(10)
    return 50_000
}

private val bridgeScope = CoroutineScope(Dispatchers.Default)

/** Мост для Java: suspend-функция через CompletableFuture. */
fun limitAsync(account: String): CompletableFuture<Long> = bridgeScope.future { limit(account) }

/** Интерфейс тарифа с методом, у которого есть тело. */
interface Tariff {
    fun base(): Long
    fun withFee(): Long = base() + 30
}

/** Список из трех элементов. */
fun registryCodes(): List<String> = listOf("A01", "B02", "C03")

/** Список после map. */
fun mappedCodes(): List<String> = listOf("A01", "B02").map { it.lowercase() }

/** Список из одного элемента. */
fun singleCode(): List<String> = listOf("A01")

/** Аннотация для опыта с companion: видна во время выполнения. */
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FUNCTION, AnnotationTarget.FIELD, AnnotationTarget.PROPERTY)
annotation class Marker

/** Класс, похожий на интеграционный тест: члены companion для фреймворка, который ищет статику. */
class IntegrationLike {
    companion object {
        @Marker
        fun props(): String = "без @JvmStatic"

        @Marker
        @JvmStatic
        fun propsStatic(): String = "с @JvmStatic"
    }
}
