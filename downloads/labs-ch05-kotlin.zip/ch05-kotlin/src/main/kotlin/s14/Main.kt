package s14

import dev.team.interop.JavaSide
import dev.team.legacy.QueueDriver
import s02.Kopecks
import java.io.ByteArrayOutputStream
import java.io.ObjectOutputStream
import java.lang.reflect.Modifier
import java.util.concurrent.Executors

private fun section(t: String) = println("\n== $t")

/** Перевод с суммой и комиссией одного типа. */
fun transfer(amount: Kopecks, fee: Kopecks): String = "сумма=${amount.value}, комиссия=${fee.value}"

private fun serializable(x: Any): String = runCatching {
    ObjectOutputStream(ByteArrayOutputStream()).use { it.writeObject(x) }; "сериализуется"
}.getOrElse { it.javaClass.simpleName + ": " + it.message }

fun main() {
    section("1 Java вызывает Kotlin")
    JavaSide.run()

    section("2 SAM-преобразование и перегрузки ExecutorService.submit")
    val ex = Executors.newSingleThreadExecutor()
    val withValue = ex.submit { 42 }
    val withoutValue = ex.submit { println("  тело без результата") }
    println("submit { 42 }: get()=${withValue.get()}")
    println("submit { println() }: get()=${withoutValue.get()}")
    val explicit = ex.submit(java.util.concurrent.Callable { 42 })
    println("submit(Callable { 42 }): get()=${explicit.get()}")
    ex.shutdown()

    section("3 лямбды и Java-сериализация")
    val plain: (Long) -> Long = { it + 30 }
    val marked: (Long) -> Long = @JvmSerializableLambda { it + 30 }
    println("обычная лямбда: ${serializable(plain)}, класс ${plain.javaClass.name}")
    println("@JvmSerializableLambda: ${serializable(marked)}")

    section("4 платформенный тип в обратном вызове Java")
    val r = runCatching { QueueDriver().subscribe { body -> println("  длина тела ${body.length}") } }
    println("исключение: ${r.exceptionOrNull()}")
    val r2 = runCatching { QueueDriver.fill(listOf("A01", "B02")) }
    println("Java дописывает в listOf: ${r2.exceptionOrNull()?.javaClass?.simpleName ?: "ok"}")
    val copy = ArrayList(listOf("A01", "B02")); QueueDriver.fill(copy)
    println("Java дописывает в ArrayList(...): $copy")

    section("5 value class не защищает от перестановки аргументов одного типа")
    val amount = Kopecks(150_00); val fee = Kopecks(30_00)
    println("transfer(fee, amount) скомпилирован: ${transfer(fee, amount)}")

    section("6 companion и статика для фреймворков")
    for (m in IntegrationLike::class.java.declaredMethods.sortedBy { it.name }) {
        println("IntegrationLike.${m.name}: static=${Modifier.isStatic(m.modifiers)}, @Marker=${m.isAnnotationPresent(Marker::class.java)}")
    }
}
