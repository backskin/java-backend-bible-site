package s08

import app.cash.turbine.test
import io.mockk.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.*
import kotlin.time.Duration.Companion.hours
import kotlin.time.Duration.Companion.seconds

private fun section(t: String) = println("\n== $t")

/** Шлюз эквайринга: обычный final-класс Kotlin. */
class AcquiringGateway {
    suspend fun charge(pan: String, kop: Long): String { delay(200); return "auth-$pan" }
    fun ping(): Boolean = true
}

/** Сервис с повтором через секунду; диспетчер внедряется, чтобы тест мог подменить время. */
class ChargeService(private val gw: AcquiringGateway, private val io: CoroutineDispatcher = Dispatchers.IO) {
    suspend fun chargeWithRetry(pan: String, kop: Long): String = withContext(io) {
        repeat(2) {
            try { return@withContext gw.charge(pan, kop) } catch (e: IllegalStateException) { delay(1.seconds) }
        }
        gw.charge(pan, kop)
    }
}

/** Уведомления клиенту: метод без результата и метод с результатом. */
class Notifier {
    fun send(account: String, text: String) { println("  настоящая отправка: $text") }
    fun quota(account: String): Int = 100
}

/** Калькулятор комиссии: настоящий класс для частичной подмены. */
open class FeeCalculator {
    open fun rate(account: String): Long = 15
    open fun fee(account: String, kop: Long): Long = kop * rate(account) / 1000
}

/** Флаги функций: object с глобальным состоянием. */
object FeatureFlags {
    fun enabled(name: String): Boolean = false
}

/** Сервис платежа: повтор через секунду и уведомление. */
class PayService(private val gw: AcquiringGateway, private val notifier: Notifier) {
    suspend fun pay(pan: String, kop: Long): String {
        val auth = try { gw.charge(pan, kop) } catch (e: IllegalStateException) { delay(1.seconds); gw.charge(pan, kop) }
        notifier.send(pan, "оплачено $kop")
        return auth
    }
}

fun main() {
    section("1 виртуальное время")
    runTest {
        val t = testScheduler.currentTime
        delay(1.hours)
        println("delay(1.hours): виртуальных мс ${testScheduler.currentTime - t}")
    }
    val wall = System.nanoTime()
    runTest { withContext(Dispatchers.Default) { delay(1.seconds) } }
    println("delay(1 с) на Dispatchers.Default внутри runTest: реальных мс ${(System.nanoTime() - wall) / 1_000_000}")

    section("2 дети не стартуют без точки приостановки")
    val r = runCatching {
        runTest {
            var x = 0
            launch { x++ }; launch { x++ }
            check(x == 2) { "x=$x до точки приостановки" }
        }
    }
    println("без yield: ${r.exceptionOrNull()?.message}")
    runTest { var x = 0; launch { x++ }; launch { x++ }; yield(); println("после yield: x=$x") }

    section("3 MockK: final-класс, coEvery и виртуальное время повторов")
    runTest {
        val gw = mockk<AcquiringGateway>()
        coEvery { gw.charge(any(), any()) } throws IllegalStateException("таймаут") andThenThrows IllegalStateException("таймаут") andThen "auth-1"
        val svc = ChargeService(gw, StandardTestDispatcher(testScheduler))
        val res = svc.chargeWithRetry("2200", 100)
        println("результат=$res, виртуальных мс=${testScheduler.currentTime}")
        coVerify(exactly = 3) { gw.charge("2200", 100) }
        println("coVerify(exactly = 3) прошел")
    }
    val strict = mockk<AcquiringGateway>()
    println("строгий мок без настройки: ${runCatching { strict.ping() }.exceptionOrNull()?.let { it::class.simpleName + ": " + it.message }}")
    val relaxed = mockk<AcquiringGateway>(relaxed = true)
    println("relaxed-мок: ping()=${relaxed.ping()}")

    section("4 Turbine и StateFlow")
    runTest {
        val limit = MutableStateFlow(0)
        limit.test {
            println("первое значение: ${awaitItem()}")
            limit.value = 1; limit.value = 2; limit.value = 3
            println("следующее значение: ${awaitItem()}")
            cancelAndIgnoreRemainingEvents()
        }
    }
    runTest(UnconfinedTestDispatcher()) {
        val limit = MutableStateFlow(0)
        limit.test {
            val got = mutableListOf(awaitItem())
            limit.value = 1; limit.value = 2; limit.value = 3
            repeat(3) { got += awaitItem() }
            println("UnconfinedTestDispatcher: $got")
            cancelAndIgnoreRemainingEvents()
        }
    }

    section("5 MockK: relaxed, relaxUnitFun, spyk, slot")
    val rel = mockk<Notifier>(relaxed = true)
    rel.send("2200", "x")
    println("relaxed: send прошел, quota()=${rel.quota("2200")}")
    val ru = mockk<Notifier>(relaxUnitFun = true)
    ru.send("2200", "x")
    println("relaxUnitFun: send прошел, quota(): ${runCatching { ru.quota("2200") }.exceptionOrNull()?.javaClass?.simpleName}")
    val spy = spyk(FeeCalculator())
    every { spy.rate("40817") } returns 20
    println("spyk: fee по подмененной ставке=${spy.fee("40817", 100_00)}, по настоящей=${spy.fee("40702", 100_00)}")
    verify { spy.rate("40702") }
    println("spyk: verify настоящего вызова rate прошел")
    val notifier = mockk<Notifier>(relaxUnitFun = true)
    val gw = mockk<AcquiringGateway>()
    val text = slot<String>()
    coEvery { gw.charge(any(), any()) } returns "auth-9"
    every { notifier.send(any(), capture(text)) } just Runs
    runTest { PayService(gw, notifier).pay("2200", 500) }
    println("slot: текст уведомления \"${text.captured}\"")

    section("6 mockkObject переживает тест без unmockkAll")
    run { mockkObject(FeatureFlags); every { FeatureFlags.enabled("new-limits") } returns true }
    println("в следующем тесте: enabled=${FeatureFlags.enabled("new-limits")}")
    unmockkAll()
    println("после unmockkAll: enabled=${FeatureFlags.enabled("new-limits")}")

    section("7 advanceTimeBy и runCurrent: повтор ровно через секунду; backgroundScope")
    runTest {
        val g = mockk<AcquiringGateway>()
        coEvery { g.charge(any(), any()) } throws IllegalStateException("таймаут") andThen "auth-1"
        val svc = PayService(g, mockk(relaxUnitFun = true))
        val job = launch { svc.pay("2200", 100) }
        advanceTimeBy(999); runCurrent()
        coVerify(exactly = 1) { g.charge(any(), any()) }
        println("через 999 мс: один вызов")
        advanceTimeBy(2); runCurrent()
        coVerify(exactly = 2) { g.charge(any(), any()) }
        println("через 1001 мс: два вызова")
        job.join()
        val ticks = mutableListOf<Long>()
        backgroundScope.launch { while (true) { delay(1.seconds); ticks += currentTime } }
        advanceTimeBy(3500)
        println("backgroundScope: тики $ticks, тест завершится без UncompletedCoroutinesError")
    }
}
