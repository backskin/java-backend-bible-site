package s03

import kotlin.concurrent.thread

open class Payment(val amountKop: Long)
class CardPayment(amountKop: Long) : Payment(amountKop) {
    /** Член класса побеждает расширение с той же сигнатурой. */
    fun describe(): String = "член CardPayment"
}

fun Payment.channel(): String = "общий канал"
fun CardPayment.channel(): String = "карточный канал"
fun CardPayment.describe(): String = "расширение CardPayment"

/** Клиент лимитов: интерфейс, который декорируем делегированием класса. */
interface LimitClient {
    fun remaining(account: String): Long
    fun reserve(account: String, kop: Long): Boolean
}

class HttpLimitClient : LimitClient {
    override fun remaining(account: String) = 50_000_00L
    override fun reserve(account: String, kop: Long) = kop <= remaining(account)
}

/** Декоратор с метриками: переопределен один метод, остальные компилятор делегирует сам. */
class MeteredLimitClient(private val inner: LimitClient) : LimitClient by inner {
    var calls = 0
    override fun reserve(account: String, kop: Long): Boolean {
        calls++
        return inner.reserve(account, kop)
    }
}

/** inline + reified: тип доступен внутри функции. */
inline fun <reified T> Map<String, Any>.typed(key: String): T? = this[key] as? T

/** Ленивое свойство со счетчиком вычислений. */
class Rates {
    var loads = 0
    val table: Map<String, Double> by lazy { loads++; Thread.sleep(50); mapOf("USD" to 92.5) }
}

fun lookupNullable(id: Long): String? = if (id > 0) "найден" else null

fun main() {
    val p: Payment = CardPayment(100)
    println("1 расширение по объявленному типу: ${p.channel()}")
    println("2 член против расширения: ${CardPayment(1).describe()}")

    // Ловушка ?.let { } ?: — лямбда вернула null, и сработал запасной вариант.
    val account: String? = "40817810000000000001"
    val r = account?.let { lookupNullable(-1) } ?: "запасной вариант"
    println("3 ?.let ?: при ненулевом account: $r")

    val metered = MeteredLimitClient(HttpLimitClient())
    metered.reserve("a", 100); metered.reserve("a", 200)
    println("4 делегирование класса: remaining=${metered.remaining("a")}, calls=${metered.calls}")

    val m: Map<String, Any> = mapOf("limit" to 1000L, "name" to "дневной")
    println("5 reified: ${m.typed<Long>("limit")}, ${m.typed<Long>("name")}")

    val rates = Rates()
    val ts = (1..8).map { thread { rates.table } }
    ts.forEach { it.join() }
    println("6 by lazy из 8 потоков: вычислений ${rates.loads}")
}
