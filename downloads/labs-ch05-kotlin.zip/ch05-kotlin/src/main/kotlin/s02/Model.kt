package s02

import java.math.BigDecimal

/** Номер счета как value class: в байткоде параметр становится String. */
@JvmInline
value class AccountNumber(val value: String) {
    init {
        require(value.length == 20) { "номер счета должен содержать 20 цифр: $value" }
    }
}

/** Сумма в копейках как value class поверх Long. */
@JvmInline
value class Kopecks(val value: Long)

/** Платеж: data class с вложенным изменяемым списком, чтобы показать поверхностное copy(). */
data class Payment(val id: Long, val from: AccountNumber, val amount: Kopecks, val tags: MutableList<String>) {
    /** Свойство из тела класса не входит в equals, hashCode, toString и copy. */
    var attempts: Int = 0
}

/** Состояния платежа: sealed interface с data object и data class. */
sealed interface PaymentState {
    data object New : PaymentState
    data class Authorized(val authCode: String) : PaymentState
    data class Captured(val authCode: String, val capturedAt: Long) : PaymentState
    data class Failed(val reason: String) : PaymentState
}

/** События платежа. */
sealed interface PaymentEvent {
    data class Authorize(val authCode: String) : PaymentEvent
    data class Capture(val at: Long) : PaymentEvent
    data class Fail(val reason: String) : PaymentEvent
}

/** Недопустимый переход машины состояний. */
class IllegalTransition(state: PaymentState, event: PaymentEvent) :
    IllegalStateException("переход $state + $event запрещен")

/** Переход машины состояний: внешний when исчерпывающий, без else. */
fun transition(state: PaymentState, event: PaymentEvent): PaymentState = when (state) {
    PaymentState.New -> when (event) {
        is PaymentEvent.Authorize -> PaymentState.Authorized(event.authCode)
        is PaymentEvent.Fail -> PaymentState.Failed(event.reason)
        is PaymentEvent.Capture -> throw IllegalTransition(state, event)
    }
    is PaymentState.Authorized -> when (event) {
        is PaymentEvent.Capture -> PaymentState.Captured(state.authCode, event.at)
        is PaymentEvent.Fail -> PaymentState.Failed(event.reason)
        is PaymentEvent.Authorize -> throw IllegalTransition(state, event)
    }
    is PaymentState.Captured, is PaymentState.Failed -> throw IllegalTransition(state, event)
}

/** Поиск по номеру счета: имя метода в байткоде будет искажено (mangled). */
fun findByAccount(account: AccountNumber): String = "счет ${account.value}"

/** Тот же поиск, но с явным именем для Java. */
@JvmName("findByAccountForJava")
fun findByAccountNamed(account: AccountNumber): String = "счет ${account.value}"

/** Сумма в nullable-позиции: здесь value class упаковывается. */
fun maybeAmount(k: Kopecks?): Long = k?.value ?: 0

fun main() {
    val acc = AccountNumber("40702810000000000001")
    val p1 = Payment(1, acc, Kopecks(150_00), mutableListOf("sbp"))
    p1.attempts = 3
    val p2 = p1.copy()
    println("1 equals после copy: ${p1 == p2}, attempts у копии: ${p2.attempts}")
    p2.tags += "retry"
    println("2 copy поверхностный: теги оригинала ${p1.tags}")
    println("3 toString: $p1")

    // Где value class упакован, а где нет: класс объектов внутри коллекции и в Any.
    val list: List<Kopecks> = listOf(Kopecks(1), Kopecks(2))
    println("4 элемент List<Kopecks>: ${(list as List<Any>)[0].javaClass.name}")
    val any: Any = Kopecks(5)
    println("5 Kopecks как Any: ${any.javaClass.name}")
    println("6 поле в data class: тип ${Payment::class.java.getDeclaredField("amount").type}")

    // Проверка init у value class.
    try { AccountNumber("123") } catch (e: IllegalArgumentException) { println("7 init: ${e.message}") }

    // Машина состояний.
    var s: PaymentState = PaymentState.New
    s = transition(s, PaymentEvent.Authorize("A1"))
    s = transition(s, PaymentEvent.Capture(1_700_000_000))
    println("8 состояние: $s")
    try { transition(s, PaymentEvent.Fail("timeout")) } catch (e: IllegalTransition) { println("9 ${e.message}") }

    // Методы с value class в сигнатуре.
    println("10 методы: " + Class.forName("s02.ModelKt").declaredMethods.map { it.name }.filter { it.startsWith("find") || it.startsWith("maybe") }.sorted())
    // PermittedSubclasses на JVM (Java 17+).
    println("11 isSealed на JVM: ${PaymentState::class.java.isSealed}, permitted=${PaymentState::class.java.permittedSubclasses?.map { it.simpleName }}")
}
