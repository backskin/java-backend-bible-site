package s05

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import s04.log

private fun section(t: String) = println("\n== $t")

/** Статусы платежей из «базы»: 3 элемента по 100 мс. */
fun statuses(): Flow<Int> = flow {
    log("строитель запущен")
    repeat(3) { delay(100); log("emit $it"); emit(it) }
}

/** «Медленная» отправка уведомления, 300 мс на элемент. */
suspend fun notify(id: Int): String { delay(300); return "уведомление $id" }

class ScoringDown : RuntimeException("антифрод недоступен")

fun main() = runBlocking {
    section("1 холодный поток: строитель запускается на каждый collect")
    val f = statuses()
    log("поток создан, ничего не выполнено")
    f.collect { }
    f.collect { }

    section("2 без буфера: производитель ждет потребителя")
    var t0 = System.nanoTime()
    statuses().map { notify(it) }.collect { log(it) }
    log("итого ${(System.nanoTime() - t0) / 1_000_000} мс")

    section("3 buffer(3)")
    t0 = System.nanoTime()
    statuses().buffer(3).map { notify(it) }.collect { log(it) }
    log("итого ${(System.nanoTime() - t0) / 1_000_000} мс")

    section("4 conflate: медленный потребитель видит только свежие значения")
    flow { repeat(10) { delay(50); emit(it) } }.conflate().collect { delay(180); log("курс №$it") }

    section("5 collectLatest: обработка устаревшего значения отменяется")
    flow { repeat(4) { delay(100); emit(it) } }.collectLatest {
        log("начал $it"); delay(250); log("закончил $it")
    }

    section("6 flowOn меняет диспетчер только выше по цепочке")
    flowOf(1).onEach { log("A") }.flowOn(Dispatchers.IO).onEach { log("B") }.flowOn(Dispatchers.Default).onEach { log("C") }.collect()

    section("7 нарушение сохранения контекста")
    val r7 = runCatching { flow { withContext(Dispatchers.IO) { emit(1) } }.collect() }
    println(r7.exceptionOrNull()?.message?.lines()?.take(2)?.joinToString(" / "))

    section("8 catch ловит только то, что выше него")
    val r8 = runCatching {
        flowOf(1, 2).catch { log("catch: $it") }.collect { if (it == 2) throw ScoringDown() }
    }
    log("исключение из collect прошло мимо catch: ${r8.exceptionOrNull()?.message}")
    flowOf(1, 2).onEach { if (it == 2) throw ScoringDown() }.catch { log("catch после onEach: ${it.message}") }.collect()

    section("9 нарушение прозрачности исключений")
    val r9 = runCatching {
        flow { try { emit(1) } catch (e: Throwable) { log("строитель проглотил: ${e.message}"); emit(2) } }
            .collect { if (it == 1) throw ScoringDown() }
    }
    println(r9.exceptionOrNull()?.let { "${it::class.simpleName}: ${it.message?.lines()?.first()}" })

    section("10 retry перезапускает строитель со всеми побочными эффектами")
    var calls = 0
    flow { calls++; log("запрос в антифрод №$calls"); if (calls < 3) throw ScoringDown(); emit("ok") }
        .retry(5) { it is ScoringDown }
        .collect { log("результат $it") }

    section("11 onCompletion видит причину")
    flowOf(1).onCompletion { log("onCompletion cause=$it") }.collect()
    val job = launch { flow { delay(1000); emit(1) }.onCompletion { log("onCompletion cause=${it?.javaClass?.simpleName}") }.collect() }
    delay(50); job.cancelAndJoin()

    section("12 StateFlow: конфляция и отсев равных значений")
    val limit = MutableStateFlow(100)
    val seen = mutableListOf<Int>()
    val c = launch { limit.collect { seen += it } }
    yield()
    limit.value = 200; limit.value = 300; limit.value = 300
    yield(); delay(10)
    limit.value = 300; delay(10)
    c.cancelAndJoin()
    log("подписчик увидел $seen")

    section("13 SharedFlow без replay: поздний подписчик пропускает события")
    val events = MutableSharedFlow<String>()
    events.emit("платеж 1 проведен")
    val late = mutableListOf<String>()
    val l = launch { events.collect { late += it } }
    yield(); events.emit("платеж 2 проведен"); yield()
    l.cancelAndJoin()
    log("поздний подписчик получил $late, subscriptionCount после отмены=${events.subscriptionCount.value}")
}
