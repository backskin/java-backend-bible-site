package s06

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.reactive.asFlow
import kotlinx.coroutines.reactive.awaitSingle
import kotlinx.coroutines.reactor.ReactorContext
import kotlinx.coroutines.reactor.asFlux
import kotlinx.coroutines.reactor.mono
import kotlinx.coroutines.slf4j.MDCContext
import org.slf4j.MDC
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import reactor.util.context.Context
import s04.log
import java.lang.management.ManagementFactory
import java.time.Duration
import java.util.concurrent.Executors

private fun section(t: String) = println("\n== $t")

fun usedMb(): Long { System.gc(); Thread.sleep(200); val r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) / 1_048_576 }

fun main() {
    section("1 Mono -> suspend и suspend -> Mono")
    runBlocking {
        val limit = Mono.just(50_000_00L).delayElement(Duration.ofMillis(50)).awaitSingle()
        log("awaitSingle: $limit")
    }
    val m = mono { delay(20); log("внутри mono, ReactorContext=${coroutineContext[ReactorContext]?.context?.getOrDefault("traceId", "нет")}"); "ok" }
    log("mono.block() = ${m.contextWrite(Context.of("traceId", "t-42")).block()}")

    section("2 Flux <-> Flow")
    runBlocking {
        val ids = Flux.range(1, 5).asFlow().map { it * 10 }.toList()
        log("Flux.asFlow: $ids")
    }
    log("Flow.asFlux: ${flowOf("a", "b").asFlux().collectList().block()}")

    section("3 MDC и смена потока")
    runBlocking {
        MDC.put("paymentId", "p-1")
        withContext(Dispatchers.IO) { log("без MDCContext: paymentId=${MDC.get("paymentId")}") }
        withContext(Dispatchers.IO + MDCContext()) { log("с MDCContext: paymentId=${MDC.get("paymentId")}") }
        MDC.clear()
    }

    section("4 100 000 ожиданий по 1 с: корутины и виртуальные потоки")
    val base = usedMb()
    var t0 = System.nanoTime()
    var peak = 0L
    runBlocking {
        val jobs = List(100_000) { launch(Dispatchers.Default) { delay(1000) } }
        delay(500); peak = usedMb() - base
        jobs.joinAll()
    }
    log("корутины: ${(System.nanoTime() - t0) / 1_000_000} мс, прирост кучи на пике ~$peak МБ")
    val base2 = usedMb()
    t0 = System.nanoTime()
    Executors.newVirtualThreadPerTaskExecutor().use { ex ->
        repeat(100_000) { ex.submit { Thread.sleep(1000) } }
        Thread.sleep(500); peak = usedMb() - base2
    }
    log("виртуальные потоки: ${(System.nanoTime() - t0) / 1_000_000} мс, прирост кучи на пике ~$peak МБ")
    log("JVM: ${ManagementFactory.getRuntimeMXBean().vmVersion}")
}

fun usedMbNoGc(): Long { val r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) / 1_048_576 }
