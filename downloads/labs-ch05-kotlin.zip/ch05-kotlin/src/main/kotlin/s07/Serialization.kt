package s07

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import tools.jackson.module.kotlin.jacksonObjectMapper
import tools.jackson.module.kotlin.readValue
import java.math.BigDecimal

private fun section(t: String) = println("\n== $t")

@JvmInline
@Serializable
value class AccountNumber(val value: String)

/** Запрос на перевод: одинаковый класс для обеих библиотек. */
@Serializable
data class TransferRequest(
    val from: AccountNumber,
    val amountKop: Long,
    val currency: String = "RUB",
    val comment: String? = null,
    val isUrgent: Boolean = false,
)

/** То же без значения по умолчанию у суммы и с вложенным списком для замера. */
@Serializable
data class Registry(val id: String, val items: List<TransferRequest>)

private fun attempt(label: String, block: () -> Any?) {
    try { println("$label -> ${block()}") } catch (e: Throwable) {
        println("$label -> ${e::class.java.name}: ${e.message?.lines()?.first()}")
    }
}

fun main() {
    val jackson = jacksonObjectMapper()
    val kx = Json
    val req = TransferRequest(AccountNumber("40702810000000000001"), 150_00)

    section("1 запись объекта с полями по умолчанию")
    println("Jackson: ${jackson.writeValueAsString(req)}")
    println("kotlinx: ${kx.encodeToString(req)}")

    section("2 нет обязательного поля amountKop")
    val noAmount = """{"from":"40702810000000000001"}"""
    attempt("Jackson") { jackson.readValue<TransferRequest>(noAmount) }
    attempt("kotlinx") { kx.decodeFromString<TransferRequest>(noAmount) }

    section("3 null в ненулевом Long")
    val nullAmount = """{"from":"40702810000000000001","amountKop":null}"""
    attempt("Jackson") { jackson.readValue<TransferRequest>(nullAmount) }
    attempt("kotlinx") { kx.decodeFromString<TransferRequest>(nullAmount) }

    val jackson2 = com.fasterxml.jackson.module.kotlin.jacksonObjectMapper()
    attempt("Jackson 2.22") { jackson2.readValue(nullAmount, TransferRequest::class.java) }
    attempt("Jackson 2.22, нет amountKop") { jackson2.readValue(noAmount, TransferRequest::class.java) }

    section("4 null в поле со значением по умолчанию currency")
    val nullCurrency = """{"from":"40702810000000000001","amountKop":100,"currency":null}"""
    attempt("Jackson") { jackson.readValue<TransferRequest>(nullCurrency) }
    attempt("kotlinx") { kx.decodeFromString<TransferRequest>(nullCurrency) }

    section("5 неизвестное поле")
    val unknown = """{"from":"40702810000000000001","amountKop":100,"channel":"sbp"}"""
    attempt("Jackson") { jackson.readValue<TransferRequest>(unknown) }
    attempt("kotlinx") { kx.decodeFromString<TransferRequest>(unknown) }
    attempt("kotlinx ignoreUnknownKeys") { Json { ignoreUnknownKeys = true }.decodeFromString<TransferRequest>(unknown) }

    section("6 строка вместо числа")
    val strAmount = """{"from":"40702810000000000001","amountKop":"100"}"""
    attempt("Jackson") { jackson.readValue<TransferRequest>(strAmount) }
    attempt("kotlinx") { kx.decodeFromString<TransferRequest>(strAmount) }

    section("7 isUrgent: имя поля в JSON")
    val urgent = req.copy(isUrgent = true)
    println("Jackson: ${jackson.writeValueAsString(urgent)}")
    println("kotlinx: ${kx.encodeToString(urgent)}")
    attempt("Jackson читает свой же вывод") { jackson.readValue<TransferRequest>(jackson.writeValueAsString(urgent)).isUrgent }

    section("8 грубый замер: реестр из 1000 переводов, 2000 циклов записи и чтения")
    val registry = Registry("r-1", List(1000) { TransferRequest(AccountNumber("4070281000000000%04d".format(it)), it * 100L, comment = "оплата по счету $it") })
    fun bench(name: String, enc: () -> String, dec: (String) -> Any) {
        repeat(300) { dec(enc()) } // прогрев
        val t0 = System.nanoTime()
        var s = ""
        repeat(2000) { s = enc(); dec(s) }
        println("$name: ${(System.nanoTime() - t0) / 1_000_000} мс, размер ${s.length} символов")
    }
    repeat(2) {
        bench("Jackson", { jackson.writeValueAsString(registry) }, { jackson.readValue<Registry>(it) })
        bench("kotlinx", { kx.encodeToString(registry) }, { kx.decodeFromString<Registry>(it) })
    }
    println("BigDecimal не сериализуем kotlinx без своего сериализатора: ${runCatching { kx.encodeToString(BigDecimal.ONE) }.exceptionOrNull()?.message?.lines()?.first()}")
}
