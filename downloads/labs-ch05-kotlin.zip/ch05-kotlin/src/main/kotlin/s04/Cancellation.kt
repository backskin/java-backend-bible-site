package s04

import kotlinx.coroutines.*
import kotlin.coroutines.cancellation.CancellationException
import kotlin.coroutines.resume

private fun section(t: String) = println("\n== $t")

/** Цикл без точек приостановки: отмена не доходит. */
fun cpuWork(ms: Long): Long { var n = 0L; val end = System.currentTimeMillis() + ms; while (System.currentTimeMillis() < end) n++; return n }

/** Мост к колбэку без поддержки отмены. */
suspend fun legacyCall(): String = suspendCancellableCoroutine<String> { /* никогда не возобновляется */ }
suspend fun legacyCallIgnoringCancel(): String = kotlin.coroutines.suspendCoroutine { cont ->
    Thread { Thread.sleep(1500); cont.resume("ответ через 1500 мс") }.start()
}

fun main() = runBlocking {
    section("1 каскад отмены вниз по дереву")
    val parent = launch {
        launch { launch { try { delay(5000) } finally { log("правнук: finally, отменен") } } }
    }
    delay(100); parent.cancelAndJoin(); log("родитель отменен: isCancelled=${parent.isCancelled}")

    section("2 цикл без точек приостановки не отменяется")
    val cpu = launch(Dispatchers.Default) { repeat(5) { cpuWork(100); log("итерация $it") } }
    delay(150); cpu.cancelAndJoin(); log("cancelAndJoin вернулся")

    section("3 то же с ensureActive()")
    val cpu2 = launch(Dispatchers.Default) { repeat(5) { ensureActive(); cpuWork(100); log("итерация $it") } }
    delay(150); cpu2.cancelAndJoin(); log("cancelAndJoin вернулся")

    section("4 runCatching проглатывает отмену")
    val swallow = launch { repeat(5) { runCatching { delay(100) }; log("шаг $it") } }
    delay(150); swallow.cancelAndJoin(); log("swallow завершена")

    section("5 runCatching с повторным выбросом CancellationException")
    val fixed = launch { repeat(5) { runCatching { delay(100) }.onFailure { if (it is CancellationException) throw it }; log("шаг $it") } }
    delay(150); fixed.cancelAndJoin(); log("fixed завершена")

    section("6 suspend-вызов в finally отмененной корутины")
    val cleanup = launch {
        try { delay(1000) } finally {
            try { delay(10); log("finally: delay прошел") } catch (e: CancellationException) { log("finally: delay бросил ${e::class.simpleName}") }
            withContext(NonCancellable) { delay(10); log("finally: NonCancellable delay прошел") }
        }
    }
    delay(50); cleanup.cancelAndJoin()

    section("7 withTimeout вокруг блокирующего вызова")
    var t0 = System.nanoTime()
    val r7 = runCatching { withTimeout(200) { withContext(Dispatchers.IO) { Thread.sleep(1000); "готово" } } }
    log("withTimeout(200) + Thread.sleep(1000): ${r7.exceptionOrNull()?.javaClass?.simpleName ?: r7.getOrNull()} через ${(System.nanoTime() - t0) / 1_000_000} мс")
    t0 = System.nanoTime()
    val r7b = runCatching { withTimeout(200) { runInterruptible(Dispatchers.IO) { Thread.sleep(1000); "готово" } } }
    log("withTimeout(200) + runInterruptible: ${r7b.exceptionOrNull()?.javaClass?.simpleName} через ${(System.nanoTime() - t0) / 1_000_000} мс")

    section("8 suspendCoroutine против suspendCancellableCoroutine под withTimeout")
    t0 = System.nanoTime()
    val r8 = withTimeoutOrNull(200) { legacyCallIgnoringCancel() }
    log("suspendCoroutine: результат=$r8 через ${(System.nanoTime() - t0) / 1_000_000} мс")
    t0 = System.nanoTime()
    val r8b = withTimeoutOrNull(200) { legacyCall() }
    log("suspendCancellableCoroutine: результат=$r8b через ${(System.nanoTime() - t0) / 1_000_000} мс")

    section("9 CancellationException, брошенная ребенком, не роняет родителя")
    coroutineScope {
        launch { throw CancellationException("сам себя отменил") }
        launch { delay(50); log("сосед доработал") }
    }
    log("scope завершился нормально")

    section("10 withTimeout внутри launch: истекший таймаут не попадает ни в журнал, ни к родителю")
    val handler = CoroutineExceptionHandler { _, e -> log("обработчик: $e") }
    val j = CoroutineScope(Dispatchers.Default + handler).launch {
        val r = withTimeout(100) { delay(1000); "ответ процессинга" }
        log("обработка результата $r — не печатается")
    }
    j.join()
    log("launch завершился: isCancelled=${j.isCancelled}, обработчик не вызывался")
}
