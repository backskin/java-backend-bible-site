package s04

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

private fun section(t: String) = println("\n== $t")

/** 200 блокирующих вызовов по 500 мс на заданном диспетчере: время и число разных потоков. */
suspend fun blockingBatch(label: String, dispatcher: CoroutineDispatcher, n: Int = 200) = coroutineScope {
    val threads = ConcurrentHashMap.newKeySet<String>()
    val t0 = System.nanoTime()
    (1..n).map { async(dispatcher) { threads += Thread.currentThread().let { if (it.isVirtual) "vt-" + it.threadId() else it.name }; Thread.sleep(500) } }.awaitAll()
    log("$label: ${(System.nanoTime() - t0) / 1_000_000} мс, потоков ${threads.size}")
}

@OptIn(ExperimentalCoroutinesApi::class, DelicateCoroutinesApi::class)
fun main() = runBlocking {
    section("1 размеры пулов")
    log("ядер: ${Runtime.getRuntime().availableProcessors()}")
    val defThreads = ConcurrentHashMap.newKeySet<String>()
    (1..200).map { async(Dispatchers.Default) { defThreads += Thread.currentThread().name; Thread.sleep(20) } }.awaitAll()
    log("Dispatchers.Default под нагрузкой: потоков ${defThreads.size}")

    section("2 200 блокирующих вызовов по 500 мс")
    blockingBatch("Dispatchers.IO", Dispatchers.IO)
    val db = Dispatchers.IO.limitedParallelism(100)
    blockingBatch("IO.limitedParallelism(100)", db)
    val vt = Executors.newVirtualThreadPerTaskExecutor().asCoroutineDispatcher()
    blockingBatch("виртуальные потоки", vt)

    section("3 limitedParallelism внутри метода против поля")
    var t0 = System.nanoTime()
    coroutineScope { repeat(40) { launch { withContext(Dispatchers.IO.limitedParallelism(4)) { Thread.sleep(200) } } } }
    log("новый вид на каждый вызов: ${(System.nanoTime() - t0) / 1_000_000} мс")
    val four = Dispatchers.IO.limitedParallelism(4)
    t0 = System.nanoTime()
    coroutineScope { repeat(40) { launch { withContext(four) { Thread.sleep(200) } } } }
    log("один вид в поле: ${(System.nanoTime() - t0) / 1_000_000} мс")

    section("4 Unconfined: продолжение на потоке того, кто возобновил")
    launch(Dispatchers.Unconfined) {
        log("до delay")
        delay(10)
        log("после delay")
    }.join()

    section("5 гонка на общем счетчике")
    var x = 0
    coroutineScope { repeat(10_000) { launch(Dispatchers.Default) { x++ } } }
    log("10 000 инкрементов без защиты: $x")
    val mutex = Mutex(); var y = 0
    coroutineScope { repeat(10_000) { launch(Dispatchers.Default) { mutex.withLock { y++ } } } }
    log("с Mutex: $y")

    section("6 runBlocking на единственном потоке диспетчера")
    val single = newSingleThreadContext("single")
    val watchdog = Thread { Thread.sleep(2000); log("через 2 с внутренний runBlocking все еще ждет: взаимная блокировка"); System.out.flush(); Runtime.getRuntime().halt(0) }
    watchdog.isDaemon = true; watchdog.start()
    withContext(single) {
        runBlocking { withContext(single) { log("сюда не попасть") } }
    }
}
