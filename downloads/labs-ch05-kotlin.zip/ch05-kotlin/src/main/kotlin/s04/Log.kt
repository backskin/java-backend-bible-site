package s04

/** Время от старта программы, мс. */
val START: Long = System.nanoTime()

/** Строка журнала: миллисекунды от старта, поток и сообщение. */
fun log(msg: Any?) {
    val ms = (System.nanoTime() - START) / 1_000_000
    println("%5d [%s] %s".format(ms, Thread.currentThread().name, msg))
}
