package s04

import kotlinx.coroutines.*

private fun section(t: String) = println("\n== $t")

class ScoringUnavailable : RuntimeException("антифрод недоступен")

@OptIn(DelicateCoroutinesApi::class)
fun main() {
    section("1 try/catch вокруг launch не ловит исключение ребенка")
    val r1 = runCatching {
        runBlocking {
            try { launch { throw ScoringUnavailable() } } catch (e: ScoringUnavailable) { log("поймано у launch") }
        }
    }
    log("runBlocking завершился с ${r1.exceptionOrNull()}")

    section("2 async в coroutineScope: try/catch вокруг await и отмена соседа")
    val r2 = runCatching {
        runBlocking {
            coroutineScope {
                val score = async { delay(100); throw ScoringUnavailable() }
                val limits = async { try { delay(1000); "лимиты ок" } catch (e: CancellationException) { log("limits отменен: ${e.message}"); throw e } }
                try { score.await() } catch (e: ScoringUnavailable) { log("await поймал: ${e.message}") }
                log("limits = ${limits.await()}")
            }
        }
    }
    log("итог: ${r2.exceptionOrNull()}")

    section("3 то же в supervisorScope")
    runBlocking {
        supervisorScope {
            val score = async { delay(100); throw ScoringUnavailable() }
            val limits = async { delay(300); "лимиты ок" }
            try { score.await() } catch (e: ScoringUnavailable) { log("await поймал: ${e.message}") }
            log("limits = ${limits.await()}")
        }
    }

    section("4 launch в supervisorScope без обработчика: исключение уходит в обработчик потока")
    runBlocking {
        supervisorScope {
            launch { throw ScoringUnavailable() }
            launch { delay(100); log("сосед жив") }
        }
    }

    section("5 промежуточный CoroutineExceptionHandler не вызывается")
    val top = CoroutineExceptionHandler { _, e -> log("[TOP] ${e.message}") }
    val mid = CoroutineExceptionHandler { _, e -> log("[MID] ${e.message}") }
    runBlocking {
        GlobalScope.launch(top) { launch(mid) { throw ScoringUnavailable() } }.join()
    }

    section("6 async в корне scope: обработчик не вызывается, исключение ждет await")
    runBlocking {
        val scope = CoroutineScope(SupervisorJob() + top)
        val d = scope.async { throw ScoringUnavailable() }
        delay(100)
        log("isCompleted=${d.isCompleted}, обработчик молчал; await -> ${runCatching { d.await() }.exceptionOrNull()?.message}")
    }

    section("7 launch(SupervisorJob()) выходит из дерева: родитель не ждет ребенка")
    runBlocking {
        val outer = launch {
            launch(SupervisorJob()) { delay(300); log("отвязанный ребенок доработал после отмены родителя") }
            launch { delay(300); log("обычный ребенок — не должно печататься") }
        }
        delay(50); outer.cancelAndJoin(); log("outer отменен и дождан")
        delay(400)
    }

    section("8 два упавших ребенка: второе исключение в suppressed")
    val r8 = runCatching {
        runBlocking {
            coroutineScope {
                launch { try { delay(1000) } finally { withContext(NonCancellable) { throw IllegalStateException("ошибка в finally") } } }
                launch { delay(50); throw ScoringUnavailable() }
            }
        }
    }
    val e8 = r8.exceptionOrNull()!!
    log("главное: ${e8.message}; suppressed: ${e8.suppressed.map { it.message }}")
}
