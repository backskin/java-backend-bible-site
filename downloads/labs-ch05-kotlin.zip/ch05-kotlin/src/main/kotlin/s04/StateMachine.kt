package s04

import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import java.math.BigDecimal

/** Заглушка АБС: остаток счета. */
suspend fun balance(account: String): BigDecimal { delay(10); return BigDecimal("1500.00") }

/** Заглушка антифрода: оценка риска. */
suspend fun score(account: String, amount: BigDecimal): Int { delay(10); return 17 }

/**
 * Две точки приостановки и локальные переменные, которые живут через них:
 * компилятор создает класс-продолжение с полем label и полями для переменных.
 */
suspend fun authorize(account: String, amount: BigDecimal, attempt: Int): String {
    val started = System.nanoTime()
    val bal = balance(account)
    if (bal < amount) return "DECLINED: не хватает средств"
    val risk = score(account, amount)
    val tookMs = (System.nanoTime() - started) / 1_000_000
    return if (risk < 50) "APPROVED попытка=$attempt за ${tookMs}мс" else "REVIEW"
}

/** Хвостовой вызов: приостановка только в последнем вызове, класс-продолжение не нужен. */
suspend fun authorizeTail(account: String): BigDecimal = balance(account)

fun main() = runBlocking {
    println(authorize("40817810000000000001", BigDecimal("100.00"), 1))
    println(authorizeTail("40817810000000000001"))
}
