package s01

import dev.team.legacy.JavaCaller
import dev.team.legacy.LegacyCardClient
import dev.team.legacy.MarkedCardClient
import java.math.BigDecimal

/** Публичная функция с ненулевым параметром: компилятор вставляет проверку для вызовов из Java. */
fun requireCity(city: String): Int = city.length

/** Комиссия с аргументами по умолчанию; @JvmOverloads дает Java перегрузки «хвостом». */
object Fees {
    @JvmStatic
    @JvmOverloads
    fun fee(amountKop: Long, percent: BigDecimal = BigDecimal("1.5"), minKop: Long = 30_00): BigDecimal =
        (BigDecimal(amountKop) * percent / BigDecimal(100)).max(BigDecimal(minKop))
}

private fun attempt(label: String, block: () -> Any?) {
    try {
        println("$label -> ${block()}")
    } catch (e: Throwable) {
        println("$label -> ${e::class.java.name}: ${e.message}")
    }
}

fun main() {
    val client = LegacyCardClient()
    val pan = "4276000000000001"

    // 1. Платформенный тип присваивается переменной с явным ненулевым типом: проверка в точке присваивания.
    attempt("1 явный тип String") { val city: String = client.city(pan); city }

    // 2. Тип выведен: переменная остается платформенной, падение переносится в точку использования.
    val inferred = client.city(pan)
    attempt("2 выведенный тип, присваивание") { inferred }
    attempt("2 выведенный тип, .length") { inferred.length }

    // 3. Элемент коллекции из Java: List<String!>, null приходит при обходе.
    attempt("3 элемент List из Java") { client.tags(pan).map { it.length } }

    // 4. Значение Map из Java: get возвращает String?, компилятор требует проверку, !! бросает NPE без имени.
    attempt("4 Map.get + !!") { client.headers()["X-Request-Id"]!!.length }

    // 5. Java передает null в Kotlin-функцию с ненулевым параметром.
    attempt("5 null из Java в Kotlin") { JavaCaller.passNull() }

    // 6. Размеченный JSpecify клиент: тип String?, компилятор заставляет обработать null.
    val marked: String? = MarkedCardClient().city(pan)
    println("6 JSpecify: String? = $marked, длина по умолчанию ${marked?.length ?: 0}")

    // 7. @JvmOverloads: Java вызывает fee(long) без двух последних аргументов.
    attempt("7 Java -> fee(long)") { JavaCaller.feeViaOverload() }
}
