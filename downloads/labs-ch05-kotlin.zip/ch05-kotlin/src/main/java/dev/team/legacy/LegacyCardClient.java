package dev.team.legacy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Старый Java-клиент процессинга без аннотаций nullability: Kotlin видит его типы как платформенные.
 */
public class LegacyCardClient {

    /** Город выпуска карты; для части карт процессинг его не знает и возвращает null. */
    public String city(String pan) {
        return pan.startsWith("2200") ? "Самара" : null;
    }

    /** Теги карты; один из элементов может оказаться null. */
    public List<String> tags(String pan) {
        List<String> tags = new ArrayList<>();
        tags.add("debit");
        tags.add(null);
        return tags;
    }

    /** Заголовки ответа процессинга; значение может быть null. */
    public Map<String, String> headers() {
        Map<String, String> h = new HashMap<>();
        h.put("X-Request-Id", null);
        return h;
    }
}
