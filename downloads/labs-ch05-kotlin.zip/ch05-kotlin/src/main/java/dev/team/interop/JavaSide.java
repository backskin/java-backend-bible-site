package dev.team.interop;

import kotlin.Unit;
import s14.FeeRule;
import s14.Interop;
import s14.Tariff;
import s14.Transfer;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.List;

/**
 * Java-код, который вызывает Kotlin-объявления из s14.Interop.
 */
public class JavaSide {

    /** Тариф, реализованный на Java: тело withFee берется из интерфейса Kotlin. */
    static class JavaTariff implements Tariff {
        @Override
        public long base() {
            return 100;
        }
    }

    /** Проверка, после которой Java требует return, хотя fail не возвращается. */
    static String checkAccount(String account) {
        if (account.startsWith("40")) {
            return account;
        }
        Interop.fail("не счет: " + account);
        return null;
    }

    /** Печатает, как Java видит Kotlin-объявления. */
    public static void run() throws Exception {
        System.out.println("FeeRule.of: " + FeeRule.of("1.5"));
        System.out.println("FeeRule.Companion.parse: " + FeeRule.Companion.parse("2"));
        System.out.println("FeeRule.ZERO: " + FeeRule.ZERO);
        System.out.println("FeeRule.Companion.getDEFAULT(): " + FeeRule.Companion.getDEFAULT());
        System.out.println("FeeRule.CURRENCY: " + FeeRule.CURRENCY);

        try {
            Interop.readRegistry(Path.of("нет-такого-реестра.txt"));
        } catch (IOException e) {
            System.out.println("@Throws: catch (IOException) поймал " + e.getClass().getSimpleName());
        }
        try {
            Interop.readRegistryNoThrows(Path.of("нет-такого-реестра.txt"));
        } catch (Exception e) {
            System.out.println("без @Throws: пришлось ловить Exception, пойман " + e.getClass().getName());
        }

        Interop.onEvent(id -> {
            System.out.println("Function1 из Java: " + id);
            return Unit.INSTANCE;
        });
        Interop.onPayment(id -> System.out.println("fun interface из Java: " + id));

        System.out.println("totalKop: " + Interop.totalKop(List.of(100L, 250L))
            + ", totalRub: " + Interop.totalRub(List.of(new BigDecimal("1.50"), new BigDecimal("2.25"))));

        Transfer t = new Transfer("40702810000000000001", "40817810000000000002", 150_00L, "RUB");
        System.out.println("copy из Java требует все параметры: " + t.copy(t.getFrom(), t.getTo(), 200_00L, t.getCurrency()));

        System.out.println("Java реализует Tariff только с base(): withFee()=" + new JavaTariff().withFee());
        System.out.println("suspend через CompletableFuture: " + Interop.limitAsync("40817810000000000002").get());
        System.out.println("checkAccount: " + checkAccount("40817810000000000002"));

        List<String> codes = Interop.registryCodes();
        System.out.println("listOf(3) из Java: класс " + codes.getClass().getName());
        codes.set(0, "Z99");
        System.out.println("  set прошел: " + codes);
        try {
            codes.add("D04");
        } catch (UnsupportedOperationException e) {
            System.out.println("  add: UnsupportedOperationException");
        }
        List<String> mapped = Interop.mappedCodes();
        mapped.add("d04");
        System.out.println("map {} из Java: класс " + mapped.getClass().getName() + ", add прошел: " + mapped);
        List<String> single = Interop.singleCode();
        System.out.println("listOf(1) из Java: класс " + single.getClass().getName());
        try {
            single.set(0, "Z99");
        } catch (UnsupportedOperationException e) {
            System.out.println("  set: UnsupportedOperationException");
        }
    }
}
