package dev.team.legacy;

import java.util.List;
import java.util.function.Consumer;

/**
 * Старый Java-драйвер очереди без аннотаций nullability.
 */
public class QueueDriver {

    /** Отдает подписчику два сообщения, второе с пустым телом. */
    public void subscribe(Consumer<String> listener) {
        listener.accept("payment-1");
        listener.accept(null);
    }

    /** Дописывает в переданный список служебную строку. */
    public static void fill(List<String> target) {
        target.add("trailer");
    }
}
