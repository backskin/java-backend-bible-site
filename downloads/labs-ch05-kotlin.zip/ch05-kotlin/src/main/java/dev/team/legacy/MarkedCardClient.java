package dev.team.legacy;

import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

/**
 * Тот же клиент, размеченный JSpecify: Kotlin видит String? и String вместо платформенных типов.
 */
@NullMarked
public class MarkedCardClient {

    /** Город выпуска карты или null, если процессинг его не знает. */
    public @Nullable String city(String pan) {
        return pan.startsWith("2200") ? "Самара" : null;
    }
}
