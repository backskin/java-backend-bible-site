package dev.team.legacy;

import s01.Fees;
import s01.NullSafetyKt;

/**
 * Java-код, который вызывает Kotlin: null в ненулевой параметр и аргументы по умолчанию.
 */
public class JavaCaller {

    /** Передает null в функцию Kotlin с параметром типа String. */
    public static int passNull() {
        return NullSafetyKt.requireCity(null);
    }

    /** Вызывает функцию с аргументами по умолчанию через перегрузку, созданную @JvmOverloads. */
    public static String feeViaOverload() {
        return Fees.fee(100_00L).toString();
    }
}
