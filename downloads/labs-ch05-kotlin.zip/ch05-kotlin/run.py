"""Опыты главы 05: собирает проект Maven и запускает программы, вывод пишет в sNN-*.txt.

Использование:
    python -X utf8 run.py            # сборка и все опыты
    python -X utf8 run.py s04        # только опыты, чьё имя файла вывода начинается с s04

Версии: Kotlin 2.4.21, kotlinx.coroutines 1.11.0, Temurin 21.0.10 (см. pom.xml).
"""
import os, subprocess, sys, datetime

HOME = os.path.expanduser('~')
ROOT = os.path.dirname(os.path.abspath(__file__))
JAVA_HOME = os.path.join(HOME, '.jdks', 'temurin-21.0.10')
JAVA = os.path.join(JAVA_HOME, 'bin', 'java')
JAVAP = os.path.join(JAVA_HOME, 'bin', 'javap')
SEP = ';' if os.name == 'nt' else ':'

# (файл вывода, главный класс или ('javap', флаги, класс), флаги JVM)
RUNS = [
    ('s01-nullsafety', 's01.NullSafetyKt', []),
    ('s01-javap-intrinsics', ('javap', ['-c', '-p'], 's01.NullSafetyKt'), []),
    ('s01-javap-overloads', ('javap', ['-p'], 's01.Fees'), []),
    ('s02-model', 's02.ModelKt', []),
    ('s02-javap-valueclass', ('javap', ['-p'], 's02.ModelKt'), []),
    ('s02-javap-sealed', ('javap', ['-v'], 's02.PaymentState'), []),
    ('s03-functions', 's03.FunctionsKt', []),
    ('s03-javap-extension', ('javap', ['-p'], 's03.FunctionsKt'), []),
    ('s04-javap-statemachine', ('javap', ['-p'], 's04.StateMachineKt$authorize$1'), []),
    ('s04-javap-signature', ('javap', ['-p'], 's04.StateMachineKt'), []),
    ('s04-cancellation', 's04.CancellationKt', []),
    ('s04-exceptions', 's04.ExceptionsKt', []),
    ('s04-dispatchers', 's04.DispatchersKt', []),
    ('s05-flows', 's05.FlowsKt', []),
    ('s06-bridges', 's06.BridgesKt', ['-Xmx2g']),
    ('s07-serialization', 's07.SerializationKt', []),
    ('s08-testing', 's08.TestingKt', []),
    ('s14-interop', 's14.MainKt', []),
    ('s14-javap-companion', ('javap', ['-p'], 's14.FeeRule'), []),
    ('s14-javap-interop', ('javap', ['-p'], 's14.Interop'), []),
    ('s14-javap-tariff', ('javap', ['-p', '-c'], 's14.Tariff'), []),
    ('s14-javap-throws', ('javap-grep', ['-v'], 's14.Interop', r'readRegistry|Exceptions:|throws'), []),
    ('s14-javac-neg', ('javac-neg', 'extra/interop-neg'), []),
    ('s15-channels', 's15.ChannelsKt', []),
    ('s15-javap-statemachine', ('javap-grep', ['-c', '-p'], 's04.StateMachineKt', r'tableswitch|COROUTINE_SUSPENDED|throwOnFailure|resume|-2147483648|iand|static final java.lang.Object \w+\('), []),
]


def classpath():
    cpfile = os.path.join(ROOT, 'cp.txt')
    subprocess.run(['mvn', '-q', '-B', 'package', '-DskipTests'], cwd=ROOT, check=True, shell=os.name == 'nt')
    subprocess.run(['mvn', '-q', '-B', 'dependency:build-classpath', '-Dmdep.outputFile=cp.txt'], cwd=ROOT, check=True, shell=os.name == 'nt')
    return os.path.join(ROOT, 'target', 'classes') + SEP + open(cpfile, encoding='utf-8').read().strip()


def clean(text):
    text = text.replace(HOME, '~').replace(HOME.replace('\\', '/'), '~').replace('\r\n', '\n')
    return text.replace(ROOT, '<lab>')


JAVAC = os.path.join(JAVA_HOME, 'bin', 'javac')
KOTLINC = os.path.join(HOME, 'tools', 'kotlinc-2.4.21', 'kotlinc', 'bin', 'kotlinc' + ('.bat' if os.name == 'nt' else ''))


def javac_neg(cp, folder):
    '''Компилирует каждый файл папки отдельно и собирает ошибки компилятора.'''
    import tempfile
    parts = []
    for name in sorted(os.listdir(folder)):
        src = os.path.join(folder, name)
        with tempfile.TemporaryDirectory() as d:
            if name.endswith('.java'):
                cmd = [JAVAC, '-encoding', 'UTF-8', '-J-Duser.language=en', '-cp', cp, '-d', d, src]
            elif name.endswith('.kt'):
                argf = os.path.join(d, 'args.txt')
                open(argf, 'w', encoding='utf-8').write('-cp ' + cp.replace(chr(92), '/') + ' -d ' + d.replace(chr(92), '/'))
                cmd = [KOTLINC, '@' + argf, src]
            else:
                continue
            p = subprocess.run(cmd, capture_output=True, cwd=folder, shell=name.endswith('.kt') and os.name == 'nt')
            msg = (p.stdout + p.stderr).decode('utf-8', 'replace').strip()
            parts.append('--- %s: код %d\n%s\n' % (name, p.returncode, msg))
    return clean('\n'.join(parts))


def write(out, what, text):
    head = '# %s, запуск %s, Kotlin 2.4.21, kotlinx.coroutines 1.11.0, Temurin 21.0.10\n# %s\n\n' % (out, datetime.date.today().isoformat(), what)
    with open(os.path.join(ROOT, out + '.txt'), 'w', encoding='utf-8', newline='\n') as f:
        f.write(head + text)


def main():
    only = sys.argv[1] if len(sys.argv) > 1 else ''
    cp = classpath()
    for out, target, jflags in RUNS:
        if not out.startswith(only):
            continue
        grep = None
        if isinstance(target, tuple) and target[0] == 'javac-neg':
            text = javac_neg(cp, os.path.join(ROOT, target[1]))
            write(out, 'javac и kotlinc на файлах ' + target[1], text)
            print(out)
            continue
        if isinstance(target, tuple):
            kind, flags, cls = target[:3]
            grep = target[3] if kind == 'javap-grep' else None
            cmd = [JAVAP, *flags, '-cp', cp, cls]
        else:
            cmd = [JAVA, '-Dstdout.encoding=UTF-8', '-Dstderr.encoding=UTF-8', '-Dfile.encoding=UTF-8', *jflags, '-cp', cp, target]
        p = subprocess.run(cmd, capture_output=True, cwd=ROOT, timeout=600)
        text = p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
        if grep:
            import re
            text = '\n'.join(l for l in text.split('\n') if re.search(grep, l)) + '\n'
        if p.returncode:
            text += '[код возврата %d]\n' % p.returncode
        head = '# %s, запуск %s, Kotlin 2.4.21, kotlinx.coroutines 1.11.0, Temurin 21.0.10\n# %s\n\n' % (
            out, datetime.date.today().isoformat(), ' '.join(os.path.basename(c) if i == 0 else c for i, c in enumerate(cmd) if c != cp))
        with open(os.path.join(ROOT, out + '.txt'), 'w', encoding='utf-8', newline='\n') as f:
            f.write(head + clean(text))
        print(out, 'код', p.returncode)


if __name__ == '__main__':
    main()
