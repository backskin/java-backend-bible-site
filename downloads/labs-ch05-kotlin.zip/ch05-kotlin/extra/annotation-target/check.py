"""Куда Kotlin кладет @NotBlank без цели на параметре-свойстве конструктора: компиляция Props.kt
разными kotlinc и javap -v. Вывод - labs/ch05-spring/s09-annotation-target-versions.txt.

    python -X utf8 check.py
"""
import datetime, glob, os, re, subprocess, tempfile

HOME = os.path.expanduser('~')
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', '..', '..', 'ch05-spring', 's09-annotation-target-versions.txt')
JDK = os.path.join(HOME, '.jdks', 'temurin-21.0.10')
API = glob.glob(os.path.join(HOME, '.m2', 'repository', 'jakarta', 'validation', 'jakarta.validation-api', '3.1.1', '*.jar'))[0]
VERSIONS = ['1.9.25', '2.2.21', '2.3.0', '2.3.20', '2.4.0', '2.4.21']
EXE = '.bat' if os.name == 'nt' else ''


def places(javap):
    """Возвращает места, где стоит NotBlank: field merchantId, param конструктора, getter."""
    found = []
    member, section = None, ''
    for line in javap.splitlines():
        m = re.match(r'  (?:[\w.$<>\[\]]+ )*?(?:[\w$]+\.)*([\w$]+)(\([^)]*\))?;$', line)
        if m and not line.startswith('   '):
            member = m.group(1) + ('(...)' if m.group(2) is not None else '')
        s = re.match(r'\s+(RuntimeVisible\w*Annotations):', line)
        if s:
            section = s.group(1)
        if line.strip().startswith('jakarta.validation.constraints.NotBlank') and member:
            where = 'на параметре' if 'Parameter' in section else 'на самом члене'
            found.append('%s - @NotBlank %s' % (member, where))
    return found


def main():
    lines = ['# s09-annotation-target-versions: Props.kt, kotlinc -jvm-target 17, javap -v -p; запуск %s, Temurin 21.0.10' % datetime.date.today().isoformat(), '']
    for v in VERSIONS:
        kc = os.path.join(HOME, 'tools', 'kotlinc-' + v, 'kotlinc', 'bin', 'kotlinc' + EXE)
        out = tempfile.mkdtemp()
        env = dict(os.environ, JAVA_HOME=JDK)
        p = subprocess.run([kc, '-jvm-target', '17', '-cp', API, '-d', out, os.path.join(HERE, 'Props.kt')],
                           capture_output=True, text=True, env=env, shell=os.name == 'nt')
        warn = [l for l in (p.stdout + p.stderr).splitlines() if 'warning' in l or 'error' in l]
        cls = os.path.join(out, 'dev', 'team', 'ch05target', 'AcquiringProps.class')
        jv = subprocess.run([os.path.join(JDK, 'bin', 'javap'), '-v', '-p', cls], capture_output=True, text=True).stdout
        lines.append('== Kotlin %s' % v)
        lines += ['  компилятор: ' + re.sub(r'^.*Props\.kt:', 'Props.kt:', w) for w in warn]
        lines += ['  ' + x for x in places(jv)]
    open(OUT, 'w', encoding='utf-8', newline='\n').write('\n'.join(lines) + '\n')
    print('\n'.join(lines))


prev = ''
if __name__ == '__main__':
    main()
