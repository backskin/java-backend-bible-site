package dev.team.ch05target

import jakarta.validation.constraints.NotBlank

// Аннотация без цели на свойстве из конструктора: куда её кладет компилятор.
data class AcquiringProps(
    @NotBlank val merchantId: String,
    @field:NotBlank val terminalId: String,
)
