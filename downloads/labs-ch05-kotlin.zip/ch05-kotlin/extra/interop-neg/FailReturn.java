/** Проверка без return после функции с типом Nothing. */
class FailReturn {
    String check(String account) {
        if (account.startsWith("40")) {
            return account;
        }
        s14.Interop.fail("не счет");
    }
}
