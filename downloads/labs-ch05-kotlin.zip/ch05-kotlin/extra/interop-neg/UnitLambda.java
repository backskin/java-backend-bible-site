/** Лямбда без return Unit.INSTANCE для (String) -> Unit. */
class UnitLambda {
    void run() {
        s14.Interop.onEvent(id -> System.out.println(id));
    }
}
