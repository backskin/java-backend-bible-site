/** Метод companion без @JvmStatic через имя класса. */
class CompanionCall {
    Object run() {
        return s14.FeeRule.parse("2");
    }
}
