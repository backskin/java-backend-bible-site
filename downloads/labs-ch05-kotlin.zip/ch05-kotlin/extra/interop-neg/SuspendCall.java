/** Вызов suspend-функции напрямую. */
class SuspendCall {
    Object run() {
        return s14.Interop.limit("40817810000000000002");
    }
}
