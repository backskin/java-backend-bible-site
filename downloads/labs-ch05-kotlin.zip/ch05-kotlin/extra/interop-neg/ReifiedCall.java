/** Вызов inline-функции с reified-параметром. */
class ReifiedCall {
    String run() {
        return s14.Interop.typeName();
    }
}
