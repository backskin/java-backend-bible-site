package s14neg

import s14.PlainListener

/** Лямбда вместо обычного интерфейса Kotlin без fun. */
val l = PlainListener { println(it) }
