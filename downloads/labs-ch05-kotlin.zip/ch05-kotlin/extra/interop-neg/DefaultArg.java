/** Конструктор data class без аргумента по умолчанию. */
class DefaultArg {
    Object run() {
        return new s14.Transfer("a", "b", 100L);
    }
}
