import java.io.IOException;
import java.nio.file.Path;

/** Ловит IOException у метода без @Throws. */
class NoThrows {
    void run() {
        try {
            s14.Interop.readRegistryNoThrows(Path.of("r.txt"));
        } catch (IOException e) {
        }
    }
}
