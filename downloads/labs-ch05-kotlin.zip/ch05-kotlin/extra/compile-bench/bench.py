"""Замер времени компиляции: Kotlin 1.9.25 (K1), Kotlin 2.4.21 (K2) и javac 21 на одинаковом по смыслу коде.

Генерирует N файлов: в каждом модель платежа, сервис с проверками, when по состояниям, лямбды и расширения.
Каждый компилятор запускается холодным процессом RUNS раз, в вывод идут все замеры и медиана.

    python -X utf8 bench.py [N] [RUNS]
"""
import os, shutil, statistics, subprocess, sys, time, datetime

HOME = os.path.expanduser('~')
HERE = os.path.dirname(os.path.abspath(__file__))
JDK = os.path.join(HOME, '.jdks', 'temurin-21.0.10')
N = int(sys.argv[1]) if len(sys.argv) > 1 else 300
RUNS = int(sys.argv[2]) if len(sys.argv) > 2 else 5
EXE = '.bat' if os.name == 'nt' else ''

KT = '''package gen.p{i}

import java.math.BigDecimal

enum class Status{i} {{ NEW, AUTHORIZED, CAPTURED, FAILED }}

data class Payment{i}(val id: Long, val account: String, val amount: BigDecimal, val status: Status{i}, val tags: List<String> = emptyList())

fun Payment{i}.isLarge(): Boolean = amount > BigDecimal("100000")

class PaymentService{i}(private val limits: Map<String, BigDecimal>) {{
    fun validate(p: Payment{i}): List<String> {{
        val errors = mutableListOf<String>()
        if (p.account.length != 20) errors += "account"
        val limit = limits[p.account] ?: BigDecimal.ZERO
        if (p.amount > limit) errors += "limit"
        return errors
    }}

    fun next(p: Payment{i}): Status{i} = when (p.status) {{
        Status{i}.NEW -> if (validate(p).isEmpty()) Status{i}.AUTHORIZED else Status{i}.FAILED
        Status{i}.AUTHORIZED -> Status{i}.CAPTURED
        Status{i}.CAPTURED, Status{i}.FAILED -> p.status
    }}

    fun report(ps: List<Payment{i}>): Map<Status{i}, BigDecimal> =
        ps.filter {{ !it.isLarge() }}
            .groupBy {{ it.status }}
            .mapValues {{ (_, v) -> v.fold(BigDecimal.ZERO) {{ acc, x -> acc + x.amount }} }}

    fun describe(p: Payment{i}?): String = p?.let {{ "${{it.id}}:${{it.status}}" }} ?: "none"
}}
'''

JAVA = '''package gen.p{i};

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

public class PaymentService{i} {{
    public enum Status {{ NEW, AUTHORIZED, CAPTURED, FAILED }}

    public record Payment(long id, String account, BigDecimal amount, Status status, List<String> tags) {{
        public boolean isLarge() {{ return amount.compareTo(new BigDecimal("100000")) > 0; }}
    }}

    private final Map<String, BigDecimal> limits;

    public PaymentService{i}(Map<String, BigDecimal> limits) {{ this.limits = limits; }}

    public List<String> validate(Payment p) {{
        List<String> errors = new ArrayList<>();
        if (p.account().length() != 20) errors.add("account");
        BigDecimal limit = limits.getOrDefault(p.account(), BigDecimal.ZERO);
        if (p.amount().compareTo(limit) > 0) errors.add("limit");
        return errors;
    }}

    public Status next(Payment p) {{
        return switch (p.status()) {{
            case NEW -> validate(p).isEmpty() ? Status.AUTHORIZED : Status.FAILED;
            case AUTHORIZED -> Status.CAPTURED;
            case CAPTURED, FAILED -> p.status();
        }};
    }}

    public Map<Status, BigDecimal> report(List<Payment> ps) {{
        return ps.stream().filter(x -> !x.isLarge())
            .collect(Collectors.groupingBy(Payment::status,
                Collectors.reducing(BigDecimal.ZERO, Payment::amount, BigDecimal::add)));
    }}

    public String describe(Payment p) {{
        return Optional.ofNullable(p).map(it -> it.id() + ":" + it.status()).orElse("none");
    }}
}}
'''


def gen(root):
    shutil.rmtree(root, ignore_errors=True)
    for i in range(N):
        d = os.path.join(root, 'kt', 'gen', 'p%d' % i); os.makedirs(d)
        open(os.path.join(d, 'P%d.kt' % i), 'w', encoding='utf-8').write(KT.format(i=i))
        d = os.path.join(root, 'java', 'gen', 'p%d' % i); os.makedirs(d)
        open(os.path.join(d, 'PaymentService%d.java' % i), 'w', encoding='utf-8').write(JAVA.format(i=i))


def files(root, ext):
    out = []
    for dp, _, fs in os.walk(root):
        out += [os.path.join(dp, f) for f in fs if f.endswith(ext)]
    return out


def timed(cmd, env):
    t0 = time.perf_counter()
    p = subprocess.run(cmd, capture_output=True, env=env)
    dt = time.perf_counter() - t0
    if p.returncode:
        print(p.stdout.decode()[-2000:], p.stderr.decode()[-2000:])
        raise SystemExit('ошибка компиляции')
    return dt


def main():
    work = os.path.join(HERE, 'work')
    gen(work)
    env0 = dict(os.environ, JAVA_HOME=JDK, PATH=os.path.join(JDK, 'bin') + os.pathsep + os.environ['PATH'])
    env0.pop('JAVA_OPTS', None)
    env = dict(env0, JAVA_OPTS='-Xmx2g -Xms128m')
    kt = files(os.path.join(work, 'kt'), '.kt'); jv = files(os.path.join(work, 'java'), '.java')
    argfile_kt = os.path.join(work, 'kt.args'); open(argfile_kt, 'w').write('\n'.join(f.replace('\\', '/') for f in kt))
    argfile_jv = os.path.join(work, 'java.args'); open(argfile_jv, 'w').write('\n'.join('"%s"' % f.replace('\\', '/') for f in jv))
    out = os.path.join(work, 'out')
    compilers = [
        ('Kotlin 1.9.25 (K1)', [os.path.join(HOME, 'tools', 'kotlinc-1.9.25', 'kotlinc', 'bin', 'kotlinc' + EXE), '-jvm-target', '17', '-d', out, '@' + argfile_kt]),
        ('Kotlin 2.4.21 (K2)', [os.path.join(HOME, 'tools', 'kotlinc-2.4.21', 'kotlinc', 'bin', 'kotlinc' + EXE), '-jvm-target', '21', '-d', out, '@' + argfile_kt]),
        ('javac 21.0.10', [os.path.join(JDK, 'bin', 'javac'), '-J-Xmx2g', '-d', out, '@' + argfile_jv]),
    ]
    lines = ['# Время компиляции, %s; %d файлов (%d строк Kotlin, %d строк Java); холодный процесс, %d запусков' % (
        datetime.date.today().isoformat(), N, sum(len(open(f, encoding='utf-8').readlines()) for f in kt),
        sum(len(open(f, encoding='utf-8').readlines()) for f in jv), RUNS),
        '# машина: %d логических ядер, Windows; компиляторы запускаются одной JVM Temurin 21.0.10, куча -Xmx2g' % os.cpu_count()]
    for name, cmd in compilers[:2]:
        shutil.rmtree(out, ignore_errors=True)
        p = subprocess.run(cmd, capture_output=True, env=env0)
        err = (p.stdout + p.stderr).decode('utf-8', 'replace')
        oom = 'OutOfMemoryError' in err
        lines.append('# %s с кучей по умолчанию из скрипта kotlinc (-Xmx512M): код %d%s' % (name, p.returncode, ', OutOfMemoryError' if oom else ''))
    lines.append('')
    for name, cmd in compilers:
        ts = []
        for _ in range(RUNS):
            shutil.rmtree(out, ignore_errors=True)
            ts.append(timed(cmd, env))
        lines.append('%-20s медиана %.1f с; все: %s' % (name, statistics.median(ts), ', '.join('%.1f' % t for t in ts)))
        print(lines[-1])
    open(os.path.join(HERE, '..', '..', 's13-compile-time.txt'), 'w', encoding='utf-8', newline='\n').write('\n'.join(lines) + '\n')
    shutil.rmtree(work, ignore_errors=True)


if __name__ == '__main__':
    main()
