package t
sealed interface State
data object A : State
data class B(val x: Int) : State
