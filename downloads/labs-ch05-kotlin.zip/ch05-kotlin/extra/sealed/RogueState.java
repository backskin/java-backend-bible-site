// Java-класс пытается реализовать Kotlin sealed interface s02.PaymentState.
public final class RogueState implements s02.PaymentState { }
