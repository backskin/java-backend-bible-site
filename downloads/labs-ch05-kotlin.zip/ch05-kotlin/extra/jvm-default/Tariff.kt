package s14

interface Tariff {
    fun base(): Long
    fun withFee(): Long = base() + 30
}
