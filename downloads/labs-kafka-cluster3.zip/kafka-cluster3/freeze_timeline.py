"""Брокер «завис» (как при долгой паузе GC или потере процессорного времени): SIGSTOP процессу kc-1 на узле kind, соединения остаются открытыми.
Смотрим, когда контроллер выведет брокера из игры (broker.session.timeout.ms=9000) и когда сократится ISR. Через FREEZE секунд процесс размораживается (SIGCONT)."""
import os
import re
import subprocess
import sys
import time

FREEZE = int(sys.argv[1]) if len(sys.argv) > 1 else 40
TOTAL = int(sys.argv[2]) if len(sys.argv) > 2 else 120
TARGET = sys.argv[3] if len(sys.argv) > 3 else "kc-1"
VIA = "kc-2" if TARGET != "kc-2" else "kc-0"
KC = r"C:\Users\backskin\java-backend-bible\tmp\kind-bin\kubeconfig"
env = dict(os.environ, KUBECONFIG=KC, MSYS_NO_PATHCONV="1")


def run(*cmd, timeout=60):
    return subprocess.run(list(cmd), capture_output=True, text=True, env=env, timeout=timeout).stdout


def prepare():
    run("kubectl", "-n", "kafka3", "exec", VIA, "--", "sh", "-c", "echo request.timeout.ms=2000 > /tmp/c.properties; echo default.api.timeout.ms=4000 >> /tmp/c.properties; echo retries=0 >> /tmp/c.properties")


def describe():
    out = run("kubectl", "-n", "kafka3", "exec", VIA, "--", "/opt/kafka/bin/kafka-topics.sh", "--bootstrap-server", f"{VIA}.kc.kafka3.svc.cluster.local:9092", "--command-config", "/tmp/c.properties", "--describe", "--topic", "pay", timeout=15)
    rows = {}
    for m in re.finditer(r"Partition: (\d+)\s+Leader: (\S+)\s+Replicas: (\S+)\s+Isr: (\S*)", out):
        rows[int(m.group(1))] = (m.group(2), m.group(4))
    return rows


def line(rows):
    return "  ".join(f"p{p}: лидер {l} ISR [{i}]" for p, (l, i) in sorted(rows.items()))


prepare()
node = run("kubectl", "-n", "kafka3", "get", "pod", TARGET, "-o", "jsonpath={.spec.nodeName}").strip()
pid = None
for p in run("docker", "exec", node, "pgrep", "-f", "kafka.Kafka").split():
    envs = run("docker", "exec", node, "sh", "-c", f"tr '\\0' '\\n' < /proc/{p}/environ | grep ^HOSTNAME=")
    if f"HOSTNAME={TARGET}" in envs:
        pid = p
print(f"под {TARGET} на узле {node}, pid JVM {pid}", flush=True)
t0 = time.time()
prev = describe()
print(f"t={0:>4.0f} с  до заморозки: {line(prev)}", flush=True)
run("docker", "exec", node, "kill", "-STOP", pid)
t_stop = time.time()
print(f"t={t_stop - t0:>4.0f} с  брокер {int(TARGET.split(chr(45))[1]) + 1} заморожен (SIGSTOP), соединения открыты", flush=True)
thawed = False
while time.time() - t0 < TOTAL:
    if not thawed and time.time() - t_stop >= FREEZE:
        run("docker", "exec", node, "kill", "-CONT", pid)
        thawed = True
        print(f"t={time.time() - t0:>4.0f} с  брокер {int(TARGET.split(chr(45))[1]) + 1} разморожен (SIGCONT)", flush=True)
    try:
        cur = describe()
    except Exception as e:
        print(f"t={time.time() - t0:>4.0f} с  describe не ответил: {type(e).__name__}", flush=True)
        continue
    if cur and cur != prev:
        print(f"t={time.time() - t0:>4.0f} с  изменение:    {line(cur)}", flush=True)
        prev = cur
    time.sleep(1)
print("конец наблюдения", flush=True)
