# Кластер из трех брокеров KRaft и опыты с лидерами, координатором и значениями по умолчанию (глава 29, подразделы 1.3, 3.4, 6.15)

Проверено 2026-10-21: kind (3 узла), Apache Kafka 3.9.1 (образ `apache/kafka:3.9.1`), клиент Kafka 4.2.1, Python 3.14, Windows + Git Bash; выводы этих опытов в `s29-*.txt` сняты на 3.9.1. С 2026-10-30 манифест поднимает Kafka 4.3.1 (опыты `labs/kafka-capacity` и логи брокера).

## Состав

- `logs_lab.sh`, `standalone_lab.sh` - журналы брокера и контроллера при типовых событиях (16.12), выводы `s29-logs-*.txt`; `log4j2-stdout.yaml` - свой log4j2 для stdout, подключается ConfigMap `kafka-log4j2`.

- `kafka3.yaml` - StatefulSet из трех узлов KRaft (каждый и брокер, и контроллер), кластер `kafka3`, внутренний адрес `kc-N.kc.kafka3.svc.cluster.local:9092`. Переопределены только идентификатор узла, слушатели, роли и список контроллеров - остальное настоящие значения по умолчанию.
- `kt.sh` - запуск утилиты Kafka внутри пода: `./kt.sh kc-0 kafka-topics.sh --bootstrap-server kc-0.kc.kafka3.svc.cluster.local:9092 --describe --topic pay`.
- `leader_timeline.py` - удаляет под брокера и печатает хронологию смены лидеров и ISR (опыт 3.4, убитый брокер); `freeze_timeline.py` - замораживает JVM брокера (`SIGSTOP` через `docker exec` в узел kind) и печатает хронологию (опыт 3.4, зависший брокер).
- `coordinator_lab.py` - сопоставление `group.id` → партиция `__consumer_offsets` → лидер → координатор (6.15); `coord_failover.py coordinator|controller` - отказ координатора группы или активного контроллера.
- `DefaultsDump.java` (клиентские умолчания из `ConfigDef`) и `SpringDefaults.java` (умолчания Spring Boot и Spring Kafka) - для подраздела 1.3; для запуска нужен Maven-проект с зависимостями `kafka-clients` (и `spring-boot-kafka` для второго класса).

## Подготовка

```bash
kubectl apply -f kafka3.yaml
kubectl -n kafka3 get pods            # дождаться kc-0, kc-1, kc-2 в состоянии Running
```

Сценарные скрипты содержат путь к `kubeconfig` кластера kind в переменной `KC` и требуют `kubectl`; поправьте его под свою машину. Тема для опытов: `./kt.sh kc-0 kafka-topics.sh --bootstrap-server kc-0.kc.kafka3.svc.cluster.local:9092 --create --topic pay --partitions 6 --replication-factor 3`.

## Что ожидать

- Раскладка `pay`: лидер каждой партиции - первая реплика в списке; первые три партиции идут "полосами".
- Убитый брокер: лидеры меняются за секунды; вернувшийся брокер входит в ISR, но лидерство возвращается через `leader.imbalance.check.interval.seconds` (300 с) или командой `kafka-leader-election.sh --election-type PREFERRED`.
- Замороженный брокер: смена лидеров не раньше `broker.session.timeout.ms` (9000 мс).
- Координатор группы совпадает с лидером партиции `abs(hashCode(group.id)) % 50`; число партиций служебной темы менять нельзя.
