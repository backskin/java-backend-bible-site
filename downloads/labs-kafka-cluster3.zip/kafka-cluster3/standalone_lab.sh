#!/bin/bash
# Глава 29, 16.12: события, для которых нужен отдельный брокер Kafka 4.3.1 в Docker.
#   acl  — SASL/PLAIN, StandardAuthorizer: отказ в доступе и разрешённая операция в kafka-authorizer.log
#   disk — каталог данных на tmpfs 48 МБ: запись до переполнения, что пишет server.log
# Запуск: bash standalone_lab.sh acl > s29-logs-acl.txt; bash standalone_lab.sh disk > s29-logs-disk.txt
export MSYS_NO_PATHCONV=1
K=/opt/kafka/bin
start() {   # $1 — имя контейнера, $2 — дополнительные опции docker run, $3 — свойства брокера
  docker rm -f "$1" >/dev/null 2>&1
  docker run -d --name "$1" $2 --entrypoint sh apache/kafka:4.3.1 -c "
cat > /tmp/s.properties <<P
node.id=1
process.roles=broker,controller
controller.listener.names=CONTROLLER
controller.quorum.bootstrap.servers=localhost:9093
offsets.topic.replication.factor=1
transaction.state.log.replication.factor=1
transaction.state.log.min.isr=1
$3
P
$K/kafka-storage.sh format -t \$($K/kafka-storage.sh random-uuid) -c /tmp/s.properties --standalone >/dev/null
exec $K/kafka-server-start.sh /tmp/s.properties" >/dev/null
  for i in $(seq 1 60); do docker exec "$1" sh -c "grep -q 'Kafka Server started' /opt/kafka/logs/server.log" 2>/dev/null && return; sleep 1; done
  echo "брокер $1 не запустился"; docker logs "$1" 2>&1 | tail -5; exit 1
}

case "$1" in
acl)
  start kacl "" "listeners=SASL_PLAINTEXT://:9092,PLAINTEXT://:9094,CONTROLLER://:9093
advertised.listeners=SASL_PLAINTEXT://localhost:9092,PLAINTEXT://localhost:9094
listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT,SASL_PLAINTEXT:SASL_PLAINTEXT
inter.broker.listener.name=PLAINTEXT
sasl.enabled.mechanisms=PLAIN
listener.name.sasl_plaintext.plain.sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username=\"admin\" password=\"admin-secret\" user_admin=\"admin-secret\" user_alice=\"alice-secret\";
authorizer.class.name=org.apache.kafka.metadata.authorizer.StandardAuthorizer
super.users=User:admin;User:ANONYMOUS"
  docker exec kacl sh -c "printf 'security.protocol=SASL_PLAINTEXT\nsasl.mechanism=PLAIN\nsasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username=\"alice\" password=\"alice-secret\";\n' > /tmp/alice.properties"
  docker exec kacl $K/kafka-topics.sh --bootstrap-server localhost:9094 --create --topic pay.events --partitions 1 >/dev/null 2>&1
  echo "=== 1. alice без ACL пишет в pay.events"
  docker exec kacl sh -c "echo test | timeout 20 $K/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic pay.events --producer.config /tmp/alice.properties 2>&1 | grep -m1 -oE 'TopicAuthorizationException[^.]*|Not authorized[^.]*'" | sed 's/^/  клиент: /'
  docker exec kacl sh -c "cat /opt/kafka/logs/kafka-authorizer.log | cut -c1-400 | tail -3" | sed 's/^/  kafka-authorizer.log: /'
  echo "=== 2. alice получает ACL на запись; уровень kafka.authorizer.logger поднимается до DEBUG"
  docker exec kacl $K/kafka-acls.sh --bootstrap-server localhost:9094 --add --allow-principal User:alice --operation Write --operation Describe --topic pay.events >/dev/null
  docker exec kacl $K/kafka-configs.sh --bootstrap-server localhost:9094 --alter --entity-type broker-loggers --entity-name 1 --add-config kafka.authorizer.logger=DEBUG >/dev/null
  n=$(docker exec kacl sh -c "wc -l < /opt/kafka/logs/kafka-authorizer.log")
  docker exec kacl sh -c "echo test | timeout 20 $K/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic pay.events --producer.config /tmp/alice.properties >/dev/null 2>&1"
  echo "  новых строк в kafka-authorizer.log: $(docker exec kacl sh -c "tail -n +$((n+1)) /opt/kafka/logs/kafka-authorizer.log | wc -l")"
  docker exec kacl sh -c "tail -n +$((n+1)) /opt/kafka/logs/kafka-authorizer.log | grep -E 'Allowed|Denied' | cut -c1-400 | sort -u -t'=' -k3,3 | head -3" | sed 's/^/  kafka-authorizer.log: /'
  docker rm -f kacl >/dev/null ;;
disk)
  start kdisk "--tmpfs /data:size=48m,uid=1000,gid=1000" "listeners=PLAINTEXT://:9092,CONTROLLER://:9093
advertised.listeners=PLAINTEXT://localhost:9092
listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
log.dirs=/data/kafka-logs
metadata.log.dir=/tmp/meta"
  docker exec kdisk $K/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic pay.events --partitions 1 >/dev/null 2>&1
  echo "=== каталог данных на tmpfs 48 МБ, запись 80 МБ"
  docker exec kdisk $K/kafka-producer-perf-test.sh --topic pay.events --num-records 80000 --record-size 1024 --throughput -1 \
    --producer-props bootstrap.servers=localhost:9092 acks=1 delivery.timeout.ms=20000 request.timeout.ms=5000 2>&1 | grep -E 'records sent|Exception' | tail -2 | cut -c1-300 | sed 's/^/  производитель: /'
  sleep 10
  echo "  брокер работает: $(docker inspect -f '{{.State.Running}}' kdisk), код выхода JVM: $(docker inspect -f '{{.State.ExitCode}}' kdisk)"
  docker logs kdisk 2>&1 | grep -E 'ERROR|FATAL|No space|offline|Offline|Shutdown|shut down|Stopping|failed' | grep -vE '^\s+at ' | cut -c1-400 | head -14 | sed 's/^/  stdout (= server.log): /'
  docker rm -f kdisk >/dev/null ;;
esac
