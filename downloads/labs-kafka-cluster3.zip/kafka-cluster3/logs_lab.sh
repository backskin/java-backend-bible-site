#!/bin/bash
# Глава 29, 16.12: какие строки пишут журналы брокера и контроллера Kafka 4.3.1 при типовых событиях.
# Кластер kafka3 (kafka3.yaml): узлы kc-0..kc-2 = node.id 1..3, каждый и брокер, и контроллер.
# Запуск: bash logs_lab.sh <сценарий> > s29-logs-<сценарий>.txt
#   failover   — SIGKILL JVM брокера, который не является активным контроллером
#   isr        — SIGSTOP брокера на 45 с и возврат (сжатие и расширение ISR)
#   controller — SIGKILL JVM активного контроллера
#   rebalance  — два потребителя входят в группу и выходят из неё
#   quota      — квота производителя 10 КБ/с и запись 2 МБ
#   unclean    — партиция RF 2 без синхронных реплик и unclean.leader.election.enable=true
export KUBECONFIG="$(cygpath -w /c/Users/backskin/java-backend-bible/tmp/kind-bin/kubeconfig)"
export MSYS_NO_PATHCONV=1
B=kc-0.kc.kafka3.svc.cluster.local:9092
FILES="server.log controller.log state-change.log kafka-request.log kafka-authorizer.log log-cleaner.log"
k() { kubectl -n kafka3 exec "$1" -- "${@:2}"; }
kt() { k kc-0 /opt/kafka/bin/"$1" --bootstrap-server $B "${@:2}" 2>/dev/null; }

declare -A MARK
mark() { for p in kc-0 kc-1 kc-2; do for f in $FILES; do MARK[$p/$f]=$(k $p sh -c "wc -l < /opt/kafka/logs/$f" 2>/dev/null || echo 0); done; done; }
# новые строки с момента mark(), отфильтрованные регуляркой; длинные строки обрезаются
since() { local pat="$1"; for p in kc-0 kc-1 kc-2; do for f in $FILES; do
    local from=$(( ${MARK[$p/$f]:-0} + 1 ))
    k $p sh -c "tail -n +$from /opt/kafka/logs/$f" 2>/dev/null | grep -E "$pat" | cut -c1-420 | sed "s|^|$p $f: |" | head -${2:-12}
  done; done; }

node_pid() {   # узел kind и pid JVM брокера в поде $1
  NODE=$(kubectl -n kafka3 get pod "$1" -o jsonpath='{.spec.nodeName}')
  for p in $(docker exec $NODE pgrep -f kafka.Kafka); do
    docker exec $NODE sh -c "tr '\0' '\n' < /proc/$p/environ | grep -q ^HOSTNAME=$1\$" && PID=$p
  done
}
active_controller() { kt kafka-metadata-quorum.sh describe --status | awk -F': *' '/LeaderId/{print $2}'; }
wait_ready() { for i in $(seq 1 60); do [ "$(kubectl -n kafka3 get pod "$1" -o jsonpath='{.status.containerStatuses[0].ready}')" = true ] && return; sleep 5; done; }

case "$1" in
failover)
  kt kafka-topics.sh --create --if-not-exists --topic logs.pay --partitions 3 --replication-factor 3 >/dev/null
  ctrl=$(active_controller); victim=kc-0; [ "$ctrl" = 1 ] && victim=kc-1
  echo "=== отказ брокера $victim (node.id $(( ${victim#kc-} + 1 ))); активный контроллер — node.id $ctrl"
  kt kafka-topics.sh --describe --topic logs.pay | grep Partition: | sed 's/^/  до: /'
  mark; node_pid $victim; docker exec $NODE kill -9 $PID; sleep 25
  kt kafka-topics.sh --describe --topic logs.pay | grep Partition: | sed 's/^/  после: /'
  since 'fenc|Fenc|unfenc|Leader|leader|ISR|isr|logs.pay|registration|heartbeat' 10
  wait_ready $victim ;;
isr)
  kt kafka-topics.sh --create --if-not-exists --topic logs.pay --partitions 3 --replication-factor 3 >/dev/null
  victim=kc-2; [ "$(active_controller)" = 3 ] && victim=kc-1
  echo "=== брокер $victim заморожен (SIGSTOP) на 45 с, затем возвращён"
  mark; node_pid $victim; docker exec $NODE kill -STOP $PID; sleep 45
  kt kafka-topics.sh --describe --topic logs.pay | grep Partition: | sed 's/^/  заморожен: /'
  docker exec $NODE kill -CONT $PID; sleep 30
  kt kafka-topics.sh --describe --topic logs.pay | grep Partition: | sed 's/^/  возвращён: /'
  since 'ISR|isr|fenc|Fenc|unfenc|logs.pay' 10 ;;
controller)
  ctrl=$(active_controller); victim=kc-$(( ctrl - 1 ))
  echo "=== SIGKILL активного контроллера node.id $ctrl ($victim)"
  mark; node_pid $victim; docker exec $NODE kill -9 $PID; sleep 20
  echo "  новый активный контроллер: node.id $(active_controller)"
  since 'active controller|Leader|leader|epoch|Epoch|elect|resign|Resign|transition|Transition' 10
  wait_ready $victim ;;
rebalance)
  kt kafka-topics.sh --create --if-not-exists --topic logs.pay --partitions 3 --replication-factor 3 >/dev/null
  echo "=== группа logs-demo: вступают два потребителя, затем по одному выходят"
  mark
  k kc-1 sh -c "timeout 25 /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server $B --topic logs.pay --group logs-demo >/dev/null 2>&1 &
                sleep 8; timeout 10 /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server $B --topic logs.pay --group logs-demo >/dev/null 2>&1; sleep 12"
  since 'logs-demo' 14 ;;
quota)
  kt kafka-topics.sh --create --if-not-exists --topic logs.quota --partitions 1 --replication-factor 3 >/dev/null
  kt kafka-configs.sh --alter --entity-type clients --entity-name quota-demo --add-config producer_byte_rate=10240 >/dev/null
  echo "=== квота producer_byte_rate=10240 для client.id quota-demo, запись 2 МБ"
  for lvl in INFO DEBUG; do
    for n in 1 2 3; do kt kafka-configs.sh --alter --entity-type broker-loggers --entity-name $n --add-config kafka.server.ClientQuotaManager=$lvl >/dev/null; done
    mark
    k kc-1 /opt/kafka/bin/kafka-producer-perf-test.sh --topic logs.quota --num-records 2000 --record-size 1024 --throughput -1 \
      --producer-props bootstrap.servers=$B client.id=quota-demo 2>/dev/null | tail -1 | sed "s/^/  уровень $lvl, производитель: /"
    echo "  строк про квоту в журналах при уровне $lvl: $(since 'uota|hrottl' 1000 | wc -l)"
    since 'uota|hrottl' 4
  done
  for n in 1 2 3; do kt kafka-configs.sh --alter --entity-type broker-loggers --entity-name $n --delete-config kafka.server.ClientQuotaManager >/dev/null; done
  kt kafka-configs.sh --alter --entity-type clients --entity-name quota-demo --delete-config producer_byte_rate >/dev/null ;;
isrlag)
  kt kafka-topics.sh --create --if-not-exists --topic logs.lag --replica-assignment 1:2:3 >/dev/null 2>&1
  echo "=== живой, но медленный последователь: поду брокера 3 (kc-2) урезан процессор до 20m, запись 5 МБ/с в течение минуты в logs.lag"
  kubectl -n kafka3 patch pod kc-2 --subresource resize -p '{"spec":{"containers":[{"name":"kafka","resources":{"limits":{"cpu":"20m"},"requests":{"cpu":"20m"}}}]}}' >/dev/null
  sleep 5; mark
  ( k kc-1 /opt/kafka/bin/kafka-producer-perf-test.sh --topic logs.lag --num-records 300000 --record-size 1024 --throughput 5000      --producer-props bootstrap.servers=$B acks=1 2>/dev/null | tail -1 | sed 's/^/  производитель: /' ) &
  for t in 20 40 55; do sleep $(( t == 20 ? 20 : t == 40 ? 20 : 15 )); kt kafka-topics.sh --describe --topic logs.lag | grep Partition: | sed "s/^/  через $t с записи: /"; done
  wait
  kubectl -n kafka3 patch pod kc-2 --subresource resize -p '{"spec":{"containers":[{"name":"kafka","resources":{"limits":{"cpu":"4"},"requests":{"cpu":"100m"}}}]}}' >/dev/null
  sleep 40
  kt kafka-topics.sh --describe --topic logs.lag | grep Partition: | sed 's/^/  процессор возвращён: /'
  since 'Shrink|Expand|logs.lag|fenc' 8 ;;
unclean)
  kt kafka-topics.sh --delete --topic logs.uncl >/dev/null; sleep 3
  kt kafka-topics.sh --create --topic logs.uncl --replica-assignment 1:2 >/dev/null; sleep 3
  echo "=== партиция logs.uncl-0 на брокерах 1 (лидер) и 2"
  node_pid kc-1; N2=$NODE; P2=$PID; node_pid kc-0; N1=$NODE; P1=$PID
  docker exec $N2 kill -STOP $P2; sleep 40
  kt kafka-topics.sh --describe --topic logs.uncl | grep Partition: | sed 's/^/  брокер 2 заморожен: /'
  k kc-2 sh -c "seq 1 100 | /opt/kafka/bin/kafka-console-producer.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --topic logs.uncl --producer-property acks=1 >/dev/null 2>&1"
  echo "  записано 100 сообщений, пока в ISR только брокер 1"
  mark
  docker exec $N1 kill -STOP $P1; docker exec $N2 kill -CONT $P2; sleep 30
  k kc-2 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --describe --topic logs.uncl 2>/dev/null | grep Partition: | sed 's/^/  брокер 1 заморожен, 2 вернулся: /'
  k kc-2 /opt/kafka/bin/kafka-configs.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --alter --entity-type topics --entity-name logs.uncl --add-config unclean.leader.election.enable=true >/dev/null 2>&1
  sleep 15
  k kc-2 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --describe --topic logs.uncl 2>/dev/null | grep Partition: | sed 's/^/  после unclean.leader.election.enable=true: /'
  k kc-2 /opt/kafka/bin/kafka-get-offsets.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --topic logs.uncl 2>/dev/null | sed 's/^/  смещение конца на новом лидере: /'
  docker exec $N1 kill -CONT $P1; sleep 20
  since 'logs.uncl|nclean|unclean' 10 ;;
unclean2)
  kt kafka-topics.sh --delete --topic logs.uncl >/dev/null; sleep 3
  kt kafka-topics.sh --create --topic logs.uncl --replica-assignment 1:2 >/dev/null; sleep 3
  echo "=== то же, но лидер (брокер 1) падает вместе с каталогом данных (SIGKILL, у пода нет тома)"
  node_pid kc-1; N2=$NODE; P2=$PID; node_pid kc-0; N1=$NODE; P1=$PID
  docker exec $N2 kill -STOP $P2; sleep 40
  kt kafka-topics.sh --describe --topic logs.uncl | grep Partition: | sed 's/^/  брокер 2 заморожен: /'
  k kc-2 sh -c "seq 1 100 | /opt/kafka/bin/kafka-console-producer.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --topic logs.uncl --producer-property acks=1 >/dev/null 2>&1"
  echo "  записано 100 сообщений, пока в ISR только брокер 1"
  k kc-2 /opt/kafka/bin/kafka-configs.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --alter --entity-type topics --entity-name logs.uncl --add-config unclean.leader.election.enable=true >/dev/null 2>&1
  mark
  docker exec $N1 kill -9 $P1; docker exec $N2 kill -CONT $P2; sleep 45
  k kc-2 /opt/kafka/bin/kafka-topics.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --describe --topic logs.uncl 2>/dev/null | grep Partition: | sed 's/^/  после падения лидера: /'
  k kc-2 /opt/kafka/bin/kafka-get-offsets.sh --bootstrap-server kc-2.kc.kafka3.svc.cluster.local:9092 --topic logs.uncl 2>/dev/null | sed 's/^/  смещение конца: /'
  since 'logs.uncl|nclean|ELR|elr' 10
  wait_ready kc-0 ;;
esac
