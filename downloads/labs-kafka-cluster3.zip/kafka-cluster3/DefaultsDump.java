package demo;

import java.util.*;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.ConfigDef;

/** Значения по умолчанию клиентских настроек берутся из самой библиотеки (ConfigDef): так их можно проверить для той версии клиента, что в вашем classpath. Сеть не нужна. */
public class DefaultsDump {
    static void dump(String title, ConfigDef def, String... keys) {
        System.out.println("-- " + title + " (клиент " + org.apache.kafka.common.utils.AppInfoParser.getVersion() + ")");
        for (String k : keys) {
            ConfigDef.ConfigKey ck = def.configKeys().get(k);
            if (ck == null) { System.out.printf("  %-45s нет такой настройки в этой версии%n", k); continue; }
            Object v = ck.defaultValue;
            String shown = v == ConfigDef.NO_DEFAULT_VALUE ? "(нет значения по умолчанию, обязательна)" : String.valueOf(v);
            System.out.printf("  %-45s %s%n", k, shown);
        }
    }

    public static void main(String[] a) {
        dump("Producer", ProducerConfig.configDef(), "acks", "enable.idempotence", "retries", "delivery.timeout.ms", "request.timeout.ms", "linger.ms",
                "batch.size", "buffer.memory", "max.block.ms", "max.in.flight.requests.per.connection", "compression.type", "max.request.size", "retry.backoff.ms", "partitioner.class", "partitioner.adaptive.partitioning.enable", "transaction.timeout.ms", "transactional.id");
        dump("Consumer", ConsumerConfig.configDef(), "group.id", "group.protocol", "enable.auto.commit", "auto.commit.interval.ms", "auto.offset.reset", "isolation.level",
                "max.poll.records", "max.poll.interval.ms", "session.timeout.ms", "heartbeat.interval.ms", "fetch.min.bytes", "fetch.max.wait.ms", "fetch.max.bytes", "max.partition.fetch.bytes",
                "partition.assignment.strategy", "group.instance.id", "client.rack", "metadata.max.age.ms", "request.timeout.ms");
        dump("Admin", AdminClientConfig.configDef(), "request.timeout.ms", "default.api.timeout.ms", "retries", "retry.backoff.ms");
    }
}
