"""Какой брокер координирует группу: считаем abs(hashCode(group.id)) % 50, смотрим лидера этой партиции __consumer_offsets и сверяем с тем, что сообщает kafka-consumer-groups --state."""
import os
import re
import subprocess
import sys

KC = r"C:\Users\backskin\java-backend-bible\tmp\kind-bin\kubeconfig"
env = dict(os.environ, KUBECONFIG=KC, MSYS_NO_PATHCONV="1")
BOOT = "kc-0.kc.kafka3.svc.cluster.local:9092"
POD = sys.argv[1] if len(sys.argv) > 1 else "kc-0"


def tool(name, *args, timeout=120):
    r = subprocess.run(["kubectl", "-n", "kafka3", "exec", POD, "--", f"/opt/kafka/bin/{name}", "--bootstrap-server", BOOT, *args], capture_output=True, text=True, env=env, timeout=timeout)
    return r.stdout + r.stderr


def java_hash(s):
    h = 0
    for ch in s:
        h = (31 * h + ord(ch)) & 0xFFFFFFFF
    return h - (1 << 32) if h >= (1 << 31) else h


def partition_of(group, n=50):
    h = java_hash(group)
    return (0 if h == -(1 << 31) else abs(h)) % n        # Utils.abs(hashCode) % число партиций (модуль, а не битовая маска)


def leaders():
    out = tool("kafka-topics.sh", "--describe", "--topic", "__consumer_offsets")
    m = {}
    for x in re.finditer(r"Partition: (\d+)\s+Leader: (\S+)\s+Replicas: (\S+)\s+Isr: (\S*)", out):
        m[int(x.group(1))] = (x.group(2), x.group(3), x.group(4))
    return m


GROUPS = ["orders-app", "payments-service", "antifraud", "ledger-writer", "notifier", "risk-engine"]
print("== какой брокер координирует группу (3 брокера, __consumer_offsets: 50 партиций, RF=3)")
for g in GROUPS:
    tool("kafka-console-consumer.sh", "--topic", "pay", "--group", g, "--timeout-ms", "6000", "--from-beginning", "--max-messages", "1", timeout=90)
ld = leaders()
ok = 0
for g in GROUPS:
    p = partition_of(g)
    st = tool("kafka-consumer-groups.sh", "--describe", "--group", g, "--state")
    coord = re.search(r":9092\s+\((\d+)\)", st)
    coord_id = coord.group(1) if coord else "?"
    lead = ld.get(p, ("?", "", ""))[0]
    same = (coord_id == lead)
    ok += same
    print(f"  group.id={g:<18} hashCode={java_hash(g):>12}  partition=abs(hash)%50={p:>2}  лидер этой партиции={lead}  координатор по kafka-consumer-groups={coord_id}  {'совпало' if same else 'НЕ совпало'}")
print(f"совпало {ok} из {len(GROUPS)}")
