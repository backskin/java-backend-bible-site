package demo;

import java.util.*;
import org.springframework.boot.kafka.autoconfigure.KafkaProperties;
import org.springframework.kafka.listener.ContainerProperties;

/** Что Spring Boot и Spring Kafka подставляют по умолчанию (без application.yml): клиентские свойства и свойства контейнера слушателя. */
public class SpringDefaults {
    public static void main(String[] a) {
        KafkaProperties kp = new KafkaProperties();
        System.out.println("-- Spring Boot: свойства, которые Boot сам кладёт в продюсер (buildProducerProperties)");
        new TreeMap<>(kp.buildProducerProperties()).forEach((k, v) -> System.out.println("  " + k + " = " + v));
        System.out.println("-- Spring Boot: свойства потребителя (buildConsumerProperties)");
        new TreeMap<>(kp.buildConsumerProperties()).forEach((k, v) -> System.out.println("  " + k + " = " + v));
        System.out.println("-- Spring Boot: spring.kafka.listener.* по умолчанию");
        System.out.println("  ack-mode = " + kp.getListener().getAckMode() + " (null — используется значение контейнера)");
        System.out.println("  concurrency = " + kp.getListener().getConcurrency());
        System.out.println("  poll-timeout = " + kp.getListener().getPollTimeout());
        System.out.println("  type = " + kp.getListener().getType());
        System.out.println("-- Spring Kafka: ContainerProperties по умолчанию");
        ContainerProperties cp = new ContainerProperties("t");
        System.out.println("  ackMode = " + cp.getAckMode());
        System.out.println("  pollTimeout = " + cp.getPollTimeout() + " мс");
        System.out.println("  idleBetweenPolls = " + cp.getIdleBetweenPolls() + " мс");
        System.out.println("  syncCommits = " + cp.isSyncCommits());
        System.out.println("  shutdownTimeout = " + cp.getShutdownTimeout() + " мс");
        System.out.println("  ackCount = " + cp.getAckCount() + ", ackTime = " + cp.getAckTime() + " мс");
        System.out.println("  eosMode = " + cp.getEosMode());
        System.out.println("  syncCommitTimeout = " + cp.getSyncCommitTimeout());
        System.out.println("  stopImmediate = " + cp.isStopImmediate());
        System.out.println("  missingTopicsFatal = " + cp.isMissingTopicsFatal());
    }
}
