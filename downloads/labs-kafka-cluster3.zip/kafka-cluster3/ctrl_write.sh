#!/bin/bash
# Опыт 3.4 гл. 29: идёт ли запись, пока кворум выбирает нового контроллера. Тема w1 лежит только на двух брокерах,
# которые не являются активным контроллером; процесс активного контроллера убивается SIGKILL (без штатной остановки).
# Производитель пишет без перерыва 30 с (acks=all, 200 записей/с); смотрим ошибки и худшую задержку.
# Запуск: KUBECONFIG=tmp/kind-bin/kubeconfig bash labs/kafka-cluster3/ctrl_write.sh > labs/kafka-cluster3/s29-ctrl-write.txt
export MSYS_NO_PATHCONV=1
K=/opt/kafka/bin; boot=kc-0.kc.kafka3.svc.cluster.local:9092
q(){ kubectl -n kafka3 exec "$1" -- $K/kafka-metadata-quorum.sh --bootstrap-server "$2" describe --status 2>/dev/null | awk '/LeaderId|LeaderEpoch/{printf "%s ", $0}'; }
leader=$(kubectl -n kafka3 exec kc-0 -- $K/kafka-metadata-quorum.sh --bootstrap-server $boot describe --status | awk '/LeaderId/{print $2}')
others=$(for n in 1 2 3; do [ $n != $leader ] && printf "%s:" $n; done); others=${others%:}
via=kc-$(( ${others%%:*} - 1 )); vboot=$via.kc.kafka3.svc.cluster.local:9092
kubectl -n kafka3 exec $via -- $K/kafka-topics.sh --bootstrap-server $vboot --delete --topic w1 >/dev/null 2>&1; sleep 3
kubectl -n kafka3 exec $via -- $K/kafka-topics.sh --bootstrap-server $vboot --create --topic w1 --replica-assignment $others >/dev/null
echo "=== 3.4 запись во время перевыборов контроллера"
echo "  активный контроллер: узел $leader; тема w1 на брокерах $others, пишем через под $via"
echo "  кворум до отказа: $(q $via $vboot)"
target=kc-$(( leader - 1 )); node=$(kubectl -n kafka3 get pod $target -o jsonpath='{.spec.nodeName}')
pid=""; for p in $(docker exec $node pgrep -f kafka.Kafka); do docker exec $node sh -c "tr '\0' '\n' < /proc/$p/environ | grep -q ^HOSTNAME=$target" && pid=$p; done
( sleep 8; docker exec $node kill -KILL $pid; echo "  +8 с: процесс контроллера (под $target, pid $pid) убит SIGKILL" ) &
kubectl -n kafka3 exec $via -- $K/kafka-producer-perf-test.sh --topic w1 --num-records 6000 --throughput 200 --record-size 300 \
  --producer-props bootstrap.servers=$vboot acks=all request.timeout.ms=5000 delivery.timeout.ms=20000 2>&1 \
  | grep -E "records sent|ERROR|Exception" | tail -4 | sed 's/^/  производитель: /'
wait
echo "  кворум после: $(q $via $vboot)"
echo "  лидер партиции w1: $(kubectl -n kafka3 exec $via -- $K/kafka-topics.sh --bootstrap-server $vboot --describe --topic w1 | awk '/Partition: 0/{print $6}')"
