#!/bin/bash
# kt.sh <под> <утилита.sh> <аргументы...> — выполнить утилиту Kafka внутри пода кластера kafka3 (внутренний адрес брокера kc-N:9092)
export KUBECONFIG="$(cygpath -w /c/Users/backskin/java-backend-bible/tmp/kind-bin/kubeconfig)"
POD="$1"; TOOL="$2"; shift 2
MSYS_NO_PATHCONV=1 kubectl -n kafka3 exec "$POD" -- /opt/kafka/bin/"$TOOL" "$@"
