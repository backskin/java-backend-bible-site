"""Почему брокер, у которого удалили под, теряет лидерство быстрее, чем замёрзший (гл. 29, 3.4).
Процессу брокера на узле kind посылается сигнал: TERM — штатная остановка (брокер сам сообщает контроллеру, что уходит),
KILL — падение без остановки (контроллер узнаёт только по тайм-ауту сессии broker.session.timeout.ms = 9000 мс).
Печатается момент, когда ни одна партиция темы pay больше не числит этого брокера лидером.
Запуск: python crash_timeline.py TERM|KILL [kc-1]"""
import os
import re
import subprocess
import sys
import time

SIG = sys.argv[1] if len(sys.argv) > 1 else "KILL"
TARGET = sys.argv[2] if len(sys.argv) > 2 else "kc-1"
VIA = "kc-2" if TARGET != "kc-2" else "kc-0"
BROKER = str(int(TARGET.split("-")[1]) + 1)
env = dict(os.environ, KUBECONFIG=os.path.join(os.path.dirname(__file__), "..", "..", "tmp", "kind-bin", "kubeconfig"), MSYS_NO_PATHCONV="1")


def run(*cmd, timeout=60):
    return subprocess.run(list(cmd), capture_output=True, text=True, env=env, timeout=timeout).stdout


def leaders():
    out = run("kubectl", "-n", "kafka3", "exec", VIA, "--", "/opt/kafka/bin/kafka-topics.sh", "--bootstrap-server",
              f"{VIA}.kc.kafka3.svc.cluster.local:9092", "--command-config", "/tmp/c.properties", "--describe", "--topic", "pay", timeout=20)
    return {int(m.group(1)): m.group(2) for m in re.finditer(r"Partition: (\d+)\s+Leader: (\S+)", out)}


run("kubectl", "-n", "kafka3", "exec", VIA, "--", "sh", "-c",
    "echo request.timeout.ms=2000 > /tmp/c.properties; echo default.api.timeout.ms=4000 >> /tmp/c.properties")
# вернуть лидерство предпочтительным репликам, чтобы у брокера были партиции
run("kubectl", "-n", "kafka3", "exec", VIA, "--", "/opt/kafka/bin/kafka-leader-election.sh", "--bootstrap-server",
    f"{VIA}.kc.kafka3.svc.cluster.local:9092", "--election-type", "PREFERRED", "--all-topic-partitions")
time.sleep(3)
node = run("kubectl", "-n", "kafka3", "get", "pod", TARGET, "-o", "jsonpath={.spec.nodeName}").strip()
pid = None
for p in run("docker", "exec", node, "pgrep", "-f", "kafka.Kafka").split():
    if f"HOSTNAME={TARGET}" in run("docker", "exec", node, "sh", "-c", f"tr '\\0' '\\n' < /proc/{p}/environ | grep ^HOSTNAME="):
        pid = p
before = leaders()
mine = sorted(p for p, l in before.items() if l == BROKER)
print(f"брокер {BROKER} (под {TARGET}, pid {pid}) лидер партиций {mine}; сигнал SIG{SIG}", flush=True)
run("docker", "exec", node, "kill", f"-{SIG}", pid)
t0 = time.time()
while time.time() - t0 < 40:
    try:
        cur = leaders()
    except Exception:
        continue
    left = [p for p in mine if cur.get(p) == BROKER]
    if cur and not left:
        print(f"  +{time.time() - t0:4.1f} с  лидерство ушло со всех партиций брокера {BROKER}: "
              + ", ".join(f"p{p}→{cur[p]}" for p in mine), flush=True)
        break
else:
    print("  за 40 с лидерство не сменилось", flush=True)
