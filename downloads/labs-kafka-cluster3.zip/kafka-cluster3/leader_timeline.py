"""Хронология выбора лидеров при отказе брокера: удаляет под kc-1 (брокер 2) и каждые ~3 с читает kafka-topics --describe через kc-0; печатает строку при каждом изменении.
Запуск: python leader_timeline.py <длительность_с> [pod_to_kill]"""
import os
import re
import subprocess
import sys
import time

DUR = int(sys.argv[1]) if len(sys.argv) > 1 else 420
KILL = sys.argv[2] if len(sys.argv) > 2 else "kc-1"
KC = r"C:\Users\backskin\java-backend-bible\tmp\kind-bin\kubeconfig"
env = dict(os.environ, KUBECONFIG=KC, MSYS_NO_PATHCONV="1")
BOOT = "kc-0.kc.kafka3.svc.cluster.local:9092" if KILL != "kc-0" else "kc-1.kc.kafka3.svc.cluster.local:9092"
VIA = "kc-0" if KILL != "kc-0" else "kc-1"


def sh(*a, timeout=60):
    return subprocess.run(["kubectl", *a], capture_output=True, text=True, env=env, timeout=timeout).stdout


def describe():
    out = sh("-n", "kafka3", "exec", VIA, "--", "/opt/kafka/bin/kafka-topics.sh", "--bootstrap-server", BOOT, "--describe", "--topic", "pay")
    rows = {}
    for m in re.finditer(r"Partition: (\d+)\s+Leader: (\S+)\s+Replicas: (\S+)\s+Isr: (\S*)", out):
        rows[int(m.group(1))] = (m.group(2), m.group(3), m.group(4))
    return rows


def line(rows):
    return "  ".join(f"p{p}: лидер {l} ISR [{i}]" for p, (l, r, i) in sorted(rows.items()))


t0 = time.time()
prev = describe()
print(f"t={0:>4.0f} с  до отказа:   {line(prev)}", flush=True)
sh("-n", "kafka3", "delete", "pod", KILL, "--grace-period=0", "--force")
print(f"t={time.time() - t0:>4.0f} с  удалён под {KILL} (брокер {int(KILL.split('-')[1]) + 1})", flush=True)
ready_printed = False
while time.time() - t0 < DUR:
    try:
        cur = describe()
    except Exception as e:
        print(f"t={time.time() - t0:>4.0f} с  describe не ответил: {type(e).__name__}", flush=True)
        time.sleep(2)
        continue
    if cur and cur != prev:
        print(f"t={time.time() - t0:>4.0f} с  изменение:    {line(cur)}", flush=True)
        prev = cur
    if not ready_printed:
        st = sh("-n", "kafka3", "get", "pod", KILL, "-o", "jsonpath={.status.containerStatuses[0].ready}")
        if st.strip() == "true":
            print(f"t={time.time() - t0:>4.0f} с  под {KILL} снова Ready", flush=True)
            ready_printed = True
    time.sleep(2)
print("конец наблюдения", flush=True)
