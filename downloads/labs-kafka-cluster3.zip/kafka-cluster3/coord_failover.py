"""Отказ координатора группы: берём группу, запускаем в ней живого потребителя, находим координатора, «убиваем» его брокер и смотрим, как координатор переезжает.
Также отказ активного контроллера KRaft. Запуск: python coord_failover.py coordinator|controller"""
import os
import re
import subprocess
import sys
import time

MODE = sys.argv[1] if len(sys.argv) > 1 else "coordinator"
KC = r"C:\Users\backskin\java-backend-bible\tmp\kind-bin\kubeconfig"
env = dict(os.environ, KUBECONFIG=KC, MSYS_NO_PATHCONV="1")
HOSTS = {1: "kc-0", 2: "kc-1", 3: "kc-2"}


def run(*cmd, timeout=90):
    return subprocess.run(list(cmd), capture_output=True, text=True, env=env, timeout=timeout)


def tool(pod, name, *args, timeout=90):
    boot = f"{pod}.kc.kafka3.svc.cluster.local:9092"
    r = run("kubectl", "-n", "kafka3", "exec", pod, "--", f"/opt/kafka/bin/{name}", "--bootstrap-server", boot, *args, timeout=timeout)
    return r.stdout + r.stderr


def java_hash(s):
    h = 0
    for ch in s:
        h = (31 * h + ord(ch)) & 0xFFFFFFFF
    return h - (1 << 32) if h >= (1 << 31) else h


def coordinator_of(group, via):
    st = tool(via, "kafka-consumer-groups.sh", "--describe", "--group", group, "--state")
    m = re.search(r":9092\s+\((\d+)\)\s+(\S*)\s+(\S+)\s+(\d+)", st)
    return (m.group(1), m.group(3), m.group(4)) if m else ("?", "?", "?")


def quorum(via):
    out = tool(via, "kafka-metadata-quorum.sh", "describe", "--status")
    lid = re.search(r"LeaderId:\s+(\d+)", out)
    ep = re.search(r"LeaderEpoch:\s+(\d+)", out)
    return (lid.group(1) if lid else "?", ep.group(1) if ep else "?")


if MODE == "controller":
    lid, ep = quorum("kc-0")
    victim = HOSTS[int(lid)]
    via = "kc-0" if victim != "kc-0" else "kc-1"
    print(f"активный контроллер до отказа: узел {lid}, эпоха {ep}", flush=True)
    t0 = time.time()
    run("kubectl", "-n", "kafka3", "delete", "pod", victim, "--grace-period=0", "--force")
    print(f"t={time.time() - t0:>4.0f} с  удалён под {victim}", flush=True)
    prev = (lid, ep)
    while time.time() - t0 < 40:
        cur = quorum(via)
        if cur != prev:
            print(f"t={time.time() - t0:>4.0f} с  активный контроллер: узел {cur[0]}, эпоха {cur[1]}", flush=True)
            prev = cur
        time.sleep(1)
    print("конец", flush=True)
    sys.exit(0)

GROUP = "orders-app"
h = java_hash(GROUP)
part = abs(h) % 50
print(f"группа {GROUP}: __consumer_offsets, партиция {part}", flush=True)
# живой потребитель в группе: console-consumer в фоне внутри пода kc-0 на 150 секунд
cons = subprocess.Popen(["kubectl", "-n", "kafka3", "exec", "kc-0", "--", "/opt/kafka/bin/kafka-console-consumer.sh", "--bootstrap-server", "kc-0.kc.kafka3.svc.cluster.local:9092",
                         "--topic", "pay", "--group", GROUP, "--timeout-ms", "150000"], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
time.sleep(12)
coord, state, members = coordinator_of(GROUP, "kc-0")
print(f"до отказа: координатор — брокер {coord}, состояние группы {state}, членов {members}", flush=True)
if coord == "1":
    print("координатор на kc-0 (там же потребитель); для чистоты опыта выберем другую группу", flush=True)
victim = HOSTS[int(coord)]
via = "kc-0" if victim != "kc-0" else "kc-1"
t0 = time.time()
run("kubectl", "-n", "kafka3", "delete", "pod", victim, "--grace-period=0", "--force")
print(f"t={time.time() - t0:>4.0f} с  удалён под {victim} (брокер {coord})", flush=True)
prev = (coord, state, members)
while time.time() - t0 < 45:
    cur = coordinator_of(GROUP, via)
    if cur != prev:
        print(f"t={time.time() - t0:>4.0f} с  координатор — брокер {cur[0]}, состояние {cur[1]}, членов {cur[2]}", flush=True)
        prev = cur
    time.sleep(2)
try:
    cons.terminate()
except Exception:
    pass
print("конец", flush=True)
