package dev.team.proc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.availability.AvailabilityChangeEvent;
import org.springframework.boot.availability.ReadinessState;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Приложение опыта разд. 7: авторизация карточных платежей процессинга Тундра-Банка.
 * Каждый запрос «ходит к эмитенту» заданное число миллисекунд. ServerLab поднимает его в разных режимах.
 */
@SpringBootApplication
@EnableAsync
@EnableScheduling
public class ProcessingApp {

    static final List<String> events = new CopyOnWriteArrayList<>();
    static volatile String scheduledThread = "-";

    @RestController
    static class AuthController {
        private final DataSource ds;
        private final Notifier notifier;

        AuthController(DataSource ds, Notifier notifier) { this.ds = ds; this.notifier = notifier; }

        /** Авторизация: ожидание ответа эмитента. */
        @GetMapping("/api/auth")
        String auth(@RequestParam(defaultValue = "100") long ms) throws InterruptedException {
            Thread.sleep(ms);
            return "APPROVED " + Thread.currentThread();
        }

        /** Авторизация с удержанием соединения из пула на время ожидания. */
        @GetMapping("/api/auth-db")
        String authDb(@RequestParam(defaultValue = "100") long ms) throws Exception {
            try (Connection c = ds.getConnection()) {
                Thread.sleep(ms);
                return "APPROVED";
            }
        }

        /** То же ожидание внутри synchronized: на JDK 21 виртуальный поток не отпускает носитель. */
        @GetMapping("/api/auth-sync")
        String authSync(@RequestParam(defaultValue = "100") long ms) throws InterruptedException {
            Object lock = new Object();
            synchronized (lock) {
                Thread.sleep(ms);
            }
            return "APPROVED";
        }

        @GetMapping("/api/async")
        String async() throws Exception { return notifier.send().get(); }
    }

    @Service
    static class Notifier {
        @Async
        public CompletableFuture<String> send() { return CompletableFuture.completedFuture(Thread.currentThread().toString()); }
    }

    @Scheduled(fixedDelay = 200)
    void reconcile() { scheduledThread = Thread.currentThread().toString(); }

    @EventListener
    void onReadiness(AvailabilityChangeEvent<ReadinessState> e) { events.add("readiness=" + e.getState()); }

    @Bean
    org.springframework.boot.ApplicationRunner executors(java.util.Map<String, TaskExecutor> ex, java.util.Map<String, TaskScheduler> sch) {
        return a -> {
            if (Boolean.getBoolean("lab.print-executors"))
                System.out.println("   исполнители: " + ex.entrySet().stream().map(e -> e.getKey() + "=" + e.getValue().getClass().getSimpleName()).toList()
                        + "; планировщики: " + sch.entrySet().stream().map(e -> e.getKey() + "=" + e.getValue().getClass().getSimpleName()).toList());
        };
    }

    public static void main(String[] args) { SpringApplication.run(ProcessingApp.class, args); }
}
