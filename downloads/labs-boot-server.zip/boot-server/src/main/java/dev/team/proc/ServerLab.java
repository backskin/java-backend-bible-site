package dev.team.proc;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.io.File;
import java.nio.file.Path;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** Ведущий опыта разд. 7: встроенный Tomcat под нагрузкой, остановка и виртуальные потоки. */
public class ServerLab {
    static final HttpClient HTTP = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(5)).executor(Executors.newCachedThreadPool(r -> { Thread t = new Thread(r); t.setDaemon(true); return t; })).build();
    static ConfigurableApplicationContext ctx;
    static String port;
    static long t0;

    public static void main(String[] a) throws Exception {
        String only = a.length > 0 ? a[0] : null;
        if ("pin-child".equals(only)) { pinChild(); return; }
        if ("keepalive-child".equals(only)) { keepAliveChild(a[1]); return; }

        if (on(only, "1")) { start("1. параметры Tomcat по умолчанию"); connector(); stop(); }

        if (on(only, "2")) { start("2. пул из 4 потоков, 20 одновременных авторизаций по 500 мс", "server.tomcat.threads.max=4");
            burst("/api/auth?ms=500", 20); stop();
            start("2б. то же, виртуальные потоки", "server.tomcat.threads.max=4", "spring.threads.virtual.enabled=true");
            connector(); burst("/api/auth?ms=500", 20); System.out.println("   поток обработки: " + body("/api/auth?ms=0").substring(9)); stop(); }

        if (on(only, "3")) { System.setProperty("lab.print-executors", "true");
            start("3. исполнители и планировщик, платформенные потоки"); Thread.sleep(400);
            System.out.println("   @Async: " + body("/api/async") + "; @Scheduled: " + ProcessingApp.scheduledThread); stop();
            start("3б. исполнители и планировщик, виртуальные потоки", "spring.threads.virtual.enabled=true"); Thread.sleep(400);
            System.out.println("   @Async: " + body("/api/async") + "; @Scheduled: " + ProcessingApp.scheduledThread); stop();
            System.clearProperty("lab.print-executors"); }

        if (on(only, "4")) { start("4. пул соединений 4, платформенные потоки 4: 20 авторизаций с удержанием соединения 500 мс",
                    "server.tomcat.threads.max=4", "spring.datasource.hikari.maximum-pool-size=4", "spring.datasource.hikari.connection-timeout=1000");
            burst("/api/auth-db?ms=500", 20); stop();
            start("4б. пул соединений 4, виртуальные потоки: то же", "spring.threads.virtual.enabled=true",
                    "spring.datasource.hikari.maximum-pool-size=4", "spring.datasource.hikari.connection-timeout=1000");
            burst("/api/auth-db?ms=500", 20); stop(); }

        if (on(only, "5")) { System.out.println("== 5. прикрепление к носителю: 2 носителя, 20 авторизаций по 500 мс (отдельный процесс)");
            child(List.of("-Djdk.virtualThreadScheduler.parallelism=2", "-Djdk.virtualThreadScheduler.maxPoolSize=2"), "pin-child"); }

        if (on(only, "6")) { shutdownCase("6. остановка без настроек: запрос на 3 с в обработке", 3000);
            shutdownCase("6б. server.shutdown=immediate", 3000, "server.shutdown=immediate");
            shutdownCase("6в. graceful, timeout-per-shutdown-phase=1s, запрос на 3 с", 3000, "spring.lifecycle.timeout-per-shutdown-phase=1s"); }

        if (on(only, "7")) { System.out.println("== 7. приложение без веб-сервера, @Scheduled на виртуальных потоках (отдельный процесс)");
            child(List.of(), "keepalive-child", "false"); child(List.of(), "keepalive-child", "true"); }
    }

    static boolean on(String only, String n) { return only == null || only.equals(n); }

    static void start(String label, String... props) {
        System.out.println("== " + label);
        List<String> args = new ArrayList<>(List.of("--server.port=0", "--spring.main.banner-mode=off", "--logging.level.root=warn",
                "--spring.datasource.url=jdbc:h2:mem:proc"));
        for (String p : props) args.add("--" + p);
        ctx = new SpringApplication(ProcessingApp.class).run(args.toArray(String[]::new));
        port = ctx.getEnvironment().getProperty("local.server.port");
        ProcessingApp.events.clear();
    }

    static void stop() { ctx.close(); }

    /** Свойства коннектора Tomcat, которые реально применились. */
    static void connector() throws Exception {
        Object ws = ctx.getClass().getMethod("getWebServer").invoke(ctx);
        Object tomcat = ws.getClass().getMethod("getTomcat").invoke(ws);
        org.apache.catalina.connector.Connector c = ((org.apache.catalina.startup.Tomcat) tomcat).getConnector();
        Map<String, Object> m = new TreeMap<>();
        for (String k : List.of("maxThreads", "minSpareThreads", "acceptCount", "maxConnections", "connectionTimeout", "keepAliveTimeout", "maxKeepAliveRequests"))
            m.put(k, c.getProperty(k));
        Object exec = c.getProtocolHandler().getExecutor();
        System.out.println("   " + ws.getClass().getSimpleName() + " " + org.apache.catalina.util.ServerInfo.getServerNumber() + ": " + m
                + "; исполнитель: " + (exec == null ? "null" : exec.getClass().getName()));
    }

    static String body(String path) throws Exception {
        return HTTP.send(req(path), HttpResponse.BodyHandlers.ofString()).body();
    }

    static HttpRequest req(String path) {
        return HttpRequest.newBuilder(URI.create("http://localhost:" + port + path)).timeout(Duration.ofSeconds(20)).build();
    }

    /** Отправляет n запросов одновременно и сводит время ответа и коды. */
    static void burst(String path, int n) throws Exception {
        long start = System.nanoTime();
        List<CompletableFuture<String>> fs = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            fs.add(HTTP.sendAsync(req(path), HttpResponse.BodyHandlers.ofString())
                    .thenApply(r -> r.statusCode() + "@" + (System.nanoTime() - start) / 100_000_000 * 100)
                    .exceptionally(e -> "ERR " + (e.getCause() != null ? e.getCause().getClass().getSimpleName() : e.getClass().getSimpleName())));
        }
        Map<String, Integer> hist = new TreeMap<>();
        for (var f : fs) hist.merge(f.get(), 1, Integer::sum);
        System.out.println("   за " + (System.nanoTime() - start) / 1_000_000 + " мс; код@мс → число: " + hist);
    }

    static void shutdownCase(String label, long ms, String... props) throws Exception {
        start(label, props);
        t0 = System.nanoTime();
        CompletableFuture<String> inFlight = HTTP.sendAsync(req("/api/auth?ms=" + ms), HttpResponse.BodyHandlers.ofString())
                .thenApply(r -> "HTTP " + r.statusCode() + " через " + since() + " мс")
                .exceptionally(e -> "ОШИБКА " + rootName(e) + " через " + since() + " мс");
        Thread.sleep(500);
        Thread closer = Thread.ofPlatform().start(() -> { ctx.close(); System.out.println("   контекст закрыт через " + since() + " мс"); });
        Thread.sleep(500);
        String late;
        try { late = "HTTP " + HTTP.send(req("/api/auth?ms=0"), HttpResponse.BodyHandlers.ofString()).statusCode(); }
        catch (Exception e) { late = "ОШИБКА " + rootName(e); }
        System.out.println("   новый запрос через 1000 мс: " + late);
        System.out.println("   запрос в обработке: " + inFlight.get());
        closer.join();
        System.out.println("   события готовности: " + ProcessingApp.events);
    }

    static long since() { return (System.nanoTime() - t0) / 1_000_000; }

    static String rootName(Throwable e) {
        while (e.getCause() != null && e.getCause() != e) e = e.getCause();
        return e.getClass().getSimpleName();
    }

    static void child(List<String> jvm, String... args) throws Exception {
        List<String> cmd = new ArrayList<>(List.of(Path.of(System.getProperty("java.home"), "bin", "java").toString(), "-Dstdout.encoding=UTF-8", "-cp", System.getProperty("java.class.path")));
        cmd.addAll(jvm);
        cmd.add(ServerLab.class.getName());
        cmd.addAll(List.of(args));
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).directory(new File(".")).start();
        long s = System.nanoTime();
        boolean done = p.waitFor(20, TimeUnit.SECONDS);
        if (!done) p.destroyForcibly().waitFor();
        String out = new String(p.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        for (String line : out.split("\\R")) if (line.startsWith("   ")) System.out.println(line);
        System.out.println("   процесс " + (done ? "завершился сам через " + (System.nanoTime() - s) / 1_000_000 + " мс" : "работал 20 с и был остановлен опытом"));
    }

    static void pinChild() throws Exception {
        start("pin", "spring.threads.virtual.enabled=true");
        System.out.print("   без synchronized: "); burst("/api/auth?ms=500", 20);
        System.out.print("   sleep внутри synchronized: "); burst("/api/auth-sync?ms=500", 20);
        stop();
    }

    static void keepAliveChild(String keepAlive) {
        new SpringApplication(ProcessingApp.class).run("--spring.main.web-application-type=none", "--spring.threads.virtual.enabled=true",
                "--spring.main.keep-alive=" + keepAlive, "--spring.main.banner-mode=off", "--logging.level.root=warn",
                "--spring.datasource.url=jdbc:h2:mem:proc");
        System.out.println("   keep-alive=" + keepAlive + ": run() вернул управление, main завершается");
    }
}
