# Встроенный сервер Spring Boot: параметры Tomcat, пулы, удержание соединений, виртуальные потоки, graceful shutdown, Jetty

Стенд к главе 10, раздел о встроенном сервере. Ведущий `ServerLab` поднимает карточный процессинг `ProcessingApp` (Spring Boot 4.1.1, Tomcat 11.0.24, HikariCP, H2) и снимает: значения коннектора Tomcat по умолчанию, двадцать одновременных запросов при разных размерах пула, исполнители задач, удержание соединений из пула базы, прикрепление виртуального потока к носителю (отдельный процесс с двумя носителями, на JDK 21 и 25), три режима остановки, приложение без веб-сервера с `spring.main.keep-alive` и без. Отдельная сборка на Jetty 12.1.12 - `s10-jetty.txt`. Выводы автора - `s10-server.txt`, `s10-server-pinning.txt`.

## Что нужно

- JDK 21 (и 25 для сравнения прикрепления), Maven.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" dev.team.proc.ServerLab
```

Jetty вместо Tomcat: исключить `spring-boot-starter-tomcat` из `spring-boot-starter-webmvc` и добавить `spring-boot-starter-jetty`, как описано в `s10-jetty.txt`. В IDEA есть конфигурации `ServerLab` и `ProcessingApp`.

## Что должно получиться

`maxThreads=200, acceptCount=100, maxConnections=8192, keepAliveTimeout=60000` по умолчанию; на JDK 21 двадцать авторизаций по 500 мс в `synchronized` на двух носителях растягиваются в разы, на 25 нет.
