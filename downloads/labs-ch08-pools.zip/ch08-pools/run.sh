#!/bin/sh
# Опыты разделов 6-7 главы 8
J21=~/.jdks/temurin-21.0.10/bin/java; J25=~/.jdks/jdk-25.0.5+8/bin/java
O="-Dstdout.encoding=UTF-8"
for J in $J21 $J25; do
  echo "=== $($J -version 2>&1 | head -1)"
  $J $O src/PoolDemo.java
  $J $O src/ShutdownDemo.java
  $J $O -Xss1m src/FjDemo.java
  $J $O -XX:ActiveProcessorCount=1 src/FjDemo.java stream
  $J $O -XX:ActiveProcessorCount=2 src/FjDemo.java stream
done > s06-pools.txt 2>&1
$J21 $O src/PoolSizeDemo.java > s06-poolsize.txt 2>&1
$J21 $O -XX:ActiveProcessorCount=3 src/PoolSizeDemo.java 2>&1 | head -1 >> s06-poolsize.txt
