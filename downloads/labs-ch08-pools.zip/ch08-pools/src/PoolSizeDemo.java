import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class PoolSizeDemo {

    /** 1000 задач; каждая берёт одно из 10 «соединений» и держит его 50 мс. */
    static long run(int poolSize) throws Exception {
        Semaphore connections = new Semaphore(10);
        ExecutorService pool = Executors.newFixedThreadPool(poolSize);
        long t0 = System.nanoTime();
        for (int i = 0; i < 1000; i++) {
            pool.execute(() -> {
                try {
                    connections.acquire();
                    try { Thread.sleep(50); } finally { connections.release(); }
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            });
        }
        pool.shutdown();
        pool.awaitTermination(1, TimeUnit.MINUTES);
        return (System.nanoTime() - t0) / 1_000_000;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("процессоров по версии JVM: " + Runtime.getRuntime().availableProcessors());
        // формула из JCIP: N_cpu * U_cpu * (1 + W/C)
        int nCpu = 8; double uCpu = 0.5, wc = 9;
        System.out.println("формула JCIP для 8 ядер, загрузка 50%, W/C=9: " + (int) (nCpu * uCpu * (1 + wc)) + " потоков");
        // закон Литтла: L = lambda * W
        double lambda = 500, w = 0.100;
        System.out.println("закон Литтла: в системе одновременно " + (lambda * w) + " запросов при 500 запр/с и 100 мс");

        System.out.println("--- 1000 задач по 50 мс через 10 соединений");
        run(10);                                                 // прогрев
        System.out.println("пул из 10 потоков:  " + run(10) + " мс");
        System.out.println("пул из 200 потоков: " + run(200) + " мс");
    }
}
