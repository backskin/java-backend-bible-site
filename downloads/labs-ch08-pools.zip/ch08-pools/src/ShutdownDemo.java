import java.util.List;
import java.util.concurrent.*;

/** shutdownNow() только прерывает: задача, не проверяющая прерывание, доработает; close() в JDK 19+. */
public class ShutdownDemo {
    static volatile long sink;

    public static void main(String[] args) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(1);
        pool.execute(() -> {                         // вычисление, которое не смотрит на interrupt
            long t0 = System.nanoTime(), x = 0;
            while (System.nanoTime() - t0 < 1_500_000_000L) x++;
            sink = x;
            System.out.println("вычислительная задача доработала до конца, interrupted=" + Thread.currentThread().isInterrupted());
        });
        pool.execute(() -> System.out.println("вторая задача (не должна выполниться)"));
        Thread.sleep(100);
        List<Runnable> dropped = pool.shutdownNow();
        System.out.println("shutdownNow: из очереди возвращено задач " + dropped.size());
        long t0 = System.nanoTime();
        boolean done = pool.awaitTermination(200, TimeUnit.MILLISECONDS);
        System.out.println("awaitTermination(200 мс) = " + done);
        pool.awaitTermination(5, TimeUnit.SECONDS);
        System.out.printf("пул остановился через %d мс после shutdownNow%n", (System.nanoTime() - t0) / 1_000_000);

        ExecutorService sleeper = Executors.newFixedThreadPool(1);
        sleeper.execute(() -> {
            try { Thread.sleep(10_000); System.out.println("сон закончился"); }
            catch (InterruptedException e) { System.out.println("задача со sleep получила InterruptedException"); }
        });
        Thread.sleep(100);
        t0 = System.nanoTime();
        sleeper.shutdownNow();
        sleeper.awaitTermination(5, TimeUnit.SECONDS);
        System.out.printf("пул со sleep остановился через %d мс%n", (System.nanoTime() - t0) / 1_000_000);

        t0 = System.nanoTime();
        try (ExecutorService es = Executors.newFixedThreadPool(2)) {   // JDK 19+: close() = shutdown + ждать
            es.submit(() -> { try { Thread.sleep(500); } catch (InterruptedException ignored) { } });
        }
        System.out.printf("try-with-resources закрылся через %d мс (дождался задачи)%n", (System.nanoTime() - t0) / 1_000_000);
    }
}
