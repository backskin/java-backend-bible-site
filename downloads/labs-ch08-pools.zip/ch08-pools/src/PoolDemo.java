import java.util.concurrent.*;

public class PoolDemo {

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    static void submitSeven(String title, ThreadPoolExecutor pool) {
        System.out.println("--- " + title);
        for (int i = 1; i <= 7; i++) {
            try {
                pool.execute(() -> sleep(1500));                // долгая задача
                System.out.println("задача " + i + ": принята; потоков " + pool.getPoolSize() + ", в очереди " + pool.getQueue().size());
            } catch (RejectedExecutionException e) {
                System.out.println("задача " + i + ": ОТКЛОНЕНА (RejectedExecutionException)");
            }
        }
        pool.shutdownNow();
    }

    public static void main(String[] args) {
        submitSeven("1. core=2, max=4, ArrayBlockingQueue(2)",
                new ThreadPoolExecutor(2, 4, 60, TimeUnit.SECONDS, new ArrayBlockingQueue<>(2)));
        submitSeven("2. core=2, max=64, LinkedBlockingQueue без границы: max не работает",
                new ThreadPoolExecutor(2, 64, 60, TimeUnit.SECONDS, new LinkedBlockingQueue<>()));
        submitSeven("3. core=2, max=4, SynchronousQueue (direct handoff)",
                new ThreadPoolExecutor(2, 4, 60, TimeUnit.SECONDS, new SynchronousQueue<>()));

        System.out.println("--- 4. что на самом деле создают фабрики Executors");
        ThreadPoolExecutor fixed = (ThreadPoolExecutor) Executors.newFixedThreadPool(4);
        System.out.println("newFixedThreadPool(4):  core=" + fixed.getCorePoolSize() + ", max=" + fixed.getMaximumPoolSize()
                + ", очередь " + fixed.getQueue().getClass().getSimpleName() + ", свободное место " + fixed.getQueue().remainingCapacity());
        ThreadPoolExecutor cached = (ThreadPoolExecutor) Executors.newCachedThreadPool();
        System.out.println("newCachedThreadPool():  core=" + cached.getCorePoolSize() + ", max=" + cached.getMaximumPoolSize()
                + ", очередь " + cached.getQueue().getClass().getSimpleName() + ", keepAlive " + cached.getKeepAliveTime(TimeUnit.SECONDS) + " с");
        fixed.shutdownNow(); cached.shutdownNow();

        System.out.println("--- 5. CallerRunsPolicy: перегруженный пул отдаёт задачу вызывающему потоку");
        ThreadPoolExecutor caller = new ThreadPoolExecutor(1, 1, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<>(1), new ThreadPoolExecutor.CallerRunsPolicy());
        for (int i = 1; i <= 3; i++) {
            final int n = i;
            caller.execute(() -> { System.out.println("задача " + n + " выполняется в потоке " + Thread.currentThread().getName()); sleep(300); });
        }
        caller.shutdown();
    }
}
