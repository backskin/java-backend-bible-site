import java.util.concurrent.*;

/** cancel(true) у CompletableFuture не прерывает поток задачи, у FutureTask прерывает; orTimeout не останавливает задачу. */
public class CfCancel {
    public static void main(String[] args) throws Exception {
        ExecutorService io = Executors.newFixedThreadPool(2);
        CountDownLatch started = new CountDownLatch(2);
        CompletableFuture<String> cf = CompletableFuture.supplyAsync(() -> {
            started.countDown();
            try { Thread.sleep(500); System.out.println("задача CF доработала: поток не прерван"); return "ok"; }
            catch (InterruptedException e) { System.out.println("задача CF прервана"); return "прервана"; }
        }, io);
        Future<String> ft = io.submit(() -> {
            started.countDown();
            try { Thread.sleep(500); return "FutureTask доработала"; }
            catch (InterruptedException e) { System.out.println("FutureTask: поток получил InterruptedException"); return "прервана"; }
        });
        started.await();
        System.out.println("cf.cancel(true) = " + cf.cancel(true) + ", isCancelled=" + cf.isCancelled());
        System.out.println("ft.cancel(true) = " + ft.cancel(true));
        Thread.sleep(700);
        // узнаём, чем закончилась задача CF, через отдельный future
        CompletableFuture<String> probe = new CompletableFuture<>();
        io.submit(() -> probe.complete("пул жив"));
        System.out.println(probe.get());

        long t0 = System.nanoTime();
        CompletableFuture<String> slow = CompletableFuture.supplyAsync(() -> {
            try { Thread.sleep(600); } catch (InterruptedException e) { return "прервана"; }
            System.out.printf("медленная задача закончилась через %d мс после старта%n", (System.nanoTime() - t0) / 1_000_000);
            return "готово";
        }, io);
        try { slow.orTimeout(100, TimeUnit.MILLISECONDS).join(); }
        catch (CompletionException e) { System.out.printf("orTimeout: %s через %d мс%n", e.getCause().getClass().getSimpleName(), (System.nanoTime() - t0) / 1_000_000); }
        Thread.sleep(700);
        io.shutdown();
    }
}
