import java.util.concurrent.*;
import java.util.stream.LongStream;

/**
 * ForkJoinPool: порог разбиения (1, 4096, без разбиения), число краж; параллелизм общего пула;
 * блокирующий вызов в общем пуле задерживает чужой supplyAsync; parallelStream при одном процессоре.
 */
public class FjDemo {

    static final long[] TURNOVERS = LongStream.range(0, 4_000_000).map(i -> (i * 7919) % 100_000).toArray();

    static final class SumTask extends RecursiveTask<Long> {
        final int from, to, threshold;
        SumTask(int from, int to, int threshold) { this.from = from; this.to = to; this.threshold = threshold; }
        @Override protected Long compute() {
            if (to - from <= threshold) {
                long s = 0;
                for (int i = from; i < to; i++) s += TURNOVERS[i];
                return s;
            }
            int mid = (from + to) >>> 1;
            SumTask left = new SumTask(from, mid, threshold);
            left.fork();                                   // одну половину отдаём в пул
            long right = new SumTask(mid, to, threshold).compute();   // вторую считаем сами
            return left.join() + right;
        }
    }

    static void threshold(int threshold) {
        ForkJoinPool pool = new ForkJoinPool(8);
        long best = Long.MAX_VALUE, sum = 0, steals = 0;
        for (int r = 0; r < 5; r++) {
            long s0 = pool.getStealCount();
            long t0 = System.nanoTime();
            sum = pool.invoke(new SumTask(0, TURNOVERS.length, threshold));
            best = Math.min(best, System.nanoTime() - t0);
            steals = pool.getStealCount() - s0;
        }
        long leaves = (TURNOVERS.length + threshold - 1) / threshold;
        System.out.printf("порог %,9d: %7.1f мс, листовых задач ~%,d, краж за прогон %,d, сумма %d%n",
                threshold, best / 1e6, leaves, steals, sum);
        pool.shutdown();
    }

    static void sequential() {
        long best = Long.MAX_VALUE, s = 0;
        for (int r = 0; r < 5; r++) {
            long t0 = System.nanoTime();
            s = 0; for (long v : TURNOVERS) s += v;
            best = Math.min(best, System.nanoTime() - t0);
        }
        System.out.printf("последовательно:     %7.1f мс, сумма %d%n", best / 1e6, s);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version") + ", availableProcessors=" + Runtime.getRuntime().availableProcessors()
                + ", commonPool parallelism=" + ForkJoinPool.commonPool().getParallelism());
        if (args.length > 0 && args[0].equals("stream")) { streamTest(); return; }
        for (int w = 0; w < 3; w++) { threshold(4096); threshold(1); }    // прогрев
        sequential();
        threshold(1);
        threshold(64);
        threshold(4096);
        threshold(65536);
        threshold(TURNOVERS.length);

        // общий пул забит блокирующими задачами: сколько ждёт чужой supplyAsync
        int par = ForkJoinPool.commonPool().getParallelism();
        CountDownLatch busy = new CountDownLatch(par);
        Thread report = new Thread(() -> LongStream.range(0, par * 4L).parallel().forEach(i -> {
            busy.countDown();
            try { Thread.sleep(300); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }));
        report.start();
        busy.await(2, TimeUnit.SECONDS);
        long t0 = System.nanoTime();
        CompletableFuture.supplyAsync(() -> 42).join();
        System.out.printf("supplyAsync(() -> 42) при общем пуле, занятом parallelStream со sleep(300): %d мс%n", (System.nanoTime() - t0) / 1_000_000);
        report.join();
        t0 = System.nanoTime();
        CompletableFuture.supplyAsync(() -> 42).join();
        System.out.printf("supplyAsync(() -> 42) при свободном общем пуле: %.2f мс%n", (System.nanoTime() - t0) / 1e6);
        streamTest();
    }

    static void streamTest() {
        long seq = Long.MAX_VALUE, par = Long.MAX_VALUE;
        for (int r = 0; r < 7; r++) {
            long t0 = System.nanoTime();
            long a = LongStream.of(TURNOVERS).map(v -> v * 31 % 97).sum();
            seq = Math.min(seq, System.nanoTime() - t0);
            t0 = System.nanoTime();
            long b = LongStream.of(TURNOVERS).parallel().map(v -> v * 31 % 97).sum();
            par = Math.min(par, System.nanoTime() - t0);
            if (a != b) throw new AssertionError();
        }
        System.out.printf("stream: последовательно %.2f мс, parallel %.2f мс%n", seq / 1e6, par / 1e6);
    }
}
