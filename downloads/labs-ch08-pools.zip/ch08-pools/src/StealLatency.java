import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Cost of a work steal: a worker forks a child task and then spins on a long computation,
 * so the child can only run on another worker that steals it. Measures fork -> child start
 * on a different thread (steal + possible unpark), and for comparison fork -> start when
 * the forking thread runs the child itself (join).
 */
public class StealLatency {
    static final AtomicLong stolen = new AtomicLong(), stolenNs = new AtomicLong();
    static final AtomicLong local = new AtomicLong(), localNs = new AtomicLong();
    static volatile long sink;

    static final class Child extends RecursiveAction {
        final long forkedAt; final Thread parent;
        Child(long forkedAt, Thread parent) { this.forkedAt = forkedAt; this.parent = parent; }
        @Override protected void compute() {
            long dt = System.nanoTime() - forkedAt;
            if (Thread.currentThread() != parent) { stolen.incrementAndGet(); stolenNs.addAndGet(dt); }
            else { local.incrementAndGet(); localNs.addAndGet(dt); }
        }
    }

    static final class Parent extends RecursiveAction {
        @Override protected void compute() {
            Child c = new Child(System.nanoTime(), Thread.currentThread());
            c.fork();
            long s = 0;
            for (int i = 0; i < 200_000; i++) s += i ^ (i >>> 3);   // ~100 µs of work: time for a thief
            sink = s;
            c.join();
        }
    }

    public static void main(String[] args) throws Exception {
        int rounds = 20_000;
        for (int par : new int[]{1, 2, 4}) {
            ForkJoinPool pool = new ForkJoinPool(par);
            stolen.set(0); stolenNs.set(0); local.set(0); localNs.set(0);
            for (int i = 0; i < rounds; i++) pool.invoke(new Parent());
            System.out.printf("parallelism=%d: stolen %d (avg %.1f us fork->start on thief), run locally %d (avg %.1f us)%n",
                    par, stolen.get(), stolen.get() == 0 ? 0.0 : stolenNs.get() / 1e3 / stolen.get(),
                    local.get(), local.get() == 0 ? 0.0 : localNs.get() / 1e3 / local.get());
            pool.shutdown();
        }
    }
}
