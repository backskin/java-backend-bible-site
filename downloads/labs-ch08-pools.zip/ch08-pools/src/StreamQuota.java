import java.util.concurrent.ForkJoinPool;
import java.util.stream.LongStream;

/** Долгая вычислительная работа (~1-2 с) последовательно и parallel(): что даёт квота CPU контейнера. */
public class StreamQuota {
    static long work(boolean parallel) {
        LongStream s = LongStream.range(0, 400_000_000L);
        if (parallel) s = s.parallel();
        return s.map(v -> v * 31 % 97).sum();
    }
    public static void main(String[] args) {
        System.out.println("java " + System.getProperty("java.version") + ", availableProcessors=" + Runtime.getRuntime().availableProcessors()
                + ", commonPool parallelism=" + ForkJoinPool.commonPool().getParallelism());
        for (int r = 0; r < 3; r++) {
            long t0 = System.nanoTime(); long a = work(false); long seq = System.nanoTime() - t0;
            t0 = System.nanoTime(); long b = work(true); long par = System.nanoTime() - t0;
            System.out.printf("прогон %d: последовательно %d мс, parallel %d мс%s%n", r + 1, seq / 1_000_000, par / 1_000_000, a == b ? "" : " РАЗНЫЕ СУММЫ");
        }
    }
}
