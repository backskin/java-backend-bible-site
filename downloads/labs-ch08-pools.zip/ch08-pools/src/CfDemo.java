import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class CfDemo {

    static CompletableFuture<Integer> failing() {
        return CompletableFuture.supplyAsync(() -> { throw new IllegalStateException("boom"); });
    }

    static String join(CompletableFuture<?> f) {
        try { return String.valueOf(f.join()); }
        catch (CompletionException e) { return "CompletionException <- " + e.getCause().getClass().getSimpleName() + "(" + e.getCause().getMessage() + ")"; }
        catch (Exception e) { return e.getClass().getSimpleName() + ": " + e.getMessage(); }
    }

    static Throwable unwrap(Throwable ex) {
        return (ex instanceof CompletionException || ex instanceof ExecutionException) && ex.getCause() != null ? ex.getCause() : ex;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("--- 1. exceptionally / handle / whenComplete на одной упавшей стадии");
        System.out.println("exceptionally(ex -> -1):        " + join(failing().exceptionally(ex -> -1)));
        System.out.println("handle((v, ex) -> ...):         " + join(failing().handle((v, ex) -> ex == null ? v : -1)));
        System.out.println("whenComplete(логирование):      " + join(failing().whenComplete((v, ex) -> System.out.println("  [log] " + unwrap(ex).getMessage()))));

        System.out.println("--- 2. когда исключение приходит обёрнутым");
        failing().handle((v, ex) -> { System.out.println("handle прямо на supplyAsync:         " + ex.getClass().getSimpleName()); return 0; }).join();
        CompletableFuture<Integer> manual = new CompletableFuture<>();
        manual.completeExceptionally(new IllegalStateException("boom"));
        manual.handle((v, ex) -> { System.out.println("handle после completeExceptionally:   " + ex.getClass().getSimpleName()); return 0; }).join();
        manual.thenApply(x -> x).handle((v, ex) -> { System.out.println("handle после thenApply:              " + ex.getClass().getSimpleName()); return 0; }).join();
        CompletableFuture<Integer> timed = new CompletableFuture<Integer>().orTimeout(200, TimeUnit.MILLISECONDS);
        try { timed.join(); } catch (CompletionException e) { System.out.println("join() после orTimeout:             " + e.getCause().getClass().getSimpleName()); }
        timed.handle((v, ex) -> { System.out.println("handle прямо на orTimeout:            " + ex.getClass().getSimpleName() + ", это TimeoutException: " + (unwrap(ex) instanceof TimeoutException)); return 0; }).join();

        System.out.println("--- 3. whenComplete сам бросает исключение");
        CompletableFuture<Integer> a = failing().whenComplete((v, ex) -> { throw new RuntimeException("из обработчика"); });
        System.out.println("исходная стадия упала:        " + join(a));
        CompletableFuture<Integer> b = CompletableFuture.completedFuture(5).whenComplete((v, ex) -> { throw new RuntimeException("из обработчика"); });
        System.out.println("исходная стадия успешна:      " + join(b));

        System.out.println("--- 4. exceptionallyCompose (JDK 12)");
        System.out.println("fallback через supplyAsync:   " + join(failing().exceptionallyCompose(ex -> CompletableFuture.supplyAsync(() -> 7))));

        System.out.println("--- 5. exceptionally(ex -> null) в середине цепочки");
        System.out.println("thenApply(x -> x + 1) после:  " + join(failing().exceptionally(ex -> null).thenApply(x -> x + 1)));

        System.out.println("--- 6. упавший future, который никто не потребляет");
        failing();                                                // ничего не печатается, ошибка исчезла
        Thread.sleep(300);
        System.out.println("в этой точке в консоли нет ни строчки об исключении");
    }
}
