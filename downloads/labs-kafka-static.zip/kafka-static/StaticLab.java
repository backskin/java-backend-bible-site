package k;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.kafka.test.EmbeddedKafkaKraftBroker;

/**
 * Гл. 29, 14.2: откуда одно событие отзыва у участника B, когда статический участник A уходит и возвращается через 1 с.
 * Печатает время каждого события B и шагов A и состояние группы перед началом счёта. Встроенный брокер, Docker не нужен.
 */
public class StaticLab {
    static String bootstrap;
    static final long T0 = System.nanoTime();

    static String t() { return String.format("%6.2f с", (System.nanoTime() - T0) / 1e9); }

    static Map<String, Object> props(String group, boolean statik) {
        Map<String, Object> p = new HashMap<>();
        p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        p.put(ConsumerConfig.GROUP_ID_CONFIG, group);
        p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        p.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 20000);
        p.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 500);
        if (statik) p.put(ConsumerConfig.GROUP_INSTANCE_ID_CONFIG, "a-1");
        return p;
    }

    static String state(AdminClient admin, String group) throws Exception {
        var d = admin.describeConsumerGroups(List.of(group)).all().get().get(group);
        return d.groupState() + ", участников " + d.members().size();
    }

    static void run(AdminClient admin, boolean statik) throws Exception {
        String group = "g-" + (statik ? "static" : "dynamic"), topic = "rb8";
        System.out.println("--- " + (statik ? "статическое" : "динамическое") + " членство");
        AtomicBoolean count = new AtomicBoolean(), stop = new AtomicBoolean();
        List<String> events = Collections.synchronizedList(new ArrayList<>());
        Thread b = new Thread(() -> {
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(props(group, false))) {
                c.subscribe(List.of(topic), new ConsumerRebalanceListener() {
                    public void onPartitionsRevoked(Collection<TopicPartition> p) {
                        if (!p.isEmpty()) events.add(t() + " B отдал " + p.size() + (count.get() ? "" : " (до начала счёта)"));
                    }
                    public void onPartitionsAssigned(Collection<TopicPartition> p) {
                        if (!p.isEmpty()) events.add(t() + " B получил " + p.size());
                    }
                });
                while (!stop.get()) c.poll(Duration.ofMillis(200));
            }
        });
        b.start();
        KafkaConsumer<String, String> a = new KafkaConsumer<>(props(group, statik));
        a.subscribe(List.of(topic));
        long end = System.nanoTime() + 5_000_000_000L;
        while (System.nanoTime() < end) a.poll(Duration.ofMillis(200));
        events.add(t() + " перед началом счёта группа: " + state(admin, group));
        count.set(true);
        events.add(t() + " A закрывается");
        a.close();
        events.add(t() + " A закрыт, группа: " + state(admin, group));
        Thread.sleep(1000);
        a = new KafkaConsumer<>(props(group, statik));
        a.subscribe(List.of(topic));
        events.add(t() + " A подключается снова");
        end = System.nanoTime() + 6_000_000_000L;
        while (System.nanoTime() < end) a.poll(Duration.ofMillis(200));
        events.add(t() + " конец, группа: " + state(admin, group));
        a.close();
        stop.set(true);
        b.join();
        synchronized (events) { events.forEach(e -> System.out.println("  " + e)); }
    }

    public static void main(String[] args) throws Exception {
        EmbeddedKafkaKraftBroker broker = new EmbeddedKafkaKraftBroker(1, 8);
        broker.brokerProperty("offsets.topic.replication.factor", "1");
        broker.afterPropertiesSet();
        bootstrap = broker.getBrokersAsString();
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            admin.createTopics(List.of(new NewTopic("rb8", 8, (short) 1))).all().get();
            run(admin, false);
            run(admin, true);
        }
        broker.destroy();
        System.exit(0);
    }
}
