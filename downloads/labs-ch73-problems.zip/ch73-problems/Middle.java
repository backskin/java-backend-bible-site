import java.util.*;

public class Middle {

    // 3.1 Число непрерывных отрезков операций с суммой ровно k (суммы бывают отрицательными)
    static long countSegmentsWithSum(long[] ops, long k) {
        Map<Long, Integer> seen = new HashMap<>();
        seen.put(0L, 1);                       // пустой префикс
        long prefix = 0, count = 0;
        for (long op : ops) {
            prefix += op;
            count += seen.getOrDefault(prefix - k, 0);
            seen.merge(prefix, 1, Integer::sum);
        }
        return count;
    }

    // 3.2 Есть ли два платежа одного клиента на одну сумму с разницей не больше window секунд
    record Pay(String client, long amountKop, long epochSec) { }

    static boolean hasNearDuplicate(List<Pay> pays, long window) {   // pays отсортированы по времени
        Map<String, Long> lastSeen = new HashMap<>();
        for (Pay p : pays) {
            String key = p.client() + "|" + p.amountKop();
            Long prev = lastSeen.put(key, p.epochSec());
            if (prev != null && p.epochSec() - prev <= window) return true;
        }
        return false;
    }

    // 3.3 Минимальная производительность шлюза (поручений в час), чтобы уложиться в hours часов
    static int minThroughput(int[] batches, int hours) {
        int lo = 1, hi = Arrays.stream(batches).max().orElse(1);
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (hoursNeeded(batches, mid) <= hours) hi = mid; else lo = mid + 1;
        }
        return lo;
    }

    static long hoursNeeded(int[] batches, int perHour) {
        long h = 0;
        for (int b : batches) h += (b + perHour - 1) / perHour;   // остаток часа простаивает
        return h;
    }

    // 3.4 Порядок запуска регламентных заданий; пустой список, если есть цикл
    static List<String> runOrder(Map<String, List<String>> dependsOn) {
        Map<String, Integer> indegree = new HashMap<>();
        Map<String, List<String>> next = new HashMap<>();
        for (var e : dependsOn.entrySet()) {
            indegree.putIfAbsent(e.getKey(), 0);
            for (String dep : e.getValue()) {
                indegree.putIfAbsent(dep, 0);
                indegree.merge(e.getKey(), 1, Integer::sum);
                next.computeIfAbsent(dep, x -> new ArrayList<>()).add(e.getKey());
            }
        }
        Deque<String> ready = new ArrayDeque<>();
        indegree.forEach((job, d) -> { if (d == 0) ready.add(job); });
        List<String> order = new ArrayList<>();
        while (!ready.isEmpty()) {
            String job = ready.poll();
            order.add(job);
            for (String n : next.getOrDefault(job, List.of()))
                if (indegree.merge(n, -1, Integer::sum) == 0) ready.add(n);
        }
        return order.size() == indegree.size() ? order : List.of();
    }

    // 3.5 Наименьшее число конвертаций из валюты from в валюту to
    static int minConversions(List<String[]> pairs, String from, String to) {
        Map<String, List<String>> g = new HashMap<>();
        for (String[] p : pairs) {
            g.computeIfAbsent(p[0], x -> new ArrayList<>()).add(p[1]);
            g.computeIfAbsent(p[1], x -> new ArrayList<>()).add(p[0]);
        }
        Map<String, Integer> dist = new HashMap<>(Map.of(from, 0));
        Deque<String> q = new ArrayDeque<>(List.of(from));
        while (!q.isEmpty()) {
            String cur = q.poll();
            if (cur.equals(to)) return dist.get(cur);
            for (String n : g.getOrDefault(cur, List.of()))
                if (dist.putIfAbsent(n, dist.get(cur) + 1) == null) q.add(n);
        }
        return -1;
    }

    // 3.6 Наименьшее число купюр для выдачи суммы; -1, если выдать нельзя
    static int minNotes(int[] notes, int amount) {
        int[] best = new int[amount + 1];
        Arrays.fill(best, Integer.MAX_VALUE);
        best[0] = 0;
        for (int s = 1; s <= amount; s++)
            for (int n : notes)
                if (n <= s && best[s - n] != Integer.MAX_VALUE)
                    best[s] = Math.min(best[s], best[s - n] + 1);
        return best[amount] == Integer.MAX_VALUE ? -1 : best[amount];
    }

    static int greedyNotes(int[] notesDesc, int amount) {
        int count = 0;
        for (int n : notesDesc) { count += amount / n; amount %= n; }
        return amount == 0 ? count : -1;
    }

    // 3.7 Наибольшее число одновременных сессий, интервалы [start, end)
    static int maxConcurrent(int[][] sessions) {
        int n = sessions.length;
        int[] starts = new int[n], ends = new int[n];
        for (int i = 0; i < n; i++) { starts[i] = sessions[i][0]; ends[i] = sessions[i][1]; }
        Arrays.sort(starts); Arrays.sort(ends);
        int i = 0, j = 0, cur = 0, best = 0;
        while (i < n) {
            if (starts[i] < ends[j]) { cur++; i++; best = Math.max(best, cur); }
            else { cur--; j++; }                 // конец раньше или одновременно с началом
        }
        return best;
    }

    // 3.8 Медиана суммы чека в потоке
    static final class RunningMedian {
        private final PriorityQueue<Long> low = new PriorityQueue<>(Comparator.reverseOrder()); // нижняя половина
        private final PriorityQueue<Long> high = new PriorityQueue<>();                         // верхняя половина

        void add(long x) {
            if (low.isEmpty() || x <= low.peek()) low.add(x); else high.add(x);
            if (low.size() > high.size() + 1) high.add(low.poll());
            else if (high.size() > low.size()) low.add(high.poll());
        }

        double median() {
            if (low.size() > high.size()) return low.peek();
            return (low.peek() + high.peek()) / 2.0;
        }
    }

    static void check(boolean ok, String name) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
    }

    public static void main(String[] args) {
        check(countSegmentsWithSum(new long[]{300, -300, 300, -300}, 0) == 4, "3.1 нулевые отрезки");
        check(countSegmentsWithSum(new long[]{100, 200, 300}, 300) == 2, "3.1 сумма 300");
        check(countSegmentsWithSum(new long[]{}, 0) == 0, "3.1 пусто");
        var pays = List.of(new Pay("К1", 50000, 1000), new Pay("К2", 50000, 1100),
                new Pay("К1", 70000, 1200), new Pay("К1", 50000, 1550));
        check(hasNearDuplicate(pays, 600), "3.2 дубль за 550 с");
        check(!hasNearDuplicate(pays, 500), "3.2 окно 500 с");
        check(minThroughput(new int[]{3, 6, 7, 11}, 8) == 4, "3.3 производительность 4");
        check(minThroughput(new int[]{30, 11, 23, 4, 20}, 5) == 30, "3.3 часов = пачек");
        check(hoursNeeded(new int[]{1_000_000_000, 1_000_000_000, 1_000_000_000}, 1) == 3_000_000_000L, "3.3 без переполнения");
        Map<String, List<String>> deps = new LinkedHashMap<>();
        deps.put("отчёт ЦБ", List.of("закрытие дня", "курсы"));
        deps.put("закрытие дня", List.of("загрузка выписок"));
        deps.put("курсы", List.of());
        List<String> order = runOrder(deps);
        check(order.size() == 4 && order.indexOf("загрузка выписок") < order.indexOf("закрытие дня")
                && order.indexOf("закрытие дня") < order.indexOf("отчёт ЦБ"), "3.4 порядок " + order);
        deps.put("загрузка выписок", List.of("отчёт ЦБ"));
        check(runOrder(deps).isEmpty(), "3.4 цикл");
        List<String[]> pairs = List.of(new String[]{"RUB", "USD"}, new String[]{"USD", "EUR"},
                new String[]{"EUR", "CHF"}, new String[]{"RUB", "CNY"}, new String[]{"CNY", "CHF"});
        check(minConversions(pairs, "RUB", "CHF") == 2, "3.5 RUB→CHF за 2");
        check(minConversions(pairs, "RUB", "JPY") == -1, "3.5 нет пути");
        check(minConversions(pairs, "RUB", "RUB") == 0, "3.5 та же валюта");
        check(minNotes(new int[]{1, 3, 4}, 6) == 2 && greedyNotes(new int[]{4, 3, 1}, 6) == 3, "3.6 жадность ошибается");
        check(minNotes(new int[]{2000, 5000}, 6000) == 3 && greedyNotes(new int[]{5000, 2000}, 6000) == -1, "3.6 банкомат 6000");
        check(minNotes(new int[]{500}, 700) == -1, "3.6 нельзя выдать");
        check(maxConcurrent(new int[][]{{0, 30}, {10, 40}, {20, 25}, {30, 50}}) == 3, "3.7 пик 3");
        check(maxConcurrent(new int[][]{{0, 10}, {10, 20}}) == 1, "3.7 касание");
        RunningMedian rm = new RunningMedian();
        rm.add(500); check(rm.median() == 500, "3.8 один");
        rm.add(100); check(rm.median() == 300, "3.8 два");
        rm.add(900); check(rm.median() == 500, "3.8 три");
        rm.add(100); check(rm.median() == 300, "3.8 четыре");
    }
}
