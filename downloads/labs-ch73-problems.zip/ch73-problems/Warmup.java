import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

public class Warmup {

    // 1. Первый повторившийся номер поручения
    static String firstRepeated(List<String> ids) {
        Set<String> seen = new HashSet<>();
        for (String id : ids) {
            if (!seen.add(id)) return id;
        }
        return null;
    }

    // 2. Первая операция, после которой остаток ушёл в минус
    static int firstOverdraft(long opening, long[] ops) {
        long balance = opening;
        for (int i = 0; i < ops.length; i++) {
            balance += ops[i];
            if (balance < 0) return i;
        }
        return -1;
    }

    // 2а. Минимальный стартовый остаток, при котором минуса не будет
    static long minOpening(long[] ops) {
        long prefix = 0, min = 0;
        for (long op : ops) {
            prefix += op;
            min = Math.min(min, prefix);
        }
        return -min;
    }

    // 3. Две суммы в отсортированном реестре, дающие сумму возврата
    static int[] pairWithSum(long[] sorted, long target) {
        int i = 0, j = sorted.length - 1;
        while (i < j) {
            long s = sorted[i] + sorted[j];
            if (s == target) return new int[]{i, j};
            if (s < target) i++; else j--;
        }
        return null;
    }

    // 4. Правильность скобок в выражении тарифного правила
    static boolean balanced(String expr) {
        Deque<Character> stack = new ArrayDeque<>();
        for (char c : expr.toCharArray()) {
            switch (c) {
                case '(', '[', '{' -> stack.push(c);
                case ')', ']', '}' -> {
                    if (stack.isEmpty()) return false;
                    char open = stack.pop();
                    if (open != switch (c) { case ')' -> '('; case ']' -> '['; default -> '{'; }) return false;
                }
                default -> { }
            }
        }
        return stack.isEmpty();
    }

    // 5. Самый длинный отрезок журнала, где не больше k отказов
    static int longestWithAtMostK(boolean[] declined, int k) {
        int left = 0, fails = 0, best = 0;
        for (int right = 0; right < declined.length; right++) {
            if (declined[right]) fails++;
            while (fails > k) {
                if (declined[left]) fails--;
                left++;
            }
            best = Math.max(best, right - left + 1);
        }
        return best;
    }

    // 6. Курс, действующий на дату: последний с датой <= d
    static BigDecimal rateOn(LocalDate[] dates, BigDecimal[] rates, LocalDate d) {
        int lo = 0, hi = dates.length - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (!dates[mid].isAfter(d)) { ans = mid; lo = mid + 1; }
            else hi = mid - 1;
        }
        return ans < 0 ? null : rates[ans];
    }

    // 7. Объединение технологических окон (минуты от начала суток, [start, end))
    static List<int[]> mergeWindows(int[][] windows) {
        int[][] w = windows.clone();
        Arrays.sort(w, Comparator.comparingInt(a -> a[0]));
        List<int[]> out = new ArrayList<>();
        for (int[] cur : w) {
            if (out.isEmpty() || out.getLast()[1] < cur[0]) out.add(cur.clone());
            else out.getLast()[1] = Math.max(out.getLast()[1], cur[1]);
        }
        return out;
    }

    // 8. k торговых точек с наибольшим оборотом
    record Payment(String merchant, long amountKop) { }

    static List<String> topK(List<Payment> payments, int k) {
        Map<String, Long> turnover = new HashMap<>();
        for (Payment p : payments) turnover.merge(p.merchant(), p.amountKop(), Long::sum);
        PriorityQueue<Map.Entry<String, Long>> heap =
                new PriorityQueue<>(Map.Entry.comparingByValue());
        for (var e : turnover.entrySet()) {
            heap.offer(e);
            if (heap.size() > k) heap.poll();
        }
        List<String> out = new ArrayList<>();
        while (!heap.isEmpty()) out.add(heap.poll().getKey());
        Collections.reverse(out);
        return out;
    }

    static void check(boolean ok, String name) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
    }

    public static void main(String[] args) {
        check("П-2".equals(firstRepeated(List.of("П-1", "П-2", "П-3", "П-2", "П-1"))), "1 повтор");
        check(firstRepeated(List.of()) == null, "1 пустой");
        check(firstOverdraft(1000, new long[]{-300, -500, 200, -600}) == 3, "2 минус на 3");
        check(firstOverdraft(0, new long[]{}) == -1, "2 пусто");
        check(minOpening(new long[]{-300, -500, 200, -600}) == 1200, "2а стартовый 1200");
        check(minOpening(new long[]{100, 200}) == 0, "2а без минуса");
        check(Arrays.equals(pairWithSum(new long[]{100, 250, 400, 700, 900}, 1100), new int[]{2, 3}), "3 пара");
        check(pairWithSum(new long[]{500}, 1000) == null, "3 один элемент");
        check(balanced("{ [ (a + b) * c ] }"), "4 верно");
        check(!balanced("( [ ) ]"), "4 крест");
        check(!balanced("(("), "4 незакрыто");
        check(!balanced(")"), "4 лишняя закрывающая");
        boolean T = true, F = false;
        check(longestWithAtMostK(new boolean[]{F, T, F, F, T, T, F, F, F}, 1) == 4, "5 k=1");
        check(longestWithAtMostK(new boolean[]{T, T}, 0) == 0, "5 все отказы");
        LocalDate[] d = {LocalDate.of(2026, 1, 1), LocalDate.of(2026, 3, 1), LocalDate.of(2026, 6, 1)};
        BigDecimal[] r = {new BigDecimal("90.10"), new BigDecimal("88.50"), new BigDecimal("91.20")};
        check(r[1].equals(rateOn(d, r, LocalDate.of(2026, 5, 31))), "6 внутри");
        check(r[2].equals(rateOn(d, r, LocalDate.of(2026, 6, 1))), "6 точная дата");
        check(rateOn(d, r, LocalDate.of(2025, 12, 31)) == null, "6 раньше всех");
        var m = mergeWindows(new int[][]{{60, 120}, {0, 30}, {110, 180}, {180, 200}, {300, 310}});
        check(m.size() == 3 && m.get(0)[1] == 30 && m.get(1)[0] == 60 && m.get(1)[1] == 200, "7 слияние");
        var top = topK(List.of(new Payment("А", 500), new Payment("Б", 300), new Payment("В", 900),
                new Payment("Б", 400), new Payment("Г", 100)), 2);
        check(top.equals(List.of("В", "Б")), "8 топ-2 " + top);
    }
}
