import java.util.*;

/** Стресс-тест: быстрое решение против перебора на тысячах маленьких случайных входов. */
public class StressTest {

    static long fast(long[] ops, long k) {                  // решение задачи 3.1
        Map<Long, Integer> seen = new HashMap<>();
        seen.put(0L, 1);
        long prefix = 0, count = 0;
        for (long op : ops) {
            prefix += op;
            count += seen.getOrDefault(prefix - k, 0);
            seen.merge(prefix, 1, Integer::sum);
        }
        return count;
    }

    static long buggy(long[] ops, long k) {                 // та же идея, но строки в цикле переставлены
        Map<Long, Integer> seen = new HashMap<>();
        seen.put(0L, 1);
        long prefix = 0, count = 0;
        for (long op : ops) {
            prefix += op;
            seen.merge(prefix, 1, Integer::sum);
            count += seen.getOrDefault(prefix - k, 0);
        }
        return count;
    }

    static long brute(long[] ops, long k) {                 // O(n²), очевидно верный
        long count = 0;
        for (int i = 0; i < ops.length; i++) {
            long s = 0;
            for (int j = i; j < ops.length; j++) {
                s += ops[j];
                if (s == k) count++;
            }
        }
        return count;
    }

    interface Solution { long run(long[] ops, long k); }

    static void stress(String name, Solution s) {
        Random rnd = new Random(42);                        // фиксированное зерно: падение воспроизводится
        for (int iter = 0; iter < 10_000; iter++) {
            int n = rnd.nextInt(8);                         // маленькие входы: ответ легко проверить глазами
            long[] ops = new long[n];
            for (int i = 0; i < n; i++) ops[i] = rnd.nextInt(7) - 3;   // от -3 до 3, много нулей и повторов
            long k = rnd.nextInt(5) - 2;
            long expected = brute(ops, k), actual = s.run(ops, k);
            if (expected != actual) {
                System.out.println(name + ": расхождение на итерации " + iter + ", ops=" + Arrays.toString(ops)
                        + ", k=" + k + ", ожидалось " + expected + ", получено " + actual);
                return;
            }
        }
        System.out.println(name + ": 10000 случайных входов, расхождений нет");
    }

    public static void main(String[] args) {
        stress("fast", StressTest::fast);
        stress("buggy", StressTest::buggy);
    }
}
