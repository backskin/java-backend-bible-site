-- Функциональная зависимость в GROUP BY: PostgreSQL 18. Разделитель инструкций — двойная точка с запятой для tmp/sqlrun.py.
DROP SCHEMA IF EXISTS kg CASCADE;;
CREATE SCHEMA kg;;
CREATE TABLE kg.accounts (account_id int PRIMARY KEY, account_name text NOT NULL);;
CREATE TABLE kg.payments (id int PRIMARY KEY, account_id int NOT NULL REFERENCES kg.accounts, amount_kop bigint NOT NULL);;
INSERT INTO kg.accounts VALUES (1,'ООО Альфа'),(2,'ИП Бета');;
INSERT INTO kg.payments VALUES (1,1,500),(2,1,700),(3,2,300);;
-- 1. Группировка по первичному ключу accounts: account_name функционально зависим
SELECT a.account_id, a.account_name, sum(p.amount_kop) AS total
FROM kg.accounts a JOIN kg.payments p USING (account_id)
GROUP BY a.account_id
ORDER BY a.account_id;;
-- 2. Группировка по внешнему ключу payments.account_id: зависимость PostgreSQL не выводит
SELECT p.account_id, a.account_name, sum(p.amount_kop) AS total
FROM kg.accounts a JOIN kg.payments p USING (account_id)
GROUP BY p.account_id;;
-- 3. Столбец, не зависящий от группировки: ошибка
SELECT a.account_id, p.id, sum(p.amount_kop)
FROM kg.accounts a JOIN kg.payments p USING (account_id)
GROUP BY a.account_id;;
DROP SCHEMA kg CASCADE;;
