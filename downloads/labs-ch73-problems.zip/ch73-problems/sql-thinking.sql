-- Задачи раздела «SQL-мышление», PostgreSQL 18. Инструкции разделены двойной точкой с запятой для tmp/sqlrun.py.
DROP SCHEMA IF EXISTS t73 CASCADE;;
CREATE SCHEMA t73;;
CREATE TABLE t73.orders (id bigint PRIMARY KEY, doc_no text NOT NULL);;
INSERT INTO t73.orders VALUES (1,'П-1'),(2,'П-2'),(3,'П-3'),(4,'П-2'),(5,'П-1');;
-- 7.1 Первое повторившееся поручение
SELECT doc_no, id
FROM (SELECT doc_no, id, row_number() OVER (PARTITION BY doc_no ORDER BY id) AS n FROM t73.orders) s
WHERE n = 2
ORDER BY id
LIMIT 1;;
CREATE TABLE t73.ops (seq int PRIMARY KEY, amount_kop bigint NOT NULL);;
INSERT INTO t73.ops VALUES (1,-300),(2,-500),(3,200),(4,-600);;
-- 7.2 Остаток после каждой операции и первая операция с минусом при начальном остатке 1000
SELECT seq, amount_kop, 1000 + sum(amount_kop) OVER (ORDER BY seq) AS balance
FROM t73.ops
ORDER BY seq;;
SELECT min(seq) AS first_overdraft
FROM (SELECT seq, 1000 + sum(amount_kop) OVER (ORDER BY seq) AS balance FROM t73.ops) s
WHERE balance < 0;;
-- 7.2а Наименьший начальный остаток без ухода в минус
SELECT greatest(0, -min(running)) AS min_opening
FROM (SELECT sum(amount_kop) OVER (ORDER BY seq) AS running FROM t73.ops) s;;
CREATE TABLE t73.sessions (id int PRIMARY KEY, started int NOT NULL, ended int NOT NULL);;
INSERT INTO t73.sessions VALUES (1,0,30),(2,10,40),(3,20,25),(4,30,50),(5,40,41);;
-- 7.3 Наибольшее число одновременных сессий, [started, ended)
SELECT max(open_now) AS peak
FROM (SELECT sum(delta) OVER (ORDER BY t, delta) AS open_now
      FROM (SELECT started AS t, 1 AS delta FROM t73.sessions
            UNION ALL
            SELECT ended, -1 FROM t73.sessions) e) s;;
CREATE TABLE t73.pay (merchant text, region text, amount_kop bigint);;
INSERT INTO t73.pay VALUES ('А','Москва',500),('Б','Москва',700),('В','Москва',700),('Г','Москва',100),
  ('Д','Казань',300),('Е','Казань',200),('Д','Казань',100);;
-- 7.4 Две крупнейшие точки в каждом регионе: row_number против dense_rank при равных оборотах
SELECT region, merchant, turnover, rn, dr
FROM (SELECT region, merchant, sum(amount_kop) AS turnover,
             row_number() OVER (PARTITION BY region ORDER BY sum(amount_kop) DESC, merchant) AS rn,
             dense_rank() OVER (PARTITION BY region ORDER BY sum(amount_kop) DESC) AS dr
      FROM t73.pay GROUP BY region, merchant) s
WHERE dr <= 2
ORDER BY region, turnover DESC, merchant;;
CREATE TABLE t73.days (client text, d date);;
INSERT INTO t73.days VALUES ('К1','2026-10-01'),('К1','2026-10-02'),('К1','2026-10-03'),('К1','2026-10-05'),
  ('К1','2026-10-06'),('К1','2026-10-06'),('К2','2026-10-10');;
-- 7.5 Самая длинная серия дней подряд с платежами («острова»)
SELECT client, min(d) AS from_day, max(d) AS to_day, count(*) AS days
FROM (SELECT client, d, d - (row_number() OVER (PARTITION BY client ORDER BY d))::int AS grp
      FROM (SELECT DISTINCT client, d FROM t73.days) u) s
GROUP BY client, grp
ORDER BY days DESC, client
LIMIT 3;;
CREATE TABLE t73.txn (id bigint PRIMARY KEY, client text, created_at timestamptz, amount_kop bigint);;
INSERT INTO t73.txn SELECT g, 'К' || (g % 100), timestamptz '2026-01-01' + g * interval '1 second', g FROM generate_series(1, 200000) g;;
CREATE INDEX ON t73.txn (created_at, id);;
ANALYZE t73.txn;;
-- 7.6 Страница по OFFSET и по ключу
EXPLAIN (ANALYZE, COSTS OFF, TIMING OFF, SUMMARY OFF)
SELECT id FROM t73.txn ORDER BY created_at, id OFFSET 190000 LIMIT 20;;
EXPLAIN (ANALYZE, COSTS OFF, TIMING OFF, SUMMARY OFF)
SELECT id FROM t73.txn WHERE (created_at, id) > (timestamptz '2026-01-01' + 190000 * interval '1 second', 190000)
ORDER BY created_at, id LIMIT 20;;
DROP SCHEMA t73 CASCADE;;
