import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.*;
import java.util.function.*;

public class Design {

    // 5.1 Калькулятор комиссии: процент с минимумом и максимумом плюс фиксированная часть
    record Tariff(BigDecimal percent, BigDecimal min, BigDecimal max, BigDecimal fixed) {
        Tariff {
            if (min.compareTo(max) > 0) throw new IllegalArgumentException("min > max");
        }
        BigDecimal fee(BigDecimal amount) {
            if (amount.signum() <= 0) throw new IllegalArgumentException("сумма должна быть положительной");
            BigDecimal byPercent = amount.multiply(percent).movePointLeft(2);      // percent в процентах: 1.5 = 1,5 %
            BigDecimal clamped = byPercent.max(min).min(max);
            return clamped.add(fixed).setScale(2, RoundingMode.HALF_EVEN);         // округляем один раз, в конце
        }
    }

    // 5.2 Разбор выписки: итоги по валютам и список ошибок с номерами строк
    record Totals(Map<String, BigDecimal> byCurrency, List<String> errors) { }

    static Totals parseStatement(List<String> lines) {
        Map<String, BigDecimal> totals = new TreeMap<>();
        List<String> errors = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.isBlank()) continue;
            String[] f = line.split(";", -1);                                       // -1: не терять пустые поля в конце
            if (f.length != 4) { errors.add("строка " + (i + 1) + ": ожидалось 4 поля, получено " + f.length); continue; }
            String ccy = f[2].trim().toUpperCase(Locale.ROOT);
            if (!ccy.matches("[A-Z]{3}")) { errors.add("строка " + (i + 1) + ": неверная валюта '" + f[2] + "'"); continue; }
            BigDecimal amount;
            try {
                amount = new BigDecimal(f[1].replace(" ", "").replace(" ", "").replace(',', '.'));
            } catch (NumberFormatException e) {
                errors.add("строка " + (i + 1) + ": неверная сумма '" + f[1] + "'");
                continue;
            }
            totals.merge(ccy, amount, BigDecimal::add);
        }
        return new Totals(totals, errors);
    }

    // 5.3 Итератор по страницам партнёрского API с курсором
    record Page<T>(List<T> items, String nextCursor) { }

    static final class PagedIterator<T> implements Iterator<T> {
        private final Function<String, Page<T>> fetch;
        private Iterator<T> current = Collections.emptyIterator();
        private String cursor;            // null до первого запроса
        private boolean started, finished;

        PagedIterator(Function<String, Page<T>> fetch) { this.fetch = fetch; }

        @Override public boolean hasNext() {
            while (!current.hasNext() && !finished) {                              // пустые страницы пропускаем
                Page<T> page = fetch.apply(started ? cursor : null);
                started = true;
                current = page.items().iterator();
                cursor = page.nextCursor();
                if (cursor == null) finished = true;
            }
            return current.hasNext();
        }

        @Override public T next() {
            if (!hasNext()) throw new NoSuchElementException();
            return current.next();
        }
    }

    // 5.4 Хранилище ключ-значение с вложенными транзакциями
    static final class TxStore {
        private static final Object TOMBSTONE = new Object();
        private final Map<String, String> committed = new HashMap<>();
        private final Deque<Map<String, Object>> tx = new ArrayDeque<>();    // верх стека — самая внутренняя транзакция

        String get(String key) {
            for (Map<String, Object> layer : tx) {                              // ArrayDeque итерирует от вершины
                if (layer.containsKey(key)) {
                    Object v = layer.get(key);
                    return v == TOMBSTONE ? null : (String) v;
                }
            }
            return committed.get(key);
        }

        void set(String key, String value) { write(key, value); }
        void delete(String key) { write(key, TOMBSTONE); }

        private void write(String key, Object value) {
            if (tx.isEmpty()) {
                if (value == TOMBSTONE) committed.remove(key); else committed.put(key, (String) value);
            } else {
                tx.peek().put(key, value);
            }
        }

        void begin() { tx.push(new HashMap<>()); }

        void rollback() {
            if (tx.isEmpty()) throw new IllegalStateException("нет открытой транзакции");
            tx.pop();
        }

        void commit() {                                                         // фиксирует внутреннюю в объемлющую
            if (tx.isEmpty()) throw new IllegalStateException("нет открытой транзакции");
            Map<String, Object> top = tx.pop();
            top.forEach(this::write);
        }
    }

    // 5.5 Планировщик с задержкой на одном рабочем потоке
    static final class DelayScheduler implements AutoCloseable {
        private record Job(long dueNanos, long seq, Runnable task, AtomicBoolean cancelled) { }

        private final PriorityQueue<Job> queue = new PriorityQueue<>(
                Comparator.comparingLong(Job::dueNanos).thenComparingLong(Job::seq));
        private final ReentrantLock lock = new ReentrantLock();
        private final Condition changed = lock.newCondition();
        private long seq;
        private volatile boolean closed;
        private final Thread worker = new Thread(this::loop, "delay-scheduler");

        DelayScheduler() { worker.start(); }

        Runnable schedule(Runnable task, long delayMs) {
            AtomicBoolean cancelled = new AtomicBoolean();
            lock.lock();
            try {
                queue.add(new Job(System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(delayMs), seq++, task, cancelled));
                changed.signal();                                               // новая задача может быть раньше прежней первой
            } finally { lock.unlock(); }
            return () -> cancelled.set(true);
        }

        private void loop() {
            while (!closed) {
                Job job;
                lock.lock();
                try {
                    while (!closed && (queue.isEmpty() || queue.peek().dueNanos() > System.nanoTime())) {
                        if (queue.isEmpty()) changed.await();
                        else changed.awaitNanos(queue.peek().dueNanos() - System.nanoTime());
                    }
                    if (closed) return;
                    job = queue.poll();
                } catch (InterruptedException e) {
                    return;
                } finally { lock.unlock(); }
                if (!job.cancelled().get()) {
                    try { job.task().run(); }                                   // вне блокировки: задача может быть долгой
                    catch (RuntimeException e) { System.err.println("задача упала: " + e); }
                }
            }
        }

        @Override public void close() throws InterruptedException {
            closed = true;
            lock.lock();
            try { changed.signalAll(); } finally { lock.unlock(); }
            worker.join();
        }
    }

    static void check(boolean ok, String name) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
    }

    public static void main(String[] args) throws Exception {
        Tariff t = new Tariff(new BigDecimal("1.5"), new BigDecimal("30"), new BigDecimal("3000"), new BigDecimal("10"));
        check(t.fee(new BigDecimal("1000")).equals(new BigDecimal("40.00")), "5.1 минимум 30 + 10");
        check(t.fee(new BigDecimal("10000")).equals(new BigDecimal("160.00")), "5.1 1,5 % от 10 000 + 10");
        check(t.fee(new BigDecimal("1000000")).equals(new BigDecimal("3010.00")), "5.1 максимум 3000 + 10");
        check(t.fee(new BigDecimal("2333.33")).equals(new BigDecimal("45.00")), "5.1 35,0000 → 45,00");
        Tariff t2 = new Tariff(new BigDecimal("1"), BigDecimal.ZERO, new BigDecimal("1000000"), BigDecimal.ZERO);
        check(t2.fee(new BigDecimal("0.50")).equals(new BigDecimal("0.00")) && t2.fee(new BigDecimal("1.50")).equals(new BigDecimal("0.02")), "5.1 банковское округление 0,005→0,00 и 0,015→0,02");
        check(0.1 + 0.2 != 0.3 && new BigDecimal("0.1").add(new BigDecimal("0.2")).compareTo(new BigDecimal("0.3")) == 0, "5.1 double против BigDecimal");
        check(!new BigDecimal("1.0").equals(new BigDecimal("1.00")) && new BigDecimal("1.0").compareTo(new BigDecimal("1.00")) == 0, "5.1 equals учитывает масштаб");

        Totals tot = parseStatement(List.of(
                "2026-10-01;1 234,56;RUB;зарплата",
                "2026-10-01;-200.00;rub;кафе",
                "2026-10-02;15;USD;перевод",
                "2026-10-02;abc;RUB;ошибка суммы",
                "2026-10-03;10;RUBL;ошибка валюты",
                "",
                "2026-10-03;5;EUR",
                "2026-10-04;100;RUB;назначение;с точкой с запятой"));
        check(tot.byCurrency().equals(Map.of("RUB", new BigDecimal("1034.56"), "USD", new BigDecimal("15"))), "5.2 итоги " + tot.byCurrency());
        check(tot.errors().size() == 4 && tot.errors().get(0).startsWith("строка 4"), "5.2 ошибки " + tot.errors());

        Map<String, Page<Integer>> api = Map.of(
                "start", new Page<>(List.of(1, 2), "c1"),
                "c1", new Page<>(List.of(), "c2"),
                "c2", new Page<>(List.of(3), "c3"),
                "c3", new Page<>(List.of(), null));
        AtomicInteger calls = new AtomicInteger();
        PagedIterator<Integer> it = new PagedIterator<>(c -> { calls.incrementAndGet(); return api.get(c == null ? "start" : c); });
        check(it.hasNext() && it.hasNext() && calls.get() == 1, "5.3 hasNext не делает лишних запросов");
        List<Integer> got = new ArrayList<>();
        it.forEachRemaining(got::add);
        check(got.equals(List.of(1, 2, 3)) && calls.get() == 4 && !it.hasNext(), "5.3 пустые страницы пропущены " + got);
        PagedIterator<Integer> empty = new PagedIterator<>(c -> new Page<>(List.of(), null));
        boolean threw = false;
        try { empty.next(); } catch (NoSuchElementException e) { threw = true; }
        check(!empty.hasNext() && threw, "5.3 пустой источник");

        TxStore s = new TxStore();
        s.set("limit", "100");
        s.begin(); s.set("limit", "200"); check("200".equals(s.get("limit")), "5.4 внутри транзакции");
        s.begin(); s.delete("limit"); check(s.get("limit") == null, "5.4 удаление во вложенной");
        s.rollback(); check("200".equals(s.get("limit")), "5.4 откат вложенной");
        s.commit(); check("200".equals(s.get("limit")), "5.4 фиксация");
        s.begin(); s.delete("limit"); s.begin(); s.set("x", "1"); s.commit(); s.commit();
        check(s.get("limit") == null && "1".equals(s.get("x")), "5.4 удаление и запись дошли до основы");
        boolean ise = false;
        try { s.rollback(); } catch (IllegalStateException e) { ise = true; }
        check(ise, "5.4 откат без транзакции");

        List<String> order = Collections.synchronizedList(new ArrayList<>());
        try (DelayScheduler ds = new DelayScheduler()) {
            ds.schedule(() -> order.add("через 300"), 300);
            Runnable cancel = ds.schedule(() -> order.add("отменённая"), 200);
            ds.schedule(() -> order.add("через 100"), 100);
            ds.schedule(() -> { throw new IllegalStateException("сбой задачи"); }, 150);
            ds.schedule(() -> order.add("через 250"), 250);
            cancel.run();
            Thread.sleep(500);
        }
        check(order.equals(List.of("через 100", "через 250", "через 300")), "5.5 порядок " + order);
    }
}
