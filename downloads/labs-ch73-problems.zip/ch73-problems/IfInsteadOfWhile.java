import java.util.*;

/** Буфер с if вместо while: потребитель просыпается, а элемент уже забрал другой. */
public class IfInsteadOfWhile {

    static final class Buffer {
        private final ArrayDeque<String> q = new ArrayDeque<>();
        private final boolean recheck;
        Buffer(boolean recheck) { this.recheck = recheck; }

        synchronized void put(String x) {
            q.addLast(x);
            notifyAll();
        }

        synchronized String take() throws InterruptedException {
            if (recheck) { while (q.isEmpty()) wait(); }   // правильно: условие проверяется после пробуждения
            else         { if (q.isEmpty()) wait(); }      // ОШИБКА: после пробуждения очередь может быть снова пуста
            return q.removeFirst();
        }
    }

    static void scenario(boolean recheck) throws InterruptedException {
        Buffer buf = new Buffer(recheck);
        List<String> log = Collections.synchronizedList(new ArrayList<>());
        Runnable consumer = () -> {
            try { log.add(Thread.currentThread().getName() + " получил " + buf.take()); }
            catch (NoSuchElementException e) { log.add(Thread.currentThread().getName() + " упал: NoSuchElementException"); }
            catch (InterruptedException e) { log.add(Thread.currentThread().getName() + " прерван, так и не дождавшись"); }
        };
        Thread c1 = new Thread(consumer, "потребитель-1"), c2 = new Thread(consumer, "потребитель-2");
        c1.start(); c2.start();
        Thread.sleep(200);                 // оба потребителя уже ждут на пустом буфере
        buf.put("платёж-1");               // один элемент, notifyAll будит обоих
        c1.join(500); c2.join(500);
        c1.interrupt(); c2.interrupt();    // при while второй потребитель ждёт следующего элемента: снимаем его
        c1.join(); c2.join();
        log.sort(null);
        System.out.println((recheck ? "while: " : "if:    ") + log);
    }

    public static void main(String[] args) throws Exception {
        scenario(false);
        scenario(true);
    }
}
