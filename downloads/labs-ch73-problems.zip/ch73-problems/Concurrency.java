import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.*;

public class Concurrency {

    // 6.1 Ограниченный буфер на Lock и двух Condition
    static final class BoundedBuffer<T> {
        private final Object[] items;
        private int head, tail, count;
        private final ReentrantLock lock = new ReentrantLock();
        private final Condition notFull = lock.newCondition();
        private final Condition notEmpty = lock.newCondition();

        BoundedBuffer(int capacity) { items = new Object[capacity]; }

        void put(T x) throws InterruptedException {
            lock.lock();
            try {
                while (count == items.length) notFull.await();     // в цикле: пробуждение не гарантирует условия
                items[tail] = x;
                tail = (tail + 1) % items.length;
                count++;
                notEmpty.signal();                                 // ждущие take ждут одного и того же
            } finally {
                lock.unlock();
            }
        }

        @SuppressWarnings("unchecked")
        T take() throws InterruptedException {
            lock.lock();
            try {
                while (count == 0) notEmpty.await();
                T x = (T) items[head];
                items[head] = null;                                // не держим ссылку на отданный элемент
                head = (head + 1) % items.length;
                count--;
                notFull.signal();
                return x;
            } finally {
                lock.unlock();
            }
        }
    }

    // 6.1а Тот же буфер на synchronized: одна очередь условий, поэтому notifyAll
    static final class MonitorBuffer<T> {
        private final ArrayDeque<T> q = new ArrayDeque<>();
        private final int capacity;
        MonitorBuffer(int capacity) { this.capacity = capacity; }

        synchronized void put(T x) throws InterruptedException {
            while (q.size() == capacity) wait();
            q.addLast(x);
            notifyAll();
        }

        synchronized T take() throws InterruptedException {
            while (q.isEmpty()) wait();
            T x = q.removeFirst();
            notifyAll();
            return x;
        }
    }

    // 6.2 Два обработчика по очереди: первый берёт нечётные пачки, второй чётные
    static List<String> alternate(int n) throws InterruptedException {
        List<String> log = Collections.synchronizedList(new ArrayList<>());
        Semaphore oddTurn = new Semaphore(1), evenTurn = new Semaphore(0);
        Thread odd = new Thread(() -> {
            try {
                for (int i = 1; i <= n; i += 2) { oddTurn.acquire(); log.add("A:" + i); evenTurn.release(); }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });
        Thread even = new Thread(() -> {
            try {
                for (int i = 2; i <= n; i += 2) { evenTurn.acquire(); log.add("B:" + i); oddTurn.release(); }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });
        odd.start(); even.start(); odd.join(); even.join();
        return log;
    }

    // 6.3 Кольцо счетов: обработчик i переводит со счёта i на счёт (i + 1) % n
    static final class Account {
        final int id; long balance;
        Account(int id, long balance) { this.id = id; this.balance = balance; }
    }

    static void transferOrdered(Account from, Account to, long amount) {
        Account first = from.id < to.id ? from : to, second = first == from ? to : from;
        synchronized (first) { synchronized (second) { from.balance -= amount; to.balance += amount; } }
    }

    static boolean ring(int n, int iterations) throws InterruptedException {
        Account[] acc = new Account[n];
        for (int i = 0; i < n; i++) acc[i] = new Account(i, 1_000_000);
        Thread[] t = new Thread[n];
        for (int i = 0; i < n; i++) {
            Account from = acc[i], to = acc[(i + 1) % n];
            t[i] = new Thread(() -> { for (int k = 0; k < iterations; k++) transferOrdered(from, to, 1); });
            t[i].setDaemon(true);
            t[i].start();
        }
        for (Thread th : t) th.join(10_000);
        long total = 0;
        for (Account a : acc) total += a.balance;
        return Arrays.stream(t).noneMatch(Thread::isAlive) && total == n * 1_000_000L;
    }

    // 6.4 Справочник курсов: читают постоянно, обновляют раз в минуту
    static final class RatesCache {
        private volatile Map<String, Long> rates = Map.of();       // неизменяемый снимок
        long get(String ccy) { return rates.getOrDefault(ccy, -1L); }
        void reload(Map<String, Long> fresh) { rates = Map.copyOf(fresh); }   // публикация через volatile
    }

    // 6.5 Не больше limit одновременных вызовов партнёра
    static final class PartnerGate {
        private final Semaphore permits;
        PartnerGate(int limit) { permits = new Semaphore(limit); }

        <T> T call(Callable<T> body, long waitMs) throws Exception {
            if (!permits.tryAcquire(waitMs, TimeUnit.MILLISECONDS))
                throw new RejectedExecutionException("партнёр перегружен, ждали " + waitMs + " мс");
            try { return body.call(); }
            finally { permits.release(); }                          // только если разрешение взято
        }
    }

    // 6.6 Ленивая загрузка справочника ровно один раз
    static final AtomicInteger loads = new AtomicInteger();

    static final class Directory {
        private static final class Holder {
            static final Map<String, String> BIC = load();
        }
        static Map<String, String> bic() { return Holder.BIC; }
        private static Map<String, String> load() {
            loads.incrementAndGet();
            try { Thread.sleep(50); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            return Map.of("044525225", "ПАО Сбербанк");
        }
    }

    static void check(boolean ok, String name) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
    }

    static long drain(int producers, int consumers, int perProducer, java.util.function.Supplier<Object> make) throws Exception {
        // производители кладут числа 1..perProducer, потребители суммируют; сумма должна сойтись
        Object buf = make.get();
        ExecutorService ex = Executors.newFixedThreadPool(producers + consumers);
        AtomicLong sum = new AtomicLong();
        int total = producers * perProducer;
        List<Future<?>> fs = new ArrayList<>();
        for (int p = 0; p < producers; p++) fs.add(ex.submit(() -> {
            for (int i = 1; i <= perProducer; i++) {
                if (buf instanceof BoundedBuffer<?> b) ((BoundedBuffer<Integer>) b).put(i);
                else ((MonitorBuffer<Integer>) buf).put(i);
            }
            return null;
        }));
        for (int c = 0; c < consumers; c++) {
            int share = total / consumers + (c < total % consumers ? 1 : 0);
            fs.add(ex.submit(() -> {
                for (int i = 0; i < share; i++) {
                    int v = buf instanceof BoundedBuffer<?> b ? ((BoundedBuffer<Integer>) b).take()
                                                             : ((MonitorBuffer<Integer>) buf).take();
                    sum.addAndGet(v);
                }
                return null;
            }));
        }
        for (Future<?> f : fs) f.get(20, TimeUnit.SECONDS);
        ex.shutdown();
        return sum.get();
    }

    public static void main(String[] args) throws Exception {
        long expected = 4L * (100_000L * 100_001L / 2);
        check(drain(4, 3, 100_000, () -> new BoundedBuffer<Integer>(8)) == expected, "6.1 Condition: сумма сошлась");
        check(drain(4, 3, 100_000, () -> new MonitorBuffer<Integer>(8)) == expected, "6.1а monitor: сумма сошлась");

        List<String> log = alternate(10);
        check(log.equals(List.of("A:1", "B:2", "A:3", "B:4", "A:5", "B:6", "A:7", "B:8", "A:9", "B:10")), "6.2 очередность " + log);

        check(ring(5, 1_000_000), "6.3 кольцо из 5 счетов без взаимоблокировки, сумма сохранена");

        RatesCache rc = new RatesCache();
        rc.reload(Map.of("USD", 9010L));
        AtomicBoolean bad = new AtomicBoolean();
        Thread reader = new Thread(() -> { for (int i = 0; i < 1_000_000; i++) if (rc.get("USD") < 0) bad.set(true); });
        reader.start();
        for (int i = 0; i < 1000; i++) rc.reload(Map.of("USD", 9000L + i, "EUR", 9800L));
        reader.join();
        check(!bad.get() && rc.get("EUR") == 9800L, "6.4 читатель всегда видит целый снимок");

        PartnerGate gate = new PartnerGate(3);
        AtomicInteger inFlight = new AtomicInteger(), maxInFlight = new AtomicInteger(), rejected = new AtomicInteger();
        ExecutorService ex = Executors.newFixedThreadPool(10);
        List<Future<?>> fs = new ArrayList<>();
        for (int i = 0; i < 10; i++) fs.add(ex.submit(() -> {
            try {
                gate.call(() -> {
                    int now = inFlight.incrementAndGet();
                    maxInFlight.accumulateAndGet(now, Math::max);
                    Thread.sleep(200);
                    inFlight.decrementAndGet();
                    return null;
                }, 50);
            } catch (RejectedExecutionException e) { rejected.incrementAndGet(); }
            catch (Exception e) { throw new RuntimeException(e); }
        }));
        for (Future<?> f : fs) f.get();
        ex.shutdown();
        check(maxInFlight.get() == 3 && rejected.get() == 7, "6.5 одновременно " + maxInFlight + ", отказов " + rejected);

        ExecutorService ex2 = Executors.newFixedThreadPool(16);
        List<Future<Map<String, String>>> res = new ArrayList<>();
        for (int i = 0; i < 16; i++) res.add(ex2.submit(Directory::bic));
        Set<Map<String, String>> distinct = Collections.newSetFromMap(new IdentityHashMap<>());
        for (var f : res) distinct.add(f.get());
        ex2.shutdown();
        check(loads.get() == 1 && distinct.size() == 1, "6.6 загрузок " + loads.get() + ", экземпляров " + distinct.size());
    }
}
