import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.*;

/** Восемь ошибок раздела «Найди ошибку»: каждая показана запуском, рядом исправление. */
public class Bugs {

    // Б1. Середина отрезка в бинарном поиске
    static void midpoint() {
        int lo = 1_500_000_000, hi = 2_000_000_000;
        System.out.println("Б1 (lo + hi) / 2 = " + (lo + hi) / 2 + ", (lo + hi) >>> 1 = " + ((lo + hi) >>> 1)
                + ", lo + (hi - lo) / 2 = " + (lo + (hi - lo) / 2));
    }

    // Б2. Компаратор вычитанием
    record Payment(String id, long amountKop) { }

    static void subtractComparator() {
        List<Payment> p = new ArrayList<>(List.of(new Payment("крупный", 3_000_000_000L), new Payment("мелкий", 100)));
        p.sort((a, b) -> (int) (a.amountKop() - b.amountKop()));
        List<Payment> q = new ArrayList<>(p);
        q.sort(Comparator.comparingLong(Payment::amountKop));
        System.out.println("Б2 вычитание: " + p.stream().map(Payment::id).toList()
                + ", comparingLong: " + q.stream().map(Payment::id).toList());
    }

    // Б3. Сравнение упакованных чисел через ==
    static void boxedEquals() {
        Integer a = 100, b = 100, c = 1000, d = 1000;
        System.out.println("Б3 100 == 100: " + (a == b) + ", 1000 == 1000: " + (c == d) + ", equals: " + c.equals(d));
    }

    // Б4. BigDecimal из double
    static void bigDecimalFromDouble() {
        System.out.println("Б4 new BigDecimal(0.1) = " + new BigDecimal(0.1) + ", BigDecimal.valueOf(0.1) = "
                + BigDecimal.valueOf(0.1) + ", new BigDecimal(\"0.1\") = " + new BigDecimal("0.1"));
    }

    // Б5. Изменяемый ключ в HashSet
    static final class Card {
        String pan;
        Card(String pan) { this.pan = pan; }
        @Override public boolean equals(Object o) { return o instanceof Card c && c.pan.equals(pan); }
        @Override public int hashCode() { return pan.hashCode(); }
    }

    static void mutableKey() {
        Set<Card> blocked = new HashSet<>();
        Card card = new Card("4276 0000 0000 0001");
        blocked.add(card);
        card.pan = "4276 0000 0000 0002";                       // перевыпуск карты: номер поменяли на месте
        boolean removed = blocked.remove(card);
        System.out.println("Б5 contains: " + blocked.contains(card) + ", remove: " + removed + ", size: " + blocked.size());
    }

    // Б6. Удаление из списка внутри for-each
    static void removeInForEach() {
        List<Long> amounts = new ArrayList<>(List.of(100L, 0L, 250L, 0L, 300L));
        try {
            for (Long x : amounts) if (x == 0) amounts.remove(x);
            System.out.println("Б6 for-each: без исключения, " + amounts);
        } catch (ConcurrentModificationException e) {
            System.out.println("Б6 for-each: ConcurrentModificationException");
        }
        List<Long> fixed = new ArrayList<>(List.of(100L, 0L, 250L, 0L, 300L));
        fixed.removeIf(x -> x == 0);
        System.out.println("Б6 removeIf: " + fixed);
    }

    // Б7. «Проверить, потом действовать» на ConcurrentHashMap
    static void checkThenAct() throws Exception {
        for (boolean correct : new boolean[]{false, true}) {
            Map<String, Integer> attempts = new ConcurrentHashMap<>();
            ExecutorService ex = Executors.newFixedThreadPool(8);
            List<Future<?>> fs = new ArrayList<>();
            for (int t = 0; t < 8; t++) fs.add(ex.submit(() -> {
                for (int i = 0; i < 100_000; i++) {
                    if (correct) attempts.merge("клиент-1", 1, Integer::sum);
                    else {
                        if (!attempts.containsKey("клиент-1")) attempts.put("клиент-1", 0);
                        attempts.put("клиент-1", attempts.get("клиент-1") + 1);
                    }
                }
            }));
            for (Future<?> f : fs) f.get();
            ex.shutdown();
            System.out.println("Б7 " + (correct ? "merge" : "get + put") + ": " + attempts.get("клиент-1") + " из 800000");
        }
    }

    // Б8. Форматирование суммы в локали по умолчанию
    static void localeFormat() {
        double amount = 1234.5;
        System.out.println("Б8 ru: " + String.format(Locale.of("ru", "RU"), "%.2f", amount)
                + ", ROOT: " + String.format(Locale.ROOT, "%.2f", amount)
                + ", BigDecimal.toPlainString: " + new BigDecimal("1234.50").toPlainString());
    }

    public static void main(String[] args) throws Exception {
        midpoint();
        subtractComparator();
        boxedEquals();
        bigDecimalFromDouble();
        mutableKey();
        removeInForEach();
        checkThenAct();
        localeFormat();
    }
}
