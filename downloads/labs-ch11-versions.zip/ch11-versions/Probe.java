import java.lang.reflect.Method;

/**
 * Отвечает по отражению, есть ли в загруженной версии reactor-core метод и помечен ли он {@code @Deprecated}.
 * Аргументы: имя класса, имя метода.
 */
public class Probe {

    public static void main(String[] args) throws Exception {
        Class<?> type = Class.forName(args[0]);
        for (Method m : type.getDeclaredMethods()) {
            if (m.getName().equals(args[1]) && m.getParameterCount() == 0) {
                System.out.println("есть, @Deprecated: " + (m.isAnnotationPresent(Deprecated.class) ? "да" : "нет"));
                return;
            }
        }
        System.out.println("нет");
    }
}
