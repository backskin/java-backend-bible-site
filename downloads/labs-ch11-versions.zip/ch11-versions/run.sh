#!/usr/bin/env bash
# В какой версии что появилось и исчезло: проверка по jar из Maven Central.
# Нужны JDK 17+ (javap, java, javac) и curl. Вывод - в run.txt.
set -u
cd "$(dirname "$0")"
mkdir -p jars
base=https://repo1.maven.org/maven2

jar() { # группа-путь артефакт версия
  local f="jars/$2-$3.jar"
  [ -f "$f" ] || curl -sfL -o "$f" "$base/$1/$2/$3/$2-$3.jar"
  echo "$f"
}
core() { jar io/projectreactor reactor-core "$1"; }
has() { # jar класс шаблон
  if javap -cp "$1" -p "$2" 2>/dev/null | grep -q "$3"; then echo "есть"; else echo "нет"; fi
}

{
echo "== Flux.mapNotNull"
for v in 3.4.0 3.4.3 3.4.4; do echo "reactor-core $v: $(has "$(core $v)" reactor.core.publisher.Flux ' mapNotNull(')"; done

echo "== Sinks.EmitFailureHandler.busyLooping"
for v in 3.4.0 3.4.15 3.4.16; do echo "reactor-core $v: $(has "$(core $v)" 'reactor.core.publisher.Sinks$EmitFailureHandler' 'busyLooping')"; done

echo "== Schedulers.elastic()"
for v in 3.4.41 3.5.0 3.8.7; do echo "reactor-core $v: $(has "$(core $v)" reactor.core.scheduler.Schedulers ' elastic()')"; done

echo "== интерфейс reactor.core.scheduler.NonBlocking"
for v in 3.1.16.RELEASE 3.2.0.RELEASE; do echo "reactor-core $v: $(has "$(core $v)" reactor.core.scheduler.NonBlocking 'interface')"; done

echo "== поле Schedulers.DEFAULT_BOUNDED_ELASTIC_ON_VIRTUAL_THREADS"
for v in 3.5.20 3.6.0; do echo "reactor-core $v: $(has "$(core $v)" reactor.core.scheduler.Schedulers 'DEFAULT_BOUNDED_ELASTIC_ON_VIRTUAL_THREADS')"; done

echo "== Hooks.enableAutomaticContextPropagation"
for v in 3.5.2 3.5.3; do echo "reactor-core $v: $(has "$(core $v)" reactor.core.publisher.Hooks 'enableAutomaticContextPropagation')"; done

echo "== ContextView"
for v in 3.3.22.RELEASE 3.4.0; do echo "reactor-core $v: $(has "$(core $v)" reactor.util.context.ContextView 'interface')"; done

echo "== UnicastProcessor и @Deprecated"
for v in 3.3.22.RELEASE 3.4.0 3.8.7; do
  d=$(javap -cp "$(core $v)" -v reactor.core.publisher.UnicastProcessor 2>/dev/null | grep -c 'java.lang.Deprecated')
  echo "reactor-core $v: класс $(has "$(core $v)" reactor.core.publisher.UnicastProcessor 'class'), упоминаний Deprecated в байткоде: $d"
done

echo "== Flux.metrics() и Schedulers.isInNonBlockingThread() по отражению"
rs=$(jar org/reactivestreams reactive-streams 1.0.4)
sep=":"; case "$(uname -s)" in MINGW*|MSYS*|CYGWIN*) sep=";";; esac
utf="-Dstdout.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8"
mkdir -p out
javac -nowarn -encoding UTF-8 -d out Probe.java
for v in 3.4.41 3.5.0 3.8.7; do echo "reactor-core $v: Flux.metrics() $(java $utf -cp "out$sep$(core $v)$sep$rs" Probe reactor.core.publisher.Flux metrics)"; done
for v in 3.1.16.RELEASE 3.2.0.RELEASE; do echo "reactor-core $v: Schedulers.isInNonBlockingThread() $(java $utf -cp "out$sep$(core $v)$sep$rs" Probe reactor.core.scheduler.Schedulers isInNonBlockingThread | tail -1)"; done

echo "== org.reactivestreams.FlowAdapters в основном артефакте"
for v in 1.0.2 1.0.3 1.0.4; do
  f=$(jar org/reactivestreams reactive-streams $v)
  echo "reactive-streams $v: $(has "$f" org.reactivestreams.FlowAdapters 'class'), размер jar $(wc -c < "$f") байт"
done

echo "== concatMap(f): первые запросы к источнику"
for v in 3.3.22.RELEASE 3.4.0 3.4.41 3.5.0 3.8.7; do
  c=$(core $v)
  javac -nowarn -encoding UTF-8 -cp "$c$sep$rs" -d out ConcatMapDemand.java 2>/dev/null
  echo "reactor-core $v: $(java $utf -cp "out$sep$c$sep$rs" ConcatMapDemand)"
done

echo "== даты в Maven Central (заголовок Last-Modified у jar)"
for a in "io/projectreactor reactor-core 3.4.0" "org/reactivestreams reactive-streams 1.0.0" "io/projectreactor reactor-core 3.5.3" "io/projectreactor reactor-core 3.6.0"; do
  set -- $a
  echo "$2 $3: $(curl -sI "$base/$1/$2/$3/$2-$3.jar" | grep -i '^last-modified' | tr -d '\r')"
done

echo "== reactor-kafka: последняя версия по maven-metadata.xml"
curl -s "$base/io/projectreactor/kafka/reactor-kafka/maven-metadata.xml" | grep -E '<latest>|<release>|<lastUpdated>' | tr -d ' '
echo "== reactor-core: последняя версия по maven-metadata.xml"
curl -s "$base/io/projectreactor/reactor-core/maven-metadata.xml" | grep -E '<latest>|<release>|<lastUpdated>' | tr -d ' '
} > run.txt 2>&1
cat run.txt
