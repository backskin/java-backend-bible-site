import java.util.ArrayList;
import java.util.List;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Печатает запросы, которые concatMap без явной упреждающей выборки отправляет источнику,
 * когда подписчик забирает десять элементов. Запускается на разных версиях reactor-core.
 */
public class ConcatMapDemand {

    public static void main(String[] args) {
        List<Long> requests = new ArrayList<>();
        Flux.range(1, 1000)
                .doOnRequest(requests::add)
                .concatMap(Mono::just)
                .take(10)
                .blockLast();
        System.out.println("запросы к источнику " + requests);
    }
}
