# В какой версии что появилось (гл. 11, сноска b11-44)

Скрипт `run.sh` скачивает из Maven Central jar-файлы reactor-core и reactive-streams разных версий и проверяет
утверждения главы о версиях: наличие методов, полей и аннотации `@Deprecated` (`javap` и класс `Probe` на отражении),
запросы `concatMap` без упреждающей выборки к источнику (класс `ConcatMapDemand`), даты артефактов (заголовок
`Last-Modified`) и последнюю версию Reactor Kafka (`maven-metadata.xml`).

Нужны JDK 17+ и curl. Запуск: `bash run.sh` (вывод в `run.txt`, скачанные jar - в `jars/`, они не хранятся в git).

Что получилось при проверке (2026-11-17, Temurin 21.0.10):

- `Flux.mapNotNull` есть с 3.4.4, `EmitFailureHandler.busyLooping` - с 3.4.16;
- `Schedulers.elastic()` есть в 3.4.41 и отсутствует в 3.5.0;
- настройка `boundedElastic` на виртуальных потоках есть с 3.6.0, `Hooks.enableAutomaticContextPropagation` - с 3.5.3,
  `ContextView` - с 3.4.0;
- `UnicastProcessor` помечен `@Deprecated` с 3.4.0 и в 3.8.7 по-прежнему на месте; `Flux.metrics()` помечен с 3.5.0;
- `Schedulers.isInNonBlockingThread()` есть уже в 3.1.16, то есть проверка `block()` появилась не в 3.2;
- `FlowAdapters` лежит в основном артефакте reactive-streams с 1.0.3, jar версии 1.0.4 занимает 11 640 байт;
- `concatMap(f)` запрашивает у источника 32 элемента на 3.3.22, 3.4.0 и 3.4.41 и по одному начиная с 3.5.0.
