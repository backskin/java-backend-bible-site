# MapStruct: настройки по умолчанию и строгие политики

Стенд к главе 32, раздел 8. Преобразователь сущности платежа в ответ API с настройками MapStruct по умолчанию и отдельные преобразователи со строгими политиками, которые компилируются вручную.

## Что нужно

- JDK 21 и Maven 3.9.

## Запуск

```bash
mvn clean compile
java -cp target/classes:$HOME/.m2/repository/org/mapstruct/mapstruct/1.6.3/mapstruct-1.6.3.jar dev.team.mapping.MappingLab
```

Сборка выдаёт предупреждение `Unmapped target property: "commission"`, а `MappingLab` показывает `null` в этом поле, разбор строки `mcc` через `Integer.parseInt`, `LinkedHashSet` для множества, `null` вместо пустой коллекции и проверку компактного конструктора записи.

Строгие варианты лежат в `src/check/java` и компилируются отдельно с процессором MapStruct:

```bash
P=$HOME/.m2/repository/org/mapstruct
javac -cp target/classes:$P/mapstruct/1.6.3/mapstruct-1.6.3.jar \
      -processorpath $P/mapstruct-processor/1.6.3/mapstruct-processor-1.6.3.jar \
      -d target/check -s target/check-gen src/check/java/dev/team/mapping/LossyMapper.java
```

`LossyMapper` падает на сужении `long` -> `int`, а `StrictPaymentMapper` компилируется: `typeConversionPolicy = ERROR` не считает `String` -> `int` потерей, а `@MappingTarget` на записи даёт пустой метод (смотрите `target/check-gen`).

Выводы, приведённые в главе: `s32-mapping.txt`, `s32-mapping-build.txt`, `s32-mapping-strict.txt`.
