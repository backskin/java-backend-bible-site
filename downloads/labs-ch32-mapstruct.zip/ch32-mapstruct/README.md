# MapStruct: настройки по умолчанию и строгие политики

Стенд к главе 32, раздел 8. Преобразователь сущности платежа в ответ API с настройками MapStruct по умолчанию и отдельные преобразователи со строгими политиками, которые компилируются вручную.

## Что нужно

- JDK 21 и Maven 3.9.

## Запуск

```bash
mvn clean compile
java -cp target/classes:$HOME/.m2/repository/org/mapstruct/mapstruct/1.6.3/mapstruct-1.6.3.jar dev.team.mapping.MappingLab
```

Сборка выдаёт предупреждение `Unmapped target property: "commission"`, а `MappingLab` показывает `null` в этом поле, разбор строки `mcc` через `Integer.parseInt`, `LinkedHashSet` для множества, `null` вместо пустой коллекции и проверку компактного конструктора записи.

Строгие варианты лежат в `src/check/java` и компилируются отдельно с процессором MapStruct:

```bash
P=$HOME/.m2/repository/org/mapstruct
javac -cp target/classes:$P/mapstruct/1.6.3/mapstruct-1.6.3.jar \
      -processorpath $P/mapstruct-processor/1.6.3/mapstruct-processor-1.6.3.jar \
      -d target/check -s target/check-gen src/check/java/dev/team/mapping/LossyMapper.java
```

`LossyMapper` падает на сужении `long` -> `int`, а `StrictPaymentMapper` компилируется: `typeConversionPolicy = ERROR` не считает `String` -> `int` потерей, а `@MappingTarget` на записи даёт пустой метод (смотрите `target/check-gen`).

## Lombok и lombok-mapstruct-binding

`src/lombok/java` - сущность карты с методами доступа Lombok и преобразователь с `unmappedTargetPolicy = ERROR`. Сборка при трех составах пути процессоров (Lombok 1.18.38 и binding 0.2.0 скачиваются `mvn dependency:get -Dartifact=org.projectlombok:lombok:1.18.38` и `...:lombok-mapstruct-binding:0.2.0`; в Git Bash на Windows разделитель путей `;`):

```bash
R=$HOME/.m2/repository
MS=$R/org/mapstruct/mapstruct/1.6.3/mapstruct-1.6.3.jar
MP=$R/org/mapstruct/mapstruct-processor/1.6.3/mapstruct-processor-1.6.3.jar
LB=$R/org/projectlombok/lombok/1.18.38/lombok-1.18.38.jar
BD=$R/org/projectlombok/lombok-mapstruct-binding/0.2.0/lombok-mapstruct-binding-0.2.0.jar
SRC=$(find src/lombok/java -name '*.java')
javac -cp $MS:$LB -processorpath $MP:$LB     -d target/lombok-a $SRC   # ошибка: Unmapped target properties
javac -cp $MS:$LB -processorpath $LB:$MP     -d target/lombok-b $SRC   # проходит
javac -cp $MS:$LB -processorpath $MP:$LB:$BD -d target/lombok-c $SRC   # проходит
```

Выводы, приведённые в главе: `s32-mapping.txt`, `s32-mapping-build.txt`, `s32-mapping-strict.txt`, `s32-mapping-lombok.txt`.
