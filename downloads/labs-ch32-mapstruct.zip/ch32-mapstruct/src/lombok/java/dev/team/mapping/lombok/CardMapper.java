package dev.team.mapping.lombok;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

/** Преобразователь сущности карты в ответ API; забытое поле - ошибка сборки. */
@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface CardMapper {

    /** Ответ API по карте. */
    record CardView(Long id, String maskedPan, String status) {
    }

    CardView toView(CardEntity card);
}
