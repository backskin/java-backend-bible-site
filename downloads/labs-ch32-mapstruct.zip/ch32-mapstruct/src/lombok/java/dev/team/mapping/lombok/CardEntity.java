package dev.team.mapping.lombok;

import lombok.Getter;
import lombok.Setter;

/** Сущность карты с методами доступа, которые генерирует Lombok. */
@Getter
@Setter
public class CardEntity {
    private Long id;
    private String maskedPan;
    private String status;
}
