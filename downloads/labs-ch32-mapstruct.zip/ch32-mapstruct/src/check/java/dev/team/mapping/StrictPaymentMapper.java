package dev.team.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

/**
 * Опыт разд. 8: строгие политики MapStruct и попытка обновить запись через @MappingTarget.
 * Собирается отдельно (см. README); вывод компилятора - s32-mapping-strict.txt.
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR, typeConversionPolicy = ReportingPolicy.ERROR)
public interface StrictPaymentMapper {

    /** commission игнорируется явно: остаётся вопрос, считает ли typeConversionPolicy String -> int потерей. */
    @Mapping(target = "commission", ignore = true)
    PaymentView toViewIgnoringCommission(PaymentEntity e);

    /** Запись нельзя изменить: у неё нет сеттеров. */
    @Mapping(target = "commission", ignore = true)
    void update(@MappingTarget PaymentView target, PaymentEntity source);
}
