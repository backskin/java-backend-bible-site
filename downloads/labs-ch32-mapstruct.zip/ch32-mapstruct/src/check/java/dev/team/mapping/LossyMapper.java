package dev.team.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

/** Опыт разд. 8: сужающее преобразование long -> int при typeConversionPolicy = ERROR. */
@Mapper(typeConversionPolicy = ReportingPolicy.ERROR)
public interface LossyMapper {
    record Source(long count) {}
    record Target(int count) {}
    Target map(Source s);
}
