package dev.team.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/** Преобразователь с политиками MapStruct по умолчанию. */
@Mapper
public interface PaymentMapper {
    PaymentMapper INSTANCE = Mappers.getMapper(PaymentMapper.class);

    PaymentView toView(PaymentEntity e);
}
