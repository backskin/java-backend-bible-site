package dev.team.mapping;

import java.math.BigDecimal;
import java.util.List;

/** Сущность платежа, как её отдаёт слой хранения. */
public class PaymentEntity {
    private final String id;
    private final BigDecimal amount;
    private final String mcc;           // код категории торговца строкой
    private final List<String> tags;    // порядок важен: так их показывает интернет-банк

    public PaymentEntity(String id, BigDecimal amount, String mcc, List<String> tags) {
        this.id = id; this.amount = amount; this.mcc = mcc; this.tags = tags;
    }
    public String getId() { return id; }
    public BigDecimal getAmount() { return amount; }
    public String getMcc() { return mcc; }
    public List<String> getTags() { return tags; }
}
