package dev.team.mapping;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Supplier;

/** Опыт разд. 8: что делает преобразователь с политиками по умолчанию на разных входах. */
public class MappingLab {

    static String run(String name, Supplier<Object> s) {
        try { return name + " -> " + s.get(); }
        catch (RuntimeException e) { return name + " -> " + e.getClass().getSimpleName() + ": " + e.getMessage(); }
    }

    public static void main(String[] args) {
        var m = PaymentMapper.INSTANCE;
        var ok = new PaymentEntity("p-1", new BigDecimal("1500.00"), "5411", List.of("зарплата", "аренда", "налоги", "АЗС", "кафе"));
        System.out.println(run("обычный платёж", () -> m.toView(ok)));
        var view = m.toView(ok);
        System.out.println("тип tags: " + view.tags().getClass().getName());
        System.out.println(run("mcc = \"54-11\"", () -> m.toView(new PaymentEntity("p-2", BigDecimal.TEN, "54-11", List.of()))));
        System.out.println(run("tags = null", () -> m.toView(new PaymentEntity("p-3", BigDecimal.TEN, "5411", null)).tags()));
        System.out.println(run("сумма -1", () -> m.toView(new PaymentEntity("p-4", new BigDecimal("-1"), "5411", List.of()))));
        System.out.println("java " + System.getProperty("java.version"));
    }
}
