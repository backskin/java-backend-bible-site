package dev.team.mapping;

import java.math.BigDecimal;
import java.util.Set;

/**
 * Ответ API. Поле commission добавили в контракт, а преобразователь о нём не знает;
 * mcc в ответе - число; tags - множество. Компактный конструктор проверяет сумму.
 */
public record PaymentView(String id, BigDecimal amount, BigDecimal commission, int mcc, Set<String> tags) {
    public PaymentView {
        if (amount != null && amount.signum() < 0) throw new IllegalArgumentException("отрицательная сумма: " + amount);
    }
}
