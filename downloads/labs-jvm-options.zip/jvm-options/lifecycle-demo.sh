#!/usr/bin/env bash
# Приложение I: как JDK реагирует на флаг на каждой стадии снятия (deprecated, obsolete, expired),
# на несуществующий флаг, на флаг отладочной сборки и на -XX:+IgnoreUnrecognizedVMOptions.
# Вывод — lifecycle-demo.txt. Каталоги JDK — как в flags.sh.
set -uo pipefail
cd "$(dirname "$0")"
J=~/.jdks
run() { local jdk=$1; shift; echo "\$ java($jdk) $*"; "$J/$jdk/bin/java" "$@" -version 2>&1 | grep -v -E '^(openjdk|OpenJDK Runtime|Java\(TM\)|Java HotSpot|OpenJDK 64-Bit Server VM \(build)' | tr -d '\r'; echo "код выхода: ${PIPESTATUS[0]}"; echo; }
{
echo "== deprecated: флаг работает, JVM предупреждает"
run temurin-17.0.21 -XX:+UseBiasedLocking
run temurin-21.0.13 -XX:MinRAMFraction=4
echo "== obsolete: флаг принимается и игнорируется"
run temurin-11.0.29 -XX:MaxPermSize=256m
run jdk-26.0.2.1+1 -XX:LockingMode=1
echo "== expired: флаг не распознаётся, JVM не стартует"
run temurin-21.0.13 -XX:+UseBiasedLocking
run temurin-17.0.21 -XX:MaxPermSize=256m
run jdk-25.0.5+8 -XX:MinRAMFraction=4
echo "== флага никогда не было"
run jdk-25.0.5+8 -XX:MaxFreqInlineSize=100
echo "== флаг только отладочной сборки (notproduct/develop)"
run jdk-25.0.5+8 -XX:+UnlockDiagnosticVMOptions -XX:+PrintEscapeAnalysis
echo "== диагностический флаг без UnlockDiagnosticVMOptions"
run jdk-25.0.5+8 -XX:+PrintInlining
echo "== IgnoreUnrecognizedVMOptions"
run jdk-25.0.5+8 -XX:+IgnoreUnrecognizedVMOptions -XX:+UseBiasedLocking -XX:MaxFreqInlineSize=100
} > lifecycle-demo.txt
cat lifecycle-demo.txt
