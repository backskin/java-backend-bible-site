# Опции JVM по версиям JDK: данные для приложения I

Стенд собирает данные, из которых строится приложение I «Опции JVM» (`book/I-jvm-options.md`): какие флаги HotSpot есть в JDK 8, 11, 17, 21, 25 и 26, их вид, тип, значение по умолчанию и диапазон, описание из исходников HotSpot, версии снятия флагов и места в книге, где упоминается каждая опция.

## Что нужно

- JDK 8, 11, 17, 21, 25 и 26 (Temurin) в `~/.jdks` — каталоги перечислены в `flags.sh`; можно передать свои.
- Docker с образами `eclipse-temurin:<версия>-jdk` для флагов Linux.
- Python 3, bash.

## Запуск

```bash
bash flags.sh            # флаги на этой машине: flags-<версия>.txt, x-<версия>.txt
bash flags-linux.sh      # флаги в контейнерах Linux: flags-linux-<версия>.txt
python catalog.py        # сводная таблица catalog.tsv (нужны исходники в src/)
python lifecycle.py      # стадии снятия флагов lifecycle.tsv (из src/*-arguments.cpp)
python mentions.py       # где в книге упоминается каждая опция: mentions.tsv
python appendix.py       # обновить строки «В книге» и полную таблицу в book/I-jvm-options.md
bash lifecycle-demo.sh   # что JVM делает с устаревшим, игнорируемым и удалённым флагом
bash order.sh            # порядок JAVA_TOOL_OPTIONS, JDK_JAVA_OPTIONS, @файла и командной строки
```

Исходники HotSpot в `src/` скачаны с GitHub OpenJDK (`openjdk/jdk` теги `jdk-9`…`jdk-26-ga`, `openjdk/jdk8u`, `jdk11u`, `jdk17u`, `jdk21u`): файлы `globals.hpp`, `*_globals.hpp` сборщиков и компиляторов и `arguments.cpp`.

## Что должно получиться

- `catalog.tsv` — 1 384 флага с версиями, видом, типом, значением, диапазоном и описанием; без описания из исходников остаются единицы флагов.
- `lifecycle.tsv` — около 360 снятых флагов с версиями «устарел», «игнорируется», «удалён».
- `lifecycle-demo.txt` — JDK 17 предупреждает о `UseBiasedLocking`, JDK 21 на нём не запускается, JDK 26 игнорирует `LockingMode`, JDK 25 на несуществующем `MaxFreqInlineSize` подсказывает `FreqInlineSize`.
- `order.txt` — при повторе опции побеждает последняя: `JAVA_TOOL_OPTIONS`, затем `JDK_JAVA_OPTIONS`, затем командная строка; `-Xmx` сильнее `MaxRAMPercentage`.

Значения с происхождением `{ergonomic}` в выводах `flags-*.txt` зависят от машины (числа процессоров и памяти).
