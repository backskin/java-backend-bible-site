"""Приложение I: жизненный цикл флагов HotSpot по таблицам special_jvm_flags в arguments.cpp.

У каждого снятого флага HotSpot ведёт три версии: deprecated (флаг работает, но JVM предупреждает),
obsolete (флаг принимается и игнорируется с предупреждением), expired (флаг больше не распознаётся,
JVM не стартует). Таблица со временем чистится от старых строк, поэтому читаются arguments.cpp
из многих версий (src/*-arguments.cpp); строки внутри #if (только для отдельных сборок) пропускаются.
Для каждого флага берётся строка из самой новой версии,
где он ещё записан. В JDK 8 таблица другая: obsolete_jvm_flags (флаг, с какой версии устарел, до какой принимается).
Вывод — lifecycle.tsv.
"""
import glob
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
VER = r"JDK_Version::(?:jdk\((\d+)\)|jdk_update\((\d+),\s*(\d+)\)|undefined\(\))"
MODERN = re.compile(r'\{\s*"(\w+)"\s*,\s*' + VER + r"\s*,\s*" + VER + r"\s*,\s*" + VER + r"\s*\}")
OLD = re.compile(r'\{\s*"(\w+)"\s*,\s*' + VER + r"\s*,\s*" + VER + r"\s*\}")


def ver(a, b, c):
    if a:
        return a
    if b:
        return f"{b}u{c}"
    return ""


def tag_order(path):
    t = os.path.basename(path).split("-")[0]
    return int(re.sub(r"\D", "", t))


out = {}
for path in sorted(glob.glob(os.path.join(HERE, "src", "*-arguments.cpp")), key=tag_order):
    tag = os.path.basename(path).split("-")[0]
    text = open(path, encoding="utf-8", errors="replace").read()
    start = text.find("special_jvm_flags[]")
    if start >= 0:
        block = text[start:text.find("};", start)]
        depth = 0
        for line in block.splitlines():
            st = line.strip()
            if st.startswith("#if"):
                depth += 1
            elif st.startswith("#endif"):
                depth -= 1
            m = MODERN.search(line)
            if m and depth == 0:
                g = m.groups()
                out[g[0]] = (ver(*g[1:4]), ver(*g[4:7]), ver(*g[7:10]), tag)
    start = text.find("obsolete_jvm_flags[]")
    if start >= 0:
        block = text[start:text.find("};", start)]
        for m in OLD.finditer(block):
            g = m.groups()
            out.setdefault(g[0], ("", ver(*g[1:4]), ver(*g[4:7]), tag))

with open(os.path.join(HERE, "lifecycle.tsv"), "w", encoding="utf-8", newline="\n") as f:
    f.write("flag\tdeprecated\tobsolete\texpired\tsource\n")
    for name in sorted(out, key=str.lower):
        d, o, e, tag = out[name]
        f.write(f"{name}\t{d}\t{o}\t{e}\t{tag}\n")
print(f"флагов в таблицах снятия: {len(out)}")
