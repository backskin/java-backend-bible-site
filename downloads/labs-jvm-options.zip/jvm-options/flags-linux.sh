#!/usr/bin/env bash
# Приложение I: то же, что flags.sh, но на Linux в контейнерах eclipse-temurin (флаги Linux: контейнеры, cgroups, THP).
# Вывод — flags-linux-<версия>.txt. Нужен Docker.
set -uo pipefail
cd "$(dirname "$0")"
export MSYS_NO_PATHCONV=1
for v in 8 11 17 21 25 26; do
  img="eclipse-temurin:$v-jdk"
  docker pull -q "$img" >/dev/null 2>&1 || { echo "$v: образ $img недоступен"; continue; }
  docker run --rm "$img" java -XX:+UnlockDiagnosticVMOptions -XX:+UnlockExperimentalVMOptions -XX:+PrintFlagsFinal -version 2>&1 | tr -d '\r' > "flags-linux-$v.txt"
  docker run --rm "$img" java -version 2>&1 | head -1 | tr -d '\r' | sed "s/^/$v: /"
done
