#!/usr/bin/env bash
# Приложение I: какие флаги HotSpot есть в каждой версии JDK и их значения по умолчанию.
# Запускает java -XX:+UnlockDiagnosticVMOptions -XX:+UnlockExperimentalVMOptions -XX:+PrintFlagsFinal -version
# на каждой JDK из списка и сохраняет вывод в flags-<версия>.txt, а java -X — в x-<версия>.txt.
# Использование: bash flags.sh <каталог_jdk>...   (по умолчанию — ~/.jdks)
set -uo pipefail
cd "$(dirname "$0")"
dirs=("$@")
if [ ${#dirs[@]} -eq 0 ]; then
  dirs=(~/.jdks/jdk8u504-b01 ~/.jdks/temurin-11.0.29 ~/.jdks/temurin-17.0.21 ~/.jdks/temurin-21.0.13 ~/.jdks/jdk-25.0.5+8 ~/.jdks/jdk-26.0.2.1+1)
fi
for d in "${dirs[@]}"; do
  j="$d/bin/java"
  v=$("$j" -XshowSettings:properties -version 2>&1 | sed -n 's/^ *java.version = //p' | tr -d '\r')
  major=${v%%.*}; [ "$major" = 1 ] && major=8
  "$j" -XX:+UnlockDiagnosticVMOptions -XX:+UnlockExperimentalVMOptions -XX:+PrintFlagsFinal -version 2>&1 | tr -d '\r' > "flags-$major.txt"
  "$j" -X 2>&1 | tr -d '\r' > "x-$major.txt"
  echo "$major ($v): $(grep -c ' = \| := ' flags-$major.txt) флагов"
done
