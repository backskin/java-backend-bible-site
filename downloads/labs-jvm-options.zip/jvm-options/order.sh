#!/usr/bin/env bash
# Приложение I: порядок применения опций из JAVA_TOOL_OPTIONS, JDK_JAVA_OPTIONS, @файла и командной строки.
# При повторе одной опции побеждает последняя; печатается итоговый MaxHeapSize. Вывод — order.txt.
set -uo pipefail
cd "$(dirname "$0")"
J=~/.jdks/jdk-25.0.5+8/bin/java
heap() { "$@" -XX:+PrintFlagsFinal -version 2>&1 | tr -d '\r' | grep -E "Picked up|NOTE: Picked| MaxHeapSize " | sed 's/  */ /g'; }
printf -- '-Xmx300m\n' > order-args.txt
{
echo "== JAVA_TOOL_OPTIONS=-Xmx100m, в командной строке -Xmx200m"
JAVA_TOOL_OPTIONS=-Xmx100m heap "$J" -Xmx200m
echo; echo "== JDK_JAVA_OPTIONS=-Xmx100m, в командной строке -Xmx200m"
JDK_JAVA_OPTIONS=-Xmx100m heap "$J" -Xmx200m
echo; echo "== JAVA_TOOL_OPTIONS=-Xmx100m и JDK_JAVA_OPTIONS=-Xmx150m без опции в командной строке"
JAVA_TOOL_OPTIONS=-Xmx100m JDK_JAVA_OPTIONS=-Xmx150m heap "$J"
echo; echo "== -Xmx200m, затем @order-args.txt (в файле -Xmx300m)"
heap "$J" -Xmx200m @order-args.txt
echo; echo "== -Xmx200m и -XX:MaxRAMPercentage=50 вместе"
heap "$J" -Xmx200m -XX:MaxRAMPercentage=50
} > order.txt
cat order.txt
