"""Приложение I: сводная таблица флагов HotSpot по версиям JDK.

Читает вывод flags.sh (flags-<версия>.txt: какие флаги есть в сборке, тип, значение по умолчанию на этой машине,
вид флага) и определения флагов из исходников HotSpot в src/ (описание и допустимый диапазон),
пишет catalog.tsv: одна строка на флаг.

Запуск: python catalog.py   (после bash flags.sh и загрузки исходников, см. README.md)
"""
import csv
import glob
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
VERSIONS = [8, 11, 17, 21, 25, 26]
MACROS = ("product_pd", "product", "diagnostic_pd", "diagnostic", "experimental_pd", "experimental",
          "manageable", "product_rw", "lp64_product", "develop_pd", "develop", "notproduct")

# --- 1. какие флаги есть в каждой версии
LINE = re.compile(r"^\s*(\S+)\s+(\w+)\s+:?=\s*([^{]*?)\s*\{([^}]*)\}")
present = {}
oses = {}
for v in VERSIONS:
    for os_name, fname in (("Windows", f"flags-{v}.txt"), ("Linux", f"flags-linux-{v}.txt")):
        path = os.path.join(HERE, fname)
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8", errors="replace") as f:
            for ln in f:
                m = LINE.match(ln)
                if m:
                    typ, name, val, kind = m.groups()
                    kinds = [k.replace("lp64_", "") for k in kind.split() if k not in ("pd", "C1", "C2", "JVMCI", "ARCH")] or ["product"]
                    present.setdefault(name, {}).setdefault(v, (typ, val.strip(), kinds[0]))
                    oses.setdefault(name, set()).add(os_name)

# --- 2. описания и диапазоны из исходников (новее перекрывает старее)
def args_of(text, start):
    """Аргументы макроса с учётом скобок и строк, начиная с открывающей скобки."""
    depth, i, cur, out, in_str = 0, start, [], [], False
    while i < len(text):
        c = text[i]
        if in_str:
            cur.append(c)
            if c == "\\":
                cur.append(text[i + 1]); i += 1
            elif c == '"':
                in_str = False
        elif c == '"':
            in_str = True; cur.append(c)
        elif c == "(":
            depth += 1
            if depth > 1:
                cur.append(c)
        elif c == ")":
            depth -= 1
            if depth == 0:
                out.append("".join(cur).strip()); return out, i + 1
            cur.append(c)
        elif c == "," and depth == 1:
            out.append("".join(cur).strip()); cur = []
        else:
            cur.append(c)
        i += 1
    return out, i

def order(path):
    base = os.path.basename(path)
    tag = base.split("-")[0]
    return {"jdk8u": 8, "jdk11u": 11, "jdk17u": 17, "jdk21u": 21, "jdk25": 25, "jdk26": 26}.get(tag, 0)

desc = {}
for path in sorted(glob.glob(os.path.join(HERE, "src", "*.hpp")), key=order):
    text = open(path, encoding="utf-8", errors="replace").read().replace("\\\n", "\n")
    tag = os.path.basename(path).split("-")[0]
    for m in re.finditer(r"\b(" + "|".join(MACROS) + r")\s*\(", text):
        a, end = args_of(text, m.end() - 1)
        if len(a) < 3 or not re.fullmatch(r"\w+", a[1] or ""):
            continue
        strs = [x for x in a if x.startswith('"')]
        if not strs:
            continue
        d = re.sub(r'"\s*"', "", strs[-1]).strip('"')
        d = re.sub(r"\s+", " ", d.replace('\\"', '"')).strip()
        default = "" if m.group(1).endswith("_pd") else a[2]
        rm = re.match(r"\s*range\(", text[end:end + 300])
        rng = ", ".join(args_of(text, end + rm.end() - 1)[0]) if rm else ""
        desc[a[1]] = (d, default, rng, m.group(1), tag)

# --- 3. таблица
rows = []
for name in sorted(present, key=str.lower):
    vs = present[name]
    have = [v for v in VERSIONS if v in vs]
    last = vs[have[-1]]
    d, src_default, rng, macro, tag = desc.get(name, ("", "", "", "", ""))
    rows.append({
        "flag": name, "type": last[0], "kind": last[2],
        "versions": ",".join(map(str, have)),
        "os": "" if len(oses[name]) == 2 else next(iter(oses[name])),
        "first": have[0], "last": have[-1],
        "default_last": last[1], "default_src": re.sub(r"\s+", " ", src_default), "range": re.sub(r"\s+", " ", rng),
        "description": d, "source": tag,
    })
with open(os.path.join(HERE, "catalog.tsv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter="\t")
    w.writeheader(); w.writerows(rows)
miss = sum(1 for r in rows if not r["description"])
print(f"флагов {len(rows)}, без описания из исходников {miss}")
