"""Приложение I: обновляет в book/I-jvm-options.md то, что собирается из данных, а не пишется руками.

1. В каждой статье (заголовок "### `опция`") строка "**В книге:** ..." — главы и разделы, где опция упоминается
   (mentions.tsv). Если строки нет, она добавляется последней в статью.
2. Между метками <!-- table:start --> и <!-- table:end --> — таблица всех флагов HotSpot из catalog.tsv
   и lifecycle.tsv, по буквам.

Запуск из корня репозитория: python labs/jvm-options/mentions.py && python labs/jvm-options/appendix.py
"""
import collections
import csv
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
BOOK = os.path.join(ROOT, "book", "I-jvm-options.md")
KIND = {"product": "рабочий", "diagnostic": "диагностический", "experimental": "экспериментальный",
        "manageable": "управляемый", "develop": "отладочный", "notproduct": "отладочный"}


def read_tsv(name):
    with open(os.path.join(HERE, name), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def book_refs():
    """опция -> {глава: [разделы]}"""
    out = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in read_tsv("mentions.tsv"):
        secs = out[r["option"]][r["chapter"]]
        if r["section"] not in secs:
            secs.append(r["section"])
    return out


def sec_key(s):
    return [int(x) for x in s.split(".")] if s else [0]


def refs_line(chapters):
    parts = []
    for nn in sorted(chapters):
        secs = sorted({s for s in chapters[nn] if s}, key=sec_key)
        if not secs:
            parts.append(f"глава {nn}")
        elif len(secs) == 1:
            parts.append(f"глава {nn}, раздел {secs[0]}")
        else:
            parts.append(f"глава {nn}, разделы {', '.join(secs[:-1])} и {secs[-1]}")
    return "**В книге:** " + "; ".join(parts) + "."


def versions(vs):
    """"8,11,17,21,25,26" -> "8–26"; с пропусками — перечислением."""
    order = [8, 11, 17, 21, 25, 26]
    have = [int(v) for v in vs.split(",") if v]
    idx = [order.index(v) for v in have]
    if idx == list(range(idx[0], idx[-1] + 1)):
        return f"{have[0]}–{have[-1]}" if len(have) > 1 else str(have[0])
    return ", ".join(map(str, have))


LITERAL = re.compile(r'^(-?[\d.]+|true|false|"[^"]*"|nullptr)$')


def default_of(r):
    src = r["default_src"].strip()
    if src in ("trueInDebug", "falseInDebug"):
        # значение отладочной сборки противоположно рабочей
        return "false" if src == "trueInDebug" else "true"
    if LITERAL.match(src):
        return "—" if src in ('nullptr', '""') else src.strip('"')
    machine = r["default_last"].strip() or "—"
    return f"{machine}*"


def table(rows, life):
    by_letter = collections.OrderedDict()
    for r in sorted(rows, key=lambda r: r["flag"].lower()):
        by_letter.setdefault(r["flag"][0].upper(), []).append(r)
    out = []
    for letter, rs in by_letter.items():
        out.append(f"### Флаги на букву {letter}\n")
        out.append("| Флаг | JDK | Снятие | По умолчанию | Описание |")
        out.append("|---|---|---|---|---|")
        for r in rs:
            lf = life.get(r["flag"])
            stage = ""
            if lf:
                bits = [f"устарел в {lf['deprecated']}" if lf["deprecated"] else "",
                        f"игнорируется с {lf['obsolete']}" if lf["obsolete"] else "",
                        f"удалён в {lf['expired']}" if lf["expired"] else ""]
                stage = ", ".join(b for b in bits if b)
            vs = versions(r["versions"]) + (f" ({r['os']})" if r["os"] else "")
            desc = r["description"].replace("|", "\\|") or "—"
            out.append(f"| `{r['flag']}` | {vs} | {stage or '—'} | `{default_of(r).replace('|', '/')}` "
                       f"| *{KIND.get(r['kind'], r['kind'])}, `{r['type']}`.* {desc} |")
        out.append("")
        out.append(f"Таблица: Флаги HotSpot на букву {letter}.\n")
    return "\n".join(out)


def main():
    text = open(BOOK, encoding="utf-8").read()
    refs = book_refs()
    # 1. строки "В книге" в статьях
    lines = text.split("\n")
    res, cur = [], None
    def flush_entry(buf, opt):
        body = [l for l in buf if not l.startswith("**В книге:**")]
        while body and body[-1] == "":
            body.pop()
        if opt in refs:
            body += ["", refs_line(refs[opt])]
        return body + [""]
    buf, opt = [], None
    for ln in lines:
        m = re.match(r"^#{2,4} ", ln)
        if m:
            if opt is not None:
                res += flush_entry(buf, opt)
            else:
                res += buf
            buf = [ln]
            om = re.match(r"^### `([^`]+)`", ln)
            opt = om.group(1) if om else None
            continue
        if ln.startswith("<!-- table:start -->") and opt is not None:
            res += flush_entry(buf, opt)
            buf, opt = [ln], None
            continue
        buf.append(ln)
    res += flush_entry(buf, opt) if opt is not None else buf
    text = "\n".join(res)
    text = re.sub(r"\n{3,}", "\n\n", text)
    # 2. таблица
    life = {r["flag"]: r for r in read_tsv("lifecycle.tsv")}
    start, end = "<!-- table:start -->", "<!-- table:end -->"
    a, b = text.index(start) + len(start), text.index(end)
    text = text[:a] + "\n\n" + table(read_tsv("catalog.tsv"), life) + "\n" + text[b:]
    open(BOOK, "w", encoding="utf-8", newline="\n").write(text)
    missing = sorted(o for o in refs if f"### `{o}`" not in text)
    print("опций из книги без статьи:", len(missing), " ".join(missing))


if __name__ == "__main__":
    main()
