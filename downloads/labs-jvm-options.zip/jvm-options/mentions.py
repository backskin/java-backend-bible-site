"""Приложение I: где в книге упоминается каждая опция JVM (глава и раздел).

Читает book/*.md, следит за номером текущего раздела по заголовкам и пишет mentions.tsv:
опция, номер главы, раздел, число упоминаний. Опции -XX:Флаг сводятся к имени флага без +/-.
Запуск из корня репозитория или отсюда: python labs/jvm-options/mentions.py
"""
import collections
import glob
import os
import re

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
OPT = re.compile(
    r"(?<![\w-])(-XX:[+-]?[A-Za-z][A-Za-z0-9_]*(?![A-Za-z0-9_*])"
    r"|-X(?:mx|ms|mn|ss|log|int|comp|mixed|share|batch|rs|noclassgc|showSettings|check|verify|future|diag|internalversion)(?![a-z])"
    r"|--(?:add-opens|add-exports|add-reads|add-modules|enable-preview|enable-native-access|illegal-access|patch-module|module-path|class-path|source|show-version|limit-modules|sun-misc-unsafe-memory-access)\b"
    r"|-(?:javaagent|agentlib|agentpath|verbose:gc|verbose:class|verbose:jni|enableassertions|ea|da|esa|dsa|XshowSettings|showversion)\b)"
)
HEAD = re.compile(r"^(#{2,3})\s+(\d+(?:\.\d+)?)\.?\s")

hits = collections.Counter()
for path in sorted(glob.glob(os.path.join(ROOT, "book", "[0-9][0-9]-*.md"))):
    nn = os.path.basename(path)[:2]
    sec, code = "", False
    for line in open(path, encoding="utf-8"):
        if line.startswith("```"):
            code = not code
        m = HEAD.match(line) if not code else None
        if m:
            sec = m.group(2)
            continue
        for o in OPT.findall(line):
            if o.startswith("-XX:"):
                o = "-XX:" + o[4:].lstrip("+-")
            hits[(o, nn, sec)] += 1

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "mentions.tsv"), "w", encoding="utf-8", newline="\n") as f:
    f.write("option\tchapter\tsection\tcount\n")
    for (o, nn, sec), c in sorted(hits.items(), key=lambda x: (x[0][0].lower(), x[0][1], x[0][2])):
        f.write(f"{o}\t{nn}\t{sec}\t{c}\n")
opts = {o for o, _, _ in hits}
print(f"опций {len(opts)}, мест {len(hits)}")
