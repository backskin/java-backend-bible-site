import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.kafka.test.EmbeddedKafkaKraftBroker;

import java.util.Map;

/** Раздел 11.9: встроенный брокер spring-kafka-test без настроек служебных топиков транзакций. */
public class EmbeddedTx {
    public static void main(String[] args) {
        for (boolean props : new boolean[]{false, true}) {
            var b = new EmbeddedKafkaKraftBroker(1, 1);
            if (props) {
                b.brokerProperty("transaction.state.log.replication.factor", "1");
                b.brokerProperty("transaction.state.log.min.isr", "1");
            }
            b.afterPropertiesSet();
            long t = System.currentTimeMillis();
            try (var p = new KafkaProducer<String, String>(Map.of(
                    ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, b.getBrokersAsString(),
                    ProducerConfig.TRANSACTIONAL_ID_CONFIG, "tx-1",
                    ProducerConfig.MAX_BLOCK_MS_CONFIG, 20000,
                    ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                    ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class))) {
                p.initTransactions();
                System.out.println((props ? "с" : "без") + " transaction.state.log.*=1: initTransactions() за " + (System.currentTimeMillis() - t) + " мс");
            } catch (Exception e) {
                System.out.println((props ? "с" : "без") + " transaction.state.log.*=1: через " + (System.currentTimeMillis() - t) + " мс " + e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally {
                b.destroy();
            }
        }
    }
}
