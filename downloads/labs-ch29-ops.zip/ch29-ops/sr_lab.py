"""Раздел 9 главы 29: режимы совместимости на настоящем Confluent Schema Registry 8.4.0.

Запуск: python sr_lab.py [адрес реестра, по умолчанию http://localhost:38081] > s29-sr.txt
Реестр поднимает sr.sh (контейнер sr29 рядом с брокером k29ops).
"""
import json
import sys
import urllib.request
import urllib.error

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:38081"
CT = "application/vnd.schemaregistry.v1+json"


def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(URL + path, data=data, method=method, headers={"Content-Type": CT})
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"null")


def avro(fields, name="PaymentEvent"):
    return json.dumps({"type": "record", "name": name, "namespace": "bank.tundra.pay", "fields": fields})


def register(subject, schema, stype="AVRO"):
    body = {"schema": schema}
    if stype != "AVRO":
        body["schemaType"] = stype
    return call("POST", f"/subjects/{subject}/versions", body)


def check(subject, schema, stype="AVRO"):
    body = {"schema": schema}
    if stype != "AVRO":
        body["schemaType"] = stype
    code, r = call("POST", f"/compatibility/subjects/{subject}/versions/latest?verbose=true", body)
    if code != 200:
        return f"ошибка {code}: {r}"
    if r.get("is_compatible"):
        return "совместима"
    import re
    kinds = sorted(set(re.findall(r"errorType:'?\"?([A-Z_]+)", " ".join(r.get("messages") or []))))
    return "НЕсовместима: " + (", ".join(kinds) or str(r.get("messages"))[:150])


def reset(subject, mode):
    call("DELETE", f"/subjects/{subject}")
    call("DELETE", f"/subjects/{subject}?permanent=true")
    call("PUT", f"/config/{subject}", {"compatibility": mode})


S = {"name": "paymentId", "type": "string"}
A = {"name": "accountId", "type": "string"}
AMT = {"name": "amount", "type": "long"}
ST = {"name": "status", "type": "string"}
CM = {"name": "comment", "type": ["null", "string"], "default": None}
V1 = [S, A, AMT, ST, CM]

CASES = [
    ("добавить необязательное поле channel (null по умолчанию)", V1 + [{"name": "channel", "type": ["null", "string"], "default": None}]),
    ("добавить обязательное поле channel без значения по умолчанию", V1 + [{"name": "channel", "type": "string"}]),
    ("удалить обязательное поле status", [S, A, AMT, CM]),
    ("удалить необязательное поле comment", [S, A, AMT, ST]),
    ("переименовать accountId в payerAccount", [S, {"name": "payerAccount", "type": "string"}, AMT, ST, CM]),
    ("переименовать accountId в payerAccount с aliases", [S, {"name": "payerAccount", "type": "string", "aliases": ["accountId"]}, AMT, ST, CM]),
    ("amount: long → double", [S, A, {"name": "amount", "type": "double"}, ST, CM]),
    ("amount: long → string", [S, A, {"name": "amount", "type": "string"}, ST, CM]),
]

print("=== 9.2 режим по умолчанию: GET /config ->", call("GET", "/config")[1])

print("=== 9.1 схема из книги: \"default\": \"null\" у поля типа [\"null\", \"string\"]")
book = json.dumps({"namespace": "customerManagement.avro", "type": "record", "name": "Customer",
                   "fields": [{"name": "id", "type": "int"}, {"name": "name", "type": "string"},
                              {"name": "faxNumber", "type": ["null", "string"], "default": "null"}]})
reset("book-value", "BACKWARD")
code, r = register("book-value", book)
print(f"  ответ {code}: {r}")
fixed = book.replace('"default": "null"', '"default": null')
reset("book-value", "BACKWARD")
code, r = register("book-value", fixed)
print(f"  с \"default\": null — ответ {code}: {r}")

print("=== 9.2 одно изменение схемы PaymentEvent v1 при трёх режимах")
for mode in ["BACKWARD", "FORWARD", "FULL"]:
    print(f"--- {mode}")
    for title, fields in CASES:
        subj = f"pay-{mode.lower()}-value"
        reset(subj, mode)
        register(subj, avro(V1))
        print(f"  {title}: {check(subj, avro(fields))}")

print("=== 9.2 транзитивность: v1 (fee: long) → v2 (fee удалено) → v3 (fee: string, по умолчанию \"\")")
for mode in ["BACKWARD", "BACKWARD_TRANSITIVE"]:
    subj = f"fee-{mode.lower()}-value"
    reset(subj, mode)
    print(f"--- {mode}")
    print("  v1:", register(subj, avro([S, AMT, {"name": "fee", "type": "long"}]))[1])
    print("  v2:", register(subj, avro([S, AMT]))[1])
    code, r = register(subj, avro([S, AMT, {"name": "fee", "type": "string", "default": ""}]))
    print(f"  v3: ответ {code}: {str(r)[:220]}")

print("=== 9.2 Protobuf: номер поля 3 занят другим типом, переименование с тем же номером")
P1 = 'syntax = "proto3"; package bank.tundra.pay; message PaymentEvent { string payment_id = 1; string account_id = 2; int64 amount = 3; }'
P2 = 'syntax = "proto3"; package bank.tundra.pay; message PaymentEvent { string payment_id = 1; string account_id = 2; string amount_text = 3; }'
P3 = 'syntax = "proto3"; package bank.tundra.pay; message PaymentEvent { string payment_id = 1; string payer_account = 2; int64 amount = 3; }'
P4 = 'syntax = "proto3"; package bank.tundra.pay; message PaymentEvent { string payment_id = 1; string account_id = 2; int64 amount = 3; string channel = 4; }'
for title, sch in [("поле 3: int64 amount → string amount_text", P2), ("поле 2: account_id → payer_account, тип тот же", P3),
                   ("новое поле channel = 4", P4)]:
    reset("pb-value", "BACKWARD")
    register("pb-value", P1, "PROTOBUF")
    print(f"  {title}: {check('pb-value', sch, 'PROTOBUF')}")
