package ops;

import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.config.ConfigResource;

import java.util.*;

import static ops.Util.*;

/**
 * Раздел 8.1: удаление по времени и объёму.
 * ts      — срок хранения считается по меткам времени записей, а не по времени изменения файла;
 * active  — активный сегмент не удаляется, пока не закрыт;
 * bytes   — retention.bytes действует на партицию;
 * bytime  — поиск смещения по времени возвращает точное смещение, а не начало сегмента;
 * future  — запись с меткой времени на 2 часа вперёд.
 */
public class RetentionLab {
    static final long DAY = 86_400_000L;

    public static void main(String[] args) throws Exception {
        try (var a = admin()) {
            var only = args.length > 0 ? Set.of(args) : Set.of("ts", "active", "trickle", "bytes", "bytime", "future");
            if (only.contains("ts")) ts(a);
            if (only.contains("active")) active(a);
            if (only.contains("trickle")) trickle(a);
            if (only.contains("bytes")) bytes(a);
            if (only.contains("bytime")) bytime(a);
            if (only.contains("future")) future(a);
        }
    }

    static void ts(Admin a) throws Exception {
        System.out.println("=== 8.1 срок хранения по меткам времени: retention.ms = 7 суток, записи с меткой «8 суток назад»");
        createTopic(a, "r-ts", 1, Map.of("retention.ms", String.valueOf(7 * DAY), "segment.ms", "3000"));
        try (var p = producer(Map.of())) {
            long old = System.currentTimeMillis() - 8 * DAY;
            for (int i = 0; i < 5; i++) p.send(new ProducerRecord<>("r-ts", 0, old, "k" + i, "старая-" + i)).get();
            Thread.sleep(3500);
            p.send(new ProducerRecord<>("r-ts", "k-new", "свежая")).get();   // закрывает первый сегмент
        }
        System.out.println(sec() + " записано 5 старых и 1 свежая; первое смещение " + earliest(a, "r-ts", 0));
        for (int i = 0; i < 12; i++) {
            Thread.sleep(2500);
            long e = earliest(a, "r-ts", 0);
            if (e > 0) { System.out.println(sec() + " первое смещение стало " + e + ": сегмент со старыми записями удалён"); return; }
        }
        System.out.println(sec() + " сегмент не удалён за 30 с");
    }

    static void active(Admin a) throws Exception {
        System.out.println("=== 8.1 активный сегмент: retention.ms = 5 с, segment.ms по умолчанию (7 суток)");
        createTopic(a, "r-active", 1, Map.of("retention.ms", "5000"));
        try (var p = producer(Map.of())) {
            for (int i = 0; i < 5; i++) p.send(new ProducerRecord<>("r-active", "k" + i, "v" + i)).get();
        }
        Thread.sleep(25_000);
        System.out.println(sec() + " через 25 с первое смещение " + earliest(a, "r-active", 0) + ", записей " + readAll("r-active", 0).size());
        var res = new ConfigResource(ConfigResource.Type.TOPIC, "r-active");
        a.incrementalAlterConfigs(Map.of(res, List.of(new AlterConfigOp(new ConfigEntry("segment.ms", "2000"), AlterConfigOp.OpType.SET)))).all().get();
        Thread.sleep(2500);
        try (var p = producer(Map.of())) { p.send(new ProducerRecord<>("r-active", "k5", "v5")).get(); }
        for (int i = 0; i < 12; i++) {
            Thread.sleep(2500);
            long e = earliest(a, "r-active", 0);
            if (e > 0) { System.out.println(sec() + " после segment.ms = 2 с и новой записи первое смещение " + e); return; }
        }
        System.out.println(sec() + " не удалено");
    }

    /** Активный сегмент, в который пишут каждые 2 с: его последняя запись всегда свежая. */
    static void trickle(Admin a) throws Exception {
        System.out.println("=== 8.1 активный сегмент с редкой записью: retention.ms = 10 с, запись каждые 2 с в течение 40 с");
        createTopic(a, "r-trickle", 1, Map.of("retention.ms", "10000"));
        try (var p = producer(Map.of("linger.ms", 0))) {
            for (int i = 0; i < 20; i++) {
                p.send(new ProducerRecord<>("r-trickle", "k", "v" + i)).get();
                Thread.sleep(2000);
                if (i % 5 == 4) System.out.println(sec() + " записано " + (i + 1) + ", первое смещение " + earliest(a, "r-trickle", 0));
            }
        }
        for (int i = 0; i < 12; i++) {
            Thread.sleep(2500);
            long e = earliest(a, "r-trickle", 0);
            if (e > 0) { System.out.println(sec() + " запись прекращена; первое смещение стало " + e); return; }
        }
        System.out.println(sec() + " после остановки записи не удалено за 30 с");
    }

    static void bytes(Admin a) throws Exception {
        System.out.println("=== 8.1 retention.bytes на партицию: 3 партиции, retention.bytes = 3 МиБ, segment.bytes = 1 МиБ, по 6 МиБ в каждую");
        createTopic(a, "r-bytes", 3, Map.of("retention.bytes", String.valueOf(3 << 20), "segment.bytes", String.valueOf(1 << 20)));
        String v = "x".repeat(1000);
        try (var p = producer(Map.of("linger.ms", 20, "compression.type", "none"))) {
            for (int part = 0; part < 3; part++)
                for (int i = 0; i < 6300; i++) p.send(new ProducerRecord<>("r-bytes", part, "k", v));
            p.flush();
        }
        Thread.sleep(15_000);
        var dirs = a.describeLogDirs(List.of(1)).allDescriptions().get().get(1);
        long total = 0;
        for (var d : dirs.values())
            for (var e : d.replicaInfos().entrySet())
                if (e.getKey().topic().equals("r-bytes")) {
                    System.out.printf(Locale.ROOT, "  %s: %.2f МиБ, первое смещение %d%n", e.getKey(), e.getValue().size() / 1048576.0,
                            earliest(a, "r-bytes", e.getKey().partition()));
                    total += e.getValue().size();
                }
        System.out.printf(Locale.ROOT, "  всего на диске: %.2f МиБ при retention.bytes = 3 МиБ%n", total / 1048576.0);
    }

    static void bytime(Admin a) throws Exception {
        System.out.println("=== 8.1 поиск смещения по времени: 100 записей с метками T0 + i секунд, запрос T0 + 50,5 с");
        createTopic(a, "r-time", 1, Map.of());
        long t0 = System.currentTimeMillis() - 3_600_000;
        try (var p = producer(Map.of())) {
            for (int i = 0; i < 100; i++) p.send(new ProducerRecord<>("r-time", 0, t0 + i * 1000L, "k", "v" + i));
            p.flush();
        }
        var tp = new TopicPartition("r-time", 0);
        var r = a.listOffsets(Map.of(tp, OffsetSpec.forTimestamp(t0 + 50_500))).all().get().get(tp);
        System.out.println("  смещение " + r.offset() + ", его метка T0 + " + (r.timestamp() - t0) / 1000 + " с (сегмент один, его начало — смещение 0)");
    }

    static void future(Admin a) throws Exception {
        System.out.println("=== 8.1 запись с меткой времени на 2 часа вперёд (message.timestamp.after.max.ms по умолчанию)");
        createTopic(a, "r-future", 1, Map.of());
        try (var p = producer(Map.of("retries", 0, "delivery.timeout.ms", 10000, "request.timeout.ms", 5000, "linger.ms", 0))) {
            p.send(new ProducerRecord<>("r-future", 0, System.currentTimeMillis() + 2 * 3_600_000L, "k", "v")).get();
            System.out.println("  принята");
        } catch (Exception e) {
            System.out.println("  " + e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage());
        }
        var res = new ConfigResource(ConfigResource.Type.TOPIC, "r-future");
        var c = a.describeConfigs(List.of(res)).all().get().get(res).get("message.timestamp.after.max.ms");
        System.out.println("  message.timestamp.after.max.ms = " + c.value() + " (" + c.source() + ")");
    }
}
