package ops;

import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.*;

import java.time.Duration;
import java.util.*;

/** Общие помощники опытов главы 29, разделы 8–16. */
final class Util {
    static String BOOT = System.getProperty("boot", "localhost:39192");
    static final long T0 = System.currentTimeMillis();

    static Admin admin() {
        return Admin.create(Map.of(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT));
    }

    static KafkaProducer<String, String> producer(Map<String, Object> extra) {
        var p = new HashMap<String, Object>(Map.of(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class));
        p.putAll(extra);
        return new KafkaProducer<>(p);
    }

    static void createTopic(Admin a, String name, int partitions, Map<String, String> cfg) throws Exception {
        try { a.deleteTopics(List.of(name)).all().get(); Thread.sleep(1500); } catch (Exception ignore) { }
        a.createTopics(List.of(new NewTopic(name, partitions, (short) 1).configs(cfg))).all().get();
    }

    /** Все записи партиции 0 с начала: key=value@offset, null-значение печатается как ⌀. */
    static List<String> readAll(String topic, int partition) {
        var p = Map.<String, Object>of(
                ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT,
                ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class,
                ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class,
                ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        var out = new ArrayList<String>();
        try (var c = new KafkaConsumer<String, String>(p)) {
            var tp = new TopicPartition(topic, partition);
            c.assign(List.of(tp));
            c.seekToBeginning(List.of(tp));
            long end = c.endOffsets(List.of(tp)).get(tp);
            long deadline = System.currentTimeMillis() + 10_000;
            while (c.position(tp) < end && System.currentTimeMillis() < deadline) {
                for (var r : c.poll(Duration.ofMillis(300)))
                    out.add(r.key() + "=" + (r.value() == null ? "⌀" : r.value()) + "@" + r.offset());
            }
        }
        return out;
    }

    static long earliest(Admin a, String topic, int partition) throws Exception {
        var tp = new TopicPartition(topic, partition);
        return a.listOffsets(Map.of(tp, OffsetSpec.earliest())).all().get().get(tp).offset();
    }

    static String sec() {
        return String.format(Locale.ROOT, "%6.1f с", (System.currentTimeMillis() - T0) / 1000.0);
    }

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); }
    }
}
