package ops;

import org.apache.kafka.clients.producer.*;

import java.util.*;

import static ops.Util.*;

/**
 * Разделы 14.4 и 18: производитель на заполненном буфере. Брокер замораживается (docker pause k29ops)
 * после того, как производитель получил метаданные; send() вызывается в цикле.
 */
public class ProducerBlock {
    public static void main(String[] args) throws Exception {
        try (var a = admin()) { createTopic(a, "pb-pay", 1, Map.of()); }
        try (var p = producer(Map.of("buffer.memory", 65536, "max.block.ms", 3000, "linger.ms", 1000,
                "batch.size", 16384, "delivery.timeout.ms", 120000, "request.timeout.ms", 30000))) {
            p.send(new ProducerRecord<>("pb-pay", "acc-1", "прогрев")).get();
            new ProcessBuilder("docker", "pause", "k29ops").inheritIO().start().waitFor();
            System.out.println("=== 14.4 буфер 64 КиБ, max.block.ms = 3000, брокер заморожен");
            String v = "x".repeat(1000);
            long t0 = System.currentTimeMillis();
            for (int i = 0; i < 68; i++) {
                long t = System.currentTimeMillis();
                java.util.concurrent.Future<RecordMetadata> f;
                try {
                    f = p.send(new ProducerRecord<>("pb-pay", "acc-1", v));
                } catch (Exception e) {
                    System.out.printf(Locale.ROOT, "  send() №%d бросил исключение через %d мс: %s%n", i + 1, System.currentTimeMillis() - t, e);
                    break;
                }
                long took = System.currentTimeMillis() - t;
                if (took > 100) {
                    String res = f.isDone() ? "future уже завершён" : "future не завершён";
                    try { if (f.isDone()) f.get(); } catch (Exception e) { res += " с ошибкой " + e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage(); }
                    System.out.printf("  send() №%d вернул управление через %d мс, %s%n", i + 1, took, res);
                } else if (i == 0 || i == 63) System.out.printf("  send() №%d вернул управление через %d мс%n", i + 1, took);
            }
            for (var m : p.metrics().entrySet()) {
                String n = m.getKey().name();
                if (m.getKey().group().equals("producer-metrics") && (n.equals("buffer-available-bytes") || n.equals("waiting-threads")
                        || n.equals("record-error-rate") || n.equals("bufferpool-wait-time-ns-total")))
                    System.out.println("  " + n + " = " + m.getValue().metricValue());
            }
        } finally {
            new ProcessBuilder("docker", "unpause", "k29ops").inheritIO().start().waitFor();
        }
    }
}
