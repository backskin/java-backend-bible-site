package ops;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.*;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.*;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static ops.Util.*;

/**
 * Раздел 10: согласованное партиционирование соединения поток — таблица,
 * окна и запоздавшие записи, имена внутренних топиков.
 */
public class StreamsLab {
    public static void main(String[] args) throws Exception {
        partitionsDiffer();
        partitionerDiffers();
        grace();
        System.out.println("=== 10.3 TimeWindows.of(Duration) в kafka-streams 4.3.1");
        try {
            TimeWindows.class.getMethod("of", Duration.class);
            System.out.println("  метод есть");
        } catch (NoSuchMethodException e) {
            System.out.println("  метода нет (NoSuchMethodException): остались ofSizeWithNoGrace и ofSizeAndGrace");
        }
    }

    static Properties props(String app) {
        var p = new Properties();
        p.put(StreamsConfig.APPLICATION_ID_CONFIG, app);
        p.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT);
        p.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
        p.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
        p.put(StreamsConfig.STATE_DIR_CONFIG, System.getProperty("java.io.tmpdir") + "/ks29-" + app + "-" + System.nanoTime());
        p.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 200);
        return p;
    }

    /** Платежи (6 партиций) соединяются со справочником счетов (3 партиции). */
    static void partitionsDiffer() throws Exception {
        for (boolean streamStream : List.of(false, true)) partitionsDiffer(streamStream);
    }

    static void partitionsDiffer(boolean streamStream) throws Exception {
        System.out.println("=== 10.2 соединение " + (streamStream ? "KStream–KStream (окно 5 мин)" : "KStream–KTable") + ": у топиков 6 и 3 партиции");
        try (var a = admin()) {
            createTopic(a, "ks-pay", 6, Map.of());
            createTopic(a, "ks-acc", 3, Map.of());
            createTopic(a, "ks-out", 6, Map.of());
        }
        try (var p = producer(Map.of())) {
            for (int i = 0; i < 12; i++) p.send(new ProducerRecord<>("ks-acc", "acc-" + i, "владелец-" + i));
            p.flush();
        }
        var b = new StreamsBuilder();
        if (streamStream) {
            KStream<String, String> acc = b.stream("ks-acc");
            b.<String, String>stream("ks-pay").join(acc, (pay, a) -> pay + "|" + a,
                    JoinWindows.ofTimeDifferenceWithNoGrace(Duration.ofMinutes(5))).to("ks-out");
        } else {
            KTable<String, String> acc = b.table("ks-acc");
            b.<String, String>stream("ks-pay").join(acc, (pay, a) -> pay + "|" + a).to("ks-out");
        }
        var ks = new KafkaStreams(b.build(), props("ks-copart-" + System.nanoTime()));
        var err = new StringBuilder();
        ks.setUncaughtExceptionHandler(e -> {
            err.append(e.getClass().getSimpleName()).append(": ").append(e.getMessage());
            return org.apache.kafka.streams.errors.StreamsUncaughtExceptionHandler.StreamThreadExceptionResponse.SHUTDOWN_CLIENT;
        });
        ks.start();
        long t = System.currentTimeMillis();
        while (System.currentTimeMillis() - t < 30_000 && ks.state() != KafkaStreams.State.RUNNING && err.isEmpty()) Thread.sleep(200);
        Thread.sleep(1000);
        System.out.println("  состояние приложения: " + ks.state() + (err.isEmpty() ? "" : "; " + err));
        var tasks = new TreeSet<String>();
        ks.metadataForLocalThreads().forEach(th -> th.activeTasks().forEach(x -> tasks.add(x.taskId() + "" + x.topicPartitions())));
        System.out.println("  задачи: " + tasks);
        if (ks.state() == KafkaStreams.State.RUNNING) {
            Thread.sleep(3000);
            try (var p = producer(Map.of())) {
                for (int r = 0; r < 10; r++)
                    for (int i = 0; i < 12; i++) p.send(new ProducerRecord<>("ks-pay", "acc-" + i, "платёж-" + r));
                p.flush();
            }
            Thread.sleep(8000);
            int out = 0;
            for (int part = 0; part < 6; part++) out += readAll("ks-out", part).size();
            System.out.println("  платежей 120 (12 счетов по 10), результатов соединения " + out + ", состояние " + ks.state());
        }
        ks.close(Duration.ofSeconds(10));
    }

    /** Те же 6 и 6 партиций, но справочник записан RoundRobinPartitioner'ом. */
    static void partitionerDiffers() throws Exception {
        System.out.println("=== 10.2 соединение KStream–KTable: 6 и 6 партиций, справочник записан RoundRobinPartitioner");
        try (var a = admin()) {
            createTopic(a, "ks-pay2", 6, Map.of());
            createTopic(a, "ks-acc2", 6, Map.of());
            createTopic(a, "ks-out2", 6, Map.of());
        }
        try (var p = producer(Map.of("partitioner.class", "org.apache.kafka.clients.producer.RoundRobinPartitioner"))) {
            for (int i = 0; i < 12; i++) p.send(new ProducerRecord<>("ks-acc2", "acc-" + i, "владелец-" + i));
            p.flush();
        }
        var app = "ks-rr-" + System.nanoTime();
        var b = new StreamsBuilder();
        KTable<String, String> acc = b.table("ks-acc2");
        b.<String, String>stream("ks-pay2").join(acc, (pay, a) -> pay + "|" + a).to("ks-out2");
        var ks = new KafkaStreams(b.build(), props(app));
        var joined = new AtomicInteger();
        ks.start();
        while (ks.state() != KafkaStreams.State.RUNNING) Thread.sleep(200);
        Thread.sleep(3000);
        try (var p = producer(Map.of())) {
            for (int r = 0; r < 10; r++)
                for (int i = 0; i < 12; i++) p.send(new ProducerRecord<>("ks-pay2", "acc-" + i, "платёж-" + r));
            p.flush();
        }
        Thread.sleep(8000);
        int out = 0;
        for (int part = 0; part < 6; part++) out += readAll("ks-out2", part).size();
        System.out.println("  платежей 120 (12 счетов по 10), результатов соединения " + out + ", ошибок нет, состояние " + ks.state());
        ks.close(Duration.ofSeconds(10));
        try (var a = admin()) {
            var internal = a.listTopics().names().get().stream().filter(n -> n.startsWith(app)).sorted().toList();
            System.out.println("  внутренние топики приложения: " + (internal.isEmpty() ? "нет" : internal));
        }
    }

    /** Окно 10 минут: запись, опоздавшая на 6 минут, при grace = 0 и grace = 5 минут. */
    static void grace() {
        System.out.println("=== 10.3 окна и запоздавшие записи (TopologyTestDriver)");
        for (var w : List.of(TimeWindows.ofSizeWithNoGrace(Duration.ofMinutes(10)),
                             TimeWindows.ofSizeAndGrace(Duration.ofMinutes(10), Duration.ofMinutes(5)))) {
            var b = new StreamsBuilder();
            b.<String, String>stream("pay").groupByKey().windowedBy(w).count(Materialized.as("cnt"))
             .toStream().map((k, v) -> KeyValue.pair(k.key() + "@" + k.window().startTime(), String.valueOf(v))).to("out");
            var p = new Properties();
            p.put(StreamsConfig.APPLICATION_ID_CONFIG, "grace");
            p.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "dummy:1");
            p.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
            p.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.StringSerde.class);
            p.put(StreamsConfig.METRICS_RECORDING_LEVEL_CONFIG, "DEBUG");
            try (var d = new TopologyTestDriver(b.build(), p)) {
                var in = d.createInputTopic("pay", new StringSerializer(), new StringSerializer());
                var out = d.createOutputTopic("out", new StringDeserializer(), new StringDeserializer());
                Instant t0 = Instant.parse("2026-11-02T10:00:00Z");
                in.pipeInput("client-7", "p1", t0.plusSeconds(60));          // 10:01, окно 10:00–10:10
                in.pipeInput("client-7", "p2", t0.plusSeconds(13 * 60));     // 10:13, время потока ушло за конец окна
                in.pipeInput("client-7", "p3", t0.plusSeconds(4 * 60));      // 10:04, опоздала: окно закрылось в 10:10
                double dropped = d.metrics().entrySet().stream()
                        .filter(e -> e.getKey().name().equals("dropped-records-total"))
                        .mapToDouble(e -> ((Number) e.getValue().metricValue()).doubleValue()).sum();
                System.out.println("  grace " + w.gracePeriodMs() / 60000 + " мин: результаты " + out.readKeyValuesToList()
                        + "; отброшено записей " + (long) dropped);
            }
        }
    }
}
