package ops;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.*;
import org.springframework.context.annotation.*;
import org.springframework.kafka.annotation.*;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import java.util.*;
import java.util.concurrent.*;

import static ops.Util.*;

/** Раздел 11.5: неблокирующие повторы @RetryableTopic в Spring Kafka 4.1.1. */
public class RetryLab {
    static final List<String> LOG = Collections.synchronizedList(new ArrayList<>());
    static final Map<String, Integer> FAILS = new ConcurrentHashMap<>();

    @Configuration
    @EnableKafka
    @EnableKafkaRetryTopic
    static class Cfg {
        @Bean ConsumerFactory<String, String> consumerFactory() {
            return new DefaultKafkaConsumerFactory<>(Map.of(
                    ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT,
                    ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest",
                    ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class,
                    ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class));
        }
        @Bean ProducerFactory<String, String> producerFactory() {
            return new DefaultKafkaProducerFactory<>(Map.of(
                    ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT,
                    ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                    ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class));
        }
        @Bean KafkaTemplate<String, String> defaultRetryTopicKafkaTemplate(ProducerFactory<String, String> pf) {
            return new KafkaTemplate<>(pf);
        }
        @Bean ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory(ConsumerFactory<String, String> cf) {
            var f = new ConcurrentKafkaListenerContainerFactory<String, String>();
            f.setConsumerFactory(cf);
            return f;
        }
        @Bean TaskScheduler taskScheduler() {
            var s = new ThreadPoolTaskScheduler();
            s.initialize();
            return s;
        }
        @Bean Listeners listeners() { return new Listeners(); }
    }

    static class Listeners {
        /** Операции по счёту acc-1: «списание-1» падает дважды, «блок» падает всегда. */
        @RetryableTopic(attempts = "4", backOff = @BackOff(delay = 1000, multiplier = 2.0))
        @KafkaListener(topics = "rt-pay", groupId = "rt-billing")
        void onPay(String v, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
            int n = FAILS.merge(v, 1, Integer::sum);
            if (v.equals("блок") || (v.equals("списание-1") && n <= 2)) {
                LOG.add(sec() + " " + topic + ": " + v + " — ошибка (попытка " + n + ")");
                throw new IllegalStateException("антифрод недоступен");
            }
            LOG.add(sec() + " " + topic + ": " + v + " — обработано");
        }

        @DltHandler
        void onDlt(String v, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
            LOG.add(sec() + " " + topic + ": " + v + " — в DLT");
        }

        @RetryableTopic(attempts = "4", backOff = @BackOff(delay = 1000))
        @KafkaListener(topics = "rt-fixed", groupId = "rt-fixed")
        void onFixed(String v) { throw new IllegalStateException("всегда"); }
    }

    public static void main(String[] args) throws Exception {
        try (var a = admin()) {
            for (var n : a.listTopics().names().get()) if (n.startsWith("rt-")) a.deleteTopics(List.of(n)).all().get();
            Thread.sleep(2000);
            createTopic(a, "rt-pay", 1, Map.of());
            createTopic(a, "rt-fixed", 1, Map.of());
        }
        try (var ctx = new AnnotationConfigApplicationContext(Cfg.class)) {
            Thread.sleep(8000);
            try (var p = producer(Map.of())) {
                for (var v : List.of("списание-1", "списание-2", "блок", "списание-3"))
                    p.send(new ProducerRecord<>("rt-pay", "acc-1", v)).get();
                p.send(new ProducerRecord<>("rt-fixed", "acc-2", "x")).get();
            }
            Thread.sleep(25_000);
        }
        System.out.println("=== 11.5 @RetryableTopic(attempts = 4, delay 1000, multiplier 2): события по счёту acc-1 в порядке записи: списание-1, списание-2, блок, списание-3");
        LOG.forEach(l -> System.out.println("  " + l));
        try (var a = admin()) {
            var names = new TreeSet<>(a.listTopics().names().get());
            names.removeIf(n -> !n.startsWith("rt-"));
            System.out.println("=== 11.5 созданные топики: " + names);
            var d = a.describeTopics(names).allTopicNames().get();
            d.forEach((n, t) -> System.out.println("  " + n + ": партиций " + t.partitions().size()));
        }
    }
}
