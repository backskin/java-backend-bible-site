package ops;

import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.producer.*;

import java.util.*;

import static ops.Util.*;

/**
 * Раздел 8.2: уплотнение журнала.
 * tomb    — что остаётся от ключа после уплотнения и когда исчезает надгробие (delete.retention.ms);
 * ratio   — min.cleanable.dirty.ratio = 0,5: малую «грязную» долю уборщик не трогает;
 * nullkey — запись без ключа в уплотняемый топик;
 * policy  — допустимые значения cleanup.policy.
 */
public class CompactionLab {
    public static void main(String[] args) throws Exception {
        try (var a = admin()) {
            var only = args.length > 0 ? Set.of(args) : Set.of("policy", "nullkey", "tomb", "ratio", "active");
            if (only.contains("policy")) policy(a);
            if (only.contains("nullkey")) nullkey(a);
            if (only.contains("tomb")) tomb(a);
            if (only.contains("ratio")) ratio(a);
            if (only.contains("active")) active(a);
        }
    }

    static void policy(Admin a) {
        System.out.println("=== 8.2 значения cleanup.policy");
        for (String v : List.of("delete.and.compact", "compact,delete")) {
            try {
                createTopic(a, "c-policy", 1, Map.of("cleanup.policy", v));
                System.out.println("  " + v + ": топик создан");
            } catch (Exception e) {
                System.out.println("  " + v + ": " + e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage());
            }
        }
    }

    static void nullkey(Admin a) throws Exception {
        System.out.println("=== 8.2 запись без ключа в уплотняемый топик");
        createTopic(a, "c-nullkey", 1, Map.of("cleanup.policy", "compact"));
        try (var p = producer(Map.of("retries", 0, "linger.ms", 0))) {
            p.send(new ProducerRecord<>("c-nullkey", null, "без ключа")).get();
            System.out.println("  принята");
        } catch (Exception e) {
            System.out.println("  " + e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage());
        }
    }

    /** Счёт: acc-1 меняет статус десять раз и закрывается (надгробие), acc-2 открыт; z — служебные записи, закрывающие сегменты. */
    static void tomb(Admin a) throws Exception {
        System.out.println("=== 8.2 надгробие: min.cleanable.dirty.ratio = 0,01, segment.ms = 2 с, delete.retention.ms = 30 с");
        createTopic(a, "c-acc", 1, Map.of("cleanup.policy", "compact", "min.cleanable.dirty.ratio", "0.01",
                "segment.ms", "2000", "delete.retention.ms", "30000"));
        try (var p = producer(Map.of("linger.ms", 0))) {
            for (int i = 1; i <= 10; i++) p.send(new ProducerRecord<>("c-acc", "acc-1", "статус-" + i)).get();
            p.send(new ProducerRecord<>("c-acc", "acc-2", "открыт")).get();
            p.send(new ProducerRecord<>("c-acc", "acc-1", null)).get();
            System.out.println(sec() + " записано: " + readAll("c-acc", 0));
            String last = "";
            int z = 0;
            long start = System.currentTimeMillis();
            while (System.currentTimeMillis() - start < 120_000) {
                Thread.sleep(3000);
                p.send(new ProducerRecord<>("c-acc", "z", "z" + (z++))).get();   // закрывает сегмент, даёт уборщику работу
                var now = readAll("c-acc", 0).stream().filter(s -> !s.startsWith("z=")).toList();
                if (!now.toString().equals(last)) {
                    System.out.println(sec() + " без служебных z: " + now);
                    last = now.toString();
                }
                if (now.stream().noneMatch(s -> s.startsWith("acc-1"))) break;
            }
        }
    }

    static void ratio(Admin a) throws Exception {
        System.out.println("=== 8.2 min.cleanable.dirty.ratio = 0,5 (по умолчанию), segment.ms = 2 с");
        createTopic(a, "c-ratio", 1, Map.of("cleanup.policy", "compact", "segment.ms", "2000"));
        try (var p = producer(Map.of("linger.ms", 5))) {
            for (int i = 0; i < 1000; i++) p.send(new ProducerRecord<>("c-ratio", "k" + i, "v1-" + i));
            p.flush();
            Thread.sleep(2500);
            p.send(new ProducerRecord<>("c-ratio", "roll", "1")).get();
            Thread.sleep(20_000);
            System.out.println(sec() + " 1000 разных ключей: записей в журнале " + readAll("c-ratio", 0).size());
            for (int i = 0; i < 300; i++) p.send(new ProducerRecord<>("c-ratio", "k" + i, "v2-" + i));
            p.flush();
            Thread.sleep(2500);
            p.send(new ProducerRecord<>("c-ratio", "roll", "2")).get();
            Thread.sleep(30_000);
            System.out.println(sec() + " +300 обновлений (грязная доля около 0,23), через 30 с записей " + readAll("c-ratio", 0).size());
            for (int i = 300; i < 1000; i++) p.send(new ProducerRecord<>("c-ratio", "k" + i, "v2-" + i));
            p.flush();
            Thread.sleep(2500);
            p.send(new ProducerRecord<>("c-ratio", "roll", "3")).get();
            for (int t = 0; t < 12; t++) {
                Thread.sleep(5000);
                int n = readAll("c-ratio", 0).size();
                System.out.println(sec() + " +700 обновлений (грязная доля около 0,5): записей " + n);
                if (n < 1500) break;
            }
        }
    }

    /** Активный сегмент не уплотняется: segment.ms по умолчанию, грязная доля 0,01. */
    static void active(Admin a) throws Exception {
        System.out.println("=== 8.2 активный сегмент: min.cleanable.dirty.ratio = 0,01, segment.ms по умолчанию (7 суток)");
        createTopic(a, "c-active", 1, Map.of("cleanup.policy", "compact", "min.cleanable.dirty.ratio", "0.01"));
        try (var p = producer(Map.of("linger.ms", 0))) {
            for (int i = 1; i <= 10; i++) p.send(new ProducerRecord<>("c-active", "acc-1", "статус-" + i)).get();
        }
        Thread.sleep(60_000);
        System.out.println(sec() + " через 60 с записей " + readAll("c-active", 0).size() + " из 10 (все версии acc-1 на месте)");
    }
}
