package ops;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.avro.Schema;
import org.apache.avro.generic.*;
import org.apache.avro.io.*;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.*;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.*;

import static ops.Util.*;

/**
 * Раздел 9.1: что сериализатор с реестром кладёт в значение записи,
 * и чем оборачивается "default": "null" из примера книги.
 */
public class SrWire {
    static final String SR = System.getProperty("sr", "http://localhost:38081");
    static final String V1 = """
        {"type":"record","name":"PaymentEvent","namespace":"bank.tundra.pay","fields":[
          {"name":"paymentId","type":"string"},{"name":"accountId","type":"string"},
          {"name":"amount","type":"long"},{"name":"status","type":"string"}]}""";

    public static void main(String[] args) throws Exception {
        wire();
        bookDefault();
    }

    static void wire() throws Exception {
        System.out.println("=== 9.1 формат значения: KafkaAvroSerializer с реестром");
        try (var a = admin()) { createTopic(a, "pay-sr", 1, Map.of()); }
        var schema = new Schema.Parser().parse(V1);
        GenericRecord ev = new GenericData.Record(schema);
        ev.put("paymentId", "pay-000123");
        ev.put("accountId", "40817810099910004312");
        ev.put("amount", 1_250_000L);
        ev.put("status", "AUTHORIZED");
        var props = new HashMap<String, Object>(Map.of(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class,
                "schema.registry.url", SR));
        try (var p = new KafkaProducer<String, Object>(props)) {
            p.send(new ProducerRecord<>("pay-sr", "pay-000123", ev)).get();
        }
        var cp = Map.<String, Object>of(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT,
                ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class,
                ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer.class);
        try (var c = new KafkaConsumer<String, byte[]>(cp)) {
            var tp = new TopicPartition("pay-sr", 0);
            c.assign(List.of(tp));
            c.seekToBeginning(List.of(tp));
            byte[] v = null;
            while (v == null) for (var r : c.poll(Duration.ofSeconds(1))) v = r.value();
            var hex = new StringBuilder();
            for (int i = 0; i < 5; i++) hex.append(String.format("%02x ", v[i]));
            System.out.println("  первые 5 байт: " + hex + "→ магический байт " + v[0] + ", идентификатор схемы " + ByteBuffer.wrap(v, 1, 4).getInt());
            String json = "{\"paymentId\":\"pay-000123\",\"accountId\":\"40817810099910004312\",\"amount\":1250000,\"status\":\"AUTHORIZED\"}";
            System.out.println("  длина значения " + v.length + " байт (5 байт заголовка + " + (v.length - 5) + " байт Avro); тот же платёж в JSON — " + json.length() + " байт");
        }
    }

    static void bookDefault() throws Exception {
        System.out.println("=== 9.1 \"default\": \"null\" из примера книги в библиотеке Avro " + Schema.class.getPackage().getImplementationVersion());
        String book = """
            {"namespace": "customerManagement.avro", "type": "record", "name": "Customer", "fields": [
              {"name": "id", "type": "int"}, {"name": "name", "type": "string"},
              {"name": "faxNumber", "type": ["null", "string"], "default": "null"}]}""";
        String v2 = """
            {"namespace": "customerManagement.avro", "type": "record", "name": "Customer", "fields": [
              {"name": "id", "type": "int"}, {"name": "name", "type": "string"},
              {"name": "email", "type": ["null", "string"], "default": null}]}""";
        Schema reader;
        try {
            reader = new Schema.Parser().parse(book);
            System.out.println("  Schema.Parser с проверкой значений по умолчанию: разобрана");
        } catch (Exception e) {
            System.out.println("  Schema.Parser с проверкой значений по умолчанию: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            reader = new Schema.Parser().setValidateDefaults(false).parse(book);
            System.out.println("  Schema.Parser без проверки (setValidateDefaults(false)): разобрана");
        }
        Schema writer = new Schema.Parser().parse(v2);
        GenericRecord rec = new GenericData.Record(writer);
        rec.put("id", 1); rec.put("name", "ООО Ромашка"); rec.put("email", "pay@example.org");
        var out = new ByteArrayOutputStream();
        BinaryEncoder enc = EncoderFactory.get().binaryEncoder(out, null);
        new GenericDatumWriter<GenericRecord>(writer).write(rec, enc);
        enc.flush();
        try {
            var dec = DecoderFactory.get().binaryDecoder(out.toByteArray(), null);
            var r = new GenericDatumReader<GenericRecord>(writer, reader).read(null, dec);
            System.out.println("  старый читатель (faxNumber) прочитал запись новой схемы (email): " + r);
        } catch (Exception e) {
            System.out.println("  старый читатель (faxNumber) читает запись новой схемы (email): " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
