package ops;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.*;
import org.springframework.kafka.core.*;
import org.springframework.kafka.listener.*;
import org.springframework.util.backoff.FixedBackOff;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

import static ops.Util.*;

/**
 * Раздел 11: Spring for Apache Kafka 4.1.1 против брокера Kafka 4.3.1.
 * defaults — DefaultErrorHandler без настроек; dltparts — DLT с меньшим числом партиций;
 * batch — пакетный слушатель с обычным исключением и с BatchListenerFailedException;
 * intercept — RecordInterceptor вернул null; longbackoff — пауза повторов длиннее max.poll.interval.ms;
 * api — что есть в классах библиотеки.
 */
public class SpringLab {
    public static void main(String[] args) throws Exception {
        var only = args.length > 0 ? Set.of(args) : Set.of("api", "defaults", "dltparts", "batch", "intercept", "longbackoff");
        if (only.contains("api")) api();
        if (only.contains("defaults")) defaults();
        if (only.contains("dltparts")) dltparts();
        if (only.contains("batch")) batch();
        if (only.contains("intercept")) intercept();
        if (only.contains("longbackoff")) { longbackoff(false, 4000, 3); longbackoff(true, 4000, 3); }
        if (only.contains("longbackoff8")) { longbackoff(false, 8000, 2); longbackoff(true, 8000, 2); }
    }

    static DefaultKafkaConsumerFactory<String, String> cf(String group, Map<String, Object> extra) {
        var p = new HashMap<String, Object>(Map.of(
                ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT,
                ConsumerConfig.GROUP_ID_CONFIG, group,
                ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest",
                ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class,
                ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class));
        p.putAll(extra);
        return new DefaultKafkaConsumerFactory<>(p);
    }

    static KafkaTemplate<Object, Object> template() {
        return new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(Map.of(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOT,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class)));
    }

    static void send(String topic, Integer partition, String... values) throws Exception {
        try (var p = producer(Map.of())) {
            for (var v : values) p.send(new ProducerRecord<>(topic, partition, "acc-1", v)).get();
        }
    }

    static long committed(String group, String topic, int partition) throws Exception {
        try (var a = admin()) {
            var m = a.listConsumerGroupOffsets(group).partitionsToOffsetAndMetadata().get();
            var o = m.get(new TopicPartition(topic, partition));
            return o == null ? -1 : o.offset();
        }
    }

    static void api() throws Exception {
        System.out.println("=== 11 классы и значения по умолчанию spring-kafka " + KafkaTemplate.class.getPackage().getImplementationVersion());
        for (var n : List.of("org.springframework.kafka.transaction.ChainedKafkaTransactionManager",
                "org.springframework.data.transaction.ChainedTransactionManager",
                "org.springframework.kafka.listener.ContainerPausingBackOffHandler",
                "org.springframework.kafka.annotation.BackOff")) {
            try { Class.forName(n); System.out.println("  " + n + ": есть"); }
            catch (ClassNotFoundException | LinkageError e) { System.out.println("  " + n + ": не загружается: " + e); }
        }
        System.out.println("  KafkaTemplate.receive(topic, partition, offset): " +
                (Arrays.stream(KafkaTemplate.class.getMethods()).anyMatch(m -> m.getName().equals("receive")) ? "есть" : "нет"));
        var cp = new ContainerProperties("x");
        System.out.println("  ContainerProperties: ackMode по умолчанию " + cp.getAckMode() + ", syncCommits " + cp.isSyncCommits());
        var h = new DefaultErrorHandler();
        System.out.println("  DefaultErrorHandler(): isAckAfterHandle " + h.isAckAfterHandle());
    }

    /** Ядовитая запись между двумя нормальными, обработчик ошибок без настроек. */
    static void defaults() throws Exception {
        System.out.println("=== 11.4 DefaultErrorHandler без настроек: ok-1, POISON, ok-2");
        try (var a = admin()) { createTopic(a, "sp-def", 1, Map.of()); }
        send("sp-def", 0, "ok-1", "POISON", "ok-2");
        var seen = Collections.synchronizedList(new ArrayList<String>());
        var props = new ContainerProperties("sp-def");
        props.setMessageListener((MessageListener<String, String>) r -> {
            seen.add(r.value());
            if (r.value().equals("POISON")) throw new IllegalStateException("антифрод недоступен");
        });
        var c = new KafkaMessageListenerContainer<>(cf("g-def", Map.of()), props);
        c.setCommonErrorHandler(new DefaultErrorHandler());
        c.start();
        long t = System.currentTimeMillis();
        while (!seen.contains("ok-2") && System.currentTimeMillis() - t < 60_000) Thread.sleep(200);
        Thread.sleep(2000);
        c.stop();
        System.out.println("  доставки по порядку: " + seen);
        System.out.println("  POISON обработан " + seen.stream().filter("POISON"::equals).count() + " раз; зафиксированное смещение группы " + committed("g-def", "sp-def", 0));
    }

    /** Исходный топик 3 партиции, DLT заранее создан с одной; ядовитая запись в партиции 2. */
    static void dltparts() throws Exception {
        System.out.println("=== 11.4 DLT с меньшим числом партиций: исходный топик 3 партиции, sp-dp-dlt — 1, запись в партиции 2");
        try (var a = admin()) { createTopic(a, "sp-dp", 3, Map.of()); createTopic(a, "sp-dp-dlt", 1, Map.of()); }
        send("sp-dp", 2, "POISON");
        var done = new CountDownLatch(1);
        var props = new ContainerProperties("sp-dp");
        props.setMessageListener((MessageListener<String, String>) r -> { throw new IllegalStateException("плохой платёж"); });
        var c = new KafkaMessageListenerContainer<>(cf("g-dp", Map.of()), props);
        var rec = new DeadLetterPublishingRecoverer(template());
        c.setCommonErrorHandler(new DefaultErrorHandler(rec, new FixedBackOff(0, 1)));
        c.start();
        Thread.sleep(12_000);
        c.stop();
        var got = readAll("sp-dp-dlt", 0);
        System.out.println("  в sp-dp-dlt, партиция 0: " + got + "; смещение группы в sp-dp-2: " + committed("g-dp", "sp-dp", 2));
    }

    /** Пакет из 10 записей, сбой на пятой (индекс 4). */
    static void batch() throws Exception {
        for (boolean precise : List.of(false, true)) {
            String topic = precise ? "sp-batch2" : "sp-batch1";
            System.out.println("=== 11.6 пакетный слушатель, сбой на записи с индексом 4, " +
                    (precise ? "BatchListenerFailedException(index 4)" : "обычное исключение") + ", FixedBackOff(0, 2) и DLT");
            try (var a = admin()) { createTopic(a, topic, 1, Map.of()); createTopic(a, topic + "-dlt", 1, Map.of()); }
            String[] vals = new String[10];
            for (int i = 0; i < 10; i++) vals[i] = i == 4 ? "POISON" : "pay-" + i;
            send(topic, 0, vals);
            var calls = Collections.synchronizedList(new ArrayList<Integer>());
            var props = new ContainerProperties(topic);
            props.setMessageListener((BatchMessageListener<String, String>) recs -> {
                calls.add(recs.size());
                for (int i = 0; i < recs.size(); i++)
                    if (recs.get(i).value().equals("POISON")) {
                        if (precise) throw new BatchListenerFailedException("сбой на " + i, i);
                        throw new IllegalStateException("сбой в пакете");
                    }
            });
            var c = new KafkaMessageListenerContainer<>(cf("g-" + topic, Map.of()), props);
            c.setCommonErrorHandler(new DefaultErrorHandler(new DeadLetterPublishingRecoverer(template()), new FixedBackOff(0, 2)));
            c.start();
            Thread.sleep(12_000);
            c.stop();
            var dlt = readAll(topic + "-dlt", 0).stream().map(s -> s.substring(s.indexOf('=') + 1, s.indexOf('@'))).toList();
            System.out.println("  размеры пакетов в вызовах слушателя: " + calls);
            System.out.println("  в DLT " + dlt.size() + " записей: " + dlt + "; смещение группы " + committed("g-" + topic, topic, 0));
        }
    }

    /** Перехватчик возвращает null для второй записи. */
    static void intercept() throws Exception {
        System.out.println("=== 11.8 RecordInterceptor вернул null для pay-2");
        try (var a = admin()) { createTopic(a, "sp-int", 1, Map.of()); }
        send("sp-int", 0, "pay-1", "pay-2", "pay-3");
        var seen = Collections.synchronizedList(new ArrayList<String>());
        var props = new ContainerProperties("sp-int");
        props.setMessageListener((MessageListener<String, String>) r -> seen.add(r.value()));
        var c = new KafkaMessageListenerContainer<>(cf("g-int", Map.of()), props);
        c.setRecordInterceptor((r, consumer) -> r.value().equals("pay-2") ? null : r);
        c.start();
        Thread.sleep(8000);
        c.stop();
        System.out.println("  слушатель получил " + seen + "; смещение группы " + committed("g-int", "sp-int", 0));
    }

    /** max.poll.interval.ms = 6 с, повторы с паузой 4 с, три повтора: 12 с ожидания на одну запись. */
    static void longbackoff(boolean pausing, long ms, int n) throws Exception {
        String topic = (pausing ? "sp-lb2-" : "sp-lb1-") + ms;
        System.out.println("=== 11.4 блокирующие повторы: FixedBackOff(" + ms + ", " + n + "), max.poll.interval.ms = 6000, " +
                (pausing ? "ContainerPausingBackOffHandler" : "обработчик паузы по умолчанию"));
        try (var a = admin()) { createTopic(a, topic, 1, Map.of()); }
        send(topic, 0, "POISON", "ok-2");
        var events = Collections.synchronizedList(new ArrayList<String>());
        var props = new ContainerProperties(topic);
        props.setMessageListener((MessageListener<String, String>) r -> {
            events.add(sec() + " " + r.value());
            if (r.value().equals("POISON")) throw new IllegalStateException("антифрод недоступен");
        });
        props.setConsumerRebalanceListener(new ConsumerRebalanceListener() {
            public void onPartitionsRevoked(Collection<TopicPartition> p) { if (!p.isEmpty()) events.add(sec() + " отозваны " + p); }
            public void onPartitionsAssigned(Collection<TopicPartition> p) { if (!p.isEmpty()) events.add(sec() + " назначены " + p); }
            public void onPartitionsLost(Collection<TopicPartition> p) { if (!p.isEmpty()) events.add(sec() + " потеряны " + p); }
        });
        var c = new KafkaMessageListenerContainer<>(cf("g-" + topic, Map.of(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, 6000)), props);
        var sched = new org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler();
        sched.initialize();
        var h = pausing
                ? new DefaultErrorHandler(null, new FixedBackOff(ms, n),
                        new ContainerPausingBackOffHandler(new ListenerContainerPauseService(null, sched)))
                : new DefaultErrorHandler(new FixedBackOff(ms, n));
        c.setCommonErrorHandler(h);
        c.start();
        Thread.sleep(30_000);
        c.stop();
        events.forEach(e -> System.out.println("  " + e));
    }
}
