#!/usr/bin/env bash
# Один узел apache/kafka:4.3.1 для опытов разделов 8–16 главы 29.
# Контейнер k29ops, сеть k29net (для Schema Registry), порт 39192 снаружи.
# Проверка сроков хранения раз в 5 с вместо 5 мин, чтобы опыты с удалением сегментов шли минуты, а не часы.
set -u
export MSYS_NO_PATHCONV=1
IMG=apache/kafka:4.3.1
docker rm -f k29ops >/dev/null 2>&1
docker network create k29net >/dev/null 2>&1
docker run -d --name k29ops --network k29net -p 39192:39192 \
  -e KAFKA_NODE_ID=1 -e KAFKA_PROCESS_ROLES=broker,controller \
  -e KAFKA_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093,EXTERNAL://:39192 \
  -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://k29ops:9092,EXTERNAL://localhost:39192 \
  -e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT,CONTROLLER:PLAINTEXT,EXTERNAL:PLAINTEXT \
  -e KAFKA_CONTROLLER_LISTENER_NAMES=CONTROLLER -e KAFKA_CONTROLLER_QUORUM_VOTERS=1@localhost:9093 \
  -e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT -e KAFKA_LOG_DIRS=/var/lib/kafka/data \
  -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 -e KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR=1 \
  -e KAFKA_TRANSACTION_STATE_LOG_MIN_ISR=1 \
  -e KAFKA_LOG_RETENTION_CHECK_INTERVAL_MS=5000 \
  $IMG >/dev/null
for i in $(seq 1 60); do docker exec k29ops /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list >/dev/null 2>&1 && break; sleep 1; done
echo "брокер $IMG готов: k29ops, localhost:39192"
