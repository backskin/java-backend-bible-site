#!/usr/bin/env bash
# Раздел 12.1 главы 29: переназначение реплик с ограничением скорости и снятие ограничения через --verify.
# Три узла apache/kafka:4.3.1 (broker,controller) в сети k29r; запуск: ./reassign.sh > s29-reassign.txt
set -u
export MSYS_NO_PATHCONV=1
IMG=apache/kafka:4.3.1
CID=MkU3OEVBNTcwNTJENDM2Qk
docker network create k29r >/dev/null 2>&1
for n in 1 2 3; do
  docker rm -f kr$n >/dev/null 2>&1
  docker run -d --name kr$n --network k29r \
    -e CLUSTER_ID=$CID -e KAFKA_NODE_ID=$n -e KAFKA_PROCESS_ROLES=broker,controller \
    -e KAFKA_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093 \
    -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://kr$n:9092 \
    -e KAFKA_CONTROLLER_LISTENER_NAMES=CONTROLLER \
    -e KAFKA_CONTROLLER_QUORUM_VOTERS=1@kr1:9093,2@kr2:9093,3@kr3:9093 \
    -e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT -e KAFKA_LOG_DIRS=/var/lib/kafka/data $IMG >/dev/null
done
B="docker exec kr1 /opt/kafka/bin"
for i in $(seq 1 90); do $B/kafka-topics.sh --bootstrap-server kr1:9092 --list >/dev/null 2>&1 && break; sleep 2; done
echo "=== кластер из трёх узлов $IMG готов"
$B/kafka-topics.sh --bootstrap-server kr1:9092 --create --topic payments --replica-assignment 1:2 >/dev/null
$B/kafka-producer-perf-test.sh --topic payments --num-records 60000 --record-size 1000 --throughput -1 \
  --producer-props bootstrap.servers=kr1:9092 acks=all compression.type=none 2>/dev/null | tail -1
echo "=== размещение до переноса"
$B/kafka-topics.sh --bootstrap-server kr1:9092 --describe --topic payments | grep Partition:
docker exec kr1 bash -c 'echo "{\"version\":1,\"partitions\":[{\"topic\":\"payments\",\"partition\":0,\"replicas\":[2,3]}]}" > /tmp/plan.json'
echo "=== --execute --throttle 5000000 (5 МБ/с), реплика переезжает с брокера 1 на брокер 3"
T0=$(date +%s)
$B/kafka-reassign-partitions.sh --bootstrap-server kr1:9092 --reassignment-json-file /tmp/plan.json --execute --throttle 5000000 | grep -v "^$" | tail -3
echo "=== ограничения во время переноса"
for n in 1 2 3; do $B/kafka-configs.sh --bootstrap-server kr1:9092 --entity-type brokers --entity-name $n --describe | grep -o "[a-z.]*throttled[a-z.]*=[0-9]*" | sed "s/^/  брокер $n: /"; done
$B/kafka-configs.sh --bootstrap-server kr1:9092 --entity-type topics --entity-name payments --describe | grep -o "[a-z.]*throttled.replicas=[^ ]*" | sed "s/^/  топик: /"
while ! $B/kafka-topics.sh --bootstrap-server kr1:9092 --describe --topic payments | grep -q "Replicas: 2,3	Isr: 2,3\|Replicas: 2,3\s*Isr: 3,2\|Replicas: 2,3	Isr: 3,2"; do sleep 2; done
echo "  перенос 60 МБ занял около $(( $(date +%s) - T0 )) с"
echo "=== размещение после переноса, до --verify"
$B/kafka-topics.sh --bootstrap-server kr1:9092 --describe --topic payments | grep Partition:
for n in 1 2 3; do echo "  брокер $n: $($B/kafka-configs.sh --bootstrap-server kr1:9092 --entity-type brokers --entity-name $n --describe | grep -c throttled) настроек ограничения"; done
echo "=== --verify"
$B/kafka-reassign-partitions.sh --bootstrap-server kr1:9092 --reassignment-json-file /tmp/plan.json --verify | grep -v "^$"
for n in 1 2 3; do echo "  брокер $n: $($B/kafka-configs.sh --bootstrap-server kr1:9092 --entity-type brokers --entity-name $n --describe | grep -c throttled) настроек ограничения"; done
echo "  топик: $($B/kafka-configs.sh --bootstrap-server kr1:9092 --entity-type topics --entity-name payments --describe | grep -c throttled) настроек ограничения"
echo "=== уменьшить число партиций"
$B/kafka-topics.sh --bootstrap-server kr1:9092 --create --topic pay3 --partitions 3 --replication-factor 2 >/dev/null
$B/kafka-topics.sh --bootstrap-server kr1:9092 --alter --topic pay3 --partitions 2 2>&1 | grep -iE "error|exception" | head -2
for n in 1 2 3; do docker rm -f kr$n >/dev/null; done
