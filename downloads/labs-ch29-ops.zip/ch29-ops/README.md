# Опыты главы 29, разделы 8–14 и 18: хранение, схемы, Streams, Spring Kafka, эксплуатация

Проверено 2026-11-02: Windows + Git Bash, JDK 21.0.10 (Temurin), Maven 3.9.16, Docker. Брокер `apache/kafka:4.3.1`, клиенты kafka-clients и kafka-streams 4.3.1, Spring Boot 4.1.1 (spring-kafka 4.1.1), Confluent Schema Registry и `kafka-avro-serializer` 8.4.0 (Avro 1.12.1).

## Состав

| Класс или скрипт | Что проверяет | Раздел главы | Вывод |
|---|---|---|---|
| `broker.sh` | один узел Kafka 4.3.1 (`k29ops`, порт 39192, сеть `k29net`), проверка сроков хранения раз в 5 с | - | - |
| `RetentionLab` | срок хранения по меткам времени; активный сегмент; `retention.bytes` на партицию; поиск по времени; метка времени из будущего | 8.1 | `s29-retention.txt`, `s29-retention-trickle.txt` |
| `CompactionLab` | значения `cleanup.policy`; запись без ключа; надгробие и `delete.retention.ms`; `min.cleanable.dirty.ratio`; активный сегмент не уплотняется | 8.2 | `s29-compaction.txt`, `s29-cleaner-log.txt` |
| `sr_lab.py` | ответы реестра схем на восемь изменений при `BACKWARD`/`FORWARD`/`FULL`, транзитивность, Protobuf, схема из книги с `"default": "null"` | 9.2 | `s29-sr.txt` |
| `SrWire` | пять байт заголовка сериализатора, размер Avro против JSON; `"default": "null"` у читателя | 9.1 | `s29-sr-wire.txt` |
| `StreamsLab` | соединения при разном числе партиций и разном разделителе; окна и время ожидания; `TimeWindows.of` | 10.2, 10.3 | `s29-streams.txt` |
| `SpringLab` | API spring-kafka 4.1.1; `DefaultErrorHandler` без настроек; DLT с меньшим числом партиций; пакетный слушатель; `RecordInterceptor` с `null`; паузы повторов и `max.poll.interval.ms` | 11.1–11.8 | `s29-spring.txt`, `s29-spring-lb8.txt` |
| `RetryLab` | `@RetryableTopic`: имена топиков повторов и нарушение порядка | 11.5 | `s29-retry.txt` |
| `embedded/EmbeddedTx.java` | встроенный брокер `spring-kafka-test` без настроек топика транзакций | 11.9 | `s29-embedded-tx.txt` |
| `ProducerBlock` | `send()` на заполненном буфере при замороженном брокере | 12.2, 14.4 | `s29-producer-block.txt` |
| `reassign.sh` | перенос реплики с `--throttle` на трех узлах и снятие ограничения `--verify`; уменьшение числа партиций | 12.1 | `s29-reassign.txt` |

## Запуск

```bash
./broker.sh
docker run -d --name sr29 --network k29net -p 38081:8081 \
  -e SCHEMA_REGISTRY_HOST_NAME=sr29 -e SCHEMA_REGISTRY_LISTENERS=http://0.0.0.0:8081 \
  -e SCHEMA_REGISTRY_KAFKASTORE_BOOTSTRAP_SERVERS=PLAINTEXT://k29ops:9092 confluentinc/cp-schema-registry:8.4.0
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt
CP="target/classes;$(cat cp.txt)"        # на Linux и macOS разделитель ":"
J="java -Dstdout.encoding=UTF-8 -Dorg.slf4j.simpleLogger.defaultLogLevel=off -cp $CP"
$J ops.RetentionLab > s29-retention.txt          # trickle отдельно: $J ops.RetentionLab trickle
$J ops.CompactionLab > s29-compaction.txt
docker exec k29ops bash -c "grep -h 'c-acc' /opt/kafka/logs/log-cleaner.log" > s29-cleaner-log.txt
python -X utf8 sr_lab.py > s29-sr.txt
$J ops.SrWire > s29-sr-wire.txt
$J ops.StreamsLab > s29-streams.txt
$J ops.SpringLab > s29-spring.txt                # longbackoff8 отдельно: $J ops.SpringLab longbackoff8
$J ops.RetryLab > s29-retry.txt
$J ops.ProducerBlock > s29-producer-block.txt    # замораживает k29ops через docker pause и размораживает в конце
./reassign.sh > s29-reassign.txt
# встроенный брокер: classpath из labs/ch29-clients
cd embedded && javac -d out -cp "$(cat ../../ch29-clients/cp.txt)" EmbeddedTx.java && java -cp "out;$(cat ../../ch29-clients/cp.txt)" EmbeddedTx
```

## Что ожидать

- `RetentionLab`: сегмент со старыми метками удаляется через секунды, хотя файл свежий; при записи раз в 2 с записи живут дольше `retention.ms`, пока сегмент получает свежие записи.
- `CompactionLab`: `delete.and.compact` отвергнут, запись без ключа - `InvalidRecordException`; десять версий ключа сводятся к надгробию, надгробие исчезает через `delete.retention.ms`.
- `StreamsLab`: приложение с топиками 6 и 3 партиций запускается без ошибки и соединяет 50 из 120 платежей (документация обещает исключение).
- `SpringLab`: без настроек ядовитая запись доставлена 10 раз и пропущена; пауза повтора 8 с при `max.poll.interval.ms` = 6 с выбивает потребителя из группы, с `ContainerPausingBackOffHandler` - нет.
- Тайминги зависят от машины; соотношения устойчивы.
