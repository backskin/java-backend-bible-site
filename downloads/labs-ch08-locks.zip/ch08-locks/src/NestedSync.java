/**
 * N nested synchronized blocks on different objects, one thread, no contention, no I/O inside.
 * With lightweight locking (JDK 25 default; JDK 21: -XX:+UnlockExperimentalVMOptions -XX:LockingMode=2)
 * the per-thread lock stack holds 8 entries, so from the ninth nested monitor on inflation happens without contention.
 * Run: java -Xlog:monitorinflation=trace NestedSync <depth>   and count lines with type='java.lang.Object'.
 */
public class NestedSync {
    static final Object[] LOCKS = new Object[32];
    static int depthReached;

    static void nest(int i, int depth) {
        if (i == depth) { depthReached = i; return; }
        synchronized (LOCKS[i]) { nest(i + 1, depth); }
    }

    public static void main(String[] args) {
        for (int i = 0; i < LOCKS.length; i++) LOCKS[i] = new Object();
        int depth = Integer.parseInt(args[0]);
        nest(0, depth);
        System.out.println("nested depth " + depthReached);
    }
}
