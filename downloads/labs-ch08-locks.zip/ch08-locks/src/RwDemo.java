import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.StampedLock;

public class RwDemo {

    static double x = 3, y = 4;

    static final class Position {
        private double px = 3, py = 4;
        private final StampedLock sl = new StampedLock();
        void move(double dx, double dy) {
            long stamp = sl.writeLock();
            try { px += dx; py += dy; } finally { sl.unlockWrite(stamp); }
        }
        double distance() {
            long stamp = sl.tryOptimisticRead();
            double cx = px, cy = py;                 // читаем в локальные переменные
            if (!sl.validate(stamp)) {               // писатель вмешался?
                stamp = sl.readLock();
                try { cx = px; cy = py; } finally { sl.unlockRead(stamp); }
            }
            return Math.hypot(cx, cy);
        }
    }

    static volatile double sink;

    static long readMs(int threads, Runnable read) throws Exception {
        Thread[] ts = new Thread[threads];
        long t0 = System.nanoTime();
        for (int t = 0; t < threads; t++) {
            ts[t] = new Thread(() -> { for (int i = 0; i < 3_000_000; i++) read.run(); });
            ts[t].start();
        }
        for (Thread t : ts) t.join();
        return (System.nanoTime() - t0) / 1_000_000;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("--- 1. ограничения ReentrantReadWriteLock");
        ReentrantReadWriteLock rw = new ReentrantReadWriteLock();
        rw.writeLock().lock();
        rw.readLock().lock();                         // понижение: взять чтение, не отпуская запись
        rw.writeLock().unlock();
        System.out.println("понижение write -> read работает, читателей: " + rw.getReadLockCount());
        System.out.println("повышение read -> write: tryLock() = " + rw.writeLock().tryLock());
        rw.readLock().unlock();
        try { rw.readLock().newCondition(); } catch (UnsupportedOperationException e) { System.out.println("readLock().newCondition(): UnsupportedOperationException"); }

        System.out.println("--- 2. StampedLock");
        StampedLock sl = new StampedLock();
        long stamp = sl.tryOptimisticRead();
        System.out.println("validate при отсутствии писателя: " + sl.validate(stamp));
        long w = sl.writeLock(); sl.unlockWrite(w);
        System.out.println("validate после записи:            " + sl.validate(stamp));
        long held = sl.writeLock();
        System.out.println("tryWriteLock() при занятой записи (реентерабельности нет): " + sl.tryWriteLock());
        sl.unlockWrite(held);

        System.out.println("--- 3. восемь потоков по 3 млн чтений одного поля");
        ReentrantLock lock = new ReentrantLock();
        Position pos = new Position();
        Runnable underLock = () -> { lock.lock(); try { sink = Math.hypot(x, y); } finally { lock.unlock(); } };
        Runnable underRw = () -> { rw.readLock().lock(); try { sink = Math.hypot(x, y); } finally { rw.readLock().unlock(); } };
        Runnable optimistic = () -> sink = pos.distance();
        for (int warm = 0; warm < 2; warm++) { readMs(8, underLock); readMs(8, underRw); readMs(8, optimistic); }
        System.out.println("ReentrantLock:               " + readMs(8, underLock) + " мс");
        System.out.println("ReentrantReadWriteLock:      " + readMs(8, underRw) + " мс");
        System.out.println("StampedLock, optimistic read: " + readMs(8, optimistic) + " мс");
    }
}
