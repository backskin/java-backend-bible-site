import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class LockDemo {

    record Job(int id) {}

    /** Очередь задач на ReentrantLock и Condition: обязательная форма lock/try/finally и while вокруг await. */
    static final class JobQueue {
        private final ReentrantLock lock = new ReentrantLock();
        private final Condition notEmpty = lock.newCondition();
        private final Deque<Job> jobs = new ArrayDeque<>();

        Job take() throws InterruptedException {
            lock.lock();
            try {
                while (jobs.isEmpty()) notEmpty.await();      // отпускает lock, паркует, при пробуждении захватывает снова
                return jobs.pollFirst();
            } finally { lock.unlock(); }
        }
        void put(Job j) {
            lock.lock();
            try { jobs.addLast(j); notEmpty.signal(); } finally { lock.unlock(); }
        }
    }

    static long contended(boolean fair) throws Exception {
        ReentrantLock lock = new ReentrantLock(fair);
        long[] counter = new long[1];
        Thread[] ts = new Thread[8];
        long t0 = System.nanoTime();
        for (int t = 0; t < 8; t++) {
            ts[t] = new Thread(() -> { for (int i = 0; i < 200_000; i++) { lock.lock(); try { counter[0]++; } finally { lock.unlock(); } } });
            ts[t].start();
        }
        for (Thread t : ts) t.join();
        return (System.nanoTime() - t0) / 1_000_000;
    }

    public static void main(String[] args) throws Exception {
        ReentrantLock lock = new ReentrantLock();

        System.out.println("--- 1. tryLock с таймаутом и lockInterruptibly");
        Thread holder = new Thread(() -> { lock.lock(); try { Thread.sleep(1500); } catch (InterruptedException ignored) { } finally { lock.unlock(); } });
        holder.start();
        Thread.sleep(100);
        long t0 = System.nanoTime();
        boolean got = lock.tryLock(100, TimeUnit.MILLISECONDS);
        System.out.println("tryLock(100 мс) вернул " + got + " через " + (System.nanoTime() - t0) / 1_000_000 + " мс");
        Thread waiter = new Thread(() -> {
            try { lock.lockInterruptibly(); lock.unlock(); }
            catch (InterruptedException e) { System.out.println("lockInterruptibly: прервано, " + e.getClass().getSimpleName()); }
        });
        waiter.start();
        Thread.sleep(100);
        waiter.interrupt();
        waiter.join();
        holder.join();

        System.out.println("--- 2. await() отпускает блокировку целиком, даже рекурсивно захваченную");
        ReentrantLock rl = new ReentrantLock();
        Condition cond = rl.newCondition();
        Thread awaiter = new Thread(() -> {
            rl.lock(); rl.lock();
            try {
                System.out.println("до await:    getHoldCount=" + rl.getHoldCount());
                cond.awaitUninterruptibly();
                System.out.println("после await: getHoldCount=" + rl.getHoldCount());
            } finally { rl.unlock(); rl.unlock(); }
        });
        awaiter.start();
        Thread.sleep(200);
        boolean mainGot = rl.tryLock();
        System.out.println("пока awaiter ждёт, главный поток взял блокировку: " + mainGot);
        cond.signal();
        rl.unlock();
        awaiter.join();

        System.out.println("--- 3. очередь задач на Condition");
        JobQueue q = new JobQueue();
        Thread consumer = new Thread(() -> { try { for (int i = 0; i < 3; i++) System.out.println("взята задача " + q.take().id()); } catch (InterruptedException ignored) { } });
        consumer.start();
        for (int i = 1; i <= 3; i++) { Thread.sleep(50); q.put(new Job(i)); }
        consumer.join();

        System.out.println("--- 4. цена честной очереди: 8 потоков x 200 000 захватов");
        contended(false);                                    // прогрев
        System.out.println("нечестная: " + contended(false) + " мс");
        System.out.println("честная:   " + contended(true) + " мс");
    }
}
