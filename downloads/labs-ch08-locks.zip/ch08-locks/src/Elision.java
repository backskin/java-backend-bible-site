/** Устранение блокировки: StringBuffer не покидает метод. Сравнить время с -XX:-EliminateLocks. */
public class Elision {
    static int concat(int n) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < n; i++) sb.append('x');
        return sb.length();
    }
    public static void main(String[] args) {
        long sum = 0;
        for (int w = 0; w < 20_000; w++) sum += concat(100);           // прогрев
        long t0 = System.nanoTime();
        for (int r = 0; r < 200_000; r++) sum += concat(100);
        System.out.printf("%s: %.1f нс на вызов concat(100), sum=%d%n",
                String.join(" ", java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments()),
                (System.nanoTime() - t0) / 200_000.0, sum);
    }
}
