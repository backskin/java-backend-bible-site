import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Запуск (JDK 21):
 *   java -Xlog:monitorinflation=trace -Djdk.virtualThreadScheduler.parallelism=1 SyncDemo.java
 * Без -Xlog тоже работает: тогда строк про тяжёлые блокировки не будет.
 */
public class SyncDemo {

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    public static void main(String[] args) throws Exception {
        System.out.println("--- 1. монитор становится тяжёлым (смотрите вывод -Xlog:monitorinflation=trace)");
        Object lock = new Object();
        synchronized (lock) { System.out.println("один поток держит монитор: тяжёлой блокировки нет"); }
        Thread holder = new Thread(() -> { synchronized (lock) { sleep(300); } });
        holder.start();
        Thread.sleep(100);
        System.out.println("главный поток пытается войти, пока монитор занят...");
        synchronized (lock) { System.out.println("вошли после борьбы: монитор раздут"); }
        holder.join();

        System.out.println("--- 2. закрепление (pinning) виртуального потока при parallelism=1");
        System.out.println("synchronized:   второй виртуальный поток стартовал через " + measure(true) + " мс");
        System.out.println("ReentrantLock:  второй виртуальный поток стартовал через " + measure(false) + " мс");
    }

    /** Первый виртуальный поток спит 500 мс внутри блокировки; сколько ждёт старта второй виртуальный поток. */
    static long measure(boolean useSynchronized) throws Exception {
        Object monitor = new Object();
        ReentrantLock rl = new ReentrantLock();
        CountDownLatch firstInside = new CountDownLatch(1);
        long[] secondStarted = new long[1];
        long[] t0 = new long[1];
        Thread first = Thread.ofVirtual().start(() -> {
            if (useSynchronized) {
                synchronized (monitor) { firstInside.countDown(); sleep(500); }
            } else {
                rl.lock();
                try { firstInside.countDown(); sleep(500); } finally { rl.unlock(); }
            }
        });
        firstInside.await();
        t0[0] = System.nanoTime();
        Thread second = Thread.ofVirtual().start(() -> secondStarted[0] = System.nanoTime());
        first.join(); second.join();
        return Duration.ofNanos(secondStarted[0] - t0[0]).toMillis();
    }
}
