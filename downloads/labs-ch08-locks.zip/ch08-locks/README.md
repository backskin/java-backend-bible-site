# Блокировки: раздувание монитора, ReentrantLock, ReadWriteLock, устранение блокировки JIT

Стенд к главе 08, раздел 4. Программы в `src/`: `SyncDemo` (раздувание монитора под `-Xlog:monitorinflation=trace`, в том числе при одном носителе виртуальных потоков), `NestedSync` (вложенные `synchronized` и стек блокировок на JDK 25), `LockDemo` (`tryLock` с таймаутом и `lockInterruptibly`, `await()` отпускает рекурсивно захваченную блокировку, очередь задач на `Condition`, стоимость честной очереди), `RwDemo` (ограничения `ReentrantReadWriteLock`, `StampedLock`, восемь потоков по 3 млн чтений под `ReentrantLock`, `ReentrantReadWriteLock` и оптимистичным чтением `StampedLock`), `Elision` (`StringBuffer` внутри метода с `-XX:-EliminateLocks` и `-XX:-DoEscapeAnalysis`). Выводы автора - `s04-locks.txt`, `s04-nested-lockstack.txt`.

## Что нужно

- Temurin JDK 21.0.10 и 25.0.5 в `~/.jdks` (пути в `run.sh`).

## Запуск

```bash
sh run.sh
```

Скрипт печатает значение флага `LockingMode` на каждом JDK и прогоняет все программы с нужными флагами. По одной: `java -Dstdout.encoding=UTF-8 src/LockDemo.java`. В IDEA на каждую программу есть конфигурация `java src/<Класс>.java`.

## Что должно получиться

На JDK 21 `LockingMode = 1` (старые блокировки на стеке), на 25 - `2` (легковесные); на 21 второй виртуальный поток в `synchronized` при одном носителе стартует через 500 мс, на 25 сразу; честная очередь `ReentrantLock` на 8 потоках в сотни раз медленнее нечестной. Времена зависят от машины.
