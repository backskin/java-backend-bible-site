#!/bin/sh
# Опыты раздела 4 главы 8 на JDK 21 и 25
J21=~/.jdks/temurin-21.0.10/bin/java; J25=~/.jdks/jdk-25.0.5+8/bin/java
O="-Dstdout.encoding=UTF-8"
for J in $J21 $J25; do
  echo "=== $($J -version 2>&1 | head -1)"
  $J -XX:+UnlockExperimentalVMOptions -XX:+PrintFlagsFinal -version 2>/dev/null | grep -E " LockingMode | UseObjectMonitorTable "
  $J $O -Xlog:monitorinflation=trace -Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=1 src/SyncDemo.java 2>&1 | grep -v "^\[" ; \
  $J $O -Xlog:monitorinflation=trace src/SyncDemo.java 2>&1 | grep "java.lang.Object'" | head -2
  $J $O src/LockDemo.java
  $J $O src/RwDemo.java
  $J $O src/Elision.java
  $J $O -XX:-EliminateLocks src/Elision.java
  $J $O -XX:-DoEscapeAnalysis src/Elision.java
done > s04-locks.txt 2>&1
