"""Глава 52, 2.8: есть ли в Loki пропуски и дубли строк pay-gateway за интервал.

    python check_seq.py <начало, unix с> <конец, unix с>     (Loki на localhost:3100 через kubectl port-forward)

Строки приложения несут поле seq, растущее на единицу; скрипт выбирает все строки
сервиса за интервал постранично и считает число строк, различных seq, дублей и дыр.
"""
import json
import sys
import urllib.parse
import urllib.request

start, end = int(sys.argv[1]) * 10**9, int(sys.argv[2]) * 10**9
seqs, lines, cursor = [], 0, start
while cursor < end:
    q = urllib.parse.urlencode({"query": '{service="pay-gateway"}', "start": cursor, "end": end,
                                "limit": 5000, "direction": "forward"})
    data = json.load(urllib.request.urlopen(f"http://localhost:3100/loki/api/v1/query_range?{q}"))
    values = [v for s in data["data"]["result"] for v in s["values"]]
    if not values:
        break
    values.sort(key=lambda v: int(v[0]))
    for ts, line in values:
        lines += 1
        seqs.append(json.loads(line)["seq"])
    cursor = int(values[-1][0]) + 1
s = sorted(set(seqs))
gaps = [(a, b) for a, b in zip(s, s[1:]) if b != a + 1]
print(f"строк в Loki: {lines}, различных seq: {len(s)}, дублей: {lines - len(s)}, "
      f"seq от {s[0] if s else '-'} до {s[-1] if s else '-'}, дыр в нумерации: {len(gaps)} {gaps[:5]}")
