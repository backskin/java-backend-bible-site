#!/bin/bash
# Глава 52, 2.8: что теряется и что дублируется при падении звеньев цепочки.
#   1) SIGKILL потребителя vector-loki посреди потока: Kafka отдаст неподтверждённое заново
#   2) SIGKILL агента vector-agent на узле приложения: агент читает файлы подов и хранит позицию в контрольной точке
#   3) одна и та же строка с одной и той же отметкой времени дважды через push API Loki
# Запуск: bash crash.sh > s52-crash.txt   (нужен kubectl port-forward svc/loki 3100:3100 в фоне)
export KUBECONFIG="$(cygpath -w /c/Users/backskin/java-backend-bible/tmp/kind-bin/kubeconfig)"
export MSYS_NO_PATHCONV=1
kill9() {   # $1 — метка app пода в пространстве logs, $2 — узел (для агента)
  local pod node pid
  if [ -n "$2" ]; then pod=$(kubectl -n logs get pod -l app=$1 --field-selector spec.nodeName=$2 -o jsonpath='{.items[0].metadata.name}')
  else pod=$(kubectl -n logs get pod -l app=$1 -o jsonpath='{.items[0].metadata.name}'); fi
  node=$(kubectl -n logs get pod $pod -o jsonpath='{.spec.nodeName}')
  for p in $(docker exec $node pgrep -f 'vector --config'); do
    docker exec $node sh -c "tr '\0' '\n' < /proc/$p/environ | grep -q ^HOSTNAME=$pod\$" && pid=$p
  done
  docker exec $node kill -9 $pid && echo "  SIGKILL $pod (pid $pid на $node)"
}
APP_NODE=$(kubectl -n logs get pod -l app=pay-gateway -o jsonpath='{.items[0].spec.nodeName}')
for what in ${WHAT:-"vector-loki" "vector-agent $APP_NODE"}; do
  t0=$(date +%s); echo "=== падение ${what%% *}"
  sleep 20; kill9 $what; sleep 60
  python -I -X utf8 check_seq.py $t0 $(( $(date +%s) - 15 )) | sed 's/^/  /'
done
echo "=== одна строка дважды с одинаковой отметкой времени (push API Loki)"
ts=$(( $(date +%s) * 1000000000 ))
body="{\"streams\":[{\"stream\":{\"service\":\"dup-test\"},\"values\":[[\"$ts\",\"{\\\"seq\\\":1,\\\"msg\\\":\\\"payment accepted\\\"}\"]]}]}"
for i in 1 2; do curl -s -o /dev/null -w "  push $i: HTTP %{http_code}\n" -H 'Content-Type: application/json' -X POST --data "$body" http://localhost:3100/loki/api/v1/push; done
ts2=$(( ts + 1000000 ))
body2="{\"streams\":[{\"stream\":{\"service\":\"dup-test\"},\"values\":[[\"$ts2\",\"{\\\"seq\\\":1,\\\"msg\\\":\\\"payment accepted\\\"}\"]]}]}"
curl -s -o /dev/null -w "  push 3 (та же строка, отметка на 1 мс позже): HTTP %{http_code}\n" -H 'Content-Type: application/json' -X POST --data "$body2" http://localhost:3100/loki/api/v1/push
sleep 3
n=$(curl -s -G http://localhost:3100/loki/api/v1/query_range --data-urlencode 'query={service="dup-test"}' --data-urlencode "start=$(( ts - 10000000000 ))" --data-urlencode "end=$(( ts + 10000000000 ))" | python -I -c "import json,sys; d=json.load(sys.stdin); print(sum(len(s['values']) for s in d['data']['result']))")
echo "  строк dup-test в Loki: $n"
