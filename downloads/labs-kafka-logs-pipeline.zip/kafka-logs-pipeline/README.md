# Сбор логов через Kafka: опыты к главе 52, 2.8 (и запросы LogQL к главе 29, 16.12)

Проверено 2026-10-30: kind (3 узла), Kafka 4.3.1 (`labs/kafka-cluster3`), Vector 0.49.0, Loki 3.5.3.

Цепочка: под `pay-gateway` пишет JSON в stdout (поле `seq` растёт на единицу) → агент Vector (DaemonSet, источник `kubernetes_logs`, метки `app in (pay-gateway,kc)`) → топики `logs.logs` (6 партиций) и `logs.kafka3` (3) → Vector-потребитель (группа `vector-loki`) → Loki.

```bash
kafka-topics.sh --create --topic logs.logs --partitions 6 --replication-factor 3    # и logs.kafka3 с 3 партициями
kubectl apply -f pipeline.yaml
kubectl -n logs port-forward svc/loki 3100:3100 &
bash outage.sh > s52-outage.txt     # Loki заморожен (SIGSTOP) на 120 с, лаг группы и проверка нумерации
bash crash.sh  > s52-crash.txt      # kill -9 потребителя и агента, дубль через push API Loki
python check_seq.py <начало> <конец> # пропуски и дубли seq в Loki за интервал
```

Что важно в `pipeline.yaml`: у потребителя шаг `strip` удаляет поля, которые дописывает источник `kafka` (`offset`, `partition`, `topic`…), иначе повторно отправленная агентом строка приходит в Loki с другим `offset` и не распознаётся как дубль.

Префикс `logs.` должен принадлежать только топикам логов: потребитель подписан по регулярке `^logs\..+` и пытается разобрать как JSON всё, что под неё попало.
