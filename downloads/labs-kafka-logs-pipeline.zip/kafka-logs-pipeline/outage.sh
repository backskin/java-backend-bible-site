#!/bin/bash
# Глава 52, 2.8: хранилище логов недоступно 120 с; растёт ли лаг потребителя, теряются ли строки после возврата.
# Loki «зависает» без потери своих данных: процесс замораживают (SIGSTOP) на узле kind.
# Убрать селектор у сервиса недостаточно: открытые соединения потребителя к поду продолжают работать через conntrack.
# Запуск: bash outage.sh > s52-outage.txt   (нужен kubectl port-forward svc/loki 3100:3100 в фоне)
export KUBECONFIG="$(cygpath -w /c/Users/backskin/java-backend-bible/tmp/kind-bin/kubeconfig)"
export MSYS_NO_PATHCONV=1
KT=../kafka-cluster3/kt.sh
lag() { $KT kc-0 kafka-consumer-groups.sh --bootstrap-server kc-0.kc.kafka3.svc.cluster.local:9092 --describe --group vector-loki 2>/dev/null \
        | awk '$2 ~ /^logs\./ && $6 ~ /^[0-9]+$/ {s[$2]+=$6} END{printf "logs.logs %d, logs.kafka3 %d", s["logs.logs"], s["logs.kafka3"]}'; }
t0=$(date +%s)
echo "=== хранилище логов недоступно 120 с; лаг группы vector-loki по топикам"
sleep 30; echo "  t=$(( $(date +%s) - t0 )) с, норма: $(lag)"
NODE=$(kubectl -n logs get pod -l app=loki -o jsonpath='{.items[0].spec.nodeName}'); PID=$(docker exec $NODE pgrep -f 'loki -config.file')
docker exec $NODE kill -STOP $PID
t1=$(date +%s); echo "  t=$(( t1 - t0 )) с: процесс Loki заморожен"
for i in 1 2 3 4 5 6 7 8; do sleep 15; echo "  t=$(( $(date +%s) - t0 )) с, хранилище недоступно: $(lag)"; done
docker exec $NODE kill -CONT $PID
t2=$(date +%s); echo "  t=$(( t2 - t0 )) с: хранилище вернулось"
while :; do sleep 5; l=$(lag); echo "  t=$(( $(date +%s) - t0 )) с: $l"; case "$l" in "logs.logs "[0-9]","*|"logs.logs "[0-9][0-9]","*) break;; esac; [ $(( $(date +%s) - t2 )) -gt 300 ] && break; done
echo "  догон занял около $(( $(date +%s) - t2 )) с"
sleep 20
python -I -X utf8 check_seq.py $t0 $(( $(date +%s) - 15 ))
kubectl -n logs logs deploy/vector-loki --since=6m 2>&1 | grep -E 'ERROR|WARN' | sed -E 's/^[0-9T:.-]+Z //' | cut -c1-200 | sort | uniq -c | sort -rn | head -4 | sed 's/^/  журнал vector-loki: /'
