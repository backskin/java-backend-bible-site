import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/** Пять безопасных способов передать потоку-читателю снимок тарифов. */
public class Publication {

    /** Неизменяемый снимок: final-поля и копия отображения. */
    record Tariffs(Map<String, Integer> commissionBps, int timeoutMs) {
        Tariffs { commissionBps = Map.copyOf(commissionBps); }
    }

    static final class FlagConfig {
        private Map<String, String> values;          // обычное поле
        private volatile boolean loaded;
        void load(Map<String, String> src) { values = Map.copyOf(src); loaded = true; }   // данные, потом флаг
        String get(String key) { return loaded ? values.get(key) : null; }                  // флаг, потом данные
    }

    static final class Holder { static final Tariffs INSTANCE = new Tariffs(Map.of("RUB", 35), 3000); }

    static volatile Tariffs current;
    static final AtomicReference<Tariffs> ref = new AtomicReference<>();
    static final ConcurrentHashMap<String, Tariffs> registry = new ConcurrentHashMap<>();

    public static void main(String[] args) throws Exception {
        FlagConfig flag = new FlagConfig();
        Thread reader = new Thread(() -> {
            String v;
            while ((v = flag.get("timeout")) == null) Thread.onSpinWait();
            System.out.println("1. volatile-флаг после данных: timeout=" + v);
            Tariffs t;
            while ((t = current) == null) Thread.onSpinWait();
            System.out.println("2. volatile-ссылка на снимок: RUB=" + t.commissionBps().get("RUB") + " б. п.");
            while ((t = ref.get()) == null) Thread.onSpinWait();
            System.out.println("3. AtomicReference: timeout=" + t.timeoutMs());
            System.out.println("4. статический держатель: RUB=" + Holder.INSTANCE.commissionBps().get("RUB") + " б. п.");
            while ((t = registry.get("main")) == null) Thread.onSpinWait();
            System.out.println("5. ConcurrentHashMap: timeout=" + t.timeoutMs());
        });
        reader.start();
        flag.load(Map.of("timeout", "3000"));
        current = new Tariffs(Map.of("RUB", 35), 3000);
        ref.set(new Tariffs(Map.of("RUB", 35), 3000));
        registry.put("main", new Tariffs(Map.of("RUB", 35), 3000));
        reader.join();
    }
}
