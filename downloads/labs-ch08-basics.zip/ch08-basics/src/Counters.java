import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.IntSupplier;

/** Четыре потока по миллиону раз увеличивают счётчик шестью способами. */
public class Counters {

    static final int THREADS = 4, PER_THREAD = 1_000_000;
    static int plain;
    static volatile int vol;
    static final AtomicInteger atomic = new AtomicInteger();
    static final LongAdder adder = new LongAdder();
    static int synced;
    static final Object MONITOR = new Object();
    static int locked;
    static final ReentrantLock LOCK = new ReentrantLock();

    static void run(String name, Runnable inc, IntSupplier result) throws Exception {
        Thread[] ts = new Thread[THREADS];
        long t0 = System.nanoTime();
        for (int t = 0; t < THREADS; t++) {
            ts[t] = new Thread(() -> { for (int i = 0; i < PER_THREAD; i++) inc.run(); });
            ts[t].start();
        }
        for (Thread t : ts) t.join();
        long ms = (System.nanoTime() - t0) / 1_000_000;
        System.out.printf("%-30s %,10d из %,d  %4d мс%n", name, result.getAsInt(), THREADS * PER_THREAD, ms);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version") + ", ядер " + Runtime.getRuntime().availableProcessors());
        for (int round = 1; round <= 3; round++) {
            System.out.println("--- прогон " + round);
            plain = 0; vol = 0; atomic.set(0); adder.reset(); synced = 0; locked = 0;
            run("обычное поле i++", () -> plain++, () -> plain);
            run("volatile i++", () -> vol++, () -> vol);
            run("AtomicInteger.incrementAndGet", atomic::incrementAndGet, atomic::get);
            run("LongAdder.increment", adder::increment, adder::intValue);
            run("synchronized i++", () -> { synchronized (MONITOR) { synced++; } }, () -> synced);
            run("ReentrantLock i++", () -> { LOCK.lock(); try { locked++; } finally { LOCK.unlock(); } }, () -> locked);
        }
    }
}
