import java.util.function.BooleanSupplier;

/**
 * Флаг остановки воркера: обычное поле, volatile, обычное поле с разными вызовами в цикле,
 * и видимость обычного поля после join().
 */
public class StopFlag {

    static boolean plain1, plain2, plain3, plain4;
    static volatile boolean vol;
    static int result;
    static final Object LOCK = new Object();

    static void lockedNoop() { synchronized (LOCK) { } }

    static void check(String name, BooleanSupplier stopped, Runnable raise, Runnable body) throws Exception {
        Thread worker = new Thread(() -> {
            long n = 0;
            while (!stopped.getAsBoolean()) { n++; body.run(); }
        });
        worker.setDaemon(true);
        worker.start();
        Thread.sleep(1000);
        raise.run();
        worker.join(3000);
        System.out.printf("%-44s воркер жив через 3 с: %s%n", name, worker.isAlive());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version") + " " + String.join(" ",
                java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments()));
        check("1. обычное поле, пустой цикл", () -> plain1, () -> plain1 = true, () -> { });
        check("2. volatile-поле", () -> vol, () -> vol = true, () -> { });
        check("3. обычное поле + Thread.onSpinWait()", () -> plain2, () -> plain2 = true, Thread::onSpinWait);
        check("4. обычное поле + пустой synchronized", () -> plain3, () -> plain3 = true, StopFlag::lockedNoop);
        check("5. обычное поле + Thread.yield()", () -> plain4, () -> plain4 = true, Thread::yield);
        Thread writer = new Thread(() -> result = 42);
        writer.start();
        writer.join();
        System.out.println("6. обычное поле после join(): " + result);
    }
}
