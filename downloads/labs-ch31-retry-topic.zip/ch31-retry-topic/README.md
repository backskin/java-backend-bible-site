# Блокирующий и неблокирующий повтор и топик недоставленных сообщений в Spring Kafka за пять минут

Шаблон к главе 31, раздел 8.1. Один и тот же сценарий - пять сообщений, второе дважды падает - прогоняется двумя слушателями: с `DefaultErrorHandler` и `FixedBackOff` (блокирующий повтор) и с `@RetryableTopic` (неблокирующий, через retry-топик и DLT). Программа печатает порядок завершения и список созданных топиков. Третий слушатель повторяет запись с экспоненциальной задержкой 500 мс x3 (упражнение 8 главы): видно, как создаются `-retry-500`, `-retry-1500`, `-retry-4500` и `-dlt`. Затем (раздел 8.2) она шлет 20 сообщений, седьмое с суммой строкой `abc`, слушателю с `DefaultErrorHandler` и `DeadLetterPublishingRecoverer`, и печатает, что попало в `orders.poison-dlt` и с какими заголовками.

Класс `ClaimCheckLab` (раздел 11.1) отправляет сообщение 2 МБ с настройками по умолчанию, затем с `max.request.size` 3 МБ только у производителя и, наконец, через Claim Check: тело в хранилище (локальная папка), в Kafka ссылка и хеш. Вывод автора - `s31-claim-check.txt`.

Класс `SplitReplicaLab` (разделы 11.3 и 12.2): реестр из 60 строк по трем партициям и сборщик частей, в том числе с потерянной частью, и справочник из 200 записей, реплицированный событиями, где 7 событий потеряны и их находит только сверка. Вывод автора - `s31-split-replica.txt`.

## Что нужно

- Docker с Compose, свободный порт 59093.
- JDK 21 и Maven; зависимости Spring Boot 4.1.1 и Spring Kafka 4.1.1 скачаются сами.

## Запуск

```bash
docker compose up -d
mvn -q -DskipTests package
java -Dstdout.encoding=UTF-8 -jar target/ch31-retry-topic-1.jar
```

Через 7–8 секунд программа печатает строки вида `неблокирующий 6464 мс m2 из orders.nonblocking-retry: ошибка №2`, итоговый порядок для обоих вариантов и число партиций у топиков, после чего завершается сама.

Класс `ClaimCheckLab` после сборки:

```bash
java -cp target/ch31-retry-topic-1.jar -Dloader.main=dev.team.retry.ClaimCheckLab org.springframework.boot.loader.launch.PropertiesLauncher
```

Так же запускается `SplitReplicaLab` (`-Dloader.main=dev.team.retry.SplitReplicaLab`).

## Что должно получиться

Результаты автора - в `s31-retry-topic.txt`: блокирующий вариант сохраняет порядок `[m1, m2, m3, m4, m5]`, но `m3`–`m5` ждут, пока `m2` повторится дважды; неблокирующий отдает `m2` в топик `orders.nonblocking-retry` и завершает его последним, `[m1, m3, m4, m5, m2]`. Retry-топик при фиксированной задержке один (`-retry`, без суффикса задержки), у него и у `-dlt` по одной партиции; `autoCreateTopics = "true"` создает с одной партицией и основной топик, тогда как `orders.blocking` подписчик создал с тремя, значением по умолчанию брокера (`KAFKA_NUM_PARTITIONS: 3` в compose). В опыте с ядовитым сообщением обработано 19 из 20, сообщение 7 после трех попыток лежит в `orders.poison-dlt` в той же партиции, что и в исходном топике, с заголовками `kafka_dlt-original-*` и `kafka_dlt-exception-cause-fqcn = java.lang.NumberFormatException`.

## Остановка

```bash
docker compose down -v
```
