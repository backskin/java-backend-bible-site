package dev.team.retry;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.BackOff;
import org.springframework.kafka.annotation.DltHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.util.backoff.FixedBackOff;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Опыт 8.1 главы 31: порядок обработки пяти сообщений при блокирующем повторе (DefaultErrorHandler)
 * и неблокирующем (@RetryableTopic). Сообщение m2 падает первые два раза в каждом варианте.
 * Опыт 8.2: «ядовитое» сообщение (сумма "abc") среди двадцати; DefaultErrorHandler с DeadLetterPublishingRecoverer
 * делает три попытки и отправляет его в топик недоставленных сообщений с заголовками.
 * Запуск: docker compose up -d; mvn -q spring-boot:run
 */
@SpringBootApplication
public class RetryApp {

    static final long T0 = System.currentTimeMillis();
    static final Map<String, AtomicInteger> FAILS = new ConcurrentHashMap<>();
    static final List<String> BLOCKING = new CopyOnWriteArrayList<>();
    static final List<String> NONBLOCKING = new CopyOnWriteArrayList<>();

    public static void main(String[] args) { SpringApplication.run(RetryApp.class, args); }

    static void handle(String variant, ConsumerRecord<String, String> rec, List<String> done) {
        String m = rec.value();
        long t = System.currentTimeMillis() - T0;
        if (m.equals("m2") && FAILS.computeIfAbsent(variant, k -> new AtomicInteger()).incrementAndGet() <= 2) {
            System.out.printf("%-12s %5d мс  %s из %s: ошибка №%d%n", variant, t, m, rec.topic(), FAILS.get(variant).get());
            throw new IllegalStateException("временный сбой");
        }
        done.add(m);
        System.out.printf("%-12s %5d мс  %s из %s: обработано%n", variant, t, m, rec.topic());
    }

    // Блокирующий повтор: DefaultErrorHandler с FixedBackOff(200 мс, 2 повтора), партиция ждёт.
    // Фабрика вынесена в отдельную конфигурацию: слушатель в том же бине дал бы циклическую зависимость.
    @org.springframework.context.annotation.Configuration
    static class Factories {
        @Bean
        ConcurrentKafkaListenerContainerFactory<String, String> blockingFactory(ConsumerFactory<String, String> cf) {
            var f = new ConcurrentKafkaListenerContainerFactory<String, String>();
            f.setConsumerFactory(cf);
            f.setCommonErrorHandler(new DefaultErrorHandler(new FixedBackOff(200L, 2L)));
            return f;
        }

        // 8.2: три попытки (FixedBackOff 200 мс, 2 повтора), затем публикация в DLT с заголовками причины
        @Bean
        ConcurrentKafkaListenerContainerFactory<String, String> poisonFactory(ConsumerFactory<String, String> cf, KafkaTemplate<String, String> template) {
            var f = new ConcurrentKafkaListenerContainerFactory<String, String>();
            f.setConsumerFactory(cf);
            f.setCommonErrorHandler(new DefaultErrorHandler(new DeadLetterPublishingRecoverer(template), new FixedBackOff(200L, 2L)));
            return f;
        }
    }

    static final List<String> POISON_DONE = new CopyOnWriteArrayList<>();
    static final Map<String, AtomicInteger> POISON_ATTEMPTS = new ConcurrentHashMap<>();

    @KafkaListener(topics = "orders.poison", groupId = "poison", containerFactory = "poisonFactory")
    public void poison(ConsumerRecord<String, String> rec) {
        String id = rec.value().replaceAll(".*\"id\":(\\d+).*", "$1");
        POISON_ATTEMPTS.computeIfAbsent(id, k -> new AtomicInteger()).incrementAndGet();
        long amount = Long.parseLong(rec.value().replaceAll(".*\"amount\":\"?([^\",}]*)\"?.*", "$1"));   // "abc" -> NumberFormatException
        POISON_DONE.add(id + ":" + amount);
    }

    @KafkaListener(topics = "orders.blocking", groupId = "blocking", containerFactory = "blockingFactory")
    public void blocking(ConsumerRecord<String, String> rec) { handle("блокирующий", rec, BLOCKING); }

    // Неблокирующий повтор: retry-топики с фиксированной задержкой 1000 мс, 3 попытки всего, затем DLT
    @RetryableTopic(attempts = "3", backOff = @BackOff(delay = 1000), autoCreateTopics = "true")
    @KafkaListener(topics = "orders.nonblocking", groupId = "nonblocking")
    public void nonBlocking(ConsumerRecord<String, String> rec) { handle("неблокирующий", rec, NONBLOCKING); }

    // Упражнение 8 главы 31: экспоненциальная задержка 500 мс x3, четыре попытки, ошибка всегда; какие топики появятся
    @RetryableTopic(attempts = "4", backOff = @BackOff(delay = 500, multiplier = 3.0), autoCreateTopics = "true")
    @KafkaListener(topics = "orders.exp", groupId = "exp")
    public void exponential(ConsumerRecord<String, String> rec) {
        System.out.printf("экспоненциальный %5d мс  %s из %s%n", System.currentTimeMillis() - T0, rec.value(), rec.topic());
        throw new IllegalStateException("всегда сбой");
    }

    @DltHandler
    public void dlt(ConsumerRecord<String, String> rec) {
        System.out.printf("DLT: %s из %s%n", rec.value(), rec.topic());
    }

    @Bean
    CommandLineRunner run(KafkaTemplate<String, String> template, KafkaAdmin admin) {
        return args -> {
            try (AdminClient ac = AdminClient.create(admin.getConfigurationProperties())) {
                ac.createTopics(List.of(new NewTopic("orders.blocking", 1, (short) 1), new NewTopic("orders.nonblocking", 1, (short) 1))).all().get();
            } catch (Exception ignored) { }
            Thread.sleep(3000);   // дать контейнерам подписаться
            for (String m : List.of("m1", "m2", "m3", "m4", "m5")) {
                template.send("orders.blocking", "k", m).get();
                template.send("orders.nonblocking", "k", m).get();
            }
            template.send("orders.exp", "k", "e1").get();
            Thread.sleep(9000);
            System.out.println("блокирующий, порядок завершения:    " + BLOCKING);
            System.out.println("неблокирующий, порядок завершения:  " + NONBLOCKING);
            try (AdminClient ac = AdminClient.create(admin.getConfigurationProperties())) {
                var names = ac.listTopics().names().get().stream().filter(n -> n.startsWith("orders.")).sorted().toList();
                var desc = ac.describeTopics(names).allTopicNames().get();
                for (String n : names) System.out.println("топик " + n + ": партиций " + desc.get(n).partitions().size());
            }
            // 8.2: двадцать сообщений, в седьмом сумма строкой "abc"
            long p0 = System.currentTimeMillis();
            for (int i = 1; i <= 20; i++)
                template.send("orders.poison", "k", i == 7 ? "{\"id\":7,\"amount\":\"abc\"}" : "{\"id\":" + i + ",\"amount\":" + i * 100 + "}").get();
            while (POISON_DONE.size() < 19 && System.currentTimeMillis() - p0 < 20000) Thread.sleep(100);
            Thread.sleep(1000);
            System.out.println("8.2: обработано " + POISON_DONE.size() + " из 20; попыток на сообщении 7: " + POISON_ATTEMPTS.get("7")
                    + "; время " + (System.currentTimeMillis() - p0) + " мс");
            var props = new java.util.HashMap<>(admin.getConfigurationProperties());
            props.put("group.id", "dlt-reader"); props.put("auto.offset.reset", "earliest");
            props.put("key.deserializer", org.apache.kafka.common.serialization.StringDeserializer.class);
            props.put("value.deserializer", org.apache.kafka.common.serialization.StringDeserializer.class);
            try (AdminClient ac = AdminClient.create(admin.getConfigurationProperties());
                 var consumer = new org.apache.kafka.clients.consumer.KafkaConsumer<String, String>(props)) {
                var dlt = ac.listTopics().names().get().stream().filter(n -> n.startsWith("orders.poison") && !n.equals("orders.poison")).sorted().toList();
                System.out.println("8.2: топики недоставленных: " + dlt);
                consumer.subscribe(dlt);
                for (var r : consumer.poll(java.time.Duration.ofSeconds(5))) {
                    System.out.println("8.2: в " + r.topic() + " партиция " + r.partition() + ": тело " + r.value());
                    for (Header h : r.headers())
                        if (!h.key().endsWith("stacktrace"))
                            System.out.println("      " + h.key() + " = " + headerText(h));
                        else System.out.println("      " + h.key() + " = <стек, " + h.value().length + " байт>");
                }
            }
            System.exit(0);
        };
    }

    /** Числовые заголовки DLT (партиция, смещение, метка времени) записаны двоичными int и long. */
    static String headerText(Header h) {
        String k = h.key();
        boolean numeric = k.endsWith("partition") || k.endsWith("offset") || k.endsWith("timestamp");
        if (numeric && h.value().length == 4) return String.valueOf(java.nio.ByteBuffer.wrap(h.value()).getInt());
        if (numeric && h.value().length == 8) return String.valueOf(java.nio.ByteBuffer.wrap(h.value()).getLong());
        return new String(h.value(), StandardCharsets.UTF_8);
    }

    static String header(ConsumerRecord<?, ?> rec, String name) {
        Header h = rec.headers().lastHeader(name);
        return h == null ? "-" : new String(h.value(), StandardCharsets.UTF_8);
    }
}
