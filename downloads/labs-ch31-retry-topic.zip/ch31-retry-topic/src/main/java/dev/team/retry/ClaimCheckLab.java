package dev.team.retry;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;

/**
 * Опыт 11.1 главы 31: сообщение 2 МБ в Kafka с настройками по умолчанию, то же после увеличения
 * max.request.size только на производителе и передача через Claim Check (тело в хранилище, в сообщении ссылка и хеш).
 * Хранилище здесь - локальная папка: для опыта важна не S3, а размер того, что уходит в брокер.
 * Запуск: docker compose up -d; mvn -q -DskipTests package;
 * java -cp target/ch31-retry-topic-1.jar -Dloader.main=dev.team.retry.ClaimCheckLab org.springframework.boot.loader.launch.PropertiesLauncher
 */
public class ClaimCheckLab {

    static KafkaProducer<String, byte[]> producer(Map<String, Object> extra) {
        var props = new java.util.HashMap<String, Object>(Map.of(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:59093",
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class));
        props.putAll(extra);
        return new KafkaProducer<>(props);
    }

    static String send(Map<String, Object> extra, byte[] body) {
        try (var p = producer(extra)) {
            p.send(new ProducerRecord<>("statements", "acc-1", body)).get();
            return "принято брокером";
        } catch (Exception e) {
            Throwable c = e.getCause() != null ? e.getCause() : e;
            return c.getClass().getSimpleName() + ": " + c.getMessage();
        }
    }

    public static void main(String[] args) throws Exception {
        byte[] body = new byte[2_000_000];
        java.util.Arrays.fill(body, (byte) 'x');
        System.out.println("=== 11.1 сообщение 2 МБ в Kafka 4.3.1 с настройками по умолчанию");
        System.out.println("  производитель по умолчанию: " + send(Map.of(), body));
        System.out.println("  max.request.size = 3 МБ только у производителя: " + send(Map.of(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, 3_000_000), body));

        Path store = Files.createTempDirectory("claim-check");
        String key = "events/stmt-1.json";
        Path obj = store.resolve(key);
        Files.createDirectories(obj.getParent());
        Files.write(obj, body);
        String sha = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(body));
        byte[] ticket = ("{\"uri\":\"store://" + key + "\",\"size\":" + body.length + ",\"sha256\":\"" + sha + "\"}").getBytes(StandardCharsets.UTF_8);
        String r = send(Map.of(), ticket);
        System.out.printf("  Claim Check: тело %d байт в хранилище, в Kafka сообщение %d байт со ссылкой и хешем: %s%n", body.length, ticket.length, r);
    }
}
