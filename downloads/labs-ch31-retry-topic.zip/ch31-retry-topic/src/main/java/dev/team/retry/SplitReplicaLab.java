package dev.team.retry;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;

/**
 * Опыты 11.3 и 12.2 главы 31 на Kafka 4.3.1.
 * 11.3: реестр из 60 строк разбит на части (Splitter) с номером и общим числом, части разложены по трём партициям;
 * сборщик (Aggregator) читает их одним потребителем и считает уникальные части. Потом то же с потерянной частью 13.
 * 12.2: справочник из 200 записей реплицируется событиями «ключ, значение» в локальную копию; затем 7 изменений
 * в источнике не публикуются (события «потерялись»), и только сверка по контрольной сумме и по ключам их находит.
 * Запуск: docker compose up -d; mvn -q -DskipTests package;
 * java -cp target/ch31-retry-topic-1.jar -Dloader.main=dev.team.retry.SplitReplicaLab org.springframework.boot.loader.launch.PropertiesLauncher
 */
public class SplitReplicaLab {

    static final String BOOTSTRAP = "localhost:59093";

    static KafkaProducer<String, String> producer() {
        return new KafkaProducer<>(Map.of(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.LINGER_MS_CONFIG, 20));
    }

    static List<ConsumerRecord<String, String>> readAll(String topic, int expected) {
        try (var c = new KafkaConsumer<String, String>(Map.of(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP,
                ConsumerConfig.GROUP_ID_CONFIG, topic + "-" + UUID.randomUUID(),
                ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest",
                ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 7,                     // маленькие порции: партиции чередуются
                ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class,
                ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class))) {
            c.subscribe(List.of(topic));
            List<ConsumerRecord<String, String>> out = new ArrayList<>();
            long t0 = System.currentTimeMillis();
            while (out.size() < expected && System.currentTimeMillis() - t0 < 15000)
                c.poll(Duration.ofMillis(300)).forEach(out::add);
            return out;
        }
    }

    static void createTopic(String name, int partitions) throws Exception {
        try (var ac = AdminClient.create(Map.of("bootstrap.servers", BOOTSTRAP))) {
            ac.createTopics(List.of(new NewTopic(name, partitions, (short) 1))).all().get();
        }
    }

    static void splitter() throws Exception {
        System.out.println("=== 11.3 реестр из 60 строк: части по трём партициям, сборщик считает уникальные части");
        for (int lost : new int[]{0, 13}) {
            String topic = "registry.lines." + UUID.randomUUID().toString().substring(0, 8);
            createTopic(topic, 3);
            try (var p = producer()) {
                for (int i = 1; i <= 60; i++) {
                    if (i == lost) continue;                                       // часть «потерялась» по дороге
                    // ключ = номер строки: части расходятся по партициям, как при параллельной разбивке
                    p.send(new ProducerRecord<>(topic, "line-" + i, "{\"registry\":\"R-1\",\"seq\":" + i + ",\"total\":60}"));
                }
            }
            List<ConsumerRecord<String, String>> got = readAll(topic, lost == 0 ? 60 : 59);
            Set<Integer> seen = new TreeSet<>();
            int inversions = 0, prev = 0;
            for (var r : got) {
                int seq = Integer.parseInt(r.value().replaceAll(".*\"seq\":(\\d+).*", "$1"));
                if (seq < prev) inversions++;
                prev = seq;
                seen.add(seq);
            }
            if (lost == 0)
                System.out.println("  получено уникальных частей " + seen.size() + " из 60; нарушений порядка среди соседних " + inversions + " из " + (got.size() - 1));
            else
                System.out.println("  часть " + lost + " потеряна: собрано " + seen.size() + " из 60, пакет не завершится без таймаута; отсутствует " +
                        java.util.stream.IntStream.rangeClosed(1, 60).filter(i -> !seen.contains(i)).boxed().toList());
        }
    }

    static String checksum(Map<String, String> m) throws Exception {
        var md = MessageDigest.getInstance("SHA-256");
        for (var e : new TreeMap<>(m).entrySet()) md.update((e.getKey() + "=" + e.getValue() + "\n").getBytes());
        return HexFormat.of().formatHex(md.digest()).substring(0, 12);
    }

    static void replica() throws Exception {
        System.out.println("=== 12.2 справочник из 200 записей: события изменений в локальную копию, 7 событий потеряны");
        String topic = "tariffs." + UUID.randomUUID().toString().substring(0, 8);
        createTopic(topic, 3);
        Map<String, String> source = new TreeMap<>();
        for (int i = 1; i <= 200; i++) source.put("T" + i, "rate=" + (100 + i));
        try (var p = producer()) { source.forEach((k, v) -> p.send(new ProducerRecord<>(topic, k, v))); }
        Map<String, String> replica = new TreeMap<>();
        readAll(topic, 200).forEach(r -> replica.put(r.key(), r.value()));
        System.out.println("  после начальной загрузки копия содержит " + replica.size() + " записей, контрольные суммы " + checksum(source) + " / " + checksum(replica));
        for (int i = 10; i <= 70; i += 10) source.put("T" + i, "rate=" + (500 + i));      // 7 изменений, события не опубликованы
        System.out.println("  после 7 потерянных изменений: контрольные суммы источника и копии " + checksum(source) + " / " + checksum(replica) + " (различны)");
        long diff = source.entrySet().stream().filter(e -> !e.getValue().equals(replica.get(e.getKey()))).count();
        System.out.println("  сверка по ключам нашла расхождений: " + diff);
    }

    public static void main(String[] args) throws Exception {
        splitter();
        replica();
    }
}
