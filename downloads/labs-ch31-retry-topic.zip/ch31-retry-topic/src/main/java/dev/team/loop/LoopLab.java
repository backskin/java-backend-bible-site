package dev.team.loop;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.OffsetSpec;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.Header;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.BackOff;
import org.springframework.kafka.annotation.DltHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Глава 31, раздел 13.6: обработчик DLT, который возвращает сообщение в работу, замыкает цепочку
 * retry-топиков в цикл. Сломанный вариант публикует запись из {@code @DltHandler} обратно в основной
 * топик; новая запись приходит без заголовка {@code retry_topic-attempts}, и счетчик попыток каждый
 * проход начинается заново. Чтобы опыт закончился, цикл обрывается после {@link #CAP} проходов.
 * Исправленный вариант делает обработчик DLT конечной точкой: он только записывает факт и ничего не публикует.
 */
@SpringBootApplication
public class LoopLab {

    /** Предел проходов в сломанном варианте; без него цикл не закончился бы никогда. */
    static final int CAP = 5;
    static final long T0 = System.currentTimeMillis();
    static final List<String> LOG = new CopyOnWriteArrayList<>();

    public static void main(String[] args) { SpringApplication.run(LoopLab.class, args); }

    /** Сломанный вариант: «отложенный разбор» в обработчике DLT отправляет запись обратно в основной топик. */
    @Component
    static class Broken {
        final KafkaTemplate<String, String> template;
        final AtomicInteger passes = new AtomicInteger();
        Broken(KafkaTemplate<String, String> template) { this.template = template; }

        @RetryableTopic(attempts = "3", backOff = @BackOff(delay = 200), autoCreateTopics = "true")
        @KafkaListener(topics = "notify.loop", groupId = "loop")
        public void listen(ConsumerRecord<String, String> rec) {
            LOG.add(String.format("сломанный     %5d мс  %s, попытка %s", System.currentTimeMillis() - T0, rec.topic(), attempts(rec)));
            throw new IllegalStateException("сервис уведомлений недоступен");
        }

        @DltHandler
        public void dlt(ConsumerRecord<String, String> rec) {
            int pass = passes.incrementAndGet();
            LOG.add(String.format("сломанный     %5d мс  %s, проход %d", System.currentTimeMillis() - T0, rec.topic(), pass));
            if (pass < CAP) template.send("notify.loop", rec.key(), rec.value());
        }
    }

    /** Исправленный вариант: обработчик DLT ничего не публикует. */
    @Component
    static class Fixed {
        @RetryableTopic(attempts = "3", backOff = @BackOff(delay = 200), autoCreateTopics = "true")
        @KafkaListener(topics = "notify.fixed", groupId = "fixed")
        public void listen(ConsumerRecord<String, String> rec) {
            LOG.add(String.format("исправленный  %5d мс  %s, попытка %s", System.currentTimeMillis() - T0, rec.topic(), attempts(rec)));
            throw new IllegalStateException("сервис уведомлений недоступен");
        }

        @DltHandler
        public void dlt(ConsumerRecord<String, String> rec) {
            LOG.add(String.format("исправленный  %5d мс  %s, записано для разбора человеком", System.currentTimeMillis() - T0, rec.topic()));
        }
    }

    @Bean
    CommandLineRunner run(KafkaTemplate<String, String> template, KafkaAdmin admin) {
        return args -> {
            Thread.sleep(3000);   // дать контейнерам подписаться
            template.send("notify.loop", "client-1", "push-1").get();
            template.send("notify.fixed", "client-1", "push-1").get();
            Thread.sleep(12000);
            LOG.forEach(System.out::println);
            try (AdminClient ac = AdminClient.create(admin.getConfigurationProperties())) {
                for (String base : List.of("notify.loop", "notify.fixed")) {
                    var names = ac.listTopics().names().get().stream().filter(n -> n.startsWith(base)).sorted().toList();
                    var parts = ac.describeTopics(names).allTopicNames().get().values().stream()
                            .flatMap(d -> d.partitions().stream().map(p -> new TopicPartition(d.name(), p.partition())))
                            .collect(Collectors.toMap(tp -> tp, tp -> OffsetSpec.latest()));
                    var ends = ac.listOffsets(parts).all().get();
                    long total = ends.values().stream().mapToLong(r -> r.offset()).sum();
                    String byTopic = names.stream().map(n -> n + "=" + ends.entrySet().stream()
                            .filter(e -> e.getKey().topic().equals(n)).mapToLong(e -> e.getValue().offset()).sum())
                            .collect(Collectors.joining(", "));
                    System.out.println("записей в топиках " + base + "*: " + total + " (" + byTopic + ")");
                }
            }
            System.exit(0);
        };
    }

    /** Заголовок счетчика попыток Spring Kafka хранит число в двоичном виде; у записи основного топика его нет. */
    static String attempts(ConsumerRecord<?, ?> rec) {
        Header h = rec.headers().lastHeader("retry_topic-attempts");
        return h == null ? "без заголовка" : new BigInteger(h.value()).toString();
    }
}
