package dev.team.rmq;

import com.rabbitmq.client.GetResponse;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.AbstractMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootVersion;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Значения по умолчанию Spring AMQP под Spring Boot. Запуск:
 * CLS=SpringAmqpLab ./run.sh --lab=requeue [--spring.rabbitmq.listener.simple.default-requeue-rejected=false]
 */
@SpringBootApplication
public class SpringAmqpLab {
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(SpringAmqpLab.class);
        app.setLogStartupInfo(false);
        app.run(args).close();
    }

    public record Payment(String id, BigDecimal amount) implements Serializable {}

    static void p(String f, Object... a) { System.out.println(String.format(f, a)); }

    @Bean
    ApplicationRunner runner(SimpleRabbitListenerContainerFactory factory, RabbitTemplate tpl, CachingConnectionFactory cf) {
        return args -> {
            String lab = args.getOptionValues("lab").get(0);
            p("Spring Boot %s, spring-rabbit %s, сценарий %s", SpringBootVersion.getVersion(),
                    RabbitTemplate.class.getPackage().getImplementationVersion(), lab);
            RabbitAdmin admin = new RabbitAdmin(cf);
            switch (lab) {
                case "defaults" -> defaults(factory, admin, args);
                case "requeue" -> requeue(factory, admin, args);
                case "template" -> template(tpl, admin);
                case "confirm" -> confirm(tpl, admin);
                default -> throw new IllegalArgumentException(lab);
            }
        };
    }

    void defaults(SimpleRabbitListenerContainerFactory factory, RabbitAdmin admin, ApplicationArguments args) throws Exception {
        admin.declareQueue(QueueBuilder.durable("lab.spring.defaults").quorum().build());
        SimpleMessageListenerContainer c = factory.createListenerContainer();
        c.setQueueNames("lab.spring.defaults");
        c.setMessageListener(m -> {});
        c.start();
        Thread.sleep(1000);
        p("prefetch у контейнера по умолчанию (по rabbitmqctl list_consumers):");
        RabbitLab.sh("docker", "exec", "r30", "rabbitmqctl", "-q", "list_consumers", "queue_name", "prefetch_count", "ack_required");
        p("AcknowledgeMode=%s, defaultRequeueRejected (поле контейнера)=%s, concurrentConsumers=%s",
                field(c, AbstractMessageListenerContainer.class, "acknowledgeMode"),
                field(c, AbstractMessageListenerContainer.class, "defaultRequeueRejected"),
                field(c, SimpleMessageListenerContainer.class, "concurrentConsumers"));
        c.stop();
        admin.deleteQueue("lab.spring.defaults");
    }

    void requeue(SimpleRabbitListenerContainerFactory factory, RabbitAdmin admin, ApplicationArguments args) throws Exception {
        String mode = args.containsOption("mode") ? args.getOptionValues("mode").get(0) : "runtime";
        admin.declareExchange(ExchangeBuilder.fanoutExchange("lab.spring.dlx").build());
        admin.declareQueue(QueueBuilder.durable("lab.spring.dlq").build());
        admin.declareBinding(new Binding("lab.spring.dlq", Binding.DestinationType.QUEUE, "lab.spring.dlx", "", null));
        admin.purgeQueue("lab.spring.dlq");
        admin.deleteQueue("lab.spring.work");
        admin.declareQueue(QueueBuilder.durable("lab.spring.work").quorum().deadLetterExchange("lab.spring.dlx").deliveryLimit(5).build());
        AtomicInteger calls = new AtomicInteger();
        SimpleMessageListenerContainer c = factory.createListenerContainer();
        c.setQueueNames("lab.spring.work");
        c.setMessageListener(m -> {
            int n = calls.incrementAndGet();
            if (n <= 10) p("  %d мс: вызов %d, поток %s, x-delivery-count=%s", System.currentTimeMillis() % 100000, n, Thread.currentThread().getName(), m.getMessageProperties().getHeaders().get("x-delivery-count"));
            if (mode.equals("reject")) throw new AmqpRejectAndDontRequeueException("схема платежа не совпала");
            throw new IllegalStateException("{битый json");
        });
        c.start();
        new RabbitTemplate(admin.getRabbitTemplate().getConnectionFactory()).convertAndSend("lab.spring.work", "{битый json");
        long st = System.currentTimeMillis();
        Thread.sleep(5000);
        c.stop();
        Properties qp = admin.getQueueProperties("lab.spring.work");
        p("режим %s: за 5 с слушатель вызван %d раз; в рабочей очереди осталось %s, в DLQ %s",
                mode, calls.get(), qp == null ? null : qp.get(RabbitAdmin.QUEUE_MESSAGE_COUNT), admin.getQueueProperties("lab.spring.dlq").get(RabbitAdmin.QUEUE_MESSAGE_COUNT));
        admin.deleteQueue("lab.spring.work");
    }

    void template(RabbitTemplate tpl, RabbitAdmin admin) throws Exception {
        admin.deleteQueue("lab.spring.tpl");
        admin.declareQueue(QueueBuilder.durable("lab.spring.tpl").quorum().build());
        p("конвертер по умолчанию: %s", tpl.getMessageConverter().getClass().getSimpleName());
        tpl.convertAndSend("lab.spring.tpl", new Payment("P-42", new BigDecimal("1500.00")));
        GetResponse r = tpl.execute(ch -> {
            GetResponse g = null;
            for (int i = 0; i < 50 && g == null; i++) { g = ch.basicGet("lab.spring.tpl", false); if (g == null) Thread.sleep(20); }
            ch.basicNack(g.getEnvelope().getDeliveryTag(), false, true);
            return g;
        });
        p("convertAndSend: deliveryMode=%s, content_type=%s", r.getProps().getDeliveryMode(), r.getProps().getContentType());
        try {
            Object o = tpl.receiveAndConvert("lab.spring.tpl", 2000);
            p("receiveAndConvert вернул %s", o);
        } catch (Exception e) {
            Throwable t = e; while (t.getCause() != null) t = t.getCause();
            p("receiveAndConvert: %s: %s", e.getClass().getSimpleName(), t.getMessage());
        }
        long st = System.nanoTime();
        Message m = tpl.receive("lab.spring.tpl");
        p("receive() на пустой очереди без тайм-аута: вернул %s за %.1f мс", m, (System.nanoTime() - st) / 1e6);
        p("Jackson2JsonMessageConverter @Deprecated=%s; JacksonJsonMessageConverter есть=%s",
                org.springframework.amqp.support.converter.Jackson2JsonMessageConverter.class.isAnnotationPresent(Deprecated.class),
                exists("org.springframework.amqp.support.converter.JacksonJsonMessageConverter"));
        admin.deleteQueue("lab.spring.tpl");
    }

    void confirm(RabbitTemplate tpl, RabbitAdmin admin) throws Exception {
        CorrelationData cd = new CorrelationData("P-42");
        long st = System.nanoTime();
        tpl.convertAndSend("lab.no.such.exchange", "payments", "платёж 42", cd);
        p("convertAndSend в несуществующий обменник вернул управление за %.1f мс без исключения", (System.nanoTime() - st) / 1e6);
        CorrelationData.Confirm cf = cd.getFuture().get(5, TimeUnit.SECONDS);
        p("подтверждение: ack=%s, причина=%s", cf.ack(), cf.reason());
        admin.declareExchange(ExchangeBuilder.directExchange("lab.spring.pay").build());
        CorrelationData cd2 = new CorrelationData("P-43");
        tpl.convertAndSend("lab.spring.pay", "no.binding", "платёж 43", cd2);
        CorrelationData.Confirm cf2 = cd2.getFuture().get(5, TimeUnit.SECONDS);
        p("обменник есть, привязки нет: ack=%s, возврат=%s", cf2.ack(), cd2.getReturned() == null ? null : cd2.getReturned().getReplyText());
    }

    static Object field(Object o, Class<?> cls, String name) {
        try { var f = cls.getDeclaredField(name); f.setAccessible(true); return f.get(o); } catch (Exception e) { return "нет поля " + name; }
    }

    static boolean exists(String cls) {
        try { Class.forName(cls); return true; } catch (ClassNotFoundException e) { return false; }
    }
}
