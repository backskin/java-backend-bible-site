package dev.team.rmq;

import com.rabbitmq.client.*;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * Опыты гл. 30 на голом amqp-client. Брокер: docker run -d --name r30 -p 5672:5672 rabbitmq:4-management.
 * Запуск: mvn -q compile exec:java -Dexec.mainClass=dev.team.rmq.RabbitLab -Dexec.args="сценарий".
 */
public class RabbitLab {
    static ConnectionFactory cf() {
        ConnectionFactory f = new ConnectionFactory();
        f.setHost("localhost");
        f.setUsername("guest");
        f.setPassword("guest");
        return f;
    }

    static byte[] b(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    static String s(byte[] b) { return new String(b, StandardCharsets.UTF_8); }
    static long t0 = System.currentTimeMillis();
    static String ts() { return String.format("%6d мс", System.currentTimeMillis() - t0); }
    static void p(String f, Object... a) { System.out.println(String.format(f, a)); }

    public static void main(String[] args) throws Exception {
        String sc = args.length > 0 ? args[0] : "all";
        p("amqp-client %s, сценарий %s", ConnectionFactory.class.getPackage().getImplementationVersion(), sc);
        try (Connection c = cf().newConnection("ch30-lab")) {
            p("брокер: %s %s", c.getServerProperties().get("product"), c.getServerProperties().get("version"));
            switch (sc) {
                case "qtype" -> qtype(c);
                case "unroutable" -> unroutable(c);
                case "persist" -> persist(c);
                case "persist-check" -> persistCheck(c);
                case "redeliver" -> redeliver(c);
                case "reorder" -> reorder(c);
                case "poison" -> poison(c);
                case "ttl" -> ttl(c);
                case "ladder" -> ladder(c);
                case "confirms" -> confirms(c);
                case "overflow" -> overflow(c);
                case "alarm" -> alarm(c);
                case "wrongchannel" -> wrongChannel(c);
                case "timeout" -> consumerTimeout(c, args.length > 1 ? args[1] : "quorum");
                case "stream" -> stream(c);
                case "prefetch" -> prefetch(c);
                default -> throw new IllegalArgumentException(sc);
            }
        }
    }

    // 1. Тип очереди, если x-queue-type не задан
    static void qtype(Connection c) throws Exception {
        Channel ch = c.createChannel();
        ch.queueDelete("lab.qtype.plain");
        ch.queueDeclare("lab.qtype.plain", true, false, false, null);
        ch.queueDelete("lab.qtype.quorum");
        ch.queueDeclare("lab.qtype.quorum", true, false, false, Map.of("x-queue-type", "quorum"));
        try (Connection c2 = cf().newConnection(); Channel ch2 = c2.createChannel()) {
            ch2.queueDeclare("lab.qtype.transient", false, false, false, null);
        } catch (Exception e) {
            p("classic, durable=false, exclusive=false: %s", rootMsg(e).replace("\n", " "));
        }
        p("объявлены lab.qtype.plain (без аргументов) и lab.qtype.quorum; тип смотреть rabbitmqctl list_queues name type durable");
    }

    // 2. Сообщение без маршрута: подтверждение, mandatory, alternate exchange
    static void unroutable(Connection c) throws Exception {
        Channel ch = c.createChannel();
        ch.confirmSelect();
        ch.exchangeDelete("lab.pay");
        ch.exchangeDelete("lab.pay.ae");
        ch.exchangeDeclare("lab.pay", BuiltinExchangeType.DIRECT, true);
        BlockingQueue<String> returns = new LinkedBlockingQueue<>();
        ch.addReturnListener(r -> returns.add(r.getReplyCode() + " " + r.getReplyText() + " rk=" + r.getRoutingKey()));
        ch.basicPublish("lab.pay", "payment.created", false, null, b("без mandatory"));
        boolean ok1 = ch.waitForConfirms(5000);
        p("без mandatory: подтверждение=%s, возврат=%s", ok1, returns.poll(1, TimeUnit.SECONDS));
        ch.basicPublish("lab.pay", "payment.created", true, null, b("с mandatory"));
        boolean ok2 = ch.waitForConfirms(5000);
        p("с mandatory: подтверждение=%s, возврат=%s", ok2, returns.poll(1, TimeUnit.SECONDS));
        // alternate exchange
        ch.exchangeDeclare("lab.pay.ae", BuiltinExchangeType.FANOUT, true);
        ch.queueDelete("lab.pay.unrouted");
        ch.queueDeclare("lab.pay.unrouted", true, false, false, null);
        ch.queueBind("lab.pay.unrouted", "lab.pay.ae", "");
        ch.exchangeDelete("lab.pay2");
        ch.exchangeDeclare("lab.pay2", BuiltinExchangeType.DIRECT, true, false, Map.of("alternate-exchange", "lab.pay.ae"));
        ch.basicPublish("lab.pay2", "payment.created", true, null, b("через AE"));
        ch.waitForConfirms(5000);
        Thread.sleep(300);
        p("с alternate-exchange: в lab.pay.unrouted сообщений=%d, возврат=%s", ch.messageCount("lab.pay.unrouted"), returns.poll(500, TimeUnit.MILLISECONDS));
        // DLX у очереди не ловит неразмаршрутизированное
        ch.queueDelete("lab.pay.dlq");
        ch.queueDeclare("lab.pay.dlq", true, false, false, null);
        ch.exchangeDelete("lab.pay.dlx");
        ch.exchangeDeclare("lab.pay.dlx", BuiltinExchangeType.FANOUT, true);
        ch.queueBind("lab.pay.dlq", "lab.pay.dlx", "");
        ch.queueDelete("lab.pay.work");
        ch.queueDeclare("lab.pay.work", true, false, false, Map.of("x-dead-letter-exchange", "lab.pay.dlx"));
        ch.queueBind("lab.pay.work", "lab.pay", "payment.settled");
        ch.basicPublish("lab.pay", "payment.created", false, null, b("мимо привязки"));
        ch.waitForConfirms(5000);
        Thread.sleep(300);
        p("очередь с DLX привязана к другому ключу: в lab.pay.dlq=%d, в lab.pay.work=%d", ch.messageCount("lab.pay.dlq"), ch.messageCount("lab.pay.work"));
    }

    // 3. Переживёт ли сообщение перезапуск
    static void persist(Connection c) throws Exception {
        Channel ch = c.createChannel();
        ch.confirmSelect();
        for (String q : List.of("lab.persist.classic", "lab.persist.quorum")) ch.queueDelete(q);
        ch.queueDeclare("lab.persist.classic", true, false, false, Map.of("x-queue-type", "classic"));
        ch.queueDeclare("lab.persist.quorum", true, false, false, Map.of("x-queue-type", "quorum"));
        ch.basicPublish("", "lab.persist.classic", null, b("transient: props=null"));
        ch.basicPublish("", "lab.persist.classic", MessageProperties.PERSISTENT_TEXT_PLAIN, b("persistent"));
        ch.basicPublish("", "lab.persist.quorum", null, b("transient в quorum"));
        ch.waitForConfirmsOrDie(5000);
        GetResponse r = ch.basicGet("lab.persist.quorum", false);
        p("deliveryMode у basicPublish(props=null): %s", r.getProps().getDeliveryMode());
        ch.basicNack(r.getEnvelope().getDeliveryTag(), false, true);
        p("до перезапуска: classic=%d, quorum=%d", ch.messageCount("lab.persist.classic"), ch.messageCount("lab.persist.quorum"));
    }

    static void persistCheck(Connection c) throws Exception {
        Channel ch = c.createChannel();
        p("после перезапуска: classic=%d, quorum=%d", ch.messageCount("lab.persist.classic"), ch.messageCount("lab.persist.quorum"));
        GetResponse r;
        while ((r = ch.basicGet("lab.persist.classic", true)) != null) p("  classic: %s", s(r.getBody()));
        while ((r = ch.basicGet("lab.persist.quorum", true)) != null) p("  quorum: %s, redelivered=%s, headers=%s", s(r.getBody()), r.getEnvelope().isRedeliver(), r.getProps().getHeaders());
    }

    // 4. Обрыв без ack: повторная доставка и счётчики
    static void redeliver(Connection c) throws Exception {
        for (String type : List.of("classic", "quorum")) {
            String q = "lab.redeliver." + type;
            Channel admin = c.createChannel();
            admin.queueDelete(q);
            admin.queueDeclare(q, true, false, false, Map.of("x-queue-type", type));
            admin.basicPublish("", q, MessageProperties.PERSISTENT_TEXT_PLAIN, b("платёж 42"));
            for (int i = 1; i <= 3; i++) {
                Channel ch = c.createChannel();
                GetResponse r = null;
                for (int w = 0; w < 100 && r == null; w++) { r = ch.basicGet(q, false); if (r == null) Thread.sleep(20); }
                Map<String, Object> h = r.getProps().getHeaders();
                p("%s, получение %d: redelivered=%s, x-delivery-count=%s, x-acquired-count=%s", type, i, r.getEnvelope().isRedeliver(),
                        h == null ? null : h.get("x-delivery-count"), h == null ? null : h.get("x-acquired-count"));
                ch.close(); // закрыли канал без ack — как упавший потребитель
            }
            admin.queueDelete(q);
        }
    }

    // 5. Конкурирующие потребители + повторная доставка = нарушение порядка
    static void reorder(Connection c) throws Exception {
        Channel admin = c.createChannel();
        String q = "lab.reorder";
        admin.queueDelete(q);
        admin.queueDeclare(q, true, false, false, Map.of("x-queue-type", "quorum"));
        List<String> processed = Collections.synchronizedList(new ArrayList<>());
        CountDownLatch done = new CountDownLatch(6);
        Channel a = c.createChannel();
        a.basicQos(1);
        Channel bch = c.createChannel();
        bch.basicQos(1);
        CountDownLatch bGotSecond = new CountDownLatch(1);
        AtomicInteger bCount = new AtomicInteger();
        bch.basicConsume(q, false, "B", new DefaultConsumer(bch) {
            @Override public void handleDelivery(String tag, Envelope env, AMQP.BasicProperties props, byte[] body) throws java.io.IOException {
                int n = bCount.incrementAndGet();
                if (n == 1) {
                    try { Thread.sleep(150); } catch (InterruptedException ignored) {}
                    processed.add("B:" + s(body));
                    done.countDown();
                    getChannel().basicAck(env.getDeliveryTag(), false);
                } else {
                    p("%s B получил %s и «упал» до подтверждения", ts(), s(body));
                    bGotSecond.countDown();
                }
            }
        });
        a.basicConsume(q, false, "A", new DefaultConsumer(a) {
            @Override public void handleDelivery(String tag, Envelope env, AMQP.BasicProperties props, byte[] body) throws java.io.IOException {
                try { Thread.sleep(100); } catch (InterruptedException ignored) {}
                processed.add("A:" + s(body) + (env.isRedeliver() ? "(повторно)" : ""));
                done.countDown();
                getChannel().basicAck(env.getDeliveryTag(), false);
            }
        });
        for (int i = 1; i <= 6; i++) admin.basicPublish("", q, null, b("m" + i));
        bGotSecond.await(5, TimeUnit.SECONDS);
        Thread.sleep(250);
        bch.close();
        done.await(10, TimeUnit.SECONDS);
        p("порядок обработки: %s", processed);
        admin.queueDelete(q);
    }

    // 6. Отравленное сообщение: requeue в цикле; delivery-limit в quorum
    static void poison(Connection c) throws Exception {
        Channel admin = c.createChannel();
        admin.exchangeDeclare("lab.poison.dlx", BuiltinExchangeType.FANOUT, true);
        admin.queueDelete("lab.poison.dlq");
        admin.queueDeclare("lab.poison.dlq", true, false, false, null);
        admin.queueBind("lab.poison.dlq", "lab.poison.dlx", "");
        record Case(String type, String how) {}
        for (Case k : List.of(new Case("classic", "nack"), new Case("quorum", "reject"), new Case("quorum", "nack"), new Case("quorum", "close"))) {
            String q = "lab.poison." + k.type + "." + k.how;
            admin.queueDelete(q);
            Map<String, Object> qa = new HashMap<>(Map.of("x-queue-type", k.type, "x-dead-letter-exchange", "lab.poison.dlx"));
            admin.queueDeclare(q, true, false, false, qa);
            admin.queuePurge("lab.poison.dlq");
            admin.basicPublish("", q, MessageProperties.PERSISTENT_TEXT_PLAIN, b("{битый json"));
            AtomicInteger deliveries = new AtomicInteger();
            AtomicReference<Object> lastCount = new AtomicReference<>();
            long start = System.currentTimeMillis();
            long deadline = start + 3000;
            if (k.how.equals("close")) {
                while (System.currentTimeMillis() < deadline && admin.messageCount(q) + 0 >= 0) {
                    Channel ch = c.createChannel();
                    GetResponse r = ch.basicGet(q, false);
                    if (r == null) { ch.close(); break; }
                    deliveries.incrementAndGet();
                    Map<String, Object> h = r.getProps().getHeaders();
                    lastCount.set(h == null ? null : h.get("x-delivery-count"));
                    ch.close();
                }
            } else {
                Channel ch = c.createChannel();
                ch.basicQos(1);
                String tag = ch.basicConsume(q, false, new DefaultConsumer(ch) {
                    @Override public void handleDelivery(String t, Envelope env, AMQP.BasicProperties props, byte[] body) throws java.io.IOException {
                        deliveries.incrementAndGet();
                        Map<String, Object> h = props.getHeaders();
                        lastCount.set(h == null ? null : h.get("x-delivery-count"));
                        if (k.how.equals("reject")) getChannel().basicReject(env.getDeliveryTag(), true);
                        else getChannel().basicNack(env.getDeliveryTag(), false, true);
                    }
                });
                Thread.sleep(3000);
                ch.basicCancel(tag);
                ch.close();
            }
            Thread.sleep(300);
            p("%s/%s за 3 с: доставок=%d (%d в секунду), последний x-delivery-count=%s, в очереди=%d, в DLQ=%d", k.type, k.how,
                    deliveries.get(), deliveries.get() / 3, lastCount.get(), admin.messageCount(q), admin.messageCount("lab.poison.dlq"));
            admin.queueDelete(q);
        }
    }

    // 7. TTL: просроченное уходит только из головы очереди
    static void ttl(Connection c) throws Exception {
        Channel admin = c.createChannel();
        admin.exchangeDeclare("lab.ttl.dlx", BuiltinExchangeType.FANOUT, true);
        for (String type : List.of("classic", "quorum")) {
            String q = "lab.ttl." + type, dlq = "lab.ttl.expired";
            admin.queueDelete(q);
            admin.queueDelete(dlq);
            admin.queueDeclare(dlq, true, false, false, null);
            admin.queueBind(dlq, "lab.ttl.dlx", "");
            admin.queueDeclare(q, true, false, false, Map.of("x-queue-type", type, "x-dead-letter-exchange", "lab.ttl.dlx"));
            long start = System.currentTimeMillis();
            admin.basicPublish("", q, new AMQP.BasicProperties.Builder().expiration("4000").deliveryMode(2).build(), b("A ttl=4000"));
            admin.basicPublish("", q, new AMQP.BasicProperties.Builder().expiration("500").deliveryMode(2).build(), b("B ttl=500"));
            Channel ch = c.createChannel();
            CountDownLatch two = new CountDownLatch(2);
            ch.basicConsume(dlq, true, new DefaultConsumer(ch) {
                @Override public void handleDelivery(String t, Envelope env, AMQP.BasicProperties props, byte[] body) {
                    p("%s: %s пришло в DLQ через %d мс, x-death reason=%s", type, s(body), System.currentTimeMillis() - start,
                            ((List<Map<String, Object>>) props.getHeaders().get("x-death")).get(0).get("reason"));
                    two.countDown();
                }
            });
            two.await(10, TimeUnit.SECONDS);
            ch.close();
        }
    }

    // 8. Лестница повторов на TTL-очередях
    static void ladder(Connection c) throws Exception {
        Channel ch = c.createChannel();
        ch.exchangeDeclare("lab.work", BuiltinExchangeType.DIRECT, true);
        ch.exchangeDeclare("lab.retry", BuiltinExchangeType.DIRECT, true);
        ch.queueDelete("lab.payments");
        ch.queueDeclare("lab.payments", true, false, false, Map.of("x-queue-type", "quorum"));
        ch.queueBind("lab.payments", "lab.work", "payments");
        int[] delays = {1000, 2000, 4000};
        for (int i = 0; i < delays.length; i++) {
            String wq = "lab.payments.wait." + delays[i];
            ch.queueDelete(wq);
            ch.queueDeclare(wq, true, false, false, Map.of("x-queue-type", "quorum", "x-message-ttl", delays[i],
                    "x-dead-letter-exchange", "lab.work", "x-dead-letter-routing-key", "payments"));
            ch.queueBind(wq, "lab.retry", "wait." + delays[i]);
        }
        CountDownLatch ok = new CountDownLatch(1);
        long start = System.currentTimeMillis();
        Channel cons = c.createChannel();
        cons.basicQos(1);
        cons.basicConsume("lab.payments", false, new DefaultConsumer(cons) {
            @Override public void handleDelivery(String t, Envelope env, AMQP.BasicProperties props, byte[] body) throws java.io.IOException {
                Map<String, Object> h = props.getHeaders() == null ? Map.of() : props.getHeaders();
                int attempt = h.containsKey("x-attempt") ? ((Number) h.get("x-attempt")).intValue() : 0;
                p("%6d мс: попытка %d, x-death=%s", System.currentTimeMillis() - start, attempt + 1,
                        h.containsKey("x-death") ? ((List<?>) h.get("x-death")).size() + " записей" : "нет");
                if (attempt < delays.length) {
                    Map<String, Object> nh = new HashMap<>(h);
                    nh.put("x-attempt", attempt + 1);
                    getChannel().basicPublish("lab.retry", "wait." + delays[attempt],
                            props.builder().headers(nh).build(), body);
                    getChannel().basicAck(env.getDeliveryTag(), false);
                } else {
                    getChannel().basicAck(env.getDeliveryTag(), false);
                    ok.countDown();
                }
            }
        });
        ch.basicPublish("lab.work", "payments", MessageProperties.PERSISTENT_TEXT_PLAIN, b("платёж 42: шлюз недоступен"));
        ok.await(20, TimeUnit.SECONDS);
        p("обработано на 4-й попытке через %d мс", System.currentTimeMillis() - start);
    }

    // 9. Стоимость гарантий публикации
    static void confirms(Connection c) throws Exception {
        int n = 20000;
        byte[] body = new byte[200];
        for (String type : List.of("classic", "quorum")) {
            String q = "lab.confirms." + type;
            Channel adm = c.createChannel();
            adm.queueDelete(q);
            adm.queueDeclare(q, true, false, false, Map.of("x-queue-type", type));
            for (String mode : List.of("без подтверждений", "подтверждение пачки по 100", "асинхронные подтверждения", "ожидание каждого", "транзакция на каждое")) {
                Channel ch = c.createChannel();
                int count = mode.contains("каждо") ? 2000 : n;
                if (mode.startsWith("транз")) ch.txSelect(); else if (!mode.startsWith("без")) ch.confirmSelect();
                ConcurrentSkipListMap<Long, Boolean> outstanding = new ConcurrentSkipListMap<>();
                if (mode.startsWith("асинх")) ch.addConfirmListener((tag, multiple) -> {
                    if (multiple) outstanding.headMap(tag, true).clear(); else outstanding.remove(tag);
                }, (tag, multiple) -> {});
                long st = System.nanoTime();
                for (int i = 1; i <= count; i++) {
                    if (mode.startsWith("асинх")) outstanding.put(ch.getNextPublishSeqNo(), true);
                    ch.basicPublish("", q, MessageProperties.PERSISTENT_BASIC, body);
                    if (mode.startsWith("подтв") && i % 100 == 0) ch.waitForConfirmsOrDie(10000);
                    if (mode.startsWith("ожид")) ch.waitForConfirmsOrDie(10000);
                    if (mode.startsWith("транз")) ch.txCommit();
                }
                if (mode.startsWith("асинх")) { while (!outstanding.isEmpty()) Thread.sleep(1); }
                if (mode.startsWith("без")) { Thread.sleep(0); }
                double sec = (System.nanoTime() - st) / 1e9;
                p("%s, %s: %d сообщ. за %.2f с, %.0f сообщ./с", type, mode, count, sec, count / sec);
                ch.close();
                adm.queuePurge(q);
            }
            adm.queueDelete(q);
        }
    }

    // 10. max-length: drop-head и reject-publish
    static void overflow(Connection c) throws Exception {
        Channel ch = c.createChannel();
        ch.confirmSelect();
        for (String type : List.of("classic", "quorum")) for (String ov : List.of("drop-head", "reject-publish")) for (boolean each : new boolean[]{false, true}) {
            if (ov.equals("drop-head") && each) continue;
            String q = "lab.overflow." + ov;
            ch.queueDelete(q);
            ch.queueDeclare(q, true, false, false, Map.of("x-queue-type", type, "x-max-length", 3, "x-overflow", ov));
            List<String> acks = Collections.synchronizedList(new ArrayList<>());
            ConfirmListener l = ch.addConfirmListener((tag, m) -> acks.add("ack" + tag + (m ? "*" : "")), (tag, m) -> acks.add("NACK" + tag + (m ? "*" : "")));
            long base = ch.getNextPublishSeqNo() - 1;
            for (int i = 1; i <= 5; i++) { ch.basicPublish("", q, MessageProperties.PERSISTENT_TEXT_PLAIN, b("заявка " + i)); if (each) try { ch.waitForConfirms(5000); } catch (Exception ignored) {} }
            try { ch.waitForConfirms(5000); } catch (Exception ignored) {}
            Thread.sleep(300);
            ch.removeConfirmListener(l);
            List<String> left = new ArrayList<>();
            GetResponse r;
            while ((r = ch.basicGet(q, true)) != null) left.add(s(r.getBody()));
            p("%s, %s%s: подтверждения (номера с %d)=%s, в очереди осталось %s", type, ov, each ? ", ждать каждое" : ", пачкой", base + 1, acks, left);
        }
    }

    // 11. Оповещение о памяти блокирует публикаторов
    static void alarm(Connection c) throws Exception {
        Channel ch = c.createChannel();
        ch.queueDelete("lab.alarm");
        ch.queueDeclare("lab.alarm", true, false, false, Map.of("x-queue-type", "quorum"));
        BlockingQueue<String> ev = new LinkedBlockingQueue<>();
        c.addBlockedListener(reason -> ev.add(ts() + " blocked: " + reason), () -> ev.add(ts() + " unblocked"));
        sh("docker", "exec", "r30", "rabbitmqctl", "set_vm_memory_high_watermark", "absolute", "50MB");
        p("%s водяной знак памяти опущен до 50 МБ", ts());
        Thread.sleep(1500);
        ExecutorService ex = Executors.newSingleThreadExecutor();
        Future<Long> f = ex.submit(() -> {
            long st = System.currentTimeMillis();
            for (int i = 0; i < 1000; i++) ch.basicPublish("", "lab.alarm", null, new byte[1024]);
            ch.basicQos(1); // синхронный метод: вернётся, только когда брокер прочтёт всё, что выше
            return System.currentTimeMillis() - st;
        });
        try {
            p("публикация 1000 сообщений: %s мс", f.get(4, TimeUnit.SECONDS));
        } catch (TimeoutException e) {
            p("%s публикация не завершилась за 4 с — поток публикатора заблокирован", ts());
        }
        sh("docker", "exec", "r30", "rabbitmqctl", "set_vm_memory_high_watermark", "0.6");
        p("%s водяной знак возвращён к 0.6", ts());
        p("публикация завершилась, всего ждала %d мс", f.get(10, TimeUnit.SECONDS));
        ex.shutdown();
        Thread.sleep(500);
        ev.forEach(e -> p("  событие: %s", e));
        ch.queueDelete("lab.alarm");
    }

    // 12. Подтверждение на чужом канале
    static void wrongChannel(Connection c) throws Exception {
        Channel adm = c.createChannel();
        adm.queueDelete("lab.wrongch");
        adm.queueDeclare("lab.wrongch", true, false, false, null);
        adm.basicPublish("", "lab.wrongch", null, b("x"));
        Channel ch1 = c.createChannel();
        Channel ch2 = c.createChannel();
        GetResponse r = ch1.basicGet("lab.wrongch", false);
        p("получено на канале %d, delivery tag=%d", ch1.getChannelNumber(), r.getEnvelope().getDeliveryTag());
        ch2.basicAck(r.getEnvelope().getDeliveryTag(), false);
        Thread.sleep(500);
        p("канал %d открыт=%s, причина закрытия: %s", ch2.getChannelNumber(), ch2.isOpen(), ch2.getCloseReason() == null ? null : ch2.getCloseReason().getMessage());
        ch1.close();
        p("после закрытия канала %d в очереди снова %d сообщ.", ch1.getChannelNumber(), adm.messageCount("lab.wrongch"));
    }

    // 13. Тайм-аут подтверждения
    static void consumerTimeout(Connection c, String type) throws Exception {
        Channel adm = c.createChannel();
        adm.queueDelete("lab.ctimeout");
        adm.queueDeclare("lab.ctimeout", true, false, false, type.equals("quorum") ? Map.of("x-queue-type", type, "x-consumer-timeout", 5000) : Map.of("x-queue-type", type));
        adm.basicPublish("", "lab.ctimeout", null, b("выписка за год"));
        Channel ch = c.createChannel();
        CountDownLatch closed = new CountDownLatch(1);
        ch.addShutdownListener(sse -> { p("%s канал закрыт брокером: %s", ts(), sse.getMessage()); closed.countDown(); });
        ch.basicConsume("lab.ctimeout", false, new DefaultConsumer(ch) {
            @Override public void handleDelivery(String t, Envelope env, AMQP.BasicProperties props, byte[] body) {
                p("%s получено «%s», обработка затянулась, ack не отправлен", ts(), s(body));
            }
            @Override public void handleCancel(String t) { p("%s брокер отменил потребителя (basic.cancel)", ts()); closed.countDown(); }
        });
        for (int i = 0; i < 70 && closed.getCount() > 0; i++) {
            Thread.sleep(1000);
            long ready = adm.messageCount("lab.ctimeout");
            if (ready > 0) { p("%s сообщение снова в готовых (ready=%d), канал открыт=%s", ts(), ready, ch.isOpen()); break; }
        }
        closed.await(5, TimeUnit.SECONDS);
        Thread.sleep(300);
        GetResponse r = adm.basicGet("lab.ctimeout", false);
        p("%s сообщение вернулось в очередь: %s, x-delivery-count=%s, x-acquired-count=%s", ts(), r != null,
                r == null || r.getProps().getHeaders() == null ? null : r.getProps().getHeaders().get("x-delivery-count"),
                r == null || r.getProps().getHeaders() == null ? null : r.getProps().getHeaders().get("x-acquired-count"));
    }

    // 14. Stream: чтение без удаления
    static void stream(Connection c) throws Exception {
        Channel adm = c.createChannel();
        adm.queueDelete("lab.stream");
        adm.queueDeclare("lab.stream", true, false, false, Map.of("x-queue-type", "stream", "x-max-age", "7D"));
        adm.confirmSelect();
        for (int i = 1; i <= 5; i++) adm.basicPublish("", "lab.stream", null, b("событие " + i));
        adm.waitForConfirmsOrDie(5000);
        for (String off : List.of("first", "first", "next")) {
            Channel ch = c.createChannel();
            ch.basicQos(100);
            List<String> got = Collections.synchronizedList(new ArrayList<>());
            ch.basicConsume("lab.stream", false, Map.of("x-stream-offset", off), new DefaultConsumer(ch) {
                @Override public void handleDelivery(String t, Envelope env, AMQP.BasicProperties props, byte[] body) throws java.io.IOException {
                    got.add(s(body) + "@" + props.getHeaders().get("x-stream-offset"));
                    getChannel().basicAck(env.getDeliveryTag(), false);
                }
            });
            Thread.sleep(1000);
            p("x-stream-offset=%s: получено %d %s", off, got.size(), got);
            ch.close();
        }
        try {
            Channel ch = c.createChannel();
            ch.basicConsume("lab.stream", true, new DefaultConsumer(ch));
            Thread.sleep(300);
            p("autoAck на стриме: канал открыт=%s", ch.isOpen());
        } catch (Exception e) {
            p("autoAck на стриме: %s", rootMsg(e));
        }
        p("в стриме после трёх чтений: %d сообщ.", adm.messageCount("lab.stream"));
    }

    // 15. Prefetch и распределение между экземплярами
    static void prefetch(Connection c) throws Exception {
        for (int pf : new int[]{250, 1}) {
            Channel adm = c.createChannel();
            String q = "lab.prefetch";
            adm.queueDelete(q);
            adm.queueDeclare(q, true, false, false, Map.of("x-queue-type", "quorum"));
            adm.confirmSelect();
            for (int i = 0; i < 40; i++) adm.basicPublish("", q, null, b("выписка " + i));
            adm.waitForConfirmsOrDie(5000);
            Map<String, AtomicInteger> cnt = new ConcurrentHashMap<>();
            List<Channel> chans = new ArrayList<>();
            for (String name : List.of("под-1", "под-2", "под-3")) {
                Channel ch = c.createChannel();
                chans.add(ch);
                ch.basicQos(pf);
                cnt.put(name, new AtomicInteger());
                ch.basicConsume(q, false, new DefaultConsumer(ch) {
                    @Override public void handleDelivery(String t, Envelope env, AMQP.BasicProperties props, byte[] body) throws java.io.IOException {
                        try { Thread.sleep(50); } catch (InterruptedException ignored) {}
                        cnt.get(name).incrementAndGet();
                        getChannel().basicAck(env.getDeliveryTag(), false);
                    }
                });
                Thread.sleep(100); // поды поднимаются по очереди
            }
            long st = System.currentTimeMillis();
            while (adm.messageCount(q) > 0 || cnt.values().stream().mapToInt(AtomicInteger::get).sum() < 40) Thread.sleep(20);
            p("prefetch=%d: распределение %s, очередь разобрана за %d мс", pf, new TreeMap<>(cnt), System.currentTimeMillis() - st + 200);
            for (Channel ch : chans) ch.close();
        }
    }

    static String rootMsg(Throwable e) {
        while (e.getCause() != null) e = e.getCause();
        return e.getMessage();
    }

    static void sh(String... cmd) throws Exception {
        Process pr = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String out = new String(pr.getInputStream().readAllBytes()).trim();
        pr.waitFor();
        if (!out.isEmpty()) p("  $ %s → %s", String.join(" ", Arrays.copyOfRange(cmd, 2, cmd.length)), out.replace('\n', ' '));
    }
}
