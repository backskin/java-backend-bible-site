# RabbitMQ 4.4: подтверждения, немаршрутизируемые сообщения, долговечность, типы очередей, prefetch, повторная доставка, TTL, потоки, Spring AMQP

Стенд к главе 30, раздел о RabbitMQ. `RabbitLab` (amqp-client 5.30.0) выполняет сценарий за запуск против RabbitMQ 4.4.0 (`rabbitmq:4-management`): `confirms`, `unroutable` (mandatory и return), `persist` и `persist-check` с перезапуском брокера между ними, `qtype` (classic, quorum, stream), `prefetch`, `redeliver`, `wrongchannel` (ack не на том канале), `reorder`, `poison`, `ttl`, `timeout` (`consumer_timeout` 30 минут), `overflow`, `alarm`, `ladder`, `stream`. `SpringAmqpLab` (`CLS=SpringAmqpLab`, Spring Boot 4.1.2) - умолчания контейнера слушателей, `convertAndSend` в несуществующий обменник, `requeue` и `x-delivery-count`, конвертер по умолчанию. Выводы автора - `s30-<сценарий>.txt`, `s30-spring-*.txt`.

## Что нужно

- JDK 21, Maven, Docker, bash.

## Запуск

```bash
docker run -d --name r30 -p 5672:5672 -p 15672:15672 rabbitmq:4-management
```

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && bash run.sh unroutable
```

Spring AMQP: `CLS=SpringAmqpLab bash run.sh confirm`. В IDEA есть конфигурации `RabbitLab`, `SpringAmqpLab` (сценарий - аргумент) и Shell-конфигурация `run`.

## Что должно получиться

Каждый файл начинается строкой с версией клиента и брокера; например, `convertAndSend` в несуществующий обменник возвращает управление за десятки миллисекунд без исключения, а ошибка приходит только через `ReturnsCallback`.
