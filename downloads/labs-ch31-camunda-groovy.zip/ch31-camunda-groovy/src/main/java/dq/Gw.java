package dq;

import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngineConfiguration;

import java.util.Map;
import java.util.stream.Collectors;

public class Gw {
    public static void main(String[] args) {
        ProcessEngine engine = ProcessEngineConfiguration.createStandaloneInMemProcessEngineConfiguration()
                .setJdbcUrl("jdbc:h2:mem:gw;DB_CLOSE_DELAY=-1").setDatabaseSchemaUpdate("create-drop").setHistory("full").buildProcessEngine();
        engine.getRepositoryService().createDeployment().addClasspathResource("gw.bpmn").deploy();
        HistoryService h = engine.getHistoryService();
        for (String[] c : new String[][]{{"gwNoDefault", "2000"}, {"gwNoDefault", "500"}, {"gwDefault", "500"}, {"gwDefault", "2000"}, {"gwTwoTrue", "700"}}) {
            String key = c[0];
            long amount = Long.parseLong(c[1]);
            try {
                var pi = engine.getRuntimeService().startProcessInstanceByKey(key, Map.of("amountMinor", amount));
                String path = h.createHistoricActivityInstanceQuery().processInstanceId(pi.getId()).orderPartiallyByOccurrence().asc().list()
                        .stream().map(a -> a.getActivityId()).collect(Collectors.joining(" -> "));
                System.out.println(key + ", amountMinor=" + amount + ": " + path);
            } catch (Exception e) {
                Throwable root = e;
                while (root.getCause() != null) root = root.getCause();
                System.out.println(key + ", amountMinor=" + amount + ": ОШИБКА " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()).split("\n")[0]);
            }
        }
        engine.close();
        System.exit(0);
    }
}
