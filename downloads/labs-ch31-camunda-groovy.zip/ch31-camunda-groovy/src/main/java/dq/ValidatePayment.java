package dq;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

/** Обработчик сервисной задачи: обычный Java-класс, который тестируется без движка. */
public class ValidatePayment implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        Object amount = execution.getVariable("amountMinor");
        boolean valid = amount instanceof Number n && n.longValue() > 0;
        execution.setVariable("valid", valid);
    }
}
