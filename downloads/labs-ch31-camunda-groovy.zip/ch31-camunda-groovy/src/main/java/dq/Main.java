package dq;

import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngineConfiguration;
import org.camunda.bpm.engine.history.HistoricActivityInstance;
import org.camunda.bpm.engine.runtime.ProcessInstance;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/** Запуск процесса оплаты в Camunda 7 на встроенной базе H2: нормальный платёж, отклонённый платёж и ошибка в Groovy-скрипте. */
public class Main {

    public static void main(String[] args) {
        ProcessEngine engine = ProcessEngineConfiguration.createStandaloneInMemProcessEngineConfiguration()
                .setJdbcUrl("jdbc:h2:mem:camunda;DB_CLOSE_DELAY=-1")
                .setDatabaseSchemaUpdate("create-drop")
                .setHistory("full")
                .buildProcessEngine();
        engine.getRepositoryService().createDeployment().addClasspathResource("payment.bpmn").deploy();

        System.out.println("=== 1. нормальный платёж на 150000 копеек");
        run(engine, "payment", Map.of("amountMinor", 150_000L));

        System.out.println("=== 2. платёж с нулевой суммой");
        run(engine, "payment", Map.of("amountMinor", 0L));

        System.out.println("=== 3. сумма пришла строкой (так бывает при разборе JSON)");
        run(engine, "payment", Map.of("amountMinor", "150000"));

        System.out.println("=== 4. опечатка в имени переменной внутри Groovy-скрипта");
        run(engine, "paymentBroken", Map.of("amountMinor", 150_000L));

        System.out.println("=== 5. что видит скрипт: он выполняется с правами приложения");
        run(engine, "paymentProbe", Map.of());
        engine.close();
    }

    static void run(ProcessEngine engine, String key, Map<String, Object> variables) {
        try {
            ProcessInstance pi = engine.getRuntimeService().startProcessInstanceByKey(key, new HashMap<>(variables));
            HistoryService h = engine.getHistoryService();
            String path = h.createHistoricActivityInstanceQuery().processInstanceId(pi.getId()).orderPartiallyByOccurrence().asc().list()
                    .stream().map(HistoricActivityInstance::getActivityId).collect(Collectors.joining(" -> "));
            System.out.println("  путь по процессу: " + path);
            Map<String, Object> out = new HashMap<>();
            h.createHistoricVariableInstanceQuery().processInstanceId(pi.getId()).list().forEach(v -> out.put(v.getName(), v.getValue()));
            System.out.println("  переменные: " + new java.util.TreeMap<>(out));
        } catch (Exception e) {
            Throwable root = e;
            while (root.getCause() != null) root = root.getCause();
            System.out.println("  ОШИБКА во время выполнения: " + e.getClass().getSimpleName() + " / " + root.getClass().getSimpleName() + ": " + String.valueOf(root.getMessage()).split("\n")[0]);
        }
    }
}
