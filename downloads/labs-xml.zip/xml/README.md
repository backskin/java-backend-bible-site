# XML в Java: XSD-схемы и их расширение, JAXB, безопасный разбор, потоковая обработка StAX, SOAP без фреймворка

Стенд к главе 28, разделы об XML и SOAP. Программы в `dev.team.xml` на встроенных JAXP, Xerces и StAX JDK 21 и Jakarta XML Binding 4.0 (реализация JAXB 4.0.7): `SchemaLab` (проверка накладной по `xsd/waybill-1.xsd` и расширенной схеме `waybill-1-ext.xsd`, документы в `docs/`), `JaxbLab` (привязка классов к схеме, пространства имен, неизвестные элементы), `SecurityLab` (XXE, billion laughs и как их выключить в фабриках), `StreamLab` (разбор большого документа StAX с постоянной памятью), `soap.SoapLab` (SOAP-обмен карточками клиентов по `xsd/clients-1.xsd` на `com.sun.net.httpserver` и `HttpClient`). Коды станций, грузов и ИНН вымышлены. Выводы приведены в главе.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" dev.team.xml.SchemaLab
```

В IDEA на каждый класс есть конфигурация.
