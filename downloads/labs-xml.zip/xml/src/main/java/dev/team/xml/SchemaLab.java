package dev.team.xml;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.util.ArrayList;
import java.util.List;

/** Опыт: проверка накладной по XSD, все ошибки сразу, пространства имён и версии формата. */
public class SchemaLab {
    static Schema schema(String name) throws Exception {
        var f = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        return f.newSchema(SchemaLab.class.getResource("/xsd/" + name));
    }

    static StreamSource doc(String name) { return new StreamSource(SchemaLab.class.getResource("/docs/" + name).toString()); }

    /** Проверка, которая не останавливается на первой ошибке: собирает все с номерами строк. */
    static List<String> validateAll(Schema s, String docName) throws Exception {
        List<String> errors = new ArrayList<>();
        Validator v = s.newValidator();
        v.setErrorHandler(new ErrorHandler() {
            public void warning(SAXParseException e) { }
            public void error(SAXParseException e) { errors.add("строка " + e.getLineNumber() + ": " + e.getMessage()); }
            public void fatalError(SAXParseException e) throws SAXParseException { throw e; }
        });
        v.validate(doc(docName));
        return errors;
    }

    /** Контрольная цифра номера вагона в учёте СтальМагистрали: схема Луна по первым семи цифрам. */
    static boolean wagonCheckDigit(String number) {
        int sum = 0;
        for (int i = 0; i < 7; i++) {
            int d = (number.charAt(i) - '0') * (i % 2 == 0 ? 2 : 1);
            sum += d / 10 + d % 10;
        }
        return (10 - sum % 10) % 10 == number.charAt(7) - '0';
    }

    public static void main(String[] args) throws Exception {
        Schema v1 = schema("waybill-1.xsd");
        System.out.println("== 1. верная накладная: ошибок " + validateAll(v1, "good.xml").size());

        System.out.println("== 2. накладная с ошибками, валидатор по умолчанию");
        try { v1.newValidator().validate(doc("bad.xml")); }
        catch (SAXParseException e) { System.out.println("   остановился на первой: строка " + e.getLineNumber() + ": " + e.getMessage()); }
        System.out.println("== 3. та же накладная с обработчиком, который собирает всё");
        validateAll(v1, "bad.xml").forEach(e -> System.out.println("   " + e));

        System.out.println("== 4. то, чего XSD проверить не может: контрольная цифра номера вагона");
        for (String n : new String[]{"52000007", "52000015", "52000006"}) System.out.println("   " + n + " — " + (wagonCheckDigit(n) ? "верный" : "НЕВЕРНЫЙ, хотя шаблону [0-9]{8} соответствует"));

        System.out.println("== 5. та же накладная без объявления пространства имён");
        validateAll(v1, "no-namespace.xml").forEach(e -> System.out.println("   " + e));

        System.out.println("== 6. версия 2 добавила элемент о температуре рефрижератора");
        Schema v1ext = schema("waybill-1-ext.xsd");
        System.out.println("   строгая v1,     элемент в чужом пространстве: " + orOk(validateAll(v1, "v2-reefer.xml")));
        System.out.println("   v1 с xs:any,    элемент в чужом пространстве: " + orOk(validateAll(v1ext, "v2-reefer.xml")));
        System.out.println("   v1 с xs:any,    элемент в своём пространстве: " + orOk(validateAll(v1ext, "v2-same-ns.xml")));
    }

    static String orOk(List<String> errors) { return errors.isEmpty() ? "принята" : "отвергнута — " + errors.get(0); }
}
