package dev.team.xml.soap;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.ByteArrayInputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Опыт: витрина клиентских данных Тундра-Банка отвечает потребителям по SOAP 1.1 без фреймворка.
 * Конверт разбирается DOM, тело проверяется по XSD, ошибки возвращаются Fault с кодом HTTP 500.
 */
public class SoapLab {
    static final String SOAP11 = "http://schemas.xmlsoap.org/soap/envelope/";
    static final String NS = "urn:tundra:clients:1";
    record Card(String inn, String name, String segment) { }
    static final List<Card> SHOWCASE = List.of(
            new Card("2901000033", "ООО «Северный лес»", "корпоративный"),
            new Card("2901000041", "ООО «Северный лён»", "МСБ"),
            new Card("290100005522", "ИП Северов Пётр Ильич", "МСБ"));

    public static void main(String[] args) throws Exception {
        Schema schema = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI)
                .newSchema(SoapLab.class.getResource("/xsd/clients-1.xsd"));
        var server = HttpServer.create(new InetSocketAddress("localhost", 8291), 0);
        server.createContext("/ws/clients", ex -> handle(ex, schema));
        server.start();

        String[][] cases = {
            {"поиск по ИНН", env("", "<cl:FindClientRequest xmlns:cl=\"urn:tundra:clients:1\"><cl:inn>2901000033</cl:inn></cl:FindClientRequest>")},
            {"нечёткий поиск по названию", env("", "<cl:FindClientRequest xmlns:cl=\"urn:tundra:clients:1\"><cl:name>северный лес</cl:name><cl:limit>5</cl:limit></cl:FindClientRequest>")},
            {"две ошибки в запросе", env("", "<cl:FindClientRequest xmlns:cl=\"urn:tundra:clients:1\"><cl:inn>290100003</cl:inn><cl:limit>0</cl:limit></cl:FindClientRequest>")},
            {"заголовок, который сервер не понимает", env("<sec:Token xmlns:sec=\"urn:tundra:security:1\" soap:mustUnderstand=\"1\">dev.team</sec:Token>",
                    "<cl:FindClientRequest xmlns:cl=\"urn:tundra:clients:1\"><cl:inn>2901000033</cl:inn></cl:FindClientRequest>")},
            {"конверт SOAP 1.2 на адрес SOAP 1.1", env("", "<cl:FindClientRequest xmlns:cl=\"urn:tundra:clients:1\"><cl:inn>2901000033</cl:inn></cl:FindClientRequest>")
                    .replace(SOAP11, "http://www.w3.org/2003/05/soap-envelope")},
        };
        var client = HttpClient.newHttpClient();
        for (String[] c : cases) {
            var resp = client.send(HttpRequest.newBuilder(URI.create("http://localhost:8291/ws/clients"))
                    .header("Content-Type", "text/xml; charset=utf-8").header("SOAPAction", "\"urn:tundra:clients:1#FindClient\"")
                    .POST(HttpRequest.BodyPublishers.ofString(c[1])).build(), HttpResponse.BodyHandlers.ofString());
            System.out.println("== " + c[0] + " → HTTP " + resp.statusCode());
            System.out.println("   " + resp.body().replaceAll("<\\?xml[^>]*>", "").replaceAll(">\\s+<", "><"));
        }
        server.stop(0);
    }

    static String env(String header, String body) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"" + SOAP11 + "\"><soap:Header>" + header
                + "</soap:Header><soap:Body>" + body + "</soap:Body></soap:Envelope>";
    }

    static void handle(HttpExchange ex, Schema schema) throws java.io.IOException {
        byte[] in = ex.getRequestBody().readAllBytes();
        String reply; int status = 200;
        try {
            var dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);   // XXE и вложенные сущности
            Document doc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(in));
            Element envelope = doc.getDocumentElement();
            if (!SOAP11.equals(envelope.getNamespaceURI()) || !"Envelope".equals(envelope.getLocalName()))
                throw new Fault("soap:VersionMismatch", "ожидается конверт SOAP 1.1 (" + SOAP11 + ")", List.of());
            Element header = child(envelope, SOAP11, "Header"), body = child(envelope, SOAP11, "Body");
            for (Element h : children(header))
                if ("1".equals(h.getAttributeNS(SOAP11, "mustUnderstand")))
                    throw new Fault("soap:MustUnderstand", "заголовок {" + h.getNamespaceURI() + "}" + h.getLocalName() + " не поддерживается", List.of());
            Element req = children(body).get(0);
            List<String> errors = new ArrayList<>();
            var v = schema.newValidator();
            v.setErrorHandler(new ErrorHandler() {
                public void warning(SAXParseException e) { }
                public void error(SAXParseException e) { errors.add(e.getMessage()); }
                public void fatalError(SAXParseException e) throws SAXParseException { throw e; }
            });
            v.validate(new DOMSource(req));
            if (!errors.isEmpty()) throw new Fault("soap:Client", "запрос не соответствует схеме urn:tundra:clients:1", errors);
            reply = respond(req);
        } catch (Fault f) {
            status = 500;                                       // SOAP 1.1 по HTTP: Fault приходит с кодом 500
            var d = new StringBuilder();
            for (String e : f.errors) d.append("<cl:error>").append(esc(e)).append("</cl:error>");
            reply = "<soap:Envelope xmlns:soap=\"" + SOAP11 + "\"><soap:Body><soap:Fault><faultcode>" + f.code + "</faultcode><faultstring xml:lang=\"ru\">"
                    + esc(f.getMessage()) + "</faultstring>" + (f.errors.isEmpty() ? "" : "<detail><cl:errors xmlns:cl=\"" + NS + "\">" + d + "</cl:errors></detail>")
                    + "</soap:Fault></soap:Body></soap:Envelope>";
        } catch (Exception e) {
            status = 500;
            reply = "<soap:Envelope xmlns:soap=\"" + SOAP11 + "\"><soap:Body><soap:Fault><faultcode>soap:Server</faultcode><faultstring>внутренняя ошибка</faultstring></soap:Fault></soap:Body></soap:Envelope>";
        }
        byte[] out = reply.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "text/xml; charset=utf-8");
        ex.sendResponseHeaders(status, out.length);
        ex.getResponseBody().write(out);
        ex.close();
    }

    /** Поиск по ИНН точный, по названию — нечёткий: слова запроса совпадают со словами названия с точностью до одной буквы. */
    static String respond(Element req) {
        String inn = text(req, "inn"), name = text(req, "name");
        String lim = text(req, "limit");
        int limit = lim == null ? 10 : Integer.parseInt(lim);
        var found = SHOWCASE.stream().filter(c -> inn != null ? c.inn().equals(inn) : fuzzy(name, c.name())).limit(limit).toList();
        var sb = new StringBuilder("<soap:Envelope xmlns:soap=\"" + SOAP11 + "\"><soap:Body><cl:FindClientResponse xmlns:cl=\"" + NS + "\">");
        for (Card c : found) sb.append("<cl:client><cl:inn>").append(c.inn()).append("</cl:inn><cl:name>").append(esc(c.name()))
                .append("</cl:name><cl:segment>").append(c.segment()).append("</cl:segment></cl:client>");
        return sb.append("</cl:FindClientResponse></soap:Body></soap:Envelope>").toString();
    }

    static boolean fuzzy(String query, String name) {
        String[] q = norm(query).split(" "), n = norm(name).split(" ");
        outer:
        for (String w : q) { for (String x : n) if (distance(w, x) <= 1) continue outer; return false; }
        return true;
    }

    static String norm(String s) { return s.toLowerCase(Locale.ROOT).replace('ё', 'е').replaceAll("[«»\"]", "").replaceAll("\\s+", " ").trim(); }

    static int distance(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) cur[j] = Math.min(Math.min(cur[j - 1], prev[j]) + 1, prev[j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    static Element child(Element p, String ns, String local) {
        if (p == null) return null;
        for (Node n = p.getFirstChild(); n != null; n = n.getNextSibling())
            if (n instanceof Element e && ns.equals(e.getNamespaceURI()) && local.equals(e.getLocalName())) return e;
        return null;
    }

    static List<Element> children(Element p) {
        List<Element> r = new ArrayList<>();
        if (p != null) for (Node n = p.getFirstChild(); n != null; n = n.getNextSibling()) if (n instanceof Element e) r.add(e);
        return r;
    }

    static String text(Element req, String local) { Element e = child(req, NS, local); return e == null ? null : e.getTextContent(); }

    static String esc(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    static final class Fault extends Exception {
        final String code; final List<String> errors;
        Fault(String code, String msg, List<String> errors) { super(msg); this.code = code; this.errors = errors; }
    }
}
