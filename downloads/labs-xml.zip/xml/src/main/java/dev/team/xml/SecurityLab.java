package dev.team.xml;

import dev.team.xml.waybill.Waybill;
import jakarta.xml.bind.JAXBContext;
import org.w3c.dom.Document;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Опыт: внешняя сущность (XXE) читает файл сервера, вложенные сущности раздувают документ. */
public class SecurityLab {
    public static void main(String[] args) throws Exception {
        Path secret = Files.createTempFile("gateway-", ".properties");
        Files.writeString(secret, "carrier.api.key=demo-key-for-dev.team-only");
        String uri = secret.toUri().toString();
        String xxe = """
            <?xml version="1.0"?>
            <!DOCTYPE waybill [ <!ENTITY leak SYSTEM "%s"> ]>
            <waybill xmlns="urn:stalmag:waybill:1" id="ЭН-2026102604">
              <date>2026-10-26</date><kind>ВАГОННАЯ</kind>
              <shipper><name>&leak;</name><inn>6658000011</inn></shipper>
            </waybill>""".formatted(uri);

        System.out.println("== 1. DOM с настройками по умолчанию");
        var dbf = DocumentBuilderFactory.newInstance(); dbf.setNamespaceAware(true);
        Document d = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(xxe.getBytes(StandardCharsets.UTF_8)));
        System.out.println("   имя отправителя: " + d.getElementsByTagNameNS("urn:stalmag:waybill:1", "name").item(0).getTextContent());

        System.out.println("== 2. DOM с запретом DOCTYPE");
        var safe = DocumentBuilderFactory.newInstance(); safe.setNamespaceAware(true);
        safe.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        try { safe.newDocumentBuilder().parse(new ByteArrayInputStream(xxe.getBytes(StandardCharsets.UTF_8))); }
        catch (Exception e) { System.out.println("   отказ: " + e.getMessage()); }

        System.out.println("== 3. DOM с ACCESS_EXTERNAL_DTD и ACCESS_EXTERNAL_SCHEMA пустыми");
        var noExt = DocumentBuilderFactory.newInstance(); noExt.setNamespaceAware(true);
        noExt.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ""); noExt.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        try { noExt.newDocumentBuilder().parse(new ByteArrayInputStream(xxe.getBytes(StandardCharsets.UTF_8))); System.out.println("   разобрано"); }
        catch (Exception e) { System.out.println("   отказ: " + e.getMessage()); }

        System.out.println("== 4. JAXB по умолчанию");
        try {
            Waybill w = (Waybill) JAXBContext.newInstance(Waybill.class).createUnmarshaller().unmarshal(new StreamSource(new StringReader(xxe)));
            System.out.println("   имя отправителя: «" + w.shipper.name + "»");
        } catch (Exception e) { System.out.println("   отказ: " + (e.getCause() != null ? e.getCause().getMessage() : e)); }

        System.out.println("== 5. StAX по умолчанию и с SUPPORT_DTD=false");
        for (boolean dtd : new boolean[]{true, false}) {
            var xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, dtd);
            var r = xif.createXMLStreamReader(new StringReader(xxe));
            String name = null;
            try {
                while (r.hasNext()) { if (r.next() == r.START_ELEMENT && r.getLocalName().equals("name")) { name = r.getElementText(); break; } }
                System.out.println("   SUPPORT_DTD=" + dtd + ": имя отправителя «" + name + "»");
            } catch (Exception e) { System.out.println("   SUPPORT_DTD=" + dtd + ": отказ: " + e.getMessage()); }
        }

        System.out.println("== 6. «миллиард смешков»: десять уровней вложенных сущностей по десять копий");
        var lol = new StringBuilder("<?xml version=\"1.0\"?>\n<!DOCTYPE lolz [\n <!ENTITY lol0 \"lol\">\n");
        for (int i = 1; i <= 9; i++) lol.append(" <!ENTITY lol").append(i).append(" \"").append(("&lol" + (i - 1) + ";").repeat(10)).append("\">\n");
        lol.append("]>\n<lolz>&lol9;</lolz>");
        System.out.println("   размер документа " + lol.length() + " байт, после раскрытия было бы 3 000 000 000 символов");
        long t0 = System.nanoTime();
        try { DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(lol.toString().getBytes(StandardCharsets.UTF_8))); }
        catch (Exception e) { System.out.println("   отказ через " + (System.nanoTime() - t0) / 1_000_000 + " мс: " + e.getMessage()); }
        Files.delete(secret);
    }
}
