package dev.team.xml.waybill;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;

import java.time.LocalDate;

/** xs:date ↔ LocalDate: JAXB 4 не знает java.time сам. */
public class LocalDateAdapter extends XmlAdapter<String, LocalDate> {
    @Override public LocalDate unmarshal(String v) { return LocalDate.parse(v); }
    @Override public String marshal(LocalDate v) { return v.toString(); }
}
