/** Классы накладной для JAXB: все элементы в пространстве urn:stalmag:waybill:1. */
@XmlSchema(namespace = "urn:stalmag:waybill:1", elementFormDefault = XmlNsForm.QUALIFIED,
        xmlns = @XmlNs(prefix = "wb", namespaceURI = "urn:stalmag:waybill:1"))
package dev.team.xml.waybill;

import jakarta.xml.bind.annotation.XmlNs;
import jakarta.xml.bind.annotation.XmlNsForm;
import jakarta.xml.bind.annotation.XmlSchema;
