package dev.team.xml;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;

/** Опыт: месячный реестр вагонов от перевозчика, DOM против StAX при куче 256 МБ. */
public class StreamLab {
    public static void main(String[] args) throws Exception {
        int n = args.length > 0 ? Integer.parseInt(args[0]) : 300_000;
        Path f = Files.createTempFile("registry-", ".xml");
        try (BufferedWriter w = Files.newBufferedWriter(f)) {
            w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<registry xmlns=\"urn:stalmag:waybill:1\" month=\"2026-10\">\n");
            for (int i = 0; i < n; i++)
                w.write("  <wagon number=\"" + (52000000 + i) + "\"><cargoCode>320003</cargoCode><net>" + (60 + i % 10) + ".125</net><station>780003</station></wagon>\n");
            w.write("</registry>\n");
        }
        System.out.printf("реестр: %d вагонов, %.1f МБ, куча до %d МБ%n", n, Files.size(f) / 1e6, Runtime.getRuntime().maxMemory() >> 20);
        String mode = args.length > 1 ? args[1] : "both";

        if (!mode.equals("dom")) {
            long t0 = System.nanoTime();
            BigDecimal total = BigDecimal.ZERO; int count = 0;
            try (InputStream in = Files.newInputStream(f)) {
                var r = XMLInputFactory.newInstance().createXMLStreamReader(in);
                while (r.hasNext()) {
                    if (r.next() == XMLStreamConstants.START_ELEMENT && r.getLocalName().equals("net")) { total = total.add(new BigDecimal(r.getElementText())); count++; }
                }
            }
            System.out.printf("StAX: %d вагонов, %s т, %d мс, занято кучи %d МБ%n", count, total, (System.nanoTime() - t0) / 1_000_000, used());
        }
        if (!mode.equals("stax")) {
            long t0 = System.nanoTime();
            try {
                var dbf = DocumentBuilderFactory.newInstance(); dbf.setNamespaceAware(true);
                var doc = dbf.newDocumentBuilder().parse(f.toFile());
                var nets = doc.getElementsByTagNameNS("urn:stalmag:waybill:1", "net");
                BigDecimal total = BigDecimal.ZERO;
                for (int i = 0; i < nets.getLength(); i++) total = total.add(new BigDecimal(nets.item(i).getTextContent()));
                System.out.printf("DOM:  %d вагонов, %s т, %d мс, занято кучи %d МБ%n", nets.getLength(), total, (System.nanoTime() - t0) / 1_000_000, used());
            } catch (OutOfMemoryError e) { System.out.println("DOM:  " + e + " через " + (System.nanoTime() - t0) / 1_000_000 + " мс"); }
        }
        Files.delete(f);
    }

    static long used() { System.gc(); var rt = Runtime.getRuntime(); return (rt.totalMemory() - rt.freeMemory()) >> 20; }
}
