package dev.team.xml.waybill;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementWrapper;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Накладная, связанная с XSD вручную: так делают, когда схема мала, а xjc в сборке не нужен. */
@XmlRootElement(name = "waybill")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"date", "kind", "shipper", "consignee", "from", "to", "wagons"})
public class Waybill {
    @XmlAttribute(required = true) public String id;
    @XmlElement(required = true) @jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter(LocalDateAdapter.class) public LocalDate date;
    @XmlElement(required = true) public String kind;
    @XmlElement(required = true) public Party shipper;
    @XmlElement(required = true) public Party consignee;
    @XmlElement(required = true) public String from;
    @XmlElement(required = true) public String to;
    @XmlElementWrapper(name = "wagons") @XmlElement(name = "wagon") public List<Wagon> wagons = new ArrayList<>();

    @XmlAccessorType(XmlAccessType.FIELD) @XmlType(propOrder = {"name", "inn"})
    public static class Party { public String name; public String inn;
        public Party() { } public Party(String name, String inn) { this.name = name; this.inn = inn; } }

    @XmlAccessorType(XmlAccessType.FIELD) @XmlType(propOrder = {"cargoCode", "net", "seals"})
    public static class Wagon {
        @XmlAttribute(required = true) public String number;
        public String cargoCode;
        public BigDecimal net;
        @XmlElement(name = "seal") public List<String> seals = new ArrayList<>();
        public Wagon() { }
        public Wagon(String number, String cargoCode, String net, String seal) { this.number = number; this.cargoCode = cargoCode; this.net = new BigDecimal(net); this.seals.add(seal); }
        @Override public String toString() { return number + " " + net + " т"; }
    }
}
