package dev.team.xml;

import dev.team.xml.waybill.Waybill;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.UnmarshalException;
import jakarta.xml.bind.Unmarshaller;

import java.io.StringReader;
import java.io.StringWriter;
import java.time.LocalDate;

/** Опыт: JAXB в обе стороны и то, что он молча теряет без схемы. */
public class JaxbLab {
    public static void main(String[] args) throws Exception {
        JAXBContext ctx = JAXBContext.newInstance(Waybill.class);

        System.out.println("== 1. накладная из XML");
        Waybill w = (Waybill) ctx.createUnmarshaller().unmarshal(SchemaLab.class.getResource("/docs/good.xml"));
        System.out.println("   " + w.id + " от " + w.date + ", " + w.shipper.name + " → " + w.consignee.name + ", вагоны " + w.wagons);

        System.out.println("== 2. накладная в XML");
        var out = new Waybill();
        out.id = "ЭН-2026102602"; out.date = LocalDate.of(2026, 10, 26); out.kind = "ВАГОННАЯ";
        out.shipper = new Waybill.Party("АО «Уральский прокат»", "6658000011");
        out.consignee = new Waybill.Party("ООО «Сибирский металлоторг»", "5406000022");
        out.from = "780003"; out.to = "850002";
        out.wagons.add(new Waybill.Wagon("52000007", "320003", "68.450", "СМ-104477"));
        Marshaller m = ctx.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        var sw = new StringWriter(); m.marshal(out, sw);
        System.out.println(sw.toString().indent(3).stripTrailing());

        String broken = """
            <waybill xmlns="urn:stalmag:waybill:1" id="ЭН-2026102603">
              <date>2026-10-26</date><kind>ВАГОННАЯ</kind>
              <shipper><name>АО «Уральский прокат»</name><inn>6658000011</inn></shipper>
              <consignee><name>ООО «Сибирский металлоторг»</name><inn>5406000022</inn></consignee>
              <from>780003</from><to>850002</to>
              <wagons>
                <wagon number="52000007"><cargoCode>320003</cargoCode><net>68,450</net></wagon>
                <wagon number="52000015"><cargoCode>320003</cargoCode><nett>69.120</nett></wagon>
              </wagons>
            </waybill>""";
        System.out.println("== 3. накладная с ошибками, разбор без схемы");
        Waybill b = (Waybill) ctx.createUnmarshaller().unmarshal(new StringReader(broken));
        for (Waybill.Wagon wg : b.wagons) System.out.println("   вагон " + wg.number + ": масса " + wg.net);

        System.out.println("== 4. то же со схемой");
        Unmarshaller strict = ctx.createUnmarshaller();
        strict.setSchema(SchemaLab.schema("waybill-1.xsd"));
        try { strict.unmarshal(new StringReader(broken)); }
        catch (UnmarshalException e) { System.out.println("   отказ: " + (e.getLinkedException() != null ? e.getLinkedException().getMessage() : e.getMessage())); }

        System.out.println("== 5. со своим обработчиком событий: собрать все замечания и решить самому");
        Unmarshaller logging = ctx.createUnmarshaller();
        logging.setSchema(SchemaLab.schema("waybill-1.xsd"));
        logging.setEventHandler(ev -> { System.out.println("   строка " + ev.getLocator().getLineNumber() + ": " + ev.getMessage()); return true; });
        logging.unmarshal(new StringReader(broken));
    }
}
