package dev.team.doclint;

import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Каждое правило проверки на минимальном документе: что ловится и что пропускается. */
class DocLintTest {

    private static final LocalDate TODAY = LocalDate.parse("2026-11-11");
    private final DocLint lint = new DocLint(180, TODAY);

    private static List<String> doc(String... body) {
        List<String> head = List.of("# Документ", "", "**Тип:** описание", "**Версия:** 1.0", "**Статус:** черновик",
                "**Владелец:** команда", "**Дата:** 2026-11-01", "", "## История изменений", "", "| Версия | Дата |", "|---|---|", "| 1.0 | 2026-11-01 |", "");
        List<String> all = new java.util.ArrayList<>(head);
        all.addAll(List.of(body));
        return all;
    }

    private List<String> rules(List<String> lines) {
        return lint.check(lines, null).stream().map(DocLint.Finding::rule).toList();
    }

    @Test void чистыйДокументБезЗамечаний() {
        assertEquals(List.of(), rules(doc("Текст без сокращений.")));
    }

    @Test void паспортБезВладельца() {
        List<String> d = doc();
        d = d.stream().filter(l -> !l.startsWith("**Владелец:**")).toList();
        assertTrue(rules(d).contains("PASSPORT"));
    }

    @Test void версияВПаспортеНеСовпадаетСИсторией() {
        List<String> d = doc().stream().map(l -> l.equals("**Версия:** 1.0") ? "**Версия:** 1.1" : l).toList();
        assertTrue(rules(d).contains("HISTORY"));
    }

    @Test void необъяснённоеСокращение() {
        assertEquals(List.of("TERMS"), rules(doc("Перевод уходит через СБП.")));
        assertEquals(List.of(), rules(doc("## Термины и сокращения", "", "- **СБП** — Система быстрых платежей.", "", "## Текст", "Перевод уходит через СБП.")));
    }

    @Test void общеизвестныеИКодНеСчитаются() {
        assertEquals(List.of(), rules(doc("Ответ в JSON по HTTP.", "```", "SELECT 1 FROM DUAL", "```", "Поле `PENDING`.")));
    }

    @Test void открытыйВопросВЧерновикеПредупреждениеВУтверждённомОшибка() {
        var draft = lint.check(doc("Лимиты уточнить у бизнеса."), null);
        assertEquals(DocLint.Level.WARN, draft.get(0).level());
        List<String> approved = doc("Лимиты уточнить у бизнеса.").stream()
                .map(l -> l.equals("**Статус:** черновик") ? "**Статус:** утверждён" : l).toList();
        assertEquals(DocLint.Level.ERROR, lint.check(approved, null).get(0).level());
    }

    @Test void битаяСсылка() throws Exception {
        Path dir = Path.of("docs");
        var found = lint.check(doc("См. [схему](withdraw-flow.md) и [вторую](withdraw-sequence.md)."), dir);
        assertEquals(1, found.size());
        assertTrue(found.get(0).message().contains("withdraw-flow.md"));
    }

    @Test void давнийДокумент() {
        List<String> d = doc().stream().map(l -> l.startsWith("**Дата:**") ? "**Дата:** 2025-01-01" : l).toList();
        assertTrue(rules(d).contains("STALE"));
    }

    @Test void требованияБезНештатныхСитуаций() {
        List<String> d = doc().stream().map(l -> l.equals("**Тип:** описание") ? "**Тип:** требования" : l).toList();
        assertTrue(rules(d).contains("FAILURES"));
        List<String> ok = new java.util.ArrayList<>(d);
        ok.addAll(List.of("## Нештатные ситуации", "1. Таймаут шлюза."));
        assertFalse(rules(ok).contains("FAILURES"));
    }
}
