package dev.team.doclint;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Проверка оформления документа проекта в Markdown (глава 61, раздел 7).
 *
 * <p>Проверяет то, что можно проверить машиной, и оставляет человеку смысл. Правила:
 * <ul>
 *   <li>{@code PASSPORT} — в начале документа есть паспорт: тип, версия, статус, владелец, дата;</li>
 *   <li>{@code HISTORY} — есть раздел «История изменений», и последняя версия в нём совпадает с версией паспорта;</li>
 *   <li>{@code TERMS} — каждое сокращение из заглавных букв (ПМИ, SLA, СБП) объяснено в разделе «Термины и сокращения»;</li>
 *   <li>{@code OPEN} — в утверждённом документе не осталось открытых вопросов (TBD, «уточнить», «??»);</li>
 *   <li>{@code LINKS} — относительные ссылки ведут на существующие файлы;</li>
 *   <li>{@code STALE} — действующий документ не старше заданного срока (по умолчанию 180 дней);</li>
 *   <li>{@code FAILURES} — в документе требований есть раздел о нештатных ситуациях.</li>
 * </ul>
 * Нарушение с уровнем ERROR не даёт пройти проверке в конвейере, WARN только сообщается.
 */
public final class DocLint {

    /** Найденное нарушение: правило, уровень, строка документа (0 — документ целиком) и пояснение. */
    public record Finding(String rule, Level level, int line, String message) {
        @Override public String toString() {
            return String.format("%-5s %-8s %s%s", level, rule, line > 0 ? "стр. " + line + ": " : "", message);
        }
    }

    public enum Level { ERROR, WARN }

    private static final List<String> PASSPORT = List.of("Тип", "Версия", "Статус", "Владелец", "Дата");
    private static final Pattern FIELD = Pattern.compile("^\\*\\*(Тип|Версия|Статус|Владелец|Дата):\\*\\*\\s*(.+?)\\s*$");
    private static final Pattern ABBR = Pattern.compile("(?<![\\p{L}\\d`])([A-ZА-ЯЁ]{2,6})(?![\\p{L}\\d`])");
    private static final Pattern OPEN = Pattern.compile("\\bTBD\\b|\\?\\?|(?i:уточнить)");
    private static final Pattern LINK = Pattern.compile("\\]\\(([^)#\\s]+)(?:#[^)]*)?\\)");
    /** Сокращения, которые объяснять не нужно: общеизвестные форматы и протоколы. */
    private static final Set<String> COMMON = Set.of("API", "HTTP", "HTTPS", "JSON", "XML", "SQL", "REST", "URL", "ID", "UTC", "ISO", "ГОСТ");

    private final int staleDays;
    private final LocalDate today;

    public DocLint(int staleDays, LocalDate today) {
        this.staleDays = staleDays;
        this.today = today;
    }

    /** Проверяет файл документа; ссылки разрешаются относительно его папки. */
    public List<Finding> check(Path file) throws IOException {
        return check(Files.readAllLines(file), file.toAbsolutePath().getParent());
    }

    /** Проверяет текст документа построчно. */
    public List<Finding> check(List<String> lines, Path baseDir) {
        List<Finding> out = new ArrayList<>();
        Map<String, String> passport = passport(lines);
        for (String f : PASSPORT)
            if (!passport.containsKey(f))
                out.add(new Finding("PASSPORT", Level.ERROR, 0, "в паспорте документа нет поля «" + f + "»"));

        // история изменений: последняя строка таблицы должна нести текущую версию
        int hist = heading(lines, "История изменений");
        if (hist < 0) {
            out.add(new Finding("HISTORY", Level.ERROR, 0, "нет раздела «История изменений»"));
        } else {
            String lastVersion = null;
            for (int i = hist + 1; i < lines.size() && !lines.get(i).startsWith("#"); i++) {
                String l = lines.get(i).trim();
                if (l.startsWith("|") && !l.startsWith("|---") && !l.toLowerCase().startsWith("| версия"))
                    lastVersion = l.split("\\|")[1].trim();
            }
            String v = passport.get("Версия");
            if (lastVersion == null)
                out.add(new Finding("HISTORY", Level.ERROR, hist + 1, "история изменений пуста"));
            else if (v != null && !v.equals(lastVersion))
                out.add(new Finding("HISTORY", Level.ERROR, hist + 1, "версия в паспорте " + v + ", а последняя в истории " + lastVersion));
        }

        // термины: сокращения в тексте против раздела «Термины и сокращения»
        int terms = heading(lines, "Термины и сокращения");
        Set<String> defined = new HashSet<>(COMMON);
        if (terms >= 0)
            for (int i = terms + 1; i < lines.size() && !lines.get(i).startsWith("#"); i++) {
                Matcher m = Pattern.compile("^\\s*[-*]\\s*\\*\\*([^*]+)\\*\\*").matcher(lines.get(i));
                if (m.find()) defined.add(m.group(1).trim());
            }
        Map<String, Integer> firstUse = new LinkedHashMap<>();
        boolean fence = false;
        for (int i = 0; i < lines.size(); i++) {
            String l = lines.get(i);
            if (l.startsWith("```")) { fence = !fence; continue; }
            if (fence || FIELD.matcher(l).matches()) continue;
            Matcher m = ABBR.matcher(l);
            while (m.find()) firstUse.putIfAbsent(m.group(1), i + 1);
        }
        firstUse.forEach((abbr, line) -> {
            if (!defined.contains(abbr))
                out.add(new Finding("TERMS", Level.WARN, line, "сокращение «" + abbr + "» не объяснено в разделе «Термины и сокращения»"));
        });

        // открытые вопросы допустимы в черновике, но не в утверждённом документе
        boolean approved = passport.getOrDefault("Статус", "").toLowerCase().startsWith("утвержд");
        for (int i = 0; i < lines.size(); i++)
            if (OPEN.matcher(lines.get(i)).find() && !FIELD.matcher(lines.get(i)).matches())
                out.add(new Finding("OPEN", approved ? Level.ERROR : Level.WARN, i + 1,
                        (approved ? "открытый вопрос в утверждённом документе: " : "открытый вопрос: ") + lines.get(i).trim()));

        // ссылки на соседние файлы
        if (baseDir != null)
            for (int i = 0; i < lines.size(); i++) {
                Matcher m = LINK.matcher(lines.get(i));
                while (m.find()) {
                    String target = m.group(1);
                    if (target.matches("^[a-z]+:.*")) continue;           // http:, mailto: — не наша забота
                    if (!Files.exists(baseDir.resolve(target)))
                        out.add(new Finding("LINKS", Level.ERROR, i + 1, "ссылка на несуществующий файл " + target));
                }
            }

        // давность
        String date = passport.get("Дата");
        if (date != null) {
            try {
                long age = ChronoUnit.DAYS.between(LocalDate.parse(date), today);
                if (age > staleDays && !passport.getOrDefault("Статус", "").toLowerCase().startsWith("архив"))
                    out.add(new Finding("STALE", Level.WARN, 0, "документ не обновлялся " + age + " " + days(age) + " (порог " + staleDays + ")"));
            } catch (DateTimeParseException e) {
                out.add(new Finding("PASSPORT", Level.ERROR, 0, "дата «" + date + "» не в формате ГГГГ-ММ-ДД"));
            }
        }

        // требования без нештатных ситуаций
        if (passport.getOrDefault("Тип", "").toLowerCase().contains("требован") && heading(lines, "Нештатные ситуации") < 0)
            out.add(new Finding("FAILURES", Level.ERROR, 0, "в документе требований нет раздела «Нештатные ситуации»"));
        return out;
    }

    /** «1 день», «3 дня», «254 дня», «11 дней». */
    static String days(long n) {
        long d = n % 10, h = n % 100;
        if (d == 1 && h != 11) return "день";
        if (d >= 2 && d <= 4 && (h < 12 || h > 14)) return "дня";
        return "дней";
    }

    private static Map<String, String> passport(List<String> lines) {
        Map<String, String> p = new LinkedHashMap<>();
        for (String l : lines.subList(0, Math.min(15, lines.size()))) {
            Matcher m = FIELD.matcher(l);
            if (m.matches()) p.put(m.group(1), m.group(2));
        }
        return p;
    }

    private static int heading(List<String> lines, String title) {
        for (int i = 0; i < lines.size(); i++)
            if (lines.get(i).matches("^#{2,3}\\s+(\\d+\\.\\s*)?" + Pattern.quote(title) + "\\s*$")) return i;
        return -1;
    }

    /** Проверяет все *.md в папке (или один файл); код выхода 1, если есть ошибки уровня ERROR. */
    public static void main(String[] args) throws IOException {
        Path root = Path.of(args.length > 0 ? args[0] : "docs");
        LocalDate today = args.length > 1 ? LocalDate.parse(args[1]) : LocalDate.now();
        DocLint lint = new DocLint(180, today);
        List<Path> files;
        try (Stream<Path> s = Files.isDirectory(root) ? Files.list(root) : Stream.of(root)) {
            files = s.filter(p -> p.toString().endsWith(".md")).sorted().toList();
        }
        int errors = 0;
        for (Path f : files) {
            List<Finding> found = lint.check(f);
            long e = found.stream().filter(x -> x.level() == Level.ERROR).count();
            errors += e;
            System.out.printf("%s: ошибок %d, предупреждений %d%n", f.getFileName(), e, found.size() - e);
            found.forEach(x -> System.out.println("  " + x));
        }
        System.out.println(errors == 0 ? "итог: документы можно утверждать" : "итог: ошибок " + errors + ", утверждать нельзя");
        if (errors > 0 && !Boolean.getBoolean("doclint.noexit")) System.exit(1);
    }
}
