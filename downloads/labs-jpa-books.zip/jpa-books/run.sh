#!/usr/bin/env bash
# Опыты гл. 12 (Spring Data JPA и Hibernate) на Spring Boot 4.1.1, Hibernate 7.4.5, H2 2.4 и встроенном PostgreSQL 15.5 (zonky).
# Запуск: ./run.sh [пакет...] — без аргументов все; вывод каждого опыта в s12-<пакет>.txt.
# Пакеты: demo s315 s35 s36 s43 s45 s46 s53 s61 s611 s66 s66pg s72 s81 s82 s82r s83 s86 s83b s91 s101 s124 s1212 s141 s1417 s1416 s1418 s1419 s144 s1410 s149 s12p s12rw s12conn s12ins s12fl s12opt s12q s12diag s1411 (номер = раздел главы: demo — 3.1, s149 — 14.9; s12p — сверка с книгами: прокси, коллекции, методы Session, разд. 3.3, 3.4, 6.1; s12rw — reWriteBatchedInserts, разд. 2.6; s12conn — момент захвата соединения, разд. 2.3; s12ins — четыре способа вставки 100 000 строк, разд. 10.4; s12fl — пересчёт порциями с clear() и без, разд. 10.7; s12opt — OPTIMISTIC на запросе и транзакция после lock_timeout, разд. 9.1–9.2; s12q — когда всплывает ошибка в тексте @Query, разд. 12.2; s12diag — логгеры SQL, параметров, медленных запросов и метрик сессии, счётчики Statistics на N+1, разд. 16; s1411 — транзакция, оборванная idle_in_transaction_session_timeout, разд. 14.11).
# У s12conn вариант lazy — с provider_disables_autocommit=true и hikari.auto-commit=false (вывод s12-s12conn-lazy.txt, запуск вручную с аргументом lazy).
# У s101 есть два варианта запуска вручную: аргумент versioned=false (вывод s12-s101-versioned.txt) и stateless-first (s12-s101-stateless-first.txt).
# У s611 вариант fail — с hibernate.query.fail_on_pagination_over_collection_fetch=true (вывод s12-s611-fail.txt).
# У s82 вариант h2 — те же шаги на H2 вместо PostgreSQL (вывод s12-s82-h2.txt); с -Dspring.jpa.properties.hibernate.connection.handling_mode=DELAYED_ACQUISITION_AND_RELEASE_AFTER_TRANSACTION — s12-s82-after-tx.txt.
# У s124 вывод с привязанными значениями лимита — s12-s124-bind.txt (тот же запуск с -Dlogging.level.org.hibernate.orm.jdbc.bind=TRACE).
# У s144 варианты с -Dspring.jpa.properties.org.hibernate.flushMode=COMMIT: без аргумента, h2-no-fk, pg-deferred (вывод s12-s144-commit*.txt).
set -uo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt >/dev/null || { mvn -q -DskipTests compile 2>&1 | grep ERROR | head -5; exit 1; }
CP="$(cygpath -w "$PWD/target/classes" 2>/dev/null || echo target/classes);$(cat cp.txt)"
[ "$(uname -o 2>/dev/null)" = "Msys" ] || CP="${CP//;/:}"
pkgs=("$@"); [ ${#pkgs[@]} -eq 0 ] && pkgs=(demo s315 s35 s36 s43 s45 s46 s53 s61 s611 s66 s66pg s72 s81 s82 s82r s83 s86 s83b s91 s101 s124 s1212 s141 s1417 s1416 s1418 s1419 s144 s1410 s149 s12p s12rw s12conn s12ins s12fl s12opt s12q s12diag s1411)
for p in "${pkgs[@]}"; do
  echo "== $p"
  WEB=-Dspring.main.web-application-type=none; [ "$p" = s72 ] && WEB=; "$J" -Dstdout.encoding=UTF-8 $WEB -cp "$CP" "$p.App" 2>&1 \
    | grep -v "WARNING.*\(sun.misc\|Unsafe\|restricted method\|native access\)" \
    | sed -e "s#$HOME#~#g" -e 's#C:\\Users\\[^\\]*#~#g' -e "s/$(whoami)/dev.team/g" >"s12-$p.txt"
  echo "   код $? , строк $(wc -l < "s12-$p.txt")"
done
