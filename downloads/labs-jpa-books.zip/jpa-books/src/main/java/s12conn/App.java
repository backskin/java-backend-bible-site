package s12conn;

import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * Разд. 2.3 гл. 12: когда транзакция Spring + Hibernate берёт соединение из пула Hikari и когда отдаёт.
 * Число занятых соединений пула печатается до транзакции, в начале (до первого SQL), после SELECT,
 * в слушателе afterCommit и после выхода. Аргумент lazy — вариант с
 * hibernate.connection.provider_disables_autocommit=true и spring.datasource.hikari.auto-commit=false.
 */
@SpringBootApplication
public class App {

    @Entity(name = "Account") @Table(name = "account")
    public static class Account { @Id Long id; java.math.BigDecimal balance; }

    public static void main(String[] args) {
        boolean lazy = args.length > 0 && args[0].equals("lazy");
        Map<String, Object> p = new HashMap<>(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s12conn",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        if (lazy) {
            p.put("spring.datasource.hikari.auto-commit", "false");
            p.put("spring.jpa.properties.hibernate.connection.provider_disables_autocommit", "true");
        }
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(p);
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            HikariDataSource ds = ctx.getBean(HikariDataSource.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", HikariCP, H2; вариант: "
                    + (lazy ? "provider_disables_autocommit=true, hikari auto-commit=false" : "настройки по умолчанию"));
            tx.executeWithoutResult(s -> { Account a = new Account(); a.id = 1L; a.balance = java.math.BigDecimal.TEN; em.persist(a); });
            System.out.println("до транзакции: занято " + ds.getHikariPoolMXBean().getActiveConnections());
            tx.executeWithoutResult(s -> {
                System.out.println("начало транзакции, SQL ещё не было: занято " + ds.getHikariPoolMXBean().getActiveConnections());
                TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                    @Override public void afterCommit() {
                        System.out.println("afterCommit (транзакция зафиксирована): занято " + ds.getHikariPoolMXBean().getActiveConnections());
                    }
                });
                em.find(Account.class, 1L);
                System.out.println("после первого SELECT: занято " + ds.getHikariPoolMXBean().getActiveConnections());
            });
            System.out.println("после выхода из транзакции: занято " + ds.getHikariPoolMXBean().getActiveConnections());
        }
    }
}
