package s91;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import jakarta.persistence.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@SpringBootApplication
public class App {

    @Entity(name = "Account") @Table(name = "account")
    static class Account {
        @Id @GeneratedValue Long id;
        @Version long version;
        BigDecimal balance = new BigDecimal("100.00");
    }

    @Entity(name = "Orders") @Table(name = "orders")
    static class Orders {
        @Id @GeneratedValue Long id;
        @Version long version;
        @OneToMany(mappedBy = "order", cascade = CascadeType.ALL) List<Line> lines = new ArrayList<>();
        @ElementCollection List<String> tags = new ArrayList<>();
    }

    @Entity(name = "Line") @Table(name = "line")
    static class Line {
        @Id @GeneratedValue Long id;
        @ManyToOne(fetch = FetchType.LAZY) Orders order;
    }

    @Component
    static class Demo implements CommandLineRunner {
        @PersistenceContext EntityManager em;
        final TransactionTemplate tx;
        Demo(TransactionTemplate tx) { this.tx = tx; }

        @Override
        public void run(String... args) throws Exception {
            Long accId = tx.execute(s -> { Account a = new Account(); em.persist(a); return a.id; });
            Long ordId = tx.execute(s -> { Orders o = new Orders(); em.persist(o); return o.id; });

            System.out.println("--- 9.1.1 конфликт версий: две транзакции читают одну строку");
            Account stale = tx.execute(s -> em.find(Account.class, accId));      // версия 0, detached после коммита
            tx.executeWithoutResult(s -> em.find(Account.class, accId).balance = new BigDecimal("150.00"));   // версия 1
            try {
                stale.balance = new BigDecimal("999.00");
                tx.executeWithoutResult(s -> em.merge(stale));                     // merge с версией 0
            } catch (RuntimeException e) {
                System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
            }

            System.out.println("--- 9.1.2 что поднимает версию родителя");
            System.out.println("версия до:                               " + version(ordId));
            tx.executeWithoutResult(s -> { Orders o = em.find(Orders.class, ordId); Line l = new Line(); l.order = o; o.lines.add(l); });
            System.out.println("после добавления строки (mappedBy):      " + version(ordId));
            tx.executeWithoutResult(s -> em.find(Orders.class, ordId).tags.add("vip"));
            System.out.println("после добавления тега (@ElementCollection): " + version(ordId));
            tx.executeWithoutResult(s -> em.find(Orders.class, ordId, LockModeType.OPTIMISTIC_FORCE_INCREMENT));
            System.out.println("после OPTIMISTIC_FORCE_INCREMENT:        " + version(ordId));
            tx.executeWithoutResult(s -> em.find(Orders.class, ordId, LockModeType.OPTIMISTIC));
            System.out.println("после OPTIMISTIC (только чтение):        " + version(ordId));

            System.out.println("--- 9.3.1 режимы блокировки: SQL выводится в конце, из журнала сервера");
            for (LockModeType mode : List.of(LockModeType.PESSIMISTIC_READ, LockModeType.PESSIMISTIC_WRITE, LockModeType.PESSIMISTIC_FORCE_INCREMENT)) {
                tx.executeWithoutResult(s -> {
                    em.createNativeQuery("select 'MARK " + mode + "'").getSingleResult();
                    em.find(Account.class, accId, mode);
                });
            }
            System.out.println("--- 9.3.2 кто ждёт и сколько (держатель блокировки отпускает её через 5 секунд)");
            holdAndTry("PESSIMISTIC_WRITE, таймаут 500 мс", accId, 500);
            holdAndTry("PESSIMISTIC_WRITE, таймаут 0 (NOWAIT)", accId, 0);
            holdAndTry("PESSIMISTIC_WRITE, SKIP LOCKED (-2)", accId, -2);
            holdAndTry("PESSIMISTIC_WRITE, без хинта", accId, null);
        }

        long version(Long id) { return tx.execute(s -> em.find(Orders.class, id).version); }

        /** Одна транзакция держит блокировку 2 секунды; вторая пытается взять ту же строку. */
        void holdAndTry(String title, Long id, Integer timeoutMs) throws Exception {
            CountDownLatch locked = new CountDownLatch(1);
            CountDownLatch release = new CountDownLatch(1);
            Thread holder = new Thread(() -> tx.executeWithoutResult(s -> {
                em.find(Account.class, id, LockModeType.PESSIMISTIC_WRITE);
                locked.countDown();
                try { release.await(5, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            }));
            holder.start();
            locked.await();
            long t0 = System.nanoTime();
            String result;
            try {
                Map<String, Object> hints = timeoutMs == null ? Map.of() : Map.of("jakarta.persistence.lock.timeout", timeoutMs);
                if (timeoutMs != null && timeoutMs == -2) {
                    List<Account> got = tx.execute(s -> em.createQuery("select a from Account a", Account.class)
                            .setLockMode(LockModeType.PESSIMISTIC_WRITE)
                            .setHint("jakarta.persistence.lock.timeout", -2).getResultList());
                    result = "вернул " + got.size() + " строк (занятая пропущена)";
                } else {
                    Account a = tx.execute(s -> em.find(Account.class, id, LockModeType.PESSIMISTIC_WRITE, hints));
                    result = "получил строку";
                }
            } catch (RuntimeException e) {
                Throwable root = e; while (root.getCause() != null) root = root.getCause();
                result = e.getClass().getSimpleName() + " / " + root.getClass().getSimpleName();
            }
            long ms = (System.nanoTime() - t0) / 1_000_000;
            System.out.printf("%-42s -> %s, ждали %d мс%n", title, result, ms);
            release.countDown();
            holder.join();
        }
    }

    public static void main(String[] args) throws Exception {
        File log = new File("pg-server.log");
        var pg = EmbeddedPostgres.builder()
                .setServerConfig("log_statement", "all")
                .setServerConfig("logging_collector", "on")
                .setServerConfig("log_directory", new File("pglog").getAbsolutePath().replace('\\', '/'))
                .setServerConfig("log_filename", "pg.log")
                .setErrorRedirector(ProcessBuilder.Redirect.DISCARD)
                .setOutputRedirector(ProcessBuilder.Redirect.DISCARD)
                .start();
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", pg.getJdbcUrl("postgres", "postgres"),
                "spring.datasource.username", "postgres",
                "spring.datasource.password", "postgres",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        app.run(args);
        Thread.sleep(1000);                                            // сервер дописывает журнал
        System.out.println("--- SQL с блокировками из журнала PostgreSQL (log_statement = all):");
        var seen = new java.util.LinkedHashSet<String>();
        for (String line : java.nio.file.Files.readAllLines(new File("pglog/pg.log").toPath())) {
            int i = line.indexOf("LOG:  execute ");
            if (i < 0) continue;
            String sql = line.substring(line.indexOf(": ", i + 14) + 2);
            if (sql.contains("for share") || sql.contains("for no key update") || sql.contains("lock_timeout")) seen.add(sql);
        }
        seen.forEach(q -> System.out.println("  " + q));
        pg.close();
    }
}
