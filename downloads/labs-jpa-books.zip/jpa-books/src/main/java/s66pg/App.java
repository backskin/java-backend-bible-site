package s66pg;

import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.BatchSize;
import org.hibernate.resource.jdbc.spi.StatementInspector;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

@SpringBootApplication
public class App {

    /** Запоминает SQL, который уходит в базу, чтобы посчитать параметры в пачках. */
    public static class SqlSpy implements StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    @Entity(name = "Customer") @Table(name = "customer")
    static class Customer {
        @Id @GeneratedValue Long id;
        String name = "c";
        String name() { return name; }
    }

    @Entity(name = "BatchedCustomer") @Table(name = "bcustomer") @BatchSize(size = 32)
    static class BatchedCustomer {
        @Id @GeneratedValue Long id;
        String name = "c";
        String name() { return name; }
    }

    @Entity(name = "Orders") @Table(name = "orders")
    static class Orders {
        @Id @GeneratedValue Long id;
        @ManyToOne(fetch = FetchType.LAZY) Customer customer;
        @ManyToOne(fetch = FetchType.LAZY) BatchedCustomer batchedCustomer;
        @OneToMany(mappedBy = "order") List<Line> lines = new ArrayList<>();
        @OneToMany(mappedBy = "order") @BatchSize(size = 32) List<BLine> batchedLines = new ArrayList<>();
    }

    @Entity(name = "Line") @Table(name = "line")
    static class Line {
        @Id @GeneratedValue Long id;
        @ManyToOne(fetch = FetchType.LAZY) Orders order;
    }

    @Entity(name = "BLine") @Table(name = "bline")
    static class BLine {
        @Id @GeneratedValue Long id;
        @ManyToOne(fetch = FetchType.LAZY) Orders order;
    }

    @Component
    static class Demo implements CommandLineRunner {
        @PersistenceContext EntityManager em;
        final TransactionTemplate tx;
        final SessionFactory sf;

        Demo(TransactionTemplate tx, EntityManagerFactory emf) {
            this.tx = tx;
            this.sf = emf.unwrap(SessionFactory.class);
        }

        @Override
        public void run(String... args) {
            tx.executeWithoutResult(s -> {
                for (int i = 0; i < 100; i++) {
                    Customer c = new Customer(); em.persist(c);
                    BatchedCustomer b = new BatchedCustomer(); em.persist(b);
                    Orders o = new Orders();
                    o.customer = c; o.batchedCustomer = b;
                    em.persist(o);
                    Line l = new Line(); l.order = o; em.persist(l);
                    BLine bl = new BLine(); bl.order = o; em.persist(bl);
                }
            });

            report("связь ManyToOne без @BatchSize ", o -> o.customer.name());
            report("связь ManyToOne с @BatchSize(32)", o -> o.batchedCustomer.name());
            report("коллекция без @BatchSize        ", o -> o.lines.size());
            report("коллекция с @BatchSize(32)      ", o -> o.batchedLines.size());
        }

        void report(String title, java.util.function.Consumer<Orders> access) {
            SqlSpy.LOG.clear();
            tx.executeWithoutResult(s -> {
                List<Orders> list = em.createQuery("select o from Orders o", Orders.class).getResultList();
                for (Orders o : list) {
                    access.accept(o);       // обращение к данным связи заставляет Hibernate загрузить её
                }
            });
            // первый запрос - сам список; остальные - загрузка связей
            List<String> loads = SqlSpy.LOG.subList(1, SqlSpy.LOG.size());
            StringBuilder sizes = new StringBuilder();
            for (String sql : loads) sizes.append(sql.chars().filter(ch -> ch == '?').count()).append(' ');
            System.out.println(title + ": запросов всего " + SqlSpy.LOG.size()
                    + "; параметров в запросах загрузки: " + (loads.size() > 6 ? loads.size() + " раз по 1" : sizes.toString().trim()));
        }
    }

    public static void main(String[] args) throws Exception {
        var pg = io.zonky.test.db.postgres.embedded.EmbeddedPostgres.start();
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", pg.getJdbcUrl("postgres", "postgres"),
                "spring.datasource.username", "postgres",
                "spring.datasource.password", "postgres",
                "spring.jpa.hibernate.ddl-auto", "create",
                "logging.level.org.hibernate.SQL", "DEBUG",
                "logging.pattern.console", "%msg%n",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", SqlSpy.class.getName(),
                "logging.level.root", "WARN",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
