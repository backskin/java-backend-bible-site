package s1417;

import org.springframework.data.repository.Repository;
import java.util.List;

public interface PaymentRepository extends Repository<Payment, Long> {
    List<Payment> findByDocNumberAndPayerId(String docNumber, Long payerId);
}
