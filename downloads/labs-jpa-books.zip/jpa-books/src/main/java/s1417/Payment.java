package s1417;

import jakarta.persistence.*;

/** Поле docNumber переименовано в documentNo, а имя derived-метода в репозитории осталось старым. */
@Entity @Table(name = "payment")
public class Payment {
    @Id @GeneratedValue Long id;
    String documentNo;
    Long payerId;
}
