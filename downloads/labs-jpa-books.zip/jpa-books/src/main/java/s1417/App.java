package s1417;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Map;

/**
 * Разд. 14.17 гл. 12: derived-метод со старым именем поля при трёх режимах
 * spring.data.jpa.repositories.bootstrap-mode — когда падает старт, а когда первый вызов.
 */
@SpringBootApplication
public class App {
    public static void main(String[] args) {
        for (String mode : new String[]{"default", "deferred", "lazy"}) {
            SpringApplication app = new SpringApplication(App.class);
            app.setDefaultProperties(Map.of(
                    "spring.datasource.url", "jdbc:h2:mem:s1417" + mode,
                    "spring.jpa.hibernate.ddl-auto", "create",
                    "spring.data.jpa.repositories.bootstrap-mode", mode,
                    "spring.main.web-application-type", "none",
                    "logging.level.root", "OFF",
                    "spring.main.banner-mode", "off"));
            ConfigurableApplicationContext ctx;
            try {
                ctx = app.run();
            } catch (RuntimeException e) {
                System.out.println("bootstrap-mode=" + mode + ": старт упал — " + root(e));
                continue;
            }
            try (ctx) {
                System.out.println("bootstrap-mode=" + mode + ": контекст поднялся");
                try {
                    ctx.getBean(PaymentRepository.class).findByDocNumberAndPayerId("П-1", 1L);
                    System.out.println("   вызов метода прошёл");
                } catch (RuntimeException e) {
                    System.out.println("   первый вызов метода упал — " + root(e));
                }
            }
        }
    }

    static String root(Throwable e) {
        Throwable q = e;
        while (q != null && !(q instanceof org.springframework.data.repository.query.QueryCreationException)) q = q.getCause();
        Throwable c = q != null ? q : e;
        return c.getClass().getSimpleName() + ": " + String.valueOf(c.getMessage()).lines().findFirst().orElse("") + (c instanceof org.springframework.data.repository.query.QueryCreationException qc ? " [метод: " + qc.getMethod().getName() + "]" : "");
    }
}
