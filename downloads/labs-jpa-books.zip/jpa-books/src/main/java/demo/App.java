package demo;

import jakarta.persistence.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.Map;

@SpringBootApplication
public class App {

    @Entity @Table(name = "payment")
    static class Payment {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
        Long id;
        BigDecimal amount;
        String status = "NEW";

        protected Payment() {}
        Payment(BigDecimal amount) { this.amount = amount; }
    }

    @Component
    static class Demo implements CommandLineRunner {
        @PersistenceContext EntityManager em;
        final TransactionTemplate tx;
        Demo(TransactionTemplate tx) { this.tx = tx; }

        @Override
        public void run(String... args) {
            // 1. new -> persist -> изменение: один метод, ни одного save для статуса
            System.out.println("--- 1. transient -> managed, затем изменение статуса");
            Long id = tx.execute(s -> {
                Payment p = new Payment(new BigDecimal("100.00"));
                System.out.println("после new:     contains=" + em.contains(p) + ", id=" + p.id);
                em.persist(p);
                System.out.println("после persist: contains=" + em.contains(p) + ", id=" + p.id);
                p.status = "ACCEPTED";               // изменение управляемого объекта
                return p.id;
            });
            System.out.println("--- коммит выполнен");

            // 2. то же присваивание у detached-объекта не даёт UPDATE
            System.out.println("--- 2. detached: присваивание без UPDATE");
            Payment detached = tx.execute(s -> em.find(Payment.class, id));
            detached.status = "REJECTED";            // транзакции уже нет, контекст закрыт
            String inDb = tx.execute(s -> em.find(Payment.class, id).status);
            System.out.println("в базе по-прежнему: " + inDb + " (в объекте: " + detached.status + ")");

            // 3. detach, merge, remove
            System.out.println("--- 3. detach / merge / remove");
            tx.executeWithoutResult(s -> {
                Payment p = em.find(Payment.class, id);
                em.detach(p);
                System.out.println("после detach:  contains=" + em.contains(p));
                Payment m = em.merge(p);
                System.out.println("merge вернул другой объект: " + (m != p) + ", contains(m)=" + em.contains(m));
                em.remove(m);
                System.out.println("после remove:  contains(m)=" + em.contains(m));
                em.flush();
                System.out.println("после flush id в объекте остался: " + m.id);
            });

            // 4. краевые случаи: что бросает Hibernate на неверных переходах
            System.out.println("--- 4. краевые случаи");
            Payment fresh = new Payment(new BigDecimal("5.00"));
            Payment copy = tx.execute(s -> em.merge(fresh));          // merge НЕ-сохранённого объекта
            System.out.println("merge(transient): fresh.id=" + fresh.id + ", copy.id=" + copy.id + ", тот же объект: " + (fresh == copy));

            try {
                tx.executeWithoutResult(s -> em.persist(copy));       // copy уже detached, id задан
            } catch (RuntimeException e) {
                System.out.println("persist(detached): " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            try {
                tx.executeWithoutResult(s -> em.remove(copy));        // remove для detached
            } catch (RuntimeException e) {
                System.out.println("remove(detached):  " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            Object pk = em.getEntityManagerFactory().getPersistenceUnitUtil().getIdentifier(copy);
            System.out.println("getIdentifier(copy) без запроса в базу: " + pk);
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.show-sql", "true",
                "logging.level.root", "WARN",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
