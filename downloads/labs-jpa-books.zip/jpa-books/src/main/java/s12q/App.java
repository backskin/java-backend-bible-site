package s12q;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Map;

/**
 * Разд. 12.2 гл. 12, сверка с книгами: когда всплывает ошибка в тексте @Query.
 * a — JPQL без select и from (как пример @Query("Order o where ...") в Spring in Action, 6-е изд., разд. 3.3.4);
 * b — native SQL с опечаткой; c — JPQL вида «from Payment p where ...».
 */
public class App {
    public static void main(String[] args) {
        System.out.println("spring-data-jpa " + org.springframework.data.jpa.repository.JpaRepository.class.getPackage().getImplementationVersion()
                + ", hibernate-core " + org.hibernate.Version.getVersionString());
        Class<?>[] cfgs = {s12q.a.Cfg.class, s12q.b.Cfg.class, s12q.c.Cfg.class};
        String[] titles = {"a. JPQL «Payment p where …»", "b. native с опечаткой", "c. JPQL «from Payment p where …»"};
        for (int i = 0; i < cfgs.length; i++) {
            SpringApplication app = new SpringApplication(cfgs[i]);
            app.setDefaultProperties(Map.of(
                    "spring.datasource.url", "jdbc:h2:mem:s12q" + i,
                    "spring.jpa.hibernate.ddl-auto", "create",
                    "spring.main.web-application-type", "none",
                    "logging.level.root", "OFF",
                    "spring.main.banner-mode", "off"));
            System.out.println("--- " + titles[i]);
            ConfigurableApplicationContext ctx;
            try {
                ctx = app.run();
            } catch (RuntimeException e) {
                Throwable r = e; while (r.getCause() != null) r = r.getCause();
                System.out.println("старт упал: " + e.getClass().getSimpleName() + "; причина: " + r.getClass().getSimpleName() + ": "
                        + String.valueOf(r.getMessage()).lines().findFirst().orElse(""));
                continue;
            }
            System.out.println("контекст поднялся");
            Class<?> type = i == 0 ? s12q.a.Cfg.Repo.class : i == 1 ? s12q.b.Cfg.Repo.class : s12q.c.Cfg.Repo.class;
            Object repo = ctx.getBean(type);
            try {
                Object res = type.getMethod("newOnes").invoke(repo);
                System.out.println("вызов newOnes(): " + res);
            } catch (Exception e) {
                Throwable r = e; while (r.getCause() != null) r = r.getCause();
                System.out.println("вызов newOnes() упал: " + e.getCause().getClass().getSimpleName() + "; причина: "
                        + String.valueOf(r.getMessage()).lines().findFirst().orElse(""));
            }
            ctx.close();
        }
    }
}
