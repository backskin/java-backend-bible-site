package s12q.a;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import s12q.Payment;

import java.util.List;

/** Вариант a: JPQL без select и from, как в примере из книги. */
@Configuration
@EnableAutoConfiguration
@EntityScan(basePackageClasses = Payment.class)
@EnableJpaRepositories(considerNestedRepositories = true)
public class Cfg {
    public interface Repo extends JpaRepository<Payment, Long> {
        @Query("Payment p where p.status = 'NEW'")
        List<Payment> newOnes();
    }
}
