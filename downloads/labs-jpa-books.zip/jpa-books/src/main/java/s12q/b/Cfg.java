package s12q.b;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import s12q.Payment;

import java.util.List;

/** Вариант b: native SQL с опечаткой в имени таблицы. */
@Configuration
@EnableAutoConfiguration
@EntityScan(basePackageClasses = Payment.class)
@EnableJpaRepositories(considerNestedRepositories = true)
public class Cfg {
    public interface Repo extends JpaRepository<Payment, Long> {
        @Query(value = "select * from paymnt where status = 'NEW'", nativeQuery = true)
        List<Payment> newOnes();
    }
}
