package s12q;

import jakarta.persistence.*;

@Entity(name = "Payment") @Table(name = "payment")
public class Payment {
    @Id public Long id;
    public String status;
}
