package s81;

import jakarta.persistence.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.concurrent.*;

@SpringBootApplication
public class App {

    @Entity(name = "Pay") @Table(name = "pay")
    static class Pay {
        @Id @GeneratedValue Long id;
        @Column(unique = true) String ref;
        protected Pay() {}
        Pay(String ref) { this.ref = ref; }
    }

    @Service
    static class Inner {
        @PersistenceContext EntityManager em;

        String where() {
            Object sid = em.createNativeQuery("select session_id()").getSingleResult();
            return "EntityManager@" + Integer.toHexString(System.identityHashCode(em.getDelegate())) + ", соединение H2 #" + sid;
        }

        @Transactional(propagation = Propagation.REQUIRED)
        public String required() { return where(); }

        @Transactional(propagation = Propagation.REQUIRES_NEW)
        public String requiresNew() { return where(); }

        @Transactional(propagation = Propagation.REQUIRES_NEW)
        public boolean seesRequiresNew(Long id) { return em.find(Pay.class, id) != null; }

        @Transactional(propagation = Propagation.NESTED)
        public void nestedInsert(String ref) {
            em.persist(new Pay(ref));
            em.flush();
        }
    }

    @Service
    static class Outer {
        @PersistenceContext EntityManager em;
        final Inner inner;
        Outer(Inner inner) { this.inner = inner; }

        @Transactional
        public void contexts() {
            System.out.println("внешний:               " + inner.where());
            System.out.println("REQUIRED внутри:       " + inner.required());
            System.out.println("REQUIRES_NEW внутри:   " + inner.requiresNew());
        }

        @Transactional
        public void visibility(boolean flush) {
            Pay p = new Pay("V-" + flush);
            em.persist(p);
            if (flush) em.flush();
            System.out.println("создан и " + (flush ? "сброшен (flush)" : "не сброшен") + ", REQUIRES_NEW его видит: " + inner.seesRequiresNew(p.id));
        }

        @Transactional
        public void holdThenInner(CountDownLatch bothHoldConnection) throws Exception {
            em.createNativeQuery("select 1").getSingleResult();     // берём соединение внешней транзакции
            bothHoldConnection.countDown();
            bothHoldConnection.await();
            inner.requiresNew();                                      // нужно второе соединение
        }


        @Transactional
        public void nested2() {
            em.persist(new Pay("M-1"));
            em.flush();
            try {
                inner.nestedInsert("M-1");                            // дубль: нарушит уникальный индекс
            } catch (RuntimeException e) {
                System.out.println("вложенная вставка упала: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            em.persist(new Pay("M-2"));                               // продолжаем с тем же EntityManager
        }

        @Transactional
        public void catchAndContinue() {
            em.persist(new Pay("C-1"));
            em.flush();
            try {
                em.persist(new Pay("C-1"));                           // дубль
                em.flush();                                           // ошибка базы уходит сюда
            } catch (RuntimeException e) {
                System.out.println("поймали: " + e.getClass().getSimpleName());
            }
            System.out.println("после ошибки: em.isOpen()=" + em.isOpen() + ", продолжаем работать с тем же EntityManager");
            em.persist(new Pay("C-2"));
            em.flush();
            System.out.println("C-2 сброшен без ошибки, метод возвращается");
        }

        @Transactional
        public void nested() {
            em.persist(new Pay("N-1"));
            try {
                inner.nestedInsert("N-1");                            // дубль: нарушит уникальный индекс
            } catch (RuntimeException e) {
                System.out.println("вложенная вставка упала: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            System.out.println("em.isOpen()=" + em.isOpen() + ", продолжаем во внешнем методе");
            em.persist(new Pay("N-2"));
        }
    }

    @Component
    static class Demo implements CommandLineRunner {
        final Outer outer;
        @PersistenceContext EntityManager em;
        final org.springframework.orm.jpa.JpaTransactionManager ptm;
        Demo(Outer outer, org.springframework.transaction.PlatformTransactionManager ptm) {
            this.outer = outer;
            this.ptm = (org.springframework.orm.jpa.JpaTransactionManager) ptm;
        }

        @Override
        public void run(String... args) throws Exception {
            System.out.println("--- 1. контекст и соединение");
            outer.contexts();

            System.out.println("--- 2. REQUIRES_NEW и данные внешней транзакции");
            outer.visibility(false);
            outer.visibility(true);

            System.out.println("--- 3. пул из 2 соединений, 2 потока с REQUIRES_NEW");
            CountDownLatch latch = new CountDownLatch(2);
            ExecutorService pool = Executors.newFixedThreadPool(2);
            Future<?> f1 = pool.submit(() -> { outer.holdThenInner(latch); return null; });
            Future<?> f2 = pool.submit(() -> { outer.holdThenInner(latch); return null; });
            for (Future<?> f : new Future<?>[]{f1, f2}) {
                try { f.get(); System.out.println("поток завершился без ошибки"); }
                catch (ExecutionException e) {
                    Throwable root = e.getCause();
                    while (root.getCause() != null) root = root.getCause();
                    System.out.println("поток упал: " + e.getCause().getClass().getSimpleName() + " / " + root.getMessage());
                }
            }
            pool.shutdown();

            System.out.println("--- 4. NESTED по умолчанию (JpaTransactionManager без nestedTransactionAllowed)");
            try {
                outer.nested();
                System.out.println("внешняя транзакция закоммичена");
            } catch (RuntimeException e) {
                System.out.println("внешняя транзакция: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }

            System.out.println("--- 5. NESTED при nestedTransactionAllowed = true");
            ptm.setNestedTransactionAllowed(true);
            try {
                outer.nested2();
                System.out.println("внешняя транзакция закоммичена");
            } catch (RuntimeException e) {
                System.out.println("внешняя транзакция: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            long count = (long) em.createQuery("select count(p) from Pay p where p.ref like 'M-%'").getSingleResult();
            System.out.println("строк M-* в базе после блока 5: " + count);

            System.out.println("--- 6. ошибка базы поймана внутри метода, работа продолжается (без NESTED)");
            try {
                outer.catchAndContinue();
                System.out.println("внешняя транзакция закоммичена");
            } catch (RuntimeException e) {
                System.out.println("внешняя транзакция: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            long c = (long) em.createQuery("select count(p) from Pay p where p.ref like 'C-%'").getSingleResult();
            System.out.println("строк C-* в базе после блока 6: " + c);
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.datasource.hikari.maximum-pool-size", "2",
                "spring.datasource.hikari.connection-timeout", "1000",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
