package s83;

import jakarta.persistence.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.List;
import java.util.Map;

@SpringBootApplication
public class App {

    @Entity(name = "Pay") @Table(name = "pay")
    static class Pay {
        @Id @GeneratedValue Long id;
        String ref;
        protected Pay() {}
        Pay(String ref) { this.ref = ref; }
    }

    /** Бизнес-отказ в виде checked-исключения. */
    static class DeclinedException extends Exception {
        DeclinedException(String m) { super(m); }
    }

    @Service
    static class Payments {
        @PersistenceContext EntityManager em;

        @Transactional
        public void checkedDefault(String ref) throws DeclinedException {
            em.persist(new Pay(ref)); em.flush();
            throw new DeclinedException("отклонён");
        }

        @Transactional(rollbackFor = DeclinedException.class)
        public void checkedRollbackFor(String ref) throws DeclinedException {
            em.persist(new Pay(ref)); em.flush();
            throw new DeclinedException("отклонён");
        }

        @Transactional
        public void runtimeDefault(String ref) {
            em.persist(new Pay(ref)); em.flush();
            throw new IllegalStateException("сбой");
        }

        @Transactional(noRollbackFor = IllegalStateException.class)
        public void runtimeNoRollback(String ref) {
            em.persist(new Pay(ref)); em.flush();
            throw new IllegalStateException("сбой");
        }

        @Transactional(readOnly = true)
        public long count(String prefix) {
            return (long) em.createQuery("select count(p) from Pay p where p.ref like :p")
                    .setParameter("p", prefix + "%").getSingleResult();
        }
    }

    @Service
    static class Line {
        @PersistenceContext EntityManager em;

        @Transactional(propagation = Propagation.REQUIRED)
        public void required(String ref, boolean bad) {
            em.persist(new Pay(ref)); em.flush();
            if (bad) throw new IllegalArgumentException("плохая строка " + ref);
        }

        @Transactional(propagation = Propagation.REQUIRES_NEW)
        public void requiresNew(String ref, boolean bad) {
            em.persist(new Pay(ref)); em.flush();
            if (bad) throw new IllegalArgumentException("плохая строка " + ref);
        }

        @Transactional(propagation = Propagation.REQUIRED)
        public void requiredChecked(String ref, boolean bad) throws DeclinedException {
            em.persist(new Pay(ref)); em.flush();
            if (bad) throw new DeclinedException("плохая строка " + ref);
        }
    }

    @Service
    static class Registry {
        final Line line;
        Registry(Line line) { this.line = line; }

        @Transactional
        public void process(String prefix, String mode) {
            for (String n : List.of("1", "2-bad", "3")) {
                boolean bad = n.endsWith("bad");
                try {
                    switch (mode) {
                        case "required" -> line.required(prefix + n, bad);
                        case "requiresNew" -> line.requiresNew(prefix + n, bad);
                        case "checked" -> line.requiredChecked(prefix + n, bad);
                    }
                } catch (Exception e) {
                    System.out.println("    поймали " + e.getClass().getSimpleName() + ", rollbackOnly="
                            + TransactionAspectSupport.currentTransactionStatus().isRollbackOnly());
                }
            }
        }
    }

    @Component
    static class Demo implements CommandLineRunner {
        final Payments payments;
        final Registry registry;
        final JpaTransactionManager ptm;

        Demo(Payments payments, Registry registry, PlatformTransactionManager ptm) {
            this.payments = payments; this.registry = registry; this.ptm = (JpaTransactionManager) ptm;
        }

        @FunctionalInterface interface Checked { void run() throws Exception; }

        void attempt(String title, String prefix, Checked c) {
            String result;
            try { c.run(); result = "метод вернул управление"; }
            catch (Exception e) { result = "исключение " + e.getClass().getSimpleName(); }
            System.out.println(title + ": " + result + "; строк в базе: " + payments.count(prefix));
        }

        @Override
        public void run(String... args) {
            System.out.println("--- 1. правило по умолчанию и его переопределение");
            attempt("checked, по умолчанию        ", "A-", () -> payments.checkedDefault("A-1"));
            attempt("checked + rollbackFor        ", "B-", () -> payments.checkedRollbackFor("B-1"));
            attempt("runtime, по умолчанию        ", "C-", () -> payments.runtimeDefault("C-1"));
            attempt("runtime + noRollbackFor      ", "D-", () -> payments.runtimeNoRollback("D-1"));

            System.out.println("--- 2. реестр из трёх строк, средняя плохая, исключение ловится внутри транзакции");
            attempt("вложенный REQUIRED, runtime   ", "E-", () -> registry.process("E-", "required"));
            attempt("вложенный REQUIRES_NEW, runtime", "F-", () -> registry.process("F-", "requiresNew"));
            attempt("вложенный REQUIRED, checked    ", "G-", () -> registry.process("G-", "checked"));

            System.out.println("--- 3. globalRollbackOnParticipationFailure = false");
            ptm.setGlobalRollbackOnParticipationFailure(false);
            attempt("вложенный REQUIRED, runtime   ", "H-", () -> registry.process("H-", "required"));
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
