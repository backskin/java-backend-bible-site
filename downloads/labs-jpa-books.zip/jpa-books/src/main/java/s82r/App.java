package s82r;

import jakarta.persistence.EntityManager;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.LazyConnectionDataSourceProxy;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Разд. 8.2 гл. 12: LazyConnectionDataSourceProxy.setReadOnlyDataSource (Spring 6.1.2+) направляет
 * readOnly-транзакции JpaTransactionManager на отдельный пул без AbstractRoutingDataSource.
 * «Основная» и «реплика» — две базы H2 с разной меткой в таблице db_marker.
 */
@SpringBootApplication
public class App {

    static DataSource h2(String name) throws Exception {
        DataSource ds = DataSourceBuilder.create().url("jdbc:h2:mem:" + name + ";DB_CLOSE_DELAY=-1").username("sa").build();
        try (var c = ds.getConnection(); var st = c.createStatement()) {
            st.execute("create table db_marker(name varchar(20))");
            st.execute("insert into db_marker values ('" + name + "')");
        }
        return ds;
    }

    @Bean @Primary
    DataSource dataSource() throws Exception {
        LazyConnectionDataSourceProxy proxy = new LazyConnectionDataSourceProxy(h2("основная"));
        proxy.setReadOnlyDataSource(h2("реплика"));
        return proxy;
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.jpa.hibernate.ddl-auto", "none",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            PlatformTransactionManager tm = ctx.getBean(PlatformTransactionManager.class);
            TransactionTemplate rw = new TransactionTemplate(tm);
            TransactionTemplate ro = new TransactionTemplate(tm);
            ro.setReadOnly(true);
            System.out.println("spring-jdbc " + org.springframework.core.SpringVersion.getVersion() + ", hibernate-core "
                    + org.hibernate.Version.getVersionString() + ", " + tm.getClass().getSimpleName());
            String q = "select name from db_marker";
            System.out.println("обычная транзакция     → " + rw.execute(s -> em.createNativeQuery(q).getSingleResult()));
            System.out.println("readOnly = true        → " + ro.execute(s -> em.createNativeQuery(q).getSingleResult()));
            System.out.println("снова обычная          → " + rw.execute(s -> em.createNativeQuery(q).getSingleResult()));
            ro.setPropagationBehavior(TransactionTemplate.PROPAGATION_REQUIRED);
            System.out.println("readOnly внутри обычной → " + rw.execute(s -> ro.execute(s2 -> em.createNativeQuery(q).getSingleResult())));
        }
    }
}
