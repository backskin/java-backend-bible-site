package s1411;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import jakarta.persistence.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Разд. 14.11 гл. 12 на встроенном PostgreSQL 15.5: транзакция, которая простаивает дольше
 * idle_in_transaction_session_timeout (задан на роль, 1 с), пока «ждёт внешний API» (sleep 2 с).
 * Печатает журнал Hikari и Spring и цепочку исключений: А — следующий запрос после паузы (auto flush), Б — только фиксация.
 */
@SpringBootApplication
public class App {

    @Entity(name = "Operation") @Table(name = "operation")
    public static class Operation {
        @Id Long id;
        BigDecimal amount;
        String status;
    }

    public static void main(String[] args) throws Exception {
        java.util.Locale.setDefault(java.util.Locale.ROOT);
        var pg = EmbeddedPostgres.builder()
                .setErrorRedirector(ProcessBuilder.Redirect.DISCARD)
                .setOutputRedirector(ProcessBuilder.Redirect.DISCARD).start();
        try (var c = pg.getPostgresDatabase().getConnection(); var st = c.createStatement()) {
            st.execute("create role recon_app login password 'recon'");
            st.execute("alter role recon_app set idle_in_transaction_session_timeout = '1s'");
            st.execute("create table operation (id bigint primary key, amount numeric(19,2), status varchar(20))");
            st.execute("insert into operation select g, g * 10, 'NEW' from generate_series(1, 5) g");
            st.execute("grant select, update on operation to recon_app");
        }
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.ofEntries(
                Map.entry("spring.datasource.url", pg.getJdbcUrl("recon_app", "postgres")),
                Map.entry("spring.datasource.username", "recon_app"),
                Map.entry("spring.datasource.password", "recon"),
                Map.entry("spring.datasource.hikari.maximum-pool-size", "2"),
                Map.entry("spring.jpa.hibernate.ddl-auto", "none"),
                Map.entry("spring.jpa.open-in-view", "false"),
                Map.entry("spring.main.web-application-type", "none"),
                Map.entry("spring.main.banner-mode", "off"),
                Map.entry("logging.pattern.console", "LOG [%logger{0}] %level %msg%n%ex{short}"),
                Map.entry("logging.level.root", "OFF"),
                Map.entry("logging.level.org.springframework.transaction.support.TransactionTemplate", "ERROR"),
                Map.entry("logging.level.org.hibernate", "WARN"),
                Map.entry("logging.level.com.zaxxer.hikari", "WARN")));
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", PostgreSQL 15.5, idle_in_transaction_session_timeout = 1s на роли recon_app");
            try {
                tx.executeWithoutResult(t -> {
                    var ops = em.createQuery("select o from Operation o order by o.id", Operation.class).getResultList();
                    System.out.println("А. изменение и запрос после паузы; порция загружена: " + ops.size() + " операций; ждём «API эквайрера» 2 с внутри транзакции");
                    sleep(2000);
                    ops.get(0).status = "CONFIRMED";
                    em.createQuery("select count(o) from Operation o", Long.class).getSingleResult();
                });
                System.out.println("транзакция зафиксирована");
            } catch (Exception e) {
                System.out.println("исключение на выходе из транзакции:");
                for (Throwable x = e; x != null; x = x.getCause()) System.out.println("  " + x.getClass().getName() + ": " + firstLine(x.getMessage()));
            }
            try {
                tx.executeWithoutResult(t -> {
                    var ops = em.createQuery("select o from Operation o order by o.id", Operation.class).getResultList();
                    System.out.println("Б. изменение после паузы, дальше только фиксация; порция загружена: " + ops.size() + " операций; ждём «API эквайрера» 2 с внутри транзакции");
                    sleep(2000);
                    ops.get(0).status = "CONFIRMED";
                });
                System.out.println("транзакция зафиксирована");
            } catch (Exception e) {
                System.out.println("исключение на выходе из транзакции:");
                for (Throwable x = e; x != null; x = x.getCause()) System.out.println("  " + x.getClass().getName() + ": " + firstLine(x.getMessage()));
            }
            try {
                Long n = tx.execute(t -> em.createQuery("select count(o) from Operation o", Long.class).getSingleResult());
                System.out.println("следующая транзакция на том же пуле: count = " + n);
            } catch (Exception e) {
                System.out.println("следующая транзакция: " + e.getClass().getName() + ": " + firstLine(e.getMessage()));
            }
        }
        pg.close();
    }

    static String firstLine(String s) { return s == null ? "" : s.lines().findFirst().orElse(""); }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); } }
}
