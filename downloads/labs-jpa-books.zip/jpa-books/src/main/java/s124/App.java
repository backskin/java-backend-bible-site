package s124;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.domain.*;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Supplier;

/**
 * Разд. 12.4 гл. 12: Page, Slice, List и Window на Spring Data JPA 4.1.1 — какие запросы уходят в базу
 * и работает ли прокрутка (scroll) для запроса из @Query.
 */
@SpringBootApplication
public class App {

    /** Вложенный интерфейс Spring Boot не сканирует: его создаём вручную. */
    interface ScrollByQuery extends org.springframework.data.repository.Repository<Payment, Long> {
        @org.springframework.data.jpa.repository.Query("select p from Payment p where p.payerId = :payerId")
        Window<Payment> scrollByQuery(Long payerId, ScrollPosition position, Sort sort, Limit limit);
    }

    /** Запоминает SQL, который Hibernate отправляет в базу. */
    public static class Spy implements org.hibernate.resource.jdbc.spi.StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s124",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", Spy.class.getName(),
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            PaymentRepository repo = ctx.getBean(PaymentRepository.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("spring-data-jpa " + org.springframework.data.jpa.repository.JpaRepository.class.getPackage().getImplementationVersion()
                    + ", hibernate-core " + org.hibernate.Version.getVersionString());
            Instant t0 = Instant.parse("2026-10-01T09:00:00Z");
            tx.executeWithoutResult(s -> {
                for (int i = 0; i < 95; i++)   // у каждой пятой пары одинаковое время: нужен второй ключ сортировки
                    repo.save(new Payment(42L, "PAID", t0.plusSeconds(60L * (i / 2)), BigDecimal.valueOf(100 + i)));
            });
            PageRequest p = PageRequest.of(0, 20, Sort.by("createdAt").descending());
            show("Page", () -> { var r = repo.findByPayerId(42L, p); return r.getNumberOfElements() + " строк, всего " + r.getTotalElements(); });
            show("Slice", () -> { var r = repo.findSliceByPayerId(42L, p); return r.getNumberOfElements() + " строк, hasNext=" + r.hasNext(); });
            show("List + Pageable", () -> repo.findListByPayerId(42L, p).size() + " строк");
            show("Page, последняя страница", () -> { var r = repo.findByPayerId(42L, PageRequest.of(4, 20)); return r.getNumberOfElements() + " строк, всего " + r.getTotalElements(); });

            System.out.println("-- keyset через Window: проход по всей выписке");
            Window<Payment> w = tx.execute(s -> repo.findFirst20ByPayerIdOrderByCreatedAtDescIdDesc(42L, ScrollPosition.keyset()));
            int pages = 1, rows = w.size();
            var seen = new java.util.HashSet<Long>();
            w.forEach(x -> seen.add(x.getId()));
            Spy.LOG.clear();
            while (w.hasNext()) {
                ScrollPosition next = w.positionAt(w.size() - 1);
                w = repo.findFirst20ByPayerIdOrderByCreatedAtDescIdDesc(42L, next);
                pages++; rows += w.size(); w.forEach(x -> seen.add(x.getId()));
            }
            System.out.println("   окон " + pages + ", строк " + rows + ", различных id " + seen.size());
            System.out.println("   SQL второго окна: " + Spy.LOG.get(0));

            System.out.println("-- keyset через Specification и FluentQuery.scroll");
            org.springframework.data.jpa.domain.Specification<Payment> byPayer = (root, q, cb) -> cb.equal(root.get("payerId"), 42L);
            Sort keyset = Sort.by(Sort.Order.desc("createdAt"), Sort.Order.desc("id"));
            Window<Payment> sw = repo.findBy(byPayer, q -> q.limit(20).sortBy(keyset).scroll(ScrollPosition.keyset()));
            int sp = 1, sr = sw.size();
            var sseen = new java.util.HashSet<Long>(); sw.forEach(x -> sseen.add(x.getId()));
            while (sw.hasNext()) {
                ScrollPosition pos = sw.positionAt(sw.size() - 1);
                sw = repo.findBy(byPayer, q -> q.limit(20).sortBy(keyset).scroll(pos));
                sp++; sr += sw.size(); sw.forEach(x -> sseen.add(x.getId()));
            }
            System.out.println("   окон " + sp + ", строк " + sr + ", различных id " + sseen.size());
            System.out.println("-- прокрутка запроса из @Query: репозиторий создаётся отдельно, чтобы не уронить контекст");
            show("@Query, возвращающий Window", () -> {
                var em = ctx.getBean(jakarta.persistence.EntityManager.class);
                new org.springframework.data.jpa.repository.support.JpaRepositoryFactory(em).getRepository(ScrollByQuery.class);
                return "репозиторий создан";
            });
        }
    }

    static void show(String title, Supplier<String> call) {
        Spy.LOG.clear();
        try {
            String r = call.get();
            System.out.printf("%-34s → %s; запросов %d%n", title, r, Spy.LOG.size());
            Spy.LOG.forEach(q -> System.out.println("      " + q));
        } catch (RuntimeException e) {
            Throwable c = e; while (c.getCause() != null && c.getCause() != c) c = c.getCause();
            System.out.printf("%-34s → %s: %s%n", title, c.getClass().getSimpleName(), String.valueOf(c.getMessage()).lines().findFirst().orElse(""));
        }
    }
}
