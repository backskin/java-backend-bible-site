package s124;

import org.springframework.data.domain.*;
import org.springframework.data.repository.Repository;

import java.util.List;

public interface PaymentRepository extends Repository<Payment, Long>, org.springframework.data.jpa.repository.JpaSpecificationExecutor<Payment> {
    Page<Payment> findByPayerId(Long payerId, Pageable pageable);
    Slice<Payment> findSliceByPayerId(Long payerId, Pageable pageable);
    List<Payment> findListByPayerId(Long payerId, Pageable pageable);

    Window<Payment> findFirst20ByPayerIdOrderByCreatedAtDescIdDesc(Long payerId, ScrollPosition position);

    void save(Payment p);
}
