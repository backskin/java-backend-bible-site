package s124;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

/** Платёж клиента: выписку листают по created_at desc, id desc. */
@Entity @Table(name = "payment")
public class Payment {
    @Id @GeneratedValue(strategy = GenerationType.SEQUENCE) Long id;
    Long payerId;
    String status;
    Instant createdAt;
    BigDecimal amount;
    protected Payment() {}
    Payment(Long payerId, String status, Instant createdAt, BigDecimal amount) {
        this.payerId = payerId; this.status = status; this.createdAt = createdAt; this.amount = amount;
    }
    public Long getId() { return id; }
    public Instant getCreatedAt() { return createdAt; }
}
