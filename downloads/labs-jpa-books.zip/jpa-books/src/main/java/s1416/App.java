package s1416;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import jakarta.persistence.*;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.Map;
import java.util.function.Function;

/**
 * Разд. 10.9 и 14.16 гл. 12 на встроенном PostgreSQL 15.5: сколько кучи занято, когда курсор Hibernate отдал первую строку
 * выгрузки из 300 000 платежей, — при четырёх сочетаниях ScrollMode, fetch size и транзакции stateless-сессии.
 */
@SpringBootApplication
public class App {

    @Entity(name = "RegPayment") @Table(name = "reg_payment")
    public static class RegPayment {
        @Id Long id;
        BigDecimal amount;
        String purpose;
    }

    public static void main(String[] args) throws Exception {
        var pg = EmbeddedPostgres.builder()
                .setErrorRedirector(ProcessBuilder.Redirect.DISCARD).setOutputRedirector(ProcessBuilder.Redirect.DISCARD).start();
        try (var c = pg.getPostgresDatabase().getConnection(); var st = c.createStatement()) {
            st.execute("create table reg_payment (id bigint primary key, amount numeric(19,2), purpose varchar(255))");
            st.execute("insert into reg_payment select g, g * 1.5, 'Оплата по договору № ' || g || ' от 01.10.2026, НДС не облагается' from generate_series(1, 300000) g");
        }
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", pg.getJdbcUrl("postgres", "postgres"),
                "spring.datasource.username", "postgres",
                "spring.datasource.password", "postgres",
                "spring.jpa.hibernate.ddl-auto", "none",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            SessionFactory sf = ctx.getBean(EntityManagerFactory.class).unwrap(SessionFactory.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", PostgreSQL 15.5, 300 000 строк; "
                    + "defaultScrollMode() диалекта = " + sf.unwrap(org.hibernate.engine.spi.SessionFactoryImplementor.class).getJdbcServices().getDialect().defaultScrollMode());
            Function<StatelessSession, ScrollableResults<RegPayment>> fwd = ss -> ss.createQuery("from RegPayment order by id", RegPayment.class)
                    .setFetchSize(1000).setReadOnly(true).scroll(ScrollMode.FORWARD_ONLY);
            Function<StatelessSession, ScrollableResults<RegPayment>> noArg = ss -> ss.createQuery("from RegPayment order by id", RegPayment.class)
                    .setFetchSize(1000).setReadOnly(true).scroll();
            measure("рецепт 10.9: FORWARD_ONLY, fetch 1000, ss.beginTransaction()", () -> withOwnTx(sf, fwd));
            measure("scroll() без аргумента, fetch 1000, ss.beginTransaction()", () -> withOwnTx(sf, noArg));
            measure("FORWARD_ONLY, fetch 1000, без транзакции сессии (autocommit)", () -> noTx(sf, fwd));
            measure("как в 14.16: scroll() без аргумента внутри @Transactional", () -> tx.execute(s -> noTx(sf, noArg)));
        }
        pg.close();
    }

    /** Возвращает прирост кучи в момент, когда отдана первая строка, в мегабайтах. */
    static long withOwnTx(SessionFactory sf, Function<StatelessSession, ScrollableResults<RegPayment>> q) {
        try (StatelessSession ss = sf.openStatelessSession()) {
            var t = ss.beginTransaction();
            long mb = firstRow(ss, q);
            t.commit();
            return mb;
        }
    }

    static long noTx(SessionFactory sf, Function<StatelessSession, ScrollableResults<RegPayment>> q) {
        try (StatelessSession ss = sf.openStatelessSession()) { return firstRow(ss, q); }
    }

    static long firstRow(StatelessSession ss, Function<StatelessSession, ScrollableResults<RegPayment>> q) {
        long before = used();
        try (var rows = q.apply(ss)) {
            rows.next();
            return (used() - before) / (1024 * 1024);
        }
    }

    static long used() {
        for (int i = 0; i < 3; i++) System.gc();
        Runtime r = Runtime.getRuntime();
        return r.totalMemory() - r.freeMemory();
    }

    static void measure(String title, java.util.function.Supplier<Long> run) {
        System.out.printf("%-66s → куча на первой строке +%d МБ%n", title, run.get());
    }
}
