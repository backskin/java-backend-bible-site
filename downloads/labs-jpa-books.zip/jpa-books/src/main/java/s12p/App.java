package s12p;

import jakarta.persistence.*;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.lang.reflect.Method;
import java.util.*;

/**
 * Разд. 1.1, 3.4, 5.3, 6.1 гл. 12: сверка утверждений книги Tudose (гл. 10, 12) с Hibernate 7.4.
 * 1) инициализирует ли getId() прокси, если @Id стоит на поле (книга, с. 334: «инициализирует»);
 * 2) какой класс у прокси и у ленивой коллекции (книга: org.hibernate.collection.internal.PersistentSet);
 * 3) есть ли в Session методы save/update/saveOrUpdate и класс HibernateProxyHelper;
 * 4) EAGER по умолчанию у @ManyToOne и прокси final-класса.
 */
@SpringBootApplication
public class App {

    @Entity(name = "Client") @Table(name = "client")
    public static class Client {
        @Id Long id;                       // доступ через поле: аннотация на поле
        String name;
        @OneToMany(mappedBy = "client") Set<Payment> payments = new HashSet<>();
        public Long getId() { return id; }
        public String getName() { return name; }
        public Set<Payment> getPayments() { return payments; }
    }

    @Entity(name = "Payment") @Table(name = "payment")
    public static class Payment {
        @Id Long id;
        @ManyToOne(fetch = FetchType.LAZY) Client client;
        @ManyToOne Client payer;           // без fetch: по спецификации EAGER
        public Client getClient() { return client; }
        public Client getPayer() { return payer; }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s12p",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.show-sql", "true",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", JDK " + Runtime.version());
            tx.executeWithoutResult(s -> {
                Client c = new Client(); c.id = 42L; c.name = "ООО Ромашка"; em.persist(c);
                Payment p = new Payment(); p.id = 1L; p.client = c; p.payer = c; em.persist(p);
            });

            System.out.println("--- 1. getReference и getId() при @Id на поле");
            tx.executeWithoutResult(s -> {
                Client ref = em.getReference(Client.class, 42L);
                System.out.println("класс прокси: " + ref.getClass().getName());
                System.out.println("Hibernate.getClassLazy: " + Hibernate.getClassLazy(ref).getName());
                System.out.println("ref instanceof Client = " + (ref instanceof Client) + ", ref.getClass() == Client.class = " + (ref.getClass() == Client.class));
                Long id = ref.getId();
                System.out.println("после getId()=" + id + " инициализирован = " + Hibernate.isInitialized(ref));
                String n = ref.getName();
                System.out.println("после getName()=" + n + " инициализирован = " + Hibernate.isInitialized(ref));
            });

            System.out.println("--- 2. find(Payment): EAGER payer и LAZY client");
            tx.executeWithoutResult(s -> {
                em.clear();
                Payment p = em.find(Payment.class, 1L);
                System.out.println("payer инициализирован = " + Hibernate.isInitialized(p.getPayer()) + ", client (тот же объект) = " + Hibernate.isInitialized(p.getClient()));
            });

            System.out.println("--- 3. класс ленивой коллекции");
            tx.executeWithoutResult(s -> {
                em.clear();
                Client c = em.find(Client.class, 42L);
                System.out.println("payments: " + c.getPayments().getClass().getName() + ", загружена = " + Hibernate.isInitialized(c.getPayments()));
                c.getPayments().size();
                System.out.println("после size(): загружена = " + Hibernate.isInitialized(c.getPayments()));
            });

            System.out.println("--- 5. remove(getReference(...)): есть ли SELECT перед DELETE (книга Tudose, с. 280: «executes a SELECT»)");
            tx.executeWithoutResult(s -> {
                em.clear();
                Payment ref = em.getReference(Payment.class, 1L);
                em.remove(ref);
                System.out.println("после remove: прокси инициализирован = " + Hibernate.isInitialized(ref));
            });
            System.out.println("--- 6. remove(getReference(...)) у сущности с коллекцией (Client.payments)");
            tx.executeWithoutResult(s -> {
                em.clear();
                Client ref = em.getReference(Client.class, 42L);
                em.remove(ref);
                System.out.println("после remove: прокси инициализирован = " + Hibernate.isInitialized(ref));
            });
            System.out.println("--- 4. методы Session и классы из книг");
            Set<String> names = new TreeSet<>();
            for (Method m : Session.class.getMethods()) names.add(m.getName());
            for (String m : List.of("save", "update", "saveOrUpdate", "replicate", "merge", "persist", "lock", "refresh"))
                System.out.println("Session." + m + ": " + (names.contains(m) ? "есть" : "нет"));
            for (String cls : List.of("org.hibernate.proxy.HibernateProxyHelper", "org.hibernate.annotations.LazyCollection",
                    "org.hibernate.collection.internal.PersistentSet", "org.hibernate.collection.spi.PersistentSet")) {
                try {
                    Class<?> k = Class.forName(cls);
                    System.out.println(cls + ": есть" + (k.isAnnotationPresent(Deprecated.class) ? " (@Deprecated)" : ""));
                } catch (ClassNotFoundException e) {
                    System.out.println(cls + ": нет");
                }
            }
        }
    }
}
