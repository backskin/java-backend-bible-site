package s1410;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity @Table(name = "account")
class Account {
    @Id Long id;
    @OneToMany(mappedBy = "account", cascade = CascadeType.PERSIST) List<Payment> payments = new ArrayList<>();
    protected Account() {}
    Account(Long id) { this.id = id; }
}

@Entity @Table(name = "payment")
class Payment {
    @Id Long id;
    @ManyToOne(fetch = FetchType.LAZY) Account account;
    protected Payment() {}
    Payment(Long id, Account a) { this.id = id; this.account = a; }
}
