package s1410;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.Map;

/** Разд. 7.4 и 14.10 гл. 12: сущность передана в @Async-метод, а транзакция, загрузившая её, уже зафиксирована. */
@SpringBootApplication @EnableAsync
public class App {
    public static void main(String[] args) throws Exception {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s1410",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            var em = ctx.getBean(jakarta.persistence.EntityManager.class);
            ctx.getBean(TransactionTemplate.class).executeWithoutResult(s -> {
                Account a = new Account(1L);
                for (long i = 1; i <= 5; i++) a.payments.add(new Payment(i, a));
                em.persist(a);
            });
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString());
            System.out.println("асинхронный поток обратился к коллекции через 300 мс, транзакция уже зафиксирована → "
                    + ctx.getBean(AccountCloser.class).close(1L, 300).get());
        }
    }
}
