package s1410;

import jakarta.persistence.EntityManager;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.CompletableFuture;

@Service
class StatementBuilder {
    /** Формирование выписки в другом потоке; получает сущность — так было в инциденте. */
    @Async
    public CompletableFuture<String> build(Account account, long delayMs) {
        try { Thread.sleep(delayMs); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        try {
            return CompletableFuture.completedFuture("платежей в выписке: " + account.payments.size() + " (поток " + Thread.currentThread().getName() + ")");
        } catch (RuntimeException e) {
            return CompletableFuture.completedFuture(e.getClass().getSimpleName() + ": " + e.getMessage() + " (поток " + Thread.currentThread().getName() + ")");
        }
    }
}

@Service
class AccountCloser {
    final EntityManager em;
    final StatementBuilder builder;
    AccountCloser(EntityManager em, StatementBuilder builder) { this.em = em; this.builder = builder; }

    @Transactional
    public CompletableFuture<String> close(Long id, long asyncDelayMs) {
        Account a = em.find(Account.class, id);
        return builder.build(a, asyncDelayMs);   // сущность пересекает границу потока
    }
}
