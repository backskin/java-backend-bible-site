package s61;

import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@SpringBootApplication
public class App {

    @Entity(name = "Customer") @Table(name = "customer")
    static class Customer {
        @Id @GeneratedValue Long id;
        String name;
        protected Customer() {}
        Customer(String name) { this.name = name; }
        String name() { return name; }
    }

    @Entity(name = "Orders") @Table(name = "orders")
    static class Orders {
        @Id @GeneratedValue Long id;
        String status = "NEW";
        @ManyToOne(fetch = FetchType.LAZY) Customer customer;
        @OneToMany(mappedBy = "order", cascade = CascadeType.PERSIST) List<Line> lines = new ArrayList<>();
        @ElementCollection @CollectionTable(name = "order_tag") List<String> tags = new ArrayList<>();
    }

    @Entity(name = "Line") @Table(name = "line")
    static class Line {
        @Id @GeneratedValue Long id;
        @ManyToOne(fetch = FetchType.LAZY) Orders order;
        int qty = 1;
    }

    @Entity(name = "EagerOrder") @Table(name = "eager_order")
    static class EagerOrder {
        @Id @GeneratedValue Long id;
        @ManyToOne(fetch = FetchType.EAGER) Customer customer;
    }

    @Component
    static class Demo implements CommandLineRunner {
        @PersistenceContext EntityManager em;
        final TransactionTemplate tx;
        final SessionFactory sf;

        final LoggingSystem logging;

        Demo(TransactionTemplate tx, EntityManagerFactory emf, LoggingSystem logging) {
            this.tx = tx;
            this.logging = logging;
            this.sf = emf.unwrap(SessionFactory.class);
        }

        long count(Runnable r) {
            sf.getStatistics().clear();
            r.run();
            return sf.getStatistics().getPrepareStatementCount();
        }

        void seed(int customers, int orders) {
            tx.executeWithoutResult(s -> {
                em.createQuery("delete from Line").executeUpdate();
                em.createNativeQuery("delete from order_tag").executeUpdate();
                em.createQuery("delete from Orders").executeUpdate();
                em.createQuery("delete from EagerOrder").executeUpdate();
                em.createQuery("delete from Customer").executeUpdate();
                List<Customer> cs = new ArrayList<>();
                for (int i = 0; i < customers; i++) { Customer c = new Customer("client-" + i); em.persist(c); cs.add(c); }
                for (int i = 0; i < orders; i++) {
                    Orders o = new Orders();
                    o.customer = cs.get(i % customers);
                    for (int k = 0; k < 3; k++) { Line l = new Line(); l.order = o; o.lines.add(l); }
                    o.tags.add("a"); o.tags.add("b");
                    em.persist(o);
                    EagerOrder e = new EagerOrder();
                    e.customer = cs.get(i % customers);
                    if (i < 4) em.persist(e);
                }
            });
        }

        @Override
        public void run(String... args) {
            // --- 6.1: N+1 и число различных родителей
            for (int[] cfg : new int[][]{{10, 100}, {100, 100}}) {
                seed(cfg[0], cfg[1]);
                long q = tx.execute(s -> count(() ->
                        em.createQuery("select o from Orders o", Orders.class).getResultList()
                                .forEach(o -> o.customer.name().length())));
                System.out.println("N+1: " + cfg[1] + " поручений, " + cfg[0] + " разных клиентов -> запросов: " + q);
            }


            // прокси: прямое чтение поля вместо метода
            tx.executeWithoutResult(s -> {
                Orders o = em.createQuery("select o from Orders o", Orders.class).setMaxResults(1).getSingleResult();
                System.out.println("прокси: поле customer.name = " + o.customer.name + ", метод name() = " + o.customer.name());
            });
            seed(10, 100);
            long eagerJpql = tx.execute(s -> count(() -> em.createQuery("select e from EagerOrder e", EagerOrder.class).getResultList()));
            Long anyEager = tx.execute(s -> em.createQuery("select min(e.id) from EagerOrder e", Long.class).getSingleResult());
            long eagerFind = tx.execute(s -> count(() -> em.find(EagerOrder.class, anyEager)));
            System.out.println("EAGER: JPQL по 4 поручениям с 4 разными клиентами -> запросов: " + eagerJpql + "; find одного -> запросов: " + eagerFind);

            long collSize = tx.execute(s -> count(() ->
                    em.createQuery("select o from Orders o where o.id in (select min(x.id) from Orders x)", Orders.class)
                            .getResultList().forEach(o -> o.lines.size())));
            long collSizeAll = tx.execute(s -> count(() ->
                    em.createQuery("select o from Orders o", Orders.class).getResultList().forEach(o -> o.lines.size())));
            System.out.println("size() коллекции: одно поручение -> " + collSize + " запроса; все 100 -> " + collSizeAll + " запросов");

            // --- 6.3: JOIN FETCH
            long fetchOne = tx.execute(s -> count(() ->
                    em.createQuery("select o from Orders o join fetch o.customer", Orders.class).getResultList()
                            .forEach(o -> o.customer.name().length())));
            System.out.println("join fetch customer: запросов: " + fetchOne);

            try {
                tx.executeWithoutResult(s ->
                        em.createQuery("select o from Orders o join fetch o.lines join fetch o.tags", Orders.class).getResultList());
            } catch (RuntimeException e) {
                Throwable root = e; while (root.getCause() != null) root = root.getCause();
                System.out.println("два bag-а: " + e.getClass().getSimpleName() + " (причина: " + root.getClass().getSimpleName() + "): " + root.getMessage());
            }

            long rows = tx.execute(s -> (long) em.createQuery(
                    "select o.id, l.id, t from Orders o join o.lines l join o.tags t", Object[].class).getResultList().size());
            System.out.println("строк в результате join lines x tags: " + rows + " (поручений 100, строк 3, меток 2)");

            System.out.println("--- пагинация с join fetch коллекции (включаем лог SQL)");
            logging.setLogLevel("org.hibernate.SQL", LogLevel.DEBUG);
            for (String jpql : List.of(
                    "select o from Orders o join fetch o.lines order by o.id",
                    "select o from Orders o left join fetch o.lines order by o.id",
                    "select o from Orders o join fetch o.lines")) {
                List<Orders> page = tx.execute(s -> {
                    sf.getStatistics().clear();
                    List<Orders> r = em.createQuery(jpql, Orders.class).setFirstResult(10).setMaxResults(5).getResultList();
                    r.forEach(o -> o.lines.size());
                    return r;
                });
                System.out.println(jpql + " -> поручений: " + page.size() + ", строк у первого: " + page.get(0).lines.size()
                        + ", запросов: " + sf.getStatistics().getPrepareStatementCount());
            }
            List<Orders> mem = tx.execute(s -> em.createQuery("select o from Orders o join fetch o.lines order by o.id", Orders.class)
                    .setHint("org.hibernate.limitInMemory", true).setFirstResult(10).setMaxResults(5).getResultList());
            System.out.println("с хинтом org.hibernate.limitInMemory -> поручений: " + mem.size() + " (в SQL выше нет offset/fetch first: лимит применён в памяти)");
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.properties.hibernate.generate_statistics", "true",
                "logging.level.root", "WARN",
                "logging.pattern.console", "%msg%n",
                "logging.level.org.hibernate.engine.internal.StatisticalLoggingSessionEventListener", "OFF",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
