package s83b;

import jakarta.persistence.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.RollbackOn;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@SpringBootApplication
public class App {

    @Entity(name = "Pay") @Table(name = "pay")
    static class Pay {
        @Id @GeneratedValue Long id;
        String ref;
        protected Pay() {}
        Pay(String ref) { this.ref = ref; }
    }

    static class DeclinedException extends Exception {
        DeclinedException(String m) { super(m); }
    }

    @Configuration
    @EnableTransactionManagement(rollbackOn = RollbackOn.ALL_EXCEPTIONS)
    static class TxConfig {}

    @Service
    static class Payments {
        @PersistenceContext EntityManager em;

        @Transactional
        public void checkedDefault(String ref) throws DeclinedException {
            em.persist(new Pay(ref)); em.flush();
            throw new DeclinedException("отклонён");
        }

        @Transactional(readOnly = true)
        public long count() { return (long) em.createQuery("select count(p) from Pay p").getSingleResult(); }
    }

    @Component
    static class Demo implements CommandLineRunner {
        final Payments payments;
        Demo(Payments payments) { this.payments = payments; }

        @Override
        public void run(String... args) {
            try { payments.checkedDefault("A-1"); }
            catch (Exception e) { System.out.println("исключение " + e.getClass().getSimpleName()); }
            System.out.println("rollbackOn = ALL_EXCEPTIONS: checked-исключение без rollbackFor, строк в базе: " + payments.count());
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
