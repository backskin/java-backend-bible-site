package s72;

import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;

@SpringBootApplication
public class App {

    @Entity(name = "Customer") @Table(name = "customer")
    static class Customer {
        @Id @GeneratedValue Long id;
        String name = "client";
        public String getName() { return name; }
    }

    @Entity(name = "Orders") @Table(name = "orders")
    static class Orders {
        @Id @GeneratedValue Long id;
        @ManyToOne(fetch = FetchType.LAZY) Customer customer;
        public Long getId() { return id; }
        public Customer getCustomer() { return customer; }
    }

    record OrderDto(Long id, String customer) {}

    @Service
    static class OrderService {
        @PersistenceContext EntityManager em;

        @Transactional
        public void seed() {
            for (int i = 0; i < 20; i++) {
                Customer c = new Customer(); em.persist(c);
                Orders o = new Orders(); o.customer = c; em.persist(o);
            }
        }

        @Transactional(readOnly = true)
        public List<Orders> findAll() {
            return em.createQuery("select o from Orders o", Orders.class).getResultList();
        }
    }

    @RestController
    static class OrderController {
        final OrderService service;
        final DataSource ds;
        final SessionFactory sf;

        OrderController(OrderService service, DataSource ds, EntityManagerFactory emf) {
            this.service = service; this.ds = ds; this.sf = emf.unwrap(SessionFactory.class);
        }

        /** DTO собирается в контроллере из ленивого графа: типичная ошибка, которую прячет OSIV. */
        @GetMapping("/orders")
        List<OrderDto> orders() {
            sf.getStatistics().clear();
            List<OrderDto> dto = service.findAll().stream()
                    .map(o -> new OrderDto(o.getId(), o.getCustomer().getName())).toList();
            System.out.println("    запросов к базе за один HTTP-запрос: " + sf.getStatistics().getPrepareStatementCount());
            return dto;
        }

        /** Сервис уже отработал; контроллер "долго пишет ответ" и смотрит, сколько соединений занято. */
        @GetMapping("/slow")
        String slow() throws InterruptedException {
            service.findAll();
            Thread.sleep(300);
            int active = ((HikariDataSource) ds).getHikariPoolMXBean().getActiveConnections();
            return "занято соединений после выхода из сервиса: " + active;
        }
    }

    @RestControllerAdvice
    static class Errors {
        @ExceptionHandler(Exception.class)
        ResponseEntity<String> handle(Exception e) {
            System.out.println("    исключение: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            return ResponseEntity.status(500).body("error");
        }
    }

    public static void main(String[] args) throws Exception {
        for (boolean osiv : new boolean[]{true, false}) {
            System.out.println("=== spring.jpa.open-in-view=" + osiv);
            try (ConfigurableApplicationContext ctx = run(osiv)) {
                ctx.getBean(OrderService.class).seed();
                String base = "http://localhost:" + ctx.getEnvironment().getProperty("local.server.port");
                HttpClient http = HttpClient.newHttpClient();
                for (String path : List.of("/orders", "/slow")) {
                    HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(base + path)).build(),
                            HttpResponse.BodyHandlers.ofString());
                    String body = r.body().length() > 70 ? r.body().substring(0, 70) + "..." : r.body();
                    System.out.println("GET " + path + " -> HTTP " + r.statusCode() + ": " + body);
                }
            }
        }
    }

    static ConfigurableApplicationContext run(boolean osiv) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo" + osiv,
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", String.valueOf(osiv),
                "spring.jpa.properties.hibernate.generate_statistics", "true",
                "server.port", "0",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        return app.run();
    }
}
