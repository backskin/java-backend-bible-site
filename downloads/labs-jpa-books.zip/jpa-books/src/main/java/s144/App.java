package s144;

import jakarta.persistence.EntityManager;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Разд. 14.4 гл. 12: persist нового исполнителя и сразу bulk-UPDATE заявок со ссылкой на него.
 * Уходит ли INSERT раньше UPDATE (автоматический flush перед запросом) для JPQL и native, и что меняет откат в конце, как в тесте.
 */
@SpringBootApplication
public class App {

    public static class Spy implements org.hibernate.resource.jdbc.spi.StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    public static void main(String[] args) throws Exception {
        boolean pgDeferred = List.of(args).contains("pg-deferred");
        io.zonky.test.db.postgres.embedded.EmbeddedPostgres pg = null;
        var props = new java.util.HashMap<String, Object>();
        if (pgDeferred) {   // PostgreSQL 15.5, схема из «миграции» с отложенной проверкой внешнего ключа
            pg = io.zonky.test.db.postgres.embedded.EmbeddedPostgres.builder()
                    .setErrorRedirector(ProcessBuilder.Redirect.DISCARD).setOutputRedirector(ProcessBuilder.Redirect.DISCARD).start();
            try (var c = pg.getPostgresDatabase().getConnection(); var st = c.createStatement()) {
                st.execute("create table assignee (id bigint primary key, name varchar(255))");
                st.execute("create table request (id bigint primary key, status varchar(255), assignee_id bigint, "
                        + "constraint fk_request_assignee foreign key (assignee_id) references assignee(id) deferrable initially deferred)");
                st.execute("create table request_plain (id bigint primary key, status varchar(255), assignee_id bigint, "
                        + "constraint fk_request_plain_assignee foreign key (assignee_id) references assignee(id) deferrable initially deferred)");
            }
            props.put("spring.datasource.url", pg.getJdbcUrl("postgres", "postgres"));
            props.put("spring.datasource.username", "postgres");
            props.put("spring.datasource.password", "postgres");
            props.put("spring.jpa.hibernate.ddl-auto", "none");
        } else if (List.of(args).contains("h2-no-fk")) {   // тестовая схема без внешнего ключа
            props.put("spring.datasource.url", "jdbc:h2:mem:s144nofk;INIT=create table assignee (id bigint primary key, name varchar(255))\\;"
                    + "create table request (id bigint primary key, status varchar(255), assignee_id bigint)\\;"
                    + "create table request_plain (id bigint primary key, status varchar(255), assignee_id bigint)");
            props.put("spring.jpa.hibernate.ddl-auto", "none");
        } else {
            props.put("spring.datasource.url", "jdbc:h2:mem:s144");
            props.put("spring.jpa.hibernate.ddl-auto", "create");
        }
        SpringApplication app = new SpringApplication(App.class);
        props.putAll(Map.of(
                "spring.jpa.open-in-view", "false",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", Spy.class.getName(),
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        app.setDefaultProperties(props);
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            RequestRepository repo = ctx.getBean(RequestRepository.class);
            RequestPlainRepository plain = ctx.getBean(RequestPlainRepository.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + (pgDeferred ? ", PostgreSQL 15.5, fk_request_assignee DEFERRABLE INITIALLY DEFERRED" : List.of(args).contains("h2-no-fk") ? ", H2 2.4, схема без внешнего ключа" : ", H2 2.4")
                    + ", FlushMode = " + System.getProperty("spring.jpa.properties.org.hibernate.flushMode", "AUTO"));
            if (!pgDeferred && !List.of(args).contains("h2-no-fk"))   // в «продовой» схеме ключ есть и у request_plain, как от Liquibase
                tx.executeWithoutResult(s -> em.createNativeQuery("alter table request_plain add constraint fk_request_plain_assignee foreign key (assignee_id) references assignee(id)").executeUpdate());
            tx.executeWithoutResult(s -> { for (long i = 1; i <= 3; i++) { em.persist(new Request(i)); em.persist(new RequestPlain(i)); } });
            long[] next = {100};
            for (String kind : List.of("JPQL", "native", "JPQL+flushAutomatically", "JPQL, поле Long", "поле Long+flushAuto")) {
                for (boolean rollbackAtEnd : new boolean[]{false, true}) {
                    long id = next[0]++;
                    Spy.LOG.clear();
                    String outcome;
                    try {
                        tx.executeWithoutResult(s -> {
                            em.persist(new Assignee(id, "Исполнитель " + id));
                            int n = switch (kind) { case "JPQL" -> repo.reassignJpql(id); case "native" -> repo.reassignNative(id); case "JPQL+flushAutomatically" -> repo.reassignJpqlFlushFirst(id);
                                case "JPQL, поле Long" -> plain.reassign(id); default -> plain.reassignFlushFirst(id); };
                            if (rollbackAtEnd) s.setRollbackOnly();   // как @Transactional на тесте
                        });
                        outcome = rollbackAtEnd ? "прошло, откат в конце" : "зафиксировано";
                    } catch (RuntimeException e) {
                        Throwable c = e; while (c.getCause() != null) c = c.getCause();
                        outcome = "ошибка " + c.getClass().getSimpleName();
                    }
                    System.out.printf("%-24s %-26s → %s; порядок: %s%n", kind, rollbackAtEnd ? "(откат в конце, как тест)" : "(фиксация)", outcome,
                            Spy.LOG.stream().filter(q -> q.startsWith("insert") || q.startsWith("update")).map(q -> q.substring(0, q.indexOf(' ', 7))).toList());
                }
            }
        }
        if (pg != null) pg.close();
    }
}
