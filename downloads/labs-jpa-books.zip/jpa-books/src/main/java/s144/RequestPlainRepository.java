package s144;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface RequestPlainRepository extends JpaRepository<RequestPlain, Long> {
    @Modifying
    @Query("update RequestPlain r set r.assigneeId = :assigneeId where r.status = 'NEW'")
    int reassign(@Param("assigneeId") Long assigneeId);

    @Modifying(flushAutomatically = true)
    @Query("update RequestPlain r set r.assigneeId = :assigneeId where r.status = 'NEW'")
    int reassignFlushFirst(@Param("assigneeId") Long assigneeId);
}
