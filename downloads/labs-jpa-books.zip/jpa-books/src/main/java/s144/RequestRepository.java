package s144;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface RequestRepository extends JpaRepository<Request, Long> {
    @Modifying
    @Query("update Request r set r.assignee.id = :assigneeId where r.status = 'NEW'")
    int reassignJpql(@Param("assigneeId") Long assigneeId);

    @Modifying(flushAutomatically = true)
    @Query("update Request r set r.assignee.id = :assigneeId where r.status = 'NEW'")
    int reassignJpqlFlushFirst(@Param("assigneeId") Long assigneeId);

    @Modifying
    @Query(value = "update request set assignee_id = :assigneeId where status = 'NEW'", nativeQuery = true)
    int reassignNative(@Param("assigneeId") Long assigneeId);
}
