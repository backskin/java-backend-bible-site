package s144;

import jakarta.persistence.*;

@Entity @Table(name = "assignee")
class Assignee {
    @Id Long id;
    String name;
    protected Assignee() {}
    Assignee(Long id, String name) { this.id = id; this.name = name; }
}

@Entity @Table(name = "request")
class Request {
    @Id Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "assignee_id", foreignKey = @ForeignKey(name = "fk_request_assignee")) Assignee assignee;
    String status = "NEW";
    protected Request() {}
    Request(Long id) { this.id = id; }
}

/** Та же заявка, но исполнитель отображён простым полем: так было в отображении из инцидента 14.4. */
@Entity @Table(name = "request_plain")
class RequestPlain {
    @Id Long id;
    @Column(name = "assignee_id") Long assigneeId;
    String status = "NEW";
    protected RequestPlain() {}
    RequestPlain(Long id) { this.id = id; }
}
