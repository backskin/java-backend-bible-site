package s45;

import jakarta.persistence.*;
import org.hibernate.Hibernate;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

@SpringBootApplication
public class App {

    @MappedSuperclass
    static abstract class Base {
        @Id @GeneratedValue Long id;
        String title = "t";
        public Long getId() { return id; }
    }

    /** Стратегия 0: id и в equals, и в hashCode. */
    @Entity(name = "BookNaive") @Table(name = "book_naive")
    static class BookNaive extends Base {
        @Override public boolean equals(Object o) { return o instanceof BookNaive b && id != null && id.equals(b.getId()); }
        @Override public int hashCode() { return Objects.hashCode(id); }
    }

    /** Стратегия 2: равенство по id, hashCode константа класса. */
    @Entity(name = "BookConst") @Table(name = "book_const")
    static class BookConst extends Base {
        @Override public boolean equals(Object o) { return o instanceof BookConst b && id != null && id.equals(b.getId()); }
        @Override public int hashCode() { return getClass().hashCode(); }
    }

    /** То же, но equals сравнивает классы через getClass(): ломается на прокси. */
    @Entity(name = "BookGetClass") @Table(name = "book_getclass")
    static class BookGetClass extends Base {
        @Override public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            return id != null && id.equals(((BookGetClass) o).getId());
        }
        @Override public int hashCode() { return getClass().hashCode(); }
    }

    /** Исправление для прокси: hashCode от настоящего класса, а не от класса-прокси. */
    @Entity(name = "BookHibClass") @Table(name = "book_hibclass")
    static class BookHibClass extends Base {
        @Override public boolean equals(Object o) { return o instanceof BookHibClass b && id != null && id.equals(b.getId()); }
        @Override public int hashCode() { return Hibernate.getClass(this).hashCode(); }
    }

    /** Стратегия 3: идентификатор назначается в конструкторе. */
    @Entity(name = "BookUuid") @Table(name = "book_uuid")
    static class BookUuid {
        @Id UUID id = UUID.randomUUID();
        String title = "t";
        public UUID getId() { return id; }
        @Override public boolean equals(Object o) { return o instanceof BookUuid b && id.equals(b.getId()); }
        @Override public int hashCode() { return id.hashCode(); }
    }

    @Component
    static class Demo implements CommandLineRunner {
        @PersistenceContext EntityManager em;
        final TransactionTemplate tx;
        Demo(TransactionTemplate tx) { this.tx = tx; }

        <T> void persistedAfterAdd(String title, Supplier<T> factory) {
            boolean found = tx.execute(s -> {
                Set<T> set = new HashSet<>();
                T b = factory.get();
                set.add(b);                 // в множество до persist
                em.persist(b);              // идентификатор назначается здесь (для UUID он уже был)
                em.flush();
                return set.contains(b);
            });
            System.out.printf("%-34s после persist set.contains(b) = %s%n", title, found);
        }

        <T extends Base> void realVsProxy(String title, Class<T> type) throws Exception {
            T seed = type.getDeclaredConstructor().newInstance();
            tx.executeWithoutResult(s -> em.persist(seed));
            T real = tx.execute(s -> em.find(type, seed.getId()));              // настоящий объект (detached)
            T proxy = tx.execute(s -> {
                T p = em.getReference(type, seed.getId());                      // прокси той же строки
                Hibernate.initialize(p);                                         // загружаем данные, чтобы прокси пережил закрытие сессии
                return p;
            });
            Set<Object> set = new HashSet<>();
            set.add(real);
            set.add(proxy);
            System.out.printf("%-34s real.equals(proxy)=%s, proxy.equals(real)=%s, размер HashSet из real и proxy: %d%n",
                    title, real.equals(proxy), proxy.equals(real), set.size());
        }

        @Override
        public void run(String... args) throws Exception {
            System.out.println("--- 1. множество, в которое положили сущность до persist");
            persistedAfterAdd("id в equals и hashCode", BookNaive::new);
            persistedAfterAdd("константный hashCode, equals по id", BookConst::new);
            persistedAfterAdd("UUID из конструктора", BookUuid::new);

            System.out.println("--- 2. та же строка как настоящий объект и как прокси");
            realVsProxy("equals через getClass()", BookGetClass.class);
            realVsProxy("hashCode от getClass()", BookConst.class);
            realVsProxy("hashCode от Hibernate.getClass(this)", BookHibClass.class);
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
