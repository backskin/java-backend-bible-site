package s12fl;

import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.stat.Statistics;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Разд. 10.7 гл. 12: пересчёт комиссии 100 000 платежей порциями по 500 в одной транзакции,
 * с парой flush() + clear() после каждой порции и с одним flush() без clear().
 * Сущность из 20 полей. Печатает время целиком, время запроса и flush на 100-й и 200-й порции,
 * число SQL по статистике Hibernate, пакеты и прирост кучи к концу транзакции.
 */
@SpringBootApplication
public class App {
    static final int ROWS = 100_000, CHUNK = 500;

    @Entity(name = "Payment") @Table(name = "payment")
    public static class Payment {
        @Id Long id;
        LocalDate bookedOn;
        BigDecimal amount, fee;
        String currency, payerAccount, payeeAccount, payerName, payeeName, payerInn, payeeInn,
               payerBic, payeeBic, purpose, docNo, channel, status, branch, operator, comment;
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s12fl",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.jpa.properties.hibernate.jdbc.batch_size", "50",
                "spring.jpa.properties.hibernate.generate_statistics", "true",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run(args)) {
            EntityManagerFactory emf = ctx.getBean(EntityManagerFactory.class);
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            SessionFactory sf = emf.unwrap(SessionFactory.class);
            Statistics st = sf.getStatistics();
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", H2, JDK " + Runtime.version()
                    + ", платежей " + ROWS + ", порция " + CHUNK + ", batch_size 50, Xmx " + Runtime.getRuntime().maxMemory() / 1_048_576 + " МБ");
            try (StatelessSession ss = sf.openStatelessSession()) {
                ss.setJdbcBatchSize(500);
                var t = ss.beginTransaction();
                LocalDate day = LocalDate.of(2026, 10, 30);
                for (long i = 1; i <= ROWS; i++) {
                    Payment p = new Payment();
                    p.id = i; p.bookedOn = day; p.amount = BigDecimal.valueOf(1000 + i % 9000, 2); p.fee = BigDecimal.ZERO;
                    p.currency = "RUB"; p.payerAccount = "40702810" + i; p.payeeAccount = "40817810" + i;
                    p.payerName = "ООО Плательщик " + i; p.payeeName = "Получатель " + i; p.payerInn = "7701" + i; p.payeeInn = "5003" + i;
                    p.payerBic = "044525225"; p.payeeBic = "044525974"; p.purpose = "Оплата по счёту " + i; p.docNo = "П-" + i;
                    p.channel = "ДБО"; p.status = "BOOKED"; p.branch = "МСК"; p.operator = "dev.team"; p.comment = "";
                    ss.insert(p);
                }
                t.commit();
            }
            for (boolean clear : new boolean[]{true, false}) {
                for (int warm = 0; warm < 2; warm++) {                     // первый прогон — прогрев JIT, печатается второй
                    final boolean report = warm == 1;
                    st.clear();
                    System.gc();
                    long heap0 = used();
                    long t0 = System.nanoTime();
                    long[] at = new long[4];
                    long[] heapEnd = new long[1];
                    final int round = warm;
                    tx.executeWithoutResult(s -> {
                        long lastId = 0; int k = 0;
                        while (true) {
                            long q0 = System.nanoTime();
                            List<Payment> page = em.createQuery(
                                    "select p from Payment p where p.bookedOn = :day and p.id > :lastId order by p.id", Payment.class)
                                    .setParameter("day", LocalDate.of(2026, 10, 30)).setParameter("lastId", lastId)
                                    .setMaxResults(CHUNK).getResultList();
                            long q1 = System.nanoTime();
                            if (page.isEmpty()) break;
                            k++;
                            for (Payment p : page) p.fee = p.amount.multiply(new BigDecimal("0.0" + (1 + round))).setScale(2, java.math.RoundingMode.HALF_UP);
                            lastId = page.get(page.size() - 1).id;
                            long f0 = System.nanoTime();
                            em.flush();
                            if (clear) em.clear();
                            long f1 = System.nanoTime();
                            if (k == 100) { at[0] = q1 - q0; at[1] = f1 - f0; }
                            if (k == 200) { at[2] = q1 - q0; at[3] = f1 - f0; }
                        }
                        System.gc();
                        heapEnd[0] = used();
                    });
                    long ms = (System.nanoTime() - t0) / 1_000_000;
                    if (report) {
                        System.out.printf("%-26s всего %6d мс; порция 100: запрос %5.1f мс, flush%s %5.1f мс; порция 200: запрос %5.1f мс, flush%s %5.1f мс%n",
                                clear ? "flush() + clear():" : "flush() без clear():", ms,
                                at[0] / 1e6, clear ? "+clear" : "", at[1] / 1e6, at[2] / 1e6, clear ? "+clear" : "", at[3] / 1e6);
                        System.out.printf("%-26s запросов SELECT %d, сущностей обновлено %d, flush %d, куча к концу транзакции +%d МБ%n",
                                "", st.getQueryExecutionCount(), st.getEntityUpdateCount(),
                                st.getFlushCount(), (heapEnd[0] - heap0) / 1_048_576);
                    }
                }
            }
        }
    }

    static long used() { Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }
}
