package s12ins;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import org.postgresql.PGConnection;
import org.postgresql.copy.CopyManager;

import java.io.StringReader;
import java.sql.*;

/**
 * Разд. 10.4 гл. 12: вставка 100 000 строк реестра в PostgreSQL четырьмя способами.
 * По одной, пакетами по 50, пакетами с reWriteBatchedInserts=true и через COPY.
 * Каждый способ — одна транзакция; время — без создания таблицы, три прогона, берётся лучший.
 */
public class App {
    static final int ROWS = 100_000;

    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.start()) {
            String base = pg.getJdbcUrl("postgres", "postgres");
            try (Connection c = DriverManager.getConnection(base)) {
                System.out.println("PostgreSQL " + c.getMetaData().getDatabaseProductVersion()
                        + ", PgJDBC " + org.postgresql.util.DriverInfo.DRIVER_VERSION + ", JDK " + Runtime.version()
                        + ", строк " + ROWS);
            }
            for (String mode : new String[]{"по одной", "пакеты по 50", "пакеты по 50 + reWriteBatchedInserts", "COPY"}) {
                long best = Long.MAX_VALUE;
                for (int run = 0; run < 3; run++) {
                    String url = base + (mode.contains("reWrite") ? "&reWriteBatchedInserts=true" : "");
                    try (Connection c = DriverManager.getConnection(url)) {
                        try (Statement s = c.createStatement()) {
                            s.execute("drop table if exists registry_entry");
                            s.execute("create table registry_entry(id bigint primary key, amount numeric(18,2), doc_no varchar(20), purpose varchar(140))");
                        }
                        c.setAutoCommit(false);
                        long t0 = System.nanoTime();
                        switch (mode) {
                            case "COPY" -> {
                                StringBuilder csv = new StringBuilder(ROWS * 80);
                                for (int i = 1; i <= ROWS; i++)
                                    csv.append(i).append(',').append(i % 10_000).append(".50,").append("D-").append(i)
                                       .append(",Оплата по договору ").append(i).append('\n');
                                CopyManager cm = c.unwrap(PGConnection.class).getCopyAPI();
                                cm.copyIn("COPY registry_entry (id, amount, doc_no, purpose) FROM STDIN WITH (FORMAT csv)",
                                        new StringReader(csv.toString()));
                            }
                            default -> {
                                boolean batch = !mode.equals("по одной");
                                try (PreparedStatement ps = c.prepareStatement(
                                        "insert into registry_entry(id, amount, doc_no, purpose) values (?, ?, ?, ?)")) {
                                    for (int i = 1; i <= ROWS; i++) {
                                        ps.setLong(1, i);
                                        ps.setBigDecimal(2, new java.math.BigDecimal((i % 10_000) + ".50"));
                                        ps.setString(3, "D-" + i);
                                        ps.setString(4, "Оплата по договору " + i);
                                        if (batch) {
                                            ps.addBatch();
                                            if (i % 50 == 0) ps.executeBatch();
                                        } else {
                                            ps.executeUpdate();
                                        }
                                    }
                                    if (batch) ps.executeBatch();
                                }
                            }
                        }
                        c.commit();
                        long ms = (System.nanoTime() - t0) / 1_000_000;
                        best = Math.min(best, ms);
                        try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("select count(*) from registry_entry")) {
                            rs.next();
                            if (rs.getLong(1) != ROWS) throw new IllegalStateException("строк " + rs.getLong(1));
                        }
                        c.commit();
                    }
                }
                System.out.printf("%-40s лучшее из трёх: %6d мс%n", mode, best);
            }
        }
    }
}
