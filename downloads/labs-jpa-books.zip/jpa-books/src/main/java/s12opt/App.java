package s12opt;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Разд. 9.1 и 9.2 гл. 12, сверка с книгами (Tudose, разд. 11.2.2–11.2.3).
 * 1. LockModeType.OPTIMISTIC на запросе из 100 счетов: сколько SELECT Hibernate делает при фиксации.
 * 2. Что остаётся от транзакции после PessimisticLockException по lock_timeout на PostgreSQL:
 *    можно ли продолжить работу в той же транзакции.
 */
@SpringBootApplication
public class App {

    @Entity(name = "Account") @Table(name = "account")
    public static class Account {
        @Id Long id;
        @Version long version;
        BigDecimal balance = new BigDecimal("100.00");
    }

    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.start()) {
            SpringApplication app = new SpringApplication(App.class);
            app.setDefaultProperties(Map.of(
                    "spring.datasource.url", pg.getJdbcUrl("postgres", "postgres"),
                    "spring.datasource.username", "postgres",
                    "spring.datasource.password", "postgres",
                    "spring.jpa.hibernate.ddl-auto", "create",
                    "spring.jpa.open-in-view", "false",
                    "spring.jpa.properties.hibernate.generate_statistics", "true",
                    "spring.main.web-application-type", "none",
                    "logging.level.root", "OFF",
                    "spring.main.banner-mode", "off"));
            try (ConfigurableApplicationContext ctx = app.run(args)) {
                EntityManager em = ctx.getBean(EntityManager.class);
                TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
                Statistics st = ctx.getBean(EntityManagerFactory.class).unwrap(SessionFactory.class).getStatistics();
                System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", PostgreSQL "
                        + tx.execute(s -> em.createNativeQuery("show server_version").getSingleResult()));
                tx.executeWithoutResult(s -> {
                    for (long i = 1; i <= 100; i++) { Account a = new Account(); a.id = i; em.persist(a); }
                });

                System.out.println("--- 1. OPTIMISTIC на запросе из 100 счетов");
                for (LockModeType mode : List.of(LockModeType.NONE, LockModeType.OPTIMISTIC)) {
                    st.clear();
                    BigDecimal sum = tx.execute(s -> em.createQuery("select a from Account a", Account.class)
                            .setLockMode(mode).getResultList().stream().map(a -> a.balance).reduce(BigDecimal.ZERO, BigDecimal::add));
                    System.out.printf("%-11s сумма %s, SQL-операторов в транзакции %d, загружено сущностей %d%n",
                            mode, sum, st.getPrepareStatementCount(), st.getEntityLoadCount());
                }

                System.out.println("--- 2. lock_timeout истёк: что с транзакцией");
                CountDownLatch locked = new CountDownLatch(1), release = new CountDownLatch(1);
                Thread holder = new Thread(() -> tx.executeWithoutResult(s -> {
                    em.find(Account.class, 1L, LockModeType.PESSIMISTIC_WRITE);
                    locked.countDown();
                    try { release.await(5, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
                }));
                holder.start();
                locked.await();
                try {
                    tx.executeWithoutResult(s -> {
                        try {
                            em.find(Account.class, 1L, LockModeType.PESSIMISTIC_WRITE,
                                    Map.of("jakarta.persistence.lock.timeout", 200));
                        } catch (RuntimeException e) {
                            System.out.println("поймали " + e.getClass().getName() + ", rollbackOnly=" + s.isRollbackOnly());
                        }
                        long before = st.getPrepareStatementCount();
                        Account other = em.find(Account.class, 2L);
                        System.out.println("  SQL-операторов на этот find: " + (st.getPrepareStatementCount() - before));
                        System.out.println("em.find(Account, 2) в той же транзакции вернул " + (other == null ? "null, хотя счёт 2 есть" : "счёт " + other.id));
                        try {
                            Object one = em.createNativeQuery("select 1").getSingleResult();
                            System.out.println("native select 1 в той же транзакции прошёл: " + one);
                        } catch (RuntimeException e) {
                            System.out.println("следующий запрос в той же транзакции: " + e.getClass().getSimpleName());
                            for (Throwable r = e.getCause(); r != null; r = r.getCause())
                                System.out.println("  причина: " + r.getClass().getSimpleName() + ": " + String.valueOf(r.getMessage()).lines().findFirst().orElse(""));
                        }
                    });
                    System.out.println("транзакция зафиксирована");
                } catch (RuntimeException e) {
                    System.out.println("фиксация: " + e.getClass().getSimpleName());
                }
                release.countDown();
                holder.join();
            }
        }
    }
}
