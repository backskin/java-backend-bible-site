package s86;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
class Listeners {
    static final List<String> SMS = new CopyOnWriteArrayList<>();
    static final List<String> AFTER_COMMIT = new CopyOnWriteArrayList<>();
    static final List<String> AFTER_ROLLBACK = new CopyOnWriteArrayList<>();
    final OutboxRepository outbox;
    final AuditWriter audit;
    Listeners(OutboxRepository outbox, AuditWriter audit) { this.outbox = outbox; this.audit = audit; }

    /** Так было в инциденте 14.20: синхронный слушатель шлёт SMS сразу. */
    @EventListener
    void smsSync(PaymentOrderExecuted e) { SMS.add("SMS «Платёж исполнен» по поручению " + e.orderId()); }

    /** Outbox для бухгалтерии: строка в той же транзакции. */
    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    void outbox(PaymentOrderExecuted e) { outbox.save(new OutboxRow(e.orderId(), "accounting")); }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    void afterCommit(PaymentOrderExecuted e) {
        AFTER_COMMIT.add("после фиксации: " + e.orderId());
        outbox.save(new OutboxRow(e.orderId(), "audit-plain"));        // грабли 8.6: запись без новой транзакции
        audit.writeInNewTx(e.orderId());                                // правильный вариант: REQUIRES_NEW
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_ROLLBACK)
    void afterRollback(PaymentOrderExecuted e) { AFTER_ROLLBACK.add("после отката: " + e.orderId()); }
}

@Component
class AuditWriter {
    final OutboxRepository outbox;
    AuditWriter(OutboxRepository outbox) { this.outbox = outbox; }
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void writeInNewTx(Long orderId) { outbox.save(new OutboxRow(orderId, "audit-requires-new")); }
}
