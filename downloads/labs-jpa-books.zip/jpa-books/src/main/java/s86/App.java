package s86;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Map;

/** Разд. 8.6 и 14.20 гл. 12: доменное событие AbstractAggregateRoot, синхронный слушатель, фазы транзакции и откат. */
@SpringBootApplication
public class App {
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s86",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            var orders = ctx.getBean(PaymentOrderRepository.class);
            var outbox = ctx.getBean(OutboxRepository.class);
            var service = ctx.getBean(PaymentService.class);
            orders.save(new PaymentOrder(1L));
            orders.save(new PaymentOrder(2L));
            for (long id : new long[]{1L, 2L}) {
                boolean fail = id == 2L;
                Listeners.SMS.clear(); Listeners.AFTER_COMMIT.clear(); Listeners.AFTER_ROLLBACK.clear();
                String outcome;
                try { service.execute(id, fail); outcome = "зафиксирована"; }
                catch (RuntimeException e) { outcome = "откатилась (" + e.getMessage() + ")"; }
                System.out.println("поручение " + id + ": транзакция " + outcome + ", статус в базе " + orders.findById(id).orElseThrow().status);
                System.out.println("   синхронный @EventListener: " + (Listeners.SMS.isEmpty() ? "не вызван" : Listeners.SMS));
                System.out.println("   AFTER_COMMIT: " + (Listeners.AFTER_COMMIT.isEmpty() ? "не вызван" : "вызван") + "; AFTER_ROLLBACK: " + (Listeners.AFTER_ROLLBACK.isEmpty() ? "не вызван" : "вызван"));
            }
            System.out.println("строки outbox: accounting (BEFORE_COMMIT) " + outbox.countByKind("accounting")
                    + ", audit-plain (запись в AFTER_COMMIT без новой транзакции) " + outbox.countByKind("audit-plain")
                    + ", audit-requires-new (REQUIRES_NEW) " + outbox.countByKind("audit-requires-new"));
        }
    }
}
