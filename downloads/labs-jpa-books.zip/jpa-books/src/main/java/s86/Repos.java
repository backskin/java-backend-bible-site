package s86;

import org.springframework.data.jpa.repository.JpaRepository;

interface PaymentOrderRepository extends JpaRepository<PaymentOrder, Long> { }
