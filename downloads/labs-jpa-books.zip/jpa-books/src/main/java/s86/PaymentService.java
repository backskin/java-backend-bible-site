package s86;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
class PaymentService {
    final PaymentOrderRepository repo;
    PaymentService(PaymentOrderRepository repo) { this.repo = repo; }

    @Transactional
    public void execute(Long id, boolean failAfterSave) {
        repo.save(repo.findById(id).orElseThrow().execute());
        if (failAfterSave) throw new IllegalStateException("конфликт версии при фиксации (имитация)");
    }
}
