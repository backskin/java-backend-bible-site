package s86;

import org.springframework.data.jpa.repository.JpaRepository;

interface OutboxRepository extends JpaRepository<OutboxRow, Long> {
    long countByKind(String kind);
}
