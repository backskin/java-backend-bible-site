package s86;

import jakarta.persistence.*;
import org.springframework.data.domain.AbstractAggregateRoot;

/** Поручение — корень агрегата, регистрирует доменное событие при исполнении. */
@Entity @Table(name = "payment_order")
class PaymentOrder extends AbstractAggregateRoot<PaymentOrder> {
    @Id Long id;
    String status = "ACCEPTED";
    protected PaymentOrder() {}
    PaymentOrder(Long id) { this.id = id; }
    PaymentOrder execute() { status = "EXECUTED"; registerEvent(new PaymentOrderExecuted(id)); return this; }
}

record PaymentOrderExecuted(Long orderId) { }

@Entity @Table(name = "outbox")
class OutboxRow {
    @Id @GeneratedValue Long id;
    Long orderId;
    String kind;
    protected OutboxRow() {}
    OutboxRow(Long orderId, String kind) { this.orderId = orderId; this.kind = kind; }
}
