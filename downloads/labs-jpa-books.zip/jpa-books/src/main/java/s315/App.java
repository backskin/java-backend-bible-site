package s315;

import jakarta.persistence.*;
import org.hibernate.Session;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Разд. 3.5 и 3.15 гл. 12: делает ли Hibernate 7.4.5 автоматический flush несохранённого платежа
 * перед запросом к другой таблице (справочник валют) — для JPQL select, JPQL update, native без query spaces и с ними.
 */
@SpringBootApplication
public class App {

    @Entity(name = "Payment") @Table(name = "payment")
    public static class Payment { @Id Long id; String status; }

    @Entity(name = "Currency") @Table(name = "currency")
    public static class Currency { @Id String code; boolean active = true; }

    public static class Spy implements org.hibernate.resource.jdbc.spi.StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s315",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", Spy.class.getName(),
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", FlushMode AUTO, запуск через JPA (Spring Boot); "
                    + "в контексте несохранённый платёж, запрос — к таблице currency");
            long[] id = {1};
            check("JPQL select по currency", em, tx, id, () -> em.createQuery("select c from Currency c", Currency.class).getResultList());
            check("JPQL select по payment", em, tx, id, () -> em.createQuery("select p from Payment p", Payment.class).getResultList());
            check("JPQL update currency", em, tx, id, () -> em.createQuery("update Currency c set c.active = true").executeUpdate());
            check("native select по currency, spaces не заданы", em, tx, id, () -> em.createNativeQuery("select count(*) from currency").getSingleResult());
            check("native select по currency, spaces = Currency", em, tx, id, () -> em.createNativeQuery("select count(*) from currency")
                    .unwrap(org.hibernate.query.NativeQuery.class).addSynchronizedEntityClass(Currency.class).getSingleResult());
            check("native update currency, spaces не заданы", em, tx, id, () -> em.createNativeQuery("update currency set active = true").executeUpdate());
            check("native update currency, spaces = Currency", em, tx, id, () -> em.createNativeQuery("update currency set active = true")
                    .unwrap(org.hibernate.query.NativeQuery.class).addSynchronizedEntityClass(Currency.class).executeUpdate());
        }
    }

    static void check(String title, EntityManager em, TransactionTemplate tx, long[] id, Runnable query) {
        Spy.LOG.clear();
        tx.executeWithoutResult(s -> {
            Payment p = new Payment(); p.id = id[0]++; p.status = "NEW";
            em.persist(p);
            query.run();
            Spy.LOG.add("--- запрос выполнен");
        });
        int insertAt = -1, marker = -1;
        for (int i = 0; i < Spy.LOG.size(); i++) {
            if (Spy.LOG.get(i).startsWith("insert into payment") && insertAt < 0) insertAt = i;
            if (Spy.LOG.get(i).startsWith("---")) marker = i;
        }
        System.out.printf("%-50s → INSERT платежа %s%n", title, insertAt < marker ? "ушёл ДО запроса (flush)" : "ушёл только на фиксации");
    }
}
