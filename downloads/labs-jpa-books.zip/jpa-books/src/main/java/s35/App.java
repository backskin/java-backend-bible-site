package s35;

import jakarta.persistence.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.Map;

@SpringBootApplication
public class App {

    @Entity(name = "Payment") @Table(name = "payment")
    static class Payment {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
        Long id;
        @Column(unique = true, nullable = false)
        String ref;
        String status = "NEW";
        BigDecimal amount = BigDecimal.TEN;

        protected Payment() {}
        Payment(String ref) { this.ref = ref; }
    }

    @Entity(name = "Client") @Table(name = "client")
    static class Client {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
        Long id;
        String name = "Acme";
    }

    @Component
    static class Demo implements CommandLineRunner {
        @PersistenceContext EntityManager em;
        final TransactionTemplate tx;
        final PlatformTransactionManager ptm;
        Demo(TransactionTemplate tx, PlatformTransactionManager ptm) { this.tx = tx; this.ptm = ptm; }

        @Override
        public void run(String... args) {
            long[] ids = tx.execute(s -> {
                Payment p = new Payment("R-1");
                Client c = new Client();
                em.persist(p);
                em.persist(c);
                return new long[]{p.id, c.id};
            });
            System.out.println("=== данные созданы");

            // 1. Какие запросы запускают flush в режиме AUTO
            tx.executeWithoutResult(s -> {
                Payment p = em.find(Payment.class, ids[0]);
                p.status = "PAID";
                System.out.println("--- 1a. JPQL по payment (таблица изменена)");
                em.createQuery("select count(p) from Payment p where p.status = 'PAID'", Long.class).getSingleResult();

                p.status = "DONE";
                System.out.println("--- 1b. JPQL по client (изменена другая таблица)");
                em.createQuery("select count(c) from Client c", Long.class).getSingleResult();

                System.out.println("--- 1c. native-запрос по client");
                em.createNativeQuery("select count(*) from client").getSingleResult();

                p.status = "ARCHIVED";
                System.out.println("--- 1d. em.find другой сущности по id");
                em.find(Client.class, ids[1]);
                System.out.println("--- (find не сбросил изменение; UPDATE уйдёт на коммите)");
            });

            // 2. Порядок операторов: DELETE уходит последним
            System.out.println("--- 2a. remove + persist с тем же уникальным ref, без flush");
            try {
                tx.executeWithoutResult(s -> {
                    Payment old = em.find(Payment.class, ids[0]);
                    em.remove(old);
                    em.persist(new Payment("R-1"));
                });
            } catch (RuntimeException e) {
                Throwable root = e;
                while (root.getCause() != null) root = root.getCause();
                System.out.println("ошибка: " + e.getClass().getSimpleName() + " / причина: " + root.getClass().getSimpleName());
            }
            System.out.println("--- 2b. то же, но с flush между remove и persist");
            tx.executeWithoutResult(s -> {
                Payment old = em.find(Payment.class, ids[0]);
                em.remove(old);
                em.flush();
                em.persist(new Payment("R-1"));
            });
            System.out.println("проходит");

            // 3. readOnly: изменения не уходят в базу и не вызывают ошибок
            System.out.println("--- 3. транзакция readOnly=true");
            TransactionTemplate ro = new TransactionTemplate(ptm);
            ro.setReadOnly(true);
            ro.executeWithoutResult(s -> {
                Payment p = em.createQuery("select p from Payment p", Payment.class).getResultList().get(0);
                p.status = "CHANGED_IN_READONLY";
            });
            String st = tx.execute(s -> em.createQuery("select p.status from Payment p", String.class).getSingleResult());
            System.out.println("статус в базе после readOnly-транзакции: " + st);
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.show-sql", "true",
                "logging.level.root", "WARN",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
