package s1212;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Supplier;

/**
 * Разд. 12.12 гл. 12: автоматический count у Page для @Query с join по коллекции — в транзакции
 * (SelectionQuery.getResultCount из Hibernate) и без неё (count-запрос из текста), и два исправления запроса.
 */
@SpringBootApplication
public class App {

    public static class Spy implements org.hibernate.resource.jdbc.spi.StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s1212",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", Spy.class.getName(),
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            AccountRepository repo = ctx.getBean(AccountRepository.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("spring-data-jpa " + org.springframework.data.jpa.repository.JpaRepository.class.getPackage().getImplementationVersion()
                    + ", hibernate-core " + org.hibernate.Version.getVersionString());
            Instant from = Instant.parse("2026-10-01T00:00:00Z");
            tx.executeWithoutResult(s -> {
                for (int i = 0; i < 3; i++) {
                    Account a = new Account(7L, "40817810" + i);
                    for (int j = 0; j < 800; j++) a.payments.add(new Payment(a, from.plusSeconds(3600L * j)));
                    repo.save(a);
                }
            });
            var em = ctx.getBean(jakarta.persistence.EntityManager.class);
            String jpql = "select a from Account a join a.payments p where a.clientId = :c and p.createdAt >= :f";
            tx.executeWithoutResult(s -> {
                var all = em.createQuery(jpql, Account.class).setParameter("c", 7L).setParameter("f", from).getResultList();
                var first20 = em.createQuery(jpql, Account.class).setParameter("c", 7L).setParameter("f", from).setMaxResults(20).getResultList();
                Long rows = em.createQuery("select count(*) from Account a join a.payments p where a.clientId = :c and p.createdAt >= :f", Long.class)
                        .setParameter("c", 7L).setParameter("f", from).getSingleResult();
                System.out.println("JPQL с join напрямую: строк соединения " + rows + ", getResultList() без лимита — " + all.size()
                        + " объектов (различных " + new java.util.HashSet<>(all).size() + "), с setMaxResults(20) — " + first20.size()
                        + " (различных " + new java.util.HashSet<>(first20).size() + ")");
            });
            PageRequest page = PageRequest.of(0, 20);
            for (String name : List.of("join (пример из главы)", "select distinct", "where exists")) {
                Supplier<Page<Account>> call = switch (name) {
                    case "select distinct" -> () -> repo.activeAccountsDistinct(7L, from, page);
                    case "where exists" -> () -> repo.activeAccountsExists(7L, from, page);
                    default -> () -> repo.activeAccounts(7L, from, page);
                };
                show(name + ", в транзакции", () -> tx.execute(s -> call.get()));
                show(name + ", без транзакции", call);
                if (name.startsWith("join")) {
                    Supplier<Page<Account>> p2 = () -> repo.activeAccounts(7L, from, PageRequest.of(1, 20));
                    show(name + ", вторая страница, в транзакции", () -> tx.execute(s -> p2.get()));
                    show(name + ", вторая страница, без транзакции", p2);
                    Supplier<Page<Account>> p1 = () -> repo.activeAccounts(7L, from, PageRequest.of(0, 1));
                    show(name + ", страница по 1, в транзакции", () -> tx.execute(s -> p1.get()));
                    show(name + ", страница по 1, без транзакции", p1);
                }
            }
        }
    }

    static void show(String title, Supplier<Page<Account>> call) {
        Spy.LOG.clear();
        Page<Account> p = call.get();
        var ids = p.getContent().stream().map(a -> a.number).toList();
        System.out.printf("%-46s на странице %d %s, totalElements %d, totalPages %d, SQL-запросов %d%n", title, p.getNumberOfElements(), ids, p.getTotalElements(), p.getTotalPages(), Spy.LOG.size());
        Spy.LOG.stream().filter(q -> q.contains("count(")).forEach(q -> System.out.println("      " + q));
    }
}
