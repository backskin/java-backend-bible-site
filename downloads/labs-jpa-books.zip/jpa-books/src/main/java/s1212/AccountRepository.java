package s1212;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import java.time.Instant;

public interface AccountRepository extends Repository<Account, Long> {
    /** Счета клиента, по которым были платежи за период — пример из разд. 12.12. */
    @Query("select a from Account a join a.payments p where a.clientId = :clientId and p.createdAt >= :from")
    Page<Account> activeAccounts(@Param("clientId") Long clientId, @Param("from") Instant from, Pageable page);

    @Query("select distinct a from Account a join a.payments p where a.clientId = :clientId and p.createdAt >= :from")
    Page<Account> activeAccountsDistinct(@Param("clientId") Long clientId, @Param("from") Instant from, Pageable page);

    @Query("select a from Account a where a.clientId = :clientId and exists (select 1 from Payment p where p.payer = a and p.createdAt >= :from)")
    Page<Account> activeAccountsExists(@Param("clientId") Long clientId, @Param("from") Instant from, Pageable page);

    void save(Account a);
}
