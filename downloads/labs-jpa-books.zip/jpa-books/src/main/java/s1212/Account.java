package s1212;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity @Table(name = "account")
public class Account {
    @Id @GeneratedValue(strategy = GenerationType.SEQUENCE) Long id;
    Long clientId;
    String number;
    @OneToMany(mappedBy = "payer", cascade = CascadeType.PERSIST) List<Payment> payments = new ArrayList<>();
    protected Account() {}
    Account(Long clientId, String number) { this.clientId = clientId; this.number = number; }
}
