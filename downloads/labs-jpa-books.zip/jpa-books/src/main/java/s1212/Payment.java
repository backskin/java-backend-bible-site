package s1212;

import jakarta.persistence.*;
import java.time.Instant;

@Entity @Table(name = "payment")
public class Payment {
    @Id @GeneratedValue(strategy = GenerationType.SEQUENCE) Long id;
    @ManyToOne(fetch = FetchType.LAZY) Account payer;
    Instant createdAt;
    protected Payment() {}
    Payment(Account payer, Instant createdAt) { this.payer = payer; this.createdAt = createdAt; }
}
