package s611;

import jakarta.persistence.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Разд. 6.11 гл. 12: когда Hibernate 7.4.5 всё ещё режет страницу с join fetch коллекции в памяти
 * и что тогда делает hibernate.query.fail_on_pagination_over_collection_fetch.
 * Аргумент: fail — включить это свойство.
 */
@SpringBootApplication
public class App {

    @Entity(name = "Orders") @Table(name = "orders")
    public static class Orders {
        @Id @GeneratedValue Long id;
        @OneToMany(mappedBy = "order", cascade = CascadeType.PERSIST) List<Line> lines = new ArrayList<>();
    }

    @Entity(name = "Line") @Table(name = "line")
    public static class Line {
        @Id @GeneratedValue Long id;
        @ManyToOne(fetch = FetchType.LAZY) Orders order;
        int qty;
    }

    /** Запоминает SQL, чтобы показать, есть ли в нём offset/fetch first. */
    public static class Spy implements org.hibernate.resource.jdbc.spi.StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    public static void main(String[] args) {
        boolean fail = List.of(args).contains("fail");
        var props = new java.util.HashMap<String, Object>(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s611",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", Spy.class.getName(),
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "logging.level.org.hibernate.orm.query", "WARN",
                "spring.main.banner-mode", "off"));
        if (fail) props.put("spring.jpa.properties.hibernate.query.fail_on_pagination_over_collection_fetch", "true");
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(props);
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString()
                    + ", fail_on_pagination_over_collection_fetch=" + fail);
            tx.executeWithoutResult(s -> {
                for (int i = 0; i < 100; i++) {
                    Orders o = new Orders();
                    for (int j = 0; j < 3; j++) { Line l = new Line(); l.order = o; l.qty = (i * 7 + j) % 50; o.lines.add(l); }
                    em.persist(o);
                }
            });
            for (String jpql : List.of(
                    "select o from Orders o join fetch o.lines order by o.id",
                    "select o from Orders o join fetch o.lines l order by o.id, l.qty",
                    "select o from Orders o join fetch o.lines l order by l.qty, o.id",
                    "select distinct o from Orders o join fetch o.lines",
                    "select distinct o from Orders o join fetch o.lines order by o.id")) {
                Spy.LOG.clear();
                try {
                    List<Orders> page = tx.execute(s -> em.createQuery(jpql, Orders.class)
                            .setFirstResult(10).setMaxResults(5).getResultList());
                    String sql = Spy.LOG.stream().filter(q -> q.contains("from orders")).findFirst().orElse("");
                    boolean inSql = sql.contains("offset") || sql.contains("fetch first");
                    System.out.printf("%-68s поручений %d; лимит %s%n", jpql, page.size(),
                            inSql ? "в SQL (вложенный запрос)" : "в памяти: SQL без offset/fetch first");
                } catch (RuntimeException e) {
                    Throwable c = e; while (c.getCause() != null) c = c.getCause();
                    System.out.printf("%-68s %s: %s%n", jpql, c.getClass().getSimpleName(), c.getMessage());
                }
            }
        }
    }
}
