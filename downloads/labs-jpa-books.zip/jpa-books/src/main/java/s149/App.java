package s149;

import com.sun.net.httpserver.HttpServer;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import javax.sql.DataSource;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

@SpringBootApplication
public class App {

    static final int ANTIFRAUD_DELAY_MS = 400;     // «медленный» сосед
    static final int CALLERS = 12;                 // одновременные авторизации
    static volatile int antifraudPort;

    @Entity(name = "CardLimit") @Table(name = "card_limit")
    static class CardLimit {
        @Id Long id;
        long remaining = 1_000_000;
        protected CardLimit() {}
        CardLimit(Long id) { this.id = id; }
    }

    @Entity(name = "Authorization") @Table(name = "authorization_")
    static class Authorization {
        @Id @GeneratedValue Long id;
        String status = "NEW";
    }

    /** Клиент антифрода. Считает вызовы, сделанные при активной транзакции (в проекте это был бы перехватчик в тестовом профиле). */
    @Component
    static class Antifraud {
        final HttpClient http = HttpClient.newHttpClient();
        final AtomicInteger callsInsideTransaction = new AtomicInteger();

        boolean check() throws Exception {
            if (TransactionSynchronizationManager.isActualTransactionActive()) callsInsideTransaction.incrementAndGet();
            HttpResponse<String> r = http.send(
                    HttpRequest.newBuilder(URI.create("http://localhost:" + antifraudPort + "/check")).build(),
                    HttpResponse.BodyHandlers.ofString());
            return r.statusCode() == 200;
        }
    }

    @Service
    static class Tx {
        @PersistenceContext EntityManager em;

        @Transactional
        public void resetLimit() {
            CardLimit limit = em.find(CardLimit.class, 1L);
            if (limit == null) em.persist(new CardLimit(1L));
            else limit.remaining = 1_000_000;
        }

        /** Плохо: блокировка строки, HTTP-вызов и запись внутри одной транзакции. */
        @Transactional
        public void authorizeInOneTransaction(Antifraud antifraud) throws Exception {
            CardLimit limit = em.find(CardLimit.class, 1L, LockModeType.PESSIMISTIC_WRITE);
            antifraud.check();
            limit.remaining -= 100;
            em.persist(new Authorization());
        }

        /** Хорошо, шаг 1: короткая транзакция резервирует сумму и сохраняет авторизацию в статусе PENDING. */
        @Transactional
        public Long reserve() {
            CardLimit limit = em.find(CardLimit.class, 1L, LockModeType.PESSIMISTIC_WRITE);
            limit.remaining -= 100;
            Authorization a = new Authorization();
            a.status = "PENDING_FRAUD_CHECK";
            em.persist(a);
            em.flush();
            return a.id;
        }

        /** Хорошо, шаг 3: вторая короткая транзакция проставляет итоговый статус. */
        @Transactional
        public void finish(Long id, String status) {
            em.find(Authorization.class, id).status = status;
        }
    }

    @Service
    static class AuthorizationService {
        final Tx tx;
        final Antifraud antifraud;
        AuthorizationService(Tx tx, Antifraud antifraud) { this.tx = tx; this.antifraud = antifraud; }

        void authorizeBad() throws Exception { tx.authorizeInOneTransaction(antifraud); }

        void authorizeGood() throws Exception {              // сам метод без @Transactional
            Long id = tx.reserve();                           // короткая транзакция
            boolean ok = antifraud.check();                   // HTTP вне транзакции
            tx.finish(id, ok ? "APPROVED" : "DECLINED");      // вторая короткая транзакция
        }
    }

    @Component
    static class Demo implements CommandLineRunner {
        final AuthorizationService service;
        final DataSource ds;
        final Antifraud antifraud;
        final Tx tx;

        Demo(AuthorizationService service, DataSource ds, Antifraud antifraud, Tx tx) {
            this.service = service; this.ds = ds; this.antifraud = antifraud; this.tx = tx;
        }

        interface Call { void run() throws Exception; }

        void scenario(String title, Call call) throws Exception {
            tx.resetLimit();
            antifraud.callsInsideTransaction.set(0);
            var pool = ((HikariDataSource) ds).getHikariPoolMXBean();
            AtomicInteger maxActive = new AtomicInteger();
            Thread sampler = new Thread(() -> {
                while (!Thread.currentThread().isInterrupted()) {
                    maxActive.accumulateAndGet(pool.getActiveConnections(), Math::max);
                    try { Thread.sleep(5); } catch (InterruptedException e) { return; }
                }
            });
            sampler.start();
            ExecutorService ex = Executors.newFixedThreadPool(CALLERS);
            List<Future<?>> fs = new ArrayList<>();
            long t0 = System.nanoTime();
            for (int i = 0; i < CALLERS; i++) fs.add(ex.submit(() -> { call.run(); return null; }));
            int ok = 0, failed = 0;
            String firstError = "";
            for (Future<?> f : fs) {
                try { f.get(); ok++; }
                catch (ExecutionException e) {
                    failed++;
                    if (firstError.isEmpty()) {
                        Throwable r = e.getCause();
                        while (r.getCause() != null) r = r.getCause();
                        firstError = r.getMessage();
                    }
                }
            }
            long ms = (System.nanoTime() - t0) / 1_000_000;
            sampler.interrupt();
            ex.shutdown();
            System.out.printf("%-30s успешно %d из %d, отказов %d, время %d мс, макс. занято соединений %d, HTTP внутри транзакции %d раз%n",
                    title, ok, CALLERS, failed, ms, maxActive.get(), antifraud.callsInsideTransaction.get());
            if (!firstError.isEmpty()) System.out.println("    первая ошибка: " + firstError);
        }

        @Override
        public void run(String... args) throws Exception {
            HttpServer server = HttpServer.create(new InetSocketAddress(0), 0);
            server.createContext("/check", exchange -> {
                try { Thread.sleep(ANTIFRAUD_DELAY_MS); } catch (InterruptedException ignored) { }
                byte[] body = "ok".getBytes();
                exchange.sendResponseHeaders(200, body.length);
                exchange.getResponseBody().write(body);
                exchange.close();
            });
            server.setExecutor(Executors.newCachedThreadPool());
            server.start();
            antifraudPort = server.getAddress().getPort();

            System.out.println("пул: 3 соединения, ожидание соединения 1 с, антифрод отвечает " + ANTIFRAUD_DELAY_MS
                    + " мс, одновременных вызовов " + CALLERS);
            scenario("HTTP внутри @Transactional", service::authorizeBad);
            scenario("HTTP вне транзакции", service::authorizeGood);
            server.stop(0);
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.datasource.hikari.maximum-pool-size", "3",
                "spring.datasource.hikari.connection-timeout", "1000",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
