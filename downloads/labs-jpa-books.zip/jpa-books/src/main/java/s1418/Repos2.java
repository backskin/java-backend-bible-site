package s1418;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

interface RegistryEntryNewRepository extends JpaRepository<RegistryEntryNew, UUID> { }
