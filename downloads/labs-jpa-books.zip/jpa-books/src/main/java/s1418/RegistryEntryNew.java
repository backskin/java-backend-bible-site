package s1418;

import jakarta.persistence.*;
import org.springframework.data.domain.Persistable;
import java.math.BigDecimal;
import java.util.UUID;

/** Та же строка с Persistable: флаг isNew сбрасывается после сохранения и загрузки. */
@Entity @Table(name = "registry_entry_new")
public class RegistryEntryNew implements Persistable<UUID> {
    @Id UUID id;
    String documentNo;
    BigDecimal amount;
    @Transient boolean isNew = true;
    protected RegistryEntryNew() {}
    RegistryEntryNew(UUID id, String documentNo, BigDecimal amount) { this.id = id; this.documentNo = documentNo; this.amount = amount; }
    @Override public UUID getId() { return id; }
    @Override public boolean isNew() { return isNew; }
    @PostPersist @PostLoad void markNotNew() { isNew = false; }
}
