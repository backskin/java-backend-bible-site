package s1418;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

interface RegistryEntryRepository extends JpaRepository<RegistryEntry, UUID> { }
