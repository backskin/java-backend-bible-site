package s1418;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

/** Разд. 14.18 гл. 12: saveAll с назначаемым UUID — SELECT перед каждой вставкой, и Persistable как лечение. */
@SpringBootApplication
public class App {

    public static class Spy implements org.hibernate.resource.jdbc.spi.StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s1418",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.properties.hibernate.jdbc.batch_size", "50",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", Spy.class.getName(),
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            var plain = ctx.getBean(RegistryEntryRepository.class);
            var persistable = ctx.getBean(RegistryEntryNewRepository.class);
            List<RegistryEntry> a = new ArrayList<>();
            List<RegistryEntryNew> b = new ArrayList<>();
            for (int i = 0; i < 1000; i++) {
                UUID id = UUID.randomUUID();
                a.add(new RegistryEntry(id, "П-" + i, BigDecimal.valueOf(i)));
                b.add(new RegistryEntryNew(id, "П-" + i, BigDecimal.valueOf(i)));
            }
            Spy.LOG.clear(); plain.saveAll(a);
            System.out.println("saveAll(1000), UUID из приложения:      " + count());
            Spy.LOG.clear(); persistable.saveAll(b);
            System.out.println("saveAll(1000), то же с Persistable:     " + count());
            System.out.println("пример: " + Spy.LOG.stream().filter(q -> q.startsWith("insert")).findFirst().orElse(""));
        }
    }

    static String count() {
        long sel = Spy.LOG.stream().filter(q -> q.startsWith("select")).count();
        long ins = Spy.LOG.stream().filter(q -> q.startsWith("insert")).count();
        return "SELECT " + sel + ", INSERT " + ins + " (подготовленных операторов; INSERT уходят пакетами)";
    }
}
