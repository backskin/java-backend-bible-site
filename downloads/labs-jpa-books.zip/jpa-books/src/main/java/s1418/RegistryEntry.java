package s1418;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.UUID;

/** Строка реестра с ключом, который назначает приложение (как в разд. 14.18). */
@Entity @Table(name = "registry_entry")
public class RegistryEntry {
    @Id UUID id;
    String documentNo;
    BigDecimal amount;
    protected RegistryEntry() {}
    RegistryEntry(UUID id, String documentNo, BigDecimal amount) { this.id = id; this.documentNo = documentNo; this.amount = amount; }
}
