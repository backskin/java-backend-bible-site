package s36;

import jakarta.persistence.*;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.Map;

@SpringBootApplication
public class App {

    @Entity(name = "Payment") @Table(name = "payment")
    static class Payment {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
        Long id;
        BigDecimal amount = new BigDecimal("100.00");
        String status = "NEW";
        @Column(updatable = false)
        String createdBy = "dev.team";
    }

    @Entity(name = "WidePayment") @Table(name = "wide_payment") @DynamicUpdate
    static class WidePayment {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
        Long id;
        BigDecimal amount = new BigDecimal("100.00");
        String status = "NEW";
    }

    @Entity(name = "Client") @Table(name = "client")
    static class Client {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
        Long id;
        String name = "Acme";
    }

    @Component
    static class Demo implements CommandLineRunner {
        @PersistenceContext EntityManager em;
        final TransactionTemplate tx;
        final PlatformTransactionManager ptm;
        final LoggingSystem logging;

        Demo(TransactionTemplate tx, PlatformTransactionManager ptm, LoggingSystem logging) {
            this.tx = tx; this.ptm = ptm; this.logging = logging;
        }

        @Override
        public void run(String... args) {
            Long id = tx.execute(s -> {
                Payment p = new Payment();
                em.persist(p);
                em.persist(new Client());
                return p.id;
            });
            Long wideId = tx.execute(s -> {
                WidePayment w = new WidePayment();
                em.persist(w);
                return w.id;
            });
            System.out.println("=== данные созданы");

            System.out.println("--- 1. присваивание тех же значений");
            tx.executeWithoutResult(s -> {
                Payment p = em.find(Payment.class, id);
                p.status = new String("NEW");               // тот же текст, другой объект
                p.amount = new BigDecimal("100.00");
            });
            System.out.println("(UPDATE нет)");

            System.out.println("--- 2. setScale(4): 100.00 -> 100.0000, то же число");
            tx.executeWithoutResult(s -> {
                Payment p = em.find(Payment.class, id);
                p.amount = p.amount.setScale(4);
            });
            System.out.println("(UPDATE нет: BigDecimal сравнивается через compareTo)");

            System.out.println("--- 3. меняем один статус: в UPDATE все колонки");
            tx.executeWithoutResult(s -> em.find(Payment.class, id).status = "PAID");

            System.out.println("--- 4. @Column(updatable = false): изменение игнорируется молча");
            tx.executeWithoutResult(s -> {
                Payment p = em.find(Payment.class, id);
                p.createdBy = "someone.else";
                p.status = "DONE";
            });
            String cb = tx.execute(s -> em.find(Payment.class, id).createdBy);
            System.out.println("createdBy в базе: " + cb);

            System.out.println("--- 5. @DynamicUpdate: в UPDATE только изменённая колонка");
            tx.executeWithoutResult(s -> em.find(WidePayment.class, wideId).status = "PAID");

            System.out.println("--- 6. стоимость обхода: 200 запросов по client при N управляемых payment");
            logging.setLogLevel("org.hibernate.SQL", LogLevel.OFF);
            tx.executeWithoutResult(s -> {
                for (int i = 0; i < 10_000; i++) {
                    em.persist(new Payment());
                    if (i % 500 == 499) { em.flush(); em.clear(); }
                }
            });
            TransactionTemplate ro = new TransactionTemplate(ptm);
            ro.setReadOnly(true);
            for (int round = 1; round <= 3; round++) {
                long empty = tx.execute(s -> loop());
                long managed = tx.execute(s -> { load(); return loop(); });
                long readOnly = ro.execute(s -> { load(); return loop(); });
                System.out.printf("прогон %d: пустой контекст %d мс, 10 000 managed %d мс, те же в readOnly %d мс%n",
                        round, empty, managed, readOnly);
            }
        }

        void load() {
            em.createQuery("select p from Payment p", Payment.class).getResultList();
        }

        long loop() {
            long t = System.nanoTime();
            for (int i = 0; i < 200; i++)
                em.createQuery("select count(c) from Client c", Long.class).getSingleResult();
            return (System.nanoTime() - t) / 1_000_000;
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.jpa.hibernate.ddl-auto", "create",
                "logging.level.org.hibernate.SQL", "DEBUG",
                "logging.pattern.console", "%msg%n",
                "logging.level.root", "WARN",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
