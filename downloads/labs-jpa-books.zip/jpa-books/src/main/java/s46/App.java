package s46;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import jakarta.persistence.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Разд. 4.6 гл. 12 на встроенном PostgreSQL 15.5: IDENTITY против SEQUENCE(allocationSize = 50) при batch_size = 50,
 * pg_stat_statements с reWriteBatchedInserts и без, и что ловит ddl-auto=validate, если последовательности нет.
 */
@SpringBootApplication
public class App {

    @Entity(name = "EIdentity") @Table(name = "e_identity")
    public static class EIdentity {
        @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long id;
        String payload;
    }

    @Entity(name = "ESequence") @Table(name = "e_sequence")
    public static class ESequence {
        @Id
        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "g")
        @SequenceGenerator(name = "g", sequenceName = "e_sequence_seq", allocationSize = 50)
        Long id;
        String payload;
    }

    /** Платёжное поручение с @GeneratedValue без strategy (AUTO). */
    @Entity(name = "PayOrder") @Table(name = "pay_order")
    public static class PayOrder {
        @Id @GeneratedValue Long id;
        String payload;
    }

    public static class Spy implements org.hibernate.resource.jdbc.spi.StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    public static void main(String[] args) throws Exception {
        var pg = EmbeddedPostgres.builder()
                .setServerConfig("shared_preload_libraries", "pg_stat_statements")
                .setErrorRedirector(ProcessBuilder.Redirect.DISCARD)
                .setOutputRedirector(ProcessBuilder.Redirect.DISCARD)
                .start();
        try (var c = pg.getPostgresDatabase().getConnection(); var st = c.createStatement()) {
            st.execute("create extension if not exists pg_stat_statements");
            var rs = st.executeQuery("select version()"); rs.next();
            System.out.println(rs.getString(1).replaceAll(",.*", ""));
        }
        for (boolean rewrite : new boolean[]{false, true}) {
            try (ConfigurableApplicationContext ctx = start(pg, rewrite, "create-drop")) {
                EntityManager em = ctx.getBean(EntityManager.class);
                TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
                try (var c = pg.getPostgresDatabase().getConnection(); var st = c.createStatement()) { st.execute("select pg_stat_statements_reset()"); }
                Spy.LOG.clear();
                tx.executeWithoutResult(s -> { for (int i = 0; i < 100; i++) { var e = new EIdentity(); e.payload = "п" + i; em.persist(e); } });
                long identityPrepared = Spy.LOG.stream().filter(q -> q.startsWith("insert into e_identity")).count();
                String identitySql = Spy.LOG.stream().filter(q -> q.startsWith("insert into e_identity")).findFirst().orElse("");
                Spy.LOG.clear();
                tx.executeWithoutResult(s -> { for (int i = 0; i < 100; i++) { var e = new ESequence(); e.payload = "п" + i; em.persist(e); } });
                long nextval = Spy.LOG.stream().filter(q -> q.contains("nextval")).count();
                System.out.println("reWriteBatchedInserts=" + rewrite);
                if (!rewrite) {
                    System.out.println("   IDENTITY: подготовлено операторов insert " + identityPrepared + ", текст: " + identitySql);
                    System.out.println("   SEQUENCE: обращений к последовательности " + nextval + " (" + Spy.LOG.stream().filter(q -> q.contains("nextval")).findFirst().orElse("") + ")");
                }
                try (var c = pg.getPostgresDatabase().getConnection(); var st = c.createStatement()) {
                    var rs = st.executeQuery("select calls, rows, left(query, 90) from pg_stat_statements where query like 'insert into e_%' order by query");
                    while (rs.next()) System.out.printf("   pg_stat_statements: calls=%d rows=%d  %s%n", rs.getLong(1), rs.getLong(2), rs.getString(3));
                }
            }
        }
        // ddl-auto=validate: таблица pay_order есть, последовательности pay_order_seq нет
        try (var c = pg.getPostgresDatabase().getConnection(); var st = c.createStatement()) {
            st.execute("drop table if exists pay_order cascade; drop sequence if exists pay_order_seq");
            st.execute("create table pay_order (id bigint primary key, payload varchar(255))");
            st.execute("create table e_identity (id bigserial primary key, payload varchar(255))");
            st.execute("create table e_sequence (id bigint primary key, payload varchar(255)); create sequence e_sequence_seq increment by 50");
        }
        try (ConfigurableApplicationContext ctx = start(pg, false, "validate")) {
            System.out.println("ddl-auto=validate без pay_order_seq: контекст поднялся");
        } catch (RuntimeException e) {
            Throwable c = e; while (c.getCause() != null) c = c.getCause();
            System.out.println("ddl-auto=validate без pay_order_seq: " + c.getClass().getSimpleName() + ": " + c.getMessage());
        }
        pg.close();
    }

    static ConfigurableApplicationContext start(EmbeddedPostgres pg, boolean rewrite, String ddl) {
        Map<String, Object> props = new HashMap<>(Map.of(
                "spring.datasource.url", pg.getJdbcUrl("postgres", "postgres") + (rewrite ? "&reWriteBatchedInserts=true" : ""),
                "spring.datasource.username", "postgres",
                "spring.datasource.password", "postgres",
                "spring.jpa.hibernate.ddl-auto", ddl,
                "spring.jpa.properties.hibernate.jdbc.batch_size", "50",
                "spring.jpa.properties.hibernate.order_inserts", "true",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", Spy.class.getName(),
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF"));
        props.put("spring.main.banner-mode", "off");
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(props);
        return app.run();
    }
}
