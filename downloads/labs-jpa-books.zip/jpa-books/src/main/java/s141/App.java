package s141;

import jakarta.persistence.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/** Разд. 14.1 гл. 12: удаление и вставка по одному уникальному ключу в одной транзакции и порядок ActionQueue. */
@SpringBootApplication
public class App {

    @Entity(name = "Setting")
    @Table(name = "setting", uniqueConstraints = @UniqueConstraint(name = "uq_setting_user_key", columnNames = {"user_id", "setting_key"}))
    public static class Setting {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE) Long id;
        @Column(name = "user_id") Long userId;
        @Column(name = "setting_key") String key;
        @Column(name = "setting_value") String value;
        protected Setting() {}
        Setting(Long userId, String key, String value) { this.userId = userId; this.key = key; this.value = value; }
    }

    public static class Spy implements org.hibernate.resource.jdbc.spi.StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s141",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", Spy.class.getName(),
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString());
            for (boolean flushBetween : new boolean[]{false, true}) {
                long user = flushBetween ? 2L : 1L;
                tx.executeWithoutResult(s -> {
                    em.persist(new Setting(user, "limit.daily", "100000"));
                    em.persist(new Setting(user, "sms.enabled", "true"));
                });
                Spy.LOG.clear();
                try {
                    tx.executeWithoutResult(s -> {
                        // «обновить набор настроек»: удалить старые, вставить новые; ключ limit.daily совпадает
                        em.createQuery("select s from Setting s where s.userId = :u", Setting.class).setParameter("u", user)
                                .getResultList().forEach(em::remove);
                        if (flushBetween) em.flush();
                        em.persist(new Setting(user, "limit.daily", "150000"));
                        em.persist(new Setting(user, "push.enabled", "true"));
                    });
                    System.out.println((flushBetween ? "с em.flush() между удалением и вставкой" : "без flush") + " → транзакция зафиксирована");
                } catch (RuntimeException e) {
                    Throwable c = e; while (c.getCause() != null) c = c.getCause();
                    System.out.println((flushBetween ? "с em.flush() между удалением и вставкой" : "без flush") + " → " + c.getClass().getSimpleName() + ": "
                            + c.getMessage().lines().findFirst().orElse("").replaceAll("\s+", " ").substring(0, Math.min(120, c.getMessage().length())));
                }
                System.out.println("   порядок операторов: " + Spy.LOG.stream().filter(q -> !q.startsWith("select"))
                        .map(q -> q.substring(0, q.indexOf(' ', 7))).toList());
            }
        }
    }
}
