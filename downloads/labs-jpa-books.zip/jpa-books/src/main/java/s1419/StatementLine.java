package s1419;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity @Table(name = "statement_line")
public class StatementLine {
    @Id @GeneratedValue(strategy = GenerationType.SEQUENCE) Long id;
    Long accountId;
    BigDecimal amount;
    protected StatementLine() {}
    StatementLine(Long accountId, BigDecimal amount) { this.accountId = accountId; this.amount = amount; }
}
