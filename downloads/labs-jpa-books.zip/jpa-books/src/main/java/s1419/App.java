package s1419;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.Map;
import java.util.function.Supplier;

/** Разд. 14.19 гл. 12: Stream из репозитория без окружающей транзакции и обе неудачные попытки починить. */
@SpringBootApplication
public class App {
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s1419",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            StatementLineRepository repo = ctx.getBean(StatementLineRepository.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            tx.executeWithoutResult(s -> { for (int i = 0; i < 1000; i++) repo.save(new StatementLine(7L, BigDecimal.valueOf(i))); });
            run("без транзакции", () -> { try (var s = repo.streamByAccountId(7L)) { return s.count(); } });
            run("@Transactional на методе репозитория", () -> { try (var s = repo.streamTxByAccountId(7L)) { return s.count(); } });
            run("транзакция снаружи (TransactionTemplate)", () -> tx.execute(st -> { try (var s = repo.streamByAccountId(7L)) { return s.count(); } }));
        }
    }

    static void run(String title, Supplier<Long> call) {
        try {
            System.out.printf("%-42s → прочитано строк %d%n", title, call.get());
        } catch (RuntimeException e) {
            System.out.printf("%-42s → %s: %s%n", title, e.getClass().getSimpleName(), String.valueOf(e.getMessage()).lines().findFirst().orElse(""));
        }
    }
}
