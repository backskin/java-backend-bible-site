package s1419;

import org.springframework.data.repository.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.stream.Stream;

public interface StatementLineRepository extends Repository<StatementLine, Long> {
    Stream<StatementLine> streamByAccountId(Long accountId);

    /** «Первая попытка» из инцидента: транзакция прямо на методе репозитория. */
    @Transactional(readOnly = true)
    Stream<StatementLine> streamTxByAccountId(Long accountId);

    void save(StatementLine line);
}
