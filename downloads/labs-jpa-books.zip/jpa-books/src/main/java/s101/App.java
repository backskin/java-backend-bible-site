package s101;

import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Разд. 10.1, 10.5 и 10.8 гл. 12: что попадает в пакеты JDBC в Hibernate 7.4.5.
 * Считает вызовы addBatch/executeBatch/executeUpdate на уровне JDBC через обёртку над DataSource.
 * Аргумент: versioned=false — передать hibernate.jdbc.batch_versioned_data=false (в Hibernate 6.6 такое свойство было).
 */
@SpringBootApplication
public class App {

    /** Платёж реестра с @Version: UPDATE версионированной сущности. */
    @Entity(name = "RegistryPayment") @Table(name = "registry_payment")
    public static class RegistryPayment {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE) Long id;
        @Version int version;
        BigDecimal amount;
        String status = "NEW";
        String comment;
    }

    /** Тот же платёж с @DynamicUpdate. */
    @Entity(name = "RegistryPaymentDyn") @Table(name = "registry_payment_dyn") @DynamicUpdate
    public static class RegistryPaymentDyn {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE) Long id;
        BigDecimal amount;
        String status = "NEW";
        String comment;
    }

    /** Строка выгрузки без версии: для StatelessSession. */
    @Entity(name = "ExportRow") @Table(name = "export_row")
    public static class ExportRow {
        @Id @GeneratedValue(strategy = GenerationType.SEQUENCE) Long id;
        String payload;
    }

    /** Счётчики JDBC: размеры выполненных пакетов и число одиночных executeUpdate. */
    static final List<Integer> BATCHES = new ArrayList<>();
    static int singles;
    /** Сколько пакетов уже было отправлено, когда Hibernate пошёл за номером в последовательность. */
    static final List<Integer> SEQ = new ArrayList<>();
    static int pending;

    @Bean
    static BeanPostProcessor countingDataSource() {
        return new BeanPostProcessor() {
            @Override public Object postProcessAfterInitialization(Object bean, String name) {
                if (!(bean instanceof DataSource ds)) return bean;
                return Proxy.newProxyInstance(App.class.getClassLoader(), new Class<?>[]{DataSource.class}, (p, m, a) -> {
                    Object r = invoke(m, ds, a);
                    return r instanceof Connection c ? wrap(c) : r;
                });
            }
        };
    }

    static Connection wrap(Connection c) {
        return (Connection) Proxy.newProxyInstance(App.class.getClassLoader(), new Class<?>[]{Connection.class}, (p, m, a) -> {
            Object r = invoke(m, c, a);
            if (r instanceof PreparedStatement ps && m.getName().equals("prepareStatement")) {
                String sql = String.valueOf(a[0]).toLowerCase();
                if (sql.contains("next value for")) SEQ.add(BATCHES.size());
                boolean dml = sql.startsWith("insert") || sql.startsWith("update") || sql.startsWith("delete");
                return Proxy.newProxyInstance(App.class.getClassLoader(), new Class<?>[]{PreparedStatement.class}, (p2, m2, a2) -> {
                    switch (m2.getName()) {
                        case "addBatch" -> pending++;
                        case "executeBatch" -> { BATCHES.add(pending); pending = 0; }
                        case "executeUpdate" -> { if (dml) singles++; }
                        default -> { }
                    }
                    return invoke(m2, ps, a2);
                });
            }
            return r;
        });
    }

    static Object invoke(java.lang.reflect.Method m, Object target, Object[] a) throws Throwable {
        try { return m.invoke(target, a); } catch (InvocationTargetException e) { throw e.getCause(); }
    }

    static void reset() { SEQ.clear(); BATCHES.clear(); singles = 0; pending = 0; }

    static String report() {
        return "пакетов " + BATCHES.size() + (BATCHES.isEmpty() ? "" : " размером " + BATCHES) + ", одиночных executeUpdate " + singles + (SEQ.isEmpty() ? "" : "; обращений к последовательности " + SEQ.size() + ", к моменту каждого отправлено пакетов " + SEQ + (pending == 0 ? "" : ", в незакрытом пакете " + pending));
    }

    public static void main(String[] args) {
        boolean versionedOff = List.of(args).contains("versioned=false");
        var props = new java.util.HashMap<String, Object>(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s101",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.properties.hibernate.jdbc.batch_size", "50",
                "spring.jpa.properties.hibernate.order_updates", "true",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        if (versionedOff) props.put("spring.jpa.properties.hibernate.jdbc.batch_versioned_data", "false");
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(props);
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManagerFactory emf = ctx.getBean(EntityManagerFactory.class);
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString()
                    + (versionedOff ? ", задано hibernate.jdbc.batch_versioned_data=false" : ""));

            tx.executeWithoutResult(s -> {
                for (int i = 0; i < 100; i++) {
                    var p = new RegistryPayment(); p.amount = BigDecimal.valueOf(i); em.persist(p);
                    var d = new RegistryPaymentDyn(); d.amount = BigDecimal.valueOf(i); em.persist(d);
                }
            });

            reset();
            tx.executeWithoutResult(s -> em.createQuery("from RegistryPayment", RegistryPayment.class)
                    .getResultList().forEach(p -> p.status = "PAID"));
            System.out.println("1. UPDATE 100 сущностей с @Version:                     " + report());

            reset();
            tx.executeWithoutResult(s -> em.createQuery("from RegistryPaymentDyn", RegistryPaymentDyn.class)
                    .getResultList().forEach(p -> p.status = "PAID"));
            System.out.println("2. @DynamicUpdate, у всех меняется одно и то же поле:  " + report());

            reset();
            tx.executeWithoutResult(s -> {
                var list = em.createQuery("from RegistryPaymentDyn order by id", RegistryPaymentDyn.class).getResultList();
                for (int i = 0; i < list.size(); i++) {
                    if (i % 2 == 0) list.get(i).status = "SETTLED"; else list.get(i).comment = "сверено";
                }
            });
            System.out.println("3. @DynamicUpdate, чередуются два разных поля:        " + report());

            SessionFactory sf = emf.unwrap(SessionFactory.class);
            if (List.of(args).contains("stateless-first")) {   // та же вставка на нетронутой последовательности
                reset();
                try (StatelessSession ss = sf.openStatelessSession()) {
                    ss.setJdbcBatchSize(50);
                    var t = ss.beginTransaction();
                    List<Long> ids = new ArrayList<>();
                    for (int i = 0; i < 100; i++) { var r = new ExportRow(); r.payload = "строка " + i; ss.insert(r); ids.add(r.id); }
                    t.commit();
                    System.out.println("0. setJdbcBatchSize(50) на нетронутой последовательности: " + report()
                            + "; id первой строки " + ids.get(0) + ", последней " + ids.get(99));
                }
            }
            reset();
            try (StatelessSession ss = sf.openStatelessSession()) {
                var t = ss.beginTransaction();
                for (int i = 0; i < 100; i++) { var r = new ExportRow(); r.payload = "строка " + i; ss.insert(r); }
                t.commit();
            }
            System.out.println("4. StatelessSession.insert ×100, batch_size=50 в настройках: " + report());

            reset();
            try (StatelessSession ss = sf.openStatelessSession()) {
                ss.setJdbcBatchSize(50);
                var t = ss.beginTransaction();
                List<Long> ids = new ArrayList<>();
                for (int i = 0; i < 100; i++) { var r = new ExportRow(); r.payload = "строка " + i; ss.insert(r); ids.add(r.id); }
                t.commit();
                System.out.println("5. StatelessSession с setJdbcBatchSize(50):              " + report()
                        + "; id первой строки " + ids.get(0) + ", последней " + ids.get(99));
            }

            reset();
            try (StatelessSession ss = sf.openStatelessSession()) {
                var t = ss.beginTransaction();
                List<ExportRow> rows = new ArrayList<>();
                for (int i = 0; i < 100; i++) { var r = new ExportRow(); r.payload = "строка " + i; rows.add(r); }
                ss.insertMultiple(rows);
                t.commit();
            }
            System.out.println("6. StatelessSession.insertMultiple(100 строк):           " + report());
        }
    }
}
