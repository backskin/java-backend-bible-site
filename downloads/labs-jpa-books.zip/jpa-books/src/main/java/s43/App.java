package s43;

import jakarta.persistence.*;
import org.hibernate.annotations.UuidGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Разд. 4.3 гл. 12: какую версию UUID дают стили @UuidGenerator в Hibernate 7.4.5
 * и растут ли значения в том порядке, в каком их сравнивает индекс (побайтно, как uuid в PostgreSQL).
 */
@SpringBootApplication
public class App {

    @Entity(name = "PayRandom") @Table(name = "pay_random")
    public static class PayRandom { @Id @GeneratedValue @UuidGenerator(style = UuidGenerator.Style.RANDOM) UUID id; }

    @Entity(name = "PayAuto") @Table(name = "pay_auto")
    public static class PayAuto { @Id @GeneratedValue @UuidGenerator UUID id; }

    @Entity(name = "PayTime") @Table(name = "pay_time")
    public static class PayTime { @Id @GeneratedValue @UuidGenerator(style = UuidGenerator.Style.TIME) UUID id; }

    @Entity(name = "PayV6") @Table(name = "pay_v6")
    public static class PayV6 { @Id @GeneratedValue @UuidGenerator(style = UuidGenerator.Style.VERSION_6) UUID id; }

    @Entity(name = "PayV7") @Table(name = "pay_v7")
    public static class PayV7 { @Id @GeneratedValue @UuidGenerator(style = UuidGenerator.Style.VERSION_7) UUID id; }

    @Entity(name = "PayPlain") @Table(name = "pay_plain")
    public static class PayPlain { @Id @GeneratedValue UUID id; }

    /** Побайтное беззнаковое сравнение — так uuid сортирует PostgreSQL и любой индекс по 16 байтам. */
    static int cmp(UUID a, UUID b) {
        int c = Long.compareUnsigned(a.getMostSignificantBits(), b.getMostSignificantBits());
        return c != 0 ? c : Long.compareUnsigned(a.getLeastSignificantBits(), b.getLeastSignificantBits());
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:s43",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + "; по 10 000 ключей на стиль, вставка подряд в одном потоке");
            run("RANDOM", em, tx, PayRandom::new, p -> p.id);
            run("AUTO (по умолчанию)", em, tx, PayAuto::new, p -> p.id);
            run("@GeneratedValue без @UuidGenerator", em, tx, PayPlain::new, p -> p.id);
            run("TIME", em, tx, PayTime::new, p -> p.id);
            run("VERSION_6", em, tx, PayV6::new, p -> p.id);
            run("VERSION_7", em, tx, PayV7::new, p -> p.id);
        }
    }

    /** В версии 1 от Hibernate первые 8 цифр — IPv4-адрес машины; в опубликованный вывод он не попадает. */
    static String mask(UUID u) { return u.version() == 1 ? "<IPv4>" + u.toString().substring(8) : u.toString(); }

    static <E> void run(String style, EntityManager em, TransactionTemplate tx, Supplier<E> factory, java.util.function.Function<E, UUID> id) {
        List<UUID> ids = new ArrayList<>();
        tx.executeWithoutResult(s -> {
            for (int i = 0; i < 10_000; i++) {
                E e = factory.get(); em.persist(e); ids.add(id.apply(e));
                if (i % 1000 == 999) { em.flush(); em.clear(); }
            }
        });
        int ascending = 0;
        for (int i = 1; i < ids.size(); i++) if (cmp(ids.get(i - 1), ids.get(i)) < 0) ascending++;
        System.out.printf("%-36s версия %d, вариант %d; следующий больше предыдущего в %5.1f%% пар; первые: %s, %s%n",
                style, ids.get(0).version(), ids.get(0).variant(), 100.0 * ascending / (ids.size() - 1), mask(ids.get(0)), mask(ids.get(1)));
    }
}
