package s12diag;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Разд. 16 гл. 12 на Hibernate 7.4.5 и встроенном PostgreSQL 15.5: какие логгеры что печатают.
 * Шаблон журнала выводит имя логгера, поэтому видно, откуда пришла строка:
 * org.hibernate.SQL (текст), org.hibernate.orm.jdbc.bind (значения), org.hibernate.SQL_SLOW (медленные, порог 20 мс),
 * метрики сессии при generate_statistics (логгер org.hibernate.session.metrics; org.hibernate.stat не печатает их), а также строки spring.jpa.show-sql, которые идут в System.out без логгера.
 * Затем сценарий N+1 (10 платежей, у каждого ленивый клиент) и счётчики Statistics,
 * и поля StatefulPersistenceContext, которые ищут в дампе кучи.
 */
@SpringBootApplication
public class App {

    @Entity(name = "Customer") @Table(name = "customer")
    public static class Customer {
        @Id Long id;
        String name;
        public String getName() { return name; }
    }

    @Entity(name = "Payment") @Table(name = "payment")
    public static class Payment {
        @Id Long id;
        BigDecimal amount;
        @ManyToOne(fetch = FetchType.LAZY) Customer customer;
    }

    public static void main(String[] args) throws Exception {
        var pg = EmbeddedPostgres.builder()
                .setErrorRedirector(ProcessBuilder.Redirect.DISCARD).setOutputRedirector(ProcessBuilder.Redirect.DISCARD).start();
        try (var c = pg.getPostgresDatabase().getConnection(); var st = c.createStatement()) {
            st.execute("create table customer (id bigint primary key, name varchar(255))");
            st.execute("create table payment (id bigint primary key, amount numeric(19,2), customer_id bigint references customer)");
            st.execute("insert into customer select g, 'Клиент ' || g from generate_series(1, 10) g");
            st.execute("insert into payment select g, g * 100, g from generate_series(1, 10) g");
        }
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.ofEntries(
                Map.entry("spring.datasource.url", pg.getJdbcUrl("postgres", "postgres")),
                Map.entry("spring.datasource.username", "postgres"),
                Map.entry("spring.datasource.password", "postgres"),
                Map.entry("spring.jpa.hibernate.ddl-auto", "none"),
                Map.entry("spring.jpa.open-in-view", "false"),
                Map.entry("spring.jpa.show-sql", "true"),
                Map.entry("spring.jpa.properties.hibernate.generate_statistics", "true"),
                Map.entry("spring.jpa.properties.hibernate.log_slow_query", "20"),
                Map.entry("spring.main.web-application-type", "none"),
                Map.entry("spring.main.banner-mode", "off"),
                Map.entry("logging.pattern.console", "LOG [%logger] %msg%n"),
                Map.entry("logging.level.root", "OFF"),
                Map.entry("logging.level.org.hibernate.SQL", "DEBUG"),
                Map.entry("logging.level.org.hibernate.orm.jdbc.bind", "TRACE"),
                Map.entry("logging.level.org.hibernate.SQL_SLOW", "INFO"),
                Map.entry("logging.level.org.hibernate.stat", "DEBUG"),
                Map.entry("logging.level.org.hibernate.session.metrics", "DEBUG")));
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            TransactionTemplate tx = ctx.getBean(TransactionTemplate.class);
            SessionFactory sf = ctx.getBean(EntityManagerFactory.class).unwrap(SessionFactory.class);
            Statistics s = sf.getStatistics();
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", PostgreSQL 15.5, JDK " + Runtime.version());

            System.out.println("--- 1. один find с параметром: текст, значение, строка show-sql");
            tx.executeWithoutResult(t -> em.find(Payment.class, 1L));

            System.out.println("--- 2. медленный native-запрос (pg_sleep 50 мс при пороге 20 мс)");
            tx.executeWithoutResult(t -> em.createNativeQuery("select pg_sleep(0.05)").getSingleResult());

            System.out.println("--- 3. N+1: 10 платежей, у каждого обращение к ленивому клиенту");
            s.clear();
            tx.executeWithoutResult(t -> {
                List<Payment> list = em.createQuery("select p from Payment p order by p.id", Payment.class).getResultList();
                for (Payment p : list) p.customer.getName().length();
            });
            System.out.printf("Statistics: prepareStatement=%d, queryExecution=%d, entityLoad=%d, entityFetch=%d, collectionFetch=%d, flush=%d%n",
                    s.getPrepareStatementCount(), s.getQueryExecutionCount(), s.getEntityLoadCount(),
                    s.getEntityFetchCount(), s.getCollectionFetchCount(), s.getFlushCount());
        }
        System.out.println("--- 4. поля StatefulPersistenceContext (что искать в дампе кучи)");
        for (Field f : Class.forName("org.hibernate.engine.internal.StatefulPersistenceContext").getDeclaredFields()) {
            if (!Modifier.isStatic(f.getModifiers())) System.out.println("  " + f.getType().getSimpleName() + " " + f.getName());
        }
        pg.close();
    }
}
