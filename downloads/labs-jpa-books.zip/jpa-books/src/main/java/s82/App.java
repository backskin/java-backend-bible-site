package s82;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import jakarta.persistence.*;
import org.hibernate.Session;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.File;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Разд. 8.2 гл. 12: что делает readOnly = true в связке JpaTransactionManager + Hibernate 7.4.5
 * и что из этого защищает от записи на PostgreSQL 15.5 и на H2.
 * Аргумент h2 — запустить на H2 вместо встроенного PostgreSQL.
 */
@SpringBootApplication
public class App {

    @Entity(name = "Account") @Table(name = "account")
    public static class Account {
        @Id Long id;
        BigDecimal balance;
        protected Account() {}
        Account(Long id, BigDecimal balance) { this.id = id; this.balance = balance; }
    }

    public static void main(String[] args) throws Exception {
        boolean h2 = List.of(args).contains("h2");
        EmbeddedPostgres pg = null;
        Map<String, Object> props = new HashMap<>(Map.of(
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        if (h2) {
            props.put("spring.datasource.url", "jdbc:h2:mem:s82");
        } else {
            new File("pglog82").mkdirs();
            pg = EmbeddedPostgres.builder()
                    .setServerConfig("log_statement", "all")
                    .setServerConfig("logging_collector", "on")
                    .setServerConfig("log_directory", new File("pglog82").getAbsolutePath().replace('\\', '/'))
                    .setServerConfig("log_filename", "pg.log")
                    .setErrorRedirector(ProcessBuilder.Redirect.DISCARD)
                    .setOutputRedirector(ProcessBuilder.Redirect.DISCARD)
                    .start();
            props.put("spring.datasource.url", pg.getJdbcUrl("postgres", "postgres"));
            props.put("spring.datasource.username", "postgres");
            props.put("spring.datasource.password", "postgres");
        }
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(props);
        try (ConfigurableApplicationContext ctx = app.run()) {
            EntityManager em = ctx.getBean(EntityManager.class);
            PlatformTransactionManager tm = ctx.getBean(PlatformTransactionManager.class);
            TransactionTemplate rw = new TransactionTemplate(tm);
            TransactionTemplate ro = new TransactionTemplate(tm);
            ro.setReadOnly(true);
            System.out.println("hibernate-core " + org.hibernate.Version.getVersionString() + ", база: " + (h2 ? "H2 2.4" : "PostgreSQL 15.5")
                    + ", менеджер транзакций: " + tm.getClass().getSimpleName());
            rw.executeWithoutResult(s -> em.persist(new Account(1L, new BigDecimal("100.00"))));

            step("1. что выставлено внутри readOnly-транзакции", ro, s -> {
                Session session = em.unwrap(Session.class);
                Account a = em.find(Account.class, 1L);
                boolean conn = session.doReturningWork(c -> c.isReadOnly());
                System.out.println("   FlushMode сессии = " + session.getHibernateFlushMode()
                        + ", defaultReadOnly = " + session.isDefaultReadOnly()
                        + ", сущность readOnly = " + session.isReadOnly(a)
                        + ", Connection.isReadOnly() = " + conn);
            });
            step("2. изменили поле managed-сущности, коммит", ro, s -> em.find(Account.class, 1L).balance = new BigDecimal("1.00"));
            show(rw, em);
            step("3. изменили поле и вызвали em.flush() вручную", ro, s -> { em.find(Account.class, 1L).balance = new BigDecimal("2.00"); em.flush(); });
            show(rw, em);
            step("4. native UPDATE через executeUpdate()", ro, s -> em.createNativeQuery("update account set balance = 3.00 where id = 1").executeUpdate());
            show(rw, em);
            step("5. persist новой сущности и em.flush()", ro, s -> { em.persist(new Account(2L, BigDecimal.TEN)); em.flush(); });
            rw.executeWithoutResult(s -> System.out.println("   строк в account: " + em.createQuery("select count(a) from Account a").getSingleResult()));
            step("6. JPQL UPDATE через executeUpdate()", ro, s -> em.createQuery("update Account a set a.balance = 4.00 where a.id = 1").executeUpdate());
            show(rw, em);
            step("7. em.remove() сущности, загруженной в readOnly, и em.flush()", ro, s -> { em.remove(em.find(Account.class, 1L)); em.flush(); });
            rw.executeWithoutResult(s -> System.out.println("   строка id=1 в базе: " + (em.find(Account.class, 1L) != null ? "есть" : "удалена")));
        }
        if (pg != null) {
            Thread.sleep(1000);
            System.out.println("--- как начинались транзакции, по журналу PostgreSQL (log_statement = all):");
            var seen = new java.util.LinkedHashMap<String, Integer>();
            for (String line : java.nio.file.Files.readAllLines(new File("pglog82/pg.log").toPath())) {
                int i = line.indexOf("LOG:  statement: BEGIN");   // PgJDBC шлёт BEGIN простым запросом
                if (i >= 0) seen.merge(line.substring(i + 17).trim(), 1, Integer::sum);
            }
            seen.forEach((k, v) -> System.out.println("   " + k + " — " + v + " раз"));
            pg.close();
        }
    }

    static void step(String title, TransactionTemplate tx, Consumer<org.springframework.transaction.TransactionStatus> body) {
        System.out.println(title);
        try {
            tx.executeWithoutResult(body);
            System.out.println("   транзакция завершилась без ошибок");
        } catch (RuntimeException e) {
            Throwable c = e; while (c.getCause() != null) c = c.getCause();
            System.out.println("   " + e.getClass().getSimpleName() + " ← " + c.getClass().getSimpleName() + ": " + c.getMessage().lines().findFirst().orElse(""));
        }
    }

    static void show(TransactionTemplate rw, EntityManager em) {
        rw.executeWithoutResult(s -> System.out.println("   в базе balance = " + em.find(Account.class, 1L).balance));
    }
}
