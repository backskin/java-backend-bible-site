package s53;

import jakarta.persistence.*;
import org.hibernate.resource.jdbc.spi.StatementInspector;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;

@SpringBootApplication
public class App {

    /** Запоминает SQL, уходящий в базу (пакетная отправка выключена, поэтому каждая строка - отдельный оператор). */
    public static class SqlSpy implements StatementInspector {
        static final List<String> LOG = new CopyOnWriteArrayList<>();
        @Override public String inspect(String sql) { LOG.add(sql); return sql; }
    }

    @Entity(name = "Child") @Table(name = "child")
    static class Child {
        @Id @GeneratedValue Long id;
        String name = "c";
        @Override public boolean equals(Object o) { return o instanceof Child c && id != null && id.equals(c.id); }
        @Override public int hashCode() { return Child.class.hashCode(); }
    }

    /** Однонаправленная @OneToMany, List без @OrderColumn (bag), связующая таблица. */
    @Entity(name = "BagParent") @Table(name = "bag_parent")
    static class BagParent {
        @Id @GeneratedValue Long id;
        @OneToMany(cascade = CascadeType.ALL) List<Child> children = new ArrayList<>();
    }

    /** То же, но Set. */
    @Entity(name = "SetParent") @Table(name = "set_parent")
    static class SetParent {
        @Id @GeneratedValue Long id;
        @OneToMany(cascade = CascadeType.ALL) Set<Child> children = new HashSet<>();
    }

    /** Однонаправленная с @JoinColumn: связующей таблицы нет. */
    @Entity(name = "JoinColParent") @Table(name = "joincol_parent")
    static class JoinColParent {
        @Id @GeneratedValue Long id;
        @OneToMany(cascade = CascadeType.ALL) @JoinColumn(name = "owner_id") List<Child> children = new ArrayList<>();
    }

    /** List с @OrderColumn. */
    @Entity(name = "OrderedParent") @Table(name = "ordered_parent")
    static class OrderedParent {
        @Id @GeneratedValue Long id;
        @OneToMany(cascade = CascadeType.ALL) @OrderColumn(name = "pos") List<Child> children = new ArrayList<>();
    }

    @Component
    static class Demo implements CommandLineRunner {
        @PersistenceContext EntityManager em;
        final TransactionTemplate tx;
        Demo(TransactionTemplate tx) { this.tx = tx; }

        static final int N = 100;

        <P> void scenario(String title, Class<P> type, Function<P, Collection<Child>> children, String where) {
            Long id = tx.execute(s -> {
                P p = newParent(type);
                for (int i = 0; i < N; i++) children.apply(p).add(new Child());
                em.persist(p);
                return (Long) em.getEntityManagerFactory().getPersistenceUnitUtil().getIdentifier(p);
            });
            tx.executeWithoutResult(s -> {
                P p = em.find(type, id);
                Collection<Child> c = children.apply(p);
                Child victim = where.equals("first") ? c.iterator().next() : last(c);
                SqlSpy.LOG.clear();
                c.remove(victim);              // убираем один элемент из ста
            });
            Map<String, Integer> counts = new TreeMap<>();
            for (String q : SqlSpy.LOG) {
                String kind = q.trim().toLowerCase().split("\s+")[0];
                if (kind.equals("select")) continue;
                counts.merge(kind + " " + table(q), 1, Integer::sum);
            }
            System.out.printf("%-44s %s%n", title, counts);
        }

        static Child last(Collection<Child> c) { Child r = null; for (Child x : c) r = x; return r; }

        static String table(String q) {
            String s = q.toLowerCase();
            for (String t : new String[]{"bag_parent_children", "set_parent_children", "ordered_parent_children", "child"}) if (s.contains(t)) return t;
            return "?";
        }

        <P> P newParent(Class<P> type) {
            try { var ctor = type.getDeclaredConstructor(); ctor.setAccessible(true); return ctor.newInstance(); }
            catch (ReflectiveOperationException e) { throw new RuntimeException(e); }
        }

        @Override
        public void run(String... args) {
            System.out.println("убрали 1 элемент из " + N + ", оператор: сколько раз");
            scenario("List без @OrderColumn (bag), связующая таблица", BagParent.class, p -> p.children, "first");
            scenario("Set, связующая таблица", SetParent.class, p -> p.children, "first");
            scenario("List + @JoinColumn (без таблицы)", JoinColParent.class, p -> p.children, "first");
            scenario("List + @OrderColumn, убрали первый", OrderedParent.class, p -> p.children, "first");
            scenario("List + @OrderColumn, убрали последний", OrderedParent.class, p -> p.children, "last");
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of(
                "spring.datasource.url", "jdbc:h2:mem:demo",
                "spring.jpa.hibernate.ddl-auto", "create",
                "spring.jpa.properties.hibernate.session_factory.statement_inspector", SqlSpy.class.getName(),
                "spring.jpa.open-in-view", "false",
                "spring.main.web-application-type", "none",
                "logging.level.root", "OFF",
                "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
