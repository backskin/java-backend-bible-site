package s12rw;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;

import java.sql.*;
import java.util.Arrays;

/**
 * Разд. 2.6 гл. 12: что возвращает executeBatch() PgJDBC с reWriteBatchedInserts и без него.
 * Пять INSERT и три UPDATE (where id <= 1, 2, 3: затрагивают 1, 2 и 3 строки) на встроенном PostgreSQL.
 */
public class App {
    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.start()) {
            System.out.println("PgJDBC " + org.postgresql.util.DriverInfo.DRIVER_VERSION + ", JDK " + Runtime.version());
            for (boolean rewrite : new boolean[]{false, true}) {
                String url = pg.getJdbcUrl("postgres", "postgres") + "&reWriteBatchedInserts=" + rewrite;
                try (Connection c = DriverManager.getConnection(url)) {
                    if (!rewrite) System.out.println("PostgreSQL " + c.getMetaData().getDatabaseProductVersion());
                    try (Statement s = c.createStatement()) {
                        s.execute("drop table if exists payment");
                        s.execute("create table payment(id bigint primary key, grp int)");
                    }
                    int[] ins;
                    try (PreparedStatement ps = c.prepareStatement("insert into payment(id, grp) values (?, ?)")) {
                        int[] grp = {1, 2, 2, 3, 3};
                        for (int i = 0; i < 5; i++) { ps.setLong(1, i + 1); ps.setInt(2, grp[i]); ps.addBatch(); }
                        ins = ps.executeBatch();
                    }
                    int[] upd;
                    try (PreparedStatement ps = c.prepareStatement("update payment set grp = grp where id <= ?")) {
                        for (int g = 1; g <= 3; g++) { ps.setInt(1, g); ps.addBatch(); }
                        upd = ps.executeBatch();
                    }
                    System.out.println("reWriteBatchedInserts=" + rewrite + ": 5 INSERT -> " + Arrays.toString(ins)
                            + ", 3 UPDATE -> " + Arrays.toString(upd) + "   (SUCCESS_NO_INFO = " + Statement.SUCCESS_NO_INFO + ")");
                }
            }
        }
    }
}
