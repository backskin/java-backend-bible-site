# Spring Data JPA и Hibernate 7.4: сорок опытов по разделам главы 12 на H2 и встроенном PostgreSQL

Стенд к главе 12. Один проект Maven (Spring Boot 4.1.1, Hibernate 7.4.5, H2 2.4, PostgreSQL 15.5 через zonky `embedded-postgres`), в котором каждый опыт - пакет `sNNN` с классом `App`, где номер отвечает разделу главы: `demo` (3.1, переходы состояний сущности), `s315` и `s35` (автоматический сброс, порядок операторов, `readOnly`), `s36` (стоимость грязной проверки на 10 000 сущностей), `s43` и `s45` (UUID и `equals` сущностей), `s53` (bag против `@OrderColumn`), `s61`, `s611`, `s66` (N+1, пагинация с `join fetch`, `@BatchSize`), `s72` (Open Session in View), `s81`–`s86` (транзакции, `readOnly`, откат по checked-исключению, события после фиксации), `s91`, `s101` (пакетные операции, `@Version`), `s124`, `s1212` (`Page`, `setMaxResults` с join), `s141`–`s1419` (инциденты: уникальный индекс без `flush`, `LazyInitializationException` в `@Async`, `idle_in_transaction_session_timeout`, порядок `FlushMode = COMMIT`, HTTP внутри `@Transactional`, `Persistable`, `Stream` без транзакции), `s12p`, `s12rw`, `s12conn`, `s12ins`, `s12fl`, `s12opt`, `s12q`, `s12diag` (сверка с книгами, `reWriteBatchedInserts`, момент захвата соединения, четыре способа вставки 100 000 строк, порции с `clear()`, `OPTIMISTIC`, ошибки в `@Query`, логгеры и `Statistics`). Выводы автора - `s12-<пакет>.txt`; `pom-412.xml` и `s12-v412.txt` - повторный прогон на Boot 4.1.2 и Hibernate 7.4.13.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, bash. В `pom.xml` бинарники PostgreSQL для Windows x64; на Linux или macOS замените артефакт `embedded-postgres-binaries-windows-amd64`.

## Запуск

```bash
bash run.sh demo s61
```

Без аргументов скрипт прогоняет все сорок пакетов (десятки минут); варианты с флагами (`lazy`, `versioned=false`, `fail`, `h2`, `FlushMode = COMMIT`) описаны в шапке `run.sh`. В IDEA на каждый `App` есть конфигурация `<пакет>: App`; для не-веб опытов в ней нужен `-Dspring.main.web-application-type=none`.

## Что должно получиться

Вывод каждого пакета приведен в соответствующем разделе главы; времена (`s36`, `s12ins`, `s12fl`) зависят от машины, порядок операторов и исключения воспроизводятся.
