create table if not exists loan_decision (
    application_id varchar(32) primary key,
    amount_kopecks bigint not null,
    status varchar(16) not null
);

create table if not exists notification (
    application_id varchar(32) primary key,
    text varchar(200) not null
);
