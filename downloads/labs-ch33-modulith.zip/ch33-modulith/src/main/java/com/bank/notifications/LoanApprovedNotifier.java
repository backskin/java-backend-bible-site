package com.bank.notifications;

import com.bank.loans.LoanApproved;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.modulith.events.ApplicationModuleListener;
import org.springframework.stereotype.Component;

/**
 * Модуль уведомлений: на одобрение заявки записывает уведомление клиенту.
 * При системном свойстве {@code notifier.fail=true} падает, изображая недоступный почтовый шлюз.
 */
@Component
class LoanApprovedNotifier {

    private final JdbcTemplate jdbc;

    LoanApprovedNotifier(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @ApplicationModuleListener
    void on(LoanApproved event) {
        System.out.println("  слушатель уведомлений: поток " + Thread.currentThread().getName() + ", заявка " + event.applicationId());
        if (Boolean.getBoolean("notifier.fail")) {
            throw new IllegalStateException("почтовый шлюз недоступен");
        }
        jdbc.update("insert into notification(application_id, text) values (?, ?)",
                event.applicationId(), "Заявка " + event.applicationId() + " одобрена");
    }
}
