package com.bank.loans;

/** Событие модуля кредитов: заявка одобрена. Публичный тип модуля, на него подписываются соседи. */
public record LoanApproved(String applicationId, long amountKopecks) {
}
