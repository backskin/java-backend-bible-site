package com.bank.loans;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** API модуля кредитов: одобрение заявки записывает решение и публикует событие в одной транзакции. */
@Service
public class LoanDecisions {

    private final JdbcTemplate jdbc;
    private final ApplicationEventPublisher events;

    LoanDecisions(JdbcTemplate jdbc, ApplicationEventPublisher events) {
        this.jdbc = jdbc;
        this.events = events;
    }

    /** Одобряет заявку и публикует {@link LoanApproved}; слушатели других модулей получают событие после фиксации. */
    @Transactional
    public void approve(String applicationId, long amountKopecks) {
        jdbc.update("insert into loan_decision(application_id, amount_kopecks, status) values (?, ?, 'APPROVED')",
                applicationId, amountKopecks);
        events.publishEvent(new LoanApproved(applicationId, amountKopecks));
    }
}
