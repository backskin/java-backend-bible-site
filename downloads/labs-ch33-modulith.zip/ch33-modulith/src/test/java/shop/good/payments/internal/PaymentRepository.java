package shop.good.payments.internal;

import java.sql.Connection;

/** Хранилище модуля: только он знает про базу. */
public class PaymentRepository {
    Connection connection;      // работа с БД спрятана внутри модуля

    public void save(String clientId, long amount) { }
}
