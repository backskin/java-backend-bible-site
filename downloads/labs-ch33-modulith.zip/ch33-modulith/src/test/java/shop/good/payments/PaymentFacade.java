package shop.good.payments;

import shop.good.limits.LimitsApi;
import shop.good.payments.internal.PaymentRepository;

/** Публичный API модуля payments. */
public class PaymentFacade {
    private final PaymentRepository repository = new PaymentRepository();
    private final LimitsApi limits = new LimitsApi();

    public boolean pay(String clientId, long amount) {
        if (!limits.fits(clientId, amount)) return false;
        repository.save(clientId, amount);
        return true;
    }
}
