package shop.good.antifraud;

import shop.good.payments.PaymentFacade;

public class FraudCheck {
    private final PaymentFacade payments = new PaymentFacade();     // только публичный API соседа
    public boolean allow(String clientId, long amount) { return amount < 5000; }
}
