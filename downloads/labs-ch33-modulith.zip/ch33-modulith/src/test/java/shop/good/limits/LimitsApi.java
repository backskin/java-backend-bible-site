package shop.good.limits;

public class LimitsApi {
    public boolean fits(String clientId, long amount) { return amount <= 1000; }
}
