package shop.bad.payments.internal;

public class PaymentRepository {
    public void save(String clientId, long amount) { }
    public long sumToday(String clientId) { return 0; }
}
