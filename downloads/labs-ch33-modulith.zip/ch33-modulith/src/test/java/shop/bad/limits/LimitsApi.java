package shop.bad.limits;

import java.sql.Connection;
import shop.bad.payments.PaymentFacade;

public class LimitsApi {
    Connection connection;                                          // SQL вне «своего» внутреннего пакета
    private final PaymentFacade payments = new PaymentFacade();     // payments -> limits -> payments: цикл

    public boolean fits(String clientId, long amount) { return payments.paidToday(clientId) + amount <= 1000; }
}
