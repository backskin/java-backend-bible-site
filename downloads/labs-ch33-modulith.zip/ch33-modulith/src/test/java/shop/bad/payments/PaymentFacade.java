package shop.bad.payments;

import shop.bad.limits.LimitsApi;
import shop.bad.payments.internal.PaymentRepository;

public class PaymentFacade {
    private final PaymentRepository repository = new PaymentRepository();
    private final LimitsApi limits = new LimitsApi();

    public boolean pay(String clientId, long amount) {
        if (!limits.fits(clientId, amount)) return false;
        repository.save(clientId, amount);
        return true;
    }

    public long paidToday(String clientId) { return 0; }
}
