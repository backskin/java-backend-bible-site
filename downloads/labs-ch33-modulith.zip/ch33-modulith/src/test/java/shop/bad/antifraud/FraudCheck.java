package shop.bad.antifraud;

import shop.bad.payments.internal.PaymentRepository;

public class FraudCheck {
    private final PaymentRepository repository = new PaymentRepository();   // обход публичного API: лезем в чужое хранилище
    public boolean allow(String clientId, long amount) { return repository.sumToday(clientId) + amount < 5000; }
}
