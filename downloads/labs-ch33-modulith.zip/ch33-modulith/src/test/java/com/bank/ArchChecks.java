package com.bank;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.EvaluationResult;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;
import static com.tngtech.archunit.library.dependencies.SlicesRuleDefinition.slices;

/**
 * Правила модульного монолита проверяются ArchUnit. Зависимость Maven: com.tngtech.archunit:archunit:1.5.1.
 * Классы shop.good и shop.bad лежат рядом в проекте; один и тот же набор правил применяется к обоим.
 */
public class ArchChecks {

    static void check(String title, ArchRule rule, JavaClasses classes) {
        EvaluationResult r = rule.evaluate(classes);
        System.out.println("  " + title + ": нарушений " + r.getFailureReport().getDetails().size());
        r.getFailureReport().getDetails().forEach(d -> System.out.println("      " + (d.lastIndexOf('(') > 0 ? d.substring(0, d.lastIndexOf('(')).trim() : d)));
    }

    public static void main(String[] args) {
        JavaClasses all = new ClassFileImporter().importPackages("shop");
        for (String variant : new String[]{"good", "bad"}) {
            JavaClasses classes = all.that(com.tngtech.archunit.base.DescribedPredicate.describe(variant,
                    c -> c.getPackageName().startsWith("shop." + variant)));
            System.out.println("=== структура shop." + variant);
            // 2.2 / 5.3: внутренний пакет модуля доступен только внутри самого модуля
            check("внутренний пакет payments виден только модулю payments",
                    noClasses().that().resideOutsideOfPackage("shop." + variant + ".payments..")
                            .should().dependOnClassesThat().resideInAPackage("shop." + variant + ".payments.internal.."), classes);
            // 6.1: работа с базой (java.sql) разрешена только во внутренних пакетах модулей
            check("доступ к java.sql только во внутренних пакетах",
                    noClasses().that().resideOutsideOfPackage("..internal..")
                            .should().dependOnClassesThat().resideInAPackage("java.sql.."), classes);
            // 5.3: между модулями нет циклов
            check("модули не образуют циклов",
                    slices().matching("shop." + variant + ".(*)..").should().beFreeOfCycles(), classes);
        }
    }
}
