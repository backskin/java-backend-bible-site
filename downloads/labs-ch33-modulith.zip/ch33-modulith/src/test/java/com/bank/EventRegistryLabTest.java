package com.bank;

import com.bank.loans.LoanDecisions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.modulith.core.ApplicationModules;
import org.springframework.modulith.events.ApplicationModuleListener;

import java.io.File;
import java.lang.annotation.Annotation;
import java.util.Arrays;

/**
 * Опыт гл. 33, разд. 2: событие между модулями при падении слушателя и повторная отправка при перезапуске.
 * Два запуска приложения на одной файловой базе H2: в первом слушатель уведомлений падает, во втором работает,
 * и включена повторная отправка незавершенных публикаций.
 */
class EventRegistryLabTest {

    @Test
    void lab() throws Exception {
        for (File f : new File("target").listFiles((d, n) -> n.startsWith("bank."))) f.delete();

        System.out.println("== состав @ApplicationModuleListener");
        for (Annotation a : ApplicationModuleListener.class.getAnnotations()) {
            if (!a.annotationType().getPackageName().startsWith("java.lang")) System.out.println("  " + a.annotationType().getSimpleName());
        }

        System.out.println("== модули");
        ApplicationModules modules = ApplicationModules.of(BankApplication.class);
        modules.forEach(m -> System.out.println("  " + m.getIdentifier() + ", базовый пакет " + m.getBasePackage().getName()));
        modules.verify();
        System.out.println("  verify() прошло");

        System.out.println("== запуск 1: слушатель уведомлений падает");
        System.setProperty("notifier.fail", "true");
        try (ConfigurableApplicationContext ctx = new SpringApplicationBuilder(BankApplication.class).run()) {
            ctx.getBean(LoanDecisions.class).approve("L-1001", 50_000_000);
            Thread.sleep(1500);
            dump(ctx.getBean(JdbcTemplate.class));
        }

        System.setProperty("notifier.fail", "false");
        System.out.println("== запуск 2: шлюз доступен, свойство повторной отправки не задано");
        try (ConfigurableApplicationContext ctx = new SpringApplicationBuilder(BankApplication.class).run()) {
            Thread.sleep(1500);
            dump(ctx.getBean(JdbcTemplate.class));
        }

        System.out.println("== запуск 3: шлюз доступен, republish-outstanding-events-on-restart=true");
        try (ConfigurableApplicationContext ctx = new SpringApplicationBuilder(BankApplication.class)
                .properties("spring.modulith.events.republish-outstanding-events-on-restart=true").run()) {
            Thread.sleep(1500);
            dump(ctx.getBean(JdbcTemplate.class));
        }
    }

    static void dump(JdbcTemplate jdbc) {
        System.out.println("  решения: " + jdbc.queryForList("select application_id, status from loan_decision"));
        System.out.println("  уведомления: " + jdbc.queryForList("select application_id, text from notification"));
        var cols = jdbc.queryForList("select column_name from information_schema.columns where table_name = 'EVENT_PUBLICATION' order by ordinal_position", String.class);
        String select = Arrays.stream(new String[] {"LISTENER_ID", "STATUS", "COMPLETION_ATTEMPTS", "COMPLETION_DATE"})
                .filter(cols::contains).reduce((a, b) -> a + ", " + b).orElse("*");
        System.out.println("  event_publication (" + cols.size() + " столбцов): " + jdbc.queryForList("select " + select + " from event_publication"));
    }
}
