# Модульный монолит: события между модулями и проверка границ

Стенд к главе 33, раздел 2. Spring Boot 4.1.2, Spring Modulith 2.1.2, H2 в файле `target/bank*`, JDK 21.

## Запуск

```bash
mvn test                                    # EventRegistryLabTest: три запуска приложения на одной базе
mvn test-compile dependency:build-classpath -Dmdep.outputFile=cp.txt -Dmdep.includeScope=test
java -cp "target/test-classes;$(cat cp.txt)" com.bank.ArchChecks   # на Linux и macOS разделитель ':'
```

`EventRegistryLabTest` одобряет заявку в модуле `loans`; слушатель модуля `notifications` в первом запуске падает (`-Dnotifier.fail=true` задается в тесте), во втором запуске работает без повторной отправки, в третьем - со свойством `spring.modulith.events.republish-outstanding-events-on-restart=true`. Тест печатает таблицы решений, уведомлений и `event_publication`.

`ArchChecks` применяет три правила ArchUnit к примерам `shop.good` и `shop.bad` из тестовых исходников.

## Выводы, приведенные в главе

- `s33-events.txt` - вывод `EventRegistryLabTest`.
- `s33-archchecks.txt` - вывод `ArchChecks`.
