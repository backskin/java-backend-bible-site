import java.util.concurrent.atomic.AtomicInteger;

/**
 * Small hot methods for PrintAssembly: volatile read/write, final-field constructor, CAS and getAndAdd.
 * Run: java -XX:+UnlockDiagnosticVMOptions -XX:+PrintAssembly -XX:CompileCommand=print,Barriers::* -XX:-TieredCompilation Barriers
 */
public class Barriers {
    static volatile int v;
    static int plain;
    static final AtomicInteger counter = new AtomicInteger();

    static final class Snapshot {
        final long limit;
        Snapshot(long limit) { this.limit = limit; }
    }
    static Snapshot published;

    static int volatileRead() { return v; }
    static void volatileWrite(int x) { v = x; }
    static void publishFinal(long x) { published = new Snapshot(x); }
    static boolean cas(int expect, int update) { return counter.compareAndSet(expect, update); }
    static int increment() { return counter.incrementAndGet(); }

    public static void main(String[] args) {
        long s = 0;
        for (int i = 0; i < 2_000_000; i++) {
            volatileWrite(i);
            s += volatileRead();
            publishFinal(i);
            cas(i, i + 1);
            s += increment();
        }
        System.out.println(s + " " + published.limit);
    }
}
