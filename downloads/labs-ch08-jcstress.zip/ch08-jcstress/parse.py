import re,glob,sys
out=[]
for f in sorted(glob.glob(sys.argv[1]+'/dev.team.jcs.JmmTests*.html')):
    t=open(f,encoding='utf-8',errors='replace').read()
    states=re.findall(r"<th nowrap align='center'>([^<]*)</th>",t)
    nums=re.findall(r"<td align='right'[^>]*>(\d+)</td>",t)
    s=[0]*len(states)
    for i,n in enumerate(nums): s[i%len(states)]+=int(n)
    out.append(f.split('JmmTests.')[1][:-5]+': '+', '.join(f'[{a}] {b:,}' for a,b in zip(states,s)))
print('\n'.join(out))
