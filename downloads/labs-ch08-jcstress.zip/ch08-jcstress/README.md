# Тест Деккера в jcstress и барьеры памяти в машинном коде x86 и ARM

Стенд к главе 08, раздел 1. `jcs/` - проект Maven с тестами `dev.team.jcs.JmmTests` для jcstress: `DekkerPlain` и `DekkerVolatile` показывают, что без `volatile` на x86 исход `0, 0` встречается в десятках процентов запусков, а с `volatile` ни разу; `parse.py` сводит HTML-отчет jcstress в одну строку на тест. `hsdis/` - Dockerfile, который собирает `hsdis` с Capstone поверх `eclipse-temurin:21-jdk`, и класс `Barriers`, чей машинный код снят с `-XX:+PrintAssembly` на x86-64 и на AArch64 (под QEMU). Выводы автора - `s01-jmm-jdk21.txt`, `s01-jmm-jdk25.txt`, сводки `s01-summary-*.txt`, `hsdis/x86.txt` и `hsdis/arm64.txt`.

## Что нужно

- JDK 21 и Maven для `jcs/`; прогон занимает минуты (у автора по 400 млн запусков на тест).
- Docker для `hsdis/`; вариант AArch64 требует `docker run --platform linux/arm64`.

## Запуск

```bash
cd jcs && mvn -q package && java -jar target/jcstress.jar -m quick
```

Отчет появляется в `jcs/results/`; сводка: `python parse.py jcs/results`. Машинный код:

```bash
cd hsdis && docker build -t jbb-hsdis . && docker run --rm jbb-hsdis
```

## Что должно получиться

`DekkerPlain: [0, 0]` с сотнями миллионов наблюдений на x86, у `DekkerVolatile` исхода `[0, 0]` нет. В листинге x86 после записи в `volatile` стоит `lock addl $0, -0x40(%rsp)`; листинг AArch64 для сравнения - в `hsdis/arm64.txt`.
