package dev.team.jcs;

import org.openjdk.jcstress.annotations.*;
import org.openjdk.jcstress.infra.results.II_Result;
import org.openjdk.jcstress.infra.results.I_Result;
import org.openjdk.jcstress.infra.results.J_Result;

/**
 * Опыты главы 8 с моделью памяти Java: перестановка записи и чтения (тест Деккера),
 * потерянный инкремент volatile, публикация объекта через гонку, разрыв long.
 */
public class JmmTests {

    /** Тест Деккера на обычных полях: исход 0, 0 модель разрешает. */
    @JCStressTest
    @Outcome(id = {"0, 1", "1, 0", "1, 1"}, expect = Expect.ACCEPTABLE, desc = "последовательное перемежение")
    @Outcome(id = "0, 0", expect = Expect.ACCEPTABLE_INTERESTING, desc = "оба чтения обогнали чужую запись")
    @State
    public static class DekkerPlain {
        int x, y;
        @Actor public void a1(II_Result r) { x = 1; r.r1 = y; }
        @Actor public void a2(II_Result r) { y = 1; r.r2 = x; }
    }

    /** Тот же тест на volatile-полях: исход 0, 0 запрещён. */
    @JCStressTest
    @Outcome(id = {"0, 1", "1, 0", "1, 1"}, expect = Expect.ACCEPTABLE, desc = "последовательное перемежение")
    @Outcome(id = "0, 0", expect = Expect.FORBIDDEN, desc = "запрещено для volatile")
    @State
    public static class DekkerVolatile {
        volatile int x, y;
        @Actor public void a1(II_Result r) { x = 1; r.r1 = y; }
        @Actor public void a2(II_Result r) { y = 1; r.r2 = x; }
    }

    /** Два потока по разу делают ++ над volatile-полем. */
    @JCStressTest
    @Outcome(id = "2", expect = Expect.ACCEPTABLE, desc = "оба инкремента дошли")
    @Outcome(id = "1", expect = Expect.ACCEPTABLE_INTERESTING, desc = "один инкремент потерян")
    @State
    public static class VolatileIncrement {
        volatile int v;
        @Actor public void a1() { v++; }
        @Actor public void a2() { v++; }
        @Arbiter public void arbiter(I_Result r) { r.r1 = v; }
    }

    static class Holder {
        int a;
        int b;
        Holder() { a = 1; b = 2; }
    }

    static class FinalHolder {
        final int a;
        final int b;
        FinalHolder() { a = 1; b = 2; }
    }

    /** Публикация через обычное поле: частично видимый объект модель разрешает. */
    @JCStressTest
    @Outcome(id = "-1, -1", expect = Expect.ACCEPTABLE, desc = "ссылку ещё не увидели")
    @Outcome(id = "1, 2", expect = Expect.ACCEPTABLE, desc = "объект виден целиком")
    @Outcome(expect = Expect.ACCEPTABLE_INTERESTING, desc = "частично видимый объект")
    @State
    public static class PublishPlain {
        Holder h;
        @Actor public void writer() { h = new Holder(); }
        @Actor public void reader(II_Result r) {
            Holder t = h;
            if (t == null) { r.r1 = -1; r.r2 = -1; } else { r.r1 = t.a; r.r2 = t.b; }
        }
    }

    /** Публикация через обычное поле объекта с final-полями: частичный объект запрещён. */
    @JCStressTest
    @Outcome(id = "-1, -1", expect = Expect.ACCEPTABLE, desc = "ссылку ещё не увидели")
    @Outcome(id = "1, 2", expect = Expect.ACCEPTABLE, desc = "объект виден целиком")
    @Outcome(expect = Expect.FORBIDDEN, desc = "частично видимый объект с final-полями")
    @State
    public static class PublishFinal {
        FinalHolder h;
        @Actor public void writer() { h = new FinalHolder(); }
        @Actor public void reader(II_Result r) {
            FinalHolder t = h;
            if (t == null) { r.r1 = -1; r.r2 = -1; } else { r.r1 = t.a; r.r2 = t.b; }
        }
    }

    /** Публикация через volatile-поле: частичный объект запрещён. */
    @JCStressTest
    @Outcome(id = "-1, -1", expect = Expect.ACCEPTABLE, desc = "ссылку ещё не увидели")
    @Outcome(id = "1, 2", expect = Expect.ACCEPTABLE, desc = "объект виден целиком")
    @Outcome(expect = Expect.FORBIDDEN, desc = "частично видимый объект при volatile")
    @State
    public static class PublishVolatile {
        volatile Holder h;
        @Actor public void writer() { h = new Holder(); }
        @Actor public void reader(II_Result r) {
            Holder t = h;
            if (t == null) { r.r1 = -1; r.r2 = -1; } else { r.r1 = t.a; r.r2 = t.b; }
        }
    }

    /** Разрыв 64-битной записи: JLS 17.7 разрешает для обычного long. */
    @JCStressTest
    @Outcome(id = {"0", "-1"}, expect = Expect.ACCEPTABLE, desc = "целое значение")
    @Outcome(expect = Expect.ACCEPTABLE_INTERESTING, desc = "половинки от разных записей")
    @State
    public static class LongTearing {
        long v;
        @Actor public void writer() { v = -1L; }
        @Actor public void reader(J_Result r) { r.r1 = v; }
    }
}
