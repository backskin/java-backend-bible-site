// OUT: s09-t25-switch-fallthrough
class T25SwitchFallthrough {
    public static void main(String[] args) {
        int day = 3;
        switch (day) {
            case 1: System.out.print("Mon ");
            case 2: System.out.print("Tue ");
            case 3: System.out.print("Wed ");
            case 4: System.out.print("Thu "); break;
            case 5: System.out.print("Fri ");
            default: System.out.print("other ");
        }
        System.out.println();

        int x = 7;
        switch (x) {
            default: System.out.print("default ");
            case 1: System.out.print("one ");
            case 2: System.out.print("two "); break;
            case 3: System.out.print("three ");
        }
        System.out.println();
        String name = switch (day) {
            case 1, 7 -> "выходной";
            case 2, 3, 4, 5, 6 -> "рабочий";
            default -> "неизвестно";
        };
        System.out.println(name);
    }
}
