// OUT: s09-t04-init-order
class T04InitOrder {
    public static void main(String[] args) {
        new B();
        System.out.print("| ");
        new B();
        System.out.println();
    }
}
class A {
    static { System.out.print("SA "); }
    { System.out.print("IA "); }
    A() { System.out.print("CA "); }
}
class B extends A {
    static { System.out.print("SB "); }
    { System.out.print("IB "); }
    B() { System.out.print("CB "); }
}
