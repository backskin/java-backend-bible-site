// MODE: javac
// OUT: s09-t30-capture-compile
import java.util.*;
class T30CaptureCompile {
    void f() {
        List<Runnable> tasks = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            tasks.add(() -> System.out.print(i));
        }
    }
}
