// MODE: javac
// JAVAC: -Xlint:removal
// OUT: s09-t01-new-integer-javac
class T01NewIntegerWarning {
    Integer f = new Integer(127);
}
