// OUT: s09-t19-arrays-aslist
import java.util.*;
class T19ArraysAsList {
    public static void main(String[] args) {
        String[] backing = {"a", "b", "c"};
        List<String> list = Arrays.asList(backing);
        list.set(0, "z");
        System.out.println(list + " " + Arrays.toString(backing) + " " + list.getClass().getName());

        int[] primitives = {1, 2, 3};
        Integer[] boxed = {1, 2, 3};
        System.out.println(Arrays.asList(primitives).size());
        System.out.println(Arrays.asList(boxed).size());
        System.out.println(Arrays.stream(primitives).boxed().toList());
        list.add("d");
    }
}
