// OUT: s09-t28-static-hiding
class T28StaticHiding {
    @SuppressWarnings("static-access")
    public static void main(String[] args) {
        Parent p = new Child();
        System.out.println(p.instanceName());
        System.out.println(p.staticName());
        System.out.println(Parent.staticName());
        System.out.println(Child.staticName());
        System.out.println(new Child().callStatic());
        Parent nul = null;
        System.out.println("через null-ссылку: " + nul.staticName());
    }
}
class Parent {
    static String staticName() { return "Parent.static"; }
    String instanceName() { return "Parent.instance"; }
    static String callStatic() { return staticName(); }
}
class Child extends Parent {
    static String staticName() { return "Child.static"; }
    @Override String instanceName() { return "Child.instance"; }
}
