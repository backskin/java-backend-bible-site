// MODE: javac
// OUT: s09-t06-overload-null
class T06OverloadNull {
    static void f(Object o) { System.out.println("Object"); }
    static void f(String s) { System.out.println("String"); }
    static void f(Integer i) { System.out.println("Integer"); }

    public static void main(String[] args) {
        f(null);
    }
}
