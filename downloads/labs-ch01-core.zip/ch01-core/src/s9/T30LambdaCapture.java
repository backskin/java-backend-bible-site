// OUT: s09-t30-lambda-capture
import java.util.*;
class T30LambdaCapture {
    public static void main(String[] args) {
        List<Runnable> tasks = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            int copy = i;
            tasks.add(() -> System.out.print(copy + " "));
        }
        tasks.forEach(Runnable::run);
        System.out.println();

        List<Runnable> tasks2 = new ArrayList<>();
        for (String s : List.of("a", "b", "c")) {
            tasks2.add(() -> System.out.print(s + " "));
        }
        tasks2.forEach(Runnable::run);
        System.out.println();
    }
}
