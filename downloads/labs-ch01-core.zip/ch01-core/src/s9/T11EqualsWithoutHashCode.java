// OUT: s09-t11-equals-without-hashcode
import java.util.*;
class T11EqualsWithoutHashCode {
    static class Key {
        final int id;
        Key(int id) { this.id = id; }
        @Override public boolean equals(Object o) { return o instanceof Key k && k.id == id; }
    }
    public static void main(String[] args) {
        Set<Key> set = new HashSet<>();
        set.add(new Key(1));
        set.add(new Key(1));
        System.out.println(set.size());
        System.out.println(set.contains(new Key(1)));

        List<Key> list = new ArrayList<>();
        list.add(new Key(1));
        System.out.println(list.contains(new Key(1)));
    }
}
