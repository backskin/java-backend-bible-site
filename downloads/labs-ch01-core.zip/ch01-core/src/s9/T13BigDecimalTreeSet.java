// OUT: s09-t13-bigdecimal-treeset
import java.math.BigDecimal;
import java.util.*;
class T13BigDecimalTreeSet {
    public static void main(String[] args) {
        var a = new BigDecimal("1.0");
        var b = new BigDecimal("1.00");

        System.out.println(a.equals(b));
        System.out.println(a.compareTo(b));
        System.out.println(new HashSet<>(List.of(a, b)).size());
        System.out.println(new TreeSet<>(List.of(a, b)).size());

        Map<BigDecimal, String> hm = new HashMap<>();
        hm.put(a, "first"); hm.put(b, "second");
        TreeMap<BigDecimal, String> tm = new TreeMap<>();
        tm.put(a, "first"); tm.put(b, "second");
        System.out.println(hm.size() + " " + tm.size() + " " + tm.get(a));
        System.out.println("ключ в TreeMap: " + tm.firstKey());
    }
}
