// MODE: javap T27Javap
// OUT: s09-t27-javap
class T27Javap {
    static String classify(String code) {
        switch (code) {
            case "A": return "первый";
            case "B": return "второй";
            default:  return "прочее";
        }
    }
}
