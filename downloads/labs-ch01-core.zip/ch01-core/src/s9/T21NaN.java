// OUT: s09-t21-nan
import java.util.*;
class T21NaN {
    public static void main(String[] args) {
        double nan = Double.NaN;
        System.out.println(nan == nan);
        System.out.println(nan != nan);
        System.out.println(Double.valueOf(nan).equals(Double.valueOf(nan)));
        System.out.println(Double.compare(nan, nan));

        Set<Double> set = new HashSet<>();
        set.add(Double.NaN);
        System.out.println(set.contains(Double.NaN));

        System.out.println(Arrays.asList(1.0, Double.NaN).indexOf(Double.NaN));

        System.out.println(0.0 == -0.0);
        System.out.println(Double.valueOf(0.0).equals(-0.0));
        System.out.println(Double.compare(0.0, -0.0));
        System.out.println(Math.min(0.0, -0.0));
        System.out.println("Double.compare(NaN, +Inf) = " + Double.compare(nan, Double.POSITIVE_INFINITY));
    }
}
