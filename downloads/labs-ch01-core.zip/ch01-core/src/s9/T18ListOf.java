// OUT: s09-t18-list-of
import java.util.*;
class T18ListOf {
    public static void main(String[] args) {
        System.out.println(List.of("a", "b").size());
        System.out.println(Arrays.asList("a", null).size());
        System.out.println(List.of("a", "a").size());
        try { System.out.println(List.of("a").contains(null)); } catch (Exception e) { System.out.println(e); }
        try { System.out.println(Set.of("a", "a").size()); } catch (Exception e) { System.out.println(e); }
        try { System.out.println(List.of("a", null).size()); } catch (Exception e) { System.out.println(e); }
        try { System.out.println(Map.of("k", "v").get(null)); } catch (Exception e) { System.out.println("Map.of(...).get(null): " + e); }
        try { System.out.println(List.of("a").indexOf(null)); } catch (Exception e) { System.out.println("List.of(...).indexOf(null): " + e); }
        System.out.println("Set.of(\"a\",\"b\",\"c\",\"d\",\"e\") в этом запуске: " + Set.of("a", "b", "c", "d", "e"));
    }
}
