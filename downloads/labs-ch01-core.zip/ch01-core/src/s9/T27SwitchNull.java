// OUT: s09-t27-switch-null
class T27SwitchNull {
    enum Status { NEW, PAID }
    static String classify(String code) {
        switch (code) {
            case "A": return "первый";
            case "B": return "второй";
            default:  return "прочее";
        }
    }
    static String classify21(String code) {
        return switch (code) {
            case null -> "не задано";
            case "A"  -> "первый";
            case "B"  -> "второй";
            default   -> "прочее";
        };
    }
    static String byEnum(Status s) {
        switch (s) { case NEW: return "new"; default: return "other"; }
    }
    public static void main(String[] args) {
        System.out.println(classify("A"));
        System.out.println(classify("Z"));
        System.out.println(classify21(null));
        try { byEnum(null); } catch (NullPointerException e) { System.out.println("enum: " + e); }
        System.out.println(classify(null));
    }
}
