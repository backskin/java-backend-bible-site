// OUT: s09-t26-char-arithmetic
class T26CharArithmetic {
    public static void main(String[] args) {
        System.out.println('a' + 1);
        System.out.println((char) ('a' + 1));
        System.out.println("" + 'a' + 1);
        System.out.println('a' + 'b');
        System.out.println("" + 'a' + 'b');

        char c = 'a';
        c += 1;
        System.out.println(c);

        System.out.println((char) -1 == '￿');
        System.out.println((int) '0');
        byte b = 10; b += 300;
        System.out.println("byte b = 10; b += 300 -> " + b);
    }
}
