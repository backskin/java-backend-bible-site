// MODE: javac
// JAVAC: -Xlint:fallthrough
// OUT: s09-t25-fallthrough-lint
class T25FallthroughLint {
    static void f(int day) {
        switch (day) {
            case 1: System.out.print("Mon ");
            case 2: System.out.print("Tue "); break;
            case 3: System.out.print("Wed ");
            // намеренное проваливание
            case 4: System.out.print("Thu "); break;
        }
    }
}
