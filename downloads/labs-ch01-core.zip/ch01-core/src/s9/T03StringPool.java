// OUT: s09-t03-string-pool
class T03StringPool {
    public static void main(String[] args) {
        String a = "java";
        String b = "ja" + "va";
        String part = "ja";
        String c = part + "va";
        final String fpart = "ja";
        String d = fpart + "va";
        String e = new String("java");
        String f = e.intern();

        System.out.println(a == b);
        System.out.println(a == c);
        System.out.println(a == d);
        System.out.println(a == e);
        System.out.println(a == f);
    }
}
