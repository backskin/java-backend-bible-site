// OUT: s09-t23-ternary-unboxing
import java.util.*;
class T23TernaryUnboxing {
    public static void main(String[] args) {
        Map<String, Boolean> flags = new HashMap<>();
        Boolean enabled = flags.containsKey("feature") ? flags.get("feature") : false;
        System.out.println(enabled);

        Integer i = null;
        System.out.println(true ? i : (Integer) 5);
        System.out.println(flags.getOrDefault("feature", false));
        flags.put("feature", null);
        System.out.println("getOrDefault при null в Map: " + flags.getOrDefault("feature", false));
        System.out.println("Boolean.TRUE.equals: " + Boolean.TRUE.equals(flags.get("feature")));
        try {
            int j = 5;
            System.out.println(true ? i : j);
        } catch (NullPointerException e) { System.out.println("числа: " + e.getMessage()); }
        enabled = flags.containsKey("feature") ? flags.get("feature") : false;
    }
}
