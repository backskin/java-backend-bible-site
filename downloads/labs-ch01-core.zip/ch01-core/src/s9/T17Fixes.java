// OUT: s09-t17-fixes
import java.util.*;
import static java.util.stream.Collectors.toCollection;
class T17Fixes {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(List.of("a", "b", "c"));
        list.removeIf(s -> s.equals("a"));
        System.out.println(list);
        list = new ArrayList<>(List.of("a", "b", "c"));
        Iterator<String> it = list.iterator();
        while (it.hasNext()) if (it.next().equals("a")) it.remove();
        System.out.println(list);
        list = new ArrayList<>(List.of("a", "b", "c"));
        list = list.stream().filter(s -> !s.equals("a")).collect(toCollection(ArrayList::new));
        System.out.println(list);

        var chm = new java.util.concurrent.ConcurrentHashMap<String, Integer>(Map.of("a", 1, "b", 2, "c", 3));
        for (String k : chm.keySet()) chm.remove("b");
        System.out.println("ConcurrentHashMap после удаления в обходе: " + new TreeMap<>(chm));
        var cow = new java.util.concurrent.CopyOnWriteArrayList<>(List.of("a", "b", "c"));
        int seen = 0;
        for (String s : cow) { cow.add("z"); seen++; }
        System.out.println("CopyOnWriteArrayList: обошли " + seen + ", размер стал " + cow.size());
    }
}
