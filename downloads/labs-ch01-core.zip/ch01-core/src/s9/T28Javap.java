// MODE: javap T28Javap
// OUT: s09-t28-javap
class T28Javap {
    static String m() {
        Parent p = new Child();
        return p.staticName();
    }
}
class Parent {
    static String staticName() { return "Parent.static"; }
}
class Child extends Parent {
    static String staticName() { return "Child.static"; }
}
