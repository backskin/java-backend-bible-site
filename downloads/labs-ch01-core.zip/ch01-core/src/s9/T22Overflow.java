// OUT: s09-t22-overflow
class T22Overflow {
    public static void main(String[] args) {
        System.out.println(Integer.MAX_VALUE + 1);
        System.out.println(Math.abs(Integer.MIN_VALUE));
        System.out.println(Integer.MIN_VALUE / -1);
        System.out.println(-7 % 3);
        System.out.println(Math.floorMod(-7, 3));
        System.out.println((int) 3_000_000_000L);
        System.out.println(1 << 32);
        System.out.println((byte) 130);

        long millis = 1000 * 60 * 60 * 24 * 30;      // «30 дней в миллисекундах»
        System.out.println(millis);
        System.out.println(1000L * 60 * 60 * 24 * 30);
        System.out.println(java.util.concurrent.TimeUnit.DAYS.toMillis(30));
        try { Math.addExact(Integer.MAX_VALUE, 1); } catch (ArithmeticException e) { System.out.println("addExact: " + e); }
    }
}
