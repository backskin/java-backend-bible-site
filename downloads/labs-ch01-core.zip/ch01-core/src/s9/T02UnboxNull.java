// OUT: s09-t02-unbox-null
import java.util.*;
class T02UnboxNull {
    public static void main(String[] args) {
        Map<String, Integer> counters = new HashMap<>();
        counters.put("a", 1);

        int x = counters.get("a");
        int y = counters.get("b");
        System.out.println(x + " " + y);
    }
}
