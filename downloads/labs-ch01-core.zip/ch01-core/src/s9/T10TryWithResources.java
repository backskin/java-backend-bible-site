// OUT: s09-t10-twr-suppressed
class T10TryWithResources {
    static class Res implements AutoCloseable {
        private final String name;
        Res(String name) { this.name = name; System.out.println("open " + name); }
        @Override public void close() {
            System.out.println("close " + name);
            throw new IllegalStateException("close failed: " + name);
        }
    }

    public static void main(String[] args) {
        try (Res a = new Res("A"); Res b = new Res("B")) {
            throw new RuntimeException("body");
        } catch (Exception e) {
            System.out.println("caught: " + e.getMessage());
            for (Throwable s : e.getSuppressed()) System.out.println("suppressed: " + s.getMessage());
        }
        System.out.println("-- тело не бросает:");
        try (Res a = new Res("A"); Res b = new Res("B")) {
            System.out.println("body ok");
        } catch (Exception e) {
            System.out.println("caught: " + e.getMessage());
            for (Throwable s : e.getSuppressed()) System.out.println("suppressed: " + s.getMessage());
        }
        System.out.println("-- старый try/finally:");
        try {
            Res a = new Res("A");
            try {
                throw new RuntimeException("body");
            } finally {
                a.close();
            }
        } catch (Exception e) {
            System.out.println("caught: " + e.getMessage() + ", suppressed: " + e.getSuppressed().length);
        }
    }
}
