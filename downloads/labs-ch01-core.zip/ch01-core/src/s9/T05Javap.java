// MODE: javap Derived
// OUT: s09-t05-javap
class Base {
    Base() { print(); }
    void print() { System.out.println("Base"); }
}
class Derived extends Base {
    private final int value = 42;
    private String name = "derived";
    @Override void print() { System.out.println("Derived: " + value + " " + name); }
}
