// OUT: s09-t31-optional
import java.util.*;
class T31Optional {
    static int calls = 0;
    static String loadDefault() { calls++; return "d"; }
    public static void main(String[] args) {
        System.out.println(Optional.ofNullable(null).isPresent());
        System.out.println(Optional.empty().orElse("default"));
        System.out.println(Optional.of("x").map(s -> (String) null).isPresent());

        Optional<String> o = Optional.of("v");
        o.orElse(loadDefault());
        System.out.println("orElse при значении: loadDefault вызван " + calls + " раз");
        calls = 0;
        o.orElseGet(() -> loadDefault());
        System.out.println("orElseGet при значении: loadDefault вызван " + calls + " раз");
        System.out.println("Optional instanceof Serializable: " + ((Object) o instanceof java.io.Serializable));

        String s = null;
        System.out.println(Optional.of(s));
    }
}
