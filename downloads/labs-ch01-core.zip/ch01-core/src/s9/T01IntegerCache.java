// OUT: s09-t01-integer-cache
class T01IntegerCache {
    @SuppressWarnings("removal")
    public static void main(String[] args) {
        Integer a = 127, b = 127;
        Integer c = 128, d = 128;
        Integer e = Integer.valueOf(127);
        Integer f = new Integer(127);           // deprecated, но компилируется
        int g = 128;

        System.out.println(a == b);
        System.out.println(c == d);
        System.out.println(a == e);
        System.out.println(a == f);
        System.out.println(c == g);
        System.out.println(c.equals(d));
    }
}
