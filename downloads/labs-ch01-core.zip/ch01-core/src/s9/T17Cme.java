// OUT: s09-t17-cme
import java.util.*;
class T17Cme {
    public static void main(String[] args) {
        List<String> second = new ArrayList<>(List.of("a", "b", "c"));
        for (String s : second) { if (s.equals("b")) second.remove(s); }
        System.out.println(second);

        List<String> first = new ArrayList<>(List.of("a", "b", "c"));
        for (String s : first) { if (s.equals("a")) first.remove(s); }
        System.out.println(first);
    }
}
