// OUT: s09-t16-erasure
import java.util.*;
class T16Erasure {
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void main(String[] args) {
        List<String> a = new ArrayList<>();
        List<Integer> b = new ArrayList<>();
        System.out.println(a.getClass() == b.getClass());
        System.out.println(a.getClass().getName());

        List<Integer> nums = new ArrayList<>();
        nums.add(1);
        List raw = nums;
        raw.add("не число");
        System.out.println(nums.size());
        int x = nums.get(1);
    }
}
