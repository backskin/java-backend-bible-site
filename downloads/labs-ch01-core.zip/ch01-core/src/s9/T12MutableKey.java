// OUT: s09-t12-mutable-key
import java.util.*;
class T12MutableKey {
    static class Key {
        int id;
        Key(int id) { this.id = id; }
        @Override public boolean equals(Object o) { return o instanceof Key k && k.id == id; }
        @Override public int hashCode() { return Integer.hashCode(id); }
    }
    public static void main(String[] args) {
        Key k = new Key(1);
        Map<Key, String> map = new HashMap<>();
        map.put(k, "v");
        k.id = 2;

        System.out.println(map.get(k));
        System.out.println(map.get(new Key(1)));
        System.out.println(map.get(new Key(2)));
        System.out.println(map.size());
        map.remove(k);
        System.out.println(map.size());
    }
}
