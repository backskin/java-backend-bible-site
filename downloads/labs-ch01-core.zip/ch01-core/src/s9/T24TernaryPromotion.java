// OUT: s09-t24-ternary-promotion
class T24TernaryPromotion {
    public static void main(String[] args) {
        System.out.println(true ? 1 : 2.0);
        System.out.println(false ? 1 : 'a');
        System.out.println(true ? 'a' : 0);
        System.out.println(true ? 'a' : 65536);
        Object o = true ? Integer.valueOf(1) : Double.valueOf(2.0);
        System.out.println(o);
        System.out.println(o.getClass().getSimpleName());
    }
}
