// OUT: s09-t09-return-value-fixed
import java.util.*;
class T09ReturnValueFixed {
    static int f() {
        int x = 1;
        try { return x; } finally { x = 2; }
    }
    static StringBuilder g() {
        StringBuilder sb = new StringBuilder("a");
        try { return sb; } finally { sb.append("b"); }
    }
    static List<String> h() {
        List<String> list = new ArrayList<>();
        try { return list; } finally { list.add("x"); }
    }
    public static void main(String[] args) {
        System.out.println(f());
        System.out.println(g());
        System.out.println(h());
    }
}
