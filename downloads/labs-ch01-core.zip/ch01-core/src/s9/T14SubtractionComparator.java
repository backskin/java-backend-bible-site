// OUT: s09-t14-subtraction-comparator
import java.util.*;
class T14SubtractionComparator {
    public static void main(String[] args) {
        List<Integer> lucky = new ArrayList<>(List.of(Integer.MAX_VALUE, -1, 0));
        lucky.sort((x, y) -> x - y);
        System.out.println("исходный порядок MAX, -1, 0: " + lucky);
        List<Integer> list = new ArrayList<>(List.of(0, -1, Integer.MAX_VALUE));
        list.sort((x, y) -> x - y);
        System.out.println(list);
        list.sort(Integer::compare);
        System.out.println(list);

        // Большой массив: ищем случай, где TimSort замечает нарушение контракта.
        Random rnd = new Random(42);
        int thrown = 0, wrong = 0;
        for (int run = 0; run < 200; run++) {
            List<Integer> big = new ArrayList<>();
            for (int i = 0; i < 10_000; i++) big.add(rnd.nextInt());
            try {
                big.sort((x, y) -> x - y);
                for (int i = 1; i < big.size(); i++) if (big.get(i - 1) > big.get(i)) { wrong++; break; }
            } catch (IllegalArgumentException e) {
                if (thrown++ == 0) System.out.println("10 000 элементов: " + e);
            }
        }
        System.out.println("из 200 сортировок по 10 000 случайных int: исключение " + thrown + ", неверный порядок без исключения " + wrong);
    }
}
