// MODE: javac
// JAVAC: -Xlint:finally
// OUT: s09-t08-finally-lint
class T08FinallyLint {
    static int g() {
        try {
            return 1;
        } finally {
            return 2;
        }
    }
}
