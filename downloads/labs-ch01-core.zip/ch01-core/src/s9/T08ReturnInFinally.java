// OUT: s09-t08-return-in-finally
class T08ReturnInFinally {
    @SuppressWarnings("finally")
    static int f() {
        try {
            throw new IllegalStateException("важная ошибка");
        } finally {
            return 42;
        }
    }
    @SuppressWarnings("finally")
    static int g() {
        try {
            return 1;
        } finally {
            return 2;
        }
    }
    public static void main(String[] args) {
        System.out.println(f());
        System.out.println(g());
    }
}
