// MODE: javac
// OUT: s09-t26-char-compile
class T26CharCompile {
    void f() {
        char c = 'a';
        c = c + 1;
    }
}
