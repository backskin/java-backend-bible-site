// OUT: s09-t05-overridable-from-ctor
class T05OverridableFromCtor {
    public static void main(String[] args) {
        new Derived().print();
        System.out.println("-- инициализатор не константный:");
        new Derived2().print();
    }
    static int computeLimit() { return 42; }
}
class Base {
    Base() { print(); }
    void print() { System.out.println("Base"); }
}
class Derived extends Base {
    private final int value = 42;
    private String name = "derived";
    @Override void print() { System.out.println("Derived: " + value + " " + name); }
}
class Derived2 extends Base {
    private final int value = T05OverridableFromCtor.computeLimit();
    private String name = "derived";
    @Override void print() { System.out.println("Derived2: " + value + " " + name); }
}
