// OUT: s09-t06-overload-null-fixed
class T06OverloadNullFixed {
    static void f(Object o) { System.out.println("Object"); }
    static void f(String s) { System.out.println("String"); }

    public static void main(String[] args) {
        f(null);
        f((Object) null);
    }
}
