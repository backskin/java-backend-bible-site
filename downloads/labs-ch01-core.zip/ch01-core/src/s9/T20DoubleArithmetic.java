// OUT: s09-t20-double
import java.math.BigDecimal;
class T20DoubleArithmetic {
    public static void main(String[] args) {
        System.out.println(0.1 + 0.2);
        System.out.println(0.1 + 0.2 == 0.3);
        System.out.println(2.00 - 1.10);
        System.out.println(0.1f + 0.2f == 0.3f);
        System.out.println(new BigDecimal(0.1));
        System.out.println(new BigDecimal("0.1"));
        System.out.println(0.1 + 0.2 - 0.3 < 1e-15);
        System.out.println(BigDecimal.valueOf(0.1));
    }
}
