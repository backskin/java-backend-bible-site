// OUT: s09-t15-array-covariance
class T15ArrayCovariance {
    public static void main(String[] args) {
        Object[] objects = new String[2];
        System.out.println(objects.getClass().getSimpleName());
        objects[0] = "ok";
        objects[1] = 42;
    }
}
