// OUT: s09-t07-overload-phases
class T07OverloadPhases {
    static void g(long x)      { System.out.println("long"); }
    static void g(Integer x)   { System.out.println("Integer"); }
    static void g(Object... x) { System.out.println("varargs"); }

    public static void main(String[] args) {
        g(5);
        g(Integer.valueOf(5));
        g(5L);
        g("a", "b");
    }
}
