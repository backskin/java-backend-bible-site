// OUT: s08-serialversionuid
import java.io.*;
class S8Uid {
    static class V1 implements Serializable { long id = 1; }
    static class V1b implements Serializable { long id = 1; void extra() { } }
    public static void main(String[] args) {
        System.out.println("UID без поля, класс V1: " + ObjectStreamClass.lookup(V1.class).getSerialVersionUID());
        System.out.println("UID без поля, тот же класс + один метод: " + ObjectStreamClass.lookup(V1b.class).getSerialVersionUID());
    }
}
