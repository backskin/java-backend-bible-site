// OUT: s08-serialization
import java.io.*;
import java.time.Instant;
import java.util.*;
class S8Serialization {
    static class NonSerialBase { String note; NonSerialBase() { System.out.println("  конструктор несериализуемого предка вызван"); note = "из конструктора"; } }
    static class Order extends NonSerialBase implements Serializable {
        @Serial private static final long serialVersionUID = 1L;
        final long id; transient String token = "секрет"; static int counter = 7;
        Order(long id) { this.id = id; System.out.println("  конструктор Order вызван"); }
    }
    static class Registry implements Serializable {
        @Serial private static final long serialVersionUID = 1L;
        static final Registry INSTANCE = new Registry();
        @Serial private Object readResolve() { return INSTANCE; }
    }
    static class NoResolve implements Serializable { static final NoResolve INSTANCE = new NoResolve(); }
    enum Single { INSTANCE }
    record Period(Instant start, Instant end) implements Serializable {
        Period { if (start.isAfter(end)) throw new IllegalArgumentException("start after end"); }
    }
    static byte[] write(Object o) throws IOException {
        var bos = new ByteArrayOutputStream();
        try (var oos = new ObjectOutputStream(bos)) { oos.writeObject(o); }
        return bos.toByteArray();
    }
    static Object read(byte[] b, ObjectInputFilter filter) throws Exception {
        try (var ois = new ObjectInputStream(new ByteArrayInputStream(b))) { if (filter != null) ois.setObjectInputFilter(filter); return ois.readObject(); }
    }
    public static void main(String[] args) throws Exception {
        System.out.println("создание:");
        byte[] bytes = write(new Order(42));
        System.out.printf("заголовок потока: %02X %02X %02X %02X, размер %d байт%n", bytes[0], bytes[1], bytes[2], bytes[3], bytes.length);
        System.out.println("чтение:");
        Order o = (Order) read(bytes, null);
        System.out.println("id=" + o.id + ", transient token=" + o.token + ", note предка=" + o.note);
        System.out.println("readResolve сохраняет синглтон: " + (read(write(Registry.INSTANCE), null) == Registry.INSTANCE));
        System.out.println("без readResolve второй экземпляр: " + (read(write(NoResolve.INSTANCE), null) != NoResolve.INSTANCE));
        System.out.println("enum: " + (read(write(Single.INSTANCE), null) == Single.INSTANCE));
        Instant now = Instant.parse("2026-11-02T10:00:00Z");
        byte[] good = write(new Period(now, now.plusSeconds(60)));
        Object back = read(good, null);
        System.out.println("record прочитан: " + back);
        System.out.println("record через канонический конструктор: см. s08-record-forged.txt");
        try { read(bytes, ObjectInputFilter.Config.createFilter("!*")); }
        catch (InvalidClassException e) { System.out.println("фильтр !*: " + e.getMessage()); }
        Object okFiltered = read(bytes, ObjectInputFilter.Config.createFilter("S8Serialization$*;java.base/*;!*"));
        System.out.println("фильтр S8Serialization$*;java.base/*;!*: прочитано " + okFiltered.getClass().getSimpleName());
        try { read(write(new ArrayList<>(List.of(new ArrayList<>(List.of(new ArrayList<>(List.of(1))))))), ObjectInputFilter.Config.createFilter("maxdepth=2")); }
        catch (InvalidClassException e) { System.out.println("maxdepth=2: " + e.getMessage()); }
    }
}
