// OUT: s08-record-forged
import java.io.*;
class S8RecordForged {
    record Limit(long amount) implements Serializable {
        Limit { if (amount < 0) throw new IllegalArgumentException("отрицательный лимит " + amount); }
    }
    static class LimitClass implements Serializable {
        final long amount;
        LimitClass(long amount) { if (amount < 0) throw new IllegalArgumentException("отрицательный лимит"); this.amount = amount; }
    }
    static byte[] write(Object o) throws IOException {
        var bos = new ByteArrayOutputStream();
        try (var oos = new ObjectOutputStream(bos)) { oos.writeObject(o); }
        return bos.toByteArray();
    }
    static Object read(byte[] b) throws Exception { try (var ois = new ObjectInputStream(new ByteArrayInputStream(b))) { return ois.readObject(); } }
    static byte[] forge(byte[] b, long from, long to) {
        byte[] r = b.clone();
        for (int i = 0; i + 8 <= r.length; i++) {
            long v = 0; for (int k = 0; k < 8; k++) v = (v << 8) | (r[i + k] & 0xFF);
            if (v == from) { for (int k = 7; k >= 0; k--) { r[i + k] = (byte) to; to >>= 8; } return r; }
        }
        throw new IllegalStateException("не нашли значение");
    }
    public static void main(String[] args) throws Exception {
        byte[] rec = forge(write(new Limit(1000)), 1000, -5);
        try { System.out.println("record: " + read(rec)); } catch (Exception e) { System.out.println("record с подделанным лимитом -5: " + e.getClass().getSimpleName() + " <- " + (e.getCause() != null ? e.getCause().getMessage() : e.getMessage())); }
        byte[] cls = forge(write(new LimitClass(1000)), 1000, -5);
        System.out.println("обычный класс с подделанным лимитом: amount = " + ((LimitClass) read(cls)).amount + " (конструктор не вызывался)");
    }
}
