// OUT: s02-emoji
class S2Emoji {
    public static void main(String[] args) {
        String emoji = "👍";
        System.out.println(emoji.length());
        System.out.println(emoji.codePointCount(0, emoji.length()));
        System.out.println(Integer.toHexString(emoji.charAt(0)));
        System.out.println(emoji.chars().count());
        System.out.println(emoji.codePoints().count());
        String broken = emoji.substring(0, 1);
        System.out.println("substring(0, 1): длина " + broken.length() + ", одиночный суррогат: " + Character.isHighSurrogate(broken.charAt(0)));
        String note = "Оплата 👍";
        System.out.println("offsetByCodePoints: " + note.substring(0, note.offsetByCodePoints(0, 8)).length() + " единиц UTF-16 на 8 кодовых точек");
        String family = "👨‍👩‍👧";
        var it = java.text.BreakIterator.getCharacterInstance();
        it.setText(family);
        int graphemes = 0; while (it.next() != java.text.BreakIterator.DONE) graphemes++;
        System.out.println("семья: length " + family.length() + ", кодовых точек " + family.codePointCount(0, family.length()) + ", графем по BreakIterator " + graphemes);
    }
}
