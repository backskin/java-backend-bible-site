// MODE: javap S2Concat
// OUT: s02-concat-javap
class S2Concat {
    static String f(String a, int b) { return "x=" + a + ", y=" + b; }
    static String loop(int n) {
        String s = "";
        for (int i = 0; i < n; i++) s += i;
        return s;
    }
}
