// OUT: s02-concat-loop
class S2ConcatLoop {
    public static void main(String[] args) {
        int n = 100_000;
        long t0 = System.nanoTime();
        String s = "";
        long copied = 0;
        for (int i = 0; i < n; i++) { copied += s.length(); s += i; }
        long plus = (System.nanoTime() - t0) / 1_000_000;
        t0 = System.nanoTime();
        StringBuilder sb = new StringBuilder(n * 6);
        for (int i = 0; i < n; i++) sb.append(i);
        String s2 = sb.toString();
        long builder = (System.nanoTime() - t0) / 1_000_000;
        System.out.println("длина " + s.length() + " символов, скопировано по дороге " + copied / 1_000_000_000.0 + " млрд символов");
        System.out.println("s += i: " + plus + " мс, StringBuilder: " + builder + " мс, результаты равны: " + s.equals(s2));
        StringBuilder grow = new StringBuilder();
        int cap = grow.capacity(), reallocs = 0;
        StringBuilder caps = new StringBuilder().append(cap);
        while (grow.length() < 1_000_000) { grow.append('x'); if (grow.capacity() != cap) { cap = grow.capacity(); reallocs++; if (reallocs <= 4) caps.append(" -> ").append(cap); } }
        System.out.println("StringBuilder без ёмкости: начальная ёмкость и рост " + caps + " ...; перевыделений до 1 000 000 символов: " + reallocs + ", итоговая ёмкость " + cap);
    }
}
