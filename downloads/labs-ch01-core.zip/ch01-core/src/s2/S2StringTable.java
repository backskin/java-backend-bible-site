// JAVA: -XX:+PrintStringTableStatistics
// OUT: s02-stringtable-statistics
class S2StringTable {
    public static void main(String[] args) {
        for (int i = 0; i < 200_000; i++) ("phone-" + i).intern();
        System.out.println("интернировано 200 000 уникальных строк");
    }
}
