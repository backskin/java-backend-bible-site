// OUT: s02-string-fields
import java.lang.reflect.*;
class S2Fields {
    public static void main(String[] args) {
        for (Field f : String.class.getDeclaredFields())
            if (!Modifier.isStatic(f.getModifiers())) System.out.println(Modifier.toString(f.getModifiers()) + " " + f.getType().getSimpleName() + " " + f.getName());
        System.out.println("String final: " + Modifier.isFinal(String.class.getModifiers()));
        System.out.println("\"Aa\".hashCode() = " + "Aa".hashCode() + ", \"BB\".hashCode() = " + "BB".hashCode());
    }
}
