// OUT: s02-switch-patterns
class S2Switch21 {
    static String describe(Object o) {
        return switch (o) {
            case null       -> "нет значения";
            case Integer i when i > 100 -> "большое число " + i;
            case Integer i  -> "число " + i;
            case String s   -> "строка длины " + s.length();
            default         -> "что-то ещё";
        };
    }
    public static void main(String[] args) {
        for (Object o : new Object[]{null, 500, 7, "ab", 1.5}) System.out.println(describe(o));
    }
}
