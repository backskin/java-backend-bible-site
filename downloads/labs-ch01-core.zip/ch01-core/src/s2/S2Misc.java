// OUT: s02-misc
import java.util.*;
class S2Misc {
    public static void main(String[] args) {
        System.out.println("\"\".isEmpty() = " + "".isEmpty());
        System.out.println("\"  \".isBlank() = " + "  ".isBlank());
        System.out.println("\"  x \".strip() = [" + "  x ".strip() + "]");
        String nbsp = " x ";
        System.out.println("em-пробел: trim() длина " + nbsp.trim().length() + ", strip() длина " + nbsp.strip().length());
        System.out.println("\"a,b,,c,\".split(\",\").length = " + "a,b,,c,".split(",").length);
        System.out.println("\"a,b,,c,\".split(\",\", -1).length = " + "a,b,,c,".split(",", -1).length);
        System.out.println("\"abc\".compareTo(\"abd\") = " + "abc".compareTo("abd") + ", \"a\".compareTo(\"z\") = " + "a".compareTo("z"));
        System.out.println("\"Straße\".toUpperCase() = " + "Straße".toUpperCase(Locale.ROOT) + " (длина " + "Straße".length() + " -> " + "Straße".toUpperCase(Locale.ROOT).length() + ")");
        System.out.println("\"i\".toUpperCase(tr) = " + "i".toUpperCase(Locale.forLanguageTag("tr")));
        String lower = "CONTENT-TYPE".toLowerCase(Locale.forLanguageTag("tr"));
        System.out.println("\"CONTENT-TYPE\".toLowerCase(tr) = " + lower + ", equals(\"content-type\"): " + lower.equals("content-type") + ", equalsIgnoreCase: " + "CONTENT-TYPE".equalsIgnoreCase("content-type"));
        String auth = "AUTHORIZATION".toLowerCase(Locale.forLanguageTag("tr"));
        System.out.println("\"AUTHORIZATION\".toLowerCase(tr) = " + auth + ", equals(\"authorization\"): " + auth.equals("authorization") + ", с Locale.ROOT: " + "AUTHORIZATION".toLowerCase(Locale.ROOT).equals("authorization"));
        System.out.println("\"title\".toUpperCase(tr) = " + "title".toUpperCase(Locale.forLanguageTag("tr")) + ", equals(\"TITLE\"): " + "title".toUpperCase(Locale.forLanguageTag("tr")).equals("TITLE"));
        System.out.println("String.valueOf((Object) null) = " + String.valueOf((Object) null));
        try { String.valueOf((char[]) null); } catch (NullPointerException e) { System.out.println("String.valueOf((char[]) null): NPE"); }
        System.out.println("\"abc\" + null = " + ("abc" + null));
        System.out.println("\"abc\".repeat(3) = " + "abc".repeat(3));
        System.out.println("\"a\\nb\".lines().count() = " + "a\nb".lines().count());
        System.out.println("\"1.2.3\".split(\".\").length = " + "1.2.3".split(".").length + ", split(\"\\\\.\") = " + Arrays.toString("1.2.3".split("\\.")) + ", Pattern.quote: " + "1.2.3".split(java.util.regex.Pattern.quote(".")).length);
    }
}
