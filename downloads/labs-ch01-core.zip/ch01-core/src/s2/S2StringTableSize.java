// JAVA: -XX:+UnlockDiagnosticVMOptions -XX:+PrintFlagsFinal
// OUT: s02-stringtablesize-flag
class S2StringTableSize {
    public static void main(String[] args) { }
}
