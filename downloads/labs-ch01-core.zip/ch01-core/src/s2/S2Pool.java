// OUT: s02-pool
class S2Pool {
    public static void main(String[] args) {
        String a = "hello";
        String b = "hello";
        String c = new String("hello");
        String d = "hel" + "lo";
        final String hel = "hel";
        String e = hel + "lo";
        String f1 = "hel";
        String f = f1 + "lo";
        String g = c.intern();
        System.out.println(a == b);
        System.out.println(a == c);
        System.out.println(a == d);
        System.out.println(a == e);
        System.out.println(a == f);
        System.out.println(a == g);
        System.out.println(a.equals(c));
        String greeting = "Hello";
        System.out.println("greeting == \"Hello\": " + (greeting == "Hello") + ", (greeting + \"!\") == \"Hello!\": " + ((greeting + "!") == "Hello!"));
    }
}
