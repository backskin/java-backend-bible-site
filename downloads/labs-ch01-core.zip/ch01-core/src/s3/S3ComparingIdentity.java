// MODE: javac
// OUT: s03-comparing-identity-javac
import java.util.*;
import java.util.function.Function;
class S3ComparingIdentity {
    Comparator<String> c = Comparator.comparing(Function.identity());
}
class S3ComparingIdentityVar {
    void f(java.util.List<String> list) {
        var c = Comparator.comparing(Function.identity());
        list.sort(Comparator.comparing(Function.identity()));
    }
}
class S3ComparingIdentityReversed {
    void f(java.util.List<String> list) {
        list.sort(Comparator.comparing(Function.identity()).reversed());
        list.sort(Comparator.comparing(s -> s.length()).reversed());
    }
}
