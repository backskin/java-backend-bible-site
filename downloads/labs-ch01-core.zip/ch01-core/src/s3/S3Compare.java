// OUT: s03-comparators
import java.math.BigDecimal;
import java.util.*;
class S3Compare {
    record Employee(String department, String lastName, long salary, long id) {}
    public static void main(String[] args) {
        var a = new BigDecimal("1.0"); var b = new BigDecimal("1.00");
        System.out.println(a.equals(b) + " " + a.compareTo(b) + " " + new HashSet<>(List.of(a, b)).size() + " " + new TreeSet<>(List.of(a, b)).size());
        System.out.println("после setScale(2): " + new HashSet<>(List.of(a.setScale(2), b.setScale(2))).size());
        List<Employee> list = new ArrayList<>(List.of(
            new Employee("IT", "Ivanov", 100, 1), new Employee("IT", "Petrov", 200, 2),
            new Employee("HR", "Sidorov", 150, 3)));
        Comparator<Employee> byDeptThenSalaryDesc = Comparator.comparing(Employee::department)
            .thenComparing(Employee::salary, Comparator.reverseOrder());
        list.sort(byDeptThenSalaryDesc);
        System.out.println("отдел ↑, зарплата ↓: " + list.stream().map(Employee::lastName).toList());
        list.sort(Comparator.comparing(Employee::department).thenComparingLong(Employee::salary).reversed());
        System.out.println("(отдел, зарплата).reversed(): " + list.stream().map(Employee::lastName).toList());
        List<Integer> immutable = List.of(3, 1, 2);
        try { Collections.sort(immutable); } catch (UnsupportedOperationException e) { System.out.println("Collections.sort(List.of(...)): UnsupportedOperationException"); }
        List<Integer> view = Arrays.asList(3, 1, 2); Collections.sort(view);
        System.out.println("Collections.sort(Arrays.asList(...)): " + view);
        List<String> withNull = new ArrayList<>(Arrays.asList("b", null, "a"));
        withNull.sort(Comparator.nullsFirst(Comparator.naturalOrder()));
        System.out.println("nullsFirst: " + withNull);
    }
}
