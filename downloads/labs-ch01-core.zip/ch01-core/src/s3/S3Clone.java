// OUT: s03-clone
class S3Clone {
    static class PaymentBatch implements Cloneable {
        long[] amounts = {100, 200};
        @Override public PaymentBatch clone() {
            try { return (PaymentBatch) super.clone(); } catch (CloneNotSupportedException e) { throw new AssertionError(e); }
        }
    }
    static class NotCloneable { Object tryClone() throws CloneNotSupportedException { return super.clone(); } }
    public static void main(String[] args) throws Exception {
        PaymentBatch a = new PaymentBatch();
        PaymentBatch b = a.clone();
        b.amounts[0] = 999;
        System.out.println("поверхностная копия: оригинал видит изменение копии: " + (a.amounts[0] == 999));
        try { new NotCloneable().tryClone(); } catch (CloneNotSupportedException e) { System.out.println("без Cloneable: " + e); }
        int[] arr = {1, 2, 3}; int[] copy = arr.clone();
        System.out.println("массив: clone() даёт " + copy.getClass().getSimpleName() + ", это другой объект: " + (copy != arr));
    }
}
