// OUT: s03-enum-hash
import java.util.*;
class S3EnumHash {
    enum Status { NEW, PAID, FAILED, REFUNDED, CANCELLED }
    public static void main(String[] args) {
        Map<Status, Integer> m = new HashMap<>();
        for (Status s : Status.values()) m.put(s, s.ordinal());
        System.out.println("HashMap: " + m.keySet() + ", EnumMap: " + new EnumMap<>(m).keySet());
        System.out.println("Status.NEW.hashCode() == identityHashCode: " + (Status.NEW.hashCode() == System.identityHashCode(Status.NEW)));
    }
}
