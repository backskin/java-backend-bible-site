// OUT: s03-hashcode
import java.util.*;
public class S3Hash {
    static class ClientId {
        final long id;
        ClientId(long id) { this.id = id; }
        @Override public boolean equals(Object o) { return o instanceof ClientId c && c.id == id; }
    }
    static class MutableClientId {
        long id;
        MutableClientId(long id) { this.id = id; }
        @Override public boolean equals(Object o) { return o instanceof MutableClientId c && c.id == id; }
        @Override public int hashCode() { return Long.hashCode(id); }
        @Override public String toString() { return "ClientId(" + id + ")"; }
    }
    static class Payment {
        Long id;
        final String name;
        Payment(String name) { this.name = name; }
        @Override public boolean equals(Object o) { return o instanceof Payment p && Objects.equals(id, p.id); }
        @Override public int hashCode() { return Objects.hashCode(id); }
    }
    static class StablePayment {
        Long id;
        @Override public boolean equals(Object o) { return this == o || o instanceof StablePayment p && id != null && id.equals(p.id); }
        @Override public int hashCode() { return 31; }
    }
    public static void main(String[] args) {
        System.out.println("--- 1. hashCode не переопределён");
        Map<ClientId, String> limits1 = new HashMap<>();
        limits1.put(new ClientId(42), "100000");
        System.out.println("get:         " + limits1.get(new ClientId(42)));
        System.out.println("containsKey: " + limits1.containsKey(new ClientId(42)));
        System.out.println("size:        " + limits1.size());
        Set<ClientId> seen = new HashSet<>();
        seen.add(new ClientId(42));
        seen.add(new ClientId(42));
        System.out.println("HashSet.size: " + seen.size());
        System.out.println("--- 2. изменяемый ключ");
        var key = new MutableClientId(42);
        Map<MutableClientId, String> limits2 = new HashMap<>();
        limits2.put(key, "100000");
        key.id = 43;
        System.out.println("get(изменённый ключ):    " + limits2.get(key));
        System.out.println("get(новый ClientId(42)): " + limits2.get(new MutableClientId(42)));
        System.out.println("remove(ключ) / size:     " + limits2.remove(key) + " / " + limits2.size());
        System.out.println("содержимое карты:        " + limits2);
        key.id = 42;
        System.out.println("после возврата поля:     " + limits2.get(key));
        System.out.println("--- 3. сущность: id присваивается после добавления в HashSet");
        Set<Payment> batch = new HashSet<>();
        Payment p = new Payment("A");
        batch.add(p);
        p.id = 100L;
        System.out.println("contains после присвоения id: " + batch.contains(p));
        Set<StablePayment> batch2 = new HashSet<>();
        StablePayment sp = new StablePayment();
        batch2.add(sp);
        sp.id = 100L;
        System.out.println("константный hashCode, contains после присвоения id: " + batch2.contains(sp));
        System.out.println("--- 4. хеш идентичности и сборщик мусора");
        Object k = new Object();
        int before = System.identityHashCode(k);
        List<byte[]> garbage = new ArrayList<>();
        for (int round = 0; round < 5; round++) {
            for (int i = 0; i < 2000; i++) garbage.add(new byte[100_000]);
            garbage.clear();
            System.gc();
        }
        int after = System.identityHashCode(k);
        System.out.println("совпали до и после пяти System.gc(): " + (before == after) + ", хеш неотрицателен: " + (after >= 0));
    }
}
