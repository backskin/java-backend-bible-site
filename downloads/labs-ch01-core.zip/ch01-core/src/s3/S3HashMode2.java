// JAVA: -XX:+UnlockExperimentalVMOptions -XX:hashCode=2
// OUT: s03-hashcode-mode2
class S3HashMode2 {
    public static void main(String[] args) {
        Object a = new Object(), b = new Object();
        System.out.println("-XX:hashCode=2: " + System.identityHashCode(a) + " " + System.identityHashCode(b));
    }
}
