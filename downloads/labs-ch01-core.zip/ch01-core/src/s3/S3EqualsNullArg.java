// OUT: s03-equals-null-arg
// Когда стандартная коллекция передаёт null в ваш equals: список, в котором есть null-элемент.
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class S3EqualsNullArg {
    // equals, который забыли защитить от null: обращается к полю аргумента без проверки
    static final class AccountNo {
        final String value;
        AccountNo(String value) { this.value = value; }
        @Override public boolean equals(Object o) {
            return value.equals(((AccountNo) o).value);   // NPE на null, ClassCastException на чужом типе
        }
        @Override public int hashCode() { return value.hashCode(); }
    }

    public static void main(String[] args) {
        List<AccountNo> list = new ArrayList<>();
        list.add(null);                       // например, строка реестра без номера счёта
        list.add(new AccountNo("40817810"));
        try {
            System.out.println("contains: " + list.contains(new AccountNo("40817810")));
        } catch (RuntimeException e) {
            System.out.println("contains бросил " + e.getClass().getSimpleName());
        }
        List<Object> mixed = new ArrayList<>(List.of("40817810", new AccountNo("40817810")));
        try {
            System.out.println("indexOf в смешанном списке: " + mixed.indexOf(new AccountNo("40817810")));
        } catch (RuntimeException e) {
            System.out.println("indexOf бросил " + e.getClass().getSimpleName());
        }
        System.out.println("list.contains(null) без вызова equals: " + list.contains(null));
        java.util.Map<AccountNo, String> owners = new java.util.HashMap<>();
        owners.put(new AccountNo("40817810"), "dev.team");
        System.out.println("map.get(null) без вызова equals: " + owners.get(null));
        System.out.println("Objects.equals(null, null): " + Objects.equals(null, null));
    }
}
