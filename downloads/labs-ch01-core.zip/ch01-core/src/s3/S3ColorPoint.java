// OUT: s03-colorpoint
import java.util.*;
class S3ColorPoint {
    static class Point {
        final int x, y;
        Point(int x, int y) { this.x = x; this.y = y; }
        @Override public boolean equals(Object o) { return o instanceof Point p && p.x == x && p.y == y; }
        @Override public int hashCode() { return 31 * x + y; }
    }
    static class ColorPoint extends Point {
        final String color;
        ColorPoint(int x, int y, String color) { super(x, y); this.color = color; }
        @Override public boolean equals(Object o) {
            if (!(o instanceof Point)) return false;
            if (!(o instanceof ColorPoint cp)) return super.equals(o);
            return super.equals(o) && cp.color.equals(color);
        }
    }
    static class GcPoint {
        final int x, y;
        GcPoint(int x, int y) { this.x = x; this.y = y; }
        @Override public boolean equals(Object o) {
            if (o == null || o.getClass() != getClass()) return false;
            GcPoint p = (GcPoint) o; return p.x == x && p.y == y;
        }
        @Override public int hashCode() { return 31 * x + y; }
    }
    public static void main(String[] args) {
        Point p = new Point(1, 2);
        ColorPoint red = new ColorPoint(1, 2, "red"), blue = new ColorPoint(1, 2, "blue");
        System.out.println("red.equals(p) = " + red.equals(p) + ", p.equals(blue) = " + p.equals(blue) + ", red.equals(blue) = " + red.equals(blue));
        GcPoint base = new GcPoint(1, 2);
        GcPoint sub = new GcPoint(1, 2) { };   // как прокси-подкласс
        System.out.println("getClass(): base.equals(подкласс) = " + base.equals(sub) + ", Set.contains = " + new HashSet<>(List.of(base)).contains(sub));
        System.out.println("HashSet и TreeSet с одними элементами равны: " + new HashSet<>(List.of(1, 2)).equals(new TreeSet<>(List.of(2, 1))));
    }
}
