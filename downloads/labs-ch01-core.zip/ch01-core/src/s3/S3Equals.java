// OUT: s03-equals
import java.util.*;
public class S3Equals {
    static class Point {
        final double x;
        Point(double x) { this.x = x; }
        @Override public boolean equals(Object o) { return o instanceof Point p && this.x == p.x; }
        @Override public int hashCode() { return Double.hashCode(x); }
    }
    record RecordPoint(double x) {}
    static class CaseInsensitiveString {
        private final String s;
        CaseInsensitiveString(String s) { this.s = Objects.requireNonNull(s); }
        @Override public boolean equals(Object o) {
            if (o instanceof CaseInsensitiveString cis) return s.equalsIgnoreCase(cis.s);
            if (o instanceof String str) return s.equalsIgnoreCase(str);
            return false;
        }
        @Override public int hashCode() { return s.toLowerCase().hashCode(); }
    }
    record Batch(String id, int[] amounts) {}
    public static void main(String[] args) {
        System.out.println("--- 1. NaN и рефлексивность");
        Point nan = new Point(Double.NaN);
        System.out.println("Point(NaN).equals(тот же объект):             " + nan.equals(nan));
        System.out.println("record(NaN) равен record(NaN):                 " + new RecordPoint(Double.NaN).equals(new RecordPoint(Double.NaN)));
        System.out.println("record(0.0) равен record(-0.0):                " + new RecordPoint(0.0).equals(new RecordPoint(-0.0)));
        System.out.println("0.0 == -0.0:                                   " + (0.0 == -0.0));
        System.out.println("Double.valueOf(0.0).equals(-0.0):              " + Double.valueOf(0.0).equals(-0.0));
        System.out.println("--- 2. симметричность");
        var cis = new CaseInsensitiveString("Polish");
        String s = "polish";
        System.out.println("cis.equals(s): " + cis.equals(s));
        System.out.println("s.equals(cis): " + s.equals(cis));
        List<Object> withCis = new ArrayList<>(List.of(cis));
        List<Object> withString = new ArrayList<>(List.of(s));
        System.out.println("список с cis .contains(\"polish\"): " + withCis.contains(s));
        System.out.println("список со строкой .contains(cis): " + withString.contains(cis));
        System.out.println("--- 3. сравнение с null и пустые ссылки");
        System.out.println("cis.equals(null):          " + cis.equals(null));
        System.out.println("Objects.equals(null, null): " + Objects.equals(null, null));
        System.out.println("--- 4. record с массивом сравнивает массив по ссылке");
        Batch a = new Batch("b1", new int[]{1, 2, 3});
        Batch b = new Batch("b1", new int[]{1, 2, 3});
        System.out.println("одинаковое содержимое, a.equals(b): " + a.equals(b));
        int[] shared = {1, 2, 3};
        System.out.println("тот же массив,        equals:       " + new Batch("b1", shared).equals(new Batch("b1", shared)));
    }
}
