// JAVA: -XX:AutoBoxCacheMax=20000
// OUT: s01-cache-autoboxcachemax-20000
class S1CacheMax20000 {
    public static void main(String[] a) {
        Integer i128a = 128, i128b = 128, big1 = 1000, big2 = 1000, n1 = 100_000, n2 = 100_000;
        Long ll1 = 1000L, ll2 = 1000L;
        System.out.println("-XX:AutoBoxCacheMax=20000: Integer 128 " + (i128a == i128b) + ", 1000 " + (big1 == big2) + ", 100000 " + (n1 == n2) + "; Long 1000 " + (ll1 == ll2));
        System.out.println("java.lang.Integer.IntegerCache.high = " + System.getProperty("java.lang.Integer.IntegerCache.high"));
    }
}
