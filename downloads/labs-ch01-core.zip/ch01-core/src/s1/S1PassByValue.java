// OUT: s01-pass-by-value
class S1PassByValue {
    static class Payment { String status = "NEW"; }
    static void mutate(Payment p)   { p.status = "SENT"; }
    static void reassign(Payment p) { p = new Payment(); p.status = "REJECTED"; }
    static void swap(Integer x, Integer y) { Integer t = x; x = y; y = t; }
    public static void main(String[] args) {
        Payment payment = new Payment();
        mutate(payment);    System.out.println(payment.status);
        reassign(payment);  System.out.println(payment.status);
        Integer a = 1, b = 2; swap(a, b);
        System.out.println("после swap: a=" + a + ", b=" + b);
    }
}
