// OUT: s01-reflect-boolean
import java.lang.reflect.Method;
public class S1ReflectBoolean {
    public static boolean test() { return true; }
    public static void main(String[] args) throws Exception {
        Method m = S1ReflectBoolean.class.getMethod("test");
        int same = 0, diff = 0;
        for (int k = 0; k < 100; k++) { if (m.invoke(null) == Boolean.TRUE) same++; else diff++; }
        System.out.println(Runtime.version().feature() + ": invoke() == Boolean.TRUE в " + same + " из 100 вызовов");
    }
}
