// OUT: s01-overflow
import java.util.concurrent.TimeUnit;
class S1Overflow {
    public static void main(String[] args) {
        System.out.println(Integer.MAX_VALUE + 1);
        System.out.println(Math.abs(Integer.MIN_VALUE));
        System.out.println(-Integer.MIN_VALUE);
        System.out.println((int) 3_000_000_000L);
        System.out.println(Integer.MIN_VALUE / -1);
        int low = 1_500_000_000, high = 2_000_000_000;
        System.out.println("(low + high) / 2 = " + (low + high) / 2 + ", low + (high - low) / 2 = " + (low + (high - low) / 2) + ", (low + high) >>> 1 = " + ((low + high) >>> 1));
        try { Math.addExact(Integer.MAX_VALUE, 1); } catch (ArithmeticException e) { System.out.println("addExact: " + e.getMessage()); }
        try { Math.toIntExact(3_000_000_000L); } catch (ArithmeticException e) { System.out.println("toIntExact: " + e.getMessage()); }
        System.out.println("floorDiv(-7, 2) = " + Math.floorDiv(-7, 2) + ", -7 / 2 = " + (-7 / 2) + ", floorMod(-7, 3) = " + Math.floorMod(-7, 3) + ", -7 % 3 = " + (-7 % 3));
        System.out.println("Math.abs(MIN_VALUE % 10) = " + Math.abs(Integer.MIN_VALUE % 10) + ", Math.abs(MIN_VALUE) % 10 = " + Math.abs(Integer.MIN_VALUE) % 10 + ", floorMod(MIN_VALUE, 10) = " + Math.floorMod(Integer.MIN_VALUE, 10));
        System.out.println("Long.MAX_VALUE / 1e9 / 86400 / 365.25 = " + (Long.MAX_VALUE / 1e9 / 86400 / 365.25) + " лет в наносекундах");
        System.out.println("Long.MAX_VALUE / 1_000_000 / 86_400_000 = " + (Long.MAX_VALUE / 1_000_000 / 86_400_000L) + " дней");
        System.out.println("TimeUnit.MILLISECONDS.toNanos(Long.MAX_VALUE) = " + TimeUnit.MILLISECONDS.toNanos(Long.MAX_VALUE));
        System.out.println("Long.MAX_VALUE * 1_000_000 = " + (Long.MAX_VALUE * 1_000_000));
    }
}
