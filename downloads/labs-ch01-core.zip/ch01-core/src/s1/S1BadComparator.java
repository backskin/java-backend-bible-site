// OUT: s01-bloch-bad-comparator
import java.util.Comparator;
class S1BadComparator {
    static Integer i;
    @SuppressWarnings("removal")
    public static void main(String[] args) {
        Comparator<Integer> naturalOrder = (a, b) -> (a < b) ? -1 : (a == b ? 0 : 1);
        System.out.println("compare(42, 42) через упаковку:   " + naturalOrder.compare(42, 42));
        System.out.println("compare(1000, 1000) через упаковку: " + naturalOrder.compare(1000, 1000));
        try { if (i == 42) System.out.println("Невероятно"); }
        catch (NullPointerException e) { System.out.println("static Integer i; i == 42 -> " + e.getClass().getSimpleName()); }
    }
}
