// OUT: s01-null
import java.util.*;
class S1Null {
    @SuppressWarnings("static-access")
    public static void main(String[] args) {
        Object o = null;
        System.out.println("null instanceof String: " + (o instanceof String));
        String s = (String) null;
        System.out.println("(String) null: " + s);
        System.out.println("((Thread) null).currentThread(): " + ((Thread) null).currentThread().getName());
        System.out.println("\"x\" + null: " + ("x" + null));
        try { synchronized (o) { } } catch (NullPointerException e) { System.out.println("synchronized(null): " + e.getClass().getSimpleName()); }
        try { throw null; } catch (NullPointerException e) { System.out.println("throw null: " + e.getClass().getSimpleName()); }
        try { new TreeMap<String, Integer>().put(null, 1); } catch (NullPointerException e) { System.out.println("TreeMap.put(null): NPE"); }
        try { List.of((Object) null); } catch (NullPointerException e) { System.out.println("List.of(null): NPE"); }
        try { int[] arr = null; System.out.println(arr.length); } catch (NullPointerException e) { System.out.println(e.getMessage()); }
    }
}
