// JAVA: -Djava.lang.Integer.IntegerCache.high=1000
// OUT: s01-cache-property-1000
class S1CacheProp {
    public static void main(String[] a) {
        Integer x = 1000, y = 1000, p = 1001, q = 1001;
        System.out.println("-Djava.lang.Integer.IntegerCache.high=1000: Integer 1000 " + (x == y) + ", 1001 " + (p == q));
    }
}
