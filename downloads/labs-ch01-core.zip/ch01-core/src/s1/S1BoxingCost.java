// OUT: s01-boxing-cost
class S1BoxingCost {
    public static void main(String[] args) {
        for (int round = 0; round < 3; round++) {
            long t0 = System.nanoTime();
            Long sum = 0L;                       // ошибка: обёртка вместо long
            for (long i = 0; i < 50_000_000L; i++) sum += i;
            long boxed = (System.nanoTime() - t0) / 1_000_000;
            t0 = System.nanoTime();
            long psum = 0L;
            for (long i = 0; i < 50_000_000L; i++) psum += i;
            long prim = (System.nanoTime() - t0) / 1_000_000;
            System.out.println("раунд " + round + ": Long " + boxed + " мс, long " + prim + " мс, сумма совпала: " + (sum == psum));
        }
        System.out.println("(время зависит от машины; см. s01-boxing-cost-gc.txt — сколько выделено)");
    }
}
