// JAVA: -XX:AutoBoxCacheMax=20
// OUT: s01-cache-autoboxcachemax-20
class S1CacheMax20 {
    public static void main(String[] a) {
        Integer x = 100, y = 100, p = 127, q = 127, r = 128, s = 128;
        System.out.println("-XX:AutoBoxCacheMax=20: Integer 100 " + (x == y) + ", 127 " + (p == q) + ", 128 " + (r == s));
    }
}
