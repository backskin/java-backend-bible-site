// OUT: s01-omit-stacktrace-fastthrow
class S1FastThrow {
    static String[] data = new String[1];
    static int len(int i) { return data[i % 1].length(); }
    public static void main(String[] args) {
        int first = -1;
        for (int i = 0; i < 200_000; i++) {
            try { len(i); }
            catch (NullPointerException e) {
                if (e.getStackTrace().length == 0 && first < 0) {
                    first = i;
                    System.out.println("бросок №" + i + ": стек " + e.getStackTrace().length + " кадров, сообщение: " + e.getMessage());
                }
            }
        }
        System.out.println(first < 0 ? "стек не пропал за 200 000 бросков" : "с этого броска HotSpot бросает готовый экземпляр без стека");
    }
}
