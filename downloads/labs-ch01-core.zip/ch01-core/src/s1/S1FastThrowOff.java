// JAVA: -XX:-OmitStackTraceInFastThrow
// OUT: s01-omit-stacktrace-off
class S1FastThrowOff {
    static String[] data = new String[1];
    static int len(int i) { return data[i % 1].length(); }
    public static void main(String[] args) {
        int empty = 0;
        for (int i = 0; i < 200_000; i++) {
            try { len(i); } catch (NullPointerException e) { if (e.getStackTrace().length == 0) empty++; }
        }
        System.out.println("-XX:-OmitStackTraceInFastThrow: исключений без стека из 200 000: " + empty);
    }
}
