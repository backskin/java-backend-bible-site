// OUT: s01-shifts
// JAVA: --add-opens java.base/java.util=ALL-UNNAMED
import java.lang.reflect.Method;
class S1Shifts {
    public static void main(String[] args) throws Exception {
        int x = -8;
        System.out.println(x >> 1);
        System.out.println(x >>> 1);
        System.out.println(x << 1);
        System.out.println(8 >>> 1);
        System.out.println(1 << 32);
        System.out.println(1 << 33);
        System.out.println(1L << 32);
        byte b = (byte) 0x80;
        System.out.println(b >> 1);
        System.out.println((b & 0xFF) >> 1);
        System.out.println(Byte.toUnsignedInt(b));
        Method m = java.util.HashMap.class.getDeclaredMethod("tableSizeFor", int.class);
        m.setAccessible(true);
        System.out.println("HashMap.tableSizeFor(100) = " + m.invoke(null, 100) + ", -1 >>> numberOfLeadingZeros(99) = " + (-1 >>> Integer.numberOfLeadingZeros(99)));
        System.out.println("(char) -1 = " + (int) (char) -1);
    }
}
