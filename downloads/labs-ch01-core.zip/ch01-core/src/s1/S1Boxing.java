// MODE: javap S1Boxing
// OUT: s01-boxing-javap
import java.util.*;
class S1Boxing {
    public static void main(String[] args) {
        Integer a = 42;          // Integer.valueOf(42)
        int b = a;               // a.intValue()
        Integer c = a + 1;       // Integer.valueOf(a.intValue() + 1)
        List<Integer> list = new ArrayList<>();
        list.add(7);             // list.add(Integer.valueOf(7))
        int d = list.get(0);     // list.get(0).intValue()
    }
}
