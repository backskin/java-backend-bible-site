// MODE: javap S1CounterBoxing
// OUT: s01-counter-boxing-javap
// Сколько упаковок и распаковок в инкременте счётчика Map<String, Integer>:
// put(k, get(k) + 1) против merge(k, 1, Integer::sum).
import java.util.HashMap;
import java.util.Map;

public class S1CounterBoxing {
    static void viaPut(Map<String, Integer> counters, String k) {
        counters.put(k, counters.get(k) + 1);
    }

    static void viaMerge(Map<String, Integer> counters, String k) {
        counters.merge(k, 1, Integer::sum);
    }

    public static void main(String[] args) {
        Map<String, Integer> m = new HashMap<>();
        viaMerge(m, "card");
        viaPut(m, "card");
        System.out.println(m);
    }
}
