// OUT: s01-boxing-alloc
import java.lang.management.ManagementFactory;
class S1BoxingAlloc {
    public static void main(String[] args) {
        var bean = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
        long tid = Thread.currentThread().threadId();
        long before = bean.getThreadAllocatedBytes(tid);
        Long sum = 0L;
        for (long i = 0; i < 50_000_000L; i++) sum += i;
        long boxed = bean.getThreadAllocatedBytes(tid) - before;
        before = bean.getThreadAllocatedBytes(tid);
        long psum = 0L;
        for (long i = 0; i < 50_000_000L; i++) psum += i;
        long prim = bean.getThreadAllocatedBytes(tid) - before;
        System.out.println("выделено с Long: " + boxed / 1_000_000 + " МБ, с long: " + prim / 1_000_000 + " МБ (" + sum + ")");
    }
}
