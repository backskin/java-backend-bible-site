// OUT: s01-double
import java.math.BigDecimal;
class S1Double {
    static boolean approxEquals(double a, double b, double relEps) {
        if (a == b) return true;
        double diff = Math.abs(a - b);
        return diff <= relEps * Math.max(Math.abs(a), Math.abs(b));
    }
    public static void main(String[] args) {
        System.out.println(0.1 + 0.2);
        System.out.println(0.1 + 0.2 == 0.3);
        System.out.println(1.03 - 0.42);
        System.out.println(2.0 - 1.1);
        System.out.println(1.00 - 9 * 0.10);
        double funds = 1.00; int itemsBought = 0;
        for (double price = 0.10; funds >= price; price += 0.10) { funds -= price; itemsBought++; }
        System.out.println("конфеты по 10, 20, 30... центов на доллар: куплено " + itemsBought + ", сдача " + funds);
        System.out.println(new BigDecimal(0.1));
        System.out.println("approxEquals(0.1+0.2, 0.3, 1e-12): " + approxEquals(0.1 + 0.2, 0.3, 1e-12));
        double a = Double.NaN, b = Double.NaN;
        System.out.println("NaN == NaN: " + (a == b) + ", equals: " + Double.valueOf(a).equals(b) + ", NaN < 1: " + (a < 1) + ", NaN > 1: " + (a > 1) + ", isNaN: " + Double.isNaN(a));
        double[] arr = {Double.NaN};
        System.out.println("arr[0] == Double.NaN: " + (arr[0] == Double.NaN));
        System.out.println(0.0 == -0.0);
        System.out.println(Double.valueOf(0.0).equals(-0.0));
        System.out.println(Double.compare(0.0, -0.0));
        System.out.println(1.0 / 0.0);
        System.out.println(1.0 / -0.0);
        System.out.println(Math.min(0.0, -0.0));
        System.out.println("-1 * 0.0 = " + (-1 * 0.0) + ", -0.5 + 0.5 = " + (-0.5 + 0.5) + ", Math.round(-0.4) = " + Math.round(-0.4));
        System.out.println("1.0 / 0 = " + (1.0 / 0) + ", 0.0 / 0.0 = " + (0.0 / 0.0) + ", -1.0 / 0.0 = " + (-1.0 / 0.0) + ", 1.0 % 0.0 = " + (1.0 % 0.0));
        try { System.out.println(1 / zero()); } catch (ArithmeticException e) { System.out.println("1 / 0: " + e.getMessage()); }
        try { System.out.println(1 % zero()); } catch (ArithmeticException e) { System.out.println("1 % 0: " + e.getMessage()); }
    }
    static int zero() { return 0; }
}
