// OUT: s01-cache
class S1Cache {
    static Integer id(int x) { return x; }
    public static void main(String[] a) {
        Integer i127a = 127, i127b = 127, i128a = 128, i128b = 128;
        System.out.println("Integer 127: " + (i127a == i127b) + ", 128: " + (i128a == i128b));
        Integer m128a = -128, m128b = -128, m129a = -129, m129b = -129;
        System.out.println("Integer -128: " + (m128a == m128b) + ", -129: " + (m129a == m129b));
        Long l127a = 127L, l127b = 127L, l128a = 128L, l128b = 128L;
        System.out.println("Long 127: " + (l127a == l127b) + ", 128: " + (l128a == l128b));
        Short s127a = 127, s127b = 127, s128a = 128, s128b = 128;
        System.out.println("Short 127: " + (s127a == s127b) + ", 128: " + (s128a == s128b));
        Character c127a = 127, c127b = 127, c128a = 128, c128b = 128;
        System.out.println("Character 127: " + (c127a == c127b) + ", 128: " + (c128a == c128b));
        boolean allByte = true;
        for (int v = -128; v <= 127; v++) { Byte x = (byte) v, y = (byte) v; allByte &= (x == y); }
        System.out.println("Byte, весь диапазон кэшируется: " + allByte);
        Boolean t1 = true, t2 = true;
        System.out.println("Boolean: " + (t1 == t2));
        Integer v1 = Integer.valueOf("100"), v2 = Integer.valueOf("100");
        System.out.println("Integer.valueOf(\"100\"): " + (v1 == v2));
        Integer big1 = 1000, big2 = 1000;
        System.out.println("Integer 1000: " + (big1 == big2));
        Integer n1 = 100_000, n2 = 100_000;
        System.out.println("Integer 100000: " + (n1 == n2));
        Long ll1 = 1000L, ll2 = 1000L;
        System.out.println("Long 1000: " + (ll1 == ll2));
        System.out.println("id(127) == id(127): " + (id(127) == id(127)) + ", id(128) == id(128): " + (id(128) == id(128)));
        System.out.println("Double.valueOf(0.0) == Double.valueOf(0.0): " + (Double.valueOf(0.0) == Double.valueOf(0.0)));
        int first = -1;
        for (int i = 100; i <= 200_000; i++) if (Integer.valueOf(i) != Integer.valueOf(i)) { first = i; break; }
        System.out.println("первое значение вне кэша Integer: " + first);
        long firstL = -1;
        for (long i = 100; i <= 200_000; i++) if (Long.valueOf(i) != Long.valueOf(i)) { firstL = i; break; }
        System.out.println("первое значение вне кэша Long: " + firstL);
    }
}
