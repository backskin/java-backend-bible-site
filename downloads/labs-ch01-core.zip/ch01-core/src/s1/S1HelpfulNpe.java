// OUT: s01-helpful-npe
class S1HelpfulNpe {
    record Payer(String name) {}
    record Payment(Payer payer) { Payer getPayer() { return payer; } }
    static Payment findById(long id) { return null; }
    public static void main(String[] args) {
        try { findById(1).getPayer(); } catch (NullPointerException e) { System.out.println(e.getMessage()); }
        Payment local = null;
        try { local.getPayer(); } catch (NullPointerException e) { System.out.println("без -g: " + e.getMessage()); }
    }
}
