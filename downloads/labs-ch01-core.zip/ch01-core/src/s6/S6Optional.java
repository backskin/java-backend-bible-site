// OUT: s06-optional
import java.util.*;
class S6Optional {
    public static void main(String[] args) {
        String name = Optional.ofNullable("  dev.team ").map(String::strip).filter(s -> !s.isEmpty()).orElse("anonymous");
        String empty = Optional.ofNullable("   ").map(String::strip).filter(s -> !s.isEmpty()).orElse("anonymous");
        System.out.println(name + " / " + empty);
        try { Optional.empty().orElseThrow(); } catch (NoSuchElementException e) { System.out.println("orElseThrow(): " + e.getMessage()); }
    }
}
