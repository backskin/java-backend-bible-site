// OUT: s06-executors
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
class S6Executors {
    public static void main(String[] args) throws Exception {
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> System.out.println("UncaughtExceptionHandler: " + e.getMessage()));
        ExecutorService pool = Executors.newSingleThreadExecutor();
        Future<?> f = pool.submit(() -> { throw new IllegalStateException("из submit"); });
        pool.execute(() -> { throw new IllegalStateException("из execute"); });
        Thread.sleep(300);
        try { f.get(); } catch (ExecutionException e) { System.out.println("submit: только через future.get(): " + e.getCause().getMessage()); }
        pool.shutdown();
        ScheduledExecutorService sched = Executors.newSingleThreadScheduledExecutor();
        AtomicInteger runs = new AtomicInteger();
        ScheduledFuture<?> sf = sched.scheduleAtFixedRate(() -> { if (runs.incrementAndGet() == 2) throw new IllegalStateException("сбой"); }, 0, 50, TimeUnit.MILLISECONDS);
        Thread.sleep(500);
        System.out.println("scheduleAtFixedRate: запусков за 500 мс при периоде 50 мс: " + runs.get() + ", задача завершена: " + sf.isDone());
        sched.shutdown();
        CompletableFuture<String> cf = CompletableFuture.supplyAsync(() -> { throw new IllegalStateException("в CompletableFuture"); });
        try { cf.join(); } catch (CompletionException e) { System.out.println("join: " + e.getClass().getSimpleName() + " <- " + e.getCause().getMessage()); }
        try { cf.get(); } catch (ExecutionException e) { System.out.println("get: " + e.getClass().getSimpleName() + " <- " + e.getCause().getMessage()); }
        System.out.println("catch (Exception) ловит Error: " + catchesError());
    }
    static boolean catchesError() {
        try { try { throw new StackOverflowError(); } catch (Exception e) { return true; } }
        catch (Error err) { return false; }
    }
}
