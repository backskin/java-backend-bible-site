// MODE: javac
// OUT: s06-multicatch-subtype
import java.io.*;
class S6MultiCatch {
    void f() {
        try { new FileReader("x").close(); }
        catch (FileNotFoundException | IOException e) { }
    }
}
