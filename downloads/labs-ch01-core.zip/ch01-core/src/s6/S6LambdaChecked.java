// MODE: javac
// OUT: s06-lambda-checked-javac
import java.nio.file.*;
import java.util.List;
class S6LambdaChecked {
    void f(List<Path> paths) { paths.stream().map(p -> Files.readString(p)).toList(); }
}
