// OUT: s06-exceptions-demo
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.*;
import java.util.List;
import java.util.concurrent.CountDownLatch;
public class S6Exceptions {
    static class DocumentNotFoundException extends RuntimeException {
        DocumentNotFoundException(String id, Throwable cause) { super("документ не найден: " + id, cause); }
    }
    static class DocumentStoreException extends RuntimeException {
        DocumentStoreException(String msg, Throwable cause) { super(msg, cause); }
    }
    static String load(Path dir, String id) {
        try { return Files.readString(dir.resolve(id)); }
        catch (NoSuchFileException e) { throw new DocumentNotFoundException(id, e); }
        catch (IOException e) { throw new DocumentStoreException("cannot read document " + id, e); }
    }
    @FunctionalInterface interface ThrowingFunction<T, R> { R apply(T t) throws IOException; }
    static <T, R> java.util.function.Function<T, R> unchecked(ThrowingFunction<T, R> f) {
        return t -> { try { return f.apply(t); } catch (IOException e) { throw new UncheckedIOException(e); } };
    }
    @SuppressWarnings("unchecked")
    static <E extends Throwable> void sneakyThrow(Throwable t) throws E { throw (E) t; }
    static void preciseRethrow() throws IOException {
        try { Files.readString(Path.of("нет-такого-файла.txt")); }
        catch (Exception e) { throw e; }
    }
    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("docs");
        Files.writeString(dir.resolve("a.txt"), "документ A");
        System.out.println("--- 1. граница слоя");
        System.out.println(load(dir, "a.txt"));
        try { load(dir, "нет.txt"); }
        catch (DocumentNotFoundException e) { System.out.println(e.getMessage() + ", причина: " + e.getCause().getClass().getSimpleName()); }
        System.out.println("--- 2. лямбда в Stream: проверяемое исключение в обёртке");
        System.out.println(List.of("a.txt").stream().map(unchecked(f -> Files.readString(dir.resolve(f)))).toList());
        try { List.of("нет.txt").stream().map(unchecked(f -> Files.readString(dir.resolve(f)))).toList(); }
        catch (UncheckedIOException e) { System.out.println("UncheckedIOException, причина: " + e.getCause().getClass().getSimpleName()); }
        System.out.println("--- 3. sneakyThrow: проверяемое исключение без throws");
        try { S6Exceptions.<RuntimeException>sneakyThrow(new IOException("вылетело без объявления")); }
        catch (Exception e) { System.out.println("поймали " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
        System.out.println("--- 4. точное повторное бросание (precise rethrow)");
        try { preciseRethrow(); }
        catch (IOException e) { System.out.println("поймали IOException, на деле " + e.getClass().getSimpleName()); }
        System.out.println("--- 5. InterruptedException: восстановить флаг");
        Thread worker = new Thread(() -> {
            try { new CountDownLatch(1).await(); }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("флаг прерывания восстановлен: " + Thread.currentThread().isInterrupted());
            }
        });
        worker.start(); worker.interrupt(); worker.join();
    }
}
