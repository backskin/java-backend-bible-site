// OUT: s06-exception-cost
class S6Cost {
    static class Normal extends RuntimeException { Normal() { super("x"); } }
    static class NoStack extends RuntimeException { NoStack() { super("x", null, false, false); } }
    static Object deep(int depth, boolean stack) {
        if (depth > 0) return deep(depth - 1, stack);
        return stack ? new Normal() : new NoStack();
    }
    public static void main(String[] args) {
        int n = 200_000;
        for (int depth : new int[]{5, 100}) {
            for (int warm = 0; warm < 3; warm++) {
                long t0 = System.nanoTime(); Object sink = null;
                for (int i = 0; i < n; i++) sink = deep(depth, true);
                long withStack = (System.nanoTime() - t0) / n;
                t0 = System.nanoTime();
                for (int i = 0; i < n; i++) sink = deep(depth, false);
                long without = (System.nanoTime() - t0) / n;
                if (warm == 2) System.out.println("глубина " + depth + ": со стеком " + withStack + " нс, без стека " + without + " нс (включая сам рекурсивный спуск)" + (sink == null ? "" : ""));
            }
        }
        System.out.println("(грубый замер без JMH; порядок величин, не точные числа)");
    }
}
