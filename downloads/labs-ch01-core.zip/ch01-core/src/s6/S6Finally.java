// OUT: s06-finally
class S6Finally {
    static class BusinessException extends RuntimeException { BusinessException(String m) { super(m); } }
    static class Conn implements AutoCloseable {
        public void close() { throw new IllegalStateException("Connection is closed"); }
    }
    public static void main(String[] args) throws Exception {
        try {
            Conn conn = new Conn();
            try { throw new BusinessException("не хватает средств"); }
            finally { conn.close(); }
        } catch (Exception e) { System.out.println("try/finally: наверх ушло " + e.getMessage() + ", suppressed " + e.getSuppressed().length); }
        try (Conn conn = new Conn()) {
            throw new BusinessException("не хватает средств");
        } catch (Exception e) { System.out.println("try-with-resources: наверх ушло " + e.getMessage() + ", suppressed: " + e.getSuppressed()[0].getMessage()); }
        try (AutoCloseable nothing = null) { System.out.println("ресурс null: тело выполнено, close() не вызван"); }
        Conn ready = new Conn();
        try (ready) { System.out.println("Java 9: try (ready) с готовой переменной"); }
        catch (IllegalStateException e) { System.out.println("закрытие: " + e.getMessage()); }
        Thread t = new Thread(() -> { });
        try { t.stop(); } catch (UnsupportedOperationException e) { System.out.println("Thread.stop(): " + e.getClass().getSimpleName()); }
    }
}
