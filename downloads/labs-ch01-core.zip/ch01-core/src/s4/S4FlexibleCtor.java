// MODE: javac
// OUT: s04-flexible-constructor
class S4FlexibleCtor {
    static class Account { Account(long limit) { } }
    static class CreditAccount extends Account {
        CreditAccount(long limit) {
            if (limit < 0) throw new IllegalArgumentException("limit");
            super(limit);
        }
    }
}
