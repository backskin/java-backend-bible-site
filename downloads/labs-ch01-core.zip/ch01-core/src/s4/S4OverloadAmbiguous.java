// MODE: javac
// OUT: s04-overload-ambiguous
class S4OverloadAmbiguous {
    static void h(String s)        { }
    static void h(StringBuilder b) { }
    void call() { h(null); }
}
