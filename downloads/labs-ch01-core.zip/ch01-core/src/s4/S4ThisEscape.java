// MODE: javac
// JAVAC: -Xlint:this-escape
// OUT: s04-this-escape-lint
package dev.team.lint;
public class S4ThisEscape {
    public S4ThisEscape() { init(); }
    protected void init() { }
}
