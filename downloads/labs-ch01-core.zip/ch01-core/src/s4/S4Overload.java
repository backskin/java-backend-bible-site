// OUT: s04-overload
import java.util.*;
class S4Overload {
    static class Parent { void greet() { System.out.println("Parent"); } }
    static class Child extends Parent { @Override void greet() { System.out.println("Child"); } }
    static void handle(Object o) { System.out.println("Object"); }
    static void handle(String s) { System.out.println("String"); }
    static void g(String s) { System.out.println("g(String)"); }
    static void g(Object o) { System.out.println("g(Object)"); }
    static void f(Integer x)   { System.out.println("Integer"); }
    static void f(Object... x) { System.out.println("varargs"); }
    public static void main(String[] args) {
        Parent p = new Child(); p.greet();
        Object o = "я строка";
        handle(o); handle((String) o); handle("литерал");
        g(null);
        f(5);
        List<Integer> list = new ArrayList<>(List.of(1, 2, 3));
        list.remove(1);
        System.out.println("list.remove(1) на [1, 2, 3]: " + list);
        list = new ArrayList<>(List.of(1, 2, 3));
        list.remove(Integer.valueOf(1));
        System.out.println("list.remove(Integer.valueOf(1)): " + list);
    }
}
