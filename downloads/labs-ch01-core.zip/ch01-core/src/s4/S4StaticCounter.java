// OUT: s04-static-counter
class S4StaticCounter {
    static class Test { static int field = 5; }
    static class SomeClass { static int i = 7; }
    @SuppressWarnings("static-access")
    public static void main(String[] args) {
        Test test1 = new Test(), test2 = new Test(), test3 = new Test();
        test1.field++; test2.field++; test3.field++; Test.field++; ++Test.field;
        System.out.println(++Test.field);
        SomeClass someClass = null;
        System.out.println("someClass.i при someClass == null: " + someClass.i);
    }
}
