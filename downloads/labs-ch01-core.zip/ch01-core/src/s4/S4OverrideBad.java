// MODE: javac
// OUT: s04-override-bad
import java.io.IOException;
class Base4 { public Object find() { return null; } void load() throws IOException { } }
class Narrower extends Base4 { @Override protected Object find() { return null; } }
class MoreThrows extends Base4 { @Override void load() throws Exception { } }
