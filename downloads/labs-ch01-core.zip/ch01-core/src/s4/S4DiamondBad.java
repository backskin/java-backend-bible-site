// MODE: javac
// OUT: s04-default-diamond-errors
class S4DiamondBad {
    interface Logger  { default String name() { return "logger"; } }
    interface Metrics { default String name() { return "metrics"; } }
    static class NoOverride implements Logger, Metrics { }
    static class Service implements Logger, Metrics { public String name() { return "s"; } }
    static class Sub extends Service { public String name() { return Logger.super.name(); } }
    interface WithEquals { default boolean equals(Object o) { return false; } }
}
