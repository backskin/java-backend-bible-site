// OUT: s04-lambda-capture
import java.util.*;
import java.util.function.*;
class S4Lambda {
    private int count;
    Runnable inc() { return () -> count++; }
    String who() { return "S4Lambda"; }
    Supplier<String> lambdaThis() { return () -> this.who(); }
    Supplier<String> anonThis() { return new Supplier<>() { public String get() { return this.getClass().getName(); } }; }
    static Runnable make() { return () -> { }; }
    static Runnable makeCapturing(int x) { return () -> System.out.print(x); }
    public static void main(String[] args) {
        S4Lambda l = new S4Lambda();
        Runnable r = l.inc(); r.run(); r.run();
        System.out.println("поле через this: " + l.count);
        System.out.println("this в лямбде: " + l.lambdaThis().get() + ", this в анонимном классе: " + l.anonThis().get());
        System.out.println("лямбда без захвата, два прохода через одну точку: тот же объект " + (make() == make()));
        System.out.println("лямбда с захватом: тот же объект " + (makeCapturing(1) == makeCapturing(1)));
        int[] holder = {0};
        List.of(1, 2, 3).forEach(x -> holder[0] += x);
        System.out.println("holder[0] = " + holder[0]);
        Function<String, Integer> f2 = String::length;
        BiFunction<String, String, Boolean> f5 = String::startsWith;
        System.out.println(f2.apply("abc") + " " + f5.apply("PAY-1", "PAY"));
    }
}
