// MODE: javap Outer2$Result Outer2$ResultUsingOuter
// OUT: s04-inner-no-this0-javap
class Outer2 {
    private final byte[] buffer = new byte[16];
    class Result { String get() { return "done"; } }
    class ResultUsingOuter { String get() { return "done " + buffer.length; } }
}
