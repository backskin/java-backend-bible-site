// MODE: javac
// OUT: s04-capture-error
class S4CaptureError {
    void f() {
        int counter = 0;
        Runnable r = () -> System.out.println(counter);
        counter++;
    }
}
