// MODE: javap Outer$Inner Outer$Nested
// OUT: s04-inner-this0-javap
class Outer {
    private int x = 1;
    class Inner { int get() { return x; } }
    static class Nested { int get() { return 42; } }
}
