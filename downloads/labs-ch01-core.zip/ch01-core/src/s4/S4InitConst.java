// OUT: s04-init-constant
class S4InitConst {
    static class Config {
        static final String NAME = "svc";
        static final String HOST = System.getProperty("user.language");
        static { System.out.println("Config init"); }
    }
    public static void main(String[] args) {
        System.out.println(Config.NAME);
        System.out.println(Config.HOST);
    }
}
