// MODE: javap S4Hiding
// OUT: s04-static-hiding-javap
class A4 { static String who() { return "A"; } }
class B4 extends A4 { static String who() { return "B"; } }
class S4Hiding {
    @SuppressWarnings("static-access")
    static String call() { A4 a = new B4(); return a.who(); }
}
