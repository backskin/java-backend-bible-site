// OUT: s04-final-copyof
import java.util.*;
class S4Final {
    public static void main(String[] args) {
        final List<String> names = new ArrayList<>();
        names.add("x");
        System.out.println("final List пополнился: " + names);
        List<String> src = new ArrayList<>(List.of("a"));
        List<String> copy = List.copyOf(src);
        List<String> view = Collections.unmodifiableList(src);
        src.add("b");
        System.out.println("List.copyOf: " + copy + ", unmodifiableList: " + view);
        List<String> imm = List.of("x");
        System.out.println("List.copyOf(List.of(...)) возвращает тот же объект: " + (List.copyOf(imm) == imm));
    }
}
