// MODE: javac
// OUT: s04-protected-other-package
package other;
class Sub extends java.util.AbstractList<String> {
    public String get(int i) { return null; }
    public int size() { return 0; }
    void f(java.util.AbstractList<String> b, Sub s) {
        int x = b.modCount;
        int y = s.modCount;
        int z = this.modCount;
    }
}
