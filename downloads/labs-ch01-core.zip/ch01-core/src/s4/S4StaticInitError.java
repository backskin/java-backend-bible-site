// OUT: s04-static-init-error
import java.util.Map;
class S4StaticInitError {
    static class Registry {
        static final Map<String, String> HANDLERS = load();
        private static Map<String, String> load() { throw new IllegalStateException("bad config"); }
    }
    public static void main(String[] args) {
        for (int i = 1; i <= 2; i++) {
            try { System.out.println(Registry.HANDLERS); }
            catch (Throwable t) { System.out.println(i + ": " + t + (t.getCause() != null ? ", причина: " + t.getCause() : "")); }
        }
    }
}
