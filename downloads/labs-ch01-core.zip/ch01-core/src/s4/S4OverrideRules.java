// MODE: javap JdbcRepository
// OUT: s04-override-covariant-bridge
import java.io.IOException;
import java.sql.SQLException;
class Repository {
    protected Object find(long id) throws IOException, SQLException { return null; }
}
class JdbcRepository extends Repository {
    @Override
    public String find(long id) throws SQLException { return "row"; }
}
