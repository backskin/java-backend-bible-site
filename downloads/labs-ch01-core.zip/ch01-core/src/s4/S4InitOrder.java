// OUT: s04-init-order
class S4InitOrder {
    static class Parent {
        static { System.out.println("1 static Parent"); }
        { System.out.println("3 instance Parent"); }
        Parent() { System.out.println("4 ctor Parent"); init(); }
        void init() { System.out.println("Parent.init"); }
    }
    static class Child extends Parent {
        static { System.out.println("2 static Child"); }
        private String name = "заполнено";
        { System.out.println("5 instance Child, name=" + name); }
        Child() { super(); System.out.println("6 ctor Child, name=" + name); }
        @Override void init() { System.out.println("Child.init, name=" + name); }
    }
    static class Broken {
        static int a = compute();
        static int b = 10;
        static int compute() { return b * 2; }
    }
    public static void main(String[] args) {
        new Child();
        System.out.println("Broken.a = " + Broken.a + ", Broken.b = " + Broken.b);
    }
}
