// MODE: javac
// OUT: s04-abstract-instantiate
class S4Abstract {
    abstract static class Car { void drive() { } }
    Object a() { return new Car(); }
    Object b() { return new Car() { }; }
}
