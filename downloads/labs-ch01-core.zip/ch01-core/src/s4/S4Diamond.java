// OUT: s04-default-diamond
class S4Diamond {
    interface Logger  { default String name() { return "logger"; } }
    interface Metrics { default String name() { return "metrics"; } }
    static class Service implements Logger, Metrics {
        @Override public String name() { return Logger.super.name() + "+" + Metrics.super.name(); }
    }
    public static void main(String[] args) { System.out.println(new Service().name()); }
}
