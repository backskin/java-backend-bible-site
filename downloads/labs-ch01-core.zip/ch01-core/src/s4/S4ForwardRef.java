// MODE: javac
// OUT: s04-illegal-forward-reference
class S4ForwardRef {
    static int a = b * 2;
    static int b = 10;
}
