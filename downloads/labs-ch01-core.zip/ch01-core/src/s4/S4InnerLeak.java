// OUT: s04-inner-leak
import java.lang.ref.WeakReference;
import java.util.function.Supplier;
class S4InnerLeak {
    static class ReportService {
        private final byte[] buffer = new byte[50 * 1024 * 1024];
        class Result implements Supplier<String> { @Override public String get() { return "done"; } }
        class ResultUsingOuter implements Supplier<String> { @Override public String get() { return "done " + buffer.length; } }
        static class StaticResult implements Supplier<String> { @Override public String get() { return "done"; } }
        Supplier<String> inner() { return new Result(); }
        Supplier<String> innerUsingOuter() { return new ResultUsingOuter(); }
        Supplier<String> nested() { return new StaticResult(); }
        Supplier<String> lambda() { return () -> "done"; }
        Supplier<String> lambdaWithThis() { return () -> "done " + buffer.length; }
    }
    static void check(String name, java.util.function.Function<ReportService, Supplier<String>> make) {
        ReportService svc = new ReportService();
        WeakReference<ReportService> ref = new WeakReference<>(svc);
        Supplier<String> cached = make.apply(svc);
        svc = null;
        for (int i = 0; i < 5 && ref.get() != null; i++) System.gc();
        System.out.println(name + ": сервис с буфером 50 МБ " + (ref.get() == null ? "собран" : "удерживается результатом") + " (" + cached.get().length() + ")");
    }
    public static void main(String[] args) {
        check("внутренний класс", ReportService::inner);
        check("внутренний, читает поле внешнего", ReportService::innerUsingOuter);
        check("static nested    ", ReportService::nested);
        check("лямбда без this  ", ReportService::lambda);
        check("лямбда с полем   ", ReportService::lambdaWithThis);
    }
}
