// MODE: javac
// JAVAC: -Xlint:all
// OUT: s04-static-lint
class S4StaticLint {
    static class SomeClass { static int i = 7; }
    int f() { SomeClass s = null; return s.i; }
}
