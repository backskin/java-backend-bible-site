// MODE: javac
// JAVAC: -Xlint:unchecked -Werror
// OUT: s05-raw-werror
import java.util.*;
class S5RawWerror {
    @SuppressWarnings("rawtypes")
    void f() {
        List<Integer> nums = new ArrayList<>();
        List raw = nums;
        raw.add("не число");
    }
}
