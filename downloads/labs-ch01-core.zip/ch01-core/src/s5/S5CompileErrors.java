// MODE: javac
// JAVAC: -Xlint:unchecked
// OUT: s05-compile-errors
import java.util.*;
class S5CompileErrors<T> {
    T make() { return new T(); }
    T[] arr() { return new T[10]; }
    boolean test(Object x) { return x instanceof List<String>; }
    void f(List<String> l) { }
    void f(List<Integer> l) { }
    static T field;
    List<String>[] lists = new List<String>[10];
    void pecs(List<? extends Number> numbers) { numbers.add(Integer.valueOf(1)); }
    void inv() { List<Number> nums = new ArrayList<Integer>(); }
    void swapBroken(List<?> list) { list.set(0, list.get(1)); }
}
