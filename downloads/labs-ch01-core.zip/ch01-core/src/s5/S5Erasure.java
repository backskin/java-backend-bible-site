// MODE: javap Main5 StringBox
// OUT: s05-erasure-bridge-javap
class Box<T> {
    private T value;
    public T get() { return value; }
    public void set(T value) { this.value = value; }
}
class StringBox extends Box<String> {
    @Override public void set(String value) { super.set(value.trim()); }
}
class Main5 {
    static String read(Box<String> box) { return box.get(); }
}
