// OUT: s05-instanceof-generic
import java.util.*;
class S5InstanceofGeneric {
    static String kind(Collection<String> c) {
        if (c instanceof List<String> list) return "список из " + list.size();
        return "другая коллекция";
    }
    public static void main(String[] args) {
        System.out.println(kind(List.of("a", "b")) + "; " + kind(Set.of("a")));
    }
}
