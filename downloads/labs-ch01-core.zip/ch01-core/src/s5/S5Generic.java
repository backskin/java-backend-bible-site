// OUT: s05-generics
import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;
class S5Generic {
    @SuppressWarnings({"rawtypes", "unchecked"})
    static void legacy() {
        List list = new ArrayList();
        list.add("строка");
        list.add(42);
        try { String s = (String) list.get(1); } catch (ClassCastException e) { System.out.println("Java 1.4: " + e.getClass().getSimpleName()); }
    }
    @SuppressWarnings({"rawtypes", "unchecked"})
    static void pollution() {
        List raw = new ArrayList<String>();
        raw.add(42);
        List<String> strings = raw;
        try { String s = strings.get(0); } catch (ClassCastException e) { System.out.println("heap pollution: " + e.getMessage().substring(0, 60) + "..."); }
    }
    static <T> T[] toArray(T... args) { return args; }
    static <T> T[] pickTwo(T a, T b) { return toArray(a, b); }
    @SafeVarargs static <T> List<T> listOf(T... elements) { return new ArrayList<>(Arrays.asList(elements)); }
    static double sum(List<? extends Number> numbers) { double t = 0; for (Number n : numbers) t += n.doubleValue(); return t; }
    static void addNumbers(List<? super Integer> dest) { for (int i = 0; i < 3; i++) dest.add(i); }
    static void swap(List<?> list, int i, int j) { swapHelper(list, i, j); }
    private static <E> void swapHelper(List<E> list, int i, int j) { list.set(i, list.set(j, list.get(i))); }
    abstract static class TypeRef<T> {
        final Type type;
        protected TypeRef() { type = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0]; }
    }
    record User(String login) {}
    static class Message<T extends Message<T>> {
        String id;
        @SuppressWarnings("unchecked") T self() { return (T) this; }
        T id(String id) { this.id = id; return self(); }
    }
    static class Email extends Message<Email> { String subject; Email subject(String s) { subject = s; return this; } }
    public static void main(String[] args) {
        legacy();
        pollution();
        try { String[] r = pickTwo("a", "b"); } catch (ClassCastException e) { System.out.println("pickTwo: " + e.getMessage().substring(0, 70) + "..."); }
        System.out.println("listOf: " + listOf("a", "b"));
        System.out.println("sum(List<Integer>) = " + sum(List.of(1, 2, 3)) + ", sum(List<Double>) = " + sum(List.of(1.5, 2.5)));
        List<Object> objs = new ArrayList<>(); addNumbers(objs); System.out.println("addNumbers(List<Object>): " + objs);
        List<String> l = new ArrayList<>(List.of("a", "b")); swap(l, 0, 1); System.out.println("swap: " + l);
        System.out.println("TypeRef: " + new TypeRef<List<User>>() {}.type.getTypeName());
        System.out.println("CRTP: " + new Email().id("1").subject("hi").getClass().getSimpleName());
        Object[] objects = new String[3];
        try { objects[0] = 42; } catch (ArrayStoreException e) { System.out.println("ArrayStoreException: " + e.getMessage()); }
        Comparator<Object> byString = Comparator.comparing(Object::toString);
        List<Integer> ints = new ArrayList<>(List.of(10, 9, 100)); ints.sort(byString);
        System.out.println("Comparator<Object> для List<Integer> через ? super: " + ints);
        System.out.println("Collections.max: " + Collections.max(List.of(3, 7, 5)));
    }
}
