// OUT: s05-bridge-reflection
import java.lang.reflect.*;
import java.util.*;
class S5Bridge {
    static class Box<T> { T value; public void set(T v) { value = v; } }
    static class StringBox extends Box<String> { @Override public void set(String v) { super.set(v.trim()); } }
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        for (Method m : StringBox.class.getDeclaredMethods())
            names.add(m.getName() + "(" + m.getParameterTypes()[0].getSimpleName() + ") bridge=" + m.isBridge() + " synthetic=" + m.isSynthetic());
        Collections.sort(names);
        names.forEach(System.out::println);
        Box raw = new StringBox();
        try { raw.set(42); } catch (ClassCastException e) {
            System.out.println("raw.set(42): " + e.getClass().getSimpleName() + " в " + e.getStackTrace()[0].getMethodName() + " (строка " + e.getStackTrace()[0].getLineNumber() + ")");
        }
    }
}
