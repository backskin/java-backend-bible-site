// MODE: javac
// OUT: s05-generic-exception
class S5GenericException<T> extends Exception { }
