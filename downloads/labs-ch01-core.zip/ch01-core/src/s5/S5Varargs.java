// MODE: javac
// JAVAC: -Xlint:unchecked
// OUT: s05-varargs-warning
import java.util.*;
class S5Varargs {
    static void dangerous(List<String>... stringLists) {
        Object[] objects = stringLists;
        objects[0] = List.of(42);
    }
    @SafeVarargs void notAllowed(List<String>... lists) { }
}
