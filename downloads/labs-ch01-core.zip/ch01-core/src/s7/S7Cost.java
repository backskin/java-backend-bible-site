// OUT: s07-reflection-cost
import java.lang.invoke.*;
import java.lang.reflect.Method;
import java.util.function.Function;
class S7Cost {
    static class Payment { final long amount; Payment(long a) { amount = a; } long total() { return amount; } }
    static final MethodHandle MH;
    static { try { MH = MethodHandles.lookup().findVirtual(Payment.class, "total", MethodType.methodType(long.class)); } catch (Exception e) { throw new ExceptionInInitializerError(e); } }
    @SuppressWarnings("unchecked")
    static <T, R> Function<T, R> asFunction(Method m) throws Throwable {
        MethodHandles.Lookup lookup = MethodHandles.lookup();
        MethodHandle mh = lookup.unreflect(m);
        CallSite site = LambdaMetafactory.metafactory(lookup, "apply", MethodType.methodType(Function.class),
            MethodType.methodType(Object.class, Object.class), mh, MethodType.methodType(Long.class, Payment.class));
        return (Function<T, R>) site.getTarget().invokeExact();
    }
    public static void main(String[] args) throws Throwable {
        Payment p = new Payment(7);
        Method m = Payment.class.getDeclaredMethod("total");
        Function<Payment, Long> fn = asFunction(m);
        int n = 5_000_000;
        for (int round = 0; round < 3; round++) {
            long s = 0, t0 = System.nanoTime();
            for (int i = 0; i < n; i++) s += p.total();
            long direct = System.nanoTime() - t0; t0 = System.nanoTime();
            for (int i = 0; i < n; i++) s += (long) m.invoke(p);
            long refl = System.nanoTime() - t0; t0 = System.nanoTime();
            for (int i = 0; i < n; i++) s += (long) MH.invokeExact(p);
            long mh = System.nanoTime() - t0; t0 = System.nanoTime();
            for (int i = 0; i < n; i++) s += fn.apply(p);
            long lmf = System.nanoTime() - t0;
            if (round == 2) System.out.printf("на вызов: прямой %.1f нс, Method.invoke %.1f нс, MethodHandle static final %.1f нс, LambdaMetafactory %.1f нс (%d)%n",
                direct / (double) n, refl / (double) n, mh / (double) n, lmf / (double) n, s % 10);
        }
        System.out.println("(грубый замер без JMH; порядок величин)");
        System.out.println("getDeclaredMethod возвращает копию: " + (Payment.class.getDeclaredMethod("total") != Payment.class.getDeclaredMethod("total")));
    }
}
