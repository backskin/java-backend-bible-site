// JAVA: --add-opens java.base/java.lang=ALL-UNNAMED
// OUT: s07-add-opens
import java.lang.reflect.Field;
class S7AddOpens {
    public static void main(String[] args) throws Exception {
        Field v = String.class.getDeclaredField("value"); v.setAccessible(true);
        System.out.println("--add-opens java.base/java.lang=ALL-UNNAMED: String.value открыт, длина массива у \"abc\" = " + ((byte[]) v.get("abc")).length);
    }
}
