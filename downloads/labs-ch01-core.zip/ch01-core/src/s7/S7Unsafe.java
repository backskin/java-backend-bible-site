// OUT: s07-unsafe-warning
import java.lang.reflect.Field;
class S7Unsafe {
    public static void main(String[] args) throws Exception {
        Field f = sun.misc.Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true);
        sun.misc.Unsafe u = (sun.misc.Unsafe) f.get(null);
        long addr = u.allocateMemory(8);
        u.putLong(addr, 42L);
        System.out.println("Unsafe.getLong = " + u.getLong(addr));
        u.freeMemory(addr);
    }
}
