// OUT: s07-serviceloader
import java.util.ServiceLoader;
import java.sql.Driver;
class S7ServiceLoader {
    public static void main(String[] args) {
        System.out.println("java.sql.Driver через ServiceLoader на голом JDK: " + ServiceLoader.load(Driver.class).stream().count());
        System.out.println("FileSystemProvider: " + java.nio.file.spi.FileSystemProvider.installedProviders().stream().map(java.nio.file.spi.FileSystemProvider::getScheme).toList());
        System.out.println("ToolProvider javac найден: " + java.util.spi.ToolProvider.findFirst("javac").isPresent());
    }
}
