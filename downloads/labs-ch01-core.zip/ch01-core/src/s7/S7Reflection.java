// OUT: s07-reflection
import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;
class S7Reflection {
    static class Init { static { System.out.println("  статический блок Init выполнен"); } }
    static class Payment { private long amount = 10; private final long fixed = 5; long total() { return amount; } }
    @Retention(RetentionPolicy.CLASS) @interface ClassRetained { }
    @Retention(RetentionPolicy.RUNTIME) @interface Runtime1 { }
    @Retention(RetentionPolicy.RUNTIME) @Inherited @interface Marked { }
    @Retention(RetentionPolicy.RUNTIME) @interface RateLimits { RateLimit[] value(); }
    @Retention(RetentionPolicy.RUNTIME) @Repeatable(RateLimits.class) @interface RateLimit { int permitsPerSecond(); }
    @ClassRetained @Runtime1 @Marked static class Annotated { }
    static class SubAnnotated extends Annotated { }
    @Marked interface MarkedIface { }
    static class Impl implements MarkedIface { }
    @RateLimit(permitsPerSecond = 10) @RateLimit(permitsPerSecond = 20) static class TwoLimits { }
    @RateLimit(permitsPerSecond = 5) static class OneLimit { }
    record Transfer(String from, long amount) { }
    void pay(String userId, long amount) { }
    public static void main(String[] args) throws Exception {
        System.out.println("Init.class:"); Class<?> c1 = Init.class;
        System.out.println("Class.forName(name, false, loader):"); Class.forName(Init.class.getName(), false, S7Reflection.class.getClassLoader());
        System.out.println("Class.forName(name):"); Class.forName(Init.class.getName());
        Payment p = new Payment();
        Field f = Payment.class.getDeclaredField("amount"); f.setAccessible(true); f.set(p, 100L);
        Field ff = Payment.class.getDeclaredField("fixed"); ff.setAccessible(true); ff.set(p, 50L);
        System.out.println("private поле через рефлексию: " + p.total() + ", private final поле: " + ff.getLong(p));
        Method m = S7Reflection.class.getDeclaredMethod("pay", String.class, long.class);
        System.out.println("имена параметров без -parameters: " + Arrays.stream(m.getParameters()).map(Parameter::getName).toList());
        System.out.println("getMethods() у Payment включает унаследованные: " + (Payment.class.getMethods().length > 0) + ", getDeclaredMethods(): " + Payment.class.getDeclaredMethods().length);
        System.out.println("@Retention(CLASS) через рефлексию: " + Annotated.class.getAnnotation(ClassRetained.class));
        System.out.println("@Retention(RUNTIME): " + (Annotated.class.getAnnotation(Runtime1.class) != null));
        System.out.println("@Inherited с суперкласса: getAnnotation " + (SubAnnotated.class.getAnnotation(Marked.class) != null) + ", getDeclaredAnnotation " + (SubAnnotated.class.getDeclaredAnnotation(Marked.class) != null));
        System.out.println("@Inherited с интерфейса: " + (Impl.class.getAnnotation(Marked.class) != null));
        System.out.println("@Repeatable, два экземпляра: getAnnotation " + TwoLimits.class.getAnnotation(RateLimit.class) + ", getAnnotationsByType " + TwoLimits.class.getAnnotationsByType(RateLimit.class).length);
        System.out.println("@Repeatable, один экземпляр: getAnnotation " + (OneLimit.class.getAnnotation(RateLimit.class) != null));
        System.out.println("record: isRecord " + Transfer.class.isRecord() + ", компоненты " + Arrays.stream(Transfer.class.getRecordComponents()).map(RecordComponent::getName).toList());
        try {
            Field v = String.class.getDeclaredField("value"); v.setAccessible(true);
            System.out.println("String.value открыт");
        } catch (InaccessibleObjectException e) { System.out.println(e.getMessage()); }
        try {
            Field v = ArrayList.class.getDeclaredField("elementData"); v.setAccessible(true);
        } catch (InaccessibleObjectException e) { System.out.println(e.getMessage()); }
    }
}
