# Опыты главы 01 (Java Core): 124 программы на JDK 21 и 25

Стенд к главе 01. Каждый вывод программы в главе получен отсюда: папка `src/sK/` отвечает разделу K главы (1 - примитивы и упаковка, 2 - строки, 3 - `equals` и `hashCode`, 4 - классы и наследование, 5 - обобщения, 6 - исключения, 7 - рефлексия и загрузка классов, 8 - сериализация, 9 - задачи T01–T31 из раздела "Типичные ошибки"). Готовые выводы лежат рядом в файлах `sK-<имя>.txt` с датой запуска и версией JDK в первой строке.

## Что нужно

- Temurin JDK 21.0.10 и JDK 25.0.5 в `~/.jdks` (пути заданы в словаре `JDKS` в начале `run.py`; другие версии - поправить там).
- Python 3 для `run.py`.
- Maven и JDK 21 для `maven-checks` (Jackson 2 и 3, EqualsVerifier).

## Запуск

Все программы на обоих JDK, вывод в `sK-<имя>.txt`:

```bash
python -X utf8 run.py
```

Выборочно:

```bash
python -X utf8 run.py src/s9/T01*.java
```

Режим задается комментариями в начале файла программы: `// MODE: run` (по умолчанию, `java Файл.java`), `// MODE: javac` (только компиляция, в вывод идут сообщения компилятора), `// MODE: javap Класс` (компиляция и `javap -c -p`), `// JAVAC:` и `// JAVA:` - флаги, `// ARGS:` - аргументы, `// OUT:` - имя файла вывода. Одну программу можно запустить и без скрипта: `java src/s1/S1Cache.java`.

Проверки с библиотеками:

```bash
cd maven-checks && mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -cp "target/classes;$(cat cp.txt)" dev.team.ch01.Checks
```

(на Linux и macOS разделитель classpath `:`). Вывод автора - `s01-s11-maven-checks.txt`.

## Что должно получиться

Если JDK те же, вывод совпадает с файлами `*.txt` дословно, кроме замеров времени (`s01-boxing-cost.txt`, `s06-exception-cost.txt`, `s07-reflection-cost.txt`) и номера броска в `s01-omit-stacktrace-fastthrow.txt`: они зависят от машины и момента компиляции C2.
