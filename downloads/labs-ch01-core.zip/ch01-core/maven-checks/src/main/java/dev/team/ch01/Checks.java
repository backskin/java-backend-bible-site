package dev.team.ch01;

import java.util.Map;
import nl.jqno.equalsverifier.EqualsVerifier;

public class Checks {
    static final class Key {
        private final int id;
        private final String name;
        Key(int id, String name) { this.id = id; this.name = name; }
        @Override public boolean equals(Object o) { return o instanceof Key k && k.id == id && java.util.Objects.equals(k.name, name); }
        @Override public int hashCode() { return Integer.hashCode(id); }
    }
    public static void main(String[] args) throws Exception {
        Map<String, Double> rate = Map.of("failureRate", 0.0 / 0.0);
        System.out.println("Jackson 2 " + com.fasterxml.jackson.databind.ObjectMapper.class.getPackage().getImplementationVersion()
            + ": " + new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(rate)
            + ", WRITE_NAN_AS_STRINGS по умолчанию: " + com.fasterxml.jackson.core.json.JsonWriteFeature.WRITE_NAN_AS_STRINGS.enabledByDefault());
        System.out.println("Jackson 3: " + new tools.jackson.databind.ObjectMapper().writeValueAsString(rate)
            + ", WRITE_NAN_AS_STRINGS по умолчанию: " + tools.jackson.core.json.JsonWriteFeature.WRITE_NAN_AS_STRINGS.enabledByDefault());
        record Dto(java.util.Optional<String> comment) {}
        try { System.out.println("Jackson 2, Optional без модуля: " + new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(new Dto(java.util.Optional.of("x")))); }
        catch (Exception e) { System.out.println("Jackson 2, Optional без модуля: " + e.getClass().getSimpleName() + ": " + e.getMessage().lines().findFirst().orElse("")); }
        System.out.println("Jackson 3, Optional: " + new tools.jackson.databind.ObjectMapper().writeValueAsString(new Dto(java.util.Optional.of("x"))));
        try { EqualsVerifier.forClass(Key.class).verify(); }
        catch (AssertionError e) { System.out.println("EqualsVerifier 4.5.2: " + e.getMessage().lines().limit(3).toList()); }
    }
}
