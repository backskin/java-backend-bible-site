# WebSocket на встроенном Tomcat: рукопожатие, параллельная отправка, медленный потребитель, лимиты, возобновление

Стенд к главе 28, раздел о WebSocket. Пять программ в `dev.team.ws` на Jakarta WebSocket 2.2 (Tomcat 11.0.24) с клиентом `java.net.http.WebSocket` из JDK: `HandshakeLab` (заголовки рукопожатия, подпротоколы, отказ), `ConcurrentSendLab` (что происходит при отправке из двух потоков в одну сессию), `SlowConsumerLab` (блокирующая отправка и `DEFAULT_BLOCKING_SEND_TIMEOUT = 20000`), `LimitsLab` (размер сообщения, тайм-аут простоя), `ResumeLab` (возобновление после обрыва с последним полученным номером). Значения по умолчанию Tomcat сверены по байткоду `org.apache.tomcat.websocket.Constants`. Выводы приведены в главе.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" dev.team.ws.HandshakeLab
```

В IDEA на каждый класс есть конфигурация.
