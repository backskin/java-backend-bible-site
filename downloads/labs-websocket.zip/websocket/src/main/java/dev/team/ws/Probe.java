package dev.team.ws;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/** Клиент на java.net.http.WebSocket: считает сообщения и запоминает код закрытия. Может «не читать», как зависший браузер. */
public final class Probe implements WebSocket.Listener {
    public final String name;
    public final AtomicInteger received = new AtomicInteger();
    public final List<String> messages = new CopyOnWriteArrayList<>();
    public final CompletableFuture<String> closed = new CompletableFuture<>();
    private final boolean reads;
    private final StringBuilder partial = new StringBuilder();
    public WebSocket ws;

    private Probe(String name, boolean reads) { this.name = name; this.reads = reads; }

    public static Probe connect(String name, String uri, boolean reads) {
        var p = new Probe(name, reads);
        p.ws = HttpClient.newHttpClient().newWebSocketBuilder().buildAsync(URI.create(uri), p).join();
        return p;
    }

    @Override public void onOpen(WebSocket ws) { ws.request(1); }

    @Override public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
        partial.append(data);
        if (last) { messages.add(partial.toString()); received.incrementAndGet(); partial.setLength(0); }
        if (reads) ws.request(1);           // медленный клиент больше не просит данных: TCP-буфер заполняется
        return null;
    }

    @Override public CompletionStage<?> onPing(WebSocket ws, ByteBuffer message) {
        System.out.println("   " + name + ": пришёл ping, клиент JDK ответит pong сам");
        ws.request(1);
        return null;
    }

    @Override public CompletionStage<?> onClose(WebSocket ws, int statusCode, String reason) {
        closed.complete(statusCode + " " + reason);
        return null;
    }

    @Override public void onError(WebSocket ws, Throwable error) { closed.complete("ошибка: " + error); }
}
