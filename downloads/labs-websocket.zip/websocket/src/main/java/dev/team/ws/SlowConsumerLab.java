package dev.team.ws;

/**
 * Опыт: один «зависший» клиент диспетчерской карты (вкладка браузера на заснувшем ноутбуке)
 * и блокирующая рассылка в одном цикле. Затем та же нагрузка с очередью на клиента.
 */
public class SlowConsumerLab {
    public static void main(String[] args) throws Exception {
        var tomcat = Server.start(8093, MapEndpoint.class);
        MapEndpoint.queueCapacity = 256;
        String payload = "x".repeat(4000);                              // событие с треком вагона, около 4 КБ
        for (String mode : new String[]{"direct", "queued"}) {
            MapEndpoint.mode = mode;
            MapEndpoint.blockingSendTimeoutMs = 3000;
            var fast = Probe.connect("диспетчер", "ws://localhost:8093/ws/map?region=*", true);
            var slow = Probe.connect("зависшая вкладка", "ws://localhost:8093/ws/map?region=*", false);
            Thread.sleep(300);
            System.out.println("== режим " + mode + ": 3000 событий по 4 КБ двум клиентам");
            long t0 = System.currentTimeMillis(), worst = 0;
            int worstSeq = 0;
            for (int i = 1; i <= 3000; i++) {
                long ms = MapEndpoint.publish("5" + (2000000 + i), "Урал", "Свердловск-Сортировочный", "ПРИБЫЛ", payload);
                if (ms > worst) { worst = ms; worstSeq = i; }
                if (i % 10 == 0) Thread.sleep(10);                    // около 1000 событий в секунду, как в час пик на сортировке
            }
            Thread.sleep(500);
            System.out.println("   рассылка заняла " + (System.currentTimeMillis() - t0) + " мс, самая долгая публикация " + worst + " мс на событии " + worstSeq);
            System.out.println("   диспетчер получил " + fast.received + ", зависшая вкладка " + slow.received
                    + "; вкладка закрыта: " + (slow.closed.isDone() ? slow.closed.join() : "нет"));
            if (!fast.ws.isOutputClosed()) fast.ws.sendClose(1000, "конец смены").join();
            slow.ws.abort();
            Thread.sleep(300);
        }
        tomcat.stop();
        System.exit(0);
    }
}
