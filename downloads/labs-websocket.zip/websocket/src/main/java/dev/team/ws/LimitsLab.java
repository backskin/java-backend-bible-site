package dev.team.ws;

/** Опыт: сообщение больше лимита, простой соединения и ping/pong. */
public class LimitsLab {
    public static void main(String[] args) throws Exception {
        var tomcat = Server.start(8094, LimitsEndpoint.class);
        String uri = "ws://localhost:8094/ws/limits";

        System.out.println("== 1. сообщение 1000 символов при лимите 1024");
        var a = Probe.connect("клиент", uri, true);
        a.ws.sendText("я".repeat(1000), true).join();
        Thread.sleep(300);
        System.out.println("   клиент получил: " + a.messages);
        System.out.println("== 2. сообщение 2000 символов");
        a.ws.sendText("я".repeat(2000), true).join();
        System.out.println("   клиент: соединение закрыто сервером: " + a.closed.get());

        System.out.println("== 3. ping от сервера");
        var b = Probe.connect("клиент", uri, true);
        b.ws.sendText("ping-me", true).join();
        Thread.sleep(500);
        System.out.println("== 4. клиент молчит при лимите простоя 1,5 с");
        long t0 = System.currentTimeMillis();
        for (int s = 1; s <= 25 && !b.closed.isDone(); s++) Thread.sleep(1000);
        System.out.println("   клиент через " + (System.currentTimeMillis() - t0) / 1000 + " с: "
                + (b.closed.isDone() ? "закрыто, " + b.closed.join() : "соединение открыто"));
        tomcat.stop();
        System.exit(0);
    }
}
