package dev.team.ws;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.websocket.server.WsSci;

import java.nio.file.Files;

/** Встроенный Tomcat 11 с конечными точками WebSocket: то же, что поднимает Spring Boot, но без Spring. */
public final class Server {
    private Server() { }

    public static Tomcat start(int port, Class<?>... endpoints) throws Exception {
        var tomcat = new Tomcat();
        tomcat.setPort(port);
        tomcat.setBaseDir(Files.createTempDirectory("ws-lab").toString());
        tomcat.getConnector();                                  // создать HTTP-коннектор по умолчанию
        Context ctx = tomcat.addContext("", null);
        ctx.addServletContainerInitializer(new WsSci(), null);  // поднимает ServerContainer и фильтр рукопожатия
        Tomcat.addServlet(ctx, "none", new jakarta.servlet.http.HttpServlet() { });  // без сервлета запрос не дойдёт до фильтра
        ctx.addServletMappingDecoded("/", "none");
        tomcat.start();
        var container = (jakarta.websocket.server.ServerContainer)
                ctx.getServletContext().getAttribute("jakarta.websocket.server.ServerContainer");
        for (Class<?> e : endpoints) container.addEndpoint(e);  // классы с @ServerEndpoint
        return tomcat;
    }
}
