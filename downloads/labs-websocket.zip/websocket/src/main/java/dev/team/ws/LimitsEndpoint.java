package dev.team.ws;

import jakarta.websocket.CloseReason;
import jakarta.websocket.OnClose;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.PongMessage;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;

import java.nio.ByteBuffer;

/** Ограничения сессии: размер сообщения и время простоя. */
@ServerEndpoint("/ws/limits")
public class LimitsEndpoint {
    @OnOpen
    public void open(Session session) {
        session.setMaxTextMessageBufferSize(1024);
        session.setMaxIdleTimeout(1500);
        System.out.println("   сервер: лимит сообщения " + session.getMaxTextMessageBufferSize() + " символов, простой " + session.getMaxIdleTimeout() + " мс");
    }

    @OnMessage
    public String onText(String text, Session session) throws Exception {
        if (text.equals("ping-me")) {
            session.getBasicRemote().sendPing(ByteBuffer.wrap("hb-1".getBytes()));
            return "{\"type\":\"pinged\"}";
        }
        return "{\"type\":\"ack\",\"len\":" + text.length() + "}";
    }

    @OnMessage
    public void onPong(PongMessage pong) {
        System.out.println("   сервер получил pong: " + new String(pong.getApplicationData().array(), pong.getApplicationData().arrayOffset(), pong.getApplicationData().remaining()));
    }

    @OnClose
    public void close(Session s, CloseReason r) {
        System.out.println("   сервер: сессия " + s.getId() + " закрыта, " + r.getCloseCode().getCode() + " " + r.getReasonPhrase());
    }
}
