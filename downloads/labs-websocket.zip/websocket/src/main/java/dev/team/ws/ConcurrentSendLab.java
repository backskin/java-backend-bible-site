package dev.team.ws;

/** Опыт: параллельная отправка в одну сессию через getBasicRemote(). */
public class ConcurrentSendLab {
    public static void main(String[] args) throws Exception {
        var tomcat = Server.start(8092, BurstEndpoint.class);
        for (String cmd : new String[]{"unsafe 2000", "safe 2000"}) {
            var p = Probe.connect("клиент", "ws://localhost:8092/ws/burst", true);
            System.out.println("== " + cmd);
            p.ws.sendText(cmd, true).join();
            Thread.sleep(1500);
            System.out.println("   клиент получил " + p.received + " сообщений из 4000");
            p.ws.sendClose(1000, "готово").join();
            Thread.sleep(200);
        }
        tomcat.stop();
    }
}
