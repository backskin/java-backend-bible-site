package dev.team.ws;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.HexFormat;

/** Опыт: рукопожатие и кадры WebSocket байт за байтом, через голый сокет. */
public class HandshakeLab {
    static final String GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";       // константа из RFC 6455, разд. 1.3

    public static void main(String[] args) throws Exception {
        var tomcat = Server.start(8091, MapEndpoint.class);
        String key = "dGhlIHNhbXBsZSBub25jZQ==";                         // ключ из примера RFC 6455
        String expected = Base64.getEncoder().encodeToString(
                MessageDigest.getInstance("SHA-1").digest((key + GUID).getBytes(StandardCharsets.US_ASCII)));
        System.out.println("== 1. рукопожатие; ожидаемый Sec-WebSocket-Accept = " + expected);
        try (var s = new Socket("localhost", 8091)) {
            OutputStream out = s.getOutputStream(); InputStream in = s.getInputStream();
            out.write(("GET /ws/map?region=%D0%A3%D1%80%D0%B0%D0%BB HTTP/1.1\r\nHost: localhost:8091\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                    + "Sec-WebSocket-Key: " + key + "\r\nSec-WebSocket-Version: 13\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            System.out.print(readHeaders(in));

            System.out.println("== 2. клиент шлёт текстовый кадр с маской");
            byte[] mask = {0x37, (byte) 0xfa, 0x21, 0x3d};
            byte[] frame = textFrame("{\"op\":\"ping\"}", mask);
            System.out.println("   кадр клиента: " + HexFormat.ofDelimiter(" ").formatHex(frame));
            out.write(frame);
            byte[] reply = readFrame(in);
            System.out.println("   кадр сервера: " + HexFormat.ofDelimiter(" ").formatHex(reply));
            System.out.println("   FIN=" + ((reply[0] & 0x80) != 0) + " opcode=" + (reply[0] & 0x0f) + " маска=" + ((reply[1] & 0x80) != 0)
                    + " длина=" + (reply[1] & 0x7f) + " данные=" + new String(reply, 2, reply.length - 2, StandardCharsets.UTF_8));

            System.out.println("== 3. клиент шлёт кадр без маски — нарушение протокола");
            out.write(textFrame("без маски", null));
            byte[] close = readFrame(in);
            int code = ((close[2] & 0xff) << 8) | (close[3] & 0xff);
            System.out.println("   сервер ответил кадром opcode=" + (close[0] & 0x0f) + ", код закрытия " + code
                    + " «" + new String(close, 4, close.length - 4, StandardCharsets.UTF_8) + "»");
        }
        Thread.sleep(200);
        tomcat.stop();
    }

    /** Текстовый кадр с FIN; маска обязательна для клиента (RFC 6455, разд. 5.3). */
    static byte[] textFrame(String text, byte[] mask) {
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        var b = new ByteArrayOutputStream();
        b.write(0x81);                                                   // FIN + opcode 1 (текст)
        b.write((mask == null ? 0 : 0x80) | data.length);                // бит маски + длина < 126
        if (mask != null) { b.writeBytes(mask); for (int i = 0; i < data.length; i++) data[i] ^= mask[i % 4]; }
        b.writeBytes(data);
        return b.toByteArray();
    }

    static String readHeaders(InputStream in) throws Exception {
        var sb = new StringBuilder();
        while (!sb.toString().endsWith("\r\n\r\n")) sb.append((char) in.read());
        return sb.toString().replace("\r\n", "\n   ").replaceFirst("^", "   ");
    }

    static byte[] readFrame(InputStream in) throws Exception {
        int b0 = in.read(), b1 = in.read();
        byte[] payload = in.readNBytes(b1 & 0x7f);
        byte[] all = new byte[2 + payload.length];
        all[0] = (byte) b0; all[1] = (byte) b1; System.arraycopy(payload, 0, all, 2, payload.length);
        return all;
    }
}
