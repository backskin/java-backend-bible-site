package dev.team.ws;

import com.fasterxml.jackson.databind.JsonNode;

/** Опыт: диспетчер теряет связь в тоннеле и переподключается с номером последнего события. */
public class ResumeLab {
    public static void main(String[] args) throws Exception {
        var tomcat = Server.start(8095, MapEndpoint.class);
        MapEndpoint.mode = "queued";
        String base = "ws://localhost:8095/ws/map?region=%D0%A3%D1%80%D0%B0%D0%BB";
        var p = Probe.connect("диспетчер", base, true);
        Thread.sleep(200);
        for (int i = 1; i <= 5; i++) MapEndpoint.publish("5200000" + i, "Урал", "Свердловск-Сортировочный", "ПРИБЫЛ", "");
        Thread.sleep(300);
        long last = MapEndpoint.JSON.readTree(p.messages.getLast()).get("seq").asLong();
        System.out.println("== 1. получено " + p.received + ", последнее seq " + last + "; связь пропала");
        p.ws.abort();
        for (int i = 6; i <= 12; i++) MapEndpoint.publish("5200000" + i, i % 2 == 0 ? "Урал" : "Сибирь", "Екатеринбург-Товарный", "ОТПРАВЛЕН", "");

        System.out.println("== 2. переподключение с since=" + last);
        var p2 = Probe.connect("диспетчер", base + "&since=" + last, true);
        Thread.sleep(300);
        for (String m : p2.messages) { JsonNode n = MapEndpoint.JSON.readTree(m); System.out.println("   догнал seq " + n.get("seq") + " " + n.get("wagon").asText() + " " + n.get("region").asText()); }

        System.out.println("== 3. переподключение после долгого перерыва: история хранит " + MapEndpoint.HISTORY_SIZE + " событий");
        for (int i = 13; i <= 80; i++) MapEndpoint.publish("52000" + i, "Урал", "Камышлов", "В ПУТИ", "");
        var p3 = Probe.connect("диспетчер", base + "&since=" + last, true);
        Thread.sleep(300);
        System.out.println("   " + p3.messages);
        tomcat.stop();
        System.exit(0);
    }
}
