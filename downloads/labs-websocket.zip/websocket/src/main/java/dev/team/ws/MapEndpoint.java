package dev.team.ws;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.websocket.CloseReason;
import jakarta.websocket.OnClose;
import jakarta.websocket.OnError;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.PongMessage;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Диспетчерская карта СтальМагистрали: клиент подписывается на регион и получает события по вагонам.
 * Режим рассылки переключается полем {@link #mode}: прямой блокирующей отправкой или через очередь на клиента.
 */
@ServerEndpoint("/ws/map")
public class MapEndpoint {
    public record WagonEvent(long seq, String wagon, String region, String station, String state, String payload) { }

    static final ObjectMapper JSON = new ObjectMapper();
    static final Map<Session, Client> CLIENTS = new ConcurrentHashMap<>();
    static final AtomicLong SEQ = new AtomicLong();
    static final Deque<WagonEvent> HISTORY = new ArrayDeque<>();        // последние события для догоняющих клиентов
    static final int HISTORY_SIZE = 50;
    static volatile String mode = "direct";                          // direct | queued
    static volatile int queueCapacity = 64;
    static volatile long blockingSendTimeoutMs = 20_000;

    /** Подписчик: регион и, в режиме queued, своя очередь с отдельным потоком отправки. */
    static final class Client {
        final Session session; final String region;
        final BlockingQueue<String> out; final Thread sender;
        Client(Session session, String region) {
            this.session = session; this.region = region;
            this.out = new ArrayBlockingQueue<>(queueCapacity);
            this.sender = Thread.ofVirtual().name("ws-send-" + session.getId()).start(this::drain);
        }
        void drain() {
            try {
                while (session.isOpen()) session.getBasicRemote().sendText(out.take());
            } catch (InterruptedException ignored) {
            } catch (Exception e) { System.out.println("   отправка " + session.getId() + " прервана: " + e); }
        }
        /** Положить в очередь; переполнение значит, что клиент не успевает читать. */
        boolean offer(String text) { return out.offer(text); }
    }

    @OnOpen
    public void open(Session session) throws Exception {
        session.getUserProperties().put("org.apache.tomcat.websocket.BLOCKING_SEND_TIMEOUT", blockingSendTimeoutMs);
        Map<String, List<String>> q = session.getRequestParameterMap();
        String region = q.getOrDefault("region", List.of("*")).get(0);
        CLIENTS.put(session, new Client(session, region));
        if (q.containsKey("since")) replay(session, region, Long.parseLong(q.get("since").get(0)));
    }

    /** Догнать клиента после переподключения: из истории, если её хватает, иначе попросить полный снимок. */
    static void replay(Session session, String region, long since) throws Exception {
        List<WagonEvent> missed;
        long oldest;
        synchronized (HISTORY) {
            oldest = HISTORY.isEmpty() ? SEQ.get() + 1 : HISTORY.peekFirst().seq();
            missed = HISTORY.stream().filter(e -> e.seq() > since && matches(region, e)).toList();
        }
        if (since + 1 < oldest) {
            session.getBasicRemote().sendText("{\"type\":\"resync\",\"reason\":\"история с " + oldest + ", клиент просит с " + (since + 1) + "\"}");
            return;
        }
        for (WagonEvent e : missed) session.getBasicRemote().sendText(JSON.writeValueAsString(e));
    }

    static boolean matches(String region, WagonEvent e) { return region.equals("*") || region.equals(e.region()); }

    @OnMessage
    public String onText(String text, Session session) {
        return "{\"type\":\"ack\",\"len\":" + text.length() + "}";
    }

    @OnMessage
    public void onPong(PongMessage pong, Session session) {
        System.out.println("   сервер получил pong от " + session.getId() + ": " + new String(pong.getApplicationData().array()));
    }

    @OnClose
    public void close(Session session, CloseReason reason) {
        Client c = CLIENTS.remove(session);
        if (c != null) c.sender.interrupt();
        System.out.println("   сервер: сессия " + session.getId() + " закрыта, " + reason.getCloseCode().getCode() + " " + reason.getReasonPhrase());
    }

    @OnError
    public void error(Session session, Throwable t) { System.out.println("   сервер: ошибка в " + session.getId() + ": " + t); }

    /** Опубликовать событие всем подписчикам региона. Возвращает время рассылки в мс. */
    public static long publish(String wagon, String region, String station, String state, String payload) throws Exception {
        var e = new WagonEvent(SEQ.incrementAndGet(), wagon, region, station, state, payload);
        synchronized (HISTORY) { HISTORY.addLast(e); while (HISTORY.size() > HISTORY_SIZE) HISTORY.removeFirst(); }
        String text = JSON.writeValueAsString(e);
        long t0 = System.nanoTime();
        for (Client c : CLIENTS.values()) {
            if (!matches(c.region, e) || !c.session.isOpen()) continue;
            if (mode.equals("direct")) {
                try { c.session.getBasicRemote().sendText(text); }
                catch (Exception ex) { System.out.println("   рассылка: сессия " + c.session.getId() + " — " + ex.getClass().getSimpleName() + ": " + ex.getMessage()); }
            } else if (!c.offer(text)) {
                System.out.println("   рассылка: очередь сессии " + c.session.getId() + " переполнена на seq " + e.seq() + ", отключаю");
                c.session.close(new CloseReason(CloseReason.CloseCodes.TRY_AGAIN_LATER, "клиент не успевает читать"));
            }
        }
        return (System.nanoTime() - t0) / 1_000_000;
    }
}
