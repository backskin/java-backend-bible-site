package dev.team.ws;

import jakarta.websocket.OnMessage;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

/** Два потока одновременно пишут в одну сессию: статус платежа и курс валюты в интернет-банке Тундра-Банка. */
@ServerEndpoint("/ws/burst")
public class BurstEndpoint {
    @OnMessage
    public void onText(String cmd, Session session) throws Exception {
        boolean safe = cmd.startsWith("safe");
        int n = Integer.parseInt(cmd.replaceAll("\\D", ""));
        var errors = new AtomicInteger(); var sent = new AtomicInteger();
        var firstError = new StringBuilder();
        var done = new CountDownLatch(2);
        for (String kind : new String[]{"status", "rate"}) {
            Thread.ofPlatform().start(() -> {
                for (int i = 0; i < n; i++) {
                    String text = "{\"type\":\"" + kind + "\",\"i\":" + i + ",\"pad\":\"" + "x".repeat(200) + "\"}";
                    try {
                        if (safe) { synchronized (session) { session.getBasicRemote().sendText(text); } }
                        else session.getBasicRemote().sendText(text);
                        sent.incrementAndGet();
                    } catch (Exception e) {
                        if (errors.incrementAndGet() == 1) synchronized (firstError) { firstError.append(e.getClass().getSimpleName()).append(": ").append(e.getMessage()); }
                    }
                }
                done.countDown();
            });
        }
        done.await();
        System.out.println("   сервер (" + (safe ? "с блокировкой" : "без блокировки") + "): отправлено " + sent + ", ошибок " + errors
                + (errors.get() > 0 ? ", первая: " + firstError : ""));
    }
}
