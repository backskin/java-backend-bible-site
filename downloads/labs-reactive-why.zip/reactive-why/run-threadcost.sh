#!/usr/bin/env bash
# Разд. 1.1: сколько стоит поток платформы в Linux-контейнере. Вывод в s11-threadcost.txt.
cd "$(dirname "$0")"
CP="mvc/target/classes;$(cat mvc/cp.txt)"
docker rm -f why-cost >/dev/null 2>&1
MSYS_NO_PATHCONV=1 docker run -d --name why-cost -p 18111:8080 -v "$(cygpath -m $PWD)/mvc/target:/app" eclipse-temurin:21.0.10_7-jdk \
  java -XX:NativeMemoryTracking=summary -jar /app/gateway-mvc-1.0.0.jar --logging.level.root=warn >/dev/null
for i in $(seq 1 90); do curl -s localhost:18111/ping >/dev/null && break; sleep 1; done
echo "== образ eclipse-temurin:21.0.10_7-jdk, ядро $(docker exec why-cost uname -r)"
echo "-- размер стека по умолчанию"
docker exec why-cost java -XX:+PrintFlagsFinal -version 2>/dev/null | grep -E " ThreadStackSize | VMThreadStackSize " | awk '{print "   "$2" = "$4" КБ"}'
export MSYS_NO_PATHCONV=1
nmt() { docker exec why-cost jcmd 1 VM.native_memory summary | grep -A3 "^-  *Thread" | tr -s ' ' | sed 's/^/   /'; }
ks() { docker exec why-cost awk '/KernelStack/{print $2}' /proc/meminfo; }
echo "-- в покое"; nmt; K0=$(ks); T0=$(docker exec why-cost sh -c 'ls /proc/1/task | wc -l')
echo "   потоков процесса: $T0, KernelStack системы: $K0 КБ"
java -Dstdout.encoding=UTF-8 -cp "$CP" dev.team.why.Load http://127.0.0.1:18111/check 400 25 > load.out 2>&1 &
LP=$!; sleep 15
echo "-- под нагрузкой: 400 клиентов ждут /check (пул Tomcat 200)"; nmt; K1=$(ks); T1=$(docker exec why-cost sh -c 'ls /proc/1/task | wc -l')
echo "   потоков процесса: $T1, KernelStack системы: $K1 КБ, прирост на поток: $(( (K1-K0) / (T1-T0) )) КБ"
wait $LP; sed 's/^/  /' load.out | grep одновременных; rm -f load.out
docker rm -f why-cost >/dev/null
