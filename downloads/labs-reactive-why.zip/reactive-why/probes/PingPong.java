import java.util.concurrent.locks.LockSupport;

/**
 * Разд. 1.1: два потока передают друг другу ход через park/unpark.
 * Время одной передачи — оценка цены переключения контекста вместе с пробуждением потока.
 */
public class PingPong {
    static volatile int turn;

    public static void main(String[] a) throws Exception {
        int rounds = 200_000;
        for (int series = 1; series <= 2; series++) {
            Thread[] t = new Thread[2];
            for (int k = 0; k < 2; k++) {
                final int me = k;
                t[k] = new Thread(() -> {
                    for (int i = 0; i < rounds; i++) {
                        while (turn != me) LockSupport.park();
                        turn = 1 - me;
                        LockSupport.unpark(t[1 - me]);
                    }
                });
            }
            turn = 0;
            long s = System.nanoTime();
            t[0].start(); t[1].start(); t[0].join(); t[1].join();
            double ns = System.nanoTime() - s;
            System.out.printf("   серия %d: %d передач хода за %.0f мс, %.2f мкс на передачу%n", series, 2 * rounds, ns / 1e6, ns / 1e3 / (2.0 * rounds));
        }
    }
}
