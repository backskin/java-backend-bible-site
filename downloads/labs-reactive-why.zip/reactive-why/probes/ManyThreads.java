import java.util.concurrent.CountDownLatch;

/** Разд. 1.1: сколько стоит запустить N платформенных потоков, которые ждут, и как растёт резидентная память процесса. */
public class ManyThreads {
    public static void main(String[] a) throws Exception {
        for (int n : new int[] {2_000, 20_000}) {
            CountDownLatch release = new CountDownLatch(1), started = new CountDownLatch(n);
            long rss0 = rss(), t = System.nanoTime();
            Thread[] ts = new Thread[n];
            for (int i = 0; i < n; i++) {
                ts[i] = new Thread(() -> { started.countDown(); try { release.await(); } catch (InterruptedException ignored) { } });
                ts[i].start();
            }
            started.await();
            long ms = (System.nanoTime() - t) / 1_000_000, rss1 = rss();
            System.out.printf("   %d потоков: запуск %d мс, прирост RSS %d МБ (%.0f КБ на поток)%n", n, ms, (rss1 - rss0) / 1024, (rss1 - rss0) * 1.0 / n);
            release.countDown();
            for (Thread x : ts) x.join();
        }
    }
    static long rss() throws Exception {
        for (String l : java.nio.file.Files.readAllLines(java.nio.file.Path.of("/proc/self/status")))
            if (l.startsWith("VmRSS:")) return Long.parseLong(l.replaceAll("[^0-9]", ""));
        return -1;
    }
}
