package dev.team.why;

import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Разд. 1.3: чисто вычислительная работа — хэш SHA-256 подписи 1 000 000 платёжных строк — в цикле и через Flux. */
public final class CpuBound {
    static final int N = 1_000_000;

    public static void main(String[] a) throws Exception {
        for (int round = 1; round <= 8; round++) {
            long t = System.nanoTime(); long s1 = loop();
            long t1 = System.nanoTime(); long s2 = flux();
            long t2 = System.nanoTime(); long s3 = fluxPublishOn();
            long t3 = System.nanoTime();
            System.out.printf("   серия %d: цикл %.0f мс, Flux.range.map.reduce %.0f мс, тот же Flux с publishOn(parallel) %.0f мс (суммы совпадают: %b)%n",
                    round, (t1 - t) / 1e6, (t2 - t1) / 1e6, (t3 - t2) / 1e6, s1 == s2 && s2 == s3);
        }
    }

    static long hash(int i) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(("40817810" + i + ";1500.00;RUB").getBytes(StandardCharsets.UTF_8));
            return d[0];
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    static long loop() { long s = 0; for (int i = 0; i < N; i++) s += hash(i); return s; }

    static long flux() { return Flux.range(0, N).map(CpuBound::hash).reduce(0L, Long::sum).block(); }

    static long fluxPublishOn() { return Flux.range(0, N).publishOn(Schedulers.parallel()).map(CpuBound::hash).reduce(0L, Long::sum).block(); }
}
