package dev.team.why;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.Duration;

/** Неблокирующий шлюз: ответ откладывается таймером на 190 мс, поток цикла событий свободен. */
@SpringBootApplication
@RestController
public class FluxGateway {
    @GetMapping("/check") Mono<String> check() { return Mono.just("ACCEPTED").delayElement(Duration.ofMillis(190)); }
    @GetMapping("/ping") Mono<String> ping() { return Mono.just("pong"); }
    public static void main(String[] args) { SpringApplication.run(FluxGateway.class, args); }
}
