# Зачем реактивность: закон Литтла на Tomcat, виртуальных потоках и Reactor Netty, стоимость потока, латентность без нагрузки

Стенд к главе 11, раздел 1. Два шлюза с одинаковыми обработчиками (`/ping` без ожидания, `/check` с ожиданием 190 мс): `mvc/` на Spring MVC и Tomcat (пул 200, второй прогон с `spring.threads.virtual.enabled=true`) и `flux/` на WebFlux и Reactor Netty; нагрузочный клиент `Load` на Reactor Netty держит заданное число одновременных запросов. `probes/` - `ManyThreads` (2000 и 20 000 ждущих потоков в контейнере с 2 ГБ) и `PingPong` (передача хода через `park/unpark`); `CpuBound` в `flux/` сравнивает цикл, `Flux.range.map.reduce` и `publishOn(parallel)` на SHA-256. Выводы автора - `s11-little.txt`, `s11-ping.txt`, `s11-threadcost.txt`, `s11-manythreads.txt`, `s11-pingpong.txt`, `s11-cpu.txt`.

## Что нужно

- JDK 21, Maven, bash с `curl`; Docker для `run-threadcost.sh` и `probes/`.

## Запуск

```bash
(cd mvc && mvn -q package -DskipTests dependency:build-classpath -Dmdep.outputFile=cp.txt) && (cd flux && mvn -q package -DskipTests) && bash run-little.sh
```

Остальные серии: `bash run-ping.sh`, `bash run-threadcost.sh`. Порт 18110 должен быть свободен. В IDEA есть конфигурации для шлюзов, `Load`, проб и Shell-конфигурации для скриптов.

## Что должно получиться

На `/check` при 200 и больше клиентах Tomcat с пулом 200 упирается в ~950 запросов/с по закону Литтла (p50 растет до 1 и 2 с), виртуальные потоки и Netty при 2000 клиентах дают ~8400 при p50 204 мс; на `/ping` с одним клиентом все три одинаковы (p50 около 0,1 мс). Поток платформы в Linux-контейнере обходится примерно в 40–100 КБ памяти (стек JVM и `KernelStack`). Цифры зависят от машины.
