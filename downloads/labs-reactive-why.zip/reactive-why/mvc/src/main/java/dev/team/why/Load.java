package dev.team.why;

import reactor.core.publisher.Flux;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Нагрузка: N одновременных клиентов в течение заданного времени шлют запросы подряд.
 * Клиенты стартуют с шагом 2 мс, чтобы не переполнить очередь accept.
 * Аргументы: url, одновременных, секунд. Выводит пропускную способность и перцентили.
 */
public final class Load {
    public static void main(String[] a) {
        String url = a[0]; int conc = Integer.parseInt(a[1]); int secs = Integer.parseInt(a[2]);
        HttpClient client = HttpClient.create(ConnectionProvider.builder("load").maxConnections(conc).pendingAcquireMaxCount(-1).build())
                .responseTimeout(Duration.ofSeconds(30));
        AtomicInteger ok = new AtomicInteger(), err = new AtomicInteger();
        java.util.Map<String, AtomicInteger> kinds = new java.util.concurrent.ConcurrentHashMap<>();
        long[] lat = new long[5_000_000]; AtomicInteger n = new AtomicInteger();
        long end = System.nanoTime() + secs * 1_000_000_000L, t0 = System.nanoTime();
        Flux.range(0, conc).flatMap(c -> reactor.core.publisher.Mono.delay(Duration.ofMillis(c * 2L)).thenMany(Flux.defer(() -> {
                    long s = System.nanoTime();
                    return client.get().uri(url).responseContent().aggregate().asString()
                            .doOnNext(x -> { ok.incrementAndGet(); int i = n.getAndIncrement(); if (i < lat.length) lat[i] = System.nanoTime() - s; })
                            .onErrorResume(e -> { err.incrementAndGet(); kinds.computeIfAbsent(e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()).replaceAll("[0-9a-f]{8}.*", "").lines().findFirst().orElse(""), k -> new AtomicInteger()).incrementAndGet(); return reactor.core.publisher.Mono.empty(); });
                }).repeat(() -> System.nanoTime() < end)), conc).blockLast();
        double el = (System.nanoTime() - t0) / 1e9;
        int cnt = Math.min(n.get(), lat.length); long[] l = Arrays.copyOf(lat, cnt); Arrays.sort(l);
        System.out.printf("   %d одновременных: %.0f запросов/с, ошибок %d, p50 %.3f мс, p99 %.3f мс%n",
                conc, ok.get() / el, err.get(), l[cnt / 2] / 1e6, l[(int) (cnt * 0.99)] / 1e6);
        if (!kinds.isEmpty()) System.out.println("     ошибки: " + kinds);
    }
}
