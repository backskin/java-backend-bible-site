package dev.team.why;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** Блокирующий шлюз: поток Tomcat спит 190 мс, имитируя ожидание внешнего платёжного шлюза. */
@SpringBootApplication
@RestController
public class MvcGateway {
    @GetMapping("/check") String check() throws InterruptedException { Thread.sleep(190); return "ACCEPTED"; }
    @GetMapping("/ping") String ping() { return "pong"; }
    public static void main(String[] args) { SpringApplication.run(MvcGateway.class, args); }
}
