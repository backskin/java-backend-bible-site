#!/usr/bin/env bash
# Разд. 1.3: латентность одного запроса без нагрузки, три серии по 15 с. Вывод в s11-ping.txt.
cd "$(dirname "$0")"
CP="mvc/target/classes;$(cat mvc/cp.txt)"
for r in 1 2 3; do for jar in mvc/target/gateway-mvc-1.0.0.jar flux/target/gateway-flux-1.0.0.jar; do
  java -jar $jar --server.port=18110 --logging.level.root=warn > app.log 2>&1 & P=$!
  for i in $(seq 1 60); do curl -s localhost:18110/ping >/dev/null && break; sleep 0.5; done
  java -Dstdout.encoding=UTF-8 -cp "$CP" dev.team.why.Load http://127.0.0.1:18110/ping 1 5 > /dev/null 2>&1
  echo "$(basename $jar .jar) серия $r: $(java -Dstdout.encoding=UTF-8 -cp "$CP" dev.team.why.Load http://127.0.0.1:18110/ping 1 15 2>/dev/null | grep одновременных)"
  kill $P; wait $P 2>/dev/null; sleep 1
done; done
