#!/usr/bin/env bash
# Разд. 1.1: закон Литтла на трёх серверах. Вывод в s11-little.txt.
cd "$(dirname "$0")"
CP="mvc/target/classes;$(cat mvc/cp.txt)"
load() { java -Dstdout.encoding=UTF-8 -cp "$CP" dev.team.why.Load "$@" 2>/dev/null | grep "одновременных"; }
serve() { curl -s -m 1 localhost:18110/ping >/dev/null && { echo "порт 18110 занят"; exit 1; }; java "${@:2}" -jar $1 --server.port=18110 --logging.level.root=warn > app.log 2>&1 & P=$!; for i in $(seq 1 60); do curl -s localhost:18110/ping >/dev/null && break; sleep 0.5; done; }
stop() { kill $P; wait $P 2>/dev/null; sleep 1; }
for mode in mvc mvc-vt flux; do
  case $mode in
    mvc) serve mvc/target/gateway-mvc-1.0.0.jar; echo "== Spring MVC, Tomcat, пул 200 потоков (по умолчанию)";;
    mvc-vt) serve mvc/target/gateway-mvc-1.0.0.jar -Dspring.threads.virtual.enabled=true; echo "== Spring MVC, виртуальные потоки";;
    flux) serve flux/target/gateway-flux-1.0.0.jar; echo "== Spring WebFlux, Reactor Netty";;
  esac
  load http://127.0.0.1:18110/check 50 3 > /dev/null
  echo "-- /check (ожидание 190 мс)"
  for c in 100 200 1000 2000; do load http://127.0.0.1:18110/check $c 15; done
  echo "-- /ping, один клиент (латентность без нагрузки)"
  load http://127.0.0.1:18110/ping 1 3 > /dev/null; load http://127.0.0.1:18110/ping 1 10
  stop
done
