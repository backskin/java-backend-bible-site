package dev.team.health;

import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Гл. 14 и 47: обработчик /limits держит поток Tomcat 2 с (как медленный вызов в смежную систему),
 * /whoami сообщает, на каком потоке обслужен запрос. Пул Tomcat — 4 потока, Actuator — на отдельном порту.
 */
@SpringBootApplication
@RestController
public class HealthApp {

    @GetMapping("/limits")
    Map<String, String> limits() {
        try { Thread.sleep(2000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return Map.of("account", "счёт", "thread", Thread.currentThread().getName());
    }

    @GetMapping("/whoami")
    String whoami() { return Thread.currentThread().getName(); }

    public static void main(String[] args) { SpringApplication.run(HealthApp.class, args); }
}
