package dev.team.jackson;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

/** Разд. 13.2 гл. 14: цена нового ObjectMapper на каждый разбор против общего (Jackson 3 из Spring Boot 4.1.1). */
public class MapperCost {
    public record Line(String sku, BigDecimal amount, int qty) {}
    public record PartnerQuote(String partnerId, String currency, BigDecimal total, Instant validTo, List<Line> lines, String status, long requestId, boolean final_) {}
    static final String JSON = "{\"partnerId\":\"P-17\",\"currency\":\"RUB\",\"total\":1500.50,\"validTo\":\"2026-10-28T10:00:00Z\",\"lines\":[{\"sku\":\"A\",\"amount\":500.25,\"qty\":1},{\"sku\":\"B\",\"amount\":1000.25,\"qty\":2}],\"status\":\"OK\",\"requestId\":42,\"final_\":true}";

    public static void main(String[] args) {
        ObjectMapper shared = JsonMapper.builder().build();
        for (int i = 0; i < 20_000; i++) { shared.readValue(JSON, PartnerQuote.class); JsonMapper.builder().build().readValue(JSON, PartnerQuote.class); }
        int n = 20_000;
        long t0 = System.nanoTime(); for (int i = 0; i < n; i++) shared.readValue(JSON, PartnerQuote.class); long sharedNs = (System.nanoTime() - t0) / n;
        long t1 = System.nanoTime(); for (int i = 0; i < n; i++) JsonMapper.builder().build().readValue(JSON, PartnerQuote.class); long freshNs = (System.nanoTime() - t1) / n;
        long t2 = System.nanoTime(); for (int i = 0; i < n; i++) JsonMapper.builder().build(); long buildNs = (System.nanoTime() - t2) / n;
        System.out.printf("jackson-databind %s%n", tools.jackson.databind.cfg.PackageVersion.VERSION);
        System.out.printf("общий маппер: %.1f мкс на readValue%n", sharedNs / 1000.0);
        System.out.printf("новый маппер на каждый вызов: %.1f мкс на readValue (из них сборка маппера %.1f мкс)%n", freshNs / 1000.0, buildNs / 1000.0);
        System.out.printf("разница: в %.0f раз%n", (double) freshNs / sharedNs);
    }
}
