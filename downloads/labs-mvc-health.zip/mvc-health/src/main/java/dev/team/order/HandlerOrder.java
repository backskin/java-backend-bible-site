package dev.team.order;

import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.DispatcherServlet;

/** Разд. 2.4 гл. 14: порядок HandlerMapping в DispatcherServlet на Spring Boot 4.1.1 (есть static/index.html). */
@SpringBootApplication
public class HandlerOrder {
    public static void main(String[] args) throws Exception {
        var app = new SpringApplication(HandlerOrder.class);
        app.setDefaultProperties(Map.of("server.port", "0", "management.server.port", "", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        try (var ctx = app.run()) {
            var ds = ctx.getBean(DispatcherServlet.class);
            var http = java.net.http.HttpClient.newHttpClient();
            http.send(java.net.http.HttpRequest.newBuilder(java.net.URI.create("http://127.0.0.1:" + ctx.getEnvironment().getProperty("local.server.port") + "/")).build(), java.net.http.HttpResponse.BodyHandlers.discarding());
            System.out.println("spring-boot " + org.springframework.boot.SpringBootVersion.getVersion());
            for (var m : ds.getHandlerMappings())
                System.out.printf("   order %-12s %s%n", m instanceof Ordered o ? (o.getOrder() == Integer.MAX_VALUE - 1 ? "MAX-1" : o.getOrder() == Integer.MAX_VALUE - 10 ? "MAX-10" : String.valueOf(o.getOrder())) : "—", m.getClass().getSimpleName());
        }
    }
}
