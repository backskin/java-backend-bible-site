package dev.team.incident;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;

/** Разд. 13.4 гл. 14: фильтр проверки подписи читает тело и передаёт дальше исходный запрос. */
@SpringBootApplication
@RestController
public class BodyIncident {
    record Transfer(String to, long amount) {}
    @PostMapping("/transfers") String t(@RequestBody Transfer t) { return "принят перевод на " + t.to(); }

    @Bean Filter signatureFilter() {
        return (req, res, chain) -> {
            var http = (HttpServletRequest) req;
            if (http.getHeader("X-Signature") != null) {
                String body = new String(http.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                req.setAttribute("signedBody", body);
            }
            chain.doFilter(req, res);
        };
    }

    public static void main(String[] args) throws Exception {
        var app = new SpringApplication(BodyIncident.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off", "logging.level.org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver", "WARN"));
        try (var ctx = app.run(args)) {
            String base = "http://127.0.0.1:" + ctx.getEnvironment().getProperty("local.server.port");
            var http = java.net.http.HttpClient.newHttpClient();
            for (boolean signed : new boolean[]{false, true}) {
                var b = java.net.http.HttpRequest.newBuilder(java.net.URI.create(base + "/transfers")).header("Content-Type", "application/json");
                if (signed) b = b.header("X-Signature", "abc");
                var r = http.send(b.POST(java.net.http.HttpRequest.BodyPublishers.ofString("{\"to\":\"40817810000000000001\",\"amount\":1500}")).build(), java.net.http.HttpResponse.BodyHandlers.ofString());
                System.out.printf("%-34s -> HTTP %d %s%n", signed ? "с X-Signature (фильтр читает тело)" : "без подписи", r.statusCode(), r.body().replaceAll("\s+", " "));
            }
        }
    }
}
