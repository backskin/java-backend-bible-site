package dev.team.incident;

import java.math.BigDecimal;
import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

/** Разд. 13.6 гл. 14: что происходит с полем amount = "1e999" при разных типах, и какое исключение видит общий обработчик. */
@SpringBootApplication
@RestController
public class AmountIncident {
    record PayLong(long amount) {}
    record PayBig(BigDecimal amount) {}
    record PayDouble(double amount) {}
    @PostMapping("/long") String l(@RequestBody PayLong p) { return "long=" + p.amount(); }
    @PostMapping("/big") String b(@RequestBody PayBig p) { return "BigDecimal=" + p.amount().toString().substring(0, Math.min(20, p.amount().toString().length())) + " scale=" + p.amount().scale(); }
    @PostMapping("/double") String d(@RequestBody PayDouble p) { return "double=" + p.amount(); }

    public static void main(String[] args) throws Exception {
        var app = new SpringApplication(AmountIncident.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        try (var ctx = app.run(args)) {
            String base = "http://127.0.0.1:" + ctx.getEnvironment().getProperty("local.server.port");
            var http = java.net.http.HttpClient.newHttpClient();
            for (String path : new String[]{"/long", "/big", "/double"}) for (String body : new String[]{"{\"amount\":\"1e999\"}", "{\"amount\":1e999}"}) {
                var r = http.send(java.net.http.HttpRequest.newBuilder(java.net.URI.create(base + path)).header("Content-Type", "application/json").POST(java.net.http.HttpRequest.BodyPublishers.ofString(body)).build(), java.net.http.HttpResponse.BodyHandlers.ofString());
                System.out.printf("POST %-7s %-20s -> HTTP %d %s%n", path, body, r.statusCode(), r.body().replaceAll("\s+", " ").substring(0, Math.min(170, r.body().length())));
            }
        }
    }
}
