package dev.team.incident;

import java.util.Map;
import java.util.concurrent.Executors;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

/** Разд. 13.7 гл. 14: SSE за nginx — события раз в 2 с (5 штук), с X-Accel-Buffering: no и без; /silent — первое событие через 15 с. Порт 18150. */
@SpringBootApplication
@RestController
public class SseIncident {
    final java.util.concurrent.ExecutorService pool = Executors.newCachedThreadPool();
    @GetMapping("/events") ResponseEntity<SseEmitter> events(@RequestParam(defaultValue = "false") boolean noBuffer, @RequestParam(defaultValue = "2000") long pause, @RequestParam(defaultValue = "5") int n) {
        var e = new SseEmitter(120_000L);
        pool.submit(() -> { try { for (int i = 1; i <= n; i++) { Thread.sleep(pause); e.send(SseEmitter.event().name("limit").data("лимит обновлён #" + i)); } e.complete(); } catch (Exception ex) { e.completeWithError(ex); } });
        var r = ResponseEntity.ok();
        if (noBuffer) r.header("X-Accel-Buffering", "no");
        return r.body(e);
    }
    public static void main(String[] args) {
        var app = new SpringApplication(SseIncident.class);
        app.setDefaultProperties(Map.of("logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        app.run(args);
    }
}
