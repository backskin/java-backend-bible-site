package dev.team.incident;

import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/** Разд. 13.5 гл. 14: часть multipart без собственного Content-Type и @RequestPart с DTO. */
@SpringBootApplication
@RestController
public class PartIncident {
    record DocumentMeta(String contractNo, String kind) {}
    @PostMapping(value = "/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    String upload(@RequestPart("meta") DocumentMeta meta, @RequestPart("file") MultipartFile file) { return "принят " + meta.contractNo() + ", " + file.getSize() + " байт"; }

    static String multipart(String boundary, boolean metaWithType) {
        String crlf = new String(new char[]{13, 10}), q = String.valueOf((char) 34);
        return "--" + boundary + crlf + "Content-Disposition: form-data; name=" + q + "meta" + q + crlf + (metaWithType ? "Content-Type: application/json" + crlf : "") + crlf
            + "{" + q + "contractNo" + q + ":" + q + "КД-7" + q + "," + q + "kind" + q + ":" + q + "scan" + q + "}" + crlf
            + "--" + boundary + crlf + "Content-Disposition: form-data; name=" + q + "file" + q + "; filename=" + q + "scan.pdf" + q + crlf + "Content-Type: application/pdf" + crlf + crlf + "%PDF-1.7" + crlf + "--" + boundary + "--" + crlf;
    }

    public static void main(String[] args) throws Exception {
        var app = new SpringApplication(PartIncident.class);
        app.setDefaultProperties(Map.of("logging.level.root", "OFF", "spring.main.banner-mode", "off", "spring.mvc.problemdetails.enabled", "true"));
        try (var ctx = app.run(args)) {
            String base = "http://127.0.0.1:" + ctx.getEnvironment().getProperty("local.server.port");
            var http = java.net.http.HttpClient.newHttpClient();
            for (boolean typed : new boolean[]{false, true}) {
                var r = http.send(java.net.http.HttpRequest.newBuilder(java.net.URI.create(base + "/documents")).header("Content-Type", "multipart/form-data; boundary=b1")
                        .POST(java.net.http.HttpRequest.BodyPublishers.ofString(multipart("b1", typed))).build(), java.net.http.HttpResponse.BodyHandlers.ofString());
                System.out.printf("%-38s -> HTTP %d %s%n", typed ? "часть meta с Content-Type: application/json" : "часть meta без Content-Type", r.statusCode(), r.body());
            }
        }
    }
}
