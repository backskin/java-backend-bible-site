import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Гл. 14 и 47: нагрузка на /limits (по 2 с блокировки потока Tomcat) и одновременный замер /livez на порту Actuator.
 * Аргументы: число одновременных /limits. Запуск: java Probe.java 16
 */
public class Probe {
    static String MAIN = System.getProperty("main", "18130"), MGMT = System.getProperty("mgmt", "18131");
    public static void main(String[] a) throws Exception {
        int n = Integer.parseInt(a[0]);
        HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
        System.out.println("   поток, обслуживший /whoami до нагрузки: " + get(http, "http://127.0.0.1:" + MAIN + "/whoami", 3).body());
        System.out.println("   /livez до нагрузки: " + time(http, "http://127.0.0.1:" + MGMT + "/actuator/health/liveness"));
        long start = System.nanoTime();
        List<CompletableFuture<HttpResponse<String>>> load = new ArrayList<>();
        for (int i = 0; i < n; i++)
            load.add(http.sendAsync(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + MAIN + "/limits")).timeout(Duration.ofSeconds(60)).build(),
                    HttpResponse.BodyHandlers.ofString()));
        Thread.sleep(300);
        System.out.println("   /livez на порту управления во время " + n + " блокирующих запросов: " + time(http, "http://127.0.0.1:" + MGMT + "/actuator/health/liveness"));
        System.out.println("   /livez на основном порту (add-additional-paths) во время нагрузки: " + time(http, "http://127.0.0.1:" + MAIN + "/livez"));
        System.out.println("   /whoami на основном порту во время нагрузки: " + time(http, "http://127.0.0.1:" + MAIN + "/whoami"));
        CompletableFuture.allOf(load.toArray(new CompletableFuture[0])).join();
        System.out.printf("   все %d запросов /limits завершились через %d мс после начала нагрузки%n", n, (System.nanoTime() - start) / 1_000_000);
    }

    static HttpResponse<String> get(HttpClient http, String u, int s) throws Exception {
        return http.send(HttpRequest.newBuilder(URI.create(u)).timeout(Duration.ofSeconds(s)).build(), HttpResponse.BodyHandlers.ofString());
    }

    static String time(HttpClient http, String u) {
        long t0 = System.nanoTime();
        try { var r = get(http, u, 10); return r.statusCode() + " " + r.body().replaceAll("\\s+", "") + " за " + (System.nanoTime() - t0) / 1_000_000 + " мс"; }
        catch (Exception e) { return "ошибка " + e.getClass().getSimpleName() + " через " + (System.nanoTime() - t0) / 1_000_000 + " мс"; }
    }
}
