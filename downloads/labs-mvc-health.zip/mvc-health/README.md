# Spring MVC: liveness при занятом пуле Tomcat, порядок HandlerMapping, инциденты с телом запроса, суммой, multipart и SSE за nginx

Стенд к главам 14 и 47. `HealthApp` с `server.tomcat.threads.max=4` и Actuator на отдельном порту, `Probe.java` дает 16 и 3 одновременных запроса `/limits` по 2 с и меряет `/actuator/health/liveness` (`run.sh`); `HandlerOrder` печатает `DispatcherServlet.getHandlerMappings()` с порядком; `MapperCost` - стоимость `readValue` у общего и нового `ObjectMapper`; инциденты: `BodyIncident` (фильтр вычитал тело, контроллер получил `Required request body is missing`), `AmountIncident` (`1e999` в сумме), `PartIncident` (часть multipart без `Content-Type`), `SseIncident` с `nginx-sse.conf` (буферизация SSE прокси). Выводы автора - `s14-*.txt`.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, bash с `curl`; Docker с nginx для `SseIncident`.

## Запуск

```bash
mvn -q package -DskipTests && bash run.sh
```

Приложение слушает 18130, порт управления 18131. Остальные программы запускаются из IDEA (конфигурация на каждый класс) или `java -cp "target/classes;$(cat cp.txt)" dev.team.incident.BodyIncident` после `mvn dependency:build-classpath -Dmdep.outputFile=cp.txt`.

## Что должно получиться

При 16 запросах на 4 потока liveness на порту управления отвечает, потому что у второго коннектора свой пул (`jcmd` показывает `http-nio-18130-exec-*` и `http-nio-18131-exec-*`); `POST /transfers` без подписи дает 200, с `X-Signature` - 400 и запись `DefaultHandlerExceptionResolver` в журнале; `WelcomePageHandlerMapping` и `BeanNameUrlHandlerMapping` оба с порядком 2.
