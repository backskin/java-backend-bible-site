#!/usr/bin/env bash
# Гл. 14 и 47: приложение Spring MVC на Tomcat с пулом из 4 потоков (server.tomcat.threads.max=4),
# 16 одновременных запросов /limits держат каждый поток 2 с; во время нагрузки меряем /actuator/health/liveness
# на отдельном порту управления. Вывод — s14-mvc-health.txt.
set -euo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
"$J" -jar target/mvc-health-1.0.0.jar > app.log 2>&1 &
APP=$!
until curl -s -o /dev/null http://127.0.0.1:18131/actuator/health/liveness; do sleep 1; done
JC="$(dirname "$J")/jcmd"; WPID=$("$JC" -l | awk '/mvc-health/ {print $1; exit}')
{
  echo "== Гл. 14 и 47. Spring MVC на Tomcat, 4 потока обработки, Actuator на отдельном порту; 16 запросов /limits по 2 с"
  "$J" -Dstdout.encoding=UTF-8 Probe.java 16
  echo "-- то же, 3 блокирующих запроса (меньше, чем потоков в пуле)"
  "$J" -Dstdout.encoding=UTF-8 Probe.java 3
  echo "-- потоки Tomcat в процессе (jcmd Thread.print): у основного порта и у порта управления"
  "$JC" "$WPID" Thread.print 2>/dev/null | grep -o '"http-nio-[0-9]*-exec-[0-9]*"' | sort -u | paste -sd' ' -
} | tee s14-mvc-health.txt
"$JC" "$WPID" VM.version >/dev/null 2>&1 && taskkill //F //PID "$WPID" >/dev/null 2>&1 || kill $APP
