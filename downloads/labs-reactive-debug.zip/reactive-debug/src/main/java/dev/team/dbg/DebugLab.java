package dev.team.dbg;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.Duration;
import reactor.blockhound.BlockHound;
import reactor.core.observability.micrometer.Micrometer;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Hooks;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.netty.http.client.HttpClient;
import reactor.netty.http.server.HttpServer;

/**
 * Разд. 9 гл. 11. Режимы (первый аргумент):
 *   checkpoint — что печатают три вида checkpoint и сколько стоит сборка с каждым;
 *   hook       — вывод Hooks.onOperatorDebug();
 *   blockhound — установка BlockHound и блокирующий вызов на parallel() и на цикле событий Netty;
 *   metrics    — какие метры даёт tap(Micrometer.metrics(registry)) после name().
 */
public final class DebugLab {

    static int parse(String s) { return Integer.parseInt(s); }   // упадёт на «12,50»

    static String suppressed(Throwable e) {
        StringWriter w = new StringWriter();
        e.printStackTrace(new PrintWriter(w));
        StringBuilder out = new StringBuilder();
        boolean on = false;
        for (String line : w.toString().split("\\R")) {
            if (line.contains("Error has been observed") || line.contains("Assembly trace") || line.contains("Suppressed")) on = true;
            if (on && !line.isBlank()) out.append("      ").append(line.strip()).append('\n');
            if (line.contains("Original Stack Trace")) break;
        }
        return out.length() == 0 ? "      (подавленного исключения с трассой сборки нет)\n" : out.toString();
    }

    static Mono<Integer> chain(int kind) {
        Mono<String> m = Mono.just("12,50");
        Mono<Integer> r = switch (kind) {
            case 0 -> m.map(DebugLab::parse);
            case 1 -> m.map(DebugLab::parse).checkpoint();
            case 2 -> m.map(DebugLab::parse).checkpoint("разбор суммы платежа");
            default -> m.map(DebugLab::parse).checkpoint("разбор суммы платежа", true);
        };
        return r.subscribeOn(Schedulers.parallel());
    }

    static void checkpoints() {
        String[] names = {"без checkpoint", "checkpoint()", "checkpoint(описание)", "checkpoint(описание, true)"};
        for (int k = 0; k < 4; k++) {
            try { chain(k).block(); } catch (Exception e) {
                System.out.println("   " + names[k] + ":");
                System.out.print(suppressed(e));
            }
        }
        System.out.println("== 9.2. цена сборки: 1 000 000 цепочек Mono.just().map().checkpoint(...), лучшая из 5 серий, нс на цепочку");
        for (int k = 0; k < 4; k++) {
            long best = Long.MAX_VALUE;
            for (int r = 0; r < 5; r++) {
                long t0 = System.nanoTime(); Object sink = null;
                for (int i = 0; i < 1_000_000; i++) {
                    Mono<String> m = Mono.just("1");
                    sink = switch (k) {
                        case 0 -> m.map(String::length);
                        case 1 -> m.map(String::length).checkpoint();
                        case 2 -> m.map(String::length).checkpoint("метка");
                        default -> m.map(String::length).checkpoint("метка", true);
                    };
                }
                best = Math.min(best, System.nanoTime() - t0);
                if (sink == null) System.out.print("");
            }
            System.out.printf("   %-28s %6.0f нс%n", names[k], best / 1_000_000.0);
        }
    }

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "checkpoint";
        System.out.println("== 9. режим " + mode + ", JDK " + Runtime.version());
        switch (mode) {
            case "checkpoint" -> checkpoints();
            case "hook" -> {
                Hooks.onOperatorDebug();
                try { chain(0).block(); } catch (Exception e) { System.out.print(suppressed(e)); }
            }
            case "blockhound" -> {
                try {
                    BlockHound.install();
                    System.out.println("   BlockHound установлен");
                } catch (Throwable e) {
                    System.out.println("   установка не удалась: " + e.getClass().getName() + ": " + e.getMessage().lines().findFirst().orElse(""));
                    return;
                }
                try {
                    Mono.fromCallable(() -> { Thread.sleep(10); return 1; }).subscribeOn(Schedulers.parallel()).block();
                    System.out.println("   sleep на parallel(): ошибки нет");
                } catch (Throwable e) { System.out.println("   sleep на parallel(): " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
                try {
                    Mono.fromCallable(() -> { Thread.sleep(10); return 1; }).subscribeOn(Schedulers.boundedElastic()).block();
                    System.out.println("   sleep на boundedElastic(): ошибки нет");
                } catch (Throwable e) { System.out.println("   sleep на boundedElastic(): " + e.getClass().getSimpleName()); }
                var server = HttpServer.create().port(0).handle((req, res) -> res.sendString(
                        Mono.fromCallable(() -> { Thread.sleep(10); return "ok"; }).onErrorResume(t -> Mono.just("ошибка: " + t.getClass().getSimpleName() + ": " + t.getMessage())))).bindNow();
                String body = HttpClient.create().get().uri("http://127.0.0.1:" + server.port() + "/").responseContent().aggregate().asString()
                        .block(Duration.ofSeconds(5));
                System.out.println("   sleep в обработчике на потоке цикла событий Netty: " + body);
                server.disposeNow();
            }
            case "metrics" -> {
                SimpleMeterRegistry registry = new SimpleMeterRegistry();
                Flux.range(1, 5).name("payments.pipeline").tap(Micrometer.metrics(registry)).blockLast();
                Mono.error(new IllegalStateException("отказ")).name("payments.pipeline").tap(Micrometer.metrics(registry)).onErrorResume(e -> Mono.empty()).block();
                for (Meter m : registry.getMeters())
                    System.out.println("   " + m.getId().getName() + " " + m.getId().getTags());
            }
            default -> System.out.println("неизвестный режим");
        }
    }
}
