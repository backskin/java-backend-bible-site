package dev.team.dbg;

import java.time.Duration;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.http.server.HttpServer;
import reactor.netty.resources.ConnectionProvider;

/**
 * Разд. 13.3 гл. 11: спасает ли maxLifeTime пул, если соединения утекают (тело ответа не прочитано и не освобождено).
 * Пул на 2 соединения, maxLifeTime 1 с, pendingAcquireTimeout 2 с. Две «утечки», пауза 3 с, третий запрос.
 */
public final class LeakLab {
    public static void main(String[] a) throws Exception {
        var server = HttpServer.create().port(0).route(r -> r
                .get("/verify", (req, res) -> res.sendString(Mono.just("отказ: подпись не прошла проверку")))
                .get("/hang", (req, res) -> res.sendString(Mono.just("поздно").delayElement(Duration.ofSeconds(10))))).bindNow();
        ConnectionProvider pool = ConnectionProvider.builder("verify").maxConnections(2)
                .maxLifeTime(Duration.ofSeconds(1)).pendingAcquireTimeout(Duration.ofSeconds(2)).build();
        HttpClient client = HttpClient.create(pool).baseUrl("http://127.0.0.1:" + server.port());

        for (int i = 1; i <= 2; i++) {   // утечка: берём статус, тело не читаем и соединение не освобождаем
            int code = client.get().uri("/verify").responseConnection((res, conn) -> Mono.just(res.status().code())).blockFirst();
            System.out.println("   утечка " + i + ": статус " + code + ", тело не прочитано");
        }
        System.out.println("   пауза 3 с — втрое больше maxLifeTime");
        Thread.sleep(3000);
        try {
            String body = client.get().uri("/verify").responseContent().aggregate().asString().block(Duration.ofSeconds(5));
            System.out.println("   третий запрос прошёл: " + body);
        } catch (Exception e) {
            System.out.println("   третий запрос: " + e.getClass().getName() + ": " + String.valueOf(e.getMessage()).lines().findFirst().orElse(""));
        }
        System.out.println("-- занятые соединения: два запроса к /hang (сервер молчит 10 с), maxLifeTime 1 с");
        ConnectionProvider pool2 = ConnectionProvider.builder("verify2").maxConnections(2)
                .maxLifeTime(Duration.ofSeconds(1)).pendingAcquireTimeout(Duration.ofSeconds(2)).build();
        HttpClient c2 = HttpClient.create(pool2).baseUrl("http://127.0.0.1:" + server.port());
        for (int i = 0; i < 2; i++) c2.get().uri("/hang").responseContent().aggregate().asString().subscribe();
        Thread.sleep(3000);
        long t0 = System.nanoTime();
        try {
            String body = c2.get().uri("/verify").responseContent().aggregate().asString().block(Duration.ofSeconds(5));
            System.out.println("   третий запрос прошёл: " + body);
        } catch (Exception e) {
            System.out.printf("   третий запрос через %d мс: %s: %s%n", (System.nanoTime() - t0) / 1_000_000, e.getClass().getName(), String.valueOf(e.getMessage()).lines().findFirst().orElse(""));
        }
        pool2.disposeLater().block();
        pool.disposeLater().block();
        server.disposeNow();
        System.exit(0);
    }
}
