package dev.team.dbg;

import java.time.Duration;
import reactor.blockhound.BlockHound;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.http.server.HttpServer;

/**
 * Разд. 9.6 гл. 11: BlockHound и цикл событий Reactor Netty. Аргумент: plain | hound-nosleep | hound-sleep.
 * Сервер в обработчике спит 10 мс (или нет), клиент ждёт ответ 3 с.
 */
public final class BhNetty {
    public static void main(String[] a) {
        String mode = a.length > 0 ? a[0] : "hound-sleep";
        if (mode.startsWith("hound")) BlockHound.install();
        boolean sleep = !mode.endsWith("nosleep");
        var server = HttpServer.create().port(0).handle((req, res) -> {
            String th = Thread.currentThread().getName();
            return res.sendString(Mono.fromCallable(() -> { if (sleep) Thread.sleep(10); return "ok"; })
                    .doOnError(t -> System.out.println("   на сервере, поток " + th + ": " + t.getClass().getName() + ": " + t.getMessage()))
                    .onErrorResume(t -> Mono.just("ошибка " + t.getClass().getSimpleName())));
        }).bindNow();
        try {
            String body = HttpClient.create().get().uri("http://127.0.0.1:" + server.port() + "/")
                    .responseContent().aggregate().asString().block(Duration.ofSeconds(3));
            System.out.println("   клиент получил: " + body);
        } catch (Exception e) {
            System.out.println("   клиент: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        server.disposeNow();
        System.exit(0);
    }
}
