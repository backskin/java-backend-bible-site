package dev.team.dbg;

import reactor.netty.http.HttpResources;
import reactor.netty.resources.ConnectionProvider;

/** Разд. 4.5 и 13.2 гл. 11: значения пула соединений Reactor Netty по умолчанию на этой машине. */
public final class PoolDefaults {
    public static void main(String[] a) {
        System.out.println("== 13.2. ядер JVM: " + Runtime.getRuntime().availableProcessors());
        System.out.println("   ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS = " + ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS);
        System.out.println("   ConnectionProvider.DEFAULT_POOL_ACQUIRE_TIMEOUT = " + ConnectionProvider.DEFAULT_POOL_ACQUIRE_TIMEOUT + " мс");
        System.out.println("   ConnectionProvider.DEFAULT_POOL_MAX_IDLE_TIME = " + ConnectionProvider.DEFAULT_POOL_MAX_IDLE_TIME);
        System.out.println("   ConnectionProvider.DEFAULT_POOL_MAX_LIFE_TIME = " + ConnectionProvider.DEFAULT_POOL_MAX_LIFE_TIME);
        System.out.println("   ConnectionProvider.DEFAULT_POOL_LEASING_STRATEGY = " + ConnectionProvider.DEFAULT_POOL_LEASING_STRATEGY);
        ConnectionProvider global = HttpResources.get();
        System.out.println("   глобальный HttpResources: " + global.getClass().getSimpleName() + ", maxConnections() = " + global.maxConnections());
        ConnectionProvider own = ConnectionProvider.create("партнёр");
        System.out.println("   ConnectionProvider.create(name): maxConnections() = " + own.maxConnections());
        System.out.println("   ConnectionProvider.builder(name).build(): maxConnections() = " + ConnectionProvider.builder("партнёр-2").build().maxConnections());
    }
}
