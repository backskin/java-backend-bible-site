import reactor.blockhound.BlockHound;

/** Разд. 9.6 гл. 11: полное сообщение BlockHound, если JVM запущена без -XX:+AllowRedefinitionToAddDeleteMethods. */
public class BhCause {
    public static void main(String[] a) {
        try { BlockHound.install(); } catch (Throwable e) { e.printStackTrace(System.out); }
    }
}
