# Отладка Reactor: checkpoint, hook, метрики, BlockHound, утечка соединений WebClient, значения по умолчанию пула Reactor Netty

Стенд к главе 11, разделы 9 и 13.2. `DebugLab` (режимы `checkpoint`, `hook`, `metrics`, `blockhound`) показывает трассу сборки при ошибке и во что обходится каждый способ ее получить (лучшая из пяти серий по миллиону цепочек); `BhNetty` и `BhCause` - BlockHound на потоке Reactor Netty и причина, по которой на JDK 21 он требует `-XX:+AllowRedefinitionToAddDeleteMethods`; `LeakLab` - два запроса, которые не читают тело ответа, исчерпывают пул из двух соединений, и третий ждет `pendingAcquireTimeout`; `PoolDefaults` печатает константы `ConnectionProvider` и глобальный `HttpResources`. Выводы автора - `s11-debug2.txt`, `s11-blockhound.txt`, `s11-leak.txt`, `s11-pool.txt`.

## Что нужно

- JDK 21 (для сравнения 25), Maven.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" dev.team.dbg.DebugLab checkpoint
```

BlockHound на JDK 21: добавить `-XX:+AllowRedefinitionToAddDeleteMethods`. В IDEA на каждый класс есть конфигурация; аргумент режима задается в ней.

## Что должно получиться

Четыре варианта трассы (`checkpoint()`, с описанием, с описанием и стеком, `Hooks.onOperatorDebug()`) и стоимость каждого на миллионе цепочек - в `s11-debug2.txt`; оба запуска BlockHound, с флагом и без, - в `s11-blockhound.txt`. В `LeakLab` третий запрос после `maxLifeTime` проходит, а при двух занятых соединениях получает `PoolAcquireTimeoutException` через 2 с.
