# Типичные ошибки Spring Boot: два класса приложения, сканирование, ленивый старт, java -cp на исполняемом jar, различия Boot 3.4–4.1

Стенд к главе 10, раздел "Типичные ошибки". Несколько приложений на Spring Boot 4.1.1 в одном проекте, каждое закрывает свои пункты списка: `PitfallsLab` на `ApplicationContextRunner` (пункты 3, 4, 10, 20–23: бин с ошибкой конфигурации при обычном и ленивом старте, условия, `@Value` без значения), `ScanApps` со стартером `ru.tundra.pf.starter` (2, 17: что видит сканирование из пакета приложения и из корня), `MiscApp` (7, 25, 27–29: размер `BufferingApplicationStartup` и прочее), тест с двумя классами `@SpringBootConfiguration` (1) и библиотека `legacy/`, собранная с `-parameters` и без (19), запуск исполняемого jar через `java -cp` (12), модуль `boot34/` с `VersionsLab` на Boot 3.4.13, 3.5.16 и 4.1.1 (21, 22). Выводы автора - `s10-pitfalls-*.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" ru.tundra.pf.PitfallsLab
```

Тест с двумя конфигурациями: `mvn -q test`. Модуль `boot34`: в его `pom.xml` версия родителя - заполнитель `__VER__`, его подставляют перед сборкой (`sed 's/__VER__/3.4.13/' boot34/pom.xml > boot34/pom-3.4.xml && mvn -q -f boot34/pom-3.4.xml compile exec:java -Dexec.mainClass=ru.tundra.pf34.VersionsLab`), и так для 3.5.16 и 4.1.1. В IDEA есть конфигурации `PitfallsLab`, `ScanApps`, `MiscApp`, `mvn test`, `boot34: VersionsLab`, `legacy: PartnerGatewayApp`.

## Что должно получиться

`Found multiple @SpringBootConfiguration annotated classes` для теста в подпакете двух приложений; `Could not find or load main class` при `java -cp app.jar <Start-Class>`; на Boot 3.4 `@ConditionalOnProperty` без `havingValue` принимает `true`, как и на 4.1.
