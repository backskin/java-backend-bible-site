package ru.tundra.pf.scan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import ru.tundra.pf.starter.LimitsStarterClient;
import ru.tundra.pf.starter.internal.LimitsCacheWarmer;

import java.util.List;

/** Пункты 2 и 17: приложение со своим клиентом лимитов и разными способами сканирования. */
public final class ScanApps {

    /** Обычный @SpringBootApplication, сканирует ru.tundra.pf (там же лежит пакет стартера). */
    @SpringBootApplication(scanBasePackages = "ru.tundra.pf.scan.app")
    public static class DefaultScanApp { }

    /** Свой @ComponentScan, который захватывает и пакет стартера, без фильтров Boot. */
    @SpringBootApplication
    @ComponentScan({"ru.tundra.pf.scan.app", "ru.tundra.pf.starter"})
    public static class WideScanApp { }

    /** scanBasePackages тоже захватывает пакет стартера, но фильтры Boot на месте. */
    @SpringBootApplication(scanBasePackages = {"ru.tundra.pf.scan.app", "ru.tundra.pf.starter"})
    public static class WideBootScanApp { }

    @Configuration(proxyBeanMethods = false)
    public static class AppClient {
        @Bean LimitsStarterClient appLimitsClient() { return new LimitsStarterClient("свой клиент приложения"); }
    }

    public static void main(String[] a) {
        run("@SpringBootApplication, сканирование только пакета приложения", DefaultScanApp.class);
        run("@SpringBootApplication + @ComponentScan, захватывающий пакет стартера", WideScanApp.class);
        run("@SpringBootApplication(scanBasePackages) с пакетом стартера, фильтры Boot на месте", WideBootScanApp.class);
    }

    static void run(String label, Class<?> main) {
        SpringApplication app = new SpringApplication(main, AppClient.class);
        ConfigurableApplicationContext ctx = app.run("--server.port=0", "--spring.main.banner-mode=off", "--logging.level.root=warn", "--spring.main.web-application-type=none");
        System.out.println("== " + label);
        ctx.getBeansOfType(LimitsStarterClient.class).forEach((n, c) -> System.out.println("   " + n + " = " + c.origin()));
        System.out.println("   LimitsCacheWarmer из внутреннего пакета стартера: " + ctx.getBeanNamesForType(LimitsCacheWarmer.class).length);
        System.out.println("   LimitsStarterAutoConfiguration зарегистрирована как: " + List.of(ctx.getBeanNamesForType(ru.tundra.pf.starter.LimitsStarterAutoConfiguration.class)));
        ctx.close();
    }
}
