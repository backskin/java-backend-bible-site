package ru.tundra.pf;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import java.util.List;

/** Ведущий опыта разд. 12: грабли, которые проверяются ApplicationContextRunner. */
public class PitfallsLab {

    record LimitsClient(String origin) { }

    // ---- 3. два определения бина с одним именем
    @Configuration(proxyBeanMethods = false)
    static class LimitsConfigA { @Bean LimitsClient limitsClient() { return new LimitsClient("конфигурация A"); } }
    @Configuration(proxyBeanMethods = false)
    static class LimitsConfigB { @Bean LimitsClient limitsClient() { return new LimitsClient("конфигурация B"); } }

    // ---- 4. класс свойств без @EnableConfigurationProperties
    @ConfigurationProperties("tundra.limits")
    public record LimitsProperties(String baseUrl) { }
    @Configuration(proxyBeanMethods = false)
    static class StarterWithoutEnable {
        @Bean LimitsClient limitsClient(LimitsProperties p) { return new LimitsClient(p.baseUrl()); }
    }
    @Configuration(proxyBeanMethods = false)
    @EnableConfigurationProperties(LimitsProperties.class)
    static class StarterWithEnable {
        @Bean LimitsClient limitsClient(LimitsProperties p) { return new LimitsClient(p.baseUrl()); }
    }

    // ---- 10. @ConditionalOnMissingBean в обычной конфигурации: порядок регистрации решает
    @Configuration(proxyBeanMethods = false)
    static class AppClientConfig { @Bean LimitsClient appLimitsClient() { return new LimitsClient("свой бин приложения"); } }
    @Configuration(proxyBeanMethods = false)
    static class FallbackClientConfig {
        @Bean @ConditionalOnMissingBean LimitsClient fallbackLimitsClient() { return new LimitsClient("запасной из обычной конфигурации"); }
    }

    // ---- 21. логические значения
    @Configuration(proxyBeanMethods = false)
    static class FeatureByProperty { @Bean @ConditionalOnProperty(name = "tundra.antifraud.enabled", havingValue = "true") String antifraudA() { return "on"; } }
    @Configuration(proxyBeanMethods = false)
    static class FeatureByBoolean { @Bean @ConditionalOnBooleanProperty("tundra.antifraud.enabled") String antifraudB() { return "on"; } }
    @ConfigurationProperties("tundra.antifraud")
    public record AntifraudProperties(boolean enabled) { }
    @Configuration(proxyBeanMethods = false)
    @EnableConfigurationProperties(AntifraudProperties.class)
    static class AntifraudBinding { }

    // ---- 22. @Qualifier("taskExecutor")
    @Component
    static class Notifier {
        Notifier(@Qualifier("taskExecutor") TaskExecutor executor) { }
    }
    @Configuration(proxyBeanMethods = false)
    @Import(Notifier.class)
    static class NotifierConfig { }

    // ---- 23. один класс свойств и через @Component, и через @EnableConfigurationProperties
    @Component
    @ConfigurationProperties("tundra.fees")
    public static class FeeProperties {
        private int min = 30;
        public int getMin() { return min; }
        public void setMin(int min) { this.min = min; }
    }
    @Configuration(proxyBeanMethods = false)
    @Import(FeeProperties.class)
    @EnableConfigurationProperties(FeeProperties.class)
    static class FeeConfig { }

    /** Клиент реестра, у которого в конфигурации не задан адрес (пункт 20). */
    static class RegistryClient {
        RegistryClient(org.springframework.core.env.Environment env) {
            if (env.getProperty("tundra.registry.url") == null) throw new IllegalStateException("не задан tundra.registry.url");
        }
    }

    @Configuration(proxyBeanMethods = false)
    static class RegistryConfig {
        @Bean RegistryClient registryClient(org.springframework.core.env.Environment env) { return new RegistryClient(env); }
    }

    public static void main(String[] a) {
        System.out.println("== 20. бин с ошибкой конфигурации, обычный и ленивый старт");
        new ApplicationContextRunner().withUserConfiguration(RegistryConfig.class)
                .run(c -> System.out.println("   обычный старт: " + (c.getStartupFailure() != null ? "СБОЙ НА СТАРТЕ " + root(c.getStartupFailure()) : "поднялся")));
        new ApplicationContextRunner().withInitializer(ctx -> ctx.addBeanFactoryPostProcessor(new org.springframework.boot.LazyInitializationBeanFactoryPostProcessor()))
                .withUserConfiguration(RegistryConfig.class)
                .run(c -> {
                    System.out.println("   ленивый старт: " + (c.getStartupFailure() != null ? "СБОЙ НА СТАРТЕ " + root(c.getStartupFailure()) : "поднялся"));
                    try { c.getBean(RegistryClient.class); System.out.println("   первое обращение: бин создан"); }
                    catch (Exception e) { System.out.println("   первое обращение к бину: " + root(e)); }
                });

        System.out.println("== 3. два @Bean limitsClient в разных конфигурациях");
        show(new ApplicationContextRunner().withUserConfiguration(LimitsConfigA.class, LimitsConfigB.class), "без флага");
        show(new ApplicationContextRunner().withAllowBeanDefinitionOverriding(true).withUserConfiguration(LimitsConfigA.class, LimitsConfigB.class), "allow-bean-definition-overriding=true, A затем B");
        show(new ApplicationContextRunner().withAllowBeanDefinitionOverriding(true).withUserConfiguration(LimitsConfigB.class, LimitsConfigA.class), "allow-bean-definition-overriding=true, B затем A");

        System.out.println("== 4. класс свойств в стартере");
        show(new ApplicationContextRunner().withUserConfiguration(StarterWithoutEnable.class).withPropertyValues("tundra.limits.base-url=https://limits.test"), "без @EnableConfigurationProperties");
        show(new ApplicationContextRunner().withUserConfiguration(StarterWithEnable.class).withPropertyValues("tundra.limits.base-url=https://limits.test"), "с @EnableConfigurationProperties");

        System.out.println("== 10. @ConditionalOnMissingBean в обычной конфигурации");
        show(new ApplicationContextRunner().withUserConfiguration(AppClientConfig.class, FallbackClientConfig.class), "свой бин регистрируется первым");
        show(new ApplicationContextRunner().withUserConfiguration(FallbackClientConfig.class, AppClientConfig.class), "свой бин регистрируется вторым");

        System.out.println("== 21. логические значения tundra.antifraud.enabled");
        for (String v : List.of("true", "yes", "on", "1", "TRUE")) {
            new ApplicationContextRunner().withUserConfiguration(FeatureByProperty.class, FeatureByBoolean.class, AntifraudBinding.class)
                    .withPropertyValues("tundra.antifraud.enabled=" + v)
                    .run(c -> System.out.println("   " + v + ": @ConditionalOnProperty(havingValue=\"true\")=" + c.containsBean("antifraudA")
                            + ", @ConditionalOnBooleanProperty=" + c.containsBean("antifraudB")
                            + (c.getStartupFailure() != null ? ", СБОЙ " + root(c.getStartupFailure())
                               : ", привязка boolean=" + c.getBean(AntifraudProperties.class).enabled())));
        }

        System.out.println("== 22. @Qualifier(\"taskExecutor\") при автоконфигурации исполнителя");
        new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(TaskExecutionAutoConfiguration.class)).withUserConfiguration(NotifierConfig.class)
                .run(c -> System.out.println("   " + (c.getStartupFailure() != null ? "СБОЙ " + root(c.getStartupFailure())
                        : "контекст поднялся; бины TaskExecutor: " + List.of(c.getBeanNamesForType(TaskExecutor.class)) + ", псевдонимы applicationTaskExecutor: "
                          + List.of(c.getAliases("applicationTaskExecutor")))));

        System.out.println("== 23. FeeProperties и под @Component, и в @EnableConfigurationProperties");
        new ApplicationContextRunner().withUserConfiguration(FeeConfig.class).withPropertyValues("tundra.fees.min=50")
                .run(c -> System.out.println("   " + (c.getStartupFailure() != null ? "СБОЙ " + root(c.getStartupFailure())
                        : "бины FeeProperties: " + List.of(c.getBeanNamesForType(FeeProperties.class)))));
    }

    static void show(ApplicationContextRunner r, String label) {
        r.run(c -> System.out.println("   " + label + ": " + (c.getStartupFailure() != null ? "СБОЙ " + root(c.getStartupFailure())
                : c.getBeansOfType(LimitsClient.class).entrySet().stream().map(e -> e.getKey() + "=" + e.getValue().origin()).toList())));
    }

    static String root(Throwable t) {
        while (t.getCause() != null) t = t.getCause();
        return t.getClass().getSimpleName() + ": " + t.getMessage().split("\n")[0];
    }
}
