package ru.tundra.pf.starter.internal;

import org.springframework.stereotype.Component;

/** Внутренний класс стартера, который потребителю не нужен. */
@Component
public class LimitsCacheWarmer { }
