package ru.tundra.pf.starter;

/** Клиент сервиса лимитов из стартера. */
public record LimitsStarterClient(String origin) { }
