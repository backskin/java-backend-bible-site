package ru.tundra.pf.starter;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

/** Автоконфигурация стартера клиента лимитов; заодно сканирует свой внутренний пакет (пункт 17). */
@AutoConfiguration
@ComponentScan("ru.tundra.pf.starter.internal")
public class LimitsStarterAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean
    public LimitsStarterClient limitsStarterClient() { return new LimitsStarterClient("клиент из стартера"); }
}
