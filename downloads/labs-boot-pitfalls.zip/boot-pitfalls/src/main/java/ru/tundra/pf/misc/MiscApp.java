package ru.tundra.pf.misc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.metrics.buffering.BufferingApplicationStartup;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

/** Пункты 7, 25, 27, 28, 29: одно приложение, сценарии включаются свойствами. */
@SpringBootApplication
public class MiscApp {

    /** Индикатор бюро кредитных историй, который ждёт ответа 3 с (пункт 7). */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnProperty("lab.slow-health")
    static class SlowHealth {
        @Bean HealthIndicator bureauHealthIndicator() {
            return () -> { try { Thread.sleep(3000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } return Health.up().build(); };
        }
    }

    /** Валидатор свойств, объявленный нестатическим методом в конфигурации с другими бинами (пункт 25). */
    @Configuration
    @ConditionalOnProperty("lab.validator")
    static class ValidatorConfig {
        @Bean Validator configurationPropertiesValidator() { return new LocalValidatorFactoryBean(); }
        @Bean String reportName() { return "реестр"; }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(MiscApp.class);
        int buffer = Integer.getInteger("lab.buffer", 0);
        BufferingApplicationStartup startup = buffer > 0 ? new BufferingApplicationStartup(buffer) : null;
        if (startup != null) app.setApplicationStartup(startup);
        var ctx = app.run(args);
        if (startup != null) {
            var events = startup.getBufferedTimeline().getEvents();
            System.out.println("   буфер " + buffer + ": шагов в буфере " + events.size() + "; последний шаг: " + events.get(events.size() - 1).getStartupStep().getName());
        }
        if (Boolean.getBoolean("lab.exit")) ctx.close();
    }
}
