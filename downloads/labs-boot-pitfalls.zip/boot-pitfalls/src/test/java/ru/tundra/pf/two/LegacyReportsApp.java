package ru.tundra.pf.two;

/** Второе «приложение», попавшее в то же дерево пакетов из подключённого модуля. */
@org.springframework.boot.SpringBootConfiguration
public class LegacyReportsApp { }
