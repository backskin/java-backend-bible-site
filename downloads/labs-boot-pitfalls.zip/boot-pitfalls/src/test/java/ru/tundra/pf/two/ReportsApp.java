package ru.tundra.pf.two;

/** Приложение отчётности. */
@org.springframework.boot.autoconfigure.SpringBootApplication
public class ReportsApp { }
