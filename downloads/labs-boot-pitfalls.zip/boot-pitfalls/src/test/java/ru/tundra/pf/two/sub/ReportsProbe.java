package ru.tundra.pf.two.sub;

@org.springframework.boot.test.context.SpringBootTest(webEnvironment = org.springframework.boot.test.context.SpringBootTest.WebEnvironment.NONE)
class ReportsProbe {
    @org.junit.jupiter.api.Test void contextLoads() { }
}
