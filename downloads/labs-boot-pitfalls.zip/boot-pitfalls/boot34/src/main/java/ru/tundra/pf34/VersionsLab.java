package ru.tundra.pf34;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringBootVersion;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;

import java.util.List;

/** Пункты 21 и 22 раздела 12 на версии Boot из pom. */
public class VersionsLab {
    @Configuration(proxyBeanMethods = false)
    static class Feature { @Bean @ConditionalOnProperty("tundra.antifraud.enabled") String antifraud() { return "on"; } }

    @Configuration(proxyBeanMethods = false)
    static class Notifier { @Bean String notifier(@Qualifier("taskExecutor") TaskExecutor e) { return "ok"; } }

    public static void main(String[] a) {
        System.out.println("== Boot " + SpringBootVersion.getVersion());
        for (String v : List.of("true", "yes", "1", "false", "no")) {
            new ApplicationContextRunner().withUserConfiguration(Feature.class).withPropertyValues("tundra.antifraud.enabled=" + v)
                    .run(c -> System.out.println("   @ConditionalOnProperty(\"tundra.antifraud.enabled\") без havingValue, значение " + v + ": "
                            + (c.getStartupFailure() != null ? "СБОЙ" : c.containsBean("antifraud"))));
        }
        for (String v : List.of("true", "yes", "1", "on")) {
            new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration.class))
                    .withPropertyValues("spring.jmx.enabled=" + v)
                    .run(c -> System.out.println("   свойство Boot spring.jmx.enabled=" + v + ": " + (c.getStartupFailure() != null ? "СБОЙ " + c.getStartupFailure().getClass().getSimpleName()
                            : "MBeanServer " + (c.getBeanNamesForType(javax.management.MBeanServer.class).length > 0 ? "создан" : "не создан"))));
        }
        new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(TaskExecutionAutoConfiguration.class)).withUserConfiguration(Notifier.class)
                .run(c -> System.out.println("   @Qualifier(\"taskExecutor\"): " + (c.getStartupFailure() != null ? "СБОЙ NoSuchBeanDefinitionException"
                        : "найден; псевдонимы applicationTaskExecutor " + List.of(c.getAliases("applicationTaskExecutor")))));
    }
}
