package ru.tundra.legacy;

import org.springframework.boot.context.properties.ConfigurationProperties;

/** Класс свойств из библиотеки партнёрского шлюза: обычный класс с одним конструктором. */
@ConfigurationProperties("tundra.partner")
public class PartnerProperties {
    private final String baseUrl;
    private final int timeoutSeconds;

    public PartnerProperties(String baseUrl, int timeoutSeconds) {
        this.baseUrl = baseUrl;
        this.timeoutSeconds = timeoutSeconds;
    }

    public String getBaseUrl() { return baseUrl; }
    public int getTimeoutSeconds() { return timeoutSeconds; }
}
