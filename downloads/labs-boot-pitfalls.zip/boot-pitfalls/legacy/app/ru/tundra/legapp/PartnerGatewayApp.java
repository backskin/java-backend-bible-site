package ru.tundra.legapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import ru.tundra.legacy.PartnerProperties;

@SpringBootApplication
@EnableConfigurationProperties(PartnerProperties.class)
public class PartnerGatewayApp {
    public static void main(String[] args) {
        var ctx = SpringApplication.run(PartnerGatewayApp.class, args);
        PartnerProperties p = ctx.getBean(PartnerProperties.class);
        System.out.println("   привязка: baseUrl=" + p.getBaseUrl() + ", timeoutSeconds=" + p.getTimeoutSeconds());
        ctx.close();
    }
}
