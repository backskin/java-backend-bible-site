package obs;

import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationHandler;
import io.micrometer.observation.ObservationRegistry;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.audit.InMemoryAuditEventRepository;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.security.authorization.AuthorizationEventPublisher;
import org.springframework.security.authorization.SpringAuthorizationEventPublisher;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Разд. 13 гл. 13: какие события безопасности публикуются в Spring Security 7.1 при входе через HTTP Basic и через форму,
 * при отказе и разрешении доступа (без бина AuthorizationEventPublisher, со SpringAuthorizationEventPublisher,
 * с ним же и предикатом «публиковать всё»), что попадает в аудит Actuator и какие наблюдения Micrometer создаются на запрос.
 * Аргумент: none | publisher | publisher-all | audit | no-observations.
 */
@SpringBootApplication
public class App {

    static final Map<String, Integer> EVENTS = new ConcurrentHashMap<>();
    static final Map<String, Integer> OBSERVATIONS = new ConcurrentHashMap<>();
    static String mode = "none";

    @RestController
    static class Api {
        @GetMapping("/api/statement") String statement() { return "выписка"; }
        @GetMapping("/api/admin/limits") String limits() { return "лимиты"; }
    }

    @Bean InMemoryUserDetailsManager users() {
        return new InMemoryUserDetailsManager(
                User.withUsername("alice").password("{noop}pw").roles("USER").build(),
                User.withUsername("admin").password("{noop}pw").roles("ADMIN").build());
    }

    @Bean SecurityFilterChain chain(HttpSecurity http) throws Exception {
        return http.authorizeHttpRequests(a -> a.requestMatchers("/api/admin/**").hasRole("ADMIN").anyRequest().authenticated())
                .httpBasic(Customizer.withDefaults()).formLogin(Customizer.withDefaults()).csrf(c -> c.disable()).build();
    }

    @Bean @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty(name = "lab.publisher", havingValue = "on")
    AuthorizationEventPublisher authorizationEventPublisher(ApplicationEventPublisher p) {
        var pub = new SpringAuthorizationEventPublisher(p);
        if (mode.equals("publisher-all")) pub.setShouldPublishResult(r -> true);
        return pub;
    }

    @Bean @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty(name = "lab.audit", havingValue = "on")
    InMemoryAuditEventRepository auditEventRepository() { return new InMemoryAuditEventRepository(); }

    @EventListener void any(org.springframework.context.ApplicationEvent e) {
        String pkg = e.getClass().getPackageName();
        if (pkg.startsWith("org.springframework.security") || pkg.startsWith("org.springframework.boot.actuate.audit")) {
            String name = e.getClass().getSimpleName();
            if (e instanceof org.springframework.security.authorization.event.AuthorizationEvent ae)
                name += "(granted=" + ae.getAuthorizationResult().isGranted() + ")";
            EVENTS.merge(name, 1, Integer::sum);
        }
    }

    @Bean ObservationHandler<Observation.Context> recorder() {
        return new ObservationHandler<>() {
            @Override public boolean supportsContext(Observation.Context c) { return true; }
            @Override public void onStart(Observation.Context c) {
                if (c.getName().startsWith("spring.security")) OBSERVATIONS.merge(c.getName(), 1, Integer::sum);
            }
        };
    }

    public static void main(String[] args) throws Exception {
        mode = args.length > 0 ? args[0] : "none";
        var props = new HashMap<String, Object>(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off",
                "management.endpoints.web.exposure.include", "auditevents"));
        if (mode.startsWith("publisher")) props.put("lab.publisher", "on");
        if (mode.equals("audit")) props.put("lab.audit", "on");
        if (mode.equals("actuator-all")) props.put("management.endpoints.web.exposure.include", "*");
        if (mode.equals("no-observations")) props.put("management.observations.enable.spring.security", "false");
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(props);
        try (ConfigurableApplicationContext ctx = app.run()) {
            String base = "http://127.0.0.1:" + ctx.getEnvironment().getProperty("local.server.port");
            HttpClient http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).build();
            System.out.println("режим " + mode + "; бин AuthorizationEventPublisher: " + ctx.getBeanNamesForType(AuthorizationEventPublisher.class).length
                    + ", бин AuditEventRepository: " + ctx.getBeanNamesForType(org.springframework.boot.actuate.audit.AuditEventRepository.class).length);
            if (mode.equals("actuator-all")) {   // 15.5: что видно при include=* (запросы с учётными данными admin)
                String auth = "Basic " + Base64.getEncoder().encodeToString("admin:pw".getBytes());
                for (String ep : List.of("/actuator/env", "/actuator/heapdump", "/actuator/threaddump", "/actuator/configprops", "/actuator/beans", "/actuator/shutdown")) {
                    var r = http.send(HttpRequest.newBuilder(URI.create(base + ep)).header("Authorization", auth).build(), HttpResponse.BodyHandlers.ofString());
                    String body = r.body();
                    String note = ep.equals("/actuator/env") ? "; значение spring.datasource-подобных свойств: " + (body.contains("\"******\"") ? "маскировано ******" : "открыто") : "";
                    System.out.printf("   GET %-22s → HTTP %d, %d байт%s%n", ep, r.statusCode(), body.length(), note);
                }
                return;
            }
            EVENTS.clear(); OBSERVATIONS.clear();
            step(http, base, "alice Basic GET /api/statement", "/api/statement", "alice:pw");
            step(http, base, "alice Basic GET /api/statement ещё раз", "/api/statement", "alice:pw");
            step(http, base, "alice Basic, неверный пароль", "/api/statement", "alice:wrong");
            step(http, base, "alice Basic GET /api/admin/limits (нет роли)", "/api/admin/limits", "alice:pw");
            var form = HttpRequest.newBuilder(URI.create(base + "/login")).header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString("username=admin&password=pw")).build();
            int code = http.send(form, HttpResponse.BodyHandlers.discarding()).statusCode();
            System.out.printf("%-48s → HTTP %d; события: %s%n", "admin вход через форму POST /login", code, drain(EVENTS));
            if (mode.equals("audit")) {
                var r = http.send(HttpRequest.newBuilder(URI.create(base + "/actuator/auditevents"))
                        .header("Authorization", "Basic " + Base64.getEncoder().encodeToString("admin:pw".getBytes())).build(), HttpResponse.BodyHandlers.ofString());
                var types = new TreeMap<String, Integer>();
                var m = java.util.regex.Pattern.compile("\"type\":\"([A-Z_]+)\"").matcher(r.body());
                while (m.find()) types.merge(m.group(1), 1, Integer::sum);
                System.out.println("/actuator/auditevents → HTTP " + r.statusCode() + ", типы событий: " + types);
            } else {
                var r = http.send(HttpRequest.newBuilder(URI.create(base + "/actuator/auditevents"))
                        .header("Authorization", "Basic " + Base64.getEncoder().encodeToString("admin:pw".getBytes())).build(), HttpResponse.BodyHandlers.discarding());
                System.out.println("/actuator/auditevents без бина AuditEventRepository → HTTP " + r.statusCode());
            }
            System.out.println("наблюдения spring.security.* за все запросы: " + new TreeMap<>(OBSERVATIONS));
        }
    }

    static void step(HttpClient http, String base, String title, String path, String cred) throws Exception {
        var req = HttpRequest.newBuilder(URI.create(base + path)).header("Authorization", "Basic " + Base64.getEncoder().encodeToString(cred.getBytes())).build();
        int code = http.send(req, HttpResponse.BodyHandlers.discarding()).statusCode();
        System.out.printf("%-48s → HTTP %d; события: %s%n", title, code, drain(EVENTS));
    }

    static String drain(Map<String, Integer> m) {
        String s = new TreeMap<>(m).toString(); m.clear(); return s;
    }
}
