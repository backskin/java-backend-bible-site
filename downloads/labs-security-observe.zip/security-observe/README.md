# События Spring Security, аудит Actuator и наблюдения Micrometer: какие события приходят в каждом режиме

Стенд к главе 13, раздел 13. Приложение `obs.App` (Spring Boot 4.1.1, Spring Security 7.1.1, Actuator) выполняет пять запросов (три через HTTP Basic, один с неверным паролем, вход через форму), собирает события пакета `org.springframework.security` слушателем и наблюдения своим `ObservationHandler`, и запускается в шести режимах: `none`, `publisher` (бин `AuthorizationEventPublisher`), `publisher-all` (публикует и разрешенные решения), `audit` (бин `AuditEventRepository`), `no-observations`, `actuator-all` (`management.endpoints.web.exposure.include=*`, что отдает `/actuator/env` с учетными данными). Выводы автора - `s13-observe-<режим>.txt`.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, bash.

## Запуск

```bash
bash run.sh
```

Один режим: конфигурация `App` в IDEA с аргументом режима.

## Что должно получиться

Без публикатора приходит только `AuthenticationSuccessEvent`; в `publisher-all` добавляется `AuthorizationDeniedEvent(granted=true)` на каждый разрешенный запрос; в `audit` события попадают в `AuditEventRepository`; в `actuator-all` значения свойств в `/actuator/env` замаскированы `******`.
