#!/usr/bin/env bash
# Разд. 13 гл. 13: события безопасности, аудит Actuator, наблюдения Micrometer. Вывод: s13-observe-<режим>.txt.
set -uo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt >/dev/null || exit 1
CP="$(cygpath -w "$PWD/target/classes" 2>/dev/null || echo target/classes);$(cat cp.txt)"
[ "$(uname -o 2>/dev/null)" = "Msys" ] || CP="${CP//;/:}"
for m in none publisher publisher-all audit no-observations actuator-all; do
  "$J" -Dstdout.encoding=UTF-8 -cp "$CP" obs.App $m 2>&1 | grep -v WARNING > "s13-observe-$m.txt"
  cat "s13-observe-$m.txt"
done
