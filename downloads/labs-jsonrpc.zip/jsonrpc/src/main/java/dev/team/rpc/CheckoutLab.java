package dev.team.rpc;

import com.fasterxml.jackson.databind.JsonNode;

import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/** Опыт: касса 17 магазина КорзиныПлюс считает чек, проводит его, повторяет после тайм-аута и досылает пакет чеков. */
public class CheckoutLab {
    static final Duration POS_TIMEOUT = Duration.ofMillis(100);         // касса не может ждать дольше: очередь у кассы

    public static void main(String[] args) throws Exception {
        for (boolean idempotent : new boolean[]{false, true}) {
            var loyalty = new Loyalty(); loyalty.idempotent = idempotent;
            var rpc = loyalty.register(new JsonRpc());
            var server = HttpRpc.start(8192, rpc);
            System.out.println("== проведение чека, ключ идемпотентности " + (idempotent ? "checkId" : "не проверяется"));
            String calc = "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.calculate\",\"id\":\"17-42-calc\",\"params\":{\"card\":\"7700000000001\","
                    + "\"lines\":[{\"sku\":\"MILK-3.2-930\",\"qty\":2,\"priceMinor\":8990},{\"sku\":\"BREAD-BORODINO\",\"qty\":1,\"priceMinor\":6490},"
                    + "{\"sku\":\"COFFEE-250\",\"qty\":1,\"priceMinor\":54990}]}}";
            System.out.println("   расчёт: " + HttpRpc.call(8192, calc, POS_TIMEOUT));
            loyalty.slowNext.set(1);                                    // база тормозит на первом проведении
            String commit = "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.commit\",\"id\":\"%s\",\"params\":{\"card\":\"7700000000001\","
                    + "\"checkId\":\"17-000042-20261026\",\"totalMinor\":159460,\"pointsToSpend\":300}}";
            try { System.out.println("   проведение: " + HttpRpc.call(8192, commit.formatted("17-42-commit-1"), POS_TIMEOUT)); }
            catch (HttpTimeoutException e) { System.out.println("   проведение: тайм-аут кассы 100 мс, касса повторяет запрос с новым id"); }
            Thread.sleep(300);                                          // первое проведение тем временем завершилось на сервере
            System.out.println("   повтор:     " + HttpRpc.call(8192, commit.formatted("17-42-commit-2"), POS_TIMEOUT));
            System.out.println("   баланс карты после чека: " + loyalty.balance.get("7700000000001") + " (было 500, списали 300, начислили 15)");
            loyalty.slowNext.set(1);
            String noSpend = "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.commit\",\"id\":\"%s\",\"params\":{\"card\":\"7700000000002\","
                    + "\"checkId\":\"17-000043-20261026\",\"totalMinor\":250000,\"pointsToSpend\":0}}";
            try { HttpRpc.call(8192, noSpend.formatted("17-43-commit-1"), POS_TIMEOUT); } catch (HttpTimeoutException e) { }
            Thread.sleep(300);
            HttpRpc.call(8192, noSpend.formatted("17-43-commit-2"), POS_TIMEOUT);
            System.out.println("   чек на 2500 ₽ без списания, тот же тайм-аут и повтор: начислено " + loyalty.balance.get("7700000000002") + " баллов (положено 25)");
            server.stop(0);
        }

        System.out.println("== касса досылает 30 чеков, накопленных без связи, одним пакетом");
        for (boolean parallel : new boolean[]{false, true}) {
            var loyalty = new Loyalty(); loyalty.commitDelayMs = 20;
            var rpc = loyalty.register(new JsonRpc()); rpc.parallelBatch = parallel;
            var server = HttpRpc.start(8193, rpc);
            List<String> calls = new ArrayList<>();
            for (int i = 1; i <= 30; i++) {
                String card = i == 7 ? "7700000000666" : i == 19 ? "7700000000002" : "7700000000001";
                long spend = i == 19 ? 100 : 0;
                calls.add("{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.commit\",\"id\":" + i + ",\"params\":{\"card\":\"" + card
                        + "\",\"checkId\":\"17-0001" + String.format("%02d", i) + "-20261025\",\"totalMinor\":" + (40000 + i * 1000) + ",\"pointsToSpend\":" + spend + "}}");
            }
            long t0 = System.nanoTime();
            String reply = HttpRpc.call(8193, "[" + String.join(",", calls) + "]", Duration.ofSeconds(5));
            long ms = (System.nanoTime() - t0) / 1_000_000;
            JsonNode arr = JsonRpc.JSON.readTree(reply.substring(reply.indexOf('|') + 2));
            var order = new ArrayList<String>(); var errors = new ArrayList<String>();
            for (JsonNode r : arr) { order.add(r.get("id").asText()); if (r.has("error")) errors.add("id " + r.get("id") + ": " + r.get("error").get("code") + " " + r.get("error").get("message").asText()); }
            System.out.println("   " + (parallel ? "параллельно" : "последовательно") + ": " + ms + " мс, ответов " + arr.size() + ", порядок id " + String.join(",", order.subList(0, 8)) + "…");
            System.out.println("   ошибки в пакете: " + errors);
            server.stop(0);
        }
    }
}
