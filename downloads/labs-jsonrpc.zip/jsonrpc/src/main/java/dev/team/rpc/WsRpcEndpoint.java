package dev.team.rpc;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.websocket.OnClose;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * JSON-RPC поверх WebSocket: касса вызывает процессинг, а процессинг сам шлёт кассам уведомления
 * и может вызвать метод на кассе. Запросы кассы обрабатываются параллельно, ответы уходят по готовности.
 */
@ServerEndpoint("/rpc-ws")
public class WsRpcEndpoint {
    static JsonRpc rpc;
    static final Map<String, Session> POS = new ConcurrentHashMap<>();                       // касса -> сессия
    static final Map<String, CompletableFuture<JsonNode>> PENDING = new ConcurrentHashMap<>(); // вызовы сервера на кассе
    static final AtomicInteger SEQ = new AtomicInteger();

    @OnOpen
    public void open(Session s) { POS.put(s.getRequestParameterMap().get("pos").get(0), s); }

    @OnClose
    public void close(Session s) { POS.values().remove(s); }

    @OnMessage
    public void onText(String text, Session s) throws Exception {
        JsonNode n = JsonRpc.JSON.readTree(text);
        if (n.isObject() && !n.has("method") && (n.has("result") || n.has("error"))) {    // это ответ кассы на вызов сервера
            var f = PENDING.remove(n.path("id").asText());
            if (f != null) f.complete(n);
            return;
        }
        Thread.ofVirtual().start(() -> {                                                  // не задерживать чтение следующих запросов
            String reply = rpc.handle(text);
            if (reply != null) send(s, reply);
        });
    }

    static void send(Session s, String text) {
        synchronized (s) { try { s.getBasicRemote().sendText(text); } catch (Exception e) { System.out.println("   отправка: " + e); } }
    }

    /** Разослать уведомление всем кассам: запрос без id, ответа не будет. */
    public static void notifyAll(String method, Object params) throws Exception {
        String text = "{\"jsonrpc\":\"2.0\",\"method\":\"" + method + "\",\"params\":" + JsonRpc.JSON.writeValueAsString(params) + "}";
        for (Session s : POS.values()) send(s, text);
    }

    /** Вызвать метод на кассе и дождаться ответа: роли клиента и сервера в JSON-RPC симметричны. */
    public static CompletableFuture<JsonNode> callPos(String pos, String method, Object params) throws Exception {
        String id = "srv-" + SEQ.incrementAndGet();
        var f = new CompletableFuture<JsonNode>();
        PENDING.put(id, f);
        send(POS.get(pos), "{\"jsonrpc\":\"2.0\",\"method\":\"" + method + "\",\"params\":" + JsonRpc.JSON.writeValueAsString(params) + ",\"id\":\"" + id + "\"}");
        return f;
    }
}
