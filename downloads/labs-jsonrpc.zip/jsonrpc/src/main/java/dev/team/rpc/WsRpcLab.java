package dev.team.rpc;

import com.fasterxml.jackson.databind.JsonNode;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;

/** Опыт: касса 17 держит WebSocket с процессингом; три запроса без ожидания, рассылка акции, вызов сервера на кассе. */
public class WsRpcLab {
    public static void main(String[] args) throws Exception {
        var loyalty = new Loyalty(); loyalty.commitDelayMs = 200;          // проведение медленное, баланс быстрый
        WsRpcEndpoint.rpc = loyalty.register(new JsonRpc());
        var tomcat = Server.start(8194, WsRpcEndpoint.class);

        List<String> got = new CopyOnWriteArrayList<>();
        var pos = HttpClient.newHttpClient().newWebSocketBuilder().buildAsync(URI.create("ws://localhost:8194/rpc-ws?pos=17"),
                new WebSocket.Listener() {
                    public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
                        String text = data.toString();
                        try {
                            JsonNode n = JsonRpc.JSON.readTree(text);
                            if ("pos.status".equals(n.path("method").asText()))      // сервер вызвал метод кассы
                                ws.sendText("{\"jsonrpc\":\"2.0\",\"result\":{\"pos\":\"17\",\"shift\":\"открыта\",\"queue\":4},\"id\":\"" + n.get("id").asText() + "\"}", true);
                        } catch (Exception ignored) { }
                        got.add(text);
                        ws.request(1);
                        return null;
                    }
                }).join();

        System.out.println("== 1. касса шлёт три запроса подряд, не дожидаясь ответов");
        pos.sendText("{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.commit\",\"params\":{\"card\":\"7700000000001\",\"checkId\":\"17-000050-20261026\",\"totalMinor\":120000,\"pointsToSpend\":0},\"id\":\"c-50\"}", true).join();
        pos.sendText("{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":[\"7700000000002\"],\"id\":\"b-1\"}", true).join();
        pos.sendText("{\"jsonrpc\":\"2.0\",\"method\":\"pos.heartbeat\",\"params\":{\"pos\":\"17\"}}", true).join();
        Thread.sleep(500);
        got.forEach(m -> System.out.println("   ← " + m));

        System.out.println("== 2. процессинг рассылает уведомление об акции и спрашивает кассу о её состоянии");
        got.clear();
        WsRpcEndpoint.notifyAll("promo.updated", Map.of("promo", "MILK-5", "validFrom", "2026-10-27T00:00:00+05:00"));
        JsonNode status = WsRpcEndpoint.callPos("17", "pos.status", Map.of()).get(2, TimeUnit.SECONDS);
        Thread.sleep(200);
        got.forEach(m -> System.out.println("   касса получила: " + m));
        System.out.println("   ответ кассы серверу: " + status);
        tomcat.stop();
        System.exit(0);
    }
}
