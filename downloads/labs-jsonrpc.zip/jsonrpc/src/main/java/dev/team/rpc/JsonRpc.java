package dev.team.rpc;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Диспетчер JSON-RPC 2.0, не знающий о транспорте: на вход строка, на выход строка или null («ответа нет»).
 * Один и тот же объект обслуживает и HTTP, и WebSocket.
 */
public final class JsonRpc {
    public static final ObjectMapper JSON = new ObjectMapper();

    /** Метод: получает params (объект, массив или null) и возвращает result. */
    @FunctionalInterface public interface Method { Object call(JsonNode params) throws Exception; }

    /** Ошибка с кодом протокола или доменным кодом. */
    public static final class RpcException extends Exception {
        final int code; final Object data;
        public RpcException(int code, String message, Object data) { super(message); this.code = code; this.data = data; }
    }

    private final Map<String, Method> methods = new ConcurrentHashMap<>();
    private final ExecutorService pool = Executors.newVirtualThreadPerTaskExecutor();
    public volatile boolean parallelBatch = false;
    public volatile int maxBatch = 100;
    public final Map<Integer, Integer> errorsByCode = new ConcurrentHashMap<>();
    public final Map<Integer, Integer> swallowedInNotifications = new ConcurrentHashMap<>();   // ошибки, которых клиент не увидит

    public JsonRpc register(String name, Method m) { methods.put(name, m); return this; }

    /** Обработать тело сообщения целиком: одиночный запрос или пакет. null — отвечать нечего. */
    public String handle(String body) {
        JsonNode root;
        try { root = JSON.readTree(body); }
        catch (Exception e) { return write(error(null, -32700, "Parse error", null)); }
        if (root == null || root.isMissingNode()) return write(error(null, -32700, "Parse error", null));
        if (!root.isArray()) { ObjectNode r = one(root); return r == null ? null : write(r); }
        if (root.isEmpty()) return write(error(null, -32600, "Invalid Request", "пустой пакет"));
        if (root.size() > maxBatch) return write(error(null, -32600, "Invalid Request", "пакет больше " + maxBatch));
        ArrayNode out = JSON.createArrayNode();
        if (parallelBatch) {
            List<Future<ObjectNode>> fs = new ArrayList<>();
            for (JsonNode n : root) fs.add(pool.submit(() -> one(n)));
            for (Future<ObjectNode> f : fs) { try { ObjectNode r = f.get(); if (r != null) out.add(r); } catch (Exception e) { throw new IllegalStateException(e); } }
        } else {
            for (JsonNode n : root) { ObjectNode r = one(n); if (r != null) out.add(r); }
        }
        return out.isEmpty() ? null : write(out);                     // пакет из одних уведомлений: ответа нет
    }

    /** Один запрос. Запрос без поля id — уведомление: на него не отвечают даже ошибкой. */
    ObjectNode one(JsonNode req) {
        boolean notification = req.isObject() && !req.has("id");
        JsonNode id = req.isObject() ? req.get("id") : null;
        if (!req.isObject() || !"2.0".equals(req.path("jsonrpc").asText(null)) || !req.path("method").isTextual()
                || (id != null && !(id.isTextual() || id.isNumber() || id.isNull()))) {
            boolean badId = id != null && !(id.isTextual() || id.isNumber() || id.isNull());
            return error(badId ? null : id, -32600, "Invalid Request", null);
        }
        JsonNode params = req.get("params");
        if (params != null && !params.isObject() && !params.isArray()) return notification ? null : error(id, -32600, "Invalid Request", "params — объект или массив");
        Method m = methods.get(req.get("method").asText());
        if (m == null) return notification ? null : error(id, -32601, "Method not found", req.get("method").asText());
        try {
            Object result = m.call(params);
            if (notification) return null;
            ObjectNode r = JSON.createObjectNode().put("jsonrpc", "2.0");
            r.set("result", JSON.valueToTree(result));
            r.set("id", id);
            return r;
        } catch (RpcException e) {
            if (notification) { swallowedInNotifications.merge(e.code, 1, Integer::sum); return null; }
            return error(id, e.code, e.getMessage(), e.data);
        } catch (IllegalArgumentException e) {
            return notification ? null : error(id, -32602, "Invalid params", e.getMessage());
        } catch (Exception e) {
            return notification ? null : error(id, -32603, "Internal error", null);   // подробности — в журнал, не клиенту
        }
    }

    ObjectNode error(JsonNode id, int code, String message, Object data) {
        errorsByCode.merge(code, 1, Integer::sum);
        ObjectNode e = JSON.createObjectNode().put("code", code).put("message", message);
        if (data != null) e.set("data", JSON.valueToTree(data));
        ObjectNode r = JSON.createObjectNode().put("jsonrpc", "2.0");
        r.set("error", e);
        r.set("id", id == null ? JSON.nullNode() : id);
        return r;
    }

    static String write(JsonNode n) {
        try { return JSON.writeValueAsString(n); } catch (Exception e) { throw new IllegalStateException(e); }
    }
}
