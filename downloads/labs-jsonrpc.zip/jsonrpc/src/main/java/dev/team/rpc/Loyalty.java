package dev.team.rpc;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Процессинг лояльности КорзиныПлюс: расчёт скидки по чеку, проведение чека, баланс.
 * Доменные ошибки — коды 1001–1099, договорённость процессинга с кассовым ПО.
 */
public final class Loyalty {
    public static final int CARD_NOT_FOUND = 1001, CARD_BLOCKED = 1002, NOT_ENOUGH_POINTS = 1003;

    final Map<String, Long> balance = new ConcurrentHashMap<>(Map.of(
            "7700000000001", 500L, "7700000000002", 0L, "7700000000666", 1200L));
    final Map<String, String> blocked = Map.of("7700000000666", "карта заблокирована антифродом");
    final Map<String, Map<String, Object>> committed = new ConcurrentHashMap<>();   // checkId -> результат проведения
    public volatile boolean idempotent = true;
    public volatile long commitDelayMs = 5;                                          // запись в базу
    public final AtomicInteger slowNext = new AtomicInteger();                       // сколько следующих проведений «тормозят»

    public JsonRpc register(JsonRpc rpc) {
        return rpc
            .register("loyalty.calculate", this::calculate)
            .register("loyalty.commit", this::commit)
            .register("loyalty.balance", this::balance)
            .register("pos.heartbeat", p -> null);                                     // уведомление от кассы
    }

    String card(JsonNode p) throws JsonRpc.RpcException {
        String card = p.isArray() ? p.path(0).asText(null) : p.path("card").asText(null);
        if (card == null) throw new IllegalArgumentException("нет номера карты");
        if (!balance.containsKey(card)) throw new JsonRpc.RpcException(CARD_NOT_FOUND, "карта не найдена", Map.of("card", card));
        if (blocked.containsKey(card)) throw new JsonRpc.RpcException(CARD_BLOCKED, blocked.get(card), Map.of("card", card));
        return card;
    }

    /** Скидка 5% на молочные товары и 1 балл за каждые 100 рублей чека. */
    Object calculate(JsonNode p) throws Exception {
        if (p == null || !p.isObject()) throw new IllegalArgumentException("params должен быть объектом");
        String card = card(p);
        long total = 0, discount = 0;
        for (JsonNode line : p.path("lines")) {
            long sum = line.path("priceMinor").asLong() * line.path("qty").asLong();
            total += sum;
            if (line.path("sku").asText().startsWith("MILK")) discount += sum * 5 / 100;
        }
        var r = new LinkedHashMap<String, Object>();
        r.put("totalMinor", total); r.put("discountMinor", discount);
        r.put("pointsToAccrue", (total - discount) / 10_000); r.put("pointsAvailable", balance.get(card));
        return r;
    }

    /** Провести чек: списать баллы и начислить новые. Ключ идемпотентности — checkId кассы, а не id запроса. */
    Object commit(JsonNode p) throws Exception {
        String card = card(p);
        String checkId = p.path("checkId").asText(null);
        if (checkId == null) throw new IllegalArgumentException("нет checkId");
        if (idempotent && committed.containsKey(checkId)) return committed.get(checkId);
        Thread.sleep(slowNext.getAndUpdate(n -> Math.max(0, n - 1)) > 0 ? 250 : commitDelayMs);
        long spend = p.path("pointsToSpend").asLong(), accrue = p.path("totalMinor").asLong() / 10_000;
        long[] after = new long[1];
        try {
            balance.compute(card, (k, b) -> {
                if (b < spend) throw new IllegalStateException();
                after[0] = b - spend + accrue; return after[0];
            });
        } catch (IllegalStateException e) {
            throw new JsonRpc.RpcException(NOT_ENOUGH_POINTS, "недостаточно баллов", Map.of("available", balance.get(card), "requested", spend));
        }
        var r = new LinkedHashMap<String, Object>();
        r.put("checkId", checkId); r.put("spent", spend); r.put("accrued", accrue); r.put("balance", after[0]);
        if (idempotent) committed.putIfAbsent(checkId, r);
        return r;
    }

    Object balance(JsonNode p) throws Exception { return Map.of("card", card(p), "points", balance.get(card(p))); }
}
