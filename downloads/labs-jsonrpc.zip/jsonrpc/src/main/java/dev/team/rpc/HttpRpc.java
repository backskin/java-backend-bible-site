package dev.team.rpc;

import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.Executors;

/** JSON-RPC поверх HTTP: один адрес POST /rpc; нет ответа — 204, иначе 200 и тело. */
public final class HttpRpc {
    private HttpRpc() { }

    public static HttpServer start(int port, JsonRpc rpc) throws IOException {
        var server = HttpServer.create(new InetSocketAddress("localhost", port), 0);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.createContext("/rpc", ex -> {
            String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            String reply = rpc.handle(body);
            if (reply == null) { ex.sendResponseHeaders(204, -1); ex.close(); return; }
            byte[] bytes = reply.getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().add("Content-Type", "application/json");
            ex.sendResponseHeaders(200, bytes.length);
            ex.getResponseBody().write(bytes);
            ex.close();
        });
        server.start();
        return server;
    }

    static final HttpClient CLIENT = HttpClient.newHttpClient();

    /** Вызов с тайм-аутом, как у кассы: «статус HTTP | тело». */
    public static String call(int port, String body, Duration timeout) throws Exception {
        var req = HttpRequest.newBuilder(URI.create("http://localhost:" + port + "/rpc"))
                .timeout(timeout).header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body)).build();
        var resp = CLIENT.send(req, HttpResponse.BodyHandlers.ofString());
        return resp.statusCode() + " | " + resp.body();
    }
}
