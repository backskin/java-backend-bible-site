package dev.team.rpc;

import java.time.Duration;

/** Опыт: граничные случаи спецификации JSON-RPC 2.0 на процессинге лояльности. */
public class SpecLab {
    public static void main(String[] args) throws Exception {
        var rpc = new Loyalty().register(new JsonRpc());
        var server = HttpRpc.start(8191, rpc);
        String[][] cases = {
            {"именованные параметры", "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":{\"card\":\"7700000000001\"},\"id\":1}"},
            {"позиционные параметры", "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":[\"7700000000001\"],\"id\":\"pos-17-000042\"}"},
            {"уведомление (нет id)", "{\"jsonrpc\":\"2.0\",\"method\":\"pos.heartbeat\",\"params\":{\"pos\":\"17\"}}"},
            {"id: null — это не уведомление", "{\"jsonrpc\":\"2.0\",\"method\":\"pos.heartbeat\",\"params\":{},\"id\":null}"},
            {"уведомление с ошибкой", "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":[\"0000\"]}"},
            {"нет метода", "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.refund\",\"params\":{},\"id\":2}"},
            {"неверные параметры", "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":{},\"id\":3}"},
            {"доменная ошибка", "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":[\"7700000000666\"],\"id\":4}"},
            {"битый JSON", "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":[\"77"},
            {"версия 1.0", "{\"jsonrpc\":\"1.0\",\"method\":\"loyalty.balance\",\"params\":[\"7700000000001\"],\"id\":5}"},
            {"id — объект", "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":[\"7700000000001\"],\"id\":{\"pos\":17}}"},
            {"пустой пакет", "[]"},
            {"пакет из одних уведомлений", "[{\"jsonrpc\":\"2.0\",\"method\":\"pos.heartbeat\",\"params\":{}},{\"jsonrpc\":\"2.0\",\"method\":\"pos.heartbeat\",\"params\":{}}]"},
            {"смешанный пакет", "[{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":[\"7700000000001\"],\"id\":10},"
                    + "{\"jsonrpc\":\"2.0\",\"method\":\"pos.heartbeat\",\"params\":{}},1,"
                    + "{\"jsonrpc\":\"2.0\",\"method\":\"loyalty.balance\",\"params\":[\"7700000000666\"],\"id\":11}]"},
        };
        for (String[] c : cases) {
            System.out.printf("%-30s -> %s%n", c[0], HttpRpc.call(8191, c[1], Duration.ofSeconds(2)));
        }
        System.out.println("ошибки по кодам (то, что должен видеть мониторинг): " + rpc.errorsByCode
                + "; проглочено в уведомлениях: " + rpc.swallowedInNotifications);
        server.stop(0);
    }
}
