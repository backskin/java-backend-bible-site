# JSON-RPC 2.0 своими руками: спецификация на тестах, оформление заказа на кассе, транспорт по HTTP и WebSocket

Стенд к главе 28, раздел о JSON-RPC. Собственная реализация `dev.team.rpc.JsonRpc` без зависимости от транспорта (Jackson 2.22.3) и три программы: `SpecLab` (поведение по спецификации: пакеты, уведомления, ошибки `-32600…-32603`, `id` строкой и числом), `CheckoutLab` (сценарий кассы КорзинаПлюс: запросы и ответы между кассой и процессингом по HTTP на `com.sun.net.httpserver` и `java.net.http.HttpClient`), `WsRpcLab` (то же по WebSocket на встроенном Tomcat 11.0.24). Выводы приведены в главе.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" dev.team.rpc.SpecLab
```

В IDEA есть конфигурации `SpecLab`, `CheckoutLab`, `WsRpcLab`.
