# Ёмкость потребителей Kafka: опыты к главе 29, подразделы 13.6–13.12

Проверено 2026-10-30: kind (3 узла), Kafka 4.3.1 (`labs/kafka-cluster3/kafka3.yaml`), клиент kafka-clients 4.3.1, JDK 21.0.12 в поде `eclipse-temurin:21-jre`.

Время обработки записи имитируется ожиданием (`LockSupport.parkNanos`) по смеси: логнормальное с медианой 8 мс и 1,5 % записей по 110–160 мс (медленный ответ антифрода). Получается p50 8 мс, p99 около 126 мс, среднее 10,3 мс — как в примере 6.14.

## Сборка и запуск

```bash
mvn -q package                       # target/caplab.jar со всеми зависимостями
kubectl -n kafka3 run caplab --image=eclipse-temurin:21-jre --restart=Never --command -- sleep infinity
kubectl -n kafka3 cp target/caplab.jar caplab:/tmp/caplab.jar
kubectl -n kafka3 exec caplab -- java -jar /tmp/caplab.jar <режим> [аргументы]
```

Клиенты работают внутри кластера, потому что брокеры объявляют внутренние адреса `kc-N.kc.kafka3.svc.cluster.local`.

## Режимы и выводы

| Режим | Что проверяет | Вывод |
|---|---|---|
| `service`, `mu` | ёмкость одного потребителя по среднему и по p99, насыщение на Kafka | `s29-cap-mu.txt`, `s29-cap-rho-a.txt` (первые строки) |
| `rho 0.5 0.7 0.85 0.95` | время в системе, лаг и закон Литтла при разной загрузке, сравнение с M/G/1 | `s29-cap-rho-a.txt`, `s29-cap-rho-b.txt` |
| `retry 0.6 0.1 3 30` | поток в топик повторов и DLT, отказ зависимости на 30 с | `s29-cap-retry.txt` |
| `skew h P 6000` | перекос ключа при 6, 12, 24 партициях | `s29-cap-skew.txt` |
| `producers` | один общий производитель против производителя на поток (`ORDER=per-thread-first` меняет порядок), общий транзакционный | `s29-cap-producers.txt` |
| `catchup 30000 600 24 12` | догон накопленного лага; `KEYED=1` — с ключами, `PARTITIONER=rr` — `RoundRobinPartitioner` | `s29-cap-catchup.txt` |
| `project 600 24 C 0.02 3 180 1500` | сквозной пример при C = 12, 8, 7 и размер на диске | `s29-cap-project.txt` |

Размер на диске снят командой `du -sb --apparent-size /tmp/kafka-logs/pay.events-*/*.log` в каждом брокере.
