package dev.team.cap;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.LockSupport;
import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.serialization.*;

/**
 * Глава 29, 13.6: опыты по расчёту ёмкости потребителей на стенде kafka-cluster3 (Kafka 4.3.1).
 *
 * Время обработки записи — смесь, как в примере 6.14: обычный путь около 8 мс (логнормальное,
 * медиана 8 мс) и редкий медленный вызов антифрода 110–160 мс с вероятностью 1,5 %.
 * Обработка имитируется ожиданием (parkNanos): процессор не занят, как при вызове внешнего сервиса.
 *
 * Режимы:
 *   service                      — распределение времени обработки без Kafka: среднее, p50, p99, E[S^2]
 *   mu                           — насыщение: один потребитель разбирает накопленные 3000 записей
 *   rho 0.5 0.7 0.85 0.95        — пуассоновский поток в одну партицию при загрузке ρ; ожидание, лаг, закон Литтла
 *   retry ρ p r outageSec        — повторы через топик повторов и DLT; доля ошибок p, повторов r, отказ зависимости
 *   skew h P N                   — перекос ключа: доля горячего ключа h, P партиций, N записей, разбор на P потребителях
 *   producers                    — один общий KafkaProducer против отдельного на поток; общий транзакционный
 *   project λ P C p r sec size   — сквозной пример: пик λ, P партиций, C потребителей, ошибки p, повторы r
 */
public class CapLab {
    static final String BS = System.getenv().getOrDefault("BS", "kc-0.kc.kafka3.svc.cluster.local:9092");

    // ---------- время обработки ----------
    static long serviceNanos() {
        var r = ThreadLocalRandom.current();
        double ms = r.nextDouble() < 0.015 ? 110 + 50 * r.nextDouble() : 8 * Math.exp(0.3 * r.nextGaussian());
        return (long) (ms * 1_000_000);
    }

    static void work(long nanos) {
        long end = System.nanoTime() + nanos;
        for (long left; (left = end - System.nanoTime()) > 0; ) LockSupport.parkNanos(left);
    }

    // ---------- статистика ----------
    static final class Stats {
        final List<Long> v = Collections.synchronizedList(new ArrayList<>());
        void add(long x) { v.add(x); }
        long[] sorted() { long[] a; synchronized (v) { a = v.stream().mapToLong(Long::longValue).toArray(); } Arrays.sort(a); return a; }
        static double pct(long[] a, double p) { return a.length == 0 ? 0 : a[Math.min(a.length - 1, (int) Math.ceil(p * a.length) - 1)]; }
        static double mean(long[] a) { return Arrays.stream(a).average().orElse(0); }
    }

    static String ms(double nanos) { return String.format(Locale.ROOT, "%.1f", nanos / 1e6); }

    // ---------- Kafka ----------
    static Admin admin() { return Admin.create(Map.of("bootstrap.servers", BS)); }

    static void topic(Admin a, String name, int partitions) throws Exception {
        try { a.deleteTopics(List.of(name)).all().get(); Thread.sleep(1500); } catch (ExecutionException ignored) { }
        for (int i = 0; ; i++) {
            try { a.createTopics(List.of(new NewTopic(name, partitions, (short) 3))).all().get(); break; }
            catch (ExecutionException e) { if (i > 20) throw e; Thread.sleep(500); }
        }
        Thread.sleep(1000);
    }

    static KafkaProducer<String, byte[]> producer(Map<String, Object> extra) {
        Map<String, Object> p = new HashMap<>(Map.of("bootstrap.servers", BS, "acks", "all",
                "key.serializer", StringSerializer.class, "value.serializer", ByteArraySerializer.class));
        p.putAll(extra);
        return new KafkaProducer<>(p);
    }

    static KafkaConsumer<String, byte[]> consumer(String group) {
        return new KafkaConsumer<>(Map.of("bootstrap.servers", BS, "group.id", group,
                "auto.offset.reset", "earliest", "enable.auto.commit", "true",
                "key.deserializer", StringDeserializer.class, "value.deserializer", ByteArrayDeserializer.class));
    }

    /** Пуассоновский поток: экспоненциальные паузы со средним 1/λ. */
    static void poisson(double lambda, long untilNanos, Runnable send) {
        long next = System.nanoTime();
        var r = ThreadLocalRandom.current();
        while (next < untilNanos) {
            work(next - System.nanoTime());
            send.run();
            next += (long) (-Math.log(1 - r.nextDouble()) / lambda * 1e9);
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("Kafka clients 4.3.1, JDK " + Runtime.version() + ", кластер " + BS);
        switch (args[0]) {
            case "service" -> service();
            case "mu" -> mu();
            case "rho" -> { for (int i = 1; i < args.length; i++) rho(Double.parseDouble(args[i])); }
            case "retry" -> retry(Double.parseDouble(args[1]), Double.parseDouble(args[2]), Integer.parseInt(args[3]), Integer.parseInt(args[4]));
            case "skew" -> skew(Double.parseDouble(args[1]), Integer.parseInt(args[2]), Integer.parseInt(args[3]));
            case "producers" -> producers();
            case "catchup" -> catchup(Integer.parseInt(args[1]), Double.parseDouble(args[2]), Integer.parseInt(args[3]), Integer.parseInt(args[4]));
            case "project" -> project(Double.parseDouble(args[1]), Integer.parseInt(args[2]), Integer.parseInt(args[3]),
                    Double.parseDouble(args[4]), Integer.parseInt(args[5]), Integer.parseInt(args[6]), Integer.parseInt(args[7]));
            default -> throw new IllegalArgumentException(args[0]);
        }
        System.exit(0);
    }

    static double E_S, E_S2;   // нс и нс^2

    static void service() {
        int n = 1_000_000;
        long[] a = new long[n];
        double s2 = 0;
        for (int i = 0; i < n; i++) { a[i] = serviceNanos(); s2 += (double) a[i] * a[i]; }
        Arrays.sort(a);
        E_S = Stats.mean(a); E_S2 = s2 / n;
        System.out.println("=== время обработки, " + n + " выборок");
        System.out.println("  среднее " + ms(E_S) + " мс, p50 " + ms(Stats.pct(a, .5)) + " мс, p99 " + ms(Stats.pct(a, .99))
                + " мс, p99.9 " + ms(Stats.pct(a, .999)) + " мс, E[S^2] = " + String.format(Locale.ROOT, "%.1f", E_S2 / 1e12) + " мс^2");
        System.out.println("  ёмкость одного потребителя: по среднему 1000/" + ms(E_S) + " = " + Math.round(1e9 / E_S)
                + " зап./с; по p99 1000/" + ms(Stats.pct(a, .99)) + " = " + String.format(Locale.ROOT, "%.1f", 1e9 / Stats.pct(a, .99))
                + " зап./с; ошибка расчёта по p99 — в " + String.format(Locale.ROOT, "%.1f", Stats.pct(a, .99) / E_S) + " раза");
    }

    static void mu() throws Exception {
        service();
        try (Admin a = admin()) { topic(a, "cap.mu", 1); }
        int n = 3000;
        try (var p = producer(Map.of("linger.ms", 5))) {
            for (int i = 0; i < n; i++) p.send(new ProducerRecord<>("cap.mu", null, new byte[100]));
        }
        try (var c = consumer("mu-" + System.nanoTime())) {
            c.subscribe(List.of("cap.mu"));
            int done = 0; long t0 = 0;
            while (done < n) {
                for (var r : c.poll(Duration.ofMillis(200))) { if (t0 == 0) t0 = System.nanoTime(); work(serviceNanos()); done++; }
            }
            double sec = (System.nanoTime() - t0) / 1e9;
            System.out.println("=== насыщение: один потребитель, " + n + " накопленных записей");
            System.out.println(String.format(Locale.ROOT, "  разобрано за %.1f с: μ = %.1f зап./с (по среднему ожидалось %d)", sec, n / sec, Math.round(1e9 / E_S)));
        }
    }

    /** Одна партиция, один потребитель, пуассоновский поток λ = ρ·μ. */
    static void rho(double rho) throws Exception {
        if (E_S == 0) service();
        double lambda = rho * 1e9 / E_S;
        String t = "cap.rho";
        try (Admin a = admin()) { topic(a, t, 1); }
        Stats total = new Stats(), wait = new Stats();
        AtomicLong sent = new AtomicLong(), processed = new AtomicLong();
        long warm = System.nanoTime() + 10_000_000_000L, end = warm + 120_000_000_000L;
        List<Long> lagSamples = Collections.synchronizedList(new ArrayList<>());
        var exec = Executors.newCachedThreadPool();
        exec.submit(() -> {
            try (var c = consumer("rho-" + System.nanoTime())) {
                c.subscribe(List.of(t));
                while (System.nanoTime() < end + 30_000_000_000L && (System.nanoTime() < end || processed.get() < sent.get())) {
                    for (var r : c.poll(Duration.ofMillis(50))) {
                        long start = System.currentTimeMillis();
                        work(serviceNanos());
                        long fin = System.currentTimeMillis();
                        if (r.timestamp() * 1_000_000L >= 0 && System.nanoTime() > warm && System.nanoTime() < end) {
                            total.add((fin - r.timestamp()) * 1_000_000L); wait.add((start - r.timestamp()) * 1_000_000L);
                        }
                        processed.incrementAndGet();
                    }
                }
            }
            return null;
        });
        exec.submit(() -> { while (System.nanoTime() < end) { if (System.nanoTime() > warm) lagSamples.add(sent.get() - processed.get()); Thread.sleep(100); } return null; });
        try (var p = producer(Map.of("linger.ms", 0))) {
            poisson(lambda, end, () -> { p.send(new ProducerRecord<>(t, null, System.currentTimeMillis(), null, new byte[100])); sent.incrementAndGet(); });
        }
        exec.shutdown(); exec.awaitTermination(60, TimeUnit.SECONDS);
        long[] T = total.sorted(), W = wait.sorted();
        double L = lagSamples.stream().mapToLong(Long::longValue).average().orElse(0);
        double lam = T.length / 120.0;
        double pk = lam * E_S2 / 1e18 / (2 * (1 - lam * E_S / 1e9));     // Поллачек — Хинчин, с
        System.out.println(String.format(Locale.ROOT,
                "ρ=%.2f λ=%.1f зап./с | время в системе: среднее %s мс, p50 %s, p99 %s | ожидание в очереди: среднее %s мс, p99 %s | " +
                        "средний лаг L=%.1f, λ·T=%.1f | M/G/1: ожидание %.1f мс",
                lam * E_S / 1e9, lam, ms(Stats.mean(T)), ms(Stats.pct(T, .5)), ms(Stats.pct(T, .99)),
                ms(Stats.mean(W)), ms(Stats.pct(W, .99)), L, lam * Stats.mean(T) / 1e9, pk * 1000));
    }

    static int attempt(ConsumerRecord<?, ?> r) {
        Header h = r.headers().lastHeader("attempt");
        return h == null ? 0 : Integer.parseInt(new String(h.value(), StandardCharsets.UTF_8));
    }

    /** Основной поток λ = ρ·μ; при ошибке запись уходит в cap.retry, после r повторов — в cap.dlt. */
    static void retry(double rho, double p, int r, int outageSec) throws Exception {
        if (E_S == 0) service();
        double lambda = rho * 1e9 / E_S;
        try (Admin a = admin()) { topic(a, "cap.main", 1); topic(a, "cap.retry", 1); topic(a, "cap.dlt", 1); }
        long t0 = System.nanoTime(), dur = 120_000_000_000L, end = t0 + dur;
        long outFrom = t0 + 40_000_000_000L, outTo = outFrom + outageSec * 1_000_000_000L;
        AtomicLong sent = new AtomicLong(), mainDone = new AtomicLong(), toRetry = new AtomicLong(), retryDone = new AtomicLong(), toDlt = new AtomicLong();
        var out = producer(Map.of("linger.ms", 0));
        var exec = Executors.newCachedThreadPool();
        java.util.function.BiConsumer<String, AtomicLong> loop = (topic, done) -> {
            try (var c = consumer("g-" + topic + System.nanoTime())) {
                c.subscribe(List.of(topic));
                while (System.nanoTime() < end) {
                    for (var rec : c.poll(Duration.ofMillis(50))) {
                        work(serviceNanos());
                        long now = System.nanoTime();
                        boolean fail = (now >= outFrom && now < outTo) || ThreadLocalRandom.current().nextDouble() < p;
                        int att = attempt(rec);
                        if (fail) {
                            var next = att < r ? new ProducerRecord<String, byte[]>("cap.retry", rec.key(), rec.value())
                                               : new ProducerRecord<String, byte[]>("cap.dlt", rec.key(), rec.value());
                            next.headers().add("attempt", String.valueOf(att + 1).getBytes(StandardCharsets.UTF_8));
                            out.send(next);
                            (att < r ? toRetry : toDlt).incrementAndGet();
                        }
                        done.incrementAndGet();
                    }
                }
            }
        };
        exec.submit(() -> loop.accept("cap.main", mainDone));
        exec.submit(() -> loop.accept("cap.retry", retryDone));
        exec.submit(() -> {
            System.out.println(String.format(Locale.ROOT, "=== повторы: ρ основного потока %.2f (λ=%.1f), доля ошибок %.2f, повторов %d, отказ зависимости %d–%d с",
                    rho, lambda, p, r, 40, 40 + outageSec));
            System.out.println("  с  | лаг основного | лаг повторов | в повторы, зап./с | в DLT, зап./с");
            long pr = 0, pd = 0;
            for (int s = 10; s <= 120; s += 10) {
                Thread.sleep(10_000);
                long rr = toRetry.get(), dd = toDlt.get();
                System.out.println(String.format(Locale.ROOT, "  %3d | %13d | %12d | %17.1f | %13.1f",
                        s, sent.get() - mainDone.get(), rr - retryDone.get(), (rr - pr) / 10.0, (dd - pd) / 10.0));
                pr = rr; pd = dd;
            }
            return null;
        });
        poisson(lambda, end, () -> { out.send(new ProducerRecord<>("cap.main", null, new byte[100])); sent.incrementAndGet(); });
        exec.shutdown(); exec.awaitTermination(30, TimeUnit.SECONDS);
        out.close();
    }

    /** N записей с горячим ключом доли h в топик из P партиций; P потребителей разбирают всё. */
    static void skew(double h, int P, int N) throws Exception {
        if (E_S == 0) service();
        String t = "cap.skew";
        try (Admin a = admin()) { topic(a, t, P); }
        try (var p = producer(Map.of("linger.ms", 5))) {
            var r = ThreadLocalRandom.current();
            for (int i = 0; i < N; i++) p.send(new ProducerRecord<>(t, r.nextDouble() < h ? "HOT" : "k" + r.nextInt(100_000), new byte[100]));
        }
        Map<Integer, Long> perPart = new ConcurrentHashMap<>();
        AtomicLong done = new AtomicLong();
        long t0 = System.nanoTime();
        var exec = Executors.newFixedThreadPool(P);
        String g = "skew-" + System.nanoTime();
        for (int i = 0; i < P; i++) exec.submit(() -> {
            try (var c = consumer(g)) {
                c.subscribe(List.of(t));
                while (done.get() < N) for (var rec : c.poll(Duration.ofMillis(100))) {
                    work(serviceNanos()); done.incrementAndGet(); perPart.merge(rec.partition(), 1L, Long::sum);
                }
            }
            return null;
        });
        exec.shutdown(); exec.awaitTermination(10, TimeUnit.MINUTES);
        double sec = (System.nanoTime() - t0) / 1e9;
        long max = perPart.values().stream().mapToLong(Long::longValue).max().orElse(0);
        System.out.println(String.format(Locale.ROOT, "доля горячего ключа %.2f, партиций %2d: самая нагруженная партиция %4d из %d (%.1f %%), разбор %.1f с, %.0f зап./с",
                h, P, max, N, 100.0 * max / N, sec, N / sec));
    }

    static void producers() throws Exception {
        try (Admin a = admin()) { topic(a, "cap.prod", 6); }
        int threads = 8, per = 50_000;
        byte[] v = new byte[1024];
        for (boolean shared : "per-thread-first".equals(System.getenv("ORDER")) ? new boolean[]{false, true} : new boolean[]{true, false}) {
            List<KafkaProducer<String, byte[]>> ps = new ArrayList<>();
            for (int i = 0; i < (shared ? 1 : threads); i++) ps.add(producer(Map.of("linger.ms", 5)));
            var exec = Executors.newFixedThreadPool(threads);
            long t0 = System.nanoTime();
            for (int i = 0; i < threads; i++) {
                var p = ps.get(shared ? 0 : i);
                exec.submit(() -> { for (int k = 0; k < per; k++) p.send(new ProducerRecord<>("cap.prod", "k" + k, v)); return null; });
            }
            exec.shutdown(); exec.awaitTermination(5, TimeUnit.MINUTES);
            ps.forEach(KafkaProducer::flush);
            double sec = (System.nanoTime() - t0) / 1e9;
            double batch = ps.stream().mapToDouble(p -> p.metrics().entrySet().stream()
                    .filter(e -> e.getKey().name().equals("batch-size-avg") && e.getKey().group().equals("producer-metrics"))
                    .mapToDouble(e -> ((Number) e.getValue().metricValue()).doubleValue()).sum()).average().orElse(0);
            long conns = ps.stream().mapToLong(p -> p.metrics().entrySet().stream()
                    .filter(e -> e.getKey().name().equals("connection-count") && e.getKey().group().equals("producer-metrics"))
                    .mapToLong(e -> ((Number) e.getValue().metricValue()).longValue()).sum()).sum();
            System.out.println(String.format(Locale.ROOT, "%s: %d потоков × %d записей по 1 КБ за %.1f с, %.0f МБ/с, средний пакет %.0f байт, соединений с брокерами %d",
                    shared ? "один общий KafkaProducer" : "KafkaProducer на каждый поток", threads, per, sec, threads * per / 1024.0 / sec, batch, conns));
            ps.forEach(KafkaProducer::close);
        }
        try (var tp = producer(Map.of("transactional.id", "cap-tx-" + System.nanoTime()))) {
            tp.initTransactions();
            tp.beginTransaction();
            var other = Executors.newSingleThreadExecutor().submit(() -> { tp.beginTransaction(); return "вторая транзакция открылась"; });
            try { System.out.println("общий транзакционный производитель: " + other.get()); }
            catch (ExecutionException e) { System.out.println("общий транзакционный производитель, второй поток: " + e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage()); }
            tp.abortTransaction();
        }
    }

    /** Догон: backlog накопленных записей, затем поток λ и C потребителей; когда лаг упадёт ниже 1 % накопленного. */
    static void catchup(int backlog, double lambda, int P, int C) throws Exception {
        if (E_S == 0) service();
        try (Admin a = admin()) { topic(a, "cap.catchup", P); }
        var out = producer("rr".equals(System.getenv("PARTITIONER"))
                ? Map.of("linger.ms", 5, "partitioner.class", "org.apache.kafka.clients.producer.RoundRobinPartitioner")
                : Map.of("linger.ms", 5));
        for (int i = 0; i < backlog; i++) out.send(new ProducerRecord<>("cap.catchup", "k" + i, new byte[100]));
        out.flush();
        AtomicLong sent = new AtomicLong(backlog), done = new AtomicLong();
        long t0 = System.nanoTime(), end = t0 + 180_000_000_000L;
        var exec = Executors.newCachedThreadPool();
        String g = "cu-" + System.nanoTime();
        for (int i = 0; i < C; i++) exec.submit(() -> {
            try (var c = consumer(g)) { c.subscribe(List.of("cap.catchup"));
                while (!Thread.currentThread().isInterrupted()) for (var rec : c.poll(Duration.ofMillis(50))) { work(serviceNanos()); done.incrementAndGet(); } }
            return null; });
        boolean keyed = "1".equals(System.getenv("KEYED"));
        exec.submit(() -> { poisson(lambda, end, () -> { out.send(new ProducerRecord<>("cap.catchup", keyed ? "acc-" + ThreadLocalRandom.current().nextInt(2_000_000) : null, new byte[100])); sent.incrementAndGet(); }); return null; });
        double predicted = backlog / (C * 1e9 / E_S - lambda);
        long nextPrint = t0;
        while ((sent.get() - done.get() > backlog / 100 || System.nanoTime() - t0 < 5_000_000_000L) && System.nanoTime() < end) {
            if (System.nanoTime() >= nextPrint) { System.out.println(String.format(Locale.ROOT, "  %5.1f с: лаг %d, разобрано %d", (System.nanoTime() - t0) / 1e9, sent.get() - done.get(), done.get())); nextPrint += 5_000_000_000L; }
            Thread.sleep(200);
        }
        double sec = (System.nanoTime() - t0) / 1e9;
        System.out.println(String.format(Locale.ROOT, "догон: накоплено %d, поток %.0f зап./с, %d партиций, %d потребителей: лаг ниже 1 %% через %.1f с; " +
                "расчёт backlog / (C·μ − λ) = %d / (%d·%.0f − %.0f) = %.1f с (без учёта сборки группы)", backlog, lambda, P, C, sec, backlog, C, 1e9 / E_S, lambda, predicted));
        exec.shutdownNow(); out.close();
    }

    static final String[] STATUS = {"CREATED", "ACCEPTED", "FRAUD_CHECKED", "SENT_TO_SBP", "COMPLETED", "REJECTED"};

    /** Событие платежа в JSON примерно заданного размера: поля с реальными форматами и история статусов. */
    static byte[] paymentJson(ThreadLocalRandom r, String acc, int size) {
        var sb = new StringBuilder(size + 200);
        sb.append("{\"eventId\":\"").append(UUID.randomUUID()).append("\",\"type\":\"PAYMENT_STATUS_CHANGED\",\"payerAccount\":\"").append(acc)
          .append("\",\"payeeAccount\":\"40702810").append(String.format("%012d", r.nextLong(1_000_000_000_000L)))
          .append("\",\"payeeBic\":\"04452").append(String.format("%04d", r.nextInt(10_000)))
          .append("\",\"amount\":\"").append(r.nextInt(1, 500_000)).append('.').append(String.format("%02d", r.nextInt(100)))
          .append("\",\"currency\":\"RUB\",\"channel\":\"").append(r.nextBoolean() ? "MOBILE" : "INTERNET_BANK")
          .append("\",\"purpose\":\"Оплата по договору № ").append(r.nextInt(1, 99_999)).append(" от 2026-10-").append(String.format("%02d", r.nextInt(1, 29)))
          .append(". НДС не облагается\",\"history\":[");
        long ts = System.currentTimeMillis() - 60_000;
        for (int i = 0; sb.length() < size - 120; i++) {
            if (i > 0) sb.append(',');
            ts += r.nextInt(50, 5_000);
            sb.append("{\"status\":\"").append(STATUS[i % STATUS.length]).append("\",\"at\":").append(ts)
              .append(",\"node\":\"pay-gateway-").append(r.nextInt(3)).append("\",\"traceId\":\"").append(Long.toHexString(r.nextLong())).append("\"}");
        }
        return sb.append("]}").toString().getBytes(StandardCharsets.UTF_8);
    }

    /** Сквозной пример: пиковый пуассоновский поток λ на P партиций, C потребителей, ошибки p с r повторами. */
    static void project(double lambda, int P, int C, double p, int r, int sec, int size) throws Exception {
        if (E_S == 0) service();
        try (Admin a = admin()) { topic(a, "pay.events", P); topic(a, "pay.events.retry", Math.max(1, P / 4)); topic(a, "pay.events.dlt", 1); }
        long t0 = System.nanoTime(), end = t0 + sec * 1_000_000_000L, warm = t0 + 15_000_000_000L;
        AtomicLong sent = new AtomicLong(), done = new AtomicLong(), toRetry = new AtomicLong(), retryDone = new AtomicLong(), dlt = new AtomicLong();
        Stats total = new Stats();
        List<Long> lags = Collections.synchronizedList(new ArrayList<>());
        var out = producer(Map.of("linger.ms", 5, "compression.type", "lz4"));
        var exec = Executors.newCachedThreadPool();
        String g = "pay-" + System.nanoTime(), gr = "payr-" + System.nanoTime();
        int retryConsumers = Math.max(1, P / 4);
        for (int i = 0; i < C + retryConsumers; i++) {
            boolean main = i < C;
            exec.submit(() -> {
                try (var c = consumer(main ? g : gr)) {
                    c.subscribe(List.of(main ? "pay.events" : "pay.events.retry"));
                    while (System.nanoTime() < end) for (var rec : c.poll(Duration.ofMillis(50))) {
                        work(serviceNanos());
                        if (main && System.nanoTime() > warm) total.add((System.currentTimeMillis() - rec.timestamp()) * 1_000_000L);
                        if (ThreadLocalRandom.current().nextDouble() < p) {
                            int att = attempt(rec);
                            var next = new ProducerRecord<>(att < r ? "pay.events.retry" : "pay.events.dlt", rec.key(), rec.value());
                            next.headers().add("attempt", String.valueOf(att + 1).getBytes(StandardCharsets.UTF_8));
                            out.send(next);
                            (att < r ? toRetry : dlt).incrementAndGet();
                        }
                        (main ? done : retryDone).incrementAndGet();
                    }
                }
                return null;
            });
        }
        exec.submit(() -> { while (System.nanoTime() < end) { if (System.nanoTime() > warm) lags.add(sent.get() - done.get()); Thread.sleep(200); } return null; });
        var rnd = ThreadLocalRandom.current();
        AtomicLong bytes = new AtomicLong();
        poisson(lambda, end, () -> {
            String acc = "40817810" + String.format("%012d", rnd.nextLong(1_000_000_000_000L));
            byte[] payload = paymentJson(rnd, acc, size);
            bytes.addAndGet(payload.length);
            out.send(new ProducerRecord<String, byte[]>("pay.events", null, System.currentTimeMillis(), acc, payload));
            sent.incrementAndGet();
        });
        Thread.sleep(3000);
        exec.shutdownNow(); exec.awaitTermination(30, TimeUnit.SECONDS);
        out.close();
        System.out.println(String.format(Locale.ROOT, "  отправлено %d событий, средний размер значения %.0f байт", sent.get(), (double) bytes.get() / sent.get()));
        long[] T = total.sorted();
        long maxLag = lags.stream().mapToLong(Long::longValue).max().orElse(0);
        double meanLag = lags.stream().mapToLong(Long::longValue).average().orElse(0);
        System.out.println(String.format(Locale.ROOT,
                "λ=%.0f зап./с, %d партиций, %d потребителей (ρ=%.2f), ошибки %.2f, повторов %d, %d с: " +
                        "время в системе среднее %s мс, p99 %s мс, p99.9 %s мс; лаг средний %.0f, максимум %d; в повторы %d, в DLT %d, повторов не разобрано %d",
                lambda, P, C, lambda * E_S / 1e9 / C, p, r, sec, ms(Stats.mean(T)), ms(Stats.pct(T, .99)), ms(Stats.pct(T, .999)),
                meanLag, maxLag, toRetry.get(), dlt.get(), toRetry.get() - retryDone.get()));
    }
}
