package dev.team.sec;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.ApplicationContext;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.assertj.MockMvcTester;

/** @WebMvcTest без @Import: попадает ли SecurityConfig приложения в слайс? */
@WebMvcTest(TransferController.class)
class S1SliceWithoutImportTests {

    @Autowired MockMvcTester mvc;
    @Autowired ApplicationContext ctx;
    @MockitoBean TransferService service;

    @Test
    void anonymousGet() {
        System.out.println("   ► без @Import: SecurityConfig в контексте: " + ctx.getBeanNamesForType(SecurityConfig.class).length
                + "; цепочек SecurityFilterChain: " + ctx.getBeanNamesForType(org.springframework.security.web.SecurityFilterChain.class).length
                + "; аноним GET /api/transfers/T-1 → " + mvc.get().uri("/api/transfers/T-1").exchange().getResponse().getStatus()
                + "; аноним POST cancel → " + mvc.post().uri("/api/transfers/T-1/cancel").exchange().getResponse().getStatus());
    }

    @Test
    @WithMockUser(roles = "OPERATOR")
    void operatorPost() {
        System.out.println("   ► без @Import, @WithMockUser(OPERATOR): POST cancel → "
                + mvc.post().uri("/api/transfers/T-1/cancel").exchange().getResponse().getStatus());
    }
}
