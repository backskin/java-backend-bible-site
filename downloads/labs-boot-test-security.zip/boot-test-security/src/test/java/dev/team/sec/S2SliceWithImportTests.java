package dev.team.sec;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.assertj.MockMvcTester;

/** То же с @Import(SecurityConfig.class). */
@WebMvcTest(TransferController.class)
@Import(SecurityConfig.class)
class S2SliceWithImportTests {

    @Autowired MockMvcTester mvc;
    @MockitoBean TransferService service;

    @Test
    void anonymous() {
        System.out.println("   ► с @Import: аноним GET → " + mvc.get().uri("/api/transfers/T-1").exchange().getResponse().getStatus()
                + "; аноним POST cancel → " + mvc.post().uri("/api/transfers/T-1/cancel").exchange().getResponse().getStatus());
    }

    @Test
    @WithMockUser(roles = "OPERATOR")
    void operatorPost() {
        System.out.println("   ► с @Import, @WithMockUser(OPERATOR): POST cancel → "
                + mvc.post().uri("/api/transfers/T-1/cancel").exchange().getResponse().getStatus());
    }
}
