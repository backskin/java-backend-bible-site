package dev.team.sec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/** Переводы СБП: читать статус может любой, отменять — только оператор. */
@SpringBootApplication
public class SecuredTransferApp {
    public static void main(String[] args) { SpringApplication.run(SecuredTransferApp.class, args); }
}

@Service
class TransferService {
    String status(String id) { return "ACCEPTED"; }
    String cancel(String id) { return "CANCELLED"; }
}

@RestController
class TransferController {
    private final TransferService service;
    TransferController(TransferService service) { this.service = service; }

    @GetMapping("/api/transfers/{id}") String status(@PathVariable String id) { return service.status(id); }
    @PostMapping("/api/transfers/{id}/cancel") String cancel(@PathVariable String id) { return service.cancel(id); }
}

/** Своя политика безопасности приложения. */
@Configuration
@EnableWebSecurity
class SecurityConfig {
    @Bean
    SecurityFilterChain api(HttpSecurity http) throws Exception {
        return http.authorizeHttpRequests(r -> r
                        .requestMatchers(HttpMethod.GET, "/api/transfers/**").permitAll()
                        .anyRequest().hasRole("OPERATOR"))
                .httpBasic(Customizer.withDefaults())
                .csrf(c -> c.disable())
                .build();
    }
}
