# @WebMvcTest и Spring Security: почему без @Import своей конфигурации тест видит чужую цепочку фильтров

Стенд к главе 10, раздел о тестировании. Сервис переводов `SecuredTransferApp` (Spring Boot 4.1.1, Security) со своей `SecurityConfig` и тест на `@WebMvcTest`, запущенный без `@Import(SecurityConfig.class)` и с ним: сколько бинов `SecurityConfig` и цепочек `SecurityFilterChain` в контексте, что получает аноним на `GET` и `POST`, что получает `@WithMockUser` с ролью `OPERATOR`. Вывод автора - `s10-test-security.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q test
```

В IDEA есть конфигурации `SecuredTransferApp` и `mvn test`.

## Что должно получиться

Без `@Import` в контексте автоконфигурированная цепочка по умолчанию: аноним получает 401 на `GET` и 403 на `POST cancel`, и даже `OPERATOR` получает 403, потому что правил из `SecurityConfig` нет; с `@Import` аноним получает 200 на `GET` и 401 на `POST cancel`, а `OPERATOR` - 200.
