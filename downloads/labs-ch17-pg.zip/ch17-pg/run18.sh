#!/bin/sh
# Опыты главы 17 на PostgreSQL 18 в Docker. Запуск: ./run18.sh имя  — выполняет sql/имя.sql, вывод в pg18-имя.txt.
# Контейнер поднимается один раз и остаётся; ./run18.sh --fresh пересоздаёт его.
set -e
cd "$(dirname "$0")"
if [ "$1" = "--fresh" ] || ! docker ps --format '{{.Names}}' | grep -qx jbb-pg18; then
  docker rm -f jbb-pg18 >/dev/null 2>&1 || true
  docker run -d --name jbb-pg18 -e POSTGRES_PASSWORD=postgres --shm-size=1g postgres:18 \
    -c wal_level=logical -c log_checkpoints=on -c log_temp_files=0 -c log_autovacuum_min_duration=0 \
    -c shared_preload_libraries=pg_stat_statements -c track_io_timing=on >/dev/null
  until docker exec jbb-pg18 pg_isready -U postgres -q; do sleep 1; done
  # hypopg (гипотетические индексы, раздел 7.6) в образ не входит
  docker exec jbb-pg18 sh -c "apt-get update -qq && apt-get install -y -qq postgresql-18-hypopg" >/dev/null 2>&1
  sleep 2
  [ "$1" = "--fresh" ] && exit 0
fi
docker exec -i jbb-pg18 psql -U postgres -X -q -v ON_ERROR_STOP=1 < "sql/$1.sql" > "pg18-$1.txt" 2>&1
cat "pg18-$1.txt"
