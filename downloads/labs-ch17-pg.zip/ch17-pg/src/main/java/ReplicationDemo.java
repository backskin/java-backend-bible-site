import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;

import java.io.IOException;
import java.net.ServerSocket;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Stream;

/**
 * Физическая репликация PostgreSQL 15.5 на одной машине: мастер и горячий резерв, цена synchronous_commit,
 * остановка записи при падении синхронной реплики и «чтение своей записи» с реплики.
 * Зависимости Maven: io.zonky.test:embedded-postgres:2.0.7, бинарники сервера под вашу ОС
 * (io.zonky.test.postgres:embedded-postgres-binaries-windows-amd64:15.5.0), org.postgresql:postgresql:42.7.4.
 * Резерв запускается тем же postgres(.exe), который распаковала встроенная сборка. Запуск: main (около минуты).
 */
public class ReplicationDemo {

    static int freePort() throws IOException {
        try (ServerSocket s = new ServerSocket(0)) { return s.getLocalPort(); }
    }

    static Connection conn(int port) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:" + port + "/postgres", "postgres", "postgres");
        c.setAutoCommit(true);
        return c;
    }

    static void exec(Connection c, String sql) throws SQLException {
        try (Statement st = c.createStatement()) { st.execute(sql); }
    }

    static String one(Connection c, String sql) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) { return rs.next() ? rs.getString(1) : null; }
    }

    static void copyDir(Path from, Path to) throws IOException {
        try (Stream<Path> w = Files.walk(from)) {
            for (Path p : (Iterable<Path>) w::iterator) {
                Path t = to.resolve(from.relativize(p));
                if (Files.isDirectory(p)) Files.createDirectories(t);
                else Files.copy(p, t, StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    /** Сервер той же основной версии, что каталог данных: встроенные сборки разных версий лежат в одном каталоге. */
    static Path postgresBinary(Path dataDir) throws IOException {
        String major = Files.readString(dataDir.resolve("PG_VERSION")).trim();
        try (Stream<Path> w = Files.walk(Path.of(System.getProperty("java.io.tmpdir"), "embedded-pg"), 4)) {
            return w.filter(p -> p.getFileName().toString().matches("postgres(\\.exe)?") && p.getParent().getFileName().toString().equals("bin"))
                    .filter(p -> version(p).startsWith("postgres (PostgreSQL) " + major + ".")).findFirst().orElseThrow();
        }
    }

    static String version(Path binary) {
        try {
            Process v = new ProcessBuilder(binary.toString(), "--version").redirectErrorStream(true).start();
            return new String(v.getInputStream().readAllBytes()).trim();
        } catch (IOException e) {
            return "";
        }
    }

    static EmbeddedPostgres startPrimary(Path dir, int port) throws IOException {
        return EmbeddedPostgres.builder().setDataDirectory(dir).setCleanDataDirectory(false).setPort(port)
                .setServerConfig("fsync", "on").setServerConfig("synchronous_commit", "on")
                .setServerConfig("max_wal_senders", "5").setServerConfig("wal_level", "replica")
                .setServerConfig("hot_standby", "on").start();
    }

    static double commitMs(Connection c, String mode, int n) throws SQLException {
        exec(c, "SET synchronous_commit = " + mode);
        long t0 = System.nanoTime();
        for (int i = 0; i < n; i++) exec(c, "INSERT INTO t(v) VALUES ('x')");
        return (System.nanoTime() - t0) / 1e6 / n;
    }

    static void waitStandby(int standbyPort) throws Exception {
        for (int i = 0; i < 60; i++) {
            try (Connection c = conn(standbyPort)) { if ("t".equals(one(c, "SELECT pg_is_in_recovery()"))) return; } catch (SQLException e) { Thread.sleep(500); }
        }
        throw new IllegalStateException("резерв не поднялся");
    }

    public static void main(String[] args) throws Exception {
        Path base = Files.createTempDirectory("repl");
        Path primaryDir = base.resolve("primary"), standbyDir = base.resolve("standby");
        int primaryPort = freePort(), standbyPort = freePort();

        // 1. кластер мастера, таблица, остановка, холодная копия каталога данных в каталог резерва
        EmbeddedPostgres primary = startPrimary(primaryDir, primaryPort);
        try (Connection c = conn(primaryPort)) {
            exec(c, "CREATE TABLE t(id bigserial PRIMARY KEY, v text)");
            exec(c, "CHECKPOINT");
        }
        primary.close();
        copyDir(primaryDir, standbyDir);
        Files.deleteIfExists(standbyDir.resolve("postmaster.pid"));
        Files.createFile(standbyDir.resolve("standby.signal"));
        Files.writeString(standbyDir.resolve("postgresql.auto.conf"),
                "primary_conninfo = 'host=localhost port=" + primaryPort + " user=postgres application_name=s1'\n", StandardOpenOption.APPEND);

        primary = startPrimary(primaryDir, primaryPort);
        Process standby = new ProcessBuilder(postgresBinary(standbyDir).toString(), "-D", standbyDir.toString(), "-p", String.valueOf(standbyPort),
                "-c", "listen_addresses=localhost", "-c", "fsync=on", "-c", "hot_standby=on", "-c", "max_connections=300")
                .redirectErrorStream(true).redirectOutput(base.resolve("standby.log").toFile()).start();
        try { waitStandby(standbyPort); } catch (IllegalStateException e) { System.out.println(Files.readString(base.resolve("standby.log"))); throw e; }

        try (Connection p = conn(primaryPort); Connection s = conn(standbyPort)) {
            System.out.println("=== 10.2 мастер и горячий резерв подняты");
            System.out.println("  резерв в режиме восстановления: " + one(s, "SELECT pg_is_in_recovery()")
                    + "; на мастере walsender: " + one(p, "SELECT application_name || ' ' || state || ' ' || sync_state FROM pg_stat_replication"));
            try { exec(s, "INSERT INTO t(v) VALUES ('на резерве')"); }
            catch (SQLException e) { System.out.println("  запись на резерв: " + e.getMessage()); }

            // 2. цена коммита в разных режимах (300 одиночных вставок на режим)
            System.out.println("=== 5.4 и 10.2 цена одного коммита, мс (300 вставок подряд)");
            exec(p, "ALTER SYSTEM SET synchronous_standby_names = ''");
            exec(p, "SELECT pg_reload_conf()");
            Thread.sleep(500);
            for (String m : List.of("off", "local", "on")) System.out.printf("  реплика асинхронная, synchronous_commit = %-12s %.2f мс%n", m, commitMs(p, m, 300));
            exec(p, "ALTER SYSTEM SET synchronous_standby_names = 's1'");
            exec(p, "SELECT pg_reload_conf()");
            Thread.sleep(1500);
            System.out.println("  синхронный резерв: " + one(p, "SELECT sync_state FROM pg_stat_replication"));
            for (String m : List.of("local", "remote_write", "on", "remote_apply")) System.out.printf("  резерв синхронный, synchronous_commit = %-12s %.2f мс%n", m, commitMs(p, m, 300));

            // 3. чтение своей записи с резерва сразу после коммита
            System.out.println("=== 10.2 запись на мастере и немедленное чтение с резерва (200 попыток на режим)");
            for (String m : List.of("off", "on", "remote_apply")) {
                int missed = 0;
                exec(p, "SET synchronous_commit = " + m);
                for (int i = 0; i < 200; i++) {
                    String tag = m + "-" + i;
                    exec(p, "INSERT INTO t(v) VALUES ('" + tag + "')");
                    if (!"1".equals(one(s, "SELECT count(*) FROM t WHERE v = '" + tag + "'"))) missed++;
                }
                System.out.printf("  synchronous_commit = %-13s резерв не увидел свою запись сразу: %d из 200%n", m, missed);
            }
        }

        // 4. падение единственной синхронной реплики
        System.out.println("=== 10.2 падение единственной синхронной реплики");
        standby.destroyForcibly();
        standby.waitFor();
        ExecutorService ex = Executors.newSingleThreadExecutor();
        try (Connection p = conn(primaryPort); Connection admin = conn(primaryPort)) {
            exec(p, "SET synchronous_commit = on");
            long t0 = System.nanoTime();
            Future<String> commit = ex.submit(() -> { exec(p, "INSERT INTO t(v) VALUES ('после падения')"); return "завершён"; });
            try { System.out.println("  коммит после остановки реплики: " + commit.get(3, TimeUnit.SECONDS)); }
            catch (TimeoutException e) {
                System.out.println("  коммит не завершился за 3 с; состояние сессии на мастере: "
                        + one(admin, "SELECT wait_event_type || '/' || wait_event FROM pg_stat_activity WHERE query LIKE 'INSERT INTO t(v) VALUES (''после%' AND pid <> pg_backend_pid()"));
                exec(admin, "ALTER SYSTEM SET synchronous_standby_names = ''");
                exec(admin, "SELECT pg_reload_conf()");
                try { System.out.printf("  после снятия требования синхронности и reload: коммит %s через %d мс%n", commit.get(10, TimeUnit.SECONDS), (System.nanoTime() - t0) / 1_000_000); }
                catch (TimeoutException e2) {
                    exec(admin, "SELECT pg_cancel_backend(pid) FROM pg_stat_activity WHERE query LIKE 'INSERT INTO t(v) VALUES (''после%' AND pid <> pg_backend_pid()");
                    System.out.println("  reload не освободил сессию; после pg_cancel_backend: " + commit.get(10, TimeUnit.SECONDS));
                }
            }
            System.out.println("  строка после падения реплики на мастере записана: " + one(admin, "SELECT count(*) FROM t WHERE v = 'после падения'"));
        } finally {
            ex.shutdownNow();
        }
        primary.close();
        System.exit(0);
    }
}
