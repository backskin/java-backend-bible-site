import java.sql.*;

/**
 * Что ломается в режиме transaction у PgBouncer (раздел 11.3): SET без LOCAL, сессионный advisory-лок
 * и серверные prepared statements драйвера pgJDBC. Сервер и PgBouncer поднимает run-bouncer.sh;
 * аргумент — порт PgBouncer (по умолчанию 6432).
 *
 * В пуле два серверных соединения. Перед каждым запросом клиента A клиент B открывает транзакцию и держит одно из них;
 * PgBouncer по умолчанию отдаёт последнее освободившееся соединение (LIFO), поэтому B забирает то, на котором
 * только что работал A, и следующий запрос A уходит на другое серверное соединение.
 */
public class PgBouncerDemo {

    static Connection conn(int port) throws SQLException {
        return DriverManager.getConnection("jdbc:postgresql://localhost:" + port + "/postgres", "postgres", "postgres");
    }

    static String one(Connection c, String sql) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) { return rs.next() ? rs.getString(1) : null; }
    }

    /** Запрос клиента A, пока клиент B держит другое серверное соединение в открытой транзакции. */
    static String onOther(Connection a, Connection b, String sql) throws SQLException {
        one(b, "SELECT 1");
        try {
            return one(a, sql) + " (процесс " + one(a, "SELECT pg_backend_pid()") + ")";
        } finally {
            b.commit();
        }
    }

    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 6432;
        try (Connection a = conn(port); Connection b = conn(port)) {
            b.setAutoCommit(false);
            System.out.println("=== 11.3 PgBouncer перед PostgreSQL " + one(a, "SHOW server_version") + ", pool_mode = transaction, два серверных соединения");

            System.out.println("--- SET без LOCAL: параметр остаётся на серверном соединении");
            System.out.println("  клиент A: SET statement_timeout = '5s' на процессе " + one(a, "SELECT pg_backend_pid()"));
            try (Statement st = a.createStatement()) { st.execute("SET statement_timeout = '5s'"); }
            for (int i = 1; i <= 4; i++) {
                System.out.println("  клиент A, запрос " + i + ": statement_timeout = " + onOther(a, b, "SHOW statement_timeout"));
            }
            one(a, "SELECT 1");
            System.out.println("  клиент B, новая транзакция: statement_timeout = " + one(b, "SHOW statement_timeout")
                    + " (процесс " + one(b, "SELECT pg_backend_pid()") + ")");
            b.commit();

            System.out.println("--- сессионный advisory-лок: взяли в одной транзакции, отпускаем в другой");
            System.out.println("  клиент A берёт лок 42: " + one(a, "SELECT pg_try_advisory_lock(42)")
                    + " (процесс " + one(a, "SELECT pg_backend_pid()") + ")");
            System.out.println("  клиент A отпускает лок 42: " + onOther(a, b, "SELECT pg_advisory_unlock(42)"));
            System.out.println("  кто держит лок 42 на сервере: процесс " + one(a,
                    "SELECT string_agg(pid::text, ', ') FROM pg_locks WHERE locktype = 'advisory' AND objid = 42 AND granted"));
            for (int i = 0; i < 2; i++) { onOther(a, b, "SELECT pg_advisory_unlock_all()::text"); }
        }

        System.out.println("--- prepared statements: pgJDBC готовит оператор на сервере с пятого выполнения (prepareThreshold=5)");
        try (Connection a = conn(port); Connection b = conn(port)) {
            b.setAutoCommit(false);
            try (PreparedStatement ps = a.prepareStatement("SELECT count(*) FROM pg_class WHERE relpages > ?")) {
                for (int i = 1; i <= 8; i++) {
                    String step = "клиент B открывает транзакцию";
                    try {
                        one(b, "SELECT 1");
                        step = "клиент A выполняет подготовленный запрос";
                        ps.setInt(1, i);
                        try (ResultSet rs = ps.executeQuery()) { rs.next(); }
                        step = "клиент A узнаёт номер процесса";
                        System.out.printf("  выполнение %d: ok (процесс %s)%n", i, one(a, "SELECT pg_backend_pid()"));
                        step = "клиент B фиксирует транзакцию";
                        b.commit();
                    } catch (SQLException e) {
                        System.out.printf("  выполнение %d: ERROR, %s: %s%n", i, step, e.getMessage().lines().findFirst().orElse(""));
                        try { b.rollback(); } catch (SQLException ignored) { }
                    }
                }
            }
        }
    }
}
