import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;

import java.sql.*;
import java.util.*;

/**
 * Устройство PostgreSQL изнутри на живой базе. Зависимости: io.zonky.test:embedded-postgres:2.0.7,
 * бинарники сервера под вашу ОС и org.postgresql:postgresql. Запуск: main (Docker не нужен).
 */
public class PgInternals {

    static String url;

    static Connection open(boolean autocommit) throws SQLException {
        Connection c = DriverManager.getConnection(url, "postgres", "postgres");
        c.setAutoCommit(autocommit);
        return c;
    }

    static List<String> rows(Connection c, String sql) throws SQLException {
        List<String> out = new ArrayList<>();
        try (Statement st = c.createStatement(); ResultSet r = st.executeQuery(sql)) {
            int n = r.getMetaData().getColumnCount();
            while (r.next()) {
                StringBuilder sb = new StringBuilder();
                for (int i = 1; i <= n; i++) sb.append(i > 1 ? " | " : "").append(r.getString(i));
                out.add(sb.toString());
            }
        }
        return out;
    }

    static void print(Connection c, String title, String sql) throws SQLException {
        System.out.println(title);
        for (String row : rows(c, sql)) System.out.println("  " + row);
    }

    static void exec(Connection c, String sql) throws SQLException {
        try (Statement st = c.createStatement()) { st.execute(sql); }
    }

    static String one(Connection c, String sql) throws SQLException { return rows(c, sql).get(0); }

    /** Ключевые узлы плана: тип узла и пара «оценка строк / фактически строк». */
    static void plan(Connection c, String title, String sql) throws SQLException {
        System.out.println(title);
        for (String line : rows(c, "explain (analyze, costs on, timing off, summary off) " + sql)) {
            String t = line.strip();
            if (t.startsWith("->") || !t.startsWith("Planning") && !t.startsWith("Execution"))
                System.out.println("  " + line.replaceAll("\\(cost=[^)]*rows=(\\d+)[^)]*\\)", "(оценка строк=$1)").replaceAll("actual rows=(\\d+(\\.\\d+)?) loops=(\\d+)", "фактически строк=$1, циклов=$3"));
        }
    }

    static String topNode(Connection c, String sql) throws SQLException {
        String first = rows(c, "explain " + sql).get(0).strip();
        return first.replaceAll("\\s*\\(cost=.*", "");
    }

    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.builder()
                .setServerConfig("wal_level", "logical")
                .setServerConfig("autovacuum", "on")
                .setServerConfig("autovacuum_naptime", "1")
                .setServerConfig("fsync", "on")                       // во встроенной сборке по умолчанию off
                .setServerConfig("synchronous_commit", "on")
                .setServerConfig("max_replication_slots", "4")
                .start()) {
            url = pg.getJdbcUrl("postgres", "postgres");
            try (Connection c = open(true)) {
                exec(c, "create extension pageinspect");

                System.out.println("=== 3.1 многоверсионность: версии одной строки");
                exec(c, "create table acc(id int primary key, v int, k int)");
                exec(c, "create index acc_k on acc(k)");
                exec(c, "insert into acc values (1, 10, 100)");
                print(c, "после INSERT (ctid, xmin, xmax, v):", "select ctid, xmin, xmax, v from acc");
                exec(c, "update acc set v = 11 where id = 1");
                print(c, "после UPDATE неиндексированной колонки (ctid, xmin, xmax, v):", "select ctid, xmin, xmax, v from acc");
                print(c, "физически в странице (lp, t_xmin, t_xmax, t_ctid, HOT-флаги):",
                        "select lp, t_xmin, t_xmax, t_ctid, (t_infomask2 & 16384) > 0 as hot_updated, (t_infomask2 & 32768) > 0 as heap_only "
                                + "from heap_page_items(get_raw_page('acc', 0)) order by lp");

                System.out.println("=== 3.5 UPDATE как DELETE + INSERT: индексированная колонка");
                exec(c, "update acc set k = 200 where id = 1");
                print(c, "после UPDATE индексированной колонки k:",
                        "select lp, t_xmin, t_xmax, t_ctid, (t_infomask2 & 16384) > 0 as hot_updated, (t_infomask2 & 32768) > 0 as heap_only "
                                + "from heap_page_items(get_raw_page('acc', 0)) order by lp");
                exec(c, "vacuum acc");
                print(c, "после VACUUM (lp_flags: 1 нормальная, 2 перенаправление, 3 мёртвая, 0 свободна):",
                        "select lp, lp_flags, t_xmin, t_xmax from heap_page_items(get_raw_page('acc', 0)) order by lp");
            }

            System.out.println("=== 3.8 xmin-горизонт: длинная транзакция не даёт VACUUM убрать мёртвые версии");
            try (Connection c = open(true); Connection longTx = open(false)) {
                exec(c, "create table ledger(id int primary key, v int)");
                exec(c, "insert into ledger select g, 0 from generate_series(1, 2000) g");
                exec(longTx, "set transaction isolation level repeatable read");
                one(longTx, "select count(*) from ledger");                 // снимок взят и удерживается
                exec(c, "update ledger set v = v + 1");                     // 2000 мёртвых версий
                print(c, "горизонт, который держит длинная транзакция (pg_stat_activity.backend_xmin):",
                        "select count(*) filter (where backend_xmin is not null and state = 'idle in transaction') as держат_горизонт from pg_stat_activity");
                try (Statement st = c.createStatement()) {
                    st.execute("vacuum (verbose) ledger");
                    for (SQLWarning w = st.getWarnings(); w != null; w = w.getNextWarning())
                        if (w.getMessage().contains("tuples:") || w.getMessage().contains("removable cutoff"))
                            for (String l : w.getMessage().split("\n")) if (l.contains("tuples:")) System.out.println("  до закрытия транзакции: " + l.strip());
                }
                longTx.commit();
                try (Statement st = c.createStatement()) {
                    st.execute("vacuum (verbose) ledger");
                    for (SQLWarning w = st.getWarnings(); w != null; w = w.getNextWarning())
                        for (String l : w.getMessage().split("\n")) if (l.contains("tuples:")) System.out.println("  после закрытия транзакции: " + l.strip());
                }
            }

            System.out.println("=== 4.3 autovacuum: порог = 50 + 0,2 × число строк");
            try (Connection c = open(true)) {
                print(c, "настройки (threshold, scale_factor, naptime):",
                        "select current_setting('autovacuum_vacuum_threshold'), current_setting('autovacuum_vacuum_scale_factor'), current_setting('autovacuum_naptime')");
                for (String t : new String[]{"under", "over"}) {
                    exec(c, "create table " + t + "(id int primary key, v int)");
                    exec(c, "insert into " + t + " select g, 0 from generate_series(1, 1000) g");
                    exec(c, "analyze " + t);
                }
                exec(c, "delete from under where id <= 200");               // 200 мёртвых версий: ниже порога 50 + 0,2*1000 = 250
                exec(c, "delete from over where id <= 400");                // 400 мёртвых версий: выше порога
                print(c, "сразу после удаления (таблица | n_dead_tup):",
                        "select relname, n_dead_tup from pg_stat_user_tables where relname in ('under','over') order by relname desc");
                int waited = 0;
                while (waited < 40 && Integer.parseInt(one(c, "select autovacuum_count from pg_stat_user_tables where relname = 'over'")) == 0) {
                    exec(c, "select pg_sleep(1)");                      // ждём: autovacuum просыпается раз в autovacuum_naptime
                    waited++;
                }
                System.out.println("autovacuum дошёл до таблицы over через " + waited + " с");
                print(c, "итог (таблица | n_dead_tup | запусков autovacuum):",
                        "select relname, n_dead_tup, autovacuum_count from pg_stat_user_tables where relname in ('under','over') order by relname desc");
            }

            System.out.println("=== 5.1 и 5.4 журнал WAL и цена fsync");
            try (Connection c = open(true)) {
                print(c, "настройки (wal_level, fsync, synchronous_commit):",
                        "select current_setting('wal_level'), current_setting('fsync'), current_setting('synchronous_commit')");
                exec(c, "create table pay(id serial primary key, amount int)");
                String before = one(c, "select pg_current_wal_lsn()");
                exec(c, "insert into pay(amount) select g from generate_series(1, 10000) g");
                System.out.println("WAL за вставку 10 000 строк: " + one(c, "select pg_wal_lsn_diff(pg_current_wal_lsn(), '" + before + "')") + " байт");
                for (String mode : new String[]{"on", "off"}) {
                    exec(c, "set synchronous_commit = " + mode);
                    long t0 = System.nanoTime();
                    for (int i = 0; i < 300; i++) exec(c, "insert into pay(amount) values (1)");     // каждая вставка — свой коммит
                    System.out.printf("synchronous_commit = %-3s: 300 отдельных коммитов, %.2f мс на коммит%n", mode, (System.nanoTime() - t0) / 1e6 / 300);
                }
            }

            System.out.println("=== 7.2 план запроса: оценка и факт");
            try (Connection c = open(true)) {
                exec(c, "create table orders(id int primary key, client_id int, status text, amount int)");
                exec(c, "insert into orders select g, g % 1000, case when g % 100 = 0 then 'NEW' else 'DONE' end, g % 5000 from generate_series(1, 200000) g");
                exec(c, "create index orders_client on orders(client_id)");
                exec(c, "analyze orders");
                plan(c, "по первичному ключу:", "select * from orders where id = 12345");
                plan(c, "по неселективному условию (99% строк):", "select * from orders where status = 'DONE'");
                plan(c, "по индексированному client_id (200 строк из 200 000):", "select * from orders where client_id = 7");

                System.out.println("=== 8.1 B-tree: что индекс умеет и чего нет");
                exec(c, "create table clients(id int primary key, name text, a int, b int)");
                exec(c, "insert into clients select g, 'client-' || g, g % 100, g % 7 from generate_series(1, 100000) g");
                exec(c, "create index clients_name on clients(name)");
                exec(c, "create index clients_ab on clients(a, b)");
                exec(c, "analyze clients");
                String[][] cases = {
                        {"name = 'client-500'", "равенство"},
                        {"name like 'client-50%'", "like 'префикс%' при collation базы"},
                        {"name like '%500'", "like '%суффикс'"},
                        {"lower(name) = 'client-500'", "функция над колонкой"},
                        {"a = 5 and b = 3", "составной индекс (a, b), обе колонки"},
                        {"a = 5", "составной индекс, только первая колонка"},
                        {"b = 3", "составной индекс, только вторая колонка"},
                };
                for (String[] cs : cases)
                    System.out.printf("  %-44s -> %s%n", cs[1] + ": " + cs[0], topNode(c, "select * from clients where " + cs[0]));
                exec(c, "create index clients_lower on clients(lower(name))");
                exec(c, "analyze clients");
                System.out.printf("  %-44s -> %s%n", "после индекса по lower(name)", topNode(c, "select * from clients where lower(name) = 'client-500'"));
                print(c, "collation базы:", "select datcollate from pg_database where datname = current_database()");
                exec(c, "create index clients_name_pat on clients(name text_pattern_ops)");
                exec(c, "analyze clients");
                System.out.printf("  %-44s -> %s%n", "like 'префикс%' после text_pattern_ops", topNode(c, "select * from clients where name like 'client-50%'"));

                System.out.println("=== 6.4 стратегии соединения: nested loop, hash, merge");
                exec(c, "create table big(id int primary key, c int)");
                exec(c, "insert into big select g, g % 1000 from generate_series(1, 100000) g");
                exec(c, "create table small(c int primary key, label text)");
                exec(c, "insert into small select g, 'c' || g from generate_series(0, 999) g");
                exec(c, "analyze big"); exec(c, "analyze small");
                exec(c, "create table big2(id int primary key, d int)");
                exec(c, "insert into big2 select g, g % 7 from generate_series(1, 100000) g");
                exec(c, "analyze big2");
                String small = "select * from big b join small s on s.c = b.c where b.id < 50000";
                String large = "select * from big b join big2 d on d.id = b.id";
                String tiny = "select * from big b join small s on s.c = b.c where b.id = 77";
                System.out.println("  маленький справочник и 50 000 строк:  " + joinNode(c, small));
                System.out.println("  две таблицы по 100 000 строк по PK:   " + joinNode(c, large));
                exec(c, "set enable_hashjoin = off");
                System.out.println("    то же при enable_hashjoin = off:    " + joinNode(c, large));
                exec(c, "set enable_mergejoin = off");
                System.out.println("    то же без hash и merge:             " + joinNode(c, large));
                exec(c, "reset all");
                System.out.println("  одна строка из big (id = 77):         " + joinNode(c, tiny));
            }

            System.out.println("=== 10.4 логическая репликация: что видит CDC");
            try (Connection c = open(true)) {
                exec(c, "create table events(id int primary key, status text)");
                exec(c, "select pg_create_logical_replication_slot('cdc', 'test_decoding')");
                exec(c, "insert into events values (1, 'NEW')");
                exec(c, "update events set status = 'PAID' where id = 1");
                exec(c, "delete from events where id = 1");
                print(c, "изменения, прочитанные из слота (test_decoding):",
                        "select data from pg_logical_slot_get_changes('cdc', null, null)");
                exec(c, "select pg_drop_replication_slot('cdc')");
            }

            System.out.println("=== 11.3 цена соединения: зачем пул");
            long t0 = System.nanoTime();
            for (int i = 0; i < 100; i++) try (Connection c = open(true)) { one(c, "select 1"); }
            double fresh = (System.nanoTime() - t0) / 1e6 / 100;
            double reuse;
            try (Connection c = open(true)) {
                one(c, "select 1");
                t0 = System.nanoTime();
                for (int i = 0; i < 100; i++) one(c, "select 1");
                reuse = (System.nanoTime() - t0) / 1e6 / 100;
            }
            System.out.printf("новое соединение на каждый запрос: %.2f мс, одно соединение: %.3f мс%n", fresh, reuse);
            List<Connection> held = new ArrayList<>();
            for (int i = 0; i < 50; i++) held.add(open(true));
            try (Connection c = open(true)) {
                System.out.println("процессов-бэкендов в pg_stat_activity при 50 открытых соединениях: "
                        + one(c, "select count(*) from pg_stat_activity where backend_type = 'client backend'"));
            }
            for (Connection h : held) h.close();
        }
    }

    static String joinNode(Connection c, String sql) throws SQLException {
        for (String l : rows(c, "explain " + sql)) {
            String t = l.strip();
            if (t.startsWith("Hash Join") || t.startsWith("Merge Join") || t.startsWith("Nested Loop"))
                return t.replaceAll("\\s*\\(cost=.*", "");
        }
        return "не найден";
    }
}
