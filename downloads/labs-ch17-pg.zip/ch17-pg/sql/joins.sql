-- Глава 17, раздел 6.4: сорванная оценка и Nested Loop, Hash Join и work_mem, Memoize. Скрипт дословно из главы.
-- Запуск на PostgreSQL 15: ./run15.sh joins (вывод в pg15-joins.txt)
\timing off
CREATE TABLE dim AS SELECT g AS id, 'cat-' || (g % 50) AS name FROM generate_series(1, 2000) g;
ALTER TABLE dim ADD PRIMARY KEY (id);
CREATE TABLE fact(id bigserial PRIMARY KEY, dim_id int NOT NULL, amount numeric NOT NULL);
CREATE INDEX ON fact(dim_id);
INSERT INTO fact(dim_id, amount) SELECT 1 + (g % 2000), g FROM generate_series(1, 20000) g;
ANALYZE dim;
ANALYZE fact;
-- 1. устаревшая статистика: после ANALYZE в fact мало строк с dim_id = 7, затем добавили 500 000 таких строк без нового ANALYZE
INSERT INTO fact(dim_id, amount) SELECT 7, g FROM generate_series(1, 500000) g;
CREATE TABLE big AS SELECT g AS id, g % 1000 AS v FROM generate_series(1, 1000000) g;
ALTER TABLE big ADD PRIMARY KEY (id);
ANALYZE big;
EXPLAIN (ANALYZE, TIMING OFF, SUMMARY ON) SELECT count(*) FROM fact f JOIN big b ON b.id = f.amount::int WHERE f.dim_id = 7;
ANALYZE fact;
EXPLAIN (ANALYZE, TIMING OFF, SUMMARY ON) SELECT count(*) FROM fact f JOIN big b ON b.id = f.amount::int WHERE f.dim_id = 7;
-- 2. Hash Join и work_mem: хеш-таблица по большей стороне не помещается в 64 КБ
SET work_mem = '64kB';
EXPLAIN (ANALYZE, TIMING OFF, SUMMARY ON) SELECT count(*) FROM fact a JOIN fact b ON a.id = b.id + 1;
SET work_mem = '256MB';
EXPLAIN (ANALYZE, TIMING OFF, SUMMARY ON) SELECT count(*) FROM fact a JOIN fact b ON a.id = b.id + 1;
RESET work_mem;
-- 3. Memoize: повторяющиеся ключи внешней стороны (50 категорий, 20 000 строк)
CREATE TABLE cat AS SELECT g AS id, repeat('x', 200) AS descr FROM generate_series(0, 49) g;
ALTER TABLE cat ADD PRIMARY KEY (id);
CREATE TABLE ev AS SELECT g AS id, g % 50 AS cat_id FROM generate_series(1, 200000) g;
ANALYZE cat;
ANALYZE ev;
SET enable_hashjoin = off;
SET enable_mergejoin = off;
SET enable_memoize = on;
EXPLAIN (ANALYZE, TIMING OFF, SUMMARY ON) SELECT count(c.descr) FROM ev e JOIN cat c ON c.id = e.cat_id;
SET enable_memoize = off;
EXPLAIN (ANALYZE, TIMING OFF, SUMMARY ON) SELECT count(c.descr) FROM ev e JOIN cat c ON c.id = e.cat_id;
