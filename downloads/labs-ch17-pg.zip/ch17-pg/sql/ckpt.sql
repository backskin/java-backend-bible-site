-- Глава 17, разделы 5.3 и 5.8: контрольные точки по объёму журнала при маленьком max_wal_size.
-- Запуск: ./run18.sh ckpt, затем строки журнала сервера: docker logs jbb-pg18 2>&1 | grep -A2 checkpoint
ALTER SYSTEM SET max_wal_size = '64MB';
ALTER SYSTEM SET checkpoint_warning = '30s';
SELECT pg_reload_conf();
SELECT pg_sleep(1);
SELECT num_timed, num_requested FROM pg_stat_checkpointer;
\echo === запись 600 МБ журнала при max_wal_size = 64MB
DROP TABLE IF EXISTS ck;
CREATE TABLE ck (id int, pad text);
INSERT INTO ck SELECT i, repeat('x', 100) FROM generate_series(1, 4000000) i;
SELECT num_timed, num_requested, write_time, sync_time, buffers_written FROM pg_stat_checkpointer;
ALTER SYSTEM RESET max_wal_size;
ALTER SYSTEM RESET checkpoint_warning;
SELECT pg_reload_conf();
DROP TABLE ck;
