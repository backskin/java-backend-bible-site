-- Глава 17, разделы 3.7 и 7.9: Index Only Scan до и после VACUUM (карта видимости).
-- Запуск: ./run18.sh vis
\echo === 3.7 и 7.9 orders: 2 000 000 поручений, 50 клиентов, autovacuum для таблицы выключен
DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
  id          bigint PRIMARY KEY,
  customer_id int NOT NULL,
  status      text NOT NULL,
  amount      numeric(12,2) NOT NULL,
  created_at  timestamptz NOT NULL
) WITH (autovacuum_enabled = false);
INSERT INTO orders
SELECT i, i % 50, 'DONE', (i % 100000) / 100.0, timestamptz '2026-01-01' + i * interval '10 seconds'
FROM generate_series(1, 2000000) i;
CREATE INDEX idx_orders_cust_covering ON orders (customer_id) INCLUDE (amount, created_at);
ANALYZE orders;
SELECT relpages, relallvisible FROM pg_class WHERE relname = 'orders';
\echo --- до VACUUM
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, SUMMARY ON)
SELECT customer_id, amount, created_at FROM orders WHERE customer_id = 12;
VACUUM (ANALYZE) orders;
SELECT relpages, relallvisible,
       round(100.0 * relallvisible / nullif(relpages, 0), 1) AS visible_pct
FROM pg_class WHERE relname = 'orders';
\echo --- после VACUUM
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, SUMMARY ON)
SELECT customer_id, amount, created_at FROM orders WHERE customer_id = 12;
\echo --- после обновления 5% строк: страницы потеряли пометку all-visible
UPDATE orders SET status = 'CHECKED' WHERE id % 20 = 0;
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, SUMMARY ON)
SELECT customer_id, amount, created_at FROM orders WHERE customer_id = 12;
