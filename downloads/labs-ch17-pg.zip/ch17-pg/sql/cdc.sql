-- Глава 17, разделы 10.4 и 10.6: что приходит в логический слот при REPLICA IDENTITY DEFAULT и FULL,
-- сколько журнала это стоит и как забытый слот держит pg_wal. Запуск: ./run18.sh cdc
DROP TABLE IF EXISTS events;
CREATE TABLE events (id int PRIMARY KEY, status text, amount numeric(12,2), payload text);
INSERT INTO events SELECT i, 'NEW', i, repeat('x', 200) FROM generate_series(1, 100000) i;
SELECT pg_drop_replication_slot(slot_name) FROM pg_replication_slots WHERE slot_name IN ('cdc', 'forgotten');
SELECT 'slot' AS step, lsn FROM pg_create_logical_replication_slot('cdc', 'test_decoding');

\echo === 10.4 REPLICA IDENTITY DEFAULT (первичный ключ)
UPDATE events SET status = 'PAID' WHERE id = 1;
DELETE FROM events WHERE id = 2;
SELECT data FROM pg_logical_slot_get_changes('cdc', NULL, NULL);

\echo === 10.4 REPLICA IDENTITY FULL
ALTER TABLE events REPLICA IDENTITY FULL;
UPDATE events SET status = 'PAID' WHERE id = 3;
DELETE FROM events WHERE id = 4;
SELECT data FROM pg_logical_slot_get_changes('cdc', NULL, NULL);

\echo === 10.4 объём WAL: обновление 50 000 строк при DEFAULT и FULL
CREATE OR REPLACE FUNCTION wal_of(sql text) RETURNS text LANGUAGE plpgsql AS $$
DECLARE l0 pg_lsn;
BEGIN
  CHECKPOINT;
  l0 := pg_current_wal_insert_lsn();
  EXECUTE sql;
  RETURN pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_insert_lsn(), l0));
END $$;
-- полные образы страниц уравнивают обе попытки: CHECKPOINT перед каждой
ALTER TABLE events REPLICA IDENTITY DEFAULT;
SELECT 'DEFAULT' AS identity, wal_of('UPDATE events SET status = ''DONE'' WHERE id % 2 = 0') AS wal;
ALTER TABLE events REPLICA IDENTITY FULL;
SELECT 'FULL' AS identity, wal_of('UPDATE events SET status = ''SENT'' WHERE id % 2 = 0') AS wal;
SELECT pg_drop_replication_slot('cdc');

\echo === 10.6 забытый слот держит журнал
SELECT 'slot' AS step, lsn FROM pg_create_logical_replication_slot('forgotten', 'test_decoding');
CREATE TABLE IF NOT EXISTS wal_filler (id int, pad text);
INSERT INTO wal_filler SELECT i, repeat('y', 100) FROM generate_series(1, 10000000) i;
CHECKPOINT;
SELECT slot_name, active, wal_status,
       pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn)) AS retained
FROM pg_replication_slots WHERE slot_name = 'forgotten';
SELECT pg_size_pretty(sum(size)) AS pg_wal_size, count(*) AS files FROM pg_ls_waldir();
SHOW max_wal_size;
SELECT pg_drop_replication_slot('forgotten');
CHECKPOINT;
SELECT pg_size_pretty(sum(size)) AS pg_wal_after_drop, count(*) AS files FROM pg_ls_waldir();
DROP TABLE wal_filler;
