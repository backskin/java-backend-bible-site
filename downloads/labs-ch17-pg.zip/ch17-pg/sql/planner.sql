-- Глава 17, разделы 6.6, 6.11, 6.12, 6.13: JIT, расширенная статистика, пакеты Hash Join, сортировка на диске,
-- Memoize и число запущенных параллельных процессов. Запуск: ./run18.sh planner
\echo === 6.11 связанные колонки city и region
DROP TABLE IF EXISTS addresses;
CREATE TABLE addresses (id bigserial, city text, region text, street text);
INSERT INTO addresses (city, region, street)
SELECT c.city, c.region, 'street ' || i
FROM generate_series(1, 1000000) i
CROSS JOIN LATERAL (
  SELECT (ARRAY['Казань','Альметьевск','Уфа','Стерлитамак'])[1 + (i % 4)] AS city,
         (ARRAY['Татарстан','Татарстан','Башкортостан','Башкортостан'])[1 + (i % 4)] AS region
) c;
ANALYZE addresses;
EXPLAIN SELECT * FROM addresses WHERE city = 'Казань' AND region = 'Татарстан';
SELECT count(*) AS actual FROM addresses WHERE city = 'Казань' AND region = 'Татарстан';
CREATE STATISTICS st_addr (dependencies, ndistinct, mcv) ON city, region FROM addresses;
ANALYZE addresses;
EXPLAIN SELECT * FROM addresses WHERE city = 'Казань' AND region = 'Татарстан';
SELECT stxname, stxkeys, stxddependencies, stxdndistinct
FROM pg_statistic_ext JOIN pg_statistic_ext_data ON oid = stxoid WHERE stxname = 'st_addr';

\echo === 6.12 Hash Join не помещается в work_mem: пакеты
DROP TABLE IF EXISTS j_customer, j_orders;
CREATE TABLE j_customer AS SELECT i AS id, 'client-' || i AS name FROM generate_series(1, 2000000) i;
CREATE TABLE j_orders AS SELECT i AS id, (i::bigint * 7919) % 2000000 + 1 AS customer_id, (i % 100000) / 100.0 AS amount
FROM generate_series(1, 4000000) i;
ANALYZE j_customer, j_orders;
SET max_parallel_workers_per_gather = 0;
SET work_mem = '2MB';
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
SELECT count(*), sum(o.amount) FROM j_orders o JOIN j_customer c ON c.id = o.customer_id;
\echo --- оценка внутренней стороны занижена: таблица выросла после ANALYZE
INSERT INTO j_customer SELECT i, 'client-' || i FROM generate_series(2000001, 6000000) i;
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
SELECT count(*), sum(o.amount) FROM j_orders o JOIN j_customer c ON c.id = o.customer_id;
ANALYZE j_customer;

\echo === 6.12 сортировка на диске и в памяти
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
SELECT id FROM j_orders ORDER BY amount, id OFFSET 3999999;
SET work_mem = '512MB';
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
SELECT id FROM j_orders ORDER BY amount, id OFFSET 3999999;
SET work_mem = '4MB';
EXPLAIN (ANALYZE, COSTS OFF)
SELECT id FROM j_orders ORDER BY amount, id LIMIT 100;

\echo === 6.12 Memoize: повторяющийся ключ на внутренней стороне Nested Loop
DROP TABLE IF EXISTS m_orders, m_customer;
CREATE TABLE m_customer AS SELECT i AS id, 'client-' || i AS name FROM generate_series(1, 1000000) i;
ALTER TABLE m_customer ADD PRIMARY KEY (id);
CREATE TABLE m_orders AS SELECT i AS id, (i % 1000) + 1 AS customer_id FROM generate_series(1, 250000) i;
ANALYZE m_customer, m_orders;
EXPLAIN (ANALYZE, COSTS OFF)
SELECT count(c.name) FROM m_orders o JOIN m_customer c ON c.id = o.customer_id;

\echo === 6.12 Gather: запланировано 4 процесса, свободно 2
SET work_mem = '4MB';
SET max_parallel_workers_per_gather = 4;
SET max_parallel_workers = 2;
SET parallel_setup_cost = 0;
SET min_parallel_table_scan_size = 0;
EXPLAIN (ANALYZE, COSTS OFF)
SELECT count(*) FROM j_orders WHERE amount > 10;
RESET max_parallel_workers;
RESET parallel_setup_cost;
RESET min_parallel_table_scan_size;

\echo === 6.6 и 6.13 JIT: 300 секций, 18 млн строк, оценка стоимости выше всех трёх порогов JIT
DROP TABLE IF EXISTS txn_part;
CREATE TABLE txn_part (id bigint, merchant_id int, amount numeric(12,2), fee numeric(12,2), created_at date)
PARTITION BY HASH (id);
SELECT format('CREATE TABLE txn_part_%s PARTITION OF txn_part FOR VALUES WITH (MODULUS 300, REMAINDER %s)', r, r)
FROM generate_series(0, 299) r \gexec
INSERT INTO txn_part SELECT i, i % 400, (i % 100000) / 100.0, (i % 300) / 100.0, date '2026-01-01' + (i % 300)
FROM generate_series(1, 18000000) i;
ANALYZE txn_part;
SET max_parallel_workers_per_gather = 0;
SHOW jit;
SHOW jit_above_cost;
-- план на 1500 строк (по узлу на секцию): печатаем верх плана, блок JIT и время
CREATE OR REPLACE FUNCTION explain_lines(q text, pat text) RETURNS SETOF text LANGUAGE plpgsql AS $$
DECLARE line text;
BEGIN
  FOR line IN EXECUTE 'EXPLAIN (ANALYZE, SUMMARY ON) ' || q LOOP
    IF line ~ pat THEN RETURN NEXT line; END IF;
  END LOOP;
END $$;
SELECT explain_lines($q$SELECT merchant_id, sum(amount - fee), avg(amount * 1.2) FROM txn_part
WHERE created_at >= date '2026-03-01' AND amount > fee * 3 GROUP BY merchant_id ORDER BY 2 DESC LIMIT 5$q$,
  '^Limit|^ +->  (Sort|HashAggregate|Append) |^JIT|Functions:|Options:|^ +Timing:|^Execution') AS jit_on;
\echo --- тот же запрос с jit = off
SET jit = off;
SELECT explain_lines($q$SELECT merchant_id, sum(amount - fee), avg(amount * 1.2) FROM txn_part
WHERE created_at >= date '2026-03-01' AND amount > fee * 3 GROUP BY merchant_id ORDER BY 2 DESC LIMIT 5$q$,
  '^Limit|^Execution') AS jit_off;
