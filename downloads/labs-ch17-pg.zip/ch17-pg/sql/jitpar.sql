-- Глава 17, раздел 6.13: компилирует ли JIT заново в каждом параллельном процессе. Нужна таблица txn_part из planner.sql.
-- Запуск: ./run18.sh jitpar
CREATE OR REPLACE FUNCTION explain_verbose_lines(q text, pat text) RETURNS SETOF text LANGUAGE plpgsql AS $$
DECLARE line text;
BEGIN
  FOR line IN EXECUTE 'EXPLAIN (ANALYZE, VERBOSE, SUMMARY ON) ' || q LOOP
    IF line ~ pat THEN RETURN NEXT line; END IF;
  END LOOP;
END $$;
SET max_parallel_workers_per_gather = 2;
SELECT explain_verbose_lines($q$SELECT merchant_id, sum(amount - fee), avg(amount * 1.2) FROM txn_part
WHERE created_at >= date '2026-03-01' AND amount > fee * 3 GROUP BY merchant_id ORDER BY 2 DESC LIMIT 5$q$,
  '^Limit|Workers Launched|^JIT|JIT for worker|Functions:|^ +Timing:|^Execution') AS jit_parallel;
