-- Глава 17, разделы 2.3 и 2.4: выравнивание колонок и методы сжатия TOAST.
-- Запуск: ./run18.sh storage  (вывод в pg18-storage.txt)
\timing off
\echo === 2.3 порядок колонок и выравнивание (1 000 000 строк)
DROP TABLE IF EXISTS payment_bad, payment_good;
CREATE TABLE payment_bad (
  is_active  boolean,
  amount     bigint,
  status     smallint,
  created_at timestamptz,
  currency   char(3),
  id         bigint
);
CREATE TABLE payment_good (
  id         bigint,
  amount     bigint,
  created_at timestamptz,
  status     smallint,
  is_active  boolean,
  currency   char(3)
);
INSERT INTO payment_bad  SELECT true, i, 1, now(), 'RUB', i FROM generate_series(1,1000000) i;
INSERT INTO payment_good SELECT i, i, now(), 1, true, 'RUB' FROM generate_series(1,1000000) i;
SELECT pg_size_pretty(pg_relation_size('payment_bad')) AS bad_size,
       pg_size_pretty(pg_relation_size('payment_good')) AS good_size,
       (SELECT pg_column_size(t.*) FROM payment_bad t LIMIT 1) AS bad_row,
       (SELECT pg_column_size(t.*) FROM payment_good t LIMIT 1) AS good_row;

\echo === 2.3 накладные расходы: таблица из двух int4
DROP TABLE IF EXISTS ref_pair;
CREATE TABLE ref_pair (a int4, b int4);
INSERT INTO ref_pair SELECT i, i FROM generate_series(1,1000000) i;
SELECT pg_relation_size('ref_pair') / 1000000.0 AS bytes_per_row,
       (SELECT pg_column_size(t.*) FROM ref_pair t LIMIT 1) AS tuple_size;

\echo === 2.4 pglz против lz4: 20 000 документов text по ~12 КБ, исходник хранится без сжатия
DROP TABLE IF EXISTS doc_src, doc_pglz, doc_lz4;
CREATE TABLE doc_src (id int, body text STORAGE EXTERNAL);
INSERT INTO doc_src
SELECT i, (SELECT string_agg(format('{"op":"payment","n":%s,"amount":%s,"merchant":"merchant-%s","status":"DONE"}',
                                    g, (g * 7919 + i) % 100000, (g + i) % 50), ',')
           FROM generate_series(1, 150) g)
FROM generate_series(1, 20000) i;
CREATE TABLE doc_pglz (id int, body text COMPRESSION pglz);
CREATE TABLE doc_lz4  (id int, body text COMPRESSION lz4);
SELECT avg(octet_length(body))::int AS raw_bytes FROM doc_src;
-- прогрев: исходник целиком в кэше
SELECT sum(length(body)) FROM doc_src;
\timing on
\echo вставка со сжатием pglz
INSERT INTO doc_pglz SELECT * FROM doc_src;
\echo вставка со сжатием lz4
INSERT INTO doc_lz4 SELECT * FROM doc_src;
\echo чтение с разжатием: pglz, lz4, без сжатия
SELECT sum(length(body)) FROM doc_pglz;
SELECT sum(length(body)) FROM doc_lz4;
SELECT sum(length(body)) FROM doc_src;
\timing off
SELECT 'pglz' AS method, pg_size_pretty(pg_total_relation_size('doc_pglz')) AS total,
       avg(pg_column_size(body))::int AS stored_bytes FROM doc_pglz UNION ALL
SELECT 'lz4', pg_size_pretty(pg_total_relation_size('doc_lz4')), avg(pg_column_size(body))::int FROM doc_lz4 UNION ALL
SELECT 'none', pg_size_pretty(pg_total_relation_size('doc_src')), avg(pg_column_size(body))::int FROM doc_src;
