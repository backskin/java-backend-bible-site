-- Глава 17, разделы 7.2, 7.6, 7.7, 7.8: планы для разборов в главе 7 (7.9 — в vis.sql).
-- Запуск: ./run18.sh plans
SET max_parallel_workers_per_gather = 0;

\echo === общие таблицы: 1 000 000 клиентов, 3 000 000 поручений за 300 дней
DROP TABLE IF EXISTS e_orders, customer;
CREATE TABLE customer (id bigint PRIMARY KEY, name text, segment text, address text);
INSERT INTO customer SELECT i, 'client-' || i, (ARRAY['retail','sme','corp'])[1 + i % 3], repeat('street ', 10) || i
FROM generate_series(1, 1000000) i;
CREATE TABLE e_orders (
  id          bigint PRIMARY KEY,
  customer_id bigint NOT NULL,
  status      text NOT NULL,
  amount      numeric(12,2) NOT NULL,
  created_at  timestamptz NOT NULL
) WITH (autovacuum_enabled = false);
-- поручения равномерно за 300 дней; статус NEW только у поручений последних суток
INSERT INTO e_orders
SELECT i, (i::bigint * 7919) % 1000000 + 1,
       CASE WHEN i > 2990000 THEN 'NEW' ELSE 'DONE' END,
       (i % 100000) / 100.0,
       timestamptz '2026-01-01 00:00+03' + (i - 1) * interval '8640 milliseconds'
FROM generate_series(1, 3000000) i;
CREATE INDEX idx_order_status  ON e_orders (status);
CREATE INDEX idx_orders_created ON e_orders (created_at);
VACUUM ANALYZE e_orders, customer;
SELECT min(created_at), max(created_at) FROM e_orders WHERE status = 'NEW';

\echo === 7.7 связанные условия: диапазон по created_at и равенство по status
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT o.id, o.amount, c.name FROM e_orders o JOIN customer c ON c.id = o.customer_id
WHERE o.created_at >= '2026-10-27 00:00+03' AND o.status = 'NEW';
\echo --- расширенная статистика (dependencies, mcv) по status и created_at
CREATE STATISTICS st_orders_status_created (dependencies, mcv) ON status, created_at FROM e_orders;
ANALYZE e_orders;
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT o.id, o.amount, c.name FROM e_orders o JOIN customer c ON c.id = o.customer_id
WHERE o.created_at >= '2026-10-27 00:00+03' AND o.status = 'NEW';
DROP STATISTICS st_orders_status_created;
\echo --- для сравнения: тот же запрос с выключенным Nested Loop
SET enable_nestloop = off;
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT o.id, o.amount, c.name FROM e_orders o JOIN customer c ON c.id = o.customer_id
WHERE o.created_at >= '2026-10-27 00:00+03' AND o.status = 'NEW';
RESET enable_nestloop;

\echo === 7.2 устаревшая статистика: 250 000 поручений перевели в NEW после ANALYZE
UPDATE e_orders SET status = 'DONE' WHERE status = 'NEW';
VACUUM ANALYZE e_orders;
UPDATE e_orders SET status = 'NEW' WHERE id % 12 = 0;
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT o.id, o.amount, c.name FROM e_orders o JOIN customer c ON c.id = o.customer_id WHERE o.status = 'NEW';
\echo --- после ANALYZE
ANALYZE e_orders;
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT o.id, o.amount, c.name FROM e_orders o JOIN customer c ON c.id = o.customer_id WHERE o.status = 'NEW';

\echo === 7.6 функция над колонкой: upper(external_id)
DROP TABLE IF EXISTS payments;
CREATE TABLE payments (id bigint PRIMARY KEY, external_id text NOT NULL, amount numeric(12,2), created_at timestamptz NOT NULL);
INSERT INTO payments SELECT i, 'pay-' || to_hex(i * 2654435761 % 4294967296), (i % 100000) / 100.0,
       now() - (i % 365) * interval '1 day'
FROM generate_series(1, 3000000) i;
INSERT INTO payments VALUES (3000001, 'pay-99xz', 10, now() - interval '1 day'),
                            (3000002, 'PAY-99xz', 20, now() - interval '2 days'),
                            (3000003, 'Pay-99XZ', 30, now() - interval '3 days');
CREATE INDEX idx_payments_extid ON payments (external_id);
VACUUM ANALYZE payments;
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT * FROM payments p WHERE upper(external_id) = 'PAY-99XZ' AND created_at > now() - interval '30 days';
\echo --- гипотетический индекс hypopg
CREATE EXTENSION IF NOT EXISTS hypopg;
SELECT * FROM hypopg_create_index('CREATE INDEX ON payments (upper(external_id))');
EXPLAIN SELECT * FROM payments p WHERE upper(external_id) = 'PAY-99XZ' AND created_at > now() - interval '30 days';
SELECT hypopg_reset();
\echo --- настоящий индекс по выражению
CREATE INDEX CONCURRENTLY idx_payments_upper_extid ON payments (upper(external_id));
ANALYZE payments;
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT * FROM payments p WHERE upper(external_id) = 'PAY-99XZ' AND created_at > now() - interval '30 days';
\echo --- параметр bigint, переданный как numeric (BigDecimal из Java)
EXPLAIN SELECT * FROM payments WHERE id = 42::numeric;

\echo === 7.8 агрегация по мерчантам: 6 000 000 операций, work_mem = 4MB
DROP TABLE IF EXISTS merchant_txn;
CREATE TABLE merchant_txn (id bigint, merchant_id int, card_id bigint, amount numeric(12,2), created_at date);
INSERT INTO merchant_txn SELECT i, i % 412, (i::bigint * 7919) % 2000000, (i % 100000) / 100.0, date '2025-11-01' + (i % 380)
FROM generate_series(1, 6000000) i;
VACUUM ANALYZE merchant_txn;
SET work_mem = '4MB';
\echo --- count и sum по мерчанту: 412 групп помещаются в память, сортировка не нужна
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT merchant_id, count(*), sum(amount) FROM merchant_txn WHERE created_at >= '2026-01-01' GROUP BY merchant_id;
\echo --- число разных карт по мерчанту: count(DISTINCT) требует сортировки
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT merchant_id, count(DISTINCT card_id) FROM merchant_txn WHERE created_at >= '2026-01-01' GROUP BY merchant_id;
\echo --- (1) памяти этому запросу
BEGIN;
SET LOCAL work_mem = '512MB';
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT merchant_id, count(DISTINCT card_id) FROM merchant_txn WHERE created_at >= '2026-01-01' GROUP BY merchant_id;
COMMIT;
\echo --- (2) индекс с готовым порядком
CREATE INDEX idx_mt_merchant_card ON merchant_txn (merchant_id, card_id) INCLUDE (created_at);
VACUUM ANALYZE merchant_txn;
EXPLAIN (ANALYZE, BUFFERS, SUMMARY ON)
SELECT merchant_id, count(DISTINCT card_id) FROM merchant_txn WHERE created_at >= '2026-01-01' GROUP BY merchant_id;
