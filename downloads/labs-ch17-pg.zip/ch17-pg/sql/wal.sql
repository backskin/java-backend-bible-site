-- Глава 17, разделы 5.7, 5.8, 8.4 и 8.8: объём WAL, полные образы страниц, wal_compression, цена индексов на запись.
-- Запуск: ./run18.sh wal
\echo === 5.7 одно обновление сразу после контрольной точки и повторное на той же странице
DROP TABLE IF EXISTS w_orders;
CREATE TABLE w_orders (
  id          bigint PRIMARY KEY,
  customer_id int NOT NULL,
  status      text NOT NULL,
  amount      numeric(12,2) NOT NULL,
  created_at  timestamptz NOT NULL
) WITH (autovacuum_enabled = false);
INSERT INTO w_orders
SELECT i, i % 5000, 'NEW', (i % 100000) / 100.0, timestamptz '2026-01-01' + i * interval '10 seconds'
FROM generate_series(1, 1000000) i;
VACUUM ANALYZE w_orders;
CHECKPOINT;
\echo --- первое изменение страницы после CHECKPOINT
EXPLAIN (ANALYZE, WAL, COSTS OFF, TIMING OFF, SUMMARY OFF) UPDATE w_orders SET status = 'DONE' WHERE id = 42;
\echo --- та же страница, второе изменение
EXPLAIN (ANALYZE, WAL, COSTS OFF, TIMING OFF, SUMMARY OFF) UPDATE w_orders SET status = 'DONE' WHERE id = 43;

\echo --- из чего состоят записи: pg_walinspect по одному обновлению сразу после CHECKPOINT
CREATE EXTENSION IF NOT EXISTS pg_walinspect;
SHOW data_checksums;
CHECKPOINT;
SELECT pg_current_wal_insert_lsn() AS l0 \gset
UPDATE w_orders SET status = 'DONE' WHERE id = 500042;
SELECT pg_current_wal_insert_lsn() AS l1 \gset
SELECT resource_manager, record_type, record_length, fpi_length,
       regexp_replace(block_ref, 'blkref #\d+: rel \d+/\d+/', 'rel ', 'g') AS block_ref
FROM pg_get_wal_records_info(:'l0', :'l1');
SELECT relname, relfilenode FROM pg_class WHERE relname IN ('w_orders', 'w_orders_pkey');

\echo === 8.8 тот же UPDATE в таблице с восемью индексами (status проиндексирован, HOT невозможен)
CREATE INDEX w_cust      ON w_orders (customer_id);
CREATE INDEX w_status    ON w_orders (status);
CREATE INDEX w_created   ON w_orders (created_at);
CREATE INDEX w_amount    ON w_orders (amount);
CREATE INDEX w_cust_cr   ON w_orders (customer_id, created_at);
CREATE INDEX w_status_cr ON w_orders (status, created_at);
CREATE INDEX w_cust_cov  ON w_orders (customer_id) INCLUDE (amount, status);
SELECT count(*) AS indexes FROM pg_index WHERE indrelid = 'w_orders'::regclass;
CHECKPOINT;
\echo --- первое изменение после CHECKPOINT
EXPLAIN (ANALYZE, WAL, COSTS OFF, TIMING OFF, SUMMARY OFF) UPDATE w_orders SET status = 'DONE' WHERE id = 1042;
\echo --- соседняя строка, страницы уже в журнале
EXPLAIN (ANALYZE, WAL, COSTS OFF, TIMING OFF, SUMMARY OFF) UPDATE w_orders SET status = 'DONE' WHERE id = 1043;
\echo --- обновление неиндексированной колонки при тех же восьми индексах (HOT)
EXPLAIN (ANALYZE, WAL, COSTS OFF, TIMING OFF, SUMMARY OFF) UPDATE w_orders SET created_at = created_at WHERE id = 1044;

\echo === 8.4 100 000 однострочных INSERT в одной транзакции: только первичный ключ против восьми индексов
DROP TABLE IF EXISTS ins_pk, ins_8;
CREATE TABLE ins_pk (LIKE w_orders INCLUDING DEFAULTS);
ALTER TABLE ins_pk ADD PRIMARY KEY (id);
CREATE TABLE ins_8 (LIKE w_orders INCLUDING ALL);
DROP FUNCTION IF EXISTS ins_bench(regclass);
CREATE OR REPLACE FUNCTION ins_bench(tbl regclass, base int DEFAULT 0) RETURNS text LANGUAGE plpgsql AS $$
DECLARE t0 timestamptz; l0 pg_lsn;
BEGIN
  t0 := clock_timestamp(); l0 := pg_current_wal_insert_lsn();
  FOR i IN 1..100000 LOOP
    EXECUTE format('INSERT INTO %s VALUES ($1, $2, ''NEW'', $3, $4)', tbl)
      USING base + i, (i * 7919) % 5000, (i % 100000) / 100.0, timestamptz '2026-01-01' + i * interval '10 seconds';
  END LOOP;
  RETURN format('%s: %s мкс на вставку, WAL %s на вставку', tbl,
                round(extract(epoch FROM clock_timestamp() - t0) * 1e6 / 100000, 1),
                round(pg_wal_lsn_diff(pg_current_wal_insert_lsn(), l0) / 100000) || ' байт');
END $$;
SELECT ins_bench('ins_pk');
SELECT ins_bench('ins_8');
\echo --- повтор на уже заполненных таблицах
SELECT ins_bench('ins_pk', 100000);
SELECT ins_bench('ins_8', 100000);

\echo === 5.8 wal_compression: одно обновление на каждой странице сразу после CHECKPOINT
DROP TABLE IF EXISTS wc;
CREATE TABLE wc (id int PRIMARY KEY, v int, pad text) WITH (autovacuum_enabled = false, fillfactor = 90);
INSERT INTO wc SELECT i, 0, repeat('payment-' || (i % 977), 6) FROM generate_series(1, 1000000) i;
VACUUM ANALYZE wc;
SELECT pg_relation_size('wc') / 8192 AS pages;
CREATE OR REPLACE FUNCTION wc_bench(method text) RETURNS text LANGUAGE plpgsql AS $$
DECLARE l0 pg_lsn; t0 timestamptz; touched bigint;
BEGIN
  PERFORM set_config('wal_compression', method, false);
  l0 := pg_current_wal_insert_lsn(); t0 := clock_timestamp();
  UPDATE wc SET v = v + 1 WHERE id % 100 = 0;
  GET DIAGNOSTICS touched = ROW_COUNT;
  RETURN format('wal_compression = %s: %s строк, WAL %s, %s мс', method, touched,
                pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_insert_lsn(), l0)),
                round(extract(epoch FROM clock_timestamp() - t0) * 1000));
END $$;
CHECKPOINT;
SELECT wc_bench('off');
CHECKPOINT;
SELECT wc_bench('pglz');
CHECKPOINT;
SELECT wc_bench('lz4');
CHECKPOINT;
SELECT wc_bench('zstd');
\echo --- для сравнения: то же обновление без контрольной точки перед ним (полных образов нет)
SELECT wc_bench('off');
