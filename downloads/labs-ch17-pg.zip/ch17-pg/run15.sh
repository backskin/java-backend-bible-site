#!/bin/sh
# Опыты главы 17 на PostgreSQL 15 в Docker: ./run15.sh имя — свежий контейнер, sql/имя.sql, вывод в pg15-имя.txt.
set -e
cd "$(dirname "$0")"
docker rm -f jbb-pg15 >/dev/null 2>&1 || true
docker run -d --name jbb-pg15 -e POSTGRES_PASSWORD=postgres --shm-size=1g postgres:15 >/dev/null
until docker exec jbb-pg15 pg_isready -U postgres -q; do sleep 1; done
sleep 2
docker exec jbb-pg15 psql -U postgres -Atc "SELECT version()" > "pg15-$1.txt"
docker exec -i jbb-pg15 psql -U postgres -X -q -v ON_ERROR_STOP=1 < "sql/$1.sql" >> "pg15-$1.txt" 2>&1
docker rm -f jbb-pg15 >/dev/null
cat "pg15-$1.txt"
