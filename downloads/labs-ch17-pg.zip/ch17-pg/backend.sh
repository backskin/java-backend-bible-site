#!/bin/sh
# Раздел 11.4: память одного backend-процесса и время подключения на PostgreSQL 18 (Linux в контейнере jbb-pg18).
# Запуск: docker cp backend.sh jbb-pg18:/backend.sh && docker exec -u postgres jbb-pg18 sh /backend.sh > backend.txt
# (от пользователя postgres: иначе /proc/PID/smaps_rollup чужого процесса не читается)
# Нужна таблица txn_part из 300 секций (sql/planner.sql).
mem() {  # собственная (Private) и пропорциональная (Pss) память процесса, кБ
  awk '/^Rss|^Pss:|^Private_Clean|^Private_Dirty/ {print "    " $0}' /proc/$1/smaps_rollup
}
T=$(mktemp -d)
echo "=== свежий backend"
psql -U postgres -X -q -At <<'EOF' > $T/out.txt &
SELECT pg_backend_pid();
SELECT pg_sleep(2);
SELECT 'CacheMemoryContext ' || pg_size_pretty(sum(total_bytes)) FROM pg_backend_memory_contexts WHERE name = 'CacheMemoryContext';
-- только планирование: открыть описания всех 300 секций, не читая данных
\o /dev/null
EXPLAIN SELECT * FROM txn_part;
\o
SELECT count(*) FROM pg_class c JOIN pg_attribute a ON a.attrelid = c.oid;
SELECT 'CacheMemoryContext ' || pg_size_pretty(sum(total_bytes)) FROM pg_backend_memory_contexts WHERE name = 'CacheMemoryContext';
SELECT 'всего контекстов ' || pg_size_pretty(sum(total_bytes)) FROM pg_backend_memory_contexts;
SELECT pg_sleep(3);
EOF
sleep 1
PID=$(head -1 $T/out.txt)
echo "  pid $PID, до запросов:"; mem "$PID"
sleep 3
echo "  после планирования запроса к 300 секциям и обхода каталога:"; mem "$PID"
wait
sed -n '2,$p' $T/out.txt | grep -v '^$' | grep -v '^[0-9]*$' | sed 's/^/  /'
echo "=== время подключения: pgbench -C (новое соединение на каждую транзакцию), 10 с, один клиент, 127.0.0.1 без пароля"
echo 'SELECT 1;' > $T/select1.sql
pgbench -U postgres -h 127.0.0.1 -n -C -T 10 -f $T/select1.sql postgres 2>&1 | grep -E "latency average|connection time|tps"
echo "--- то же по сети контейнера с паролем (scram-sha-256; к 127.0.0.1 в образе доступ без пароля, trust)"
PGPASSWORD=postgres pgbench -U postgres -h "$(hostname -i | cut -d" " -f1)" -n -C -T 10 -f $T/select1.sql postgres 2>&1 | grep -E "latency average|connection time|tps"
echo "--- то же через unix-сокет"
pgbench -U postgres -n -C -T 10 -f $T/select1.sql postgres 2>&1 | grep -E "latency average|connection time|tps"
echo "--- одно соединение на весь прогон"
pgbench -U postgres -h 127.0.0.1 -n -T 10 -f $T/select1.sql postgres 2>&1 | grep -E "latency average|connection time|tps"
psql -U postgres -At -c "SHOW password_encryption" -c "SELECT version()"
