#!/bin/sh
# Раздел 6.9: задержка случайного и последовательного чтения страницы 8 КБ мимо кэша ОС (O_DIRECT, одна очередь).
# Запуск внутри контейнера jbb-pg18: docker exec jbb-pg18 sh /fio.sh  (копируется туда командой docker cp fio.sh jbb-pg18:/fio.sh). Вывод — fio.txt.
set -e
command -v fio >/dev/null || { apt-get update -qq >/dev/null && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq fio >/dev/null 2>&1; }
cd /var/lib/postgresql
# файл создаётся заранее: иначе первый замер идёт одновременно с его записью
fio --name=layout --filename=fio-test.bin --size=2G --bs=1m --rw=write --direct=1 --output-format=terse >/dev/null
sync; sleep 5
for rw in read randread; do
  fio --name="$rw" --filename=fio-test.bin --size=2G --bs=8k --rw="$rw" --direct=1 --ioengine=psync \
      --iodepth=1 --numjobs=1 --runtime=20 --time_based --group_reporting \
      --output-format=normal | grep -E "^$rw|IOPS=|clat \(|lat \(usec\)|50.00th|99.00th" || true
done
rm -f fio-test.bin
