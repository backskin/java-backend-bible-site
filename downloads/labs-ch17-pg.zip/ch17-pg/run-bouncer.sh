#!/bin/sh
# Опыт 11.3: PgBouncer в режиме transaction перед PostgreSQL 18 (контейнер jbb-pg18 из run18.sh).
# Запускает PgBouncerDemo дважды: max_prepared_statements = 0 и 200. Вывод в pgbouncer.txt.
set -e
cd "$(dirname "$0")"
docker ps --format '{{.Names}}' | grep -qx jbb-pg18 || ./run18.sh --fresh
docker network inspect jbb17 >/dev/null 2>&1 || docker network create jbb17 >/dev/null
docker network connect jbb17 jbb-pg18 2>/dev/null || true
export JAVA_HOME=${JAVA_HOME:-$HOME/.jdks/temurin-21.0.13}
export MAVEN_OPTS="-Dstdout.encoding=UTF-8 -Dfile.encoding=UTF-8"
mvn -q compile
: > pgbouncer.txt
for mps in 0 200; do
  sed "s/^max_prepared_statements = .*/max_prepared_statements = $mps/" bouncer/pgbouncer.ini > bouncer/run.ini
  docker rm -f jbb-bouncer >/dev/null 2>&1 || true
  docker run -d --name jbb-bouncer --network jbb17 -p 6432:6432 \
    -v "$(pwd -W 2>/dev/null || pwd)/bouncer/run.ini:/etc/pgbouncer/pgbouncer.ini:ro" \
    -v "$(pwd -W 2>/dev/null || pwd)/bouncer/userlist.txt:/etc/pgbouncer/userlist.txt:ro" \
    edoburu/pgbouncer:latest >/dev/null
  sleep 3
  echo "##### max_prepared_statements = $mps" >> pgbouncer.txt
  mvn -q exec:java -Dexec.mainClass=PgBouncerDemo 2>&1 | grep -v SLF4J >> pgbouncer.txt
done
docker rm -f jbb-bouncer >/dev/null
rm -f bouncer/run.ini
cat pgbouncer.txt
