# Стенд главы 17 «PostgreSQL изнутри»

Здесь лежат все опыты, на которые ссылается глава 17: классы Java на встроенном PostgreSQL 15.5 и SQL-скрипты на PostgreSQL 18 в Docker. Каждый вывод сохранён рядом со скриптом, а в главе на него ведёт сноска.

## Классы на встроенном PostgreSQL 15.5

Сервер поднимается внутри процесса через `io.zonky.test:embedded-postgres`, Docker не нужен. Нужен JDK 21.

```bash
mvn -q compile exec:java -Dexec.mainClass=PgInternals     # вывод: pg-internals-15.txt
mvn -q compile exec:java -Dexec.mainClass=ReplicationDemo # вывод: replication-15.txt
```

- `PgInternals` — версии строк, VACUUM и горизонт, autovacuum, журнал, планы, B-tree, логическое декодирование, цена соединения (разделы 3–11).
- `ReplicationDemo` — мастер и горячий резерв на одной машине: время фиксации в режимах `synchronous_commit`, чтение с резерва сразу после записи, падение синхронной реплики (5.4, 10.2).

Для вывода по-русски в консоли Windows задайте `MAVEN_OPTS="-Dstdout.encoding=UTF-8 -Dfile.encoding=UTF-8"`.

## Скрипты на PostgreSQL 18

`run18.sh имя` поднимает контейнер `jbb-pg18` (если его нет), выполняет `sql/имя.sql` и пишет вывод в `pg18-имя.txt`. `run15.sh имя` делает то же на свежем PostgreSQL 15.

| Скрипт | Разделы | Что проверяет |
|---|---|---|
| `storage` | 2.3, 2.4 | порядок колонок и выравнивание, сжатие pglz и lz4 |
| `vis` | 3.7, 7.9 | Index Only Scan до и после VACUUM |
| `wal` | 5.7, 5.8, 8.4, 8.8 | полные образы страниц, `pg_walinspect`, `wal_compression`, затраты индексов на запись |
| `ckpt` | 5.3, 5.8 | контрольные точки при маленьком `max_wal_size` |
| `planner` | 6.6, 6.11–6.13 | JIT на 300 секциях, расширенная статистика, пакеты Hash Join, сортировка, Memoize, Gather |
| `jitpar` | 6.13 | компиляция JIT в каждом параллельном процессе (после `planner`) |
| `plans` | 7.2, 7.6–7.8 | планы для разборов главы 7 |
| `cdc` | 10.4, 10.6 | `REPLICA IDENTITY FULL`, забытый слот |
| `joins` (PG 15) | 6.4 | устаревшая статистика, Hash Join и `work_mem`, Memoize |

Таблица: Скрипты стенда, разделы главы и что они проверяют.

Строки журнала сервера о контрольных точках и временных файлах выписаны в `pg18-server-log.txt`.

## Отдельные опыты

- `run-bouncer.sh` — PgBouncer 1.26 в режиме `transaction` перед PostgreSQL 18 и класс `PgBouncerDemo` (11.3); вывод `pgbouncer.txt`, конфигурация в `bouncer/`.
- `fio.sh` — случайное и последовательное чтение страницы 8 КБ мимо кэша ОС (6.9); вывод `fio.txt`.
- `backend.sh` — память backend-процесса и время подключения через `pgbench -C` (11.4); вывод `backend.txt`.
