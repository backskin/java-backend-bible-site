package dev.team.ch03;

import org.openjdk.jmh.annotations.*;

import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.*;

/** Цикл против стрима, последовательный против параллельного, упаковка, LinkedList против ArrayList. */
@State(Scope.Benchmark)
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@Warmup(iterations = 3, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(1)
public class StreamVsLoop {
    @Param({"1000", "100000", "10000000"})
    int n;

    int[] ints;
    List<Integer> boxed;
    List<Integer> linked;

    @Setup
    public void setup() {
        ints = new Random(1).ints(n, 0, 1000).toArray();
        boxed = Arrays.stream(ints).boxed().collect(Collectors.toCollection(ArrayList::new));
        linked = n <= 100_000 ? new LinkedList<>(boxed) : List.of();
    }

    /** Q ≈ 1: сумма чётных. */
    @Benchmark public long loopInts() { long s = 0; for (int x : ints) if ((x & 1) == 0) s += x; return s; }
    @Benchmark public long streamInts() { return IntStream.of(ints).filter(x -> (x & 1) == 0).asLongStream().sum(); }
    @Benchmark public long parallelInts() { return IntStream.of(ints).parallel().filter(x -> (x & 1) == 0).asLongStream().sum(); }
    @Benchmark public long loopBoxed() { long s = 0; for (Integer x : boxed) if ((x & 1) == 0) s += x; return s; }
    @Benchmark public long streamBoxed() { return boxed.stream().filter(x -> (x & 1) == 0).mapToLong(Integer::longValue).sum(); }
    @Benchmark public long streamBoxedReduce() { return boxed.stream().filter(x -> (x & 1) == 0).map(Integer::longValue).reduce(0L, Long::sum); }
    @Benchmark public long parallelBoxed() { return boxed.parallelStream().filter(x -> (x & 1) == 0).mapToLong(Integer::longValue).sum(); }
    @Benchmark public long linkedListIterate() { long s = 0; for (Integer x : linked) if ((x & 1) == 0) s += x; return s; }
}
