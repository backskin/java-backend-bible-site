package dev.team.ch03;

import org.openjdk.jmh.annotations.*;

import java.util.*;
import java.util.concurrent.TimeUnit;

/** Сортировка массива платежей: рукописный компаратор против собранного из comparingInt/thenComparing (у Блоха «примерно на 10% медленнее»). */
@State(Scope.Benchmark)
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@Warmup(iterations = 3, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(1)
public class ComparatorCost {
    record Payment(int priority, int branch, long amount) {}

    static final Comparator<Payment> HAND = (a, b) -> {
        int c = Integer.compare(a.priority(), b.priority());
        if (c != 0) return c;
        c = Integer.compare(a.branch(), b.branch());
        if (c != 0) return c;
        return Long.compare(a.amount(), b.amount());
    };
    static final Comparator<Payment> BUILT = Comparator.comparingInt(Payment::priority)
            .thenComparingInt(Payment::branch).thenComparingLong(Payment::amount);
    static final Comparator<Payment> BOXED = Comparator.comparing(Payment::priority)
            .thenComparing(Payment::branch).thenComparing(Payment::amount);

    Payment[] source;
    Payment[] work;

    @Setup(Level.Trial)
    public void setup() {
        Random r = new Random(7);
        source = new Payment[100_000];
        for (int i = 0; i < source.length; i++) source[i] = new Payment(r.nextInt(5), r.nextInt(100), r.nextLong(1_000_000));
    }
    @Setup(Level.Invocation)
    public void copy() { work = source.clone(); }

    @Benchmark public Payment[] handWritten() { Arrays.sort(work, HAND); return work; }
    @Benchmark public Payment[] comparingInt() { Arrays.sort(work, BUILT); return work; }
    @Benchmark public Payment[] comparingBoxed() { Arrays.sort(work, BOXED); return work; }
}
