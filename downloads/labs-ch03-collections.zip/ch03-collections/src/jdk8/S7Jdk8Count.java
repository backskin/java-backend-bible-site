import java.util.*;
import java.util.stream.*;

// count() и peek на JDK 8, 21, 25 (код совместим с Java 8)
public class S7Jdk8Count {
    public static void main(String[] args) {
        System.out.println("java.version=" + System.getProperty("java.version"));
        List<String> peeked = new ArrayList<>();
        long c1 = new ArrayList<>(Arrays.asList(" a", "b ", " c ")).stream().map(String::trim).peek(peeked::add).count();
        System.out.println("map+peek+count: count=" + c1 + ", peek вызван " + peeked.size() + " раз");
        peeked.clear();
        long c2 = new ArrayList<>(Arrays.asList(" a", "b ", " c ")).stream().skip(1).map(String::trim).peek(peeked::add).count();
        System.out.println("skip(1)+map+peek+count: count=" + c2 + ", peek вызван " + peeked.size() + " раз");
    }
}
