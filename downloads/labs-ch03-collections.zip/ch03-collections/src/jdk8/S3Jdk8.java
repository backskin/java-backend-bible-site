import java.util.*;
import java.util.concurrent.*;

// Рекурсивный computeIfAbsent на JDK 8 и на современных JDK (код совместим с Java 8)
public class S3Jdk8 {
    static long fibChm(final int n, final Map<Integer, Long> c) {
        if (n < 2) return n;
        return c.computeIfAbsent(n, k -> fibChm(k - 1, c) + fibChm(k - 2, c));
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java.version=" + System.getProperty("java.version"));
        final Map<String, Integer> m = new HashMap<>();
        m.put("a", 2);
        try {
            m.computeIfAbsent("c", k -> { m.put("b", 1); return 3; });
            System.out.println("put внутри computeIfAbsent: без исключения, " + new TreeMap<>(m));
        } catch (ConcurrentModificationException e) {
            System.out.println("put внутри computeIfAbsent: ConcurrentModificationException, " + new TreeMap<>(m));
        }

        final Map<String, Integer> g = new HashMap<>();
        for (int i = 0; i < 11; i++) g.put("k" + i, i);
        Integer r;
        try {
            r = g.computeIfAbsent("x", k -> { for (int i = 0; i < 20; i++) g.put("n" + i, i); return 42; });
            int iterated = 0; for (String key : g.keySet()) iterated++;
            System.out.println("функция добавила 20 записей и вызвала рост: вернул " + r + ", get(x)=" + g.get("x")
                    + ", size()=" + g.size() + ", при обходе " + iterated);
        } catch (ConcurrentModificationException e) {
            System.out.println("функция добавила 20 записей: ConcurrentModificationException");
        }

        for (final int n : new int[]{2, 5, 12, 16}) {
            final long[] res = {-1};
            final String[] err = {null};
            Thread t = new Thread(() -> {
                try { res[0] = fibChm(n, new ConcurrentHashMap<>()); }
                catch (IllegalStateException e) { err[0] = e.getMessage(); }
            });
            t.setDaemon(true);
            t.start();
            t.join(3000);
            if (t.isAlive()) System.out.println("ConcurrentHashMap fib(" + n + "): через 3 с поток в состоянии " + t.getState());
            else if (err[0] != null) System.out.println("ConcurrentHashMap fib(" + n + "): IllegalStateException: " + err[0]);
            else System.out.println("ConcurrentHashMap fib(" + n + ") = " + res[0]);
        }
    }
}
