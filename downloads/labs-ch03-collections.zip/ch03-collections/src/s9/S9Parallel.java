// OUT: s09-parallel
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;

// Параллельные стримы: общий пул, потоки, флаг parallel/sequential, исключения, контекст, свой пул, блокировки
class S9Parallel {
    static final ThreadLocal<String> TRACE_ID = new ThreadLocal<>();

    public static void main(String[] args) throws Exception {
        System.out.println("availableProcessors=" + Runtime.getRuntime().availableProcessors()
                + ", ForkJoinPool.getCommonPoolParallelism()=" + ForkJoinPool.getCommonPoolParallelism());

        Set<String> threads = ConcurrentHashMap.newKeySet();
        IntStream.range(0, 1_000_000).parallel().map(i -> { threads.add(Thread.currentThread().getName().replaceAll("\\d+$", "N")); return i; }).sum();
        System.out.println("потоки, выполнявшие лямбду: " + new TreeSet<>(threads));

        Set<String> t2 = ConcurrentHashMap.newKeySet();
        IntStream.range(0, 100_000).parallel().map(i -> i * 2).sequential().forEach(i -> t2.add(Thread.currentThread().getName()));
        System.out.println("parallel() ... sequential(): потоков " + t2.size() + " " + t2);

        try {
            IntStream.range(0, 1000).parallel().forEach(i -> {
                if (i == 777 && !Thread.currentThread().getName().equals("main")) throw new IllegalStateException("сбой на элементе " + i);
                if (i == 777) throw new IllegalStateException("сбой на элементе " + i + " в main");
            });
        } catch (IllegalStateException e) {
            System.out.println("исключение в вызывающем потоке: " + e.getClass().getSimpleName() + ": " + e.getMessage()
                    + "; cause=" + (e.getCause() == null ? "null" : e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage()));
        }

        TRACE_ID.set("trace-42");
        Map<Boolean, Long> ctx = IntStream.range(0, 100_000).parallel().boxed()
                .collect(Collectors.partitioningBy(i -> "trace-42".equals(TRACE_ID.get()), Collectors.counting()));
        System.out.println("ThreadLocal виден в лямбде: " + ctx.get(true) + " элементов, не виден: " + ctx.get(false));

        ForkJoinPool pool = new ForkJoinPool(4);
        Set<String> own = ConcurrentHashMap.newKeySet();
        pool.submit(() -> IntStream.range(0, 1_000_000).parallel().forEach(i -> own.add(Thread.currentThread().getName().replaceAll("\\d+$", "N")))).get();
        pool.shutdown();
        System.out.println("parallel внутри pool.submit(): потоки " + new TreeSet<>(own));

        List<Integer> ids = IntStream.range(0, 32).boxed().toList();
        long t0 = System.nanoTime();
        ids.parallelStream().map(id -> { sleep(100); return id; }).toList();
        long blocking = (System.nanoTime() - t0) / 1_000_000;
        long t1 = System.nanoTime();
        try (ExecutorService vt = Executors.newVirtualThreadPerTaskExecutor()) {
            List<Future<Integer>> fs = new ArrayList<>();
            for (Integer id : ids) fs.add(vt.submit(() -> { sleep(100); return id; }));
            for (Future<Integer> f : fs) f.get();
        }
        long virtual = (System.nanoTime() - t1) / 1_000_000;
        System.out.println("32 вызова по 100 мс: параллельный стрим " + blocking + " мс, виртуальные потоки " + virtual + " мс");

        CountDownLatch release = new CountDownLatch(1);
        Thread hog = new Thread(() -> IntStream.range(0, ForkJoinPool.getCommonPoolParallelism() * 4).parallel().forEach(i -> { try { release.await(); } catch (InterruptedException e) { } }));
        hog.start();
        Thread.sleep(300);
        long t2s = System.nanoTime();
        CompletableFuture<String> cf = CompletableFuture.supplyAsync(() -> "курс USD");
        String res;
        try { res = cf.get(2, TimeUnit.SECONDS); } catch (TimeoutException e) { res = "не выполнена за 2 с"; }
        System.out.println("CompletableFuture.supplyAsync без executor, пока параллельный стрим ждёт в общем пуле: " + res
                + " (" + (System.nanoTime() - t2s) / 1_000_000 + " мс)");
        release.countDown();
        hog.join();
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); } }
}
