// OUT: s04-maps
import java.math.BigDecimal;
import java.util.*;

// LinkedHashMap и LRU, TreeMap и навигация, EnumSet, IdentityHashMap, WeakHashMap
class S4Maps {
    static final class LruCache<K, V> extends LinkedHashMap<K, V> {
        private final int maxEntries;
        LruCache(int maxEntries) { super(16, 0.75f, true); this.maxEntries = maxEntries; }
        @Override protected boolean removeEldestEntry(Map.Entry<K, V> eldest) { return size() > maxEntries; }
    }
    enum Permission { READ, WRITE, APPROVE, ADMIN }
    enum Wide { A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,B7,B8,B9,C0,C1,C2,C3,C4,C5,C6,C7,C8,C9,
        D0,D1,D2,D3,D4,D5,D6,D7,D8,D9,E0,E1,E2,E3,E4,E5,E6,E7,E8,E9,F0,F1,F2,F3,F4,F5,F6,F7,F8,F9,G0,G1,G2,G3,G4 }
    static final class Listener { }
    static final class ListenerInfo { final Listener owner; ListenerInfo(Listener l) { owner = l; } }

    public static void main(String[] args) throws Exception {
        LruCache<String, BigDecimal> rates = new LruCache<>(3);
        rates.put("USD", new BigDecimal("81.20")); rates.put("EUR", new BigDecimal("88.10")); rates.put("CNY", new BigDecimal("11.30"));
        rates.get("USD");
        rates.put("KZT", new BigDecimal("0.16"));
        System.out.println("LRU на 3 записи после get(USD) и put(KZT): " + rates.keySet());
        try { for (String k : rates.keySet()) rates.get(k); }
        catch (ConcurrentModificationException e) { System.out.println("get во время обхода access-ordered LinkedHashMap: ConcurrentModificationException"); }
        LinkedHashMap<String, Integer> ins = new LinkedHashMap<>();
        ins.put("a", 1); ins.put("b", 2); ins.put("a", 3);
        System.out.println("порядок вставки, повторный put(a) место не меняет: " + ins.keySet());

        NavigableMap<BigDecimal, BigDecimal> fee = new TreeMap<>();
        fee.put(new BigDecimal("0"), new BigDecimal("0.020"));
        fee.put(new BigDecimal("10000"), new BigDecimal("0.015"));
        fee.put(new BigDecimal("100000"), new BigDecimal("0.010"));
        System.out.println("floorEntry(55000.00) -> " + fee.floorEntry(new BigDecimal("55000.00")));
        System.out.println("floorEntry(-1) -> " + fee.floorEntry(new BigDecimal("-1")) + ", ceilingKey(55000) -> " + fee.ceilingKey(new BigDecimal("55000")));
        fee.put(new BigDecimal("10000.00"), new BigDecimal("0.014"));
        System.out.println("put(10000.00) заменил значение у ключа 10000: size=" + fee.size() + ", " + fee);
        NavigableMap<BigDecimal, BigDecimal> head = fee.headMap(new BigDecimal("100000"), false);
        fee.put(new BigDecimal("50000"), new BigDecimal("0.012"));
        System.out.println("headMap — представление, видит новый ключ 50000: " + head.keySet());
        try { head.put(new BigDecimal("200000"), BigDecimal.ONE); } catch (IllegalArgumentException e) { System.out.println("put вне диапазона headMap: " + e.getMessage()); }

        Set<Permission> granted = EnumSet.of(Permission.READ, Permission.WRITE);
        System.out.println("EnumSet: " + granted.getClass().getSimpleName() + ", на 65 константах: " + EnumSet.noneOf(Wide.class).getClass().getSimpleName()
                + ", containsAll(READ, APPROVE)=" + granted.containsAll(EnumSet.of(Permission.READ, Permission.APPROVE)));
        EnumMap<Permission, Integer> usage = new EnumMap<>(Permission.class);
        usage.put(Permission.ADMIN, 1); usage.put(Permission.READ, 2);
        System.out.println("EnumMap обходится в порядке объявления: " + usage);
        try { usage.put(null, 1); } catch (NullPointerException e) { System.out.println("EnumMap.put(null, ...): NullPointerException"); }

        IdentityHashMap<String, String> seen = new IdentityHashMap<>();
        String acc1 = new String("40702810000000000001"), acc2 = new String("40702810000000000001");
        seen.put(acc1, "запрос 1"); seen.put(acc2, "запрос 2");
        System.out.println("IdentityHashMap с двумя равными по equals номерами счёта: size=" + seen.size() + ", HashMap дал бы 1");

        WeakHashMap<Object, String> weak = new WeakHashMap<>();
        weak.put("literal", "строка из пула");
        weak.put(new String("computed"), "строка, созданная на лету");
        Listener l = new Listener();
        weak.put(l, "listener без обратной ссылки");
        Listener l2 = new Listener();
        WeakHashMap<Listener, ListenerInfo> leak = new WeakHashMap<>();
        leak.put(l2, new ListenerInfo(l2));
        l = null; l2 = null;
        for (int i = 0; i < 5; i++) { System.gc(); Thread.sleep(50); }
        System.out.println("WeakHashMap после System.gc(): " + weak.values() + "; значение со ссылкой на ключ осталось: size=" + leak.size());
    }
}
