// OUT: s04-primitive
// JAVA: -Djdk.attach.allowAttachSelf -XX:+EnableDynamicAgentLoading -Xmx3g -cp {M2}/org/openjdk/jol/jol-core/0.17/jol-core-0.17.jar;{M2}/it/unimi/dsi/fastutil/8.5.15/fastutil-8.5.15.jar;{M2}/org/eclipse/collections/eclipse-collections/11.1.0/eclipse-collections-11.1.0.jar;{M2}/org/eclipse/collections/eclipse-collections-api/11.1.0/eclipse-collections-api-11.1.0.jar
import org.openjdk.jol.info.GraphLayout;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import org.eclipse.collections.impl.map.mutable.primitive.LongLongHashMap;
import org.eclipse.collections.impl.set.mutable.primitive.LongHashSet;
import java.util.*;

// Память словаря и множества на миллион long: JDK против коллекций примитивов (JOL 0.17, fastutil 8.5.15, Eclipse Collections 11.1.0)
class S4Primitive {
    static final int N = 1_000_000;

    static String mb(long bytes) { return String.format("%.1f МБ", bytes / 1048576.0); }

    public static void main(String[] args) {
        // Ключи и значения вне кэша Long (-128..127), как в справочнике счетов
        Map<Long, Long> jdkMap = HashMap.newHashMap(N);
        Long2LongOpenHashMap fuMap = new Long2LongOpenHashMap(N);
        LongLongHashMap ecMap = new LongLongHashMap(N);
        long[] keys = new long[N], values = new long[N];
        for (int i = 0; i < N; i++) {
            long k = 40702810000000000L + i, v = (i + 1000L) * 3;
            jdkMap.put(k, v); fuMap.put(k, v); ecMap.put(k, v); keys[i] = k; values[i] = v;
        }
        long jdk = GraphLayout.parseInstance(jdkMap).totalSize();
        long fu = GraphLayout.parseInstance(fuMap).totalSize();
        long ec = GraphLayout.parseInstance(ecMap).totalSize();
        long arr = GraphLayout.parseInstance(keys).totalSize() + GraphLayout.parseInstance(values).totalSize();
        System.out.println("Словарь long -> long на " + N + " записей:");
        System.out.printf("  HashMap<Long, Long>        %s (%.1f байт на запись)%n", mb(jdk), (double) jdk / N);
        System.out.printf("  Long2LongOpenHashMap       %s (%.1f байт на запись), выигрыш %.1f раза%n", mb(fu), (double) fu / N, (double) jdk / fu);
        System.out.printf("  EC LongLongHashMap         %s (%.1f байт на запись), выигрыш %.1f раза%n", mb(ec), (double) ec / N, (double) jdk / ec);
        System.out.printf("  два long[] (поиск binarySearch) %s, выигрыш %.1f раза%n", mb(arr), (double) jdk / arr);

        Set<Long> jdkSet = HashSet.newHashSet(N);
        LongOpenHashSet fuSet = new LongOpenHashSet(N);
        LongHashSet ecSet = new LongHashSet(N);
        BitSet bits = new BitSet();
        for (int i = 0; i < N; i++) {
            long k = 1_000_000L + i * 7L;
            jdkSet.add(k); fuSet.add(k); ecSet.add(k); bits.set((int) k);
        }
        long js = GraphLayout.parseInstance(jdkSet).totalSize();
        long fs = GraphLayout.parseInstance(fuSet).totalSize();
        long es = GraphLayout.parseInstance(ecSet).totalSize();
        long bs = GraphLayout.parseInstance(bits).totalSize();
        System.out.println("Множество из " + N + " long (значения от 10^6 с шагом 7):");
        System.out.printf("  HashSet<Long>              %s (%.1f байт на элемент)%n", mb(js), (double) js / N);
        System.out.printf("  LongOpenHashSet            %s (%.1f байт на элемент), выигрыш %.1f раза%n", mb(fs), (double) fs / N, (double) js / fs);
        System.out.printf("  EC LongHashSet             %s (%.1f байт на элемент), выигрыш %.1f раза%n", mb(es), (double) es / N, (double) js / es);
        System.out.printf("  BitSet до %d              %s, выигрыш %.1f раза%n", bits.length(), mb(bs), (double) js / bs);
        System.out.println(GraphLayout.parseInstance(jdkMap).toFootprint());
        System.out.println("Число объектов: HashMap " + GraphLayout.parseInstance(jdkMap).totalCount()
                + ", Long2LongOpenHashMap " + GraphLayout.parseInstance(fuMap).totalCount()
                + ", два long[] 2");
    }
}
