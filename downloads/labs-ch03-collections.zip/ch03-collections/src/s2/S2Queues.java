// OUT: s02-queues
// JAVA: --add-opens java.base/java.util=ALL-UNNAMED
import java.lang.reflect.Field;
import java.util.*;

// ArrayDeque и PriorityQueue: null, рост, порядок итерации, стабильность
class S2Queues {
    static int len(Object o, Class<?> c, String field) throws Exception {
        Field f = c.getDeclaredField(field); f.setAccessible(true); return ((Object[]) f.get(o)).length;
    }

    public static void main(String[] args) throws Exception {
        ArrayDeque<String> d = new ArrayDeque<>();
        try { d.push(null); } catch (NullPointerException e) { System.out.println("ArrayDeque.push(null): NullPointerException"); }
        System.out.println("ArrayDeque.contains(null): " + d.contains(null));
        LinkedList<String> ll = new LinkedList<>(); ll.push(null);
        System.out.println("LinkedList.push(null) принят, size=" + ll.size());
        System.out.println("new ArrayDeque<>() массив: " + len(d, ArrayDeque.class, "elements"));
        List<Integer> dg = new ArrayList<>(); int last = -1;
        for (int i = 0; i < 300; i++) { d.addLast("x"); int c = len(d, ArrayDeque.class, "elements"); if (c != last) { dg.add(c); last = c; } }
        System.out.println("ArrayDeque рост: " + dg);

        PriorityQueue<Integer> pq = new PriorityQueue<>(List.of(50, 10, 40, 20, 30, 5));
        System.out.println("PriorityQueue toString (обход массива кучи): " + pq);
        List<Integer> polled = new ArrayList<>(); while (!pq.isEmpty()) polled.add(pq.poll());
        System.out.println("poll в цикле: " + polled);
        PriorityQueue<Integer> g = new PriorityQueue<>(); List<Integer> pg = new ArrayList<>(); last = -1;
        for (int i = 0; i < 300; i++) { g.add(i); int c = len(g, PriorityQueue.class, "queue"); if (c != last) { pg.add(c); last = c; } }
        System.out.println("PriorityQueue рост от 11: " + pg);

        record Payment(String id, int priority) {}
        PriorityQueue<Payment> q = new PriorityQueue<>(Comparator.comparingInt(Payment::priority));
        for (int i = 1; i <= 8; i++) q.add(new Payment("p" + i, i % 2));
        List<String> out = new ArrayList<>(); while (!q.isEmpty()) out.add(q.poll().id());
        System.out.println("равный приоритет, порядок выдачи (поступали p1..p8): " + out);
        record Seq(Payment p, long seq) {}
        PriorityQueue<Seq> qs = new PriorityQueue<>(Comparator.comparingInt((Seq s) -> s.p().priority()).thenComparingLong(Seq::seq));
        long seq = 0; for (int i = 1; i <= 8; i++) qs.add(new Seq(new Payment("p" + i, i % 2), seq++));
        out.clear(); while (!qs.isEmpty()) out.add(qs.poll().p().id());
        System.out.println("с порядковым номером в компараторе: " + out);
    }
}
