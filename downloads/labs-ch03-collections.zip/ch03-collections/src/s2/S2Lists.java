// OUT: s02-lists
// JAVA: --add-opens java.base/java.util=ALL-UNNAMED
import java.lang.reflect.Field;
import java.util.*;

// ArrayList: ёмкость и рост; удаление в цикле; перегрузки remove; removeIf на разных коллекциях
class S2Lists {
    static int capacity(ArrayList<?> list) throws Exception {
        Field f = ArrayList.class.getDeclaredField("elementData");
        f.setAccessible(true);
        return ((Object[]) f.get(list)).length;
    }

    public static void main(String[] args) throws Exception {
        ArrayList<Integer> list = new ArrayList<>();
        System.out.println("new ArrayList<>(): длина массива до первого add = " + capacity(list));
        List<Integer> steps = new ArrayList<>();
        int last = -1;
        for (int i = 0; i < 1_000_000; i++) {
            list.add(i);
            int c = capacity(list);
            if (c != last) { steps.add(c); last = c; }
        }
        System.out.println("рост до 1 000 000: " + steps.size() + " массивов: " + steps);
        long garbage = 0;
        for (int i = 0; i < steps.size() - 1; i++) garbage += 16 + 4L * steps.get(i);
        System.out.println("суммарно в мусор (compressed oops, заголовок 16 байт): " + garbage / 1024 + " КБ; итоговый массив " + last + ", занято " + list.size());
        list.trimToSize();
        System.out.println("после trimToSize: " + capacity(list));

        ArrayList<Integer> zero = new ArrayList<>(0);
        List<Integer> zsteps = new ArrayList<>();
        for (int i = 0; i < 12; i++) { zero.add(i); zsteps.add(capacity(zero)); }
        System.out.println("new ArrayList<>(0), ёмкость после каждого add: " + zsteps);

        List<Integer> offsets = new ArrayList<>(List.of(10, 0, 20, 5, 30));
        offsets.remove(0);
        System.out.println("List<Integer>.remove(0) удалил индекс 0: " + offsets);
        offsets.remove(Integer.valueOf(5));
        System.out.println("remove(Integer.valueOf(5)) удалил значение: " + offsets);

        List<Integer> history = new ArrayList<>();
        for (int i = 0; i < 10; i++) history.add(i);
        for (int i = 5; i < history.size(); i++) history.remove(i);
        System.out.println("удаление хвоста циклом по индексу с 5: " + history + " (остались 6 и 8)");
        history = new ArrayList<>(); for (int i = 0; i < 10; i++) history.add(i);
        history.subList(5, history.size()).clear();
        System.out.println("subList(5, size).clear(): " + history);

        List<Integer> nums = Arrays.asList(1, 2, 3, 8, 9, 10, 13, 14);
        for (Collection<Integer> c : List.<Collection<Integer>>of(new ArrayList<>(nums), new TreeSet<>(nums), new ArrayDeque<>(nums), new LinkedList<>(nums))) {
            c.removeIf(x -> c.contains(x - 1));
            System.out.println("removeIf(x -> c.contains(x-1)) на " + c.getClass().getSimpleName() + ": " + c);
        }

        List<String> l = new ArrayList<>(List.of("a", "b", "c"));
        for (String s : l) { if (s.equals("b")) l.remove("a"); }
        System.out.println("удаление во время for-each на предпоследнем элементе: без исключения, список " + l);
        try { for (String s : new ArrayList<>(List.of("a", "b", "c"))) { }
              List<String> l2 = new ArrayList<>(List.of("a", "b", "c"));
              for (String s : l2) if (s.equals("a")) l2.remove("c"); }
        catch (ConcurrentModificationException e) { System.out.println("удаление на первом элементе: " + e.getClass().getSimpleName()); }

        Integer[] arr = {3, 1, 2};
        Collections.sort(Arrays.asList(arr));
        System.out.println("Collections.sort(Arrays.asList(arr)) отсортировал сам массив: " + Arrays.toString(arr));
        try { Arrays.asList(arr).add(4); } catch (UnsupportedOperationException e) { System.out.println("Arrays.asList(...).add: UnsupportedOperationException"); }
        try { Collections.sort(List.of(2, 1)); } catch (UnsupportedOperationException e) { System.out.println("Collections.sort(List.of(2,1)): UnsupportedOperationException"); }
        Collections.emptyList().sort(null);
        System.out.println("Collections.emptyList().sort(null): без исключения");
        try { List.of().sort(null); } catch (UnsupportedOperationException e) { System.out.println("List.of().sort(null): UnsupportedOperationException"); }
        List<StringBuilder> copies = Collections.nCopies(3, new StringBuilder());
        copies.get(0).append("x");
        System.out.println("nCopies: одна ссылка на три позиции: " + copies);
    }
}
