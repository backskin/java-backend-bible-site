// OUT: s02-layout
// JAVA: -Djdk.attach.allowAttachSelf -XX:+EnableDynamicAgentLoading -Xmx2g -cp {M2}/org/openjdk/jol/jol-core/0.17/jol-core-0.17.jar
import org.openjdk.jol.info.ClassLayout;
import org.openjdk.jol.info.GraphLayout;
import java.util.*;

// Раскладка узлов коллекций и расход памяти на элемент (JOL 0.17)
class S2Layout {
    public static void main(String[] args) throws Exception {
        for (String cls : List.of("java.util.LinkedList$Node", "java.util.HashMap$Node", "java.util.HashMap$TreeNode",
                "java.util.LinkedHashMap$Entry", "java.util.TreeMap$Entry", "java.util.concurrent.ConcurrentHashMap$Node")) {
            System.out.println(cls + ": " + ClassLayout.parseClass(Class.forName(cls)).instanceSize() + " байт");
        }
        int n = 100_000;
        List<Integer> elems = new ArrayList<>(n);
        for (int i = 0; i < n; i++) elems.add(i * 1000);  // вне кэша Integer
        long elemBytes = GraphLayout.parseInstance((Object) elems.toArray()).totalSize() - (16 + 4L * n);
        ArrayList<Integer> al = new ArrayList<>(elems);
        ArrayList<Integer> alGrown = new ArrayList<>(); alGrown.addAll(elems.subList(0, 1)); for (int i = 1; i < n; i++) alGrown.add(elems.get(i));
        LinkedList<Integer> ll = new LinkedList<>(elems);
        ArrayDeque<Integer> ad = new ArrayDeque<>(elems);
        HashMap<Integer, Integer> hm = new HashMap<>(); for (Integer e : elems) hm.put(e, e);
        TreeMap<Integer, Integer> tm = new TreeMap<>(); for (Integer e : elems) tm.put(e, e);
        report("ArrayList (из коллекции, без запаса)", al, elemBytes, n, 1);
        report("ArrayList (рос по одному)", alGrown, elemBytes, n, 1);
        report("LinkedList", ll, elemBytes, n, 1);
        report("ArrayDeque", ad, elemBytes, n, 1);
        report("HashMap (ключ=значение)", hm, elemBytes, n, 1);
        report("TreeMap (ключ=значение)", tm, elemBytes, n, 1);
        System.out.println("JVM: " + System.getProperty("java.vm.version"));
    }

    static void report(String name, Object o, long elemBytes, int n, int k) {
        long total = GraphLayout.parseInstance(o).totalSize();
        System.out.printf("%-38s %.1f байт на элемент без самих Integer%n", name, (total - elemBytes) / (double) n);
    }
}
