// OUT: s10-gatherers
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.*;

// Gatherers (JEP 485, Java 24): на JDK 21 не компилируется, это видно в выводе
class S10Gatherers {
    static <T, K> Gatherer<T, ?, T> distinctBy(Function<? super T, ? extends K> key) {
        return Gatherer.ofSequential(
                HashSet<K>::new,
                (seen, element, downstream) -> !seen.add(key.apply(element)) || downstream.push(element));
    }

    public static void main(String[] args) {
        System.out.println("windowFixed(3): " + IntStream.rangeClosed(1, 8).boxed().gather(Gatherers.windowFixed(3)).toList());
        System.out.println("windowSliding(3): " + IntStream.rangeClosed(1, 5).boxed().gather(Gatherers.windowSliding(3)).toList());
        List<BigDecimal> ops = List.of(new BigDecimal("1000.00"), new BigDecimal("-250.00"), new BigDecimal("-800.00"), new BigDecimal("300.00"));
        System.out.println("scan, остаток после каждой операции: " + ops.stream().gather(Gatherers.scan(() -> BigDecimal.ZERO, BigDecimal::add)).toList());
        System.out.println("fold: " + ops.stream().gather(Gatherers.fold(() -> BigDecimal.ZERO, BigDecimal::add)).toList());
        record Pay(String id, String client) {}
        System.out.println("свой distinctBy(client): " + Stream.of(new Pay("p1", "A"), new Pay("p2", "B"), new Pay("p3", "A")).gather(distinctBy(Pay::client)).map(Pay::id).toList());

        Set<String> kinds = ConcurrentHashMap.newKeySet();
        long t0 = System.nanoTime();
        List<Integer> res = IntStream.range(0, 32).boxed().gather(Gatherers.mapConcurrent(8, i -> {
            kinds.add(Thread.currentThread().isVirtual() ? "виртуальный" : "платформенный");
            try { Thread.sleep(100); } catch (InterruptedException e) { throw new RuntimeException(e); }
            return i;
        })).toList();
        long ms = (System.nanoTime() - t0) / 1_000_000;
        System.out.println("mapConcurrent(8), 32 вызова по 100 мс: " + ms + " мс, порядок сохранён: " + res.equals(IntStream.range(0, 32).boxed().toList()) + ", потоки: " + kinds);
        long t1 = System.nanoTime();
        Optional<Integer> firstSlow = IntStream.range(0, 1000).boxed().gather(Gatherers.mapConcurrent(4, i -> i)).findFirst();
        System.out.println("findFirst после mapConcurrent: " + firstSlow.get());
    }
}
