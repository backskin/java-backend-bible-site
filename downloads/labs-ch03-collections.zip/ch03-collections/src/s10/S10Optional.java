// OUT: s10-optional
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.*;

// Optional: orElse и orElseGet, of и ofNullable, flatMap(Optional::stream); суммы double и BigDecimal
class S10Optional {
    static final AtomicInteger saves = new AtomicInteger();
    static String createDefaultAccount() { saves.incrementAndGet(); return "new-account"; }

    public static void main(String[] args) {
        Optional<String> found = Optional.of("acc-1");
        found.orElse(createDefaultAccount());
        System.out.println("orElse при найденном значении вызвал создание: " + saves.get() + " раз");
        saves.set(0);
        found.orElseGet(S10Optional::createDefaultAccount);
        System.out.println("orElseGet при найденном значении: " + saves.get() + " раз");
        try { Optional.of(null); } catch (NullPointerException e) { System.out.println("Optional.of(null): NullPointerException"); }
        try { Optional.empty().get(); } catch (NoSuchElementException e) { System.out.println("Optional.empty().get(): " + e.getMessage()); }
        Map<String, String> owners = Map.of("acc-1", "Северный лес", "acc-3", "Уральский прокат");
        List<String> ids = List.of("acc-1", "acc-2", "acc-3");
        System.out.println("flatMap(Optional::stream): " + ids.stream().map(id -> Optional.ofNullable(owners.get(id))).flatMap(Optional::stream).toList());
        System.out.println("OptionalInt.empty().orElse(-1)=" + OptionalInt.empty().orElse(-1) + ", IntStream.empty().max()=" + IntStream.empty().max());

        double d = DoubleStream.generate(() -> 0.1).limit(10).sum();
        double naive = 0; for (int i = 0; i < 10; i++) naive += 0.1;
        BigDecimal bd = Stream.generate(() -> new BigDecimal("0.1")).limit(10).reduce(BigDecimal.ZERO, BigDecimal::add);
        System.out.println("десять раз по 0.1: DoubleStream.sum=" + d + ", цикл по double=" + naive + ", BigDecimal=" + bd);
        double[] mixed = {1e16, 1.0, -1e16, 1.0};
        double loopMixed = 0; for (double x : mixed) loopMixed += x;
        System.out.println("1e16 + 1 - 1e16 + 1: цикл=" + loopMixed + ", DoubleStream.sum=" + DoubleStream.of(mixed).sum());
        try { LongStream.of(Long.MAX_VALUE, 1).reduce(0, Math::addExact); } catch (ArithmeticException e) { System.out.println("Math::addExact в reduce: ArithmeticException " + e.getMessage()); }
        System.out.println("LongStream.sum с переполнением: " + LongStream.of(Long.MAX_VALUE, 1).sum());
        IntSummaryStatistics st = IntStream.of(5, 1, 9).summaryStatistics();
        System.out.println("summaryStatistics: " + st);
    }
}
