// OUT: s05-immutable
// JAVA: -Djdk.attach.allowAttachSelf -XX:+EnableDynamicAgentLoading -Xmx2g -cp {M2}/org/openjdk/jol/jol-core/0.17/jol-core-0.17.jar
import org.openjdk.jol.info.GraphLayout;
import java.util.*;

// Неизменяемые коллекции, обёртки, Arrays.asList, fail-fast и представления
class S5Immutable {
    record Item(String sku) {}
    record Order(List<Item> items) {}
    record SafeOrder(List<Item> items) { SafeOrder { items = List.copyOf(items); } }

    public static void main(String[] args) {
        List<String> src = new ArrayList<>(List.of("a", "b"));
        List<String> view = Collections.unmodifiableList(src);
        List<String> copy = List.copyOf(src);
        src.add("c");
        System.out.println("после src.add(c): unmodifiableList=" + view + ", copyOf=" + copy);
        try { copy.contains(null); } catch (NullPointerException e) { System.out.println("List.copyOf(...).contains(null): NullPointerException"); }
        try { List.of("a", null); } catch (NullPointerException e) { System.out.println("List.of(a, null): NullPointerException при создании"); }
        System.out.println("view.contains(null)=" + view.contains(null));
        System.out.println("List.copyOf(неизменяемого) тот же объект: " + (List.copyOf(copy) == copy)
                + "; List.copyOf(unmodifiableList) тот же: " + (List.copyOf(view) == (Object) view)
                + "; List.of() == List.of(): " + (List.of() == List.of()));
        System.out.println("классы: " + List.of(1).getClass().getSimpleName() + ", " + List.of(1, 2).getClass().getSimpleName()
                + ", " + List.of(1, 2, 3).getClass().getSimpleName() + ", " + Set.of(1, 2, 3).getClass().getSimpleName()
                + ", " + Map.of(1, 1).getClass().getSimpleName() + ", " + Map.of(1, 1, 2, 2).getClass().getSimpleName());
        Integer[] five = {1000, 2000, 3000, 4000, 5000};
        long elems = 0; for (Integer x : five) elems += GraphLayout.parseInstance(x).totalSize();
        List<Integer> al = new ArrayList<>(); for (Integer x : five) al.add(x);
        System.out.println("5 элементов без самих Integer: List.of " + (GraphLayout.parseInstance(List.of(five)).totalSize() - elems)
                + " байт, ArrayList после add " + (GraphLayout.parseInstance(al).totalSize() - elems)
                + " байт, new ArrayList<>(List.of(...)) " + (GraphLayout.parseInstance(new ArrayList<>(List.of(five))).totalSize() - elems) + " байт");

        Integer[] arr = {1, 2, 3};
        List<Integer> asList = Arrays.asList(arr);
        asList.set(0, 99); arr[2] = 77;
        System.out.println("Arrays.asList: set пишет в массив " + Arrays.toString(arr) + ", запись в массив видна в списке " + asList
                + ", класс " + asList.getClass().getName());
        int[] prim = {1, 2, 3};
        System.out.println("Arrays.asList(int[]).size()=" + Arrays.asList(prim).size() + ", List.of(int[]).size()=" + List.of(prim).size());

        List<Integer> nums = new ArrayList<>(List.of(1, 2, 3, 4, 5));
        try { nums.stream().forEach(x -> { if (x == 2) nums.remove(x); }); System.out.println("stream + remove: без исключения"); }
        catch (NullPointerException e) { System.out.println("stream().forEach с remove: NullPointerException в лямбде, список " + nums); }
        catch (ConcurrentModificationException e) { System.out.println("stream().forEach с remove: ConcurrentModificationException, список " + nums); }
        List<Integer> nums2 = new ArrayList<>(List.of(1, 2, 3, 4, 5));
        List<Integer> seen = new ArrayList<>();
        try { nums2.stream().forEach(x -> { seen.add(x); if (x != null && x.equals(2)) nums2.remove(x); }); }
        catch (ConcurrentModificationException e) { System.out.println("с проверкой на null: лямбда увидела " + seen + ", затем ConcurrentModificationException"); }

        List<Integer> parent = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6));
        List<Integer> head = parent.subList(0, 3);
        head.clear();
        System.out.println("subList(0,3).clear() удалил префикс у родителя: " + parent);
        List<Integer> tail = parent.subList(1, 3);
        parent.add(7);
        try { tail.size(); } catch (ConcurrentModificationException e) { System.out.println("subList после add в родителя: ConcurrentModificationException на size()"); }

        Map<String, Integer> limits = new HashMap<>(Map.of("client-1", 100, "client-2", 0, "client-3", 50));
        limits.keySet().remove("client-1");
        limits.values().removeIf(v -> v == 0);
        for (Map.Entry<String, Integer> e : limits.entrySet()) e.setValue(e.getValue() * 2);
        System.out.println("keySet().remove, values().removeIf, entry.setValue меняют словарь: " + limits);
        try { limits.keySet().add("client-9"); } catch (UnsupportedOperationException e) { System.out.println("keySet().add: UnsupportedOperationException"); }

        List<Item> items = new ArrayList<>(List.of(new Item("A")));
        Order o = new Order(items); SafeOrder so = new SafeOrder(items);
        items.add(new Item("B"));
        System.out.println("record без копии видит внешний add: " + o.items().size() + " позиции; с компактным конструктором: " + so.items().size());
    }
}
