// OUT: s06-concurrent
// JAVA: --add-opens java.base/java.util.concurrent=ALL-UNNAMED
import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

// ConcurrentHashMap, CopyOnWriteArrayList, BlockingQueue: гонки, null, рекурсия, ёмкость, итераторы
class S6Concurrent {
    static String count(Map<String, Integer> counts) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(8);
        AtomicInteger failures = new AtomicInteger();
        List<Future<?>> fs = new ArrayList<>();
        for (int t = 0; t < 8; t++) fs.add(pool.submit(() -> {
            try { for (int i = 0; i < 200_000; i++) counts.merge("acc-" + (i % 100), 1, Integer::sum); }
            catch (Exception e) { failures.incrementAndGet(); }
        }));
        for (Future<?> f : fs) f.get();
        pool.shutdown();
        long sum = 0; try { for (Integer v : counts.values()) sum += v; } catch (Exception e) { return "обход упал: " + e; }
        return "сумма " + sum + " из 1600000, потоков упало " + failures.get();
    }
    static Object[] table(ConcurrentHashMap<?, ?> m) throws Exception {
        Field f = ConcurrentHashMap.class.getDeclaredField("table"); f.setAccessible(true); return (Object[]) f.get(m);
    }
    static int tableOf(ConcurrentHashMap<String, String> m) throws Exception { m.put("a", "b"); return table(m).length; }
    static final class Same { final int id; Same(int id) { this.id = id; } public int hashCode() { return 7; } public boolean equals(Object o) { return o instanceof Same s && s.id == id; } }

    public static void main(String[] args) throws Exception {
        for (int run = 1; run <= 3; run++) System.out.println("HashMap, прогон " + run + ": " + count(new HashMap<>()));
        System.out.println("ConcurrentHashMap: " + count(new ConcurrentHashMap<>()));
        Map<String, Integer> sync = Collections.synchronizedMap(new HashMap<>());
        System.out.println("synchronizedMap: " + count(sync));

        ConcurrentHashMap<String, String> m = new ConcurrentHashMap<>();
        try { m.put("k", null); } catch (NullPointerException e) { System.out.println("CHM.put(k, null): NullPointerException"); }
        try { m.put(null, "v"); } catch (NullPointerException e) { System.out.println("CHM.put(null, v): NullPointerException"); }
        try { m.containsKey(null); } catch (NullPointerException e) { System.out.println("CHM.containsKey(null): NullPointerException"); }

        ConcurrentHashMap<Integer, Integer> c = new ConcurrentHashMap<>();
        try { c.computeIfAbsent(1, k -> c.computeIfAbsent(17, k2 -> 1)); } catch (IllegalStateException e) { System.out.println("ключи 1 и 17 (один бакет таблицы на 16): " + e.getMessage()); }
        ConcurrentHashMap<Integer, Integer> d = new ConcurrentHashMap<>();
        d.computeIfAbsent(1, k -> d.computeIfAbsent(2, k2 -> 1));
        System.out.println("ключи 1 и 2 (разные бакеты): прошло без ошибки, " + d);

        ConcurrentHashMap<Integer, String> it = new ConcurrentHashMap<>();
        for (int i = 0; i < 5; i++) it.put(i, "v" + i);
        int seen = 0;
        for (Integer key : it.keySet()) { if (key < 1000) it.put(1000 + key * 7, "новый"); seen++; }
        System.out.println("вставка во время обхода: исключения нет, итератор прошёл " + seen + " ключей, size=" + it.size());

        System.out.println("new ConcurrentHashMap<>(16) -> таблица " + tableOf(new ConcurrentHashMap<>(16))
                + "; (64) -> " + tableOf(new ConcurrentHashMap<>(64))
                + "; (16, 0.75f, 64) -> " + tableOf(new ConcurrentHashMap<>(16, 0.75f, 64)));
        System.out.println("вложенные классы CHM с именем Segment: " + Arrays.stream(ConcurrentHashMap.class.getDeclaredClasses()).map(Class::getSimpleName).filter(n -> n.equals("Segment")).toList()
                + ", поле segments: " + Arrays.stream(ConcurrentHashMap.class.getDeclaredFields()).anyMatch(f -> f.getName().equals("segments")));
        ConcurrentHashMap<Same, Integer> tb = new ConcurrentHashMap<>(64);
        for (int i = 1; i <= 9; i++) { tb.put(new Same(i), i); }
        Object[] t = table(tb);
        System.out.println("9 ключей с одним хешем, таблица " + t.length + ": голова бакета " + t[7 & (t.length - 1)].getClass().getSimpleName());

        CopyOnWriteArrayList<String> listeners = new CopyOnWriteArrayList<>(List.of("audit", "metrics"));
        Iterator<String> snap = listeners.iterator();
        listeners.add("antifraud");
        List<String> fromSnap = new ArrayList<>(); snap.forEachRemaining(fromSnap::add);
        System.out.println("COW: итератор, созданный до add, видит " + fromSnap + ", список " + listeners);
        try { listeners.iterator().remove(); } catch (UnsupportedOperationException | IllegalStateException e) { System.out.println("COW iterator.remove(): " + e.getClass().getSimpleName()); }
        for (int n : new int[]{10_000, 50_000}) {
            long t0 = System.nanoTime(); List<Integer> cow = new CopyOnWriteArrayList<>(); for (int i = 0; i < n; i++) cow.add(i);
            long t1 = System.nanoTime(); List<Integer> al = Collections.synchronizedList(new ArrayList<>()); for (int i = 0; i < n; i++) al.add(i);
            long t2 = System.nanoTime();
            System.out.printf("%d add: CopyOnWriteArrayList %d мс, synchronizedList %d мс%n", n, (t1 - t0) / 1_000_000, (t2 - t1) / 1_000_000);
        }

        ArrayBlockingQueue<String> abq = new ArrayBlockingQueue<>(2);
        System.out.println("ArrayBlockingQueue(2): offer x3 -> " + abq.offer("a") + ", " + abq.offer("b") + ", " + abq.offer("c")
                + "; offer с таймаутом 100 мс -> " + abq.offer("d", 100, TimeUnit.MILLISECONDS));
        System.out.println("new LinkedBlockingQueue<>().remainingCapacity() = " + new LinkedBlockingQueue<>().remainingCapacity());
        System.out.println("SynchronousQueue.offer без ожидающего потребителя: " + new SynchronousQueue<String>().offer("x"));
        ConcurrentLinkedQueue<Integer> clq = new ConcurrentLinkedQueue<>(); for (int i = 0; i < 3; i++) clq.add(i);
        System.out.println("ConcurrentLinkedQueue.poll из пустой после трёх poll: " + clq.poll() + clq.poll() + clq.poll() + " затем " + clq.poll());

        ConcurrentHashMap<String, Long> balances = new ConcurrentHashMap<>();
        for (int i = 0; i < 10_000; i++) balances.put("acc-" + i, (long) i);
        String over = balances.search(1000, (k, v) -> v > 9_990 ? k : null);
        long total = balances.reduceValuesToLong(1000, Long::longValue, 0L, Long::sum);
        System.out.println("search нашёл ключ с остатком > 9990: " + (over != null) + "; reduceValuesToLong = " + total);
        Set<String> keys = ConcurrentHashMap.newKeySet();
        keys.add("a");
        System.out.println("ConcurrentHashMap.newKeySet(): " + keys.getClass().getSimpleName());
    }
}
