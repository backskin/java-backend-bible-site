// OUT: s03-treeify
// JAVA: --add-opens java.base/java.util=ALL-UNNAMED
import java.lang.reflect.Field;
import java.util.*;

// Бакет-дерево: когда строится, когда разбирается обратно, кого спасает
class S3Treeify {
    static final class Plain {                       // одинаковый хеш, без Comparable
        final int id; final int h;
        Plain(int id, int h) { this.id = id; this.h = h; }
        @Override public int hashCode() { return h; }
        @Override public boolean equals(Object o) { return o instanceof Plain p && p.id == id; }
    }
    record Wrapped(String s) {}                      // хеш как у строки, но не Comparable

    static Object[] table(HashMap<?, ?> m) throws Exception {
        Field f = HashMap.class.getDeclaredField("table"); f.setAccessible(true); return (Object[]) f.get(m);
    }
    static String bucket(HashMap<?, ?> m, int hash) throws Exception {
        Object[] t = table(m);
        Object b = t[hash & (t.length - 1)];
        return "таблица " + t.length + ", бакет " + (b == null ? "пуст" : b.getClass().getSimpleName());
    }
    static List<String> colliding(int blocks) {
        List<String> res = List.of("");
        for (int i = 0; i < blocks; i++) { List<String> next = new ArrayList<>(); for (String s : res) { next.add(s + "Aa"); next.add(s + "BB"); } res = next; }
        return res;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("\"Aa\".hashCode()=" + "Aa".hashCode() + ", \"BB\".hashCode()=" + "BB".hashCode());
        HashMap<Plain, Integer> m = new HashMap<>();
        for (int i = 1; i <= 12; i++) { m.put(new Plain(i, 1), i); System.out.println("ключей с хешем 1: " + i + " -> " + bucket(m, 1)); }

        HashMap<Plain, Integer> big = new HashMap<>(64);
        for (int i = 1; i <= 14; i++) big.put(new Plain(i, 1), i);
        System.out.println("14 ключей в таблице на 64: " + bucket(big, 1));
        for (int i = 14; i >= 1; i--) {
            big.remove(new Plain(i, 1));
            if (i <= 6) System.out.println("удалены до " + (i - 1) + " узлов: " + (i - 1 == 0 ? "пусто" : bucket(big, 1)));
        }

        HashMap<Plain, Integer> split = new HashMap<>(64);
        for (int i = 1; i <= 5; i++) split.put(new Plain(i, 1), i);
        for (int i = 6; i <= 10; i++) split.put(new Plain(i, 1 + 64), i);
        System.out.println("10 узлов (хеши 1 и 65) в бакете 1: " + bucket(split, 1));
        for (int i = 100; split.size() < 49 + 10; i++) split.put(new Plain(i, i * 2 + 1000), i);
        System.out.println("после удвоения до 128: хеш 1 -> " + bucket(split, 1) + "; хеш 65 -> " + bucket(split, 65));

        for (int blocks : new int[]{13, 15}) {
            List<String> keys = colliding(blocks);
            long t0 = System.nanoTime();
            Map<String, Integer> byString = new HashMap<>();
            for (String k : keys) byString.put(k, 1);
            for (String k : keys) byString.get(k);
            long t1 = System.nanoTime();
            Map<Wrapped, Integer> byWrapper = new HashMap<>();
            for (String k : keys) byWrapper.put(new Wrapped(k), 1);
            for (String k : keys) byWrapper.get(new Wrapped(k));
            long t2 = System.nanoTime();
            System.out.printf("%d ключей с одним хешем: String %d мс, record без Comparable %d мс%n",
                    keys.size(), (t1 - t0) / 1_000_000, (t2 - t1) / 1_000_000);
        }
    }
}
