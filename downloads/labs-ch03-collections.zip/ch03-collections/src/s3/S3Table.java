// OUT: s03-table
// JAVA: --add-opens java.base/java.util=ALL-UNNAMED
import java.lang.reflect.Field;
import java.util.*;

// HashMap: индекс бакета, рост таблицы, предразмер, перенос узлов при удвоении
class S3Table {
    static int tableLength(HashMap<?, ?> map) throws Exception {
        Field f = HashMap.class.getDeclaredField("table");
        f.setAccessible(true);
        Object[] t = (Object[]) f.get(map);
        return t == null ? 0 : t.length;
    }

    static void growth(String title, HashMap<Integer, Integer> map, int n) throws Exception {
        StringBuilder sb = new StringBuilder(title + ": до вставок " + tableLength(map));
        int last = tableLength(map);
        for (int i = 1; i <= n; i++) {
            map.put(i, i);
            int now = tableLength(map);
            if (now != last) { sb.append("; после ").append(i).append("-й ").append(last).append("->").append(now); last = now; }
        }
        System.out.println(sb);
    }

    public static void main(String[] args) throws Exception {
        int h = "Lee".hashCode();
        System.out.println("\"Lee\".hashCode()=" + h + ", h % 128=" + (h % 128)
                + ", HashMap: (h ^ h>>>16) & 127=" + ((h ^ (h >>> 16)) & 127));
        HashMap<String, Integer> probe = new HashMap<>(128);
        probe.put("Lee", 1);
        Field tf = HashMap.class.getDeclaredField("table"); tf.setAccessible(true);
        Object[] t = (Object[]) tf.get(probe);
        for (int i = 0; i < t.length; i++) if (t[i] != null) System.out.println("в таблице на 128 ячеек ключ \"Lee\" лежит в бакете " + i);

        growth("new HashMap<>()", new HashMap<>(), 100);
        growth("new HashMap<>(100)", new HashMap<>(100), 100);
        growth("HashMap.newHashMap(100)", HashMap.newHashMap(100), 100);
        growth("new HashMap<>(75) для 100 записей", new HashMap<>(75), 100);
        growth("new HashMap<>(3)", new HashMap<>(3), 10);
        HashMap<Integer, Integer> big = new HashMap<>();
        int resizes = 0, last = 0;
        for (int i = 0; i < 1_000_000; i++) { big.put(i, i); int now = tableLength(big); if (now != last) { resizes++; last = now; } }
        System.out.println("миллион записей без предразмера: выделений таблицы " + resizes + ", итоговая длина " + last);

        for (int hash : new int[]{5, 21, 37, 53}) {
            System.out.println("hash=" + hash + ": бакет при 16 ячейках " + (hash & 15) + ", при 32 — " + (hash & 31)
                    + ((hash & 16) != 0 ? " (бит 16 установлен, переезжает)" : " (остаётся)"));
        }
    }
}
