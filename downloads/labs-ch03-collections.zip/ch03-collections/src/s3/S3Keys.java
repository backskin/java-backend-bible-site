// OUT: s03-keys
import java.lang.management.ManagementFactory;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;

// Изменяемые ключи, null в значениях, рекурсивный computeIfAbsent, порядок обхода
class S3Keys {
    static Map<Integer, Long> hashCache = new HashMap<>();
    static long fibHash(int n) { return n < 2 ? n : hashCache.computeIfAbsent(n, k -> fibHash(k - 1) + fibHash(k - 2)); }
    static long fibChm(int n, Map<Integer, Long> c) { return n < 2 ? n : c.computeIfAbsent(n, k -> fibChm(k - 1, c) + fibChm(k - 2, c)); }
    static long fibMemo(int n, Map<Integer, Long> memo) {
        if (n < 2) return n;
        Long cached = memo.get(n);
        if (cached != null) return cached;
        long v = fibMemo(n - 1, memo) + fibMemo(n - 2, memo);
        memo.put(n, v);
        return v;
    }

    public static void main(String[] args) throws Exception {
        if (args.length > 0) { System.out.println(Set.of("RUB", "USD", "EUR", "CNY", "KZT", "BYN")); return; }

        List<String> key = new ArrayList<>(List.of("client-42", "RUB"));
        Map<List<String>, String> limits = new HashMap<>();
        limits.put(key, "100000");
        key.set(1, "USD");
        System.out.println("изменённый ключ: get(key)=" + limits.get(key) + ", get(List.of(42,RUB))=" + limits.get(List.of("client-42", "RUB"))
                + ", get(List.of(42,USD))=" + limits.get(List.of("client-42", "USD")) + ", size=" + limits.size());

        try { fibHash(10); } catch (ConcurrentModificationException e) { System.out.println("fib(10) через HashMap.computeIfAbsent: ConcurrentModificationException"); }
        Map<String, Integer> hm = new HashMap<>();
        try { hm.computeIfAbsent("a", k -> { hm.put("b", 1); return 2; }); }
        catch (ConcurrentModificationException e) { System.out.println("put внутри функции: CME, состояние после исключения " + hm); }
        StringBuilder chm = new StringBuilder("ConcurrentHashMap fib: ");
        for (int n = 2; n <= 90; n++) {
            try { fibChm(n, new ConcurrentHashMap<>()); }
            catch (IllegalStateException e) { chm.append("n=2..").append(n - 1).append(" проходит, n=").append(n).append(": ").append(e.getMessage()); break; }
        }
        System.out.println(chm);
        int fails = 0; for (int n = 14; n <= 90; n++) try { fibChm(n, new ConcurrentHashMap<>()); } catch (IllegalStateException e) { fails++; }
        System.out.println("из n=14..90 падает " + fails + " из 77");
        System.out.println("get+put: HashMap fib(50)=" + fibMemo(50, new HashMap<>()) + ", ConcurrentHashMap fib(50)=" + fibMemo(50, new ConcurrentHashMap<>()));

        ConcurrentHashMap<Integer, Integer> dl = new ConcurrentHashMap<>();
        CountDownLatch inside = new CountDownLatch(2);
        Runnable a = () -> dl.computeIfAbsent(1, k -> { inside.countDown(); await(inside); return dl.computeIfAbsent(2, x -> 2); });
        Runnable b = () -> dl.computeIfAbsent(2, k -> { inside.countDown(); await(inside); return dl.computeIfAbsent(1, x -> 1); });
        Thread ta = new Thread(a, "calc-1"), tb = new Thread(b, "calc-2");
        ta.setDaemon(true); tb.setDaemon(true); ta.start(); tb.start();
        Thread.sleep(500);
        long[] ids = ManagementFactory.getThreadMXBean().findDeadlockedThreads();
        System.out.println("два потока, функции лезут в бакет соседа: " + ta.getState() + "/" + tb.getState()
                + ", findDeadlockedThreads нашёл " + (ids == null ? 0 : ids.length));

        Map<String, Integer> counts = new TreeMap<>();
        for (String w : "a b a c a b".split(" ")) counts.merge(w, 1, Integer::sum);
        System.out.println("merge-счётчик: " + counts);
        Map<String, Integer> m = new HashMap<>();
        m.getOrDefault("x", 0);
        int s1 = m.size();
        m.computeIfAbsent("x", k -> 0);
        System.out.println("size после getOrDefault=" + s1 + ", после computeIfAbsent=" + m.size());

        Map<String, String> n = new HashMap<>();
        System.out.println("computeIfAbsent(k -> null) вернул " + n.computeIfAbsent("k", k -> null) + ", containsKey=" + n.containsKey("k"));
        n.put("x", "5"); n.merge("x", "1", (o, v) -> null); System.out.println("merge с функцией, вернувшей null: x удалён=" + !n.containsKey("x"));
        n.put("y", "1"); n.compute("y", (k, v) -> null); System.out.println("compute -> null: y удалён=" + !n.containsKey("y"));
        n.put("z", null);
        System.out.println("put(z, null): containsKey=" + n.containsKey("z") + ", getOrDefault(z, d)=" + n.getOrDefault("z", "d")
                + ", computeIfAbsent(z, k -> 7)=" + n.computeIfAbsent("z", k -> "7"));
        n.put("p", null); n.putIfAbsent("p", "1"); System.out.println("putIfAbsent заменяет null: p=" + n.get("p"));
        try { n.merge("q", null, (o, v) -> v); } catch (NullPointerException e) { System.out.println("merge(q, null, ...): NullPointerException"); }

        System.out.println("HashSet 0..99: " + abbreviate(IntStream.range(0, 100).boxed().collect(Collectors.toCollection(HashSet::new))));
        System.out.println("HashSet 0..990 шаг 10: " + abbreviate(IntStream.range(0, 100).mapToObj(x -> x * 10).collect(Collectors.toCollection(HashSet::new))));
        System.out.println("HashSet строк: " + new HashSet<>(List.of("RUB", "USD", "EUR", "CNY", "KZT", "BYN")));
        String java = ProcessHandle.current().info().command().orElseThrow();
        String src = Arrays.stream(System.getProperty("sun.java.command").split(" ")).filter(x -> x.endsWith(".java")).findFirst().orElseThrow();
        for (int i = 0; i < 3; i++) {
            Process p = new ProcessBuilder(java, src, "child").redirectErrorStream(true).start();
            System.out.println("Set.of в новом процессе JVM #" + (i + 1) + ": " + new String(p.getInputStream().readAllBytes()).trim());
        }
    }

    static String abbreviate(Collection<?> c) { return c.stream().limit(8).map(String::valueOf).collect(Collectors.joining(", ", "[", ", ...]")); }
    static void await(CountDownLatch l) { try { l.await(); } catch (InterruptedException e) { throw new RuntimeException(e); } }
}
