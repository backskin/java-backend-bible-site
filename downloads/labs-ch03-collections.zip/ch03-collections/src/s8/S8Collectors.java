// OUT: s08-collectors
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.*;

// Коллекторы: toMap, groupingBy, filtering, teeing, toList, reduce и null
class S8Collectors {
    record Txn(String account, String currency, BigDecimal amount, boolean settled) {}

    static <T> Collector<T, ?, List<T>> topN(int n, Comparator<? super T> cmp) {
        return Collector.of(
                () -> new PriorityQueue<T>(n + 1, cmp),
                (pq, t) -> { pq.offer(t); if (pq.size() > n) pq.poll(); },
                (a, b) -> { for (T t : b) { a.offer(t); if (a.size() > n) a.poll(); } return a; },
                pq -> { List<T> out = new ArrayList<>(pq); out.sort(cmp.reversed()); return out; });
    }

    public static void main(String[] args) {
        List<Txn> txns = List.of(
                new Txn("A", "RUB", new BigDecimal("100.00"), true),
                new Txn("A", "USD", new BigDecimal("5.00"), false),
                new Txn("B", "RUB", new BigDecimal("250.00"), true),
                new Txn("C", "RUB", new BigDecimal("40.00"), true));

        try { txns.stream().collect(Collectors.toMap(Txn::account, Txn::amount)); }
        catch (IllegalStateException e) { System.out.println("toMap на дубликате: " + e.getMessage()); }
        System.out.println("toMap с функцией слияния: " + new TreeMap<>(txns.stream().collect(Collectors.toMap(Txn::account, Txn::amount, BigDecimal::add))));
        try { Stream.of("a").collect(Collectors.toMap(Function.identity(), s -> (String) null)); }
        catch (NullPointerException e) { System.out.println("toMap с null-значением: NullPointerException"); }
        try { Stream.of("a", "b").collect(Collectors.toMap(Function.identity(), s -> (String) null, (x, y) -> x)); }
        catch (NullPointerException e) { System.out.println("toMap с функцией слияния и null-значением: NullPointerException"); }
        try { Stream.of("a", "b").collect(Collectors.groupingBy(s -> s.equals("a") ? null : s)); }
        catch (NullPointerException e) { System.out.println("groupingBy с null-ключом: " + e.getMessage()); }

        Map<String, List<Txn>> g = txns.stream().collect(Collectors.groupingBy(Txn::account));
        System.out.println("groupingBy: " + g.getClass().getSimpleName() + " из " + g.get("A").getClass().getSimpleName());
        Map<String, Long> unsettledFiltering = txns.stream().collect(Collectors.groupingBy(Txn::account, TreeMap::new,
                Collectors.filtering(t -> !t.settled(), Collectors.counting())));
        Map<String, Long> unsettledFilter = txns.stream().filter(t -> !t.settled()).collect(Collectors.groupingBy(Txn::account, TreeMap::new, Collectors.counting()));
        System.out.println("filtering внутри groupingBy: " + unsettledFiltering + "; filter перед groupingBy: " + unsettledFilter);
        System.out.println("partitioningBy(amount > 1000): " + txns.stream().collect(Collectors.partitioningBy(t -> t.amount().compareTo(new BigDecimal("1000")) > 0, Collectors.counting())));
        Map<String, Map<String, BigDecimal>> nested = txns.stream().collect(Collectors.groupingBy(Txn::account, TreeMap::new,
                Collectors.groupingBy(Txn::currency, Collectors.reducing(BigDecimal.ZERO, Txn::amount, BigDecimal::add))));
        System.out.println("вложенная группировка счёт -> валюта -> сумма: " + nested);

        record Stats(long count, BigDecimal sum) {}
        System.out.println("teeing(count, sum): " + txns.stream().collect(Collectors.teeing(Collectors.counting(),
                Collectors.reducing(BigDecimal.ZERO, Txn::amount, BigDecimal::add), Stats::new)));

        List<String> a = Stream.of("x", "y").collect(Collectors.toList());
        a.add("z");
        System.out.println("Collectors.toList(): " + a.getClass().getSimpleName() + ", add прошёл: " + a);
        List<String> b = Stream.of("x", null).toList();
        System.out.println("Stream.toList(): " + b.getClass().getSimpleName() + ", null допустим: " + b);
        try { b.add("z"); } catch (UnsupportedOperationException e) { System.out.println("Stream.toList().add: UnsupportedOperationException"); }
        try { Stream.of("x", null).collect(Collectors.toUnmodifiableList()); } catch (NullPointerException e) { System.out.println("toUnmodifiableList с null: NullPointerException"); }

        List<String> bad = IntStream.range(0, 10_000).parallel().mapToObj(Integer::toString)
                .reduce(new ArrayList<>(), (acc, s) -> { acc.add(s); return acc; }, (x, y) -> { x.addAll(y); return x; });
        System.out.println("reduce с изменяемой identity в параллели: size=" + bad.size() + " вместо 10000 (одна общая ArrayList)");
        List<String> good = IntStream.range(0, 10_000).parallel().mapToObj(Integer::toString).collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
        System.out.println("collect(ArrayList::new, add, addAll) в параллели: size=" + good.size());

        List<String> abcd = List.of("a", "b", "c", "d");
        System.out.println("List.hashCode=" + abcd.hashCode()
                + ", reduce последовательно=" + abcd.stream().mapToInt(Objects::hashCode).reduce(1, (x, y) -> x * 31 + y)
                + ", reduce параллельно=" + abcd.parallelStream().mapToInt(Objects::hashCode).reduce(1, (x, y) -> x * 31 + y));

        List<Integer> withNull = Arrays.asList(null, 1, 2);
        Comparator<Integer> nl = Comparator.nullsLast(Comparator.naturalOrder());
        System.out.println("collect(maxBy(nullsLast)) = " + withNull.stream().collect(Collectors.maxBy(nl)));
        try { withNull.stream().max(nl); } catch (NullPointerException e) { System.out.println("max(nullsLast) с null в результате: NullPointerException"); }
        try { withNull.stream().findFirst(); } catch (NullPointerException e) { System.out.println("findFirst с первым null: NullPointerException"); }

        List<Integer> data = new Random(42).ints(100_000, 0, 1_000_000).boxed().toList();
        List<Integer> seqTop = data.stream().collect(topN(5, Comparator.naturalOrder()));
        List<Integer> parTop = data.parallelStream().collect(topN(5, Comparator.naturalOrder()));
        List<Integer> sortTop = data.stream().sorted(Comparator.reverseOrder()).limit(5).toList();
        System.out.println("topN последовательно " + seqTop + ", параллельно " + parTop + ", через sorted " + sortTop);
    }
}
