// OUT: s07-pipeline
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.*;

// Ленивость, вертикальная обработка, толчки через Sink, барьер sorted, характеристики и деление источников
class S7Pipeline {
    static String chars(Spliterator<?> s) {
        List<String> r = new ArrayList<>();
        int c = s.characteristics();
        if ((c & Spliterator.ORDERED) != 0) r.add("ORDERED");
        if ((c & Spliterator.DISTINCT) != 0) r.add("DISTINCT");
        if ((c & Spliterator.SORTED) != 0) r.add("SORTED");
        if ((c & Spliterator.SIZED) != 0) r.add("SIZED");
        if ((c & Spliterator.NONNULL) != 0) r.add("NONNULL");
        if ((c & Spliterator.IMMUTABLE) != 0) r.add("IMMUTABLE");
        if ((c & Spliterator.CONCURRENT) != 0) r.add("CONCURRENT");
        if ((c & Spliterator.SUBSIZED) != 0) r.add("SUBSIZED");
        return String.join("|", r);
    }
    static String split(Spliterator<?> s) {
        long before = s.estimateSize();
        Spliterator<?> half = s.trySplit();
        return "до " + (before == Long.MAX_VALUE ? "неизвестно" : before) + ", отдал " + (half == null ? "null" : half.estimateSize()) + ", осталось " + (s.estimateSize() == Long.MAX_VALUE ? "неизвестно" : s.estimateSize());
    }

    public static void main(String[] args) {
        List<String> trace = new ArrayList<>();
        Stream<String> lazy = Stream.of("p1", "p2", "p3").filter(p -> { trace.add("filter " + p); return true; });
        System.out.println("конвейер без терминальной операции: вызовов " + trace.size());
        lazy.map(p -> { trace.add("map " + p); return p; }).forEach(p -> trace.add("forEach " + p));
        System.out.println("вертикальная обработка: " + trace);

        trace.clear();
        Optional<Integer> first = Stream.iterate(1, i -> i + 1).peek(i -> trace.add("src " + i)).filter(i -> i % 3 == 0).findFirst();
        System.out.println("бесконечный источник + findFirst: " + first.get() + ", источник отдал " + trace);

        trace.clear();
        List<Integer> sorted = Stream.of(3, 1, 2).peek(i -> trace.add("до sorted " + i)).sorted().peek(i -> trace.add("после sorted " + i)).toList();
        System.out.println("барьер sorted: " + trace);

        System.out.println("стек вызовов изнутри filter при findFirst на ArrayList:");
        new ArrayList<>(List.of("a", "b")).stream().filter(s -> {
            StackTraceElement[] st = new Throwable().getStackTrace();
            for (int i = 1; i < Math.min(st.length, 9); i++) System.out.println("    " + st[i].getClassName().replace("java.util.stream.", "") + "." + st[i].getMethodName());
            return true;
        }).findFirst();

        Map<String, Spliterator<?>> src = new LinkedHashMap<>();
        src.put("ArrayList", new ArrayList<>(List.of(1, 2, 3)).spliterator());
        src.put("List.of", List.of(1, 2, 3).spliterator());
        src.put("Arrays.asList", Arrays.asList(1, 2, 3).spliterator());
        src.put("LinkedList", new LinkedList<>(List.of(1, 2, 3)).spliterator());
        src.put("ArrayDeque", new ArrayDeque<>(List.of(1, 2, 3)).spliterator());
        src.put("HashSet", new HashSet<>(List.of(1, 2, 3)).spliterator());
        src.put("TreeSet", new TreeSet<>(List.of(1, 2, 3)).spliterator());
        src.put("ConcurrentHashMap.keySet", new ConcurrentHashMap<>(Map.of(1, 1)).keySet().spliterator());
        src.put("IntStream.range", IntStream.range(0, 3).spliterator());
        src.put("Stream.iterate", Stream.iterate(0, i -> i + 1).spliterator());
        src.put("ArrayList.stream().filter", new ArrayList<>(List.of(1, 2, 3)).stream().filter(i -> i > 0).spliterator());
        src.put("ArrayList.stream().sorted", new ArrayList<>(List.of(1, 2, 3)).stream().sorted().spliterator());
        for (var e : src.entrySet()) System.out.printf("%-28s %s%n", e.getKey(), chars(e.getValue()));

        List<Integer> big = IntStream.range(0, 10_000).boxed().toList();
        System.out.println("trySplit ArrayList(10000): " + split(new ArrayList<>(big).spliterator()));
        System.out.println("trySplit LinkedList(10000): " + split(new LinkedList<>(big).spliterator()));
        System.out.println("trySplit ArrayDeque(10000): " + split(new ArrayDeque<>(big).spliterator()));
        System.out.println("trySplit HashSet(10000): " + split(new HashSet<>(big).spliterator()));
        System.out.println("trySplit TreeSet(10000): " + split(new TreeSet<>(big).spliterator()));
        System.out.println("trySplit Stream.iterate: " + split(Stream.iterate(0, i -> i + 1).spliterator()));
        Spliterator<Integer> ll = new LinkedList<>(big).spliterator();
        List<Long> batches = new ArrayList<>();
        for (int i = 0; i < 6; i++) { Spliterator<Integer> b = ll.trySplit(); if (b == null) break; batches.add(b.estimateSize()); }
        System.out.println("LinkedList(10000), шесть trySplit подряд отдают: " + batches);

        List<String> peeked = new ArrayList<>();
        long c1 = new ArrayList<>(List.of(" a", "b ", " c ")).stream().map(String::trim).peek(peeked::add).count();
        System.out.println("map+peek+count на списке: count=" + c1 + ", peek вызван " + peeked.size() + " раз");
        peeked.clear();
        long c2 = new ArrayList<>(List.of(" a", "b ", " c ")).stream().skip(1).map(String::trim).peek(peeked::add).count();
        System.out.println("skip(1)+peek+count: count=" + c2 + ", peek вызван " + peeked.size() + " раз");
        peeked.clear();
        long c3 = new ArrayList<>(List.of(" a", "b ", " c ")).stream().filter(s -> true).peek(peeked::add).count();
        System.out.println("filter+peek+count: count=" + c3 + ", peek вызван " + peeked.size() + " раз");

        Stream<String> s = Stream.of("a", "b");
        s.filter(x -> true);
        try { s.map(String::toUpperCase).toList(); } catch (IllegalStateException e) { System.out.println("второе ответвление от того же стрима: " + e.getMessage()); }
        Stream<String> t = Stream.of("a");
        t.count();
        try { t.count(); } catch (IllegalStateException e) { System.out.println("повторная терминальная операция: " + e.getMessage()); }

        int[] prim = {1, 2, 3};
        System.out.println("Stream.of(int[]).count()=" + Stream.of(prim).count() + ", Arrays.stream(int[]).count()=" + Arrays.stream(prim).count());
        StringBuilder sb = new StringBuilder();
        "Hi!".chars().forEach(sb::append);
        System.out.println("\"Hi!\".chars().forEach(sb::append) -> " + sb);
        System.out.println("Stream.ofNullable(null).count()=" + Stream.ofNullable(null).count());
    }
}
