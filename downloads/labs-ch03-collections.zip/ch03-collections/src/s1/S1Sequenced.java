// OUT: s01-sequenced
import java.util.*;

// Java 21, JEP 431: единый API упорядоченных коллекций и его неочевидные места
class S1Sequenced {
    public static void main(String[] args) {
        List<String> payments = new ArrayList<>(List.of("p1", "p2", "p3"));
        System.out.println("getLast: " + payments.getLast());
        List<String> rev = payments.reversed();
        payments.add("p4");
        System.out.println("reversed после add в оригинал: " + rev + " (представление, не копия)");

        LinkedHashSet<String> set = new LinkedHashSet<>(List.of("a", "b", "c"));
        set.addFirst("c");
        System.out.println("LinkedHashSet.addFirst(существующий): " + set);

        LinkedHashMap<String, Integer> m = new LinkedHashMap<>();
        m.put("x", 1); m.put("y", 2);
        m.putFirst("y", 20);
        System.out.println("LinkedHashMap.putFirst(существующий): " + m + ", firstEntry=" + m.firstEntry());

        try { new TreeSet<>(List.of(1, 2)).addFirst(0); }
        catch (UnsupportedOperationException e) { System.out.println("TreeSet.addFirst: " + e); }
        try { List.of(1, 2).reversed().add(3); }
        catch (UnsupportedOperationException e) { System.out.println("List.of(...).reversed().add: " + e); }
        System.out.println("ArrayDeque instanceof SequencedCollection: " + (new ArrayDeque<>() instanceof SequencedCollection));
        System.out.println("HashSet instanceof SequencedCollection: " + (Object) (new HashSet<>() instanceof SequencedCollection));
    }
}
