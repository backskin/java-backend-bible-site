// OUT: s01-comparators
import java.math.BigDecimal;
import java.util.*;

// Контракты сравнения: BigDecimal в TreeSet, вычитание, NaN, порог 32 у TimSort, reversed()
class S1Comparators {
    record Limit(String client, int value) {}
    record Amount(double value) {}

    public static void main(String[] args) {
        var a = new BigDecimal("1.0"); var b = new BigDecimal("1.00");
        System.out.println("equals=" + a.equals(b) + " compareTo=" + a.compareTo(b)
                + " HashSet=" + new HashSet<>(List.of(a, b)).size()
                + " TreeSet=" + new TreeSet<>(List.of(a, b)).size()
                + " stripTrailingZeros.equals=" + a.stripTrailingZeros().equals(b.stripTrailingZeros()));

        Comparator<Limit> bySubtraction = (x, y) -> x.value() - y.value();
        Limit big = new Limit("A", 2_000_000_000), neg = new Limit("B", -2_000_000_000);
        System.out.println("вычитание: compare(2e9, -2e9)=" + bySubtraction.compare(big, neg) + " (отрицательно: 2e9 «меньше» -2e9)");

        for (int n : new int[]{31, 32, 1000}) {
            int failures = 0;
            for (int seed = 0; seed < 200; seed++) {
                Random r = new Random(seed);
                List<Limit> data = new ArrayList<>();
                for (int i = 0; i < n; i++) data.add(new Limit("c" + i, r.nextInt()));
                try { data.sort(bySubtraction); } catch (IllegalArgumentException e) { failures++; }
            }
            System.out.println("вычитание, n=" + n + ": IllegalArgumentException в " + failures + " из 200 запусков");
        }
        Random r = new Random(209);
        List<Limit> data = new ArrayList<>();
        for (int i = 0; i < 32; i++) data.add(new Limit("c" + i, r.nextInt()));
        try { data.sort(bySubtraction); System.out.println("seed 209, n=32: без исключения"); }
        catch (IllegalArgumentException e) { System.out.println("seed 209, n=32: " + e.getMessage()); }

        Comparator<Amount> naive = (x, y) -> x.value() < y.value() ? -1 : x.value() > y.value() ? 1 : 0;
        System.out.println("наивный компаратор: NaN vs 1.0 = " + naive.compare(new Amount(Double.NaN), new Amount(1.0))
                + ", NaN vs 2.0 = " + naive.compare(new Amount(Double.NaN), new Amount(2.0))
                + ", 1.0 vs 2.0 = " + naive.compare(new Amount(1.0), new Amount(2.0)));
        System.out.println("Double.compare(NaN, +inf)=" + Double.compare(Double.NaN, Double.POSITIVE_INFINITY)
                + " Double.compare(-0.0, 0.0)=" + Double.compare(-0.0, 0.0) + " (-0.0 == 0.0)=" + (-0.0 == 0.0));
        int naiveFail = 0;
        for (int seed = 0; seed < 200; seed++) {
            Random rr = new Random(seed);
            List<Amount> xs = new ArrayList<>();
            for (int i = 0; i < 1000; i++) xs.add(new Amount(rr.nextInt(10) == 0 ? Double.NaN : rr.nextDouble()));
            try { xs.sort(naive); } catch (IllegalArgumentException e) { naiveFail++; }
        }
        System.out.println("NaN в 10% данных, n=1000: IllegalArgumentException в " + naiveFail + " из 200");

        record P(String id, int prio, int amount) {}
        List<P> ps = new ArrayList<>(List.of(new P("a", 1, 10), new P("b", 2, 10), new P("c", 2, 5), new P("d", 1, 5)));
        ps.sort(Comparator.comparingInt(P::prio).reversed().thenComparingInt(P::amount));
        System.out.println("comparingInt(prio).reversed().thenComparingInt(amount): " + ps.stream().map(P::id).toList());
        ps.sort(Comparator.comparingInt(P::prio).thenComparingInt(P::amount).reversed());
        System.out.println("comparingInt(prio).thenComparingInt(amount).reversed(): " + ps.stream().map(P::id).toList());

        class NoComparable {}
        try { new TreeSet<>().add(new NoComparable()); }
        catch (ClassCastException e) { System.out.println("TreeSet.add первого элемента без Comparable: ClassCastException"); }
        try { new TreeMap<>().put(null, 1); }
        catch (NullPointerException e) { System.out.println("TreeMap.put(null, ...) на пустой карте: NullPointerException"); }
    }
}
