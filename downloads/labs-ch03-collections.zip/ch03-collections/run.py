"""Опыты главы 03: запускает программы из src/sK/ на JDK 21 и JDK 25 и пишет вывод в sK-<имя>.txt.

Использование:
    python -X utf8 run.py                 # все программы
    python -X utf8 run.py src/s9/T01*.java

Заголовок программы (необязательные строки-комментарии в начале файла):
    // MODE: run            — java Файл.java (по умолчанию)
    // MODE: javac          — только компиляция, в вывод попадают сообщения javac
    // MODE: javap Класс    — компиляция и javap -c -p Класс
    // JAVAC: -Xlint:all    — флаги javac (для javac/javap)
    // JAVA: -Xmx64m        — флаги java ({M2} заменяется на путь к ~/.m2/repository)
    // ARGS: a b            — аргументы программы
    // OUT: s9-t01-integer-cache   — имя файла вывода (без .txt)
"""
import glob, os, re, shutil, subprocess, sys, tempfile, datetime

HOME = os.path.expanduser('~')
JDKS = {
    '21.0.10': os.path.join(HOME, '.jdks', 'temurin-21.0.10', 'bin'),
    '25.0.5': os.path.join(HOME, '.jdks', 'jdk-25.0.5+8', 'bin'),
}
ROOT = os.path.dirname(os.path.abspath(__file__))
HOME_RE = re.compile(re.escape(HOME).replace(r'\\\\', r'[\\/]'), re.I)


def header(src, key):
    m = re.search(r'^//\s*%s:\s*(.*)$' % key, src, re.M)
    return m.group(1).strip() if m else None


def clean(text, tmp):
    text = text.replace(tmp, '<tmp>').replace(tmp.replace('\\', '/'), '<tmp>')
    text = text.replace(HOME, '~').replace(HOME.replace('\\', '/'), '~')
    return text.replace('\r\n', '\n')


def run_one(path):
    src = open(path, encoding='utf-8').read()
    mode = (header(src, 'MODE') or 'run').split()
    jflags = [f.replace('{M2}', os.path.join(HOME, '.m2', 'repository')) for f in (header(src, 'JAVA') or '').split()]
    cflags = (header(src, 'JAVAC') or '').split()
    args = (header(src, 'ARGS') or '').split()
    results = {}
    for ver, bin_ in JDKS.items():
        tmp = tempfile.mkdtemp(prefix='ch03-')
        try:
            env = dict(os.environ, JAVA_TOOL_OPTIONS='', LANG='C')
            env.pop('JAVA_TOOL_OPTIONS')
            common = ['-J-Duser.language=en'] if False else []
            if mode[0] == 'run':
                cmd = [os.path.join(bin_, 'java'), '-Duser.language=en', '-Dstdout.encoding=UTF-8',
                       '-Dstderr.encoding=UTF-8', *jflags, os.path.abspath(path), *args]
                p = subprocess.run(cmd, capture_output=True, cwd=tmp, env=env, timeout=600)
                out = p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
                out += '' if p.returncode == 0 else '[код возврата %d]\n' % p.returncode
            else:
                cmd = [os.path.join(bin_, 'javac'), '-J-Duser.language=en', '-J-Dstdout.encoding=UTF-8', '-J-Dstderr.encoding=UTF-8', '-encoding', 'UTF-8',
                       *cflags, '-d', tmp, os.path.abspath(path)]
                p = subprocess.run(cmd, capture_output=True, cwd=tmp, env=env)
                out = '$ javac %s %s\n' % (' '.join(cflags), os.path.basename(path))
                out += p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
                out += '[javac: код возврата %d]\n' % p.returncode
                if mode[0] == 'javap' and p.returncode == 0:
                    for cls in mode[1:]:
                        q = subprocess.run([os.path.join(bin_, 'javap'), '-J-Duser.language=en', '-J-Dstdout.encoding=UTF-8', '-c', '-p',
                                            '-cp', tmp, cls], capture_output=True)
                        out += '$ javap -c -p %s\n' % cls + q.stdout.decode('utf-8', 'replace') + q.stderr.decode('utf-8', 'replace')
            results[ver] = clean(out, tmp)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    rel = os.path.relpath(path, ROOT).replace('\\', '/')
    name = header(src, 'OUT') or os.path.splitext(os.path.basename(path))[0].lower()
    vers = list(results)
    lines = ['# Запуск %s: labs/ch03-collections/%s' % (datetime.date.today().isoformat(), rel)]
    if results[vers[0]] == results[vers[1]]:
        lines.append('# Temurin JDK %s и JDK %s: вывод одинаковый' % tuple(vers))
        lines.append(results[vers[0]].rstrip('\n'))
    else:
        for v in vers:
            lines.append('# ---- Temurin JDK %s' % v)
            lines.append(results[v].rstrip('\n'))
    dst = os.path.join(ROOT, name + '.txt')
    open(dst, 'w', encoding='utf-8', newline='\n').write('\n'.join(lines) + '\n')
    print('==>', os.path.basename(dst))
    print('\n'.join(lines[1:]))


if __name__ == '__main__':
    files = sys.argv[1:] or sorted(glob.glob(os.path.join(ROOT, 'src', 's*', '*.java')))
    for f in files:
        for g in sorted(glob.glob(f)) or [f]:
            run_one(g)
