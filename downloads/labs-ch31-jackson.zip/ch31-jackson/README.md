# Неизвестное поле и неизвестное значение enum в Jackson 2, Jackson 3 и маппере Spring Boot 4

Стенд к главе 31, раздел 7.1 (терпимый читатель событий). Класс `JacksonUnknown` читает одно и то же событие платежа тремя мапперами: `new ObjectMapper()` из Jackson 2.22, `JsonMapper.builder().build()` из Jackson 3.1 и бин `JsonMapper`, который создает автоконфигурация Spring Boot 4.1.1. Событие приходит в двух вариантах: с лишним полем `cashback` и с незнакомым значением статуса `REFUNDED`. Вывод автора - `s31-jackson.txt`.

## Что нужно

- JDK 21, Maven.

## Запуск

```bash
mvn -q compile exec:java
```

В IDEA есть конфигурация `JacksonUnknown`.

## Что должно получиться

Jackson 2 падает на лишнем поле с `UnrecognizedPropertyException`, Jackson 3 и маппер Spring Boot читают такое событие без ошибки (`FAIL_ON_UNKNOWN_PROPERTIES` выключен по умолчанию); незнакомое значение enum все три варианта отвергают с `InvalidFormatException`.
