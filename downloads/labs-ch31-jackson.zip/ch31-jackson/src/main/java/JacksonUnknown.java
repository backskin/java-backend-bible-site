import java.util.List;

/** Глава 31: как Jackson 2 и Jackson 3 (и маппер Spring Boot 4) реагируют на неизвестное поле и неизвестное значение enum. */
public class JacksonUnknown {
    public enum Status { NEW, PAID, UNKNOWN }
    public record Payment(String id, long amount, Status status) {}

    static final String UNKNOWN_FIELD = "{\"id\":\"p1\",\"amount\":100,\"status\":\"PAID\",\"cashback\":5}";
    static final String UNKNOWN_ENUM = "{\"id\":\"p1\",\"amount\":100,\"status\":\"REFUNDED\"}";

    interface Reader { Object read(String json) throws Exception; }

    static void probe(String label, Reader r) {
        for (String[] c : List.of(new String[]{"неизвестное поле", UNKNOWN_FIELD}, new String[]{"неизвестный enum", UNKNOWN_ENUM})) {
            try {
                System.out.println("  " + label + ", " + c[0] + ": прочитано " + r.read(c[1]));
            } catch (Exception e) {
                System.out.println("  " + label + ", " + c[0] + ": " + e.getClass().getSimpleName());
            }
        }
    }

    public static void main(String[] a) throws Exception {
        var m2 = new com.fasterxml.jackson.databind.ObjectMapper();
        System.out.println("Jackson 2: " + com.fasterxml.jackson.databind.cfg.PackageVersion.VERSION);
        probe("new ObjectMapper()", j -> m2.readValue(j, Payment.class));
        var m3 = tools.jackson.databind.json.JsonMapper.builder().build();
        System.out.println("Jackson 3: " + tools.jackson.databind.cfg.PackageVersion.VERSION);
        probe("JsonMapper.builder().build()", j -> m3.readValue(j, Payment.class));
        System.out.println("  FAIL_ON_UNKNOWN_PROPERTIES по умолчанию в Jackson 3: "
                + m3.isEnabled(tools.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES));
        var ctx = new org.springframework.boot.builder.SpringApplicationBuilder(Cfg.class).web(org.springframework.boot.WebApplicationType.NONE)
                .logStartupInfo(false).run();
        var boot = ctx.getBean(tools.jackson.databind.json.JsonMapper.class);
        System.out.println("Spring Boot " + org.springframework.boot.SpringBootVersion.getVersion() + ", бин JsonMapper из автоконфигурации:");
        probe("маппер Spring Boot", j -> boot.readValue(j, Payment.class));
        System.out.println("  FAIL_ON_UNKNOWN_PROPERTIES у маппера Spring Boot: "
                + boot.isEnabled(tools.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES));
        ctx.close();
    }

    @org.springframework.context.annotation.Configuration @org.springframework.boot.autoconfigure.EnableAutoConfiguration
    static class Cfg {}
}
