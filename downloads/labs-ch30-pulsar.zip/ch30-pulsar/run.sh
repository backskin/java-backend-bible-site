#!/bin/bash
# Запуск сценария: ./run.sh <сценарий>; вывод в UTF-8
cd "$(dirname "$0")"
CP="target/classes;$(cat cp.txt)"
java -Dstdout.encoding=UTF-8 -Dorg.slf4j.simpleLogger.defaultLogLevel=warn -cp "$CP" dev.team.pulsar.PulsarLab "$@" 2>&1 | grep -v "SLF4J\|ForgivingExceptionHandler"
