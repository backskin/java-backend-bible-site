package dev.team.pulsar;

import org.apache.pulsar.client.api.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Опыты гл. 30 на Apache Pulsar. Сервер: docker run -d --name p30 -p 6650:6650 -p 8080:8080 apachepulsar/pulsar:4.0.7 bin/pulsar standalone
 */
public class PulsarLab {
    static void p(String f, Object... a) { System.out.println(String.format(f, a)); }
    static long t0 = System.currentTimeMillis();
    static String ts() { return String.format("%6d мс", System.currentTimeMillis() - t0); }

    public static void main(String[] args) throws Exception {
        try (PulsarClient c = PulsarClient.builder().serviceUrl("pulsar://localhost:6650").build()) {
            p("pulsar-client %s, сценарий %s", PulsarClient.class.getPackage().getImplementationVersion(), args[0]);
            String topic = "persistent://public/default/lab-" + args[0] + "-" + System.currentTimeMillis();
            switch (args[0]) {
                case "exclusive" -> exclusive(c, topic);
                case "shared" -> shared(c, topic);
                case "keyshared" -> keyShared(c, topic, args.length > 1 && args[1].equals("batching"));
                case "dlq" -> dlq(c, topic);
                case "replay" -> replay(c, topic);
                default -> throw new IllegalArgumentException(args[0]);
            }
        }
    }

    static void exclusive(PulsarClient c, String topic) throws Exception {
        Consumer<String> a = c.newConsumer(Schema.STRING).topic(topic).subscriptionName("ledger").subscriptionType(SubscriptionType.Exclusive).subscribe();
        try {
            c.newConsumer(Schema.STRING).topic(topic).subscriptionName("ledger").subscriptionType(SubscriptionType.Exclusive).subscribe();
        } catch (PulsarClientException e) {
            p("второй Exclusive-потребитель подписки ledger: %s: %s", e.getClass().getSimpleName(), e.getMessage().lines().findFirst().orElse(""));
        }
        Consumer<String> f1 = c.newConsumer(Schema.STRING).topic(topic).subscriptionName("ledger-fo").subscriptionType(SubscriptionType.Failover).consumerName("f1").subscribe();
        Consumer<String> f2 = c.newConsumer(Schema.STRING).topic(topic).subscriptionName("ledger-fo").subscriptionType(SubscriptionType.Failover).consumerName("f2").subscribe();
        try (Producer<String> pr = c.newProducer(Schema.STRING).topic(topic).create()) {
            for (int i = 1; i <= 4; i++) pr.send("проводка " + i);
        }
        Map<String, Integer> got = new TreeMap<>();
        for (Consumer<String> x : List.of(f1, f2)) {
            int n = 0;
            Message<String> m;
            while ((m = x.receive(500, TimeUnit.MILLISECONDS)) != null) { x.acknowledge(m); n++; }
            got.put(x.getConsumerName(), n);
        }
        p("Failover, два потребителя: %s", got);
        a.close(); f1.close(); f2.close();
    }

    // Shared: неподтверждённое сообщение упавшего потребителя приходит другому позже
    static void shared(PulsarClient c, String topic) throws Exception {
        List<String> order = Collections.synchronizedList(new ArrayList<>());
        Consumer<String> a = c.newConsumer(Schema.STRING).topic(topic).subscriptionName("settle").subscriptionType(SubscriptionType.Shared)
                .consumerName("A").receiverQueueSize(1).subscribe();
        Consumer<String> b = c.newConsumer(Schema.STRING).topic(topic).subscriptionName("settle").subscriptionType(SubscriptionType.Shared)
                .consumerName("B").receiverQueueSize(1).subscribe();
        try (Producer<String> pr = c.newProducer(Schema.STRING).topic(topic).enableBatching(false).create()) {
            for (int i = 1; i <= 6; i++) pr.send("m" + i);
        }
        Message<String> held = b.receive(2, TimeUnit.SECONDS);
        p("%s B получил %s и «упал» до подтверждения", ts(), held.getValue());
        Thread.sleep(200);
        Message<String> m;
        int i = 0;
        while (i++ < 3 && (m = a.receive(300, TimeUnit.MILLISECONDS)) != null) { order.add("A:" + m.getValue()); a.acknowledge(m); }
        b.close();
        while ((m = a.receive(2, TimeUnit.SECONDS)) != null) { order.add("A:" + m.getValue() + (m.getRedeliveryCount() > 0 ? "(повторно " + m.getRedeliveryCount() + ")" : "")); a.acknowledge(m); }
        p("порядок обработки у A: %s", order);
        try {
            a.acknowledgeCumulative(MessageId.latest);
        } catch (PulsarClientException e) {
            p("acknowledgeCumulative на Shared: %s", e.getMessage());
        }
        a.close();
    }

    // Key_Shared: один ключ — один потребитель
    static void keyShared(PulsarClient c, String topic, boolean batching) throws Exception {
        Map<String, Set<String>> keyToConsumers = new ConcurrentHashMap<>();
        List<Consumer<String>> cs = new ArrayList<>();
        for (String name : List.of("C1", "C2", "C3")) {
            cs.add(c.newConsumer(Schema.STRING).topic(topic).subscriptionName("accounts").subscriptionType(SubscriptionType.Key_Shared)
                    .consumerName(name).messageListener((cons, msg) -> {
                        keyToConsumers.computeIfAbsent(msg.getKey(), k -> ConcurrentHashMap.newKeySet()).add(cons.getConsumerName());
                        cons.acknowledgeAsync(msg);
                    }).subscribe());
        }
        ProducerBuilder<String> pb = c.newProducer(Schema.STRING).topic(topic);
        if (!batching) pb.enableBatching(false); else pb.batchingMaxPublishDelay(50, TimeUnit.MILLISECONDS);
        try (Producer<String> pr = pb.create()) {
            List<CompletableFuture<MessageId>> fs = new ArrayList<>();
            for (int i = 0; i < 200; i++) fs.add(pr.newMessage().key("счёт-" + (i % 10)).value("проводка " + i).sendAsync());
            CompletableFuture.allOf(fs.toArray(new CompletableFuture[0])).get();
        }
        Thread.sleep(2000);
        long split = keyToConsumers.values().stream().filter(s -> s.size() > 1).count();
        p("Key_Shared, батчинг производителя %s: ключей %d, ключей у двух и более потребителей: %d; %s",
                batching ? "по умолчанию (включён)" : "выключен", keyToConsumers.size(), split, new TreeMap<>(keyToConsumers));
        for (Consumer<String> x : cs) x.close();
    }

    // DLQ после maxRedeliverCount
    static void dlq(PulsarClient c, String topic) throws Exception {
        AtomicInteger calls = new AtomicInteger();
        Consumer<String> cons = c.newConsumer(Schema.STRING).topic(topic).subscriptionName("payments").subscriptionType(SubscriptionType.Shared)
                .negativeAckRedeliveryDelay(200, TimeUnit.MILLISECONDS)
                .deadLetterPolicy(DeadLetterPolicy.builder().maxRedeliverCount(3).build())
                .messageListener((x, msg) -> {
                    p("%s доставка %d, redeliveryCount=%d: %s — negativeAcknowledge", ts(), calls.incrementAndGet(), msg.getRedeliveryCount(), msg.getValue());
                    x.negativeAcknowledge(msg);
                }).subscribe();
        try (Producer<String> pr = c.newProducer(Schema.STRING).topic(topic).create()) { pr.send("{битый json"); }
        Thread.sleep(4000);
        cons.close();
        String dlqTopic = topic + "-payments-DLQ";
        try (Consumer<String> d = c.newConsumer(Schema.STRING).topic(dlqTopic).subscriptionName("ops")
                .subscriptionInitialPosition(SubscriptionInitialPosition.Earliest).subscribe()) {
            Message<String> m = d.receive(3, TimeUnit.SECONDS);
            p("в %s: %s, свойства %s", dlqTopic.substring(dlqTopic.lastIndexOf('/') + 1), m == null ? null : m.getValue(), m == null ? null : m.getProperties());
        }
    }

    // Чтение без разрушения: перемотка курсора подписки
    static void replay(PulsarClient c, String topic) throws Exception {
        try (Producer<String> pr = c.newProducer(Schema.STRING).topic(topic).create()) {
            for (int i = 1; i <= 3; i++) pr.send("событие " + i);
        }
        Consumer<String> cons = c.newConsumer(Schema.STRING).topic(topic).subscriptionName("reports")
                .subscriptionInitialPosition(SubscriptionInitialPosition.Earliest).subscribe();
        int n = 0;
        Message<String> m;
        while ((m = cons.receive(500, TimeUnit.MILLISECONDS)) != null) { cons.acknowledge(m); n++; }
        p("первое чтение подписки reports: %d", n);
        cons.seek(MessageId.earliest);
        n = 0;
        while ((m = cons.receive(1, TimeUnit.SECONDS)) != null) { cons.acknowledge(m); n++; }
        p("после seek(earliest): %d", n);
        cons.close();
    }
}
