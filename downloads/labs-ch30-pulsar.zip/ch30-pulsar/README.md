# Apache Pulsar 4.0: подписки Exclusive, Shared и Key_Shared, negativeAcknowledge и DLQ, повторное чтение, пакетирование и ключи

Стенд к главе 30, раздел о Pulsar. `PulsarLab` (pulsar-client 4.0.7) выполняет сценарий за запуск против Pulsar 4.0.7 standalone в Docker: `exclusive` (второй потребитель получает `ConsumerBusyException`), `shared` (потребитель "упал" до подтверждения, сообщение уходит другому), `dlq` (`negativeAcknowledge`, `redeliveryCount`, dead letter topic), `replay` (вторая подписка читает с начала), `keyshared` (распределение десяти ключей по трем потребителям без пакетирования и с аргументом `batching`, когда ключи перестают делиться). Выводы автора - `s30-pulsar-<сценарий>.txt`.

## Что нужно

- JDK 21, Maven, Docker, bash.

## Запуск

```bash
docker run -d --name p30 -p 6650:6650 -p 8080:8080 apachepulsar/pulsar:4.0.7 bin/pulsar standalone
```

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && bash run.sh keyshared
```

В IDEA есть конфигурация `PulsarLab` (сценарий - аргумент) и Shell-конфигурация `run`.

## Что должно получиться

Без пакетирования ни один ключ не достается двум потребителям; с пакетами по умолчанию все десять ключей уходят одному, пока не включен `BatcherBuilder.KEY_BASED`.
