# Spring Data R2DBC: слайс @DataR2dbcTest, схема из spring.sql.init, Flyway рядом с R2DBC, реестр с вложенным списком

Стенд к главе 11, раздел о R2DBC. Реестр платежей `RegistryApp` (Spring Boot 4.1.1, Spring Data R2DBC 4.1.1, r2dbc-postgresql, Flyway, WebFlux) и два теста: `PaymentSliceTest` (`@DataR2dbcTest`, схема из `spring.sql.init`) и `RegistryIntegrationTest` (R2DBC и Flyway в одном приложении, реестр со списком платежей - связей между сущностями в R2DBC нет, и это показано). База - PostgreSQL 17 в Testcontainers. Вывод автора - `s11-r2dbc.txt`.

## Что нужно

- JDK 21, Maven, Docker.

## Запуск

```bash
mvn -q test
```

В IDEA есть конфигурации `RegistryApp` и `mvn test`.

## Что должно получиться

`@DataR2dbcTest` создает две таблицы из `schema.sql`; интеграционный тест показывает, что Flyway идет по JDBC, а запросы приложения по R2DBC, и что вложенный список платежей приходится собирать вторым запросом.
