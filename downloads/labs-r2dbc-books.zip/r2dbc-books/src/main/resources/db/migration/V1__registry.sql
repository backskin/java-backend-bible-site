create table registries (id bigserial primary key, name varchar(64) not null);
create table payments (id bigserial primary key, registry_id bigint references registries(id),
  account varchar(20) not null, amount numeric(18,2) not null, status varchar(16) not null, version int not null);
