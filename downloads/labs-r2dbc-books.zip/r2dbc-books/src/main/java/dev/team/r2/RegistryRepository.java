package dev.team.r2;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface RegistryRepository extends ReactiveCrudRepository<Registry, Long> { }
