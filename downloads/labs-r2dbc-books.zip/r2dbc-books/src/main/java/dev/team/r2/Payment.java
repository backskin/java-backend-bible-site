package dev.team.r2;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Table;

import java.math.BigDecimal;

/** Платёж реестра; таблица payments, потому что order и payment удобнее не путать с ключевыми словами SQL. */
@Table("payments")
public record Payment(@Id Long id, Long registryId, String account, BigDecimal amount, String status, @Version Integer version) {
    public static Payment fresh(Long registryId, String account, String amount) {
        return new Payment(null, registryId, account, new BigDecimal(amount), "NEW", null);
    }
}
