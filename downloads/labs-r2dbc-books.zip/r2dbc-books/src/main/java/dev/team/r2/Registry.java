package dev.team.r2;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.List;

/** Реестр с вложенным списком платежей: так связь описывают в Spring Data JDBC. */
@Table("registries")
public record Registry(@Id Long id, String name, List<Payment> payments) { }
