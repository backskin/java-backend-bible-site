package dev.team.r2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Реестр платежей Тундра-Банка на R2DBC. */
@SpringBootApplication
public class RegistryApp {
    public static void main(String[] args) { SpringApplication.run(RegistryApp.class, args); }
}
