package dev.team.r2;

import io.r2dbc.spi.ConnectionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.ApplicationContext;
import org.springframework.r2dbc.core.DatabaseClient;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.postgresql.PostgreSQLContainer;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

import java.util.List;

/** Приложение целиком: Flyway через JDBC, данные через R2DBC, база из @ServiceConnection. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@Testcontainers
class RegistryIntegrationTest {

    @Container @ServiceConnection
    static PostgreSQLContainer postgres = new PostgreSQLContainer("postgres:17.9");

    @Autowired ConnectionFactory connectionFactory;
    @Autowired DatabaseClient db;
    @Autowired PaymentRepository payments;
    @Autowired RegistryRepository registries;
    @Autowired ApplicationContext ctx;

    @Test
    void wiring() {
        System.out.println("== R2DBC и Flyway в одном приложении");
        System.out.println("   ConnectionFactory: " + connectionFactory.getClass().getName());
        if (connectionFactory instanceof io.r2dbc.pool.ConnectionPool pool)
            System.out.println("   пул: максимум " + pool.getMetrics().map(m -> String.valueOf(m.getMaxAllocatedSize())).orElse("?")
                    + ", создано сейчас " + pool.getMetrics().map(m -> String.valueOf(m.allocatedSize())).orElse("?"));
        System.out.println("   бины DataSource: " + List.of(ctx.getBeanNamesForType(javax.sql.DataSource.class)));
        System.out.println("   бины Flyway: " + List.of(ctx.getBeanNamesForType(org.flywaydb.core.Flyway.class)));
        StepVerifier.create(db.sql("select version, description from flyway_schema_history order by installed_rank").map(r -> r.get(0) + " " + r.get(1)).all().collectList())
                .assertNext(v -> System.out.println("   flyway_schema_history: " + v)).verifyComplete();
    }

    @Test
    void saveAndRead() {
        System.out.println("== сохранение платежей и чтение по реестру");
        Long regId = db.sql("insert into registries(name) values ('реестр 2026-10-27') returning id").map(r -> r.get(0, Long.class)).one().block();
        Flux<Payment> saved = payments.saveAll(Flux.just(Payment.fresh(regId, "40817810000000000001", "1500.00"), Payment.fresh(regId, "40817810000000000002", "250.50")));
        StepVerifier.create(saved.thenMany(payments.findByRegistryId(regId)).map(p -> p.account() + ":" + p.amount() + ":v" + p.version()).collectList())
                .assertNext(l -> System.out.println("   прочитано: " + l)).verifyComplete();
    }

    @Test
    void relationship() {
        System.out.println("== реестр со списком платежей внутри (связь как в Spring Data JDBC)");
        StepVerifier.create(registries.save(new Registry(null, "реестр со связью", List.of(Payment.fresh(null, "40817810000000000003", "10.00")))))
                .consumeErrorWith(e -> System.out.println("   ошибка: " + e.getClass().getName() + ": " + e.getMessage().lines().findFirst().orElse("")))
                .verify();
    }
}
