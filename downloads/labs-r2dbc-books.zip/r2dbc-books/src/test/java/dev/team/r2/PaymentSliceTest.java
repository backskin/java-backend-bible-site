package dev.team.r2;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.r2dbc.test.autoconfigure.DataR2dbcTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.test.context.TestPropertySource;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.postgresql.PostgreSQLContainer;
import reactor.test.StepVerifier;

/** Срез R2DBC: схема из spring.sql.init, Flyway выключен. */
@DataR2dbcTest
@Testcontainers
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.sql.init.mode=always",
        "spring.sql.init.schema-locations=classpath:registry-schema.sql"})
class PaymentSliceTest {

    @Container @ServiceConnection
    static PostgreSQLContainer postgres = new PostgreSQLContainer("postgres:17.9");

    @Autowired PaymentRepository payments;
    @Autowired DatabaseClient db;

    @Test
    void schemaFromSqlInit() {
        System.out.println("== @DataR2dbcTest и схема из spring.sql.init");
        StepVerifier.create(db.sql("select count(*) from information_schema.tables where table_name in ('payments','registries')").map(r -> r.get(0, Long.class)).one())
                .assertNext(n -> System.out.println("   таблиц создано: " + n)).verifyComplete();
        StepVerifier.create(payments.save(Payment.fresh(null, "40817810000000000009", "99.90")).map(p -> "id=" + p.id() + " version=" + p.version()))
                .assertNext(s -> System.out.println("   сохранён: " + s)).verifyComplete();
    }
}
