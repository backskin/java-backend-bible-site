# Виртуальные потоки на JDK 21 и 25: ожидание и вычисления, прикрепление, компенсация, дампы

Стенд к главе 02, разделы 5 и 12. Программы в `src/` показывают, где виртуальные потоки выигрывают (`IoVsCpu`), что они не вытесняются (`NoPreemption`), как прикрепление к носителю выглядит в `synchronized`, в статическом инициализаторе и в нативном вызове (`PinSync`, `PinClinit`, `PinNative`, событие JFR в `PinJfr`), как планировщик компенсирует блокировку (`Compensation`) и какие свойства у виртуального потока (`VtProps`). Выводы автора - в `s5-*.txt` и `s12-json-states.txt`; замеры прежней редакции главы сохранены в `old-runs.md`.

## Что нужно

- Temurin JDK 21.0.10 и 25.0.5 в `~/.jdks` (словарь `ALL` в `run.py`, пути в `dump.sh` и `json_states.sh`).
- Python 3; для `json_states.sh` - Python в `PATH`.

## Запуск

```bash
python -X utf8 run.py
```

Флаги планировщика (`-Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=1` и другие) заданы в заголовках программ строкой `// JAVA:`, так что отдельно их передавать не нужно. Дампы потоков - два скрипта, каждый сам поднимает `Sleepers` с 1000 спящих виртуальных потоков:

```bash
sh dump.sh > s5-dump.txt 2>&1
```

```bash
sh json_states.sh > s12-json-states.txt 2>&1
```

Первый сравнивает `jstack` и `jcmd Thread.dump_to_file -format=json`, второй показывает структуру JSON-дампа (на 25 у потока есть поле `state`, на 21 нет).

## Что должно получиться

Времена в `s5-io-vs-cpu.txt`, `s5-compensation.txt` и `s5-pin-*.txt` зависят от числа процессоров и машины, соотношения сохраняются: четыре задачи по 500 мс в `synchronized` на одном носителе на JDK 21 занимают около двух секунд, на 25 - около половины секунды. `PinNative` рассчитан на Windows (вызывает `Sleep` из `kernel32`).
