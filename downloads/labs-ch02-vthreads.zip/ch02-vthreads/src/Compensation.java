// JDKS: 21 25
// JAVA: -Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=8
// OUT: s5-compensation
// Компенсация: при прикреплении планировщик может временно добавить носителей сверх parallelism (до maxPoolSize).
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;

public class Compensation {
    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version") + ", parallelism=1, maxPoolSize=8");
        for (String kind : new String[]{"synchronized + sleep(500)", "synchronized + wait(500)"}) {
            Set<String> carriers = ConcurrentHashMap.newKeySet();
            long t0 = System.nanoTime();
            try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
                for (int i = 0; i < 4; i++) {
                    ex.submit(() -> {
                        Object m = new Object();
                        synchronized (m) {
                            carriers.add(Thread.currentThread().toString().replaceAll(".*@", ""));
                            if (kind.contains("wait")) m.wait(500); else Thread.sleep(500);
                        }
                        return null;
                    });
                }
            }
            System.out.printf("%-26s 4 задачи: %5d мс, разных носителей: %d%n", kind, (System.nanoTime() - t0) / 1_000_000, carriers.size());
        }
    }
}
