// JDKS: 21 25
// JAVA: -Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=1
// OUT: s5-pin-clinit
// Блокировка внутри статического инициализатора класса прикрепляет виртуальный поток и в JDK 24+.
import java.util.concurrent.Executors;

public class PinClinit {
    static class Tariffs {
        static final String VERSION;
        static {
            try { Thread.sleep(1000); } catch (InterruptedException e) { throw new RuntimeException(e); }
            VERSION = "2026-11";
        }
    }

    public static void main(String[] args) throws Exception {
        long t0 = System.nanoTime();
        try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
            ex.submit(() -> System.out.println("тарифы " + Tariffs.VERSION + " загружены через " + (System.nanoTime() - t0) / 1_000_000 + " мс"));
            Thread.sleep(50);
            ex.submit(() -> System.out.println("платёж, которому тарифы не нужны, обработан через " + (System.nanoTime() - t0) / 1_000_000 + " мс"));
        }
        System.out.println("java " + System.getProperty("java.version") + ", один носитель");
    }
}
