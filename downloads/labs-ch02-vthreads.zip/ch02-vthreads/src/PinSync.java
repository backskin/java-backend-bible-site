// JDKS: 21 25
// JAVA: -Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=1 -Djdk.tracePinnedThreads=short
// OUT: s5-pin-sync
// Прикрепление к носителю: synchronized, ReentrantLock и Object.wait при одном носителе.
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class PinSync {
    interface Body { void run() throws InterruptedException; }

    static void timed(String name, Body body) throws Exception {
        long t0 = System.nanoTime();
        try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < 4; i++) {
                ex.submit(() -> { body.run(); return null; });
            }
        }
        System.out.printf("%-30s %5d мс%n", name, (System.nanoTime() - t0) / 1_000_000);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version") + ", носителей 1, четыре задачи по 500 мс");
        timed("synchronized + sleep(500)", () -> {
            synchronized (new Object()) { Thread.sleep(500); }
        });
        timed("ReentrantLock + sleep(500)", () -> {
            var lock = new ReentrantLock();
            lock.lock();
            try { Thread.sleep(500); } finally { lock.unlock(); }
        });
        timed("synchronized + wait(500)", () -> {
            Object m = new Object();
            synchronized (m) { m.wait(500); }
        });
    }
}
