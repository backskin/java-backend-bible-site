// JDKS: 21 25
// JAVA: -Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=1
// OUT: s5-pin-jfr
// Событие JFR jdk.VirtualThreadPinned: 16 задач по 50 мс сна внутри synchronized.
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.concurrent.Executors;
import jdk.jfr.Recording;
import jdk.jfr.consumer.RecordingFile;

public class PinJfr {
    public static void main(String[] args) throws Exception {
        Path file = Files.createTempFile("pin", ".jfr");
        try (var r = new Recording()) {
            r.enable("jdk.VirtualThreadPinned").withThreshold(Duration.ofMillis(20)).withStackTrace();
            r.start();
            long t0 = System.nanoTime();
            try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
                for (int i = 0; i < 16; i++) {
                    ex.submit(() -> { synchronized (new Object()) { Thread.sleep(50); } return null; });
                }
            }
            System.out.println("java " + System.getProperty("java.version") + ": 16 задач по 50 мс в synchronized заняли "
                    + (System.nanoTime() - t0) / 1_000_000 + " мс");
            r.stop();
            r.dump(file);
        }
        var events = RecordingFile.readAllEvents(file);
        System.out.println("событий jdk.VirtualThreadPinned: " + events.size());
        if (!events.isEmpty()) {
            var e = events.get(0);
            System.out.println("длительность первого: ~" + e.getDuration().toMillis() + " мс");
            System.out.println("верх стека: " + e.getStackTrace().getFrames().stream().limit(3)
                    .map(f -> f.getMethod().getType().getName() + "." + f.getMethod().getName()).toList());
            e.getFields().forEach(f -> {
                if (!f.getName().matches("startTime|duration|eventThread|stackTrace"))
                    System.out.println("поле " + f.getName() + " = " + e.getValue(f.getName()));
            });
        }
        Files.delete(file);
    }
}
