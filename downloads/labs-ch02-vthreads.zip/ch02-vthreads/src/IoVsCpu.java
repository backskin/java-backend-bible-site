// JDKS: 21 25
// OUT: s5-io-vs-cpu
// Ожидание против вычислений: пул платформенных потоков и поток на задачу.
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

public class IoVsCpu {
    static long time(Runnable r) {
        long t0 = System.nanoTime();
        r.run();
        return (System.nanoTime() - t0) / 1_000_000;
    }

    static void sleepTasks(ExecutorService ex, int n) {
        try (ex) {
            IntStream.range(0, n).forEach(i -> ex.submit(() -> { Thread.sleep(1000); return i; }));
        }
    }

    static volatile long sink;

    static long burn(long n) {
        long s = 0;
        for (long i = 0; i < n; i++) s += i * i % 7;
        return s;
    }

    static void cpu(ExecutorService ex, int tasks) {
        try (ex) {
            for (int i = 0; i < tasks; i++) ex.submit(() -> sink += burn(400_000_000L));
        }
    }

    public static void main(String[] args) {
        int cores = Runtime.getRuntime().availableProcessors();
        System.out.println("java " + System.getProperty("java.version") + ", процессоров " + cores);
        System.out.println("10 000 задач по 1 с ожидания:");
        System.out.println("  пул из 200 платформенных потоков: " + time(() -> sleepTasks(Executors.newFixedThreadPool(200), 10_000)) + " мс");
        System.out.println("  виртуальный поток на задачу:      " + time(() -> sleepTasks(Executors.newVirtualThreadPerTaskExecutor(), 10_000)) + " мс");
        System.out.println("32 вычислительные задачи по 400 млн итераций:");
        System.out.println("  пул по числу ядер:                " + time(() -> cpu(Executors.newFixedThreadPool(cores), 32)) + " мс");
        System.out.println("  виртуальный поток на задачу:      " + time(() -> cpu(Executors.newVirtualThreadPerTaskExecutor(), 32)) + " мс");
        System.out.println("  один поток подряд:                " + time(() -> { for (int i = 0; i < 32; i++) sink += burn(400_000_000L); }) + " мс");
    }
}
