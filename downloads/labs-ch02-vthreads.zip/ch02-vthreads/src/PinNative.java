// JDKS: 25
// JAVA: -Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=1 --enable-native-access=ALL-UNNAMED
// OUT: s5-pin-native
// Нативный вызов через FFM (kernel32 Sleep) держит носитель и в JDK 25: JEP 491 касается только synchronized.
import java.lang.foreign.*;
import java.lang.invoke.MethodHandle;
import java.util.concurrent.Executors;

public class PinNative {
    public static void main(String[] args) throws Throwable {
        Linker linker = Linker.nativeLinker();
        SymbolLookup kernel32 = SymbolLookup.libraryLookup("kernel32", Arena.global());
        MethodHandle sleep = linker.downcallHandle(kernel32.find("Sleep").orElseThrow(),
                FunctionDescriptor.ofVoid(ValueLayout.JAVA_INT));
        for (String kind : new String[]{"Thread.sleep(200)", "kernel32 Sleep(200) через FFM"}) {
            long t0 = System.nanoTime();
            try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
                for (int i = 0; i < 5; i++) {
                    ex.submit(() -> {
                        if (kind.startsWith("Thread")) Thread.sleep(200);
                        else try { sleep.invokeExact(200); } catch (Throwable t) { throw new RuntimeException(t); }
                        return null;
                    });
                }
            }
            System.out.printf("%-30s x5 на одном носителе: %d мс%n", kind, (System.nanoTime() - t0) / 1_000_000);
        }
        System.out.println("java " + System.getProperty("java.version"));
    }
}
