// Вспомогательная программа для dump.sh: 1000 виртуальных потоков «ждут ответа шлюза» 60 с.
import java.util.concurrent.Executors;

public class Sleepers {
    public static void main(String[] args) throws Exception {
        var ex = Executors.newVirtualThreadPerTaskExecutor();
        for (int i = 0; i < 1000; i++) {
            ex.submit(() -> { Thread.sleep(60_000); return null; });
        }
        System.out.println("ready " + ProcessHandle.current().pid());
        Thread.sleep(60_000);
    }
}
