// JDKS: 21 25
// JAVA: -Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=1
// OUT: s5-no-preemption
// Вытеснения по времени нет: вычисление занимает носитель, пока не закончится.
import java.util.concurrent.Executors;

public class NoPreemption {
    static volatile long sink;

    public static void main(String[] args) throws Exception {
        long t0 = System.nanoTime();
        try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
            ex.submit(() -> {
                long s = 0;
                for (long i = 0; i < 3_000_000_000L; i++) s += i % 7;
                sink = s;
                System.out.println("расчёт скоринга закончен через " + (System.nanoTime() - t0) / 1_000_000 + " мс");
            });
            Thread.sleep(20);
            ex.submit(() -> System.out.println("проверка лимита выполнена через " + (System.nanoTime() - t0) / 1_000_000 + " мс"));
        }
        System.out.println("java " + System.getProperty("java.version") + ", один носитель");
    }
}
