// JDKS: 21 25
// OUT: s5-vt-props
// Свойства виртуального потока: имя, демон, приоритет, группа, наследование InheritableThreadLocal.
public class VtProps {
    static final InheritableThreadLocal<String> TENANT = new InheritableThreadLocal<>();

    public static void main(String[] args) throws Exception {
        TENANT.set("bank-1");
        Thread vt = Thread.ofVirtual().unstarted(() -> {
            Thread t = Thread.currentThread();
            System.out.println("имя: '" + t.getName() + "', isVirtual: " + t.isVirtual() + ", isDaemon: " + t.isDaemon()
                    + ", приоритет: " + t.getPriority() + ", группа: " + t.getThreadGroup().getName());
            System.out.println("InheritableThreadLocal по умолчанию: " + TENANT.get());
            t.setPriority(Thread.MAX_PRIORITY);
            System.out.println("после setPriority(10): " + t.getPriority());
        });
        vt.start();
        vt.join();
        try {
            Thread.ofVirtual().unstarted(() -> { }).setDaemon(false);
        } catch (IllegalArgumentException e) {
            System.out.println("setDaemon(false): " + e);
        }
        Thread named = Thread.ofVirtual().name("payment-", 0).inheritInheritableThreadLocals(false)
                .start(() -> System.out.println("имя: " + Thread.currentThread().getName() + ", InheritableThreadLocal: " + TENANT.get()));
        named.join();
        Thread carrierView = Thread.ofVirtual().name("limits").start(() -> System.out.println("toString изнутри: " + Thread.currentThread()));
        carrierView.join();
        System.out.println("подкласс Thread виртуальным не бывает: isVirtual=" + new Thread() { }.isVirtual());
    }
}
