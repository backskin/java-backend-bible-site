#!/bin/sh
# Опыт 5.6 и 12: виртуальные потоки в jstack и в jcmd Thread.dump_to_file -format=json; размер стека по умолчанию.
# Запуск: sh dump.sh > s5-dump.txt 2>&1
cd "$(dirname "$0")"
for J in ~/.jdks/temurin-21.0.10/bin ~/.jdks/jdk-25.0.5+8/bin; do
  echo "# ---- $($J/java -version 2>&1 | head -1)"
  T=$(mktemp -d)
  $J/javac -d $T src/Sleepers.java
  $J/java -cp $T Sleepers > $T/out.txt 2>&1 &
  PID=$!
  for i in 1 2 3 4 5 6 7 8 9 10; do grep -q ready $T/out.txt && break; sleep 1; done
  JPID=$(sed -n 's/ready //p' $T/out.txt)
  echo "jstack: строк с VirtualThread или Thread.sleep в виртуальных потоках: $($J/jstack $JPID | grep -c 'VirtualThread\[')"
  echo "jstack: всего потоков в дампе: $($J/jstack $JPID | grep -c '^\"')"
  $J/jcmd $JPID Thread.dump_to_file -format=json $T/dump.json > /dev/null
  echo "jcmd Thread.dump_to_file -format=json: всего потоков (\"tid\"): $(grep -c '"tid"' $T/dump.json), из них с ключом \"virtual\": true: $(grep -c '"virtual": true' $T/dump.json), кадров VirtualThread.sleepNanos: $(grep -c 'VirtualThread.sleepNanos' $T/dump.json)"
  echo "jcmd Thread.vthread_scheduler:"; $J/jcmd $JPID Thread.vthread_scheduler 2>&1 | sed -n '2,6p'
  kill $PID 2>/dev/null; wait $PID 2>/dev/null
  rm -rf $T
done
echo "# ---- размер стека платформенного потока по умолчанию"
for J in ~/.jdks/temurin-21.0.10/bin ~/.jdks/jdk-25.0.5+8/bin; do
  echo "$($J/java -version 2>&1 | head -1): $($J/java -XX:+PrintFlagsFinal -version 2>/dev/null | grep -E ' ThreadStackSize ')"
done
