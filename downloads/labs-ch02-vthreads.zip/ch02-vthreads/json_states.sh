#!/bin/sh
# Опыт 12.1: структура JSON-дампа jcmd Thread.dump_to_file на JDK 21 и 25 (есть ли у потоков поле state).
# Запуск: sh json_states.sh > s12-json-states.txt 2>&1
cd "$(dirname "$0")"
export PYTHONIOENCODING=utf-8
for J in ~/.jdks/temurin-21.0.10/bin ~/.jdks/jdk-25.0.5+8/bin; do
  T=$(mktemp -d); W=$(cygpath -m $T)
  $J/javac -d $T src/Sleepers.java
  $J/java -cp $T Sleepers > $T/out.txt 2>&1 & PID=$!
  for i in 1 2 3 4 5 6 7 8 9 10; do grep -q ready $T/out.txt && break; sleep 1; done
  JPID=$(sed -n 's/ready //p' $T/out.txt)
  $J/jcmd $JPID Thread.dump_to_file -format=json $W/d.json > /dev/null
  echo "# $($J/java -version 2>&1 | head -1)"
  python -c "
import json,collections
d=json.load(open(r'$W/d.json'))
print('ключи threadDump:', list(d['threadDump'].keys()))
print('ключи потока:', list(d['threadDump']['threadContainers'][0]['threads'][0].keys()))
print('состояния:', dict(collections.Counter(t.get('state') for c in d['threadDump']['threadContainers'] for t in c.get('threads',[]))))
"
  kill $PID; wait $PID 2>/dev/null; rm -rf $T
done
