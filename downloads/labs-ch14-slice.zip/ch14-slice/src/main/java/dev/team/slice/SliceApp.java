package dev.team.slice;

import java.math.BigDecimal;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SliceApp {
    public static void main(String[] args) { SpringApplication.run(SliceApp.class, args); }
}

record Limit(String account, BigDecimal daily) {}

@Service
class LimitService {
    Limit find(String account) { return new Limit(account, new BigDecimal("100000.00")); }
}

@RestController
class LimitController {
    private final LimitService service;
    LimitController(LimitService service) { this.service = service; }

    @GetMapping("/api/limits/{account}")
    Limit limit(@PathVariable String account) { return service.find(account); }
}

/** Конфигурация безопасности: чтение лимитов открыто всем, остальное — только после входа. */
@Configuration
@EnableWebSecurity
class SecurityConfig {
    @Bean
    SecurityFilterChain api(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(a -> a.requestMatchers("/api/limits/**").permitAll().anyRequest().authenticated())
            .httpBasic(b -> { });
        return http.build();
    }
}
