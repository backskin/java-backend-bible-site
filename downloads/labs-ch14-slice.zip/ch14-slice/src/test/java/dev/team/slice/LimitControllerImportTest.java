package dev.team.slice;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.assertj.MockMvcTester;

/** Сверка утверждений книг о срезе @WebMvcTest на Boot 4.1.1; результаты печатаются в stdout. */
@WebMvcTest(LimitController.class)
@org.springframework.context.annotation.Import(SecurityConfig.class)
class LimitControllerImportTest {
    @Autowired MockMvcTester mvc;
    @Autowired ApplicationContext ctx;
    @MockitoBean LimitService service;

    @Test
    void sliceContents() {
        given(service.find("40817")).willReturn(new Limit("40817", new BigDecimal("100000.00")));
        var result = mvc.get().uri("/api/limits/40817").exchange();
        System.out.println("== @WebMvcTest(LimitController.class) + @Import(SecurityConfig.class), Spring Boot " + org.springframework.boot.SpringBootVersion.getVersion()
                + ", JUnit Jupiter " + Test.class.getPackage().getImplementationVersion());
        System.out.println("   GET /api/limits/40817 → " + result.getResponse().getStatus() + " " + contentOf(result));
        System.out.println("   бин securityConfig в срезе: " + ctx.containsBean("securityConfig"));
        System.out.println("   бины SecurityFilterChain: " + String.join(", ", ctx.getBeanNamesForType(org.springframework.security.web.SecurityFilterChain.class)));
        System.out.println("   бины tools.jackson.databind.json.JsonMapper: " + String.join(", ", ctx.getBeanNamesForType(tools.jackson.databind.json.JsonMapper.class)));
        System.out.println("   бин LimitService в срезе — заглушка Mockito: " + org.mockito.Mockito.mockingDetails(ctx.getBean(LimitService.class)).isMock());
        for (String cls : new String[] {
                "org.springframework.boot.test.mock.mockito.MockBean",
                "org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest",
                "org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest",
                "org.springframework.test.web.servlet.client.RestTestClient",
                "org.springframework.test.web.servlet.assertj.MockMvcTester",
                "com.fasterxml.jackson.databind.ObjectMapper"}) {
            boolean present;
            try { Class.forName(cls); present = true; } catch (ClassNotFoundException e) { present = false; }
            System.out.println("   класс " + cls + ": " + (present ? "есть" : "нет"));
        }
        assertThat(result).hasStatusOk();
    }

    private static String contentOf(org.springframework.test.web.servlet.assertj.MvcTestResult r) {
        try { return r.getResponse().getContentAsString(); } catch (Exception e) { return e.toString(); }
    }
}
