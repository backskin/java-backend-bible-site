# Срез @WebMvcTest и своя конфигурация безопасности: 401 без @Import, 200 с ним

Стенд к главе 14, раздел 12.2. Приложение `SliceApp` (Spring Boot 4.1.1, Security) с `SecurityConfig`, открывающей `/api/limits/**`, и два теста на `LimitController`: `LimitControllerSliceTest` без импорта конфигурации и `LimitControllerImportTest` с `@Import(SecurityConfig.class)`; тесты печатают статус и имя бина `SecurityFilterChain` в контексте, а также проверяют, что классов `MockBean`, старого `WebMvcTest` и `com.fasterxml.jackson.databind.ObjectMapper` в Boot 4 нет. Вывод автора - `s14-slice.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q test
```

В IDEA есть конфигурации `SliceApp` и `mvn test`.

## Что должно получиться

Без импорта `GET /api/limits/40817` дает 401 и в контексте `defaultSecurityFilterChain`; с импортом - 200 и цепочка `api`. Упражнение главы: закрыть путь в `SecurityConfig` и посмотреть, какой из тестов это заметит.
