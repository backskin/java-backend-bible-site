# NATS и JetStream: core без хранения, WorkQueue против Limits, повторная доставка, дедупликация, один потребитель на стрим

Стенд к главе 30, раздел о NATS. `NatsLab` (jnats 2.26.4) выполняет сценарий за запуск против nats-server 2.15.2 с `-js`: `core` (подписчик, подключившийся после публикации, прошлого не видит), `retention` (стрим `limits`: после ack сообщение остается) и `redeliver` (стрим `workqueue`: сообщение без ack приходит снова), `dedup` (`Nats-Msg-Id` и окно дубликатов 2 минуты), `wpi` (у WorkQueue один потребитель на фильтр). Выводы автора - `s30-nats-<сценарий>.txt`.

## Что нужно

- JDK 21, Maven, Docker, bash.

## Запуск

```bash
docker run -d --name n30 -p 4222:4222 nats:latest -js
```

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && bash run.sh retention
```

В IDEA есть конфигурация `NatsLab` (сценарий - аргумент) и Shell-конфигурация `run`.

## Что должно получиться

Для стрима `workqueue` после ack `nats stream info` показывает меньше сообщений, для `limits` число не меняется: переключатель между очередью и логом - одна настройка `retention`.
