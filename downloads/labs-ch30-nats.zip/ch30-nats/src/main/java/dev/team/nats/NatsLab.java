package dev.team.nats;

import io.nats.client.*;
import io.nats.client.api.*;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;

/**
 * Опыты гл. 30 на NATS и JetStream. Сервер: docker run -d --name n30 -p 4222:4222 nats -js
 */
public class NatsLab {
    static void p(String f, Object... a) { System.out.println(String.format(f, a)); }
    static byte[] b(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    static String s(byte[] b) { return new String(b, StandardCharsets.UTF_8); }
    static long t0 = System.currentTimeMillis();
    static String ts() { return String.format("%6d мс", System.currentTimeMillis() - t0); }

    public static void main(String[] args) throws Exception {
        try (Connection nc = Nats.connect("nats://localhost:4222")) {
            p("jnats %s, сервер %s, сценарий %s", Nats.CLIENT_VERSION, nc.getServerInfo().getVersion(), args[0]);
            switch (args[0]) {
                case "core" -> core(nc);
                case "redeliver" -> redeliver(nc);
                case "dedup" -> dedup(nc);
                case "retention" -> retention(nc);
                case "wpi" -> wpi(nc);
                default -> throw new IllegalArgumentException(args[0]);
            }
        }
    }

    // Core NATS: сообщение без подписчика пропадает
    static void core(Connection nc) throws Exception {
        nc.publish("rates.usd", b("курс 1 — подписчиков ещё нет"));
        nc.flush(Duration.ofSeconds(1));
        Subscription sub = nc.subscribe("rates.*");
        nc.publish("rates.usd", b("курс 2 — подписчик есть"));
        nc.flush(Duration.ofSeconds(1));
        List<String> got = new ArrayList<>();
        Message m;
        while ((m = sub.nextMessage(Duration.ofMillis(500))) != null) got.add(s(m.getData()));
        p("подписчик, подключившийся после первой публикации, получил: %s", got);
        // запрос-ответ без ответчика
        long st = System.currentTimeMillis();
        Object res;
        try { res = nc.request("limits.check", b("карта 4276"), Duration.ofSeconds(1)); } catch (Exception e) { res = e; }
        p("request без ответчика: вернул %s за %d мс", res, System.currentTimeMillis() - st);
    }

    static JetStreamManagement stream(Connection nc, String name, RetentionPolicy rp, String... subjects) throws Exception {
        JetStreamManagement jsm = nc.jetStreamManagement();
        try { jsm.deleteStream(name); } catch (JetStreamApiException ignored) {}
        StreamInfo si = jsm.addStream(StreamConfiguration.builder().name(name).subjects(subjects)
                .retentionPolicy(rp).storageType(StorageType.File).build());
        p("стрим %s: retention=%s, duplicateWindow=%s, maxAge=%s, replicas=%d", name, si.getConfiguration().getRetentionPolicy(),
                si.getConfiguration().getDuplicateWindow(), si.getConfiguration().getMaxAge(), si.getConfiguration().getReplicas());
        return jsm;
    }

    // Повторная доставка по AckWait и предел MaxDeliver
    static void redeliver(Connection nc) throws Exception {
        JetStreamManagement jsm = stream(nc, "SETTLEMENT", RetentionPolicy.WorkQueue, "settle.>");
        ConsumerInfo ci = jsm.addOrUpdateConsumer("SETTLEMENT", ConsumerConfiguration.builder().durable("settler")
                .ackWait(Duration.ofSeconds(2)).maxDeliver(3).build());
        p("потребитель: ackPolicy=%s, maxAckPending=%d, ackWait=%s, maxDeliver=%d", ci.getConsumerConfiguration().getAckPolicy(),
                ci.getConsumerConfiguration().getMaxAckPending(), ci.getConsumerConfiguration().getAckWait(), ci.getConsumerConfiguration().getMaxDeliver());
        JetStream js = nc.jetStream();
        js.publish("settle.card", b("клиринг пачки 2026-11-02"));
        JetStreamSubscription sub = js.subscribe(null, PullSubscribeOptions.bind("SETTLEMENT", "settler"));
        for (int i = 0; i < 5; i++) {
            List<Message> l = sub.fetch(1, Duration.ofSeconds(3));
            if (l.isEmpty()) { p("%s fetch: пусто", ts()); continue; }
            Message m = l.get(0);
            p("%s доставка %d (redelivered=%s): %s — ack не отправлен", ts(), m.metaData().deliveredCount(), m.isJetStream() && m.metaData().deliveredCount() > 1, s(m.getData()));
        }
        ConsumerInfo after = jsm.getConsumerInfo("SETTLEMENT", "settler");
        p("после MaxDeliver: ackPending=%d, redelivered=%d, в стриме сообщений=%d", after.getNumAckPending(), after.getRedelivered(),
                jsm.getStreamInfo("SETTLEMENT").getStreamState().getMsgCount());
        try {
            jsm.addOrUpdateConsumer("SETTLEMENT", ConsumerConfiguration.builder().durable("second").build());
            p("второй потребитель без фильтра на WorkQueue создан");
        } catch (JetStreamApiException e) {
            p("второй потребитель без фильтра на WorkQueue: %s", e.getMessage());
        }
    }

    // Дедупликация по Nats-Msg-Id
    static void dedup(Connection nc) throws Exception {
        JetStreamManagement jsm = stream(nc, "PAYMENTS", RetentionPolicy.Limits, "pay.>");
        JetStream js = nc.jetStream();
        for (int i = 0; i < 2; i++) {
            PublishAck a = js.publish("pay.created", b("платёж P-42"), PublishOptions.builder().messageId("P-42").build());
            p("публикация %d с Nats-Msg-Id=P-42: seq=%d, duplicate=%s", i + 1, a.getSeqno(), a.isDuplicate());
        }
        p("сообщений в стриме: %d", jsm.getStreamInfo("PAYMENTS").getStreamState().getMsgCount());
    }

    // Limits: два независимых потребителя читают всё; Interest: сообщение живёт, пока его ждут
    static void retention(Connection nc) throws Exception {
        JetStreamManagement jsm = stream(nc, "PAYMENTS", RetentionPolicy.Limits, "pay.>");
        JetStream js = nc.jetStream();
        for (int i = 1; i <= 3; i++) js.publish("pay.created", b("платёж " + i));
        for (String d : List.of("antifraud", "ledger")) {
            jsm.addOrUpdateConsumer("PAYMENTS", ConsumerConfiguration.builder().durable(d).deliverPolicy(DeliverPolicy.All).build());
            JetStreamSubscription sub = js.subscribe(null, PullSubscribeOptions.bind("PAYMENTS", d));
            List<Message> l = sub.fetch(10, Duration.ofSeconds(1));
            l.forEach(Message::ack);
            p("Limits, потребитель %s прочитал %d", d, l.size());
        }
        p("Limits: в стриме после двух чтений с ack: %d", jsm.getStreamInfo("PAYMENTS").getStreamState().getMsgCount());
        jsm = stream(nc, "PAYMENTS", RetentionPolicy.Interest, "pay.>");
        for (String d : List.of("antifraud", "ledger"))
            jsm.addOrUpdateConsumer("PAYMENTS", ConsumerConfiguration.builder().durable(d).build());
        for (int i = 1; i <= 3; i++) js.publish("pay.created", b("платёж " + i));
        JetStreamSubscription sub = js.subscribe(null, PullSubscribeOptions.bind("PAYMENTS", "antifraud"));
        List<Message> l = sub.fetch(10, Duration.ofSeconds(1));
        l.forEach(Message::ack);
        Thread.sleep(300);
        p("Interest: antifraud подтвердил %d, в стриме %d (ждут ledger)", l.size(), jsm.getStreamInfo("PAYMENTS").getStreamState().getMsgCount());
        sub = js.subscribe(null, PullSubscribeOptions.bind("PAYMENTS", "ledger"));
        l = sub.fetch(10, Duration.ofSeconds(1));
        l.forEach(Message::ack);
        Thread.sleep(300);
        p("Interest: ledger подтвердил %d, в стриме %d", l.size(), jsm.getStreamInfo("PAYMENTS").getStreamState().getMsgCount());
    }

    // +WPI продлевает AckWait
    static void wpi(Connection nc) throws Exception {
        JetStreamManagement jsm = stream(nc, "REPORTS", RetentionPolicy.WorkQueue, "report.>");
        jsm.addOrUpdateConsumer("REPORTS", ConsumerConfiguration.builder().durable("builder").ackWait(Duration.ofSeconds(2)).build());
        JetStream js = nc.jetStream();
        js.publish("report.year", b("выписка за год"));
        JetStreamSubscription sub = js.subscribe(null, PullSubscribeOptions.bind("REPORTS", "builder"));
        Message m = sub.fetch(1, Duration.ofSeconds(2)).get(0);
        p("%s получено, обработка 5 с при AckWait=2 с; каждую секунду inProgress()", ts());
        for (int i = 0; i < 5; i++) { Thread.sleep(1000); m.inProgress(); }
        List<Message> dup = sub.fetch(1, Duration.ofMillis(500));
        p("%s повторных доставок за время работы: %d", ts(), dup.size());
        m.ack();
        Thread.sleep(300);
        p("%s после ack в стриме %d", ts(), jsm.getStreamInfo("REPORTS").getStreamState().getMsgCount());
    }
}
