package aj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.function.Supplier;

/**
 * Разд. 6.4 и 6.13 гл. 13: что защищает @PreAuthorize в режиме прокси и в режиме AdviceMode.ASPECTJ
 * (без вплетения и с вплетением во время загрузки через -javaagent:aspectjweaver.jar и aop.xml из spring-security-aspects).
 * Аргумент: proxy | aspectj.
 */
@SpringBootApplication
public class App {

    @Configuration @EnableMethodSecurity @ConditionalOnProperty(name = "lab.mode", havingValue = "proxy")
    static class ProxyMode { }

    @Configuration @EnableMethodSecurity(mode = AdviceMode.ASPECTJ) @ConditionalOnProperty(name = "lab.mode", havingValue = "aspectj")
    static class AspectjMode { }

    @Service
    public static class Payments {
        @PreAuthorize("hasRole('ADMIN')") public String approve() { return "платёж одобрен"; }
        public String selfInvocation() { return this.approve(); }
        @PreAuthorize("hasRole('ADMIN')") public final String approveFinal() { return "одобрен final-методом"; }
        @PreAuthorize("hasRole('ADMIN')") String approvePackagePrivate() { return "одобрен package-private методом"; }
    }

    public static void main(String[] args) {
        String mode = args.length > 0 ? args[0] : "proxy";
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of("lab.mode", mode, "spring.main.web-application-type", "none",
                "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        boolean agent = java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().stream().anyMatch(a -> a.contains("aspectjweaver"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken("dev.team", null,
                    AuthorityUtils.createAuthorityList("ROLE_USER")));
            Payments bean = ctx.getBean(Payments.class);
            System.out.println("режим " + mode + (agent ? ", -javaagent:aspectjweaver" : ", без агента") + "; класс бина: "
                    + (bean.getClass() == Payments.class ? "Payments (прокси нет)" : "прокси " + bean.getClass().getSimpleName().replaceAll("\\$\\$.*", "")) + "; пользователь с ROLE_USER");
            call("бин.approve()", bean::approve);
            call("бин.selfInvocation() → this.approve()", bean::selfInvocation);
            call("бин.approveFinal() (final)", bean::approveFinal);
            call("бин.approvePackagePrivate()", bean::approvePackagePrivate);
            call("new Payments().approve() (не бин)", () -> new Payments().approve());
        }
    }

    static void call(String title, Supplier<String> s) {
        String r;
        try { r = "выполнен: " + s.get(); } catch (RuntimeException e) { r = "отказ: " + e.getClass().getSimpleName(); }
        System.out.printf("   %-40s → %s%n", title, r);
    }
}
