# Method security в режиме прокси и AspectJ: что защищается без агента и с -javaagent

Стенд к главе 13, разделы 6.4 и 6.13. Одно приложение `aj.App` (Spring Boot 4.1.1, Spring Security 7.1.1, `spring-security-aspects`) запускается трижды: `@EnableMethodSecurity` в режиме прокси, в режиме `AdviceMode.ASPECTJ` без вплетения и в том же режиме с `-javaagent:aspectjweaver`; в каждом случае печатается класс бина и исход вызовов `approve()` через бин и через `this` для пользователя с `ROLE_USER`. Вывод автора - `s13-aspectj.txt`.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, bash.

## Запуск

```bash
bash run.sh
```

Скрипт сам находит `aspectjweaver` в classpath для третьего запуска. В IDEA есть конфигурация `App` (аргумент `proxy` или `aspectj`; для варианта с агентом добавьте `-javaagent:<путь к aspectjweaver.jar>` в параметры JVM) и Shell-конфигурация `run`.

## Что должно получиться

В режиме прокси вызов через бин дает `AuthorizationDeniedException`, через `this` проходит; в режиме AspectJ без агента не защищен ни один метод; с агентом защищены оба вызова.
