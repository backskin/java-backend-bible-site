#!/usr/bin/env bash
# Разд. 6.4 и 6.13 гл. 13: method security в режиме прокси, ASPECTJ без вплетения и ASPECTJ с -javaagent. Вывод — s13-aspectj.txt.
set -uo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt >/dev/null || exit 1
CP="$(cygpath -w "$PWD/target/classes" 2>/dev/null || echo target/classes);$(cat cp.txt)"
[ "$(uname -o 2>/dev/null)" = "Msys" ] || CP="${CP//;/:}"
W=$(tr ';:' '\n\n' < cp.txt | grep aspectjweaver | head -1)
{ "$J" -Dstdout.encoding=UTF-8 -cp "$CP" aj.App proxy
  "$J" -Dstdout.encoding=UTF-8 -cp "$CP" aj.App aspectj
  "$J" -Dstdout.encoding=UTF-8 "-javaagent:$W" -cp "$CP" aj.App aspectj; } 2>&1 | grep -v "WARNING\|^\[AppClassLoader" | tee s13-aspectj.txt
