package ru.tundrabank.lib.m02;

public class C00405 { public int v() { return 405; } }
