package ru.tundrabank.lib.m01;

public class C00296 { public int v() { return 296; } }
