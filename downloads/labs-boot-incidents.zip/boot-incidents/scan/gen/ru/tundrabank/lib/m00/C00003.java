package ru.tundrabank.lib.m00;

public class C00003 { public int v() { return 3; } }
