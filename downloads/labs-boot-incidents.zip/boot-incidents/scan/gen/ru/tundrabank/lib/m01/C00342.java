package ru.tundrabank.lib.m01;

public class C00342 { public int v() { return 342; } }
