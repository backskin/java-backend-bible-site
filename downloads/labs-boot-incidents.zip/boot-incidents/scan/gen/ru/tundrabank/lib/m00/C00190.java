package ru.tundrabank.lib.m00;

public class C00190 { public int v() { return 190; } }
