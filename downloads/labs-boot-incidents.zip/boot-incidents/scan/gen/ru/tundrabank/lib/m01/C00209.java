package ru.tundrabank.lib.m01;

public class C00209 { public int v() { return 209; } }
