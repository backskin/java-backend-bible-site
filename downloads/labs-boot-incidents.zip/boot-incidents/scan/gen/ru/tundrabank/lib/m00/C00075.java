package ru.tundrabank.lib.m00;

public class C00075 { public int v() { return 75; } }
