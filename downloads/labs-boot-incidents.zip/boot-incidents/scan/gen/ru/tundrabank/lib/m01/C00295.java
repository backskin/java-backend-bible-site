package ru.tundrabank.lib.m01;

public class C00295 { public int v() { return 295; } }
