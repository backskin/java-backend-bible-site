package ru.tundrabank.lib.m02;

public class C00458 { public int v() { return 458; } }
