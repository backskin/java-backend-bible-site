package ru.tundrabank.lib.m00;

public class C00103 { public int v() { return 103; } }
