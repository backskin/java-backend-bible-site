package ru.tundrabank.lib.m02;

public class C00451 { public int v() { return 451; } }
