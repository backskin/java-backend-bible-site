package ru.tundrabank.lib.m00;

public class C00135 { public int v() { return 135; } }
