package ru.tundrabank.lib.m00;

public class C00112 { public int v() { return 112; } }
