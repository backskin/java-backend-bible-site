package ru.tundrabank.lib.m00;

public class C00113 { public int v() { return 113; } }
