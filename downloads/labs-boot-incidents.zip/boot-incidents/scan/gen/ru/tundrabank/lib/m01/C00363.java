package ru.tundrabank.lib.m01;

public class C00363 { public int v() { return 363; } }
