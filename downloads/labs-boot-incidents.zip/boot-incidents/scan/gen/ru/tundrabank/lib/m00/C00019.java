package ru.tundrabank.lib.m00;

public class C00019 { public int v() { return 19; } }
