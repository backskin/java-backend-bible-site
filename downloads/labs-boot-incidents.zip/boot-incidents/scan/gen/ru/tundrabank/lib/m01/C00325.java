package ru.tundrabank.lib.m01;

public class C00325 { public int v() { return 325; } }
