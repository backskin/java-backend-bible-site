package ru.tundrabank.lib.m01;

public class C00394 { public int v() { return 394; } }
