package ru.tundrabank.lib.m00;

public class C00044 { public int v() { return 44; } }
