package ru.tundrabank.lib.m00;

public class C00167 { public int v() { return 167; } }
