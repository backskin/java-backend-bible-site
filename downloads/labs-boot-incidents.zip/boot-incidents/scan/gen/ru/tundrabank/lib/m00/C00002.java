package ru.tundrabank.lib.m00;

public class C00002 { public int v() { return 2; } }
