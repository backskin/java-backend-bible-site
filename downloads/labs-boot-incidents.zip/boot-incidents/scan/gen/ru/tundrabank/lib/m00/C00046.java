package ru.tundrabank.lib.m00;

public class C00046 { public int v() { return 46; } }
