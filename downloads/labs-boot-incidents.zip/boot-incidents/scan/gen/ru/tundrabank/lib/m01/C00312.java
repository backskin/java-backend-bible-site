package ru.tundrabank.lib.m01;

public class C00312 { public int v() { return 312; } }
