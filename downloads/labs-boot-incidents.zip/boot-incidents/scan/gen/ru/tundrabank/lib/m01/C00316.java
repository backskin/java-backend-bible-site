package ru.tundrabank.lib.m01;

public class C00316 { public int v() { return 316; } }
