package ru.tundrabank.lib.m01;

public class C00255 { public int v() { return 255; } }
