package ru.tundrabank.lib.m01;

public class C00238 { public int v() { return 238; } }
