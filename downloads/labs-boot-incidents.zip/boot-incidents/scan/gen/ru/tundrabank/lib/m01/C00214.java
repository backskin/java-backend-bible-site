package ru.tundrabank.lib.m01;

public class C00214 { public int v() { return 214; } }
