package ru.tundrabank.lib.m02;

public class C00446 { public int v() { return 446; } }
