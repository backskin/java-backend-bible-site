package ru.tundrabank.lib.m00;

public class C00136 { public int v() { return 136; } }
