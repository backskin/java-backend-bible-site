package ru.tundrabank.lib.m01;

public class C00210 { public int v() { return 210; } }
