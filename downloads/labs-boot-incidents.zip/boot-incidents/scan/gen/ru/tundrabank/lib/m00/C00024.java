package ru.tundrabank.lib.m00;

public class C00024 { public int v() { return 24; } }
