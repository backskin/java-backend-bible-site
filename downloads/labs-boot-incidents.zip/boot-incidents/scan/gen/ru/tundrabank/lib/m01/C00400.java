package ru.tundrabank.lib.m01;

@org.springframework.stereotype.Component
public class C00400 { public int v() { return 400; } }
