package ru.tundrabank.lib.m02;

public class C00462 { public int v() { return 462; } }
