package ru.tundrabank.lib.m01;

public class C00282 { public int v() { return 282; } }
