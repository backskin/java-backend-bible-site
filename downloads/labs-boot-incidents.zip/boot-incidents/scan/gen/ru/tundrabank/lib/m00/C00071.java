package ru.tundrabank.lib.m00;

public class C00071 { public int v() { return 71; } }
