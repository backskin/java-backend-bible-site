package ru.tundrabank.lib.m00;

public class C00034 { public int v() { return 34; } }
