package ru.tundrabank.lib.m00;

public class C00115 { public int v() { return 115; } }
