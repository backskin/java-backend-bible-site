package ru.tundrabank.lib.m00;

public class C00158 { public int v() { return 158; } }
