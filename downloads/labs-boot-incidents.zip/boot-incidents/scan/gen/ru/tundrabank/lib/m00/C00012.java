package ru.tundrabank.lib.m00;

public class C00012 { public int v() { return 12; } }
