package ru.tundrabank.lib.m01;

public class C00299 { public int v() { return 299; } }
