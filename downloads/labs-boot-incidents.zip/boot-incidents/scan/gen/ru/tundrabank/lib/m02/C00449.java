package ru.tundrabank.lib.m02;

public class C00449 { public int v() { return 449; } }
