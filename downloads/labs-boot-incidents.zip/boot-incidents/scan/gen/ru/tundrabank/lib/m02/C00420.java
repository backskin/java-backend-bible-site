package ru.tundrabank.lib.m02;

public class C00420 { public int v() { return 420; } }
