package ru.tundrabank.lib.m00;

public class C00127 { public int v() { return 127; } }
