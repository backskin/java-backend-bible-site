package ru.tundrabank.lib.m01;

public class C00300 { public int v() { return 300; } }
