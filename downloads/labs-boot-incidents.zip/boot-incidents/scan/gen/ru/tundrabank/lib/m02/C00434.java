package ru.tundrabank.lib.m02;

public class C00434 { public int v() { return 434; } }
