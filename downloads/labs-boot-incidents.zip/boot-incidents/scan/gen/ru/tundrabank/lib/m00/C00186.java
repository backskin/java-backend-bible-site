package ru.tundrabank.lib.m00;

public class C00186 { public int v() { return 186; } }
