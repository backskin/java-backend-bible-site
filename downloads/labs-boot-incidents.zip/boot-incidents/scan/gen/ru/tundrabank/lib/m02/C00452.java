package ru.tundrabank.lib.m02;

public class C00452 { public int v() { return 452; } }
