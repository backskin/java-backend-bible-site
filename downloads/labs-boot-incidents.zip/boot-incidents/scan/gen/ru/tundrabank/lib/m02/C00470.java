package ru.tundrabank.lib.m02;

public class C00470 { public int v() { return 470; } }
