package ru.tundrabank.lib.m01;

public class C00327 { public int v() { return 327; } }
