package ru.tundrabank.lib.m00;

public class C00122 { public int v() { return 122; } }
