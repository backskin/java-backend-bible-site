package ru.tundrabank.lib.m00;

public class C00047 { public int v() { return 47; } }
