package ru.tundrabank.lib.m00;

public class C00056 { public int v() { return 56; } }
