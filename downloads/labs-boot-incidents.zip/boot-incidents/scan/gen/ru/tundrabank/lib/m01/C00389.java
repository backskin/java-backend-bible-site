package ru.tundrabank.lib.m01;

public class C00389 { public int v() { return 389; } }
