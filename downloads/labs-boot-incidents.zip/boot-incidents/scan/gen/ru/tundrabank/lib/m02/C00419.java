package ru.tundrabank.lib.m02;

public class C00419 { public int v() { return 419; } }
