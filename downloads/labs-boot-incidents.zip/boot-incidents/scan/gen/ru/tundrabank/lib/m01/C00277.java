package ru.tundrabank.lib.m01;

public class C00277 { public int v() { return 277; } }
