package ru.tundrabank.lib.m00;

public class C00200 { public int v() { return 200; } }
