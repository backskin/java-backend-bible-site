package ru.tundrabank.lib.m01;

public class C00278 { public int v() { return 278; } }
