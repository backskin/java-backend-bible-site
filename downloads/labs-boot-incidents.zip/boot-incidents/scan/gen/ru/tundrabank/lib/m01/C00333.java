package ru.tundrabank.lib.m01;

public class C00333 { public int v() { return 333; } }
