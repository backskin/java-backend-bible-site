package ru.tundrabank.lib.m00;

public class C00031 { public int v() { return 31; } }
