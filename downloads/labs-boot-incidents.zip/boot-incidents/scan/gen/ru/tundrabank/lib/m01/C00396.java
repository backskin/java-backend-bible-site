package ru.tundrabank.lib.m01;

public class C00396 { public int v() { return 396; } }
