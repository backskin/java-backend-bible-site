package ru.tundrabank.lib.m02;

public class C00430 { public int v() { return 430; } }
