package ru.tundrabank.lib.m01;

public class C00303 { public int v() { return 303; } }
