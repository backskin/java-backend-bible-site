package ru.tundrabank.lib.m00;

public class C00109 { public int v() { return 109; } }
