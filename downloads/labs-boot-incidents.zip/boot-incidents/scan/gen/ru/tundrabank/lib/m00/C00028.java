package ru.tundrabank.lib.m00;

public class C00028 { public int v() { return 28; } }
