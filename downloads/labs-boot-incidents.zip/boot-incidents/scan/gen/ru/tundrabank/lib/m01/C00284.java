package ru.tundrabank.lib.m01;

public class C00284 { public int v() { return 284; } }
