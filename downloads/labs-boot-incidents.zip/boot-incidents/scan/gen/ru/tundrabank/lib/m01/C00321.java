package ru.tundrabank.lib.m01;

public class C00321 { public int v() { return 321; } }
