package ru.tundrabank.lib.m00;

public class C00089 { public int v() { return 89; } }
