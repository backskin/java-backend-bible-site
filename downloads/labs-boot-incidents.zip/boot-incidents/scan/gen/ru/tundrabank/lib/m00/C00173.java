package ru.tundrabank.lib.m00;

public class C00173 { public int v() { return 173; } }
