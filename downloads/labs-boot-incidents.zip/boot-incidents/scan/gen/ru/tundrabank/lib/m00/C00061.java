package ru.tundrabank.lib.m00;

public class C00061 { public int v() { return 61; } }
