package ru.tundrabank.lib.m00;

public class C00119 { public int v() { return 119; } }
