package ru.tundrabank.lib.m00;

public class C00009 { public int v() { return 9; } }
