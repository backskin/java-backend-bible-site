package ru.tundrabank.lib.m01;

public class C00386 { public int v() { return 386; } }
