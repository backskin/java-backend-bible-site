package ru.tundrabank.lib.m00;

public class C00182 { public int v() { return 182; } }
