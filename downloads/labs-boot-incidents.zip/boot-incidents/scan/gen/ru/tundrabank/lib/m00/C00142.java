package ru.tundrabank.lib.m00;

public class C00142 { public int v() { return 142; } }
