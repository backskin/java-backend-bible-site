package ru.tundrabank.lib.m00;

public class C00026 { public int v() { return 26; } }
