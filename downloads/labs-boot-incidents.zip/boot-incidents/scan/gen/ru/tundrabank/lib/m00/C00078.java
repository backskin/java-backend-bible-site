package ru.tundrabank.lib.m00;

public class C00078 { public int v() { return 78; } }
