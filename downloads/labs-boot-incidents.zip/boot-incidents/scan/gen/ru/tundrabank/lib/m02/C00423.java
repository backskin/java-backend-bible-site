package ru.tundrabank.lib.m02;

public class C00423 { public int v() { return 423; } }
