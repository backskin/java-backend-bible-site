package ru.tundrabank.lib.m00;

public class C00099 { public int v() { return 99; } }
