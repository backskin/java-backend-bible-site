package ru.tundrabank.lib.m01;

public class C00319 { public int v() { return 319; } }
