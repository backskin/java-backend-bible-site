package ru.tundrabank.lib.m01;

public class C00359 { public int v() { return 359; } }
