package ru.tundrabank.lib.m01;

public class C00371 { public int v() { return 371; } }
