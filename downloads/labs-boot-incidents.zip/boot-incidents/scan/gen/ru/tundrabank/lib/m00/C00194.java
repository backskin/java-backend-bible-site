package ru.tundrabank.lib.m00;

public class C00194 { public int v() { return 194; } }
