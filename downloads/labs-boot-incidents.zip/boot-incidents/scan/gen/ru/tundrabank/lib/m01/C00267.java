package ru.tundrabank.lib.m01;

public class C00267 { public int v() { return 267; } }
