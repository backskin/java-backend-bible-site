package ru.tundrabank.lib.m00;

public class C00157 { public int v() { return 157; } }
