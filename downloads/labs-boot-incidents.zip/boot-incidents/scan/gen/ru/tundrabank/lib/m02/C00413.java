package ru.tundrabank.lib.m02;

public class C00413 { public int v() { return 413; } }
