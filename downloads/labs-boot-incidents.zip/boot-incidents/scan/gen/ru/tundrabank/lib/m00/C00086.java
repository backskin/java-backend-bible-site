package ru.tundrabank.lib.m00;

public class C00086 { public int v() { return 86; } }
