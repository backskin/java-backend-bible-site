package ru.tundrabank.lib.m01;

public class C00212 { public int v() { return 212; } }
