package ru.tundrabank.lib.m01;

public class C00215 { public int v() { return 215; } }
