package ru.tundrabank.lib.m01;

public class C00306 { public int v() { return 306; } }
