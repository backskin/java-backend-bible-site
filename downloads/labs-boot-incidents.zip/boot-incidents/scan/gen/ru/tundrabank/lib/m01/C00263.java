package ru.tundrabank.lib.m01;

public class C00263 { public int v() { return 263; } }
