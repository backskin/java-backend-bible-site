package ru.tundrabank.lib.m00;

public class C00008 { public int v() { return 8; } }
