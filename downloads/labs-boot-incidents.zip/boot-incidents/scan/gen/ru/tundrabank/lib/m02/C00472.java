package ru.tundrabank.lib.m02;

public class C00472 { public int v() { return 472; } }
