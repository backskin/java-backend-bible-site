package ru.tundrabank.lib.m01;

public class C00245 { public int v() { return 245; } }
