package ru.tundrabank.lib.m01;

public class C00358 { public int v() { return 358; } }
