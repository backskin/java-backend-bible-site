package ru.tundrabank.lib.m00;

public class C00149 { public int v() { return 149; } }
