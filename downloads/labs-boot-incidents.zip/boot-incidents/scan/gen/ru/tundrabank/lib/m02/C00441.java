package ru.tundrabank.lib.m02;

public class C00441 { public int v() { return 441; } }
