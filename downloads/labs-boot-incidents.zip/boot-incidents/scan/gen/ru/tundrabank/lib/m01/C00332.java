package ru.tundrabank.lib.m01;

public class C00332 { public int v() { return 332; } }
