package ru.tundrabank.lib.m00;

public class C00134 { public int v() { return 134; } }
