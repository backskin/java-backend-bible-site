package ru.tundrabank.lib.m02;

public class C00403 { public int v() { return 403; } }
