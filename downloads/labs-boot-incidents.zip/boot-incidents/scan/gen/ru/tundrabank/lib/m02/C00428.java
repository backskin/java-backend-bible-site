package ru.tundrabank.lib.m02;

public class C00428 { public int v() { return 428; } }
