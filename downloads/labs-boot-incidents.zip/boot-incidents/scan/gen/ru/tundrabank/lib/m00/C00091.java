package ru.tundrabank.lib.m00;

public class C00091 { public int v() { return 91; } }
