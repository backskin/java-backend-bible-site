package ru.tundrabank.lib.m00;

public class C00144 { public int v() { return 144; } }
