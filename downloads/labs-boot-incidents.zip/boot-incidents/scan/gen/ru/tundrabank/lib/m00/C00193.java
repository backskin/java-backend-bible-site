package ru.tundrabank.lib.m00;

public class C00193 { public int v() { return 193; } }
