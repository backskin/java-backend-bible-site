package ru.tundrabank.lib.m00;

public class C00128 { public int v() { return 128; } }
