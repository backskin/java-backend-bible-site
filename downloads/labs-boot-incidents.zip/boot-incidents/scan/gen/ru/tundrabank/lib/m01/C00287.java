package ru.tundrabank.lib.m01;

public class C00287 { public int v() { return 287; } }
