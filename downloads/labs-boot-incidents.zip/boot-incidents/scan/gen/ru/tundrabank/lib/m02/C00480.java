package ru.tundrabank.lib.m02;

public class C00480 { public int v() { return 480; } }
