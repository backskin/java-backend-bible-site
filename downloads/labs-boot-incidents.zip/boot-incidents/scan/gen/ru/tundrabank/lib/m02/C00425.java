package ru.tundrabank.lib.m02;

public class C00425 { public int v() { return 425; } }
