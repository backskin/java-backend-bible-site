package ru.tundrabank.lib.m00;

public class C00108 { public int v() { return 108; } }
