package ru.tundrabank.lib.m01;

public class C00288 { public int v() { return 288; } }
