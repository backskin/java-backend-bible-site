package ru.tundrabank.lib.m01;

public class C00302 { public int v() { return 302; } }
