package ru.tundrabank.lib.m01;

public class C00276 { public int v() { return 276; } }
