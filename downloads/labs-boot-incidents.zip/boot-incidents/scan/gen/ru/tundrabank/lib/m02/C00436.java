package ru.tundrabank.lib.m02;

public class C00436 { public int v() { return 436; } }
