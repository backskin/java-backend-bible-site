package ru.tundrabank.lib.m01;

public class C00292 { public int v() { return 292; } }
