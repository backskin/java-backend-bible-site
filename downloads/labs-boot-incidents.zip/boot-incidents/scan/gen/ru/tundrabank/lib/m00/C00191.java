package ru.tundrabank.lib.m00;

public class C00191 { public int v() { return 191; } }
