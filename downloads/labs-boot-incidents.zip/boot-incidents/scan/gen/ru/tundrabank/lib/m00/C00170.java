package ru.tundrabank.lib.m00;

public class C00170 { public int v() { return 170; } }
