package ru.tundrabank.lib.m01;

public class C00357 { public int v() { return 357; } }
