package ru.tundrabank.lib.m01;

public class C00349 { public int v() { return 349; } }
