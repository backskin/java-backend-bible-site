package ru.tundrabank.lib.m01;

public class C00397 { public int v() { return 397; } }
