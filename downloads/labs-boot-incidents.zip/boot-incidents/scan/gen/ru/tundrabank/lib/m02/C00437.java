package ru.tundrabank.lib.m02;

public class C00437 { public int v() { return 437; } }
