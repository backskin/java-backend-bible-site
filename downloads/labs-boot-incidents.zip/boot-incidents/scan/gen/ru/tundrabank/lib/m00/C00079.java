package ru.tundrabank.lib.m00;

public class C00079 { public int v() { return 79; } }
