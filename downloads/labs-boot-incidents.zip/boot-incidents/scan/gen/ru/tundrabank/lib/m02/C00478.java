package ru.tundrabank.lib.m02;

public class C00478 { public int v() { return 478; } }
