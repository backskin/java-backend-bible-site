package ru.tundrabank.lib.m01;

public class C00256 { public int v() { return 256; } }
