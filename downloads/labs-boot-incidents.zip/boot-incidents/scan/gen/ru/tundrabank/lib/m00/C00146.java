package ru.tundrabank.lib.m00;

public class C00146 { public int v() { return 146; } }
