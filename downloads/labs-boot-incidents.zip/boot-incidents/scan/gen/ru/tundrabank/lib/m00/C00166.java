package ru.tundrabank.lib.m00;

public class C00166 { public int v() { return 166; } }
