package ru.tundrabank.lib.m00;

public class C00172 { public int v() { return 172; } }
