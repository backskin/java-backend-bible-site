package ru.tundrabank.lib.m00;

public class C00073 { public int v() { return 73; } }
