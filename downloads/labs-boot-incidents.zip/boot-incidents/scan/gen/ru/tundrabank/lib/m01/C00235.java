package ru.tundrabank.lib.m01;

public class C00235 { public int v() { return 235; } }
