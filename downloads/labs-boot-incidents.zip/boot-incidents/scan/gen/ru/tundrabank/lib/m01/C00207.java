package ru.tundrabank.lib.m01;

public class C00207 { public int v() { return 207; } }
