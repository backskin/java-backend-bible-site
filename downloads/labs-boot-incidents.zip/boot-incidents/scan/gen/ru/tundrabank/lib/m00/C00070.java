package ru.tundrabank.lib.m00;

public class C00070 { public int v() { return 70; } }
