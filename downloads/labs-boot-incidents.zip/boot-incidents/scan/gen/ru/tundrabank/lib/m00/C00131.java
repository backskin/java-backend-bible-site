package ru.tundrabank.lib.m00;

public class C00131 { public int v() { return 131; } }
