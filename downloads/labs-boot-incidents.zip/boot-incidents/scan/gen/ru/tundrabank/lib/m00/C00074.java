package ru.tundrabank.lib.m00;

public class C00074 { public int v() { return 74; } }
