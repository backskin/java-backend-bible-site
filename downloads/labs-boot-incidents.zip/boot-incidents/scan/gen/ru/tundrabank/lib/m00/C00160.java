package ru.tundrabank.lib.m00;

public class C00160 { public int v() { return 160; } }
