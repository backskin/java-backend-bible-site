package ru.tundrabank.lib.m00;

public class C00087 { public int v() { return 87; } }
