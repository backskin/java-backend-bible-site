package ru.tundrabank.lib.m01;

public class C00355 { public int v() { return 355; } }
