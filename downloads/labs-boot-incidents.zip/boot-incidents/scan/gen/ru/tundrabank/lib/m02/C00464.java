package ru.tundrabank.lib.m02;

public class C00464 { public int v() { return 464; } }
