package ru.tundrabank.lib.m00;

public class C00058 { public int v() { return 58; } }
