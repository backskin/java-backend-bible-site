package ru.tundrabank.lib.m00;

public class C00035 { public int v() { return 35; } }
