package ru.tundrabank.lib.m02;

public class C00414 { public int v() { return 414; } }
