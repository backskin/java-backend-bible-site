package ru.tundrabank.lib.m01;

public class C00330 { public int v() { return 330; } }
