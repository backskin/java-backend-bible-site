package ru.tundrabank.lib.m00;

public class C00082 { public int v() { return 82; } }
