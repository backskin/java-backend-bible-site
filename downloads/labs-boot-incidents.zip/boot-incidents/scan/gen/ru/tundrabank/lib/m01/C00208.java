package ru.tundrabank.lib.m01;

public class C00208 { public int v() { return 208; } }
