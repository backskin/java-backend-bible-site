package ru.tundrabank.lib.m01;

public class C00269 { public int v() { return 269; } }
