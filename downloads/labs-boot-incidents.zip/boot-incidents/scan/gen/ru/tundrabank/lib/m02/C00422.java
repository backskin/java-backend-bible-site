package ru.tundrabank.lib.m02;

public class C00422 { public int v() { return 422; } }
