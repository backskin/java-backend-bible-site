package ru.tundrabank.lib.m00;

public class C00036 { public int v() { return 36; } }
