package ru.tundrabank.lib.m02;

public class C00461 { public int v() { return 461; } }
