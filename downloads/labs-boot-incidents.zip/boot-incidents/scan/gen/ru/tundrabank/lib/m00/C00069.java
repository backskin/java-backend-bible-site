package ru.tundrabank.lib.m00;

public class C00069 { public int v() { return 69; } }
