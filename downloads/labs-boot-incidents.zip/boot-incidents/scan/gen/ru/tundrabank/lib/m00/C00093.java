package ru.tundrabank.lib.m00;

public class C00093 { public int v() { return 93; } }
