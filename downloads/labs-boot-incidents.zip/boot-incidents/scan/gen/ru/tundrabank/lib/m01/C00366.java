package ru.tundrabank.lib.m01;

public class C00366 { public int v() { return 366; } }
