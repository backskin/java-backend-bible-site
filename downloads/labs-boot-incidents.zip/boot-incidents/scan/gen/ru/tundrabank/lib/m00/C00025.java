package ru.tundrabank.lib.m00;

public class C00025 { public int v() { return 25; } }
