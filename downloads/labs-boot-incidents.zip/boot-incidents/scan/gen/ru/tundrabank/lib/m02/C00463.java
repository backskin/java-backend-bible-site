package ru.tundrabank.lib.m02;

public class C00463 { public int v() { return 463; } }
