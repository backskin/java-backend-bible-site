package ru.tundrabank.lib.m01;

public class C00257 { public int v() { return 257; } }
