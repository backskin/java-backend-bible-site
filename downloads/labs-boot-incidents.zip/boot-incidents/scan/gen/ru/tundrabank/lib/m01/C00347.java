package ru.tundrabank.lib.m01;

public class C00347 { public int v() { return 347; } }
