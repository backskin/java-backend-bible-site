package ru.tundrabank.lib.m02;

public class C00421 { public int v() { return 421; } }
