package ru.tundrabank.lib.m01;

public class C00270 { public int v() { return 270; } }
