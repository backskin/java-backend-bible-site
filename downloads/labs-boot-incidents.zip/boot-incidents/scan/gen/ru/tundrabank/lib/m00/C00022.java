package ru.tundrabank.lib.m00;

public class C00022 { public int v() { return 22; } }
