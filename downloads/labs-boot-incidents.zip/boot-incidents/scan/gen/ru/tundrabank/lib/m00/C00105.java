package ru.tundrabank.lib.m00;

public class C00105 { public int v() { return 105; } }
