package ru.tundrabank.lib.m00;

public class C00011 { public int v() { return 11; } }
