package ru.tundrabank.lib.m00;

public class C00005 { public int v() { return 5; } }
