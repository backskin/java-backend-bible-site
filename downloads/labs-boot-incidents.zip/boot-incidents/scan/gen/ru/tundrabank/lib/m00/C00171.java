package ru.tundrabank.lib.m00;

public class C00171 { public int v() { return 171; } }
