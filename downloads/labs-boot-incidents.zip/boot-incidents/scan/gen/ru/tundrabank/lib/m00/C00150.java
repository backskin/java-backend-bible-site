package ru.tundrabank.lib.m00;

public class C00150 { public int v() { return 150; } }
