package ru.tundrabank.lib.m00;

public class C00020 { public int v() { return 20; } }
