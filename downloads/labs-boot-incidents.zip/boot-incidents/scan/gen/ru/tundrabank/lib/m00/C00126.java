package ru.tundrabank.lib.m00;

public class C00126 { public int v() { return 126; } }
