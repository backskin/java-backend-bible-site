package ru.tundrabank.lib.m00;

public class C00111 { public int v() { return 111; } }
