package ru.tundrabank.lib.m01;

public class C00258 { public int v() { return 258; } }
