package ru.tundrabank.lib.m01;

public class C00274 { public int v() { return 274; } }
