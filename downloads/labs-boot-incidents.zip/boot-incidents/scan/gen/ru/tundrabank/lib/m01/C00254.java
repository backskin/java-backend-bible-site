package ru.tundrabank.lib.m01;

public class C00254 { public int v() { return 254; } }
