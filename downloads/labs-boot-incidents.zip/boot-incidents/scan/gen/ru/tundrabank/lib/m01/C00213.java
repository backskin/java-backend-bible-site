package ru.tundrabank.lib.m01;

public class C00213 { public int v() { return 213; } }
