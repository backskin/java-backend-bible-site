package ru.tundrabank.lib.m01;

public class C00372 { public int v() { return 372; } }
