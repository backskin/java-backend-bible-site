package ru.tundrabank.lib.m01;

public class C00346 { public int v() { return 346; } }
