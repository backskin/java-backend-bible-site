package ru.tundrabank.lib.m00;

public class C00051 { public int v() { return 51; } }
