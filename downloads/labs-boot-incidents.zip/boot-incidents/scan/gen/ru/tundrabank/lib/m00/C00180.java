package ru.tundrabank.lib.m00;

public class C00180 { public int v() { return 180; } }
