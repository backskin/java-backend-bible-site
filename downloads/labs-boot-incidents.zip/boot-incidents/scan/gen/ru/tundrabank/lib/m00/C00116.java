package ru.tundrabank.lib.m00;

public class C00116 { public int v() { return 116; } }
