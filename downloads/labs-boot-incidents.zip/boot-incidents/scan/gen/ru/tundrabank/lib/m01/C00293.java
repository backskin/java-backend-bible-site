package ru.tundrabank.lib.m01;

public class C00293 { public int v() { return 293; } }
