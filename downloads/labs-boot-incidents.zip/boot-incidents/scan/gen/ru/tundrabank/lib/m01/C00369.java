package ru.tundrabank.lib.m01;

public class C00369 { public int v() { return 369; } }
