package ru.tundrabank.lib.m00;

public class C00083 { public int v() { return 83; } }
