package ru.tundrabank.lib.m00;

public class C00165 { public int v() { return 165; } }
