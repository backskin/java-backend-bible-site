package ru.tundrabank.lib.m00;

public class C00159 { public int v() { return 159; } }
