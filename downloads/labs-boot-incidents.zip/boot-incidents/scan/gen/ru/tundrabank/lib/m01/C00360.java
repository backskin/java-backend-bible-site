package ru.tundrabank.lib.m01;

public class C00360 { public int v() { return 360; } }
