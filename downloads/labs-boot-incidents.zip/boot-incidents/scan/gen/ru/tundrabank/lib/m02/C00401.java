package ru.tundrabank.lib.m02;

public class C00401 { public int v() { return 401; } }
