package ru.tundrabank.lib.m01;

public class C00281 { public int v() { return 281; } }
