package ru.tundrabank.lib.m01;

public class C00392 { public int v() { return 392; } }
