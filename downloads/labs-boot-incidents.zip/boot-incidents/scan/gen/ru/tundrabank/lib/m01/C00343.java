package ru.tundrabank.lib.m01;

public class C00343 { public int v() { return 343; } }
