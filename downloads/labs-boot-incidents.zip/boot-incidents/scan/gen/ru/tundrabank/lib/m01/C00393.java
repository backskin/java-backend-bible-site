package ru.tundrabank.lib.m01;

public class C00393 { public int v() { return 393; } }
