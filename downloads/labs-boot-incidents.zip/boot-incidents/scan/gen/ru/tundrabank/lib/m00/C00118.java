package ru.tundrabank.lib.m00;

public class C00118 { public int v() { return 118; } }
