package ru.tundrabank.lib.m00;

public class C00037 { public int v() { return 37; } }
