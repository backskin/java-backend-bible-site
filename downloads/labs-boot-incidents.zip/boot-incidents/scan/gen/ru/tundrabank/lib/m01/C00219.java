package ru.tundrabank.lib.m01;

public class C00219 { public int v() { return 219; } }
