package ru.tundrabank.lib.m00;

public class C00189 { public int v() { return 189; } }
