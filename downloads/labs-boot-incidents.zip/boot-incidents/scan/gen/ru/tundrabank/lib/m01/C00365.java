package ru.tundrabank.lib.m01;

public class C00365 { public int v() { return 365; } }
