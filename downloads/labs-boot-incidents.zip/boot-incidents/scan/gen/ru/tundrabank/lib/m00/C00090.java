package ru.tundrabank.lib.m00;

public class C00090 { public int v() { return 90; } }
