package ru.tundrabank.lib.m00;

public class C00106 { public int v() { return 106; } }
