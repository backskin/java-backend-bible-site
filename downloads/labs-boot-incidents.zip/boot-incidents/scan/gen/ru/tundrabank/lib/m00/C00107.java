package ru.tundrabank.lib.m00;

public class C00107 { public int v() { return 107; } }
