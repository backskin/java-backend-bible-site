package ru.tundrabank.lib.m01;

public class C00309 { public int v() { return 309; } }
