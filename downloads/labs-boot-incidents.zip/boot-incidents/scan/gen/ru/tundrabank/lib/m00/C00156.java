package ru.tundrabank.lib.m00;

public class C00156 { public int v() { return 156; } }
