package ru.tundrabank.lib.m01;

public class C00232 { public int v() { return 232; } }
