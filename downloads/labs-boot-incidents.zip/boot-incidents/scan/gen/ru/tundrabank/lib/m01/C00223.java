package ru.tundrabank.lib.m01;

public class C00223 { public int v() { return 223; } }
