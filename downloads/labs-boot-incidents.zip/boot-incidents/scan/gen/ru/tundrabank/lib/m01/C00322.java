package ru.tundrabank.lib.m01;

public class C00322 { public int v() { return 322; } }
