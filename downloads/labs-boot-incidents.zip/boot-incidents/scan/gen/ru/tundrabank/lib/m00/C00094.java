package ru.tundrabank.lib.m00;

public class C00094 { public int v() { return 94; } }
