package ru.tundrabank.lib.m01;

public class C00345 { public int v() { return 345; } }
