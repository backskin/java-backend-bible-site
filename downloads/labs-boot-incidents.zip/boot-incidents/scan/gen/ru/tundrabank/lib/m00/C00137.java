package ru.tundrabank.lib.m00;

public class C00137 { public int v() { return 137; } }
