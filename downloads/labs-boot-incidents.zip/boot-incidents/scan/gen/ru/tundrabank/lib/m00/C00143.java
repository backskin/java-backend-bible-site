package ru.tundrabank.lib.m00;

public class C00143 { public int v() { return 143; } }
