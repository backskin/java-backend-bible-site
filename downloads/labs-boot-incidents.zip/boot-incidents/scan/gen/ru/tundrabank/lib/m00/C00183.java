package ru.tundrabank.lib.m00;

public class C00183 { public int v() { return 183; } }
