package ru.tundrabank.lib.m01;

public class C00233 { public int v() { return 233; } }
