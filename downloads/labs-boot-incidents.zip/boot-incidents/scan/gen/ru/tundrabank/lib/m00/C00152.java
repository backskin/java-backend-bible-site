package ru.tundrabank.lib.m00;

public class C00152 { public int v() { return 152; } }
