package ru.tundrabank.lib.m01;

public class C00236 { public int v() { return 236; } }
