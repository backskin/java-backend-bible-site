package ru.tundrabank.lib.m01;

public class C00391 { public int v() { return 391; } }
