package ru.tundrabank.lib.m02;

public class C00455 { public int v() { return 455; } }
