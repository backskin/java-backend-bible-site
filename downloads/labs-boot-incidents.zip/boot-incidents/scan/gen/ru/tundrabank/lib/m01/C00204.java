package ru.tundrabank.lib.m01;

public class C00204 { public int v() { return 204; } }
