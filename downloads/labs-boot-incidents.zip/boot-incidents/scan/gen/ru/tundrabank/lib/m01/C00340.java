package ru.tundrabank.lib.m01;

public class C00340 { public int v() { return 340; } }
