package ru.tundrabank.lib.m01;

public class C00399 { public int v() { return 399; } }
