package ru.tundrabank.lib.m02;

public class C00440 { public int v() { return 440; } }
