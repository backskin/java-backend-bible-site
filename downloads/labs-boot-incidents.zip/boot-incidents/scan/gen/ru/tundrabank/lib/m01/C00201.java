package ru.tundrabank.lib.m01;

public class C00201 { public int v() { return 201; } }
