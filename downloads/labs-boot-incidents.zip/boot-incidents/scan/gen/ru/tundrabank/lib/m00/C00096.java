package ru.tundrabank.lib.m00;

public class C00096 { public int v() { return 96; } }
