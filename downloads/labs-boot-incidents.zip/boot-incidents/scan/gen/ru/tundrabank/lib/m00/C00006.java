package ru.tundrabank.lib.m00;

public class C00006 { public int v() { return 6; } }
