package ru.tundrabank.lib.m02;

public class C00468 { public int v() { return 468; } }
