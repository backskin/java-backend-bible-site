package ru.tundrabank.lib.m00;

public class C00042 { public int v() { return 42; } }
