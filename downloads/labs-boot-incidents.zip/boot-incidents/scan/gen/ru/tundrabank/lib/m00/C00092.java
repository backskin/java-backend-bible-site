package ru.tundrabank.lib.m00;

public class C00092 { public int v() { return 92; } }
