package ru.tundrabank.lib.m00;

public class C00043 { public int v() { return 43; } }
