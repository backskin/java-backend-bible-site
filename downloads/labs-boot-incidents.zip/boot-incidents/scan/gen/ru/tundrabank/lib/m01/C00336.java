package ru.tundrabank.lib.m01;

public class C00336 { public int v() { return 336; } }
