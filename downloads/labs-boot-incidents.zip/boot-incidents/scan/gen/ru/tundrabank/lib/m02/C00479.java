package ru.tundrabank.lib.m02;

public class C00479 { public int v() { return 479; } }
