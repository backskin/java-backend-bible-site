package ru.tundrabank.lib.m00;

public class C00017 { public int v() { return 17; } }
