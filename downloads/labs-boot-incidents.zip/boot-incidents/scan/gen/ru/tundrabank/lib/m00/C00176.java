package ru.tundrabank.lib.m00;

public class C00176 { public int v() { return 176; } }
