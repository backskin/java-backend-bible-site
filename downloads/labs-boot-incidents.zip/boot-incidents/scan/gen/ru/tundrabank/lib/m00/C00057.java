package ru.tundrabank.lib.m00;

public class C00057 { public int v() { return 57; } }
