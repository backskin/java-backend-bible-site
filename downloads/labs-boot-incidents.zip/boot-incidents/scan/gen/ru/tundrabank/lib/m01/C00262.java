package ru.tundrabank.lib.m01;

public class C00262 { public int v() { return 262; } }
