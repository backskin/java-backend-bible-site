package ru.tundrabank.lib.m00;

public class C00066 { public int v() { return 66; } }
