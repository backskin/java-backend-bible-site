package ru.tundrabank.lib.m02;

public class C00471 { public int v() { return 471; } }
