package ru.tundrabank.lib.m02;

public class C00473 { public int v() { return 473; } }
