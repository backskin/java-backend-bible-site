package ru.tundrabank.lib.m01;

public class C00265 { public int v() { return 265; } }
