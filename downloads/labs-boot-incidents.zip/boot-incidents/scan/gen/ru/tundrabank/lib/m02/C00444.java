package ru.tundrabank.lib.m02;

public class C00444 { public int v() { return 444; } }
