package ru.tundrabank.lib.m01;

public class C00364 { public int v() { return 364; } }
