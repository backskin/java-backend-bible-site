package ru.tundrabank.lib.m01;

public class C00326 { public int v() { return 326; } }
