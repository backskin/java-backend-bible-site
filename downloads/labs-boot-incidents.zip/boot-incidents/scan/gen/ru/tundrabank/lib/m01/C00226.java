package ru.tundrabank.lib.m01;

public class C00226 { public int v() { return 226; } }
