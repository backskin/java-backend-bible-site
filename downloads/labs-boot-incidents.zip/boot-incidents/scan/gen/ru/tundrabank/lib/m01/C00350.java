package ru.tundrabank.lib.m01;

public class C00350 { public int v() { return 350; } }
