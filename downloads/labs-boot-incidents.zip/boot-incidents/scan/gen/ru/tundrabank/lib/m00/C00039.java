package ru.tundrabank.lib.m00;

public class C00039 { public int v() { return 39; } }
