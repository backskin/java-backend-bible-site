package ru.tundrabank.lib.m01;

public class C00337 { public int v() { return 337; } }
