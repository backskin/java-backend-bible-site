package ru.tundrabank.lib.m01;

public class C00244 { public int v() { return 244; } }
