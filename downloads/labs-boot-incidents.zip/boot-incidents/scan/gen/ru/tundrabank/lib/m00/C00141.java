package ru.tundrabank.lib.m00;

public class C00141 { public int v() { return 141; } }
