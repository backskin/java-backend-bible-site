package ru.tundrabank.lib.m00;

public class C00072 { public int v() { return 72; } }
