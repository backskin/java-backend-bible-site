package ru.tundrabank.lib.m02;

public class C00432 { public int v() { return 432; } }
