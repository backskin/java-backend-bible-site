package ru.tundrabank.lib.m00;

public class C00117 { public int v() { return 117; } }
