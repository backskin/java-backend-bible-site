package ru.tundrabank.lib.m00;

public class C00016 { public int v() { return 16; } }
