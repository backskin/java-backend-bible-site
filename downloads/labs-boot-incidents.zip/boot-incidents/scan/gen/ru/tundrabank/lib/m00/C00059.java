package ru.tundrabank.lib.m00;

public class C00059 { public int v() { return 59; } }
