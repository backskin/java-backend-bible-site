package ru.tundrabank.lib.m01;

public class C00374 { public int v() { return 374; } }
