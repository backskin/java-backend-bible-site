package ru.tundrabank.lib.m00;

public class C00168 { public int v() { return 168; } }
