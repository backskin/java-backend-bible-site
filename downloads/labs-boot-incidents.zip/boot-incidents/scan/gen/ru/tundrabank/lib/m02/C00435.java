package ru.tundrabank.lib.m02;

public class C00435 { public int v() { return 435; } }
