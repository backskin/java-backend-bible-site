package ru.tundrabank.lib.m00;

public class C00015 { public int v() { return 15; } }
