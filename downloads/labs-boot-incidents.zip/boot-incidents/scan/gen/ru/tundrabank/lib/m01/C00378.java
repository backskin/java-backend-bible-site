package ru.tundrabank.lib.m01;

public class C00378 { public int v() { return 378; } }
