package ru.tundrabank.lib.m02;

public class C00445 { public int v() { return 445; } }
