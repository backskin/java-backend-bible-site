package ru.tundrabank.lib.m01;

public class C00250 { public int v() { return 250; } }
