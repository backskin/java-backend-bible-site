package ru.tundrabank.lib.m02;

public class C00438 { public int v() { return 438; } }
