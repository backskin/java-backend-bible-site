package ru.tundrabank.lib.m02;

public class C00469 { public int v() { return 469; } }
