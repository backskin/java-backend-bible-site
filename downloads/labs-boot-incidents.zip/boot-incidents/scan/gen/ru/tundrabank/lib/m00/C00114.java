package ru.tundrabank.lib.m00;

public class C00114 { public int v() { return 114; } }
