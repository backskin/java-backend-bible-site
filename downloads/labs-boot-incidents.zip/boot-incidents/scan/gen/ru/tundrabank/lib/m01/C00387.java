package ru.tundrabank.lib.m01;

public class C00387 { public int v() { return 387; } }
