package ru.tundrabank.lib.m00;

public class C00100 { public int v() { return 100; } }
