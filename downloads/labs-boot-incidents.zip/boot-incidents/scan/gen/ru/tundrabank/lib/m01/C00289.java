package ru.tundrabank.lib.m01;

public class C00289 { public int v() { return 289; } }
