package ru.tundrabank.lib.m00;

public class C00132 { public int v() { return 132; } }
