package ru.tundrabank.lib.m00;

public class C00139 { public int v() { return 139; } }
