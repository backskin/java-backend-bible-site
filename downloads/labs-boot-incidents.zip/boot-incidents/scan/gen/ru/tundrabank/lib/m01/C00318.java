package ru.tundrabank.lib.m01;

public class C00318 { public int v() { return 318; } }
