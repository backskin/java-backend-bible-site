package ru.tundrabank.lib.m00;

public class C00067 { public int v() { return 67; } }
