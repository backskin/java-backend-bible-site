package ru.tundrabank.lib.m01;

public class C00376 { public int v() { return 376; } }
