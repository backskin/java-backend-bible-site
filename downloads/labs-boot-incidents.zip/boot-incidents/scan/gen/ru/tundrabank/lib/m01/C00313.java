package ru.tundrabank.lib.m01;

public class C00313 { public int v() { return 313; } }
