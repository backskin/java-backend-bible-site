package ru.tundrabank.lib.m01;

public class C00260 { public int v() { return 260; } }
