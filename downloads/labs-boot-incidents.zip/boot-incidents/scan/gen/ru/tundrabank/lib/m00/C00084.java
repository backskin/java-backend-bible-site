package ru.tundrabank.lib.m00;

public class C00084 { public int v() { return 84; } }
