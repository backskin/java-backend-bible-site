package ru.tundrabank.lib.m01;

public class C00354 { public int v() { return 354; } }
