package ru.tundrabank.lib.m00;

public class C00102 { public int v() { return 102; } }
