package ru.tundrabank.lib.m00;

public class C00125 { public int v() { return 125; } }
