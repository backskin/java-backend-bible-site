package ru.tundrabank.lib.m01;

public class C00297 { public int v() { return 297; } }
