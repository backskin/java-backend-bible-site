package ru.tundrabank.lib.m01;

public class C00308 { public int v() { return 308; } }
