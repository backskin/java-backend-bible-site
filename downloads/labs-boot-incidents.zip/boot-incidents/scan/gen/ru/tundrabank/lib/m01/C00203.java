package ru.tundrabank.lib.m01;

public class C00203 { public int v() { return 203; } }
