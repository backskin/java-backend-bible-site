package ru.tundrabank.lib.m01;

public class C00317 { public int v() { return 317; } }
