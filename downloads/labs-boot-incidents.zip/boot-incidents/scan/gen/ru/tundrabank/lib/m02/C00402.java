package ru.tundrabank.lib.m02;

public class C00402 { public int v() { return 402; } }
