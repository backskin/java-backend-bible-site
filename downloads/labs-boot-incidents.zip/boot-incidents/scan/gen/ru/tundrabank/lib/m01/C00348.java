package ru.tundrabank.lib.m01;

public class C00348 { public int v() { return 348; } }
