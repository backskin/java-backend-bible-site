package ru.tundrabank.lib.m01;

public class C00237 { public int v() { return 237; } }
