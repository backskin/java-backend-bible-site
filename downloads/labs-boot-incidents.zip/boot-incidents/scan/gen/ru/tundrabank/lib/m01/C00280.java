package ru.tundrabank.lib.m01;

public class C00280 { public int v() { return 280; } }
