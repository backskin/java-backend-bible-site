package ru.tundrabank.lib.m02;

public class C00439 { public int v() { return 439; } }
