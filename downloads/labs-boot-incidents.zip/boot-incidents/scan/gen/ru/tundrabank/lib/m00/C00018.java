package ru.tundrabank.lib.m00;

public class C00018 { public int v() { return 18; } }
