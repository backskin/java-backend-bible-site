package ru.tundrabank.lib.m00;

public class C00063 { public int v() { return 63; } }
