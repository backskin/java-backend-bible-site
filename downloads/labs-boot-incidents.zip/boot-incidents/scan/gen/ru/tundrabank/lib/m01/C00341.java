package ru.tundrabank.lib.m01;

public class C00341 { public int v() { return 341; } }
