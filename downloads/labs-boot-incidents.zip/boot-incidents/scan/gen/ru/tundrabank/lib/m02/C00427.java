package ru.tundrabank.lib.m02;

public class C00427 { public int v() { return 427; } }
