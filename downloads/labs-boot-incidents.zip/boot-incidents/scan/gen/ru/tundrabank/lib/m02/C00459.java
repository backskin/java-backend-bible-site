package ru.tundrabank.lib.m02;

public class C00459 { public int v() { return 459; } }
