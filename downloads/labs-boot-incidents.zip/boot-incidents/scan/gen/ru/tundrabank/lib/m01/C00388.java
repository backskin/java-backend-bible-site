package ru.tundrabank.lib.m01;

public class C00388 { public int v() { return 388; } }
