package ru.tundrabank.lib.m00;

public class C00161 { public int v() { return 161; } }
