package ru.tundrabank.lib.m01;

public class C00272 { public int v() { return 272; } }
