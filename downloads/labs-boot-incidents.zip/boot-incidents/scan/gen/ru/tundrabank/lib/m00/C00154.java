package ru.tundrabank.lib.m00;

public class C00154 { public int v() { return 154; } }
