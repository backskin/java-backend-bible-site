package ru.tundrabank.lib.m02;

public class C00416 { public int v() { return 416; } }
