package ru.tundrabank.lib.m00;

public class C00163 { public int v() { return 163; } }
