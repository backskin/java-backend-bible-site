package ru.tundrabank.lib.m00;

public class C00174 { public int v() { return 174; } }
