package ru.tundrabank.lib.m00;

public class C00147 { public int v() { return 147; } }
