package ru.tundrabank.lib.m01;

public class C00271 { public int v() { return 271; } }
