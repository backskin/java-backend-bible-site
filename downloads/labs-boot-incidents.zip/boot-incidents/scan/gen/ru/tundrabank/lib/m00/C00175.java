package ru.tundrabank.lib.m00;

public class C00175 { public int v() { return 175; } }
