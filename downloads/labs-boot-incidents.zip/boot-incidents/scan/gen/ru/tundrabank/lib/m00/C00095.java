package ru.tundrabank.lib.m00;

public class C00095 { public int v() { return 95; } }
