package ru.tundrabank.lib.m00;

public class C00080 { public int v() { return 80; } }
