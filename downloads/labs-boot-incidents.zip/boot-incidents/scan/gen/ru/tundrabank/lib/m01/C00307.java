package ru.tundrabank.lib.m01;

public class C00307 { public int v() { return 307; } }
