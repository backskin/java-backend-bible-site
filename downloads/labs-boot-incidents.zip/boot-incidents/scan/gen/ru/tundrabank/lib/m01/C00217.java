package ru.tundrabank.lib.m01;

public class C00217 { public int v() { return 217; } }
