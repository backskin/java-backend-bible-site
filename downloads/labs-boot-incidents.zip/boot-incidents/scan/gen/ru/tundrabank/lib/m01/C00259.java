package ru.tundrabank.lib.m01;

public class C00259 { public int v() { return 259; } }
