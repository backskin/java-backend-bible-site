package ru.tundrabank.lib.m02;

public class C00467 { public int v() { return 467; } }
