package ru.tundrabank.lib.m00;

public class C00178 { public int v() { return 178; } }
