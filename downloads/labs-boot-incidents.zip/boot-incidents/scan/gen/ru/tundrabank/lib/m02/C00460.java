package ru.tundrabank.lib.m02;

public class C00460 { public int v() { return 460; } }
