package ru.tundrabank.lib.m01;

public class C00218 { public int v() { return 218; } }
