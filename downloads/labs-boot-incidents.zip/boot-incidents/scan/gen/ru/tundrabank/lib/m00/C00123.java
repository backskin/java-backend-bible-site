package ru.tundrabank.lib.m00;

public class C00123 { public int v() { return 123; } }
