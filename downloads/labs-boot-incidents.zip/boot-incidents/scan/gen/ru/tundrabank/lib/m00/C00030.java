package ru.tundrabank.lib.m00;

public class C00030 { public int v() { return 30; } }
