package ru.tundrabank.lib.m02;

public class C00411 { public int v() { return 411; } }
