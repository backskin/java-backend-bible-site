package ru.tundrabank.lib.m01;

public class C00334 { public int v() { return 334; } }
