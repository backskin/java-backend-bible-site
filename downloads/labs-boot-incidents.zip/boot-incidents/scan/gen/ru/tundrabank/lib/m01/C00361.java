package ru.tundrabank.lib.m01;

public class C00361 { public int v() { return 361; } }
