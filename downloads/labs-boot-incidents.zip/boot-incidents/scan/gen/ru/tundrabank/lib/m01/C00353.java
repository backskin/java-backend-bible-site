package ru.tundrabank.lib.m01;

public class C00353 { public int v() { return 353; } }
