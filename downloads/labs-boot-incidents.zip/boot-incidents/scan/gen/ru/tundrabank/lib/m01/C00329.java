package ru.tundrabank.lib.m01;

public class C00329 { public int v() { return 329; } }
