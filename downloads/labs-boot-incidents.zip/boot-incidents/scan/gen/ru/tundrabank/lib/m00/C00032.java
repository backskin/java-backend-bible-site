package ru.tundrabank.lib.m00;

public class C00032 { public int v() { return 32; } }
