package ru.tundrabank.lib.m01;

public class C00239 { public int v() { return 239; } }
