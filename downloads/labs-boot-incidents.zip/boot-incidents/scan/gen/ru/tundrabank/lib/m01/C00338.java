package ru.tundrabank.lib.m01;

public class C00338 { public int v() { return 338; } }
