package ru.tundrabank.lib.m01;

public class C00286 { public int v() { return 286; } }
