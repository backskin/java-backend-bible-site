package ru.tundrabank.lib.m01;

public class C00367 { public int v() { return 367; } }
