package ru.tundrabank.lib.m01;

public class C00323 { public int v() { return 323; } }
