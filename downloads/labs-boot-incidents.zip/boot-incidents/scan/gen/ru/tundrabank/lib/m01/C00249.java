package ru.tundrabank.lib.m01;

public class C00249 { public int v() { return 249; } }
