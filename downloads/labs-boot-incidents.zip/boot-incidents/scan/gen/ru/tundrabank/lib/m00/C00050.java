package ru.tundrabank.lib.m00;

public class C00050 { public int v() { return 50; } }
