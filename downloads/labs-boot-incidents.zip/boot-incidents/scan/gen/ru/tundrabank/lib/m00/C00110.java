package ru.tundrabank.lib.m00;

public class C00110 { public int v() { return 110; } }
