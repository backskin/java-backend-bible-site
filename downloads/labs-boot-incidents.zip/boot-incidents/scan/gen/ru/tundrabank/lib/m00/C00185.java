package ru.tundrabank.lib.m00;

public class C00185 { public int v() { return 185; } }
