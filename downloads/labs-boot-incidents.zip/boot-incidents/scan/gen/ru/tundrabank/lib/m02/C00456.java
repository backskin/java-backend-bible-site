package ru.tundrabank.lib.m02;

public class C00456 { public int v() { return 456; } }
