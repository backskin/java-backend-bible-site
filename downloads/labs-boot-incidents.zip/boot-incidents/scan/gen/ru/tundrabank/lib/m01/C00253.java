package ru.tundrabank.lib.m01;

public class C00253 { public int v() { return 253; } }
