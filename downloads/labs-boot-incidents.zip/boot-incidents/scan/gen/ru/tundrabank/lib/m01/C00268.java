package ru.tundrabank.lib.m01;

public class C00268 { public int v() { return 268; } }
