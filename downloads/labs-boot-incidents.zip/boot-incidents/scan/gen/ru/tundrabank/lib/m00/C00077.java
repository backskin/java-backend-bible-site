package ru.tundrabank.lib.m00;

public class C00077 { public int v() { return 77; } }
