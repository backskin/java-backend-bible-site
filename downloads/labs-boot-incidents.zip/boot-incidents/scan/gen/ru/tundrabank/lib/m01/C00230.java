package ru.tundrabank.lib.m01;

public class C00230 { public int v() { return 230; } }
