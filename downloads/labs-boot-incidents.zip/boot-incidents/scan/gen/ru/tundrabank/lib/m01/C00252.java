package ru.tundrabank.lib.m01;

public class C00252 { public int v() { return 252; } }
