package ru.tundrabank.lib.m00;

public class C00140 { public int v() { return 140; } }
