package ru.tundrabank.lib.m02;

public class C00476 { public int v() { return 476; } }
