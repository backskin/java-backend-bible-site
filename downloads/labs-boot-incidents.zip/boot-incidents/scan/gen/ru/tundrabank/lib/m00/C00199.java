package ru.tundrabank.lib.m00;

public class C00199 { public int v() { return 199; } }
