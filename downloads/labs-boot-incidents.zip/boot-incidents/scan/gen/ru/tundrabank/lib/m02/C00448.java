package ru.tundrabank.lib.m02;

public class C00448 { public int v() { return 448; } }
