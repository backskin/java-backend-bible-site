package ru.tundrabank.lib.m00;

public class C00010 { public int v() { return 10; } }
