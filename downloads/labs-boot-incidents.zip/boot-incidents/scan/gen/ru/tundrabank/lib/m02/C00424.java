package ru.tundrabank.lib.m02;

public class C00424 { public int v() { return 424; } }
