package ru.tundrabank.lib.m00;

public class C00188 { public int v() { return 188; } }
