package ru.tundrabank.lib.m00;

public class C00162 { public int v() { return 162; } }
