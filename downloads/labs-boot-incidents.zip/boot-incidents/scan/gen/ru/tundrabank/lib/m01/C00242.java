package ru.tundrabank.lib.m01;

public class C00242 { public int v() { return 242; } }
