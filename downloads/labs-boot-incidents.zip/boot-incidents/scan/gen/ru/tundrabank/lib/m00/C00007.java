package ru.tundrabank.lib.m00;

public class C00007 { public int v() { return 7; } }
