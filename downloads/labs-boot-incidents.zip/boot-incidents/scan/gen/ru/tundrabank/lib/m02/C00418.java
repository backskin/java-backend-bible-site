package ru.tundrabank.lib.m02;

public class C00418 { public int v() { return 418; } }
