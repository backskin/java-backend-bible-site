package ru.tundrabank.lib.m00;

public class C00179 { public int v() { return 179; } }
