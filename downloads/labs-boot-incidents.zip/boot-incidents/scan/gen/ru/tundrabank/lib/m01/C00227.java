package ru.tundrabank.lib.m01;

public class C00227 { public int v() { return 227; } }
