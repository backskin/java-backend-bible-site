package ru.tundrabank.lib.m01;

public class C00311 { public int v() { return 311; } }
