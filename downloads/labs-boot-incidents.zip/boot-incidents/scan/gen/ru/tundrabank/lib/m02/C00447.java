package ru.tundrabank.lib.m02;

public class C00447 { public int v() { return 447; } }
