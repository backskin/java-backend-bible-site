package ru.tundrabank.lib.m02;

public class C00457 { public int v() { return 457; } }
