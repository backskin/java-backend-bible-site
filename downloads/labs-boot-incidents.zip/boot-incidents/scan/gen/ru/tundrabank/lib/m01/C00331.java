package ru.tundrabank.lib.m01;

public class C00331 { public int v() { return 331; } }
