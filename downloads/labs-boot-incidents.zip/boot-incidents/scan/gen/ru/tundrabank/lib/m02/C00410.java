package ru.tundrabank.lib.m02;

public class C00410 { public int v() { return 410; } }
