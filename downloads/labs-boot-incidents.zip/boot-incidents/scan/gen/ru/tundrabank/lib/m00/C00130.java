package ru.tundrabank.lib.m00;

public class C00130 { public int v() { return 130; } }
