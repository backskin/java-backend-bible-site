package ru.tundrabank.lib.m00;

public class C00148 { public int v() { return 148; } }
