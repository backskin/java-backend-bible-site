package ru.tundrabank.lib.m00;

public class C00133 { public int v() { return 133; } }
