package ru.tundrabank.lib.m01;

public class C00373 { public int v() { return 373; } }
