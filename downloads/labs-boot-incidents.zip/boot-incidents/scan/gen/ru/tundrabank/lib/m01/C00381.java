package ru.tundrabank.lib.m01;

public class C00381 { public int v() { return 381; } }
