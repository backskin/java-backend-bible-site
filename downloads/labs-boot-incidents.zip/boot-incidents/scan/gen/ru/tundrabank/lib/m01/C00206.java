package ru.tundrabank.lib.m01;

public class C00206 { public int v() { return 206; } }
