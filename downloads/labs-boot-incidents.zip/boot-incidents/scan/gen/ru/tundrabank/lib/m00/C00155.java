package ru.tundrabank.lib.m00;

public class C00155 { public int v() { return 155; } }
