package ru.tundrabank.lib.m02;

public class C00466 { public int v() { return 466; } }
