package ru.tundrabank.lib.m01;

public class C00224 { public int v() { return 224; } }
