package ru.tundrabank.lib.m00;

public class C00062 { public int v() { return 62; } }
