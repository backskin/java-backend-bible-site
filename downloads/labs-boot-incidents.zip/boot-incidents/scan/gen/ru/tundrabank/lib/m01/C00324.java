package ru.tundrabank.lib.m01;

public class C00324 { public int v() { return 324; } }
