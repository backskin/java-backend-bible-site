package ru.tundrabank.lib.m01;

public class C00225 { public int v() { return 225; } }
