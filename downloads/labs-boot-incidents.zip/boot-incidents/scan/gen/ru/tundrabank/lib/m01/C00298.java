package ru.tundrabank.lib.m01;

public class C00298 { public int v() { return 298; } }
