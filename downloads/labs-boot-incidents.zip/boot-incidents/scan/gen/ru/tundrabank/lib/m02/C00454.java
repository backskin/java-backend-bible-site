package ru.tundrabank.lib.m02;

public class C00454 { public int v() { return 454; } }
