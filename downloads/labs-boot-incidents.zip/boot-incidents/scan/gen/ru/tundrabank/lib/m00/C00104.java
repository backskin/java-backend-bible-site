package ru.tundrabank.lib.m00;

public class C00104 { public int v() { return 104; } }
