package ru.tundrabank.lib.m00;

public class C00192 { public int v() { return 192; } }
