package ru.tundrabank.lib.m01;

public class C00377 { public int v() { return 377; } }
