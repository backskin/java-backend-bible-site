package ru.tundrabank.lib.m02;

public class C00443 { public int v() { return 443; } }
