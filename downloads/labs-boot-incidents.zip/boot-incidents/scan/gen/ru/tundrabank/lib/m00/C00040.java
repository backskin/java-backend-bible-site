package ru.tundrabank.lib.m00;

public class C00040 { public int v() { return 40; } }
