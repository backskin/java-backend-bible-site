package ru.tundrabank.lib.m02;

public class C00407 { public int v() { return 407; } }
