package ru.tundrabank.lib.m02;

public class C00453 { public int v() { return 453; } }
