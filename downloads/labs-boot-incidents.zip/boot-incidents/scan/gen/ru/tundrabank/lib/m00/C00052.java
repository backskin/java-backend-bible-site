package ru.tundrabank.lib.m00;

public class C00052 { public int v() { return 52; } }
