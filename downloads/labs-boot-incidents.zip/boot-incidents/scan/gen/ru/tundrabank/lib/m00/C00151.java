package ru.tundrabank.lib.m00;

public class C00151 { public int v() { return 151; } }
