package ru.tundrabank.lib.m00;

public class C00013 { public int v() { return 13; } }
