package ru.tundrabank.lib.m02;

public class C00465 { public int v() { return 465; } }
