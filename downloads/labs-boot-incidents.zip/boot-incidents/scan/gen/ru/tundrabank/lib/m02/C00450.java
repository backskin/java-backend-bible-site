package ru.tundrabank.lib.m02;

public class C00450 { public int v() { return 450; } }
