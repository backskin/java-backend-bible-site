package ru.tundrabank.lib.m00;

public class C00153 { public int v() { return 153; } }
