package ru.tundrabank.lib.m00;

public class C00198 { public int v() { return 198; } }
