package ru.tundrabank.lib.m00;

public class C00197 { public int v() { return 197; } }
