package ru.tundrabank.lib.m02;

public class C00404 { public int v() { return 404; } }
