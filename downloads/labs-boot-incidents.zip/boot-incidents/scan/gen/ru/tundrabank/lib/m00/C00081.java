package ru.tundrabank.lib.m00;

public class C00081 { public int v() { return 81; } }
