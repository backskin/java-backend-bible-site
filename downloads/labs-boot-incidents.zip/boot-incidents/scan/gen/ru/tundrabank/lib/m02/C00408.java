package ru.tundrabank.lib.m02;

public class C00408 { public int v() { return 408; } }
