package ru.tundrabank.lib.m00;

public class C00064 { public int v() { return 64; } }
