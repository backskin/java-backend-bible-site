package ru.tundrabank.lib.m01;

public class C00216 { public int v() { return 216; } }
