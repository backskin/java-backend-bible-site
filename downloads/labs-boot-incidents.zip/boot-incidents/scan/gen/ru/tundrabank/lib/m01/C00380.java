package ru.tundrabank.lib.m01;

public class C00380 { public int v() { return 380; } }
