package ru.tundrabank.lib.m00;

public class C00138 { public int v() { return 138; } }
