package ru.tundrabank.lib.m01;

public class C00390 { public int v() { return 390; } }
