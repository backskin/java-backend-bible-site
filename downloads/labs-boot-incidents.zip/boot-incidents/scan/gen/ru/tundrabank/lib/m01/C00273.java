package ru.tundrabank.lib.m01;

public class C00273 { public int v() { return 273; } }
