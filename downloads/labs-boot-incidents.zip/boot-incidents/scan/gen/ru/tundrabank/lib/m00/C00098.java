package ru.tundrabank.lib.m00;

public class C00098 { public int v() { return 98; } }
