package ru.tundrabank.lib.m01;

public class C00234 { public int v() { return 234; } }
