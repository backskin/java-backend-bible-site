package ru.tundrabank.lib.m01;

public class C00275 { public int v() { return 275; } }
