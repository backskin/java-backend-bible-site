package ru.tundrabank.lib.m01;

public class C00251 { public int v() { return 251; } }
