package ru.tundrabank.lib.m00;

public class C00120 { public int v() { return 120; } }
