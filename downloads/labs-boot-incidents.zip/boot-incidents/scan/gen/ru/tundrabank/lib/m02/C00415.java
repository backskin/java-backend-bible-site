package ru.tundrabank.lib.m02;

public class C00415 { public int v() { return 415; } }
