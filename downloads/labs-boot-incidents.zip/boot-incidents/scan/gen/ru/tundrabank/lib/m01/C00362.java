package ru.tundrabank.lib.m01;

public class C00362 { public int v() { return 362; } }
