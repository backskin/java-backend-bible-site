package ru.tundrabank.lib.m01;

public class C00310 { public int v() { return 310; } }
