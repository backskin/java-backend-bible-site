package ru.tundrabank.lib.m01;

public class C00220 { public int v() { return 220; } }
