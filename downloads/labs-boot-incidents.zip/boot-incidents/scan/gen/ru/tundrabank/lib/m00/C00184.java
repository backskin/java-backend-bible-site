package ru.tundrabank.lib.m00;

public class C00184 { public int v() { return 184; } }
