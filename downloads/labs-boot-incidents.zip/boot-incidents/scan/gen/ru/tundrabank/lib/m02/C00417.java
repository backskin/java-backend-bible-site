package ru.tundrabank.lib.m02;

public class C00417 { public int v() { return 417; } }
