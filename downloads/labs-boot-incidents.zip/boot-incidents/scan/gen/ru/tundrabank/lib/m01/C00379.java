package ru.tundrabank.lib.m01;

public class C00379 { public int v() { return 379; } }
