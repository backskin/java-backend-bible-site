package ru.tundrabank.lib.m02;

public class C00412 { public int v() { return 412; } }
