package ru.tundrabank.lib.m00;

public class C00088 { public int v() { return 88; } }
