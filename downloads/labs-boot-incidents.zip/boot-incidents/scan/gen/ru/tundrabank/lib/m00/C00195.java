package ru.tundrabank.lib.m00;

public class C00195 { public int v() { return 195; } }
