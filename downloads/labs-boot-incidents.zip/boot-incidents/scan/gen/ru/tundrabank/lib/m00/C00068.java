package ru.tundrabank.lib.m00;

public class C00068 { public int v() { return 68; } }
