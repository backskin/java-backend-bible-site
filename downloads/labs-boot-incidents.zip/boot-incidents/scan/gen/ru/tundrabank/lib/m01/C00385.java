package ru.tundrabank.lib.m01;

public class C00385 { public int v() { return 385; } }
