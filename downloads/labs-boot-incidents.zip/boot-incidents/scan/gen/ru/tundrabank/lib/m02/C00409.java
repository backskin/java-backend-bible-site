package ru.tundrabank.lib.m02;

public class C00409 { public int v() { return 409; } }
