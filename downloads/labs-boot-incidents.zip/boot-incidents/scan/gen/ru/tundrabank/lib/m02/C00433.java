package ru.tundrabank.lib.m02;

public class C00433 { public int v() { return 433; } }
