package ru.tundrabank.lib.m02;

public class C00442 { public int v() { return 442; } }
