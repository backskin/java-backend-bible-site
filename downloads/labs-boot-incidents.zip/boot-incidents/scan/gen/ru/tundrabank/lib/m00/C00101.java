package ru.tundrabank.lib.m00;

public class C00101 { public int v() { return 101; } }
