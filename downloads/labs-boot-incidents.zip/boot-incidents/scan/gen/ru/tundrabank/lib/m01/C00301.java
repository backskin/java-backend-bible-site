package ru.tundrabank.lib.m01;

public class C00301 { public int v() { return 301; } }
