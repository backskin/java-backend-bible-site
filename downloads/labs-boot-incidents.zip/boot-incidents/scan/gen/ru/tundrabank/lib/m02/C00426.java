package ru.tundrabank.lib.m02;

public class C00426 { public int v() { return 426; } }
