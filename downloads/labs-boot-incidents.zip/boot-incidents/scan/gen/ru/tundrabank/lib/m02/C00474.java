package ru.tundrabank.lib.m02;

public class C00474 { public int v() { return 474; } }
