package ru.tundrabank.lib.m00;

public class C00045 { public int v() { return 45; } }
