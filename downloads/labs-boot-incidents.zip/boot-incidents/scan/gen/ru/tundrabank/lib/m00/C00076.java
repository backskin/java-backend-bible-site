package ru.tundrabank.lib.m00;

public class C00076 { public int v() { return 76; } }
