package ru.tundrabank.lib.m00;

public class C00055 { public int v() { return 55; } }
