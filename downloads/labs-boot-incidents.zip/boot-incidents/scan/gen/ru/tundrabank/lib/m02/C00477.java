package ru.tundrabank.lib.m02;

public class C00477 { public int v() { return 477; } }
