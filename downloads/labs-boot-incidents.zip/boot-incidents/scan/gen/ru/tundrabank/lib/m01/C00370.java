package ru.tundrabank.lib.m01;

public class C00370 { public int v() { return 370; } }
