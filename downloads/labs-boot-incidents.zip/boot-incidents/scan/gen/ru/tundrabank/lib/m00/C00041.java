package ru.tundrabank.lib.m00;

public class C00041 { public int v() { return 41; } }
