package ru.tundrabank.lib.m00;

public class C00001 { public int v() { return 1; } }
