package ru.tundrabank.lib.m01;

public class C00211 { public int v() { return 211; } }
