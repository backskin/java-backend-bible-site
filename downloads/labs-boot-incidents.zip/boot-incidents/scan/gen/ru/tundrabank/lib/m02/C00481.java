package ru.tundrabank.lib.m02;

public class C00481 { public int v() { return 481; } }
