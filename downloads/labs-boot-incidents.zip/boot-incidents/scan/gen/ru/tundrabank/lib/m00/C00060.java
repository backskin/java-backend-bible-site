package ru.tundrabank.lib.m00;

public class C00060 { public int v() { return 60; } }
