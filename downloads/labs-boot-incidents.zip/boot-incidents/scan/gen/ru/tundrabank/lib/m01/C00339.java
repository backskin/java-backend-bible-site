package ru.tundrabank.lib.m01;

public class C00339 { public int v() { return 339; } }
