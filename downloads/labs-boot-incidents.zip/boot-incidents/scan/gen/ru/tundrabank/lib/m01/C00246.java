package ru.tundrabank.lib.m01;

public class C00246 { public int v() { return 246; } }
