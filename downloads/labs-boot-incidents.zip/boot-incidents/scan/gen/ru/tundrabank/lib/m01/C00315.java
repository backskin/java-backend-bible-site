package ru.tundrabank.lib.m01;

public class C00315 { public int v() { return 315; } }
