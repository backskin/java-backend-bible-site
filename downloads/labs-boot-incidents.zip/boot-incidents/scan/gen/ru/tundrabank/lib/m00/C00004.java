package ru.tundrabank.lib.m00;

public class C00004 { public int v() { return 4; } }
