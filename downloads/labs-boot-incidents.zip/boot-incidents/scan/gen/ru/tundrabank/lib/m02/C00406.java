package ru.tundrabank.lib.m02;

public class C00406 { public int v() { return 406; } }
