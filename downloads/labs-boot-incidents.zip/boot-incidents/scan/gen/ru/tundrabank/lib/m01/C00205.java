package ru.tundrabank.lib.m01;

public class C00205 { public int v() { return 205; } }
