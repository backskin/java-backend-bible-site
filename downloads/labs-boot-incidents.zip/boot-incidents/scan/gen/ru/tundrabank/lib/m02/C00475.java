package ru.tundrabank.lib.m02;

public class C00475 { public int v() { return 475; } }
