package ru.tundrabank.lib.m01;

public class C00294 { public int v() { return 294; } }
