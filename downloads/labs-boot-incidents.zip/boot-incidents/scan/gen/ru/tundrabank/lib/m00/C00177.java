package ru.tundrabank.lib.m00;

public class C00177 { public int v() { return 177; } }
