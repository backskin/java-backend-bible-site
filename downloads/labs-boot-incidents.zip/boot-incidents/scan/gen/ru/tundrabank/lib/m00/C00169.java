package ru.tundrabank.lib.m00;

public class C00169 { public int v() { return 169; } }
