package ru.tundrabank.lib.m00;

public class C00014 { public int v() { return 14; } }
