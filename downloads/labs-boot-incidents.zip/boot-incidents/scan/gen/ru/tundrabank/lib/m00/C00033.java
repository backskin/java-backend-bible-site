package ru.tundrabank.lib.m00;

public class C00033 { public int v() { return 33; } }
