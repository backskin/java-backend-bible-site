package ru.tundrabank.lib.m01;

public class C00228 { public int v() { return 228; } }
