package ru.tundrabank.lib.m01;

public class C00304 { public int v() { return 304; } }
