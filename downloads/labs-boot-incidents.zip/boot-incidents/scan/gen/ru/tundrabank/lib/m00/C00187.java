package ru.tundrabank.lib.m00;

public class C00187 { public int v() { return 187; } }
