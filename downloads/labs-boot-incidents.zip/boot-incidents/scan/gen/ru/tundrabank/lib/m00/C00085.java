package ru.tundrabank.lib.m00;

public class C00085 { public int v() { return 85; } }
