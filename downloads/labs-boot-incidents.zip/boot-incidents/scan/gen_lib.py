"""Генерирует «корпоративную библиотеку» для инцидента 11.5: 20 000 классов в ru.tundrabank.lib.mNN,
из них 50 с @Component и 10 с @Configuration, которые приложению не нужны.
python gen_lib.py <каталог исходников>
"""
import pathlib, sys

root = pathlib.Path(sys.argv[1])
n = 0
for m in range(100):
    pkg = f"ru.tundrabank.lib.m{m:02d}"
    d = root / pkg.replace(".", "/")
    d.mkdir(parents=True, exist_ok=True)
    for c in range(200):
        n += 1
        ann = ""
        if n % 400 == 0:
            ann = "@org.springframework.stereotype.Component\n"
        if n % 2000 == 0:
            ann = "@org.springframework.context.annotation.Configuration(proxyBeanMethods = false)\n"
        (d / f"C{n:05d}.java").write_text(
            f"package {pkg};\n\n{ann}public class C{n:05d} {{ public int v() {{ return {n}; }} }}\n", encoding="utf-8")
print(n, "классов")
