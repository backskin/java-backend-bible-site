package ru.tundrabank.payments.gateway;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Тот же шлюз, главный класс в пакете своего сервиса. */
@SpringBootApplication
public class GatewayApp {
    public static void main(String[] args) { ScanReport.run(GatewayApp.class, args); }
}
