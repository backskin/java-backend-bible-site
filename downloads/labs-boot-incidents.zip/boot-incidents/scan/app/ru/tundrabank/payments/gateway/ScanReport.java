package ru.tundrabank.payments.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.metrics.buffering.BufferingApplicationStartup;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.stream.StreamSupport;

/** Запускает приложение с BufferingApplicationStartup и печатает, сколько стоило сканирование. */
public final class ScanReport {

    @RestController
    static class TransferController { @GetMapping("/api/transfer") String ok() { return "ACCEPTED"; } }

    public static void run(Class<?> main, String[] args) {
        BufferingApplicationStartup startup = new BufferingApplicationStartup(16384);
        SpringApplication app = new SpringApplication(main);
        app.setApplicationStartup(startup);
        long t = System.nanoTime();
        var ctx = app.run(args);
        long ms = (System.nanoTime() - t) / 1_000_000;
        long lib = Arrays.stream(ctx.getBeanDefinitionNames()).filter(n -> {
            Class<?> type = ctx.getType(n);
            return type != null && type.getName().startsWith("ru.tundrabank.lib.");
        }).count();
        startup.getBufferedTimeline().getEvents().stream()
                .filter(e -> e.getStartupStep().getName().equals("spring.context.config-classes.parse"))
                .forEach(e -> System.out.println("   spring.context.config-classes.parse: " + e.getDuration().toMillis() + " мс, "
                        + StreamSupport.stream(e.getStartupStep().getTags().spliterator(), false)
                                .map(tag -> tag.getKey() + "=" + tag.getValue()).toList()));
        System.out.println("   старт " + main.getSimpleName() + ": " + ms + " мс; бинов всего " + ctx.getBeanDefinitionCount() + ", из библиотеки ru.tundrabank.lib: " + lib);
        ctx.close();
    }
}
