package ru.tundrabank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Главный класс в корне корпоративного пакета: сканирование обходит все библиотеки ru.tundrabank.*. */
@SpringBootApplication
public class RootApp {
    public static void main(String[] args) { ru.tundrabank.payments.gateway.ScanReport.run(RootApp.class, args); }
}
