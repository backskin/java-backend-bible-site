package ru.tundra.notify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import tools.jackson.databind.PropertyNamingStrategies;

import java.math.BigDecimal;

/** Уведомления партнёру о зачислении: партнёр ждёт поля в snake_case. */
@SpringBootApplication
public class NotifyApp {
    public record CreditNotice(String accountId, BigDecimal creditedAmount) { }

    /** Формат для партнёра задаёт кастомайзер приложения. */
    @Bean
    JsonMapperBuilderCustomizer partnerNaming() {
        return b -> b.propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }

    public static void main(String[] args) { SpringApplication.run(NotifyApp.class, args); }
}
