package ru.tundra.observability;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import tools.jackson.databind.cfg.DateTimeFeature;

/** Стартер трассировки: даты строками ISO 8601, как их ждут партнёры. */
@AutoConfiguration(before = org.springframework.boot.jackson.autoconfigure.JacksonAutoConfiguration.class)
public class TracingJacksonAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean
    JsonMapperBuilderCustomizer tracingJsonCustomizer() {
        return b -> b.disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS);
    }
}
