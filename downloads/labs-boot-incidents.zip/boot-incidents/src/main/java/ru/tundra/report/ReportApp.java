package ru.tundra.report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** Сервис отчётности для инцидента 11.4: на нём гоняют сорок с лишним интеграционных тестов. */
@SpringBootApplication
public class ReportApp {
    public static void main(String[] args) { SpringApplication.run(ReportApp.class, args); }

    @Service
    public static class ReportService {
        private final int batch;
        public ReportService(Environment env) { this.batch = env.getProperty("tundra.report.batch", Integer.class, 500); }
        public int batch() { return batch; }
    }

    @RestController
    static class ReportController {
        private final ReportService service;
        ReportController(ReportService service) { this.service = service; }
        @GetMapping("/api/reports/batch") int batch() { return service.batch(); }
    }
}
