package ru.tundra.audit.autoconfigure;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import tools.jackson.databind.cfg.DateTimeFeature;

/** Стартер аудита 4.1.0: тот же код, класс перенесён в другой пакет. */
@AutoConfiguration(before = org.springframework.boot.jackson.autoconfigure.JacksonAutoConfiguration.class)
public class AuditJacksonAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean
    JsonMapperBuilderCustomizer auditJsonCustomizer() {
        return b -> b.enable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS);
    }
}
