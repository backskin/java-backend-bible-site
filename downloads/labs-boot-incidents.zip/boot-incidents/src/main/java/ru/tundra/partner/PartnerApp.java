package ru.tundra.partner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.endpoint.SanitizingFunction;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

/** Инцидент 11.3: учётные данные партнёра пришли составной строкой в переменной окружения. */
@SpringBootApplication
public class PartnerApp {

    /** Маскирует всё, что похоже на секрет, даже при show-values=always; включается флагом lab.sanitize. */
    @Bean
    @ConditionalOnProperty("lab.sanitize")
    SanitizingFunction partnerSecrets() {
        return SanitizingFunction.sanitizeValue()
                .ifLikelySensitive()
                .ifKeyMatches("(?i).*credentials.*");
    }

    public static void main(String[] args) { SpringApplication.run(PartnerApp.class, args); }
}
