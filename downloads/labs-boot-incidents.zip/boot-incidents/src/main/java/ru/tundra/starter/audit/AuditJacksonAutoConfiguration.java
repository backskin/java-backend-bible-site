package ru.tundra.starter.audit;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import tools.jackson.databind.cfg.DateTimeFeature;

/** Стартер аудита 4.0.3: даты числами, как их хранит журнал аудита. */
@AutoConfiguration(before = org.springframework.boot.jackson.autoconfigure.JacksonAutoConfiguration.class)
public class AuditJacksonAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean
    JsonMapperBuilderCustomizer auditJsonCustomizer() {
        return b -> b.enable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS);
    }
}
