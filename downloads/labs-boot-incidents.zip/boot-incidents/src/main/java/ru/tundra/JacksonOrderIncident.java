package ru.tundra;

import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
import org.springframework.boot.jackson.autoconfigure.JacksonAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import tools.jackson.databind.json.JsonMapper;

import java.time.Instant;

/**
 * Инцидент 11.1: два внутренних стартера объявляют кастомайзер JsonMapper под @ConditionalOnMissingBean
 * без порядка; после переноса класса аудита в другой пакет меняется алфавит и формат дат у партнёра.
 */
public class JacksonOrderIncident {

    record PaymentNotice(String id, Instant bookedAt) { }

    public static void main(String[] a) {
        run("стартер аудита 4.0.3 (ru.tundra.starter.audit), трассировки (ru.tundra.observability)",
                ru.tundra.starter.audit.AuditJacksonAutoConfiguration.class);
        run("стартер аудита 4.1.0 (ru.tundra.audit.autoconfigure), трассировки (ru.tundra.observability)",
                ru.tundra.audit.autoconfigure.AuditJacksonAutoConfiguration.class);
        System.out.println("== исправление: свой кастомайзер приложения с @Order(LOWEST_PRECEDENCE) поверх стартера 4.1.0");
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(JacksonAutoConfiguration.class, ru.tundra.audit.autoconfigure.AuditJacksonAutoConfiguration.class,
                        ru.tundra.observability.TracingJacksonAutoConfiguration.class))
                .withUserConfiguration(AppJson.class)
                .run(ctx -> System.out.println("   уведомление партнёру: " + ctx.getBean(JsonMapper.class).writeValueAsString(
                        new PaymentNotice("P-2026-000154", Instant.parse("2026-09-21T10:15:00Z")))));
    }

    @org.springframework.context.annotation.Configuration(proxyBeanMethods = false)
    static class AppJson {
        @org.springframework.context.annotation.Bean
        @org.springframework.core.annotation.Order(org.springframework.core.Ordered.LOWEST_PRECEDENCE)
        org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer partnerDates() {
            return b -> b.disable(tools.jackson.databind.cfg.DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS);
        }
    }

    static void run(String label, Class<?> audit) {
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(JacksonAutoConfiguration.class, audit,
                        ru.tundra.observability.TracingJacksonAutoConfiguration.class))
                .run(ctx -> {
                    String json = ctx.getBean(JsonMapper.class).writeValueAsString(
                            new PaymentNotice("P-2026-000154", Instant.parse("2026-09-21T10:15:00Z")));
                    System.out.println("== " + label);
                    System.out.println("   уведомление партнёру: " + json);
                    ConditionEvaluationReport.get(ctx.getBeanFactory()).getConditionAndOutcomesBySource().forEach((src, o) -> {
                        if (src.contains("JacksonAutoConfiguration#") && !src.startsWith("org.")) o.forEach(co ->
                                System.out.println("   " + src.replaceAll(".*\\.", "") + ": " + (co.getOutcome().isMatch() ? "применён" : "не применён — " + co.getOutcome().getMessage())));
                    });
                });
    }
}
