package ru.tundra.limits;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.context.annotation.Bean;

import java.time.Duration;

/**
 * Инцидент 11.2: свойство переименовали из read-timeout в response-timeout,
 * а переменную окружения в новом контуре завели по старому имени.
 */
@SpringBootApplication
@EnableConfigurationProperties(LimitsGatewayApp.LimitsProperties.class)
public class LimitsGatewayApp {

    @ConfigurationProperties("tundra.limits")
    public record LimitsProperties(@DefaultValue("2s") Duration responseTimeout) { }

    @Bean
    ApplicationRunner printTimeout(LimitsProperties p) {
        return a -> System.out.println("   тайм-аут клиента лимитов: " + p.responseTimeout());
    }

    public static void main(String[] args) { SpringApplication.run(LimitsGatewayApp.class, args); }
}
