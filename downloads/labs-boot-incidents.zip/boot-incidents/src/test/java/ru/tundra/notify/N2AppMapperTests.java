package ru.tundra.notify;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import tools.jackson.databind.SerializationFeature;
import tools.jackson.databind.json.JsonMapper;

import java.math.BigDecimal;

/** Исправление: тест дополняет преобразователь кастомайзером, а не заменяет его. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
class N2AppMapperTests {

    @TestConfiguration(proxyBeanMethods = false)
    static class TestJson {
        @Bean JsonMapperBuilderCustomizer readableInTests() { return b -> b.enable(SerializationFeature.INDENT_OUTPUT); }
    }

    @Autowired JsonMapper mapper;

    @Test
    void notice() {
        System.out.println("   ► тест с кастомайзером: " + mapper.writeValueAsString(new NotifyApp.CreditNotice("40817810000000000154", new BigDecimal("1500.00"))).replaceAll("\\s+", " "));
    }
}
