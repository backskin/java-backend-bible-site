package ru.tundra.notify;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import tools.jackson.databind.json.JsonMapper;

import java.math.BigDecimal;

/** Контекст как в бою, без тестовых подмен: что на самом деле уходит партнёру. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
class N0ProductionMapperTests {

    @Autowired JsonMapper mapper;

    @Test
    void notice() {
        System.out.println("   ► контекст как в бою: " + mapper.writeValueAsString(new NotifyApp.CreditNotice("40817810000000000154", new BigDecimal("1500.00"))));
    }
}
