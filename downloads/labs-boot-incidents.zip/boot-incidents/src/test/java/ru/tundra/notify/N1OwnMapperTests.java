package ru.tundra.notify;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import tools.jackson.databind.json.JsonMapper;

import java.math.BigDecimal;

/** Тестовая конфигурация объявила свой JsonMapper «чтобы было удобно»: автоконфигурация отступила. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
class N1OwnMapperTests {

    @TestConfiguration(proxyBeanMethods = false)
    static class TestJson {
        @Bean JsonMapper jsonMapper() { return JsonMapper.builder().build(); }
    }

    @Autowired JsonMapper mapper;

    @Test
    void notice() {
        System.out.println("   ► тест со своим JsonMapper: " + mapper.writeValueAsString(new NotifyApp.CreditNotice("40817810000000000154", new BigDecimal("1500.00"))));
    }
}
