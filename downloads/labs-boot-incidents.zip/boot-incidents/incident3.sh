#!/usr/bin/env bash
# Инцидент 11.3. Запуск из labs/boot-incidents: bash incident3.sh
CP="target/classes;$(cat cp.txt)"
BASE="--server.port=18099 --spring.main.banner-mode=off --logging.level.root=warn --management.endpoints.web.exposure.include=*"
run() {
  local label="$1"; shift
  TUNDRA_PARTNER_CREDENTIALS='svc-sbp:Lab-Only-Pass1@https://partner.test' java -Dstdout.encoding=UTF-8 -cp "$CP" ru.tundra.partner.PartnerApp $BASE "$@" > app.log 2>&1 &
  for i in $(seq 1 60); do curl -s localhost:18099/actuator/health > /dev/null && break; sleep 0.5; done
  echo "== $label"
  echo "   /actuator/env/TUNDRA_PARTNER_CREDENTIALS → $(curl -s localhost:18099/actuator/env/TUNDRA_PARTNER_CREDENTIALS | grep -o '"property":{[^}]*}' | head -1)"
  echo "   /actuator/env/tundra.partner.credentials → $(curl -s localhost:18099/actuator/env/tundra.partner.credentials | grep -o '"property":{[^}]*}' | head -1)"
  powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='java.exe'\" | Where-Object { \$_.CommandLine -match 'PartnerApp' } | ForEach-Object { Stop-Process -Id \$_.ProcessId -Force }"
  sleep 1
}
run "1. exposure=*, show-values по умолчанию"
run "2. exposure=*, show-values=always" --management.endpoint.env.show-values=always
run "3. exposure=*, show-values=always и своя SanitizingFunction" --management.endpoint.env.show-values=always --lab.sanitize=true
rm -f app.log
