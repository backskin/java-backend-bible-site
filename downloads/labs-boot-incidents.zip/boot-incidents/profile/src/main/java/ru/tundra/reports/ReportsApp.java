package ru.tundra.reports;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;

/** Сервис отчётности: в бою должен работать на PostgreSQL из профиля prod. */
@SpringBootApplication
public class ReportsApp {

    @Bean
    ApplicationRunner report(DataSource ds, Environment env) {
        return a -> {
            try (var c = ds.getConnection()) {
                System.out.println("   активные профили: " + java.util.List.of(env.getActiveProfiles()) + "; база: "
                        + c.getMetaData().getDatabaseProductName() + " " + c.getMetaData().getURL());
            }
        };
    }

    public static void main(String[] args) { SpringApplication.run(ReportsApp.class, args); }
}
