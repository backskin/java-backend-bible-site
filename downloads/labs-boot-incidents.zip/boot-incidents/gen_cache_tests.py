"""Генерирует 44 тестовых класса для инцидента 11.4.

python gen_cache_tests.py scattered   — у каждого свой properties: 36 уникальных конфигураций, классы 37–44 повторяют 1–8
python gen_cache_tests.py unified     — все 44 класса на @ReportIntegrationTest
"""
import pathlib, sys

mode = sys.argv[1]
d = pathlib.Path(__file__).parent / "src/test/java/ru/tundra/report/gen"
d.mkdir(parents=True, exist_ok=True)
for f in d.glob("*.java"):
    f.unlink()
for i in range(1, 45):
    batch = i if i <= 36 else i - 36
    if mode == "scattered":
        ann = f'@org.springframework.boot.test.context.SpringBootTest(properties = "tundra.report.batch={batch}")'
        expect = batch
    else:
        ann = "@ru.tundra.report.ReportIntegrationTest"
        expect = 500
    (d / f"R{i:02d}Tests.java").write_text(f"""package ru.tundra.report.gen;

{ann}
class R{i:02d}Tests {{
    @org.springframework.beans.factory.annotation.Autowired ru.tundra.report.ReportApp.ReportService service;

    @org.junit.jupiter.api.Test
    void batch() {{ org.assertj.core.api.Assertions.assertThat(service.batch()).isEqualTo({expect}); }}
}}
""", encoding="utf-8")
print(mode, "44 классов")
