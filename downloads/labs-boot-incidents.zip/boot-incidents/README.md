# Восемь инцидентов Spring Boot: порядок кастомайзеров Jackson, старое имя свойства, секрет в /actuator/env, кэш тестовых контекстов, сканирование 20 000 классов, профили, старт без базы

Стенд к главе 10, раздел 11. Каждый инцидент - свое приложение или скрипт на Spring Boot 4.1.1: `JacksonOrderIncident` (11.1, два стартера с кастомайзерами `ObjectMapper` и `@Order`), `incident2.sh` с `LimitsGatewayApp` (11.2, переменная `TUNDRA_LIMITS_READTIMEOUT` при переименованном свойстве и `spring-boot-properties-migrator`), `incident3.sh` с `PartnerApp` и `boot27/` (11.3, секрет в `/actuator/env` на Boot 4.1 и 2.7), `gen_cache_tests.py` (11.4, 44 тестовых класса с разными и с едиными настройками), `scan/` (11.5, библиотека из 20 000 классов с одинаковыми простыми именами; классы генерируются скриптом, в репозитории их нет), `profile/` с `ReportsApp` (11.6, `SPRING_PROFILES_ACTIVE` и база), `ReportApp` (11.7, старт при недоступной базе), `NotifyApp` (11.8, одно уведомление в трех контекстах Jackson). Выводы автора - `s10-incident1.txt` … `s10-incident8.txt`.

## Что нужно

- JDK 21, Maven, bash с `curl`; для 11.3 на Boot 2.7 - JDK 17; для 11.6 - Docker (PostgreSQL 17).

## Запуск

Сборка и classpath:

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt
```

Инциденты со скриптами: `bash incident2.sh`, `bash incident3.sh` (порты 18098 и 18099). Инциденты-приложения запускаются из IDEA (конфигурации `JacksonOrderIncident`, `NotifyApp`, `ReportApp`, `PartnerApp`, `LimitsGatewayApp`, `boot27: PartnerApp27`, `profile: ReportsApp`) или `java -cp "target/classes;$(cat cp.txt)" <класс>`. Кэш тестов: `python gen_cache_tests.py` создает тесты, затем `mvn test`.

## Что должно получиться

11.2: тайм-аут остается `PT2S`, пока свойство не переименовано или не подключен migrator; 11.3: Boot 4.1 маскирует значение `******` даже при `show-values=always`, пока не задана своя `SanitizingFunction`; 11.4: 32 контекста против одного, 15 с против 8.
