package ru.tundra.old;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Тот же сервис партнёра на Boot 2.7.18. */
@SpringBootApplication
public class PartnerApp27 {
    public static void main(String[] args) { SpringApplication.run(PartnerApp27.class, args); }
}
