#!/usr/bin/env bash
# Инцидент 11.2. Запуск из labs/boot-incidents: bash incident2.sh
CP_ALL="target/classes;$(cat cp.txt)"
CP_NOMIG=$(echo "$CP_ALL" | tr ';' '\n' | grep -v properties-migrator | paste -sd ';')
ARGS="--server.port=18098 --spring.main.banner-mode=off --logging.level.root=warn --management.endpoints.web.exposure.include=env --management.endpoint.env.show-values=always"
run() {
  local label="$1" cp="$2"
  BANK=1 TUNDRA_LIMITS_READTIMEOUT=10s java -Dstdout.encoding=UTF-8 -cp "$cp" ru.tundra.limits.LimitsGatewayApp $ARGS > app.log 2>&1 &
  for i in $(seq 1 60); do curl -s localhost:18098/actuator/env > /dev/null && break; sleep 0.5; done
  echo "== $label"
  grep -a "тайм-аут клиента" app.log
  echo "   /actuator/env/tundra.limits.response-timeout → $(curl -s localhost:18098/actuator/env/tundra.limits.response-timeout | grep -o '"property":{[^}]*}' | head -1)"
  echo "   /actuator/env/tundra.limits.read-timeout → $(curl -s localhost:18098/actuator/env/tundra.limits.read-timeout | grep -o '"property":{[^}]*}' | head -1)"
  echo "   /actuator/env/tundra.limits.readtimeout → $(curl -s localhost:18098/actuator/env/tundra.limits.readtimeout | grep -o '"property":{[^}]*}' | head -1)"
  sed -n '/PropertiesMigrationListener/,+8p' app.log | grep -v '^$' | sed -E 's/^[0-9]{4}-[0-9-]+T[^ ]+ +//' | cut -c1-200 | sed 's/^/   журнал: /'
  grep -a "ERROR" app.log | grep -v "^\s*at " | sed 's/^[0-9T:.+-]* *//' | cut -c1-400 | sed 's/^/   журнал: /'
  powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='java.exe'\" | Where-Object { \$_.CommandLine -match 'LimitsGatewayApp' } | ForEach-Object { Stop-Process -Id \$_.ProcessId -Force }"
  sleep 1
}
run "переменная TUNDRA_LIMITS_READTIMEOUT=10s, свойство называется response-timeout" "$CP_NOMIG"
run "то же с spring-boot-properties-migrator и метаданными deprecation" "$CP_ALL"
