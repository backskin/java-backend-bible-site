import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Три показателя вакансии: Lead Time (от принятия спецификации до продакшена), доля сценариев, принятых с первого предъявления, и CSI.
 * Данные учебные: два периода по восемь сценариев; запуск: java KpiDemo.java (JDK 21).
 */
public class KpiDemo {

    record Scenario(String id, String specAccepted, String deployed, int presentations, int csi) {
        long leadDays() { return ChronoUnit.DAYS.between(LocalDate.parse(specAccepted), LocalDate.parse(deployed)); }
        boolean firstPass() { return presentations == 1; }
    }

    static long percentile(List<Long> sorted, double p) {
        int index = (int) Math.ceil(p * sorted.size()) - 1;
        return sorted.get(Math.max(0, index));
    }

    static void report(String title, List<Scenario> items) {
        List<Long> lead = items.stream().map(Scenario::leadDays).sorted(Comparator.naturalOrder()).toList();
        double firstPass = 100.0 * items.stream().filter(Scenario::firstPass).count() / items.size();
        double csi = items.stream().mapToInt(Scenario::csi).average().orElse(0);
        System.out.printf("  %-34s Lead Time: медиана %2d дн., p90 %2d дн.; с первого раза: %3.0f %%; CSI: %.1f из 5%n",
                title, percentile(lead, 0.5), percentile(lead, 0.9), firstPass, csi);
    }

    public static void main(String[] args) {
        List<Scenario> before = new ArrayList<>(List.of(
                new Scenario("S-01", "2026-01-12", "2026-02-03", 3, 3), new Scenario("S-02", "2026-01-14", "2026-02-09", 2, 3),
                new Scenario("S-03", "2026-01-19", "2026-02-20", 4, 2), new Scenario("S-04", "2026-01-26", "2026-02-17", 1, 4),
                new Scenario("S-05", "2026-02-02", "2026-03-04", 3, 3), new Scenario("S-06", "2026-02-09", "2026-03-02", 2, 4),
                new Scenario("S-07", "2026-02-16", "2026-03-23", 3, 3), new Scenario("S-08", "2026-02-23", "2026-03-18", 2, 3)));
        List<Scenario> after = new ArrayList<>(List.of(
                new Scenario("S-09", "2026-04-06", "2026-04-17", 1, 5), new Scenario("S-10", "2026-04-08", "2026-04-22", 1, 4),
                new Scenario("S-11", "2026-04-13", "2026-04-30", 2, 4), new Scenario("S-12", "2026-04-20", "2026-05-01", 1, 5),
                new Scenario("S-13", "2026-04-27", "2026-05-12", 1, 4), new Scenario("S-14", "2026-05-04", "2026-05-19", 1, 5),
                new Scenario("S-15", "2026-05-11", "2026-05-29", 2, 4), new Scenario("S-16", "2026-05-18", "2026-05-28", 1, 5)));
        System.out.println("=== учебные данные: период до введения критериев приёмки и автоматических проверок и после");
        report("до (сценарии S-01..S-08)", before);
        report("после (сценарии S-09..S-16)", after);
        System.out.println("  Связь показателей: сценарии с несколькими предъявлениями в «до» дают самые длинные Lead Time (S-03: 4 предъявления, 32 дня).");
    }
}
