# Ревью кода от ИИ: генерация, статический анализ, покрытие и мутанты (гл. 81, подраздел 7.4)

Стенд из трех частей.

1. `gen/` - локальная модель `qwen2.5:1.5b` через Ollama десять раз пишет метод комиссии `feeMinor(amountMinor, bps)`
   с округлением HALF_UP; скрипт компилирует каждый вариант и проверяет на восьми случаях
   (`gen_check.py 10 0.8 plain` - короткая постановка, `framed` - с формулой, примерами и запретами);
   `review_check.py` просит ту же модель оценить варианты как ревьюер.
2. Maven-проект в корне - класс `PaymentService` в стиле кода от ИИ, написанный вручную с пятью типичными дефектами
   (секрет в коде, `BigDecimal` из `double`, сравнение строк через `==`, проглоченное исключение, SQL склейкой строк),
   слабые тесты `WeakTest` в том же стиле, исправленный `PaymentServiceFixed` и тесты `StrongTest`.
   Подключены SpotBugs с Find Security Bugs, JaCoCo с порогом 80 % строк и PIT.
3. `k8s/` - манифест Deployment в стиле ИИ (`replicas` строкой, поле `limit` вместо `limits`) и исправленный.

## Что нужно

JDK 21, Maven 3.9, Python 3.10+, Ollama с `qwen2.5:1.5b` (часть 1), любой кластер Kubernetes, например kind (часть 3).

## Запуск

```bash
mvn compile spotbugs:check                             # статический анализ
mvn verify                                             # тесты и порог покрытия
mvn test-compile org.pitest:pitest-maven:mutationCoverage
python gen/gen_check.py 10 0.8 plain                   # из папки gen/
kubectl apply --dry-run=server -f k8s/ai-deployment.yaml
```

## Что получилось при проверке (2026-11-16)

- `run-spotbugs.txt` (SpotBugs 4.10.5, Find Security Bugs 1.14.0): шесть замечаний к `PaymentService` - проглоченное
  исключение, `BigDecimal` из `double`, сравнение строк по ссылке, незакрытый `Statement` и SQL-инъекция (два правила);
  пароль в коде не найден.
- `run-verify.txt`: девять зеленых тестов, порог покрытия 80 % пройден.
- `run-pit-by-class.txt` (PIT 1.30.1): у `PaymentService` со слабыми тестами убито 3 мутанта из 9 (33 %),
  у `PaymentServiceFixed` с сильными - 13 из 17 (76 %).
- `k8s/run.txt` (kind, Kubernetes 1.37.0): сервер отклоняет `replicas: "3"`, после исправления - поле `limit`,
  исправленный манифест принимается.
- `gen/run-plain.txt`, `gen/run-framed.txt`, `gen/run-review.txt` - генерация и ревью моделью (Ollama 0.40.16);
  результаты первого запуска 2026-10-20 на более старой версии Ollama сохранены в `gen/saved-plain`, `gen/saved-framed`.
