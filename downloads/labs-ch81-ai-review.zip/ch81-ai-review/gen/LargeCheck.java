import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Проверка варианта, прошедшего все восемь случаев, на крупных суммах: Fee.feeMinor из папки варианта
 * сравнивается с точным расчетом в BigDecimal. Запуск: java -cp gen/s8 LargeCheck.java
 * (класс Fee берется из папки варианта, сам LargeCheck запускается из исходника).
 */
public class LargeCheck {
    public static void main(String[] args) {
        long[] amounts = {1_234_567_891L, 123_456_789_012L, 1_000_000_000_005L, 12_345_678_901_235L, 999_999_999_999_995L,
                66666666700L, 66666666666700L, 6666666666666700L, 66666666666666900L}; // последние - ровно половина копейки
        int bps = 150;
        int wrong = 0;
        for (long amount : amounts) {
            long exact = BigDecimal.valueOf(amount).multiply(BigDecimal.valueOf(bps))
                    .divide(BigDecimal.valueOf(10_000), 0, RoundingMode.HALF_UP).longValueExact();
            long got = Fee.feeMinor(amount, bps);
            if (got != exact) wrong++;
            System.out.printf("%,25d коп. x %d bps: вариант %,d, точно %,d%s%n", amount, bps, got, exact, got == exact ? "" : "  РАСХОЖДЕНИЕ");
        }
        System.out.println("расхождений: " + wrong + " из " + amounts.length);
        // Случайные суммы по порядкам: где расчет через double начинает расходиться с точным.
        java.util.Random random = new java.util.Random(1);
        int[] rates = {1, 25, 100, 150, 175, 250, 299};
        for (int exp = 9; exp <= 16; exp++) {
            long from = (long) Math.pow(10, exp);
            int diff = 0, n = 100_000;
            for (int i = 0; i < n; i++) {
                long amount = from + (long) (random.nextDouble() * 9 * from);
                int rate = rates[random.nextInt(rates.length)];
                long exact = BigDecimal.valueOf(amount).multiply(BigDecimal.valueOf(rate))
                        .divide(BigDecimal.valueOf(10_000), 0, RoundingMode.HALF_UP).longValueExact();
                if (Fee.feeMinor(amount, rate) != exact) diff++;
            }
            System.out.printf("суммы 10^%d..10^%d коп.: расхождений %d из %d%n", exp, exp + 1, diff, n);
        }
    }
}
