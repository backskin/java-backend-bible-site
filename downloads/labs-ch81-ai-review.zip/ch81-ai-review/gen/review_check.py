"""Ревью кода моделью: ловит ли qwen2.5:1.5b известные дефекты в сгенерированных вариантах. Запуск: python review_check.py"""
import json
import os
import urllib.request

BASE = "http://localhost:11434"
MODEL = "qwen2.5:1.5b"
HERE = os.path.dirname(os.path.abspath(__file__))

SPEC = "Метод feeMinor(amountMinor, bps) должен вернуть amountMinor * bps / 10000, округлённое до целой копейки по HALF_UP."

# (папка, известно ли, что вариант верен на 8 случаях)
SAMPLES = {"gen/s0": False, "gen/s3": False, "gen/s4": False, "gen/s8": True, "gen/s1": False, "gen/s9": False}


def ask(code, seed):
    prompt = (f"Требование: {SPEC}\n\nКод:\n{code}\n\nСоответствует ли код требованию? Ответь первым словом ДА или НЕТ, затем одна фраза с объяснением.")
    body = {"model": MODEL, "stream": False, "options": {"temperature": 0.7, "seed": seed, "num_predict": 60},
            "messages": [{"role": "user", "content": prompt}]}
    req = urllib.request.Request(BASE + "/api/chat", data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.load(r)["message"]["content"].strip()


total_wrong_said_yes = total_wrong = 0
for folder, passes in SAMPLES.items():
    code = open(os.path.join(HERE, folder, "Fee.java"), encoding="utf-8", errors="replace").read()
    answers = [ask(code, 500 + k).lower() for k in range(6)]
    yes = sum(a.startswith("да") for a in answers)
    no = sum(a.startswith("нет") for a in answers)
    print(f"{folder}: {'проходит 8/8' if passes else 'содержит дефект'}; ответы модели: ДА {yes}, НЕТ {no}, прочее {6 - yes - no}")
    if not passes:
        total_wrong += 6
        total_wrong_said_yes += yes
print(f"на неверных вариантах модель-ревьюер сказала «ДА» в {total_wrong_said_yes} из {total_wrong} проверок")
