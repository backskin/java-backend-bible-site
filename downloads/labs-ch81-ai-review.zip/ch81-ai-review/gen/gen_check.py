"""Проверка кода, сгенерированного локальной моделью: N попыток, компиляция javac, проверка на таблице случаев.
Запуск: python gen_check.py [N] [температура]"""
import json
import os
import re
import subprocess
import sys
import urllib.request
from decimal import Decimal, ROUND_HALF_UP

BASE = "http://localhost:11434"
MODEL = "qwen2.5:1.5b"
N = int(sys.argv[1]) if len(sys.argv) > 1 else 10
TEMP = float(sys.argv[2]) if len(sys.argv) > 2 else 0.8
VARIANT = sys.argv[3] if len(sys.argv) > 3 else "plain"
WORK = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gen" if VARIANT == "plain" else "gen-" + VARIANT)
os.makedirs(WORK, exist_ok=True)

PROMPT = """Напиши на Java 21 класс Fee с одним методом:
public static long feeMinor(long amountMinor, int bps)
Метод возвращает комиссию в копейках: amountMinor * bps / 10000, округление до целой копейки по правилу HALF_UP
(половина копейки округляется вверх). Деньги нельзя хранить в double. Ответь только кодом класса, без пояснений."""

PROMPT_FRAMED = PROMPT + """
Формула: fee = amountMinor * bps / 10000, где bps — базисные пункты (100 bps = 1 %).
Примеры (amountMinor, bps -> результат):
  150000, 150 -> 2250
  10000, 25 -> 25
  50, 100 -> 1   (0.5 копейки округляется вверх)
  5, 100 -> 0    (0.05 копейки округляется вниз)
Используй только long и BigInteger или BigDecimal, никаких double и float. Промежуточное произведение может быть больше long."""
if VARIANT == "framed":
    PROMPT = PROMPT_FRAMED

CASES = [(150000, 150), (1, 150), (10000, 25), (333, 150), (999999, 150), (50, 100), (5, 100), (0, 150)]


def expected(a, b):
    return int((Decimal(a) * b / Decimal(10000)).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def ask(seed):
    body = {"model": MODEL, "stream": False, "options": {"temperature": TEMP, "seed": seed, "num_predict": 400},
            "messages": [{"role": "user", "content": PROMPT}]}
    req = urllib.request.Request(BASE + "/api/chat", data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.load(r)["message"]["content"]


def extract(text):
    m = re.search(r"```(?:java)?\s*(.*?)```", text, re.S)
    return (m.group(1) if m else text).strip()


MAIN = """public class Check {
    public static void main(String[] a) {
        long[][] cases = {%s};
        int ok = 0;
        for (long[] c : cases) {
            long got;
            try { got = Fee.feeMinor(c[0], (int) c[1]); } catch (Throwable t) { System.out.println("EXC " + t); continue; }
            if (got == c[2]) ok++; else System.out.println("  случай " + c[0] + "/" + c[1] + ": ожидали " + c[2] + ", получили " + got);
        }
        System.out.println("OK " + ok + "/" + cases.length);
    }
}
"""

stats = {"compiled": 0, "all_ok": 0, "no_class": 0, "double": 0}
rows = []
cases_src = ", ".join("{%d, %d, %d}" % (a, b, expected(a, b)) for a, b in CASES)
for i in range(N):
    text = ask(1000 + i)
    code = extract(text)
    d = os.path.join(WORK, f"s{i}")
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "Fee.java"), "w", encoding="utf-8").write(code)
    open(os.path.join(d, "Check.java"), "w", encoding="utf-8").write(MAIN % cases_src)
    uses_double = bool(re.search(r"\b(double|float|Math\.round|Math\.floor)\b", code))
    stats["double"] += uses_double
    if "class Fee" not in code:
        stats["no_class"] += 1
        rows.append((i, "нет класса Fee", uses_double))
        continue
    c = subprocess.run(["javac", "-encoding", "UTF-8", "-d", d, os.path.join(d, "Fee.java"), os.path.join(d, "Check.java")], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if c.returncode != 0:
        first = (c.stderr.strip().splitlines() or ["?"])[0]
        rows.append((i, "не компилируется: " + first.split("Fee.java:")[-1][:90], uses_double))
        continue
    stats["compiled"] += 1
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8", "-cp", d, "Check"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
    last = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "?"
    if last == f"OK {len(CASES)}/{len(CASES)}":
        stats["all_ok"] += 1
    rows.append((i, "компилируется; " + last, uses_double))

print(f"модель {MODEL}, температура {TEMP}, попыток {N}")
for i, r, dbl in rows:
    print(f"  #{i}: {r}{'; использует double/float/Math.round' if dbl else ''}")
print(f"итого: компилируется {stats['compiled']}/{N}, проходит все {len(CASES)} случаев {stats['all_ok']}/{N}, без класса Fee {stats['no_class']}, double/float/Math.round в коде {stats['double']}/{N}")
