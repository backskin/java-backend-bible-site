public class Fee {

    public static long feeMinor(long amountMinor, int bps) {
        BigDecimal amount = BigDecimal.valueOf(amountMinor);
        int bpsInt = bps;
        int precision = bpsInt / 2;
        BigDecimal bpsFactor = BigDecimal.valueOf(bpsInt / 2).pow(precision, BigDecimal.ROUND_HALF_UP);
        return amount.multiply(bpsFactor).setScale(0, BigDecimal.ROUND_HALF_UP).longValue();
    }
}