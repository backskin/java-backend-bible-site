public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        BigInteger amountMinorBigInt = BigInteger.valueOf(amountMinor);
        BigInteger bpsBigInt = BigInteger.valueOf(bps);
        BigInteger one = BigInteger.TEN.pow(-4); // 1/10000

        BigInteger result = amountMinorBigInt.multiply(bpsBigInt);
        BigInteger half = one.shiftLeft(2); // 1/50000

        BigInteger rounded = result.add(half).shiftRight(4); // Half up

        return rounded.longValue();
    }
}