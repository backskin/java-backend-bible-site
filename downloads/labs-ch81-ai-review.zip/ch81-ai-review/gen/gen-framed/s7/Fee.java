public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        // Convert bps to long to avoid overflow
        int bpsLong = bps;
        if (bpsLong > 100000) {
            bpsLong = 100000;
        }
        long total = amountMinor * bpsLong / 10000;
        // Check for rounding up or down
        long halfUp = Math.floorMod(total, 10000) + 5000 / 10000;
        if (halfUp > 0.5) {
            return (long) Math.ceil(total);
        } else {
            return (long) Math.floor(total);
        }
    }
}