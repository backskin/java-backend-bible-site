public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        BigInteger base = BigInteger.valueOf(amountMinor);
        BigInteger rate = BigInteger.valueOf(bps);
        return base.multiply(rate).divide(BigInteger.valueOf(10000), 0, RoundingMode.HALF_UP).longValue();
    }
}