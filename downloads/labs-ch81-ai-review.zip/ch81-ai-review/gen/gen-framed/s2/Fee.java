import java.math.BigDecimal;
import java.math.RoundingMode;

public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        long multiplier = BigDecimal.valueOf(bps / 100).multiply(BigDecimal.TEN).longValue();
        BigDecimal amount = new BigDecimal(String.valueOf(amountMinor));
        BigDecimal bpsMultiplier = new BigDecimal(String.valueOf(multiplier));
        BigDecimal result = amount.multiply(bpsMultiplier);
        BigDecimal finalResult = result.setScale(2, RoundingMode.HALF_UP).longValue();
        return finalResult;
    }
}