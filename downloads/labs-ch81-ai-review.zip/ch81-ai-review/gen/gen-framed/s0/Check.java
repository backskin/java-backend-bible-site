public class Check {
    public static void main(String[] a) {
        long[][] cases = {{150000, 150, 2250}, {1, 150, 0}, {10000, 25, 25}, {333, 150, 5}, {999999, 150, 15000}, {50, 100, 1}, {5, 100, 0}, {0, 150, 0}};
        int ok = 0;
        for (long[] c : cases) {
            long got;
            try { got = Fee.feeMinor(c[0], (int) c[1]); } catch (Throwable t) { System.out.println("EXC " + t); continue; }
            if (got == c[2]) ok++; else System.out.println("  случай " + c[0] + "/" + c[1] + ": ожидали " + c[2] + ", получили " + got);
        }
        System.out.println("OK " + ok + "/" + cases.length);
    }
}
