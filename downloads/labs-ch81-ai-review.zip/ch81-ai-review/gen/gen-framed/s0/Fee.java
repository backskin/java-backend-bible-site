public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        BigDecimal amount = BigDecimal.valueOf(amountMinor);
        int basePps = bps;
        BigDecimal pps = BigDecimal.valueOf(basePps);
        BigDecimal fee = amount.multiply(pps).divide(BigDecimal.valueOf(10000), BigDecimal.RoundingMode.HALF_UP);
        return fee.longValue();
    }
}