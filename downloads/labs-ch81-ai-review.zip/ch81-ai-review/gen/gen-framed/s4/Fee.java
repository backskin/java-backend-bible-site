import java.math.BigInteger;

public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        BigInteger bigDecimalAmountMinor = BigInteger.valueOf(amountMinor);
        BigInteger bigDecimalBps = BigInteger.valueOf(bps);
        BigInteger bigDecimalProduct = bigDecimalAmountMinor.multiply(bigDecimalBps);
        BigInteger bigDecimalDivisor = BigInteger.TEN.pow(5); // 10000
        BigInteger bigDecimalResult = bigDecimalProduct.divide(bigDecimalDivisor, 0, BigDecimal.ROUND_HALF_UP);
        return bigDecimalResult.longValue();
    }
}