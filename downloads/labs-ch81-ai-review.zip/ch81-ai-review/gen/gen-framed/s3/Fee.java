import java.math.BigDecimal;
import java.math.RoundingMode;

public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        BigDecimal amount = BigDecimal.valueOf(amountMinor);
        BigDecimal bpsDecimal = BigDecimal.valueOf(bps);
        BigDecimal fee = amount.multiply(bpsDecimal.divide(new BigDecimal("10000"), BigDecimal.ROUND_HALF_UP));
        return fee.longValue();
    }
}