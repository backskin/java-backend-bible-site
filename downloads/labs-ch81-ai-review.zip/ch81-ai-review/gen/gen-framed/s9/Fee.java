import java.math.BigInteger;

public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        BigInteger bigAmountMinor = BigInteger.valueOf(amountMinor);
        BigInteger bigBps = BigInteger.valueOf(bps);
        BigInteger result = bigAmountMinor.multiply(bigBps).divide(BigInteger.valueOf(10000));
        return result.longValue();
    }
}