public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        long product = amountMinor * bps;
        BigDecimal result = new BigDecimal(product);
        BigDecimal oneHundred = new BigDecimal(100);
        BigDecimal oneHundredThousand = new BigDecimal(10000);
        BigDecimal fraction = result.remainder(oneHundredThousand);
        BigDecimal integerPart = result.divide(oneHundredThousand, 0, RoundingMode.CEILING);
        BigDecimal fractionPart = result.remainder(oneHundred, 1);
        BigDecimal finalFee = integerPart.add(fractionPart.divide(oneHundred, 0, RoundingMode.HALF_UP));
        return finalFee.longValue();
    }
}