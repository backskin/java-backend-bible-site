public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        return (long) Math.round((double) (amountMinor * bps / 10000 + 0.5) / 0.0001);
    }
}