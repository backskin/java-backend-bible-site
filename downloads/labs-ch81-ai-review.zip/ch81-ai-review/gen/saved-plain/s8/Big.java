public class Big {
    public static void main(String[] x) {
        System.out.println("получили " + Fee.feeMinor(295084633758660L, 250) + ", ожидали 7377115843967");
        System.out.println("получили " + Fee.feeMinor(765376603761250L, 100) + ", ожидали 7653766037613");
    }
}
