public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        return (long) Math.floor((amountMinor * bps / 10000) + 0.5f);
    }
}