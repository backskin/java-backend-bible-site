public class Fee {

    public static long feeMinor(long amountMinor, int bps) {
        return Math.round((double) amountMinor * bps / 10000 + 0.5);
    }
}