public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        long fee = amountMinor * (long) bps / 10000;
        return Math.floorMod(fee, 100);
    }
}