import java.math.BigDecimal;
import java.math.RoundingMode;

public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        BigDecimal amount = BigDecimal.valueOf(amountMinor);
        BigDecimal bpsBigDecimal = BigDecimal.valueOf(bps);
        BigDecimal amountMinorWithBps = amount.multiply(bpsBigDecimal.divide(BigDecimal.valueOf(100), BigDecimal.ROUND_HALF_UP));
        BigDecimal fee = amountMinorWithBps.subtract(amount);
        return fee.longValue();
    }
}