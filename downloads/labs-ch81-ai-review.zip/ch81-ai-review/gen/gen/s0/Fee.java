public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        return (long) Math.round((double) (amountMinor * bps / 10000d) * 100.0d) / 100.0d;
    }
}