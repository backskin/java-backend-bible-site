public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        return (long) (amountMinor * bps / 10000);
    }
}