import java.math.BigDecimal;
import java.math.RoundingMode;

public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        double amount = amountMinor * (double) bps / 10000;
        BigDecimal bigDecimal = new BigDecimal(amount).setScale(2, RoundingMode.HALF_UP);
        long roundedAmount = bigDecimal.longValue();
        return roundedAmount;
    }
}