import java.math.BigDecimal;
import java.math.RoundingMode;

public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        return BigDecimal.valueOf(amountMinor)
                .setScale(2, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(bps))
                .longValue();
    }
}