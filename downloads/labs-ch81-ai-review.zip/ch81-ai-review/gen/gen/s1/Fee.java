public class Fee {
    public static long feeMinor(long amountMinor, int bps) {
        return (long) Math.ceil(amountMinor * bps / 10000f);
    }
}