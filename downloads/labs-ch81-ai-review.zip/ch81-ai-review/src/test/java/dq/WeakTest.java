package dq;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Тесты в стиле «от ИИ»: вызывают каждый метод, поэтому покрытие строк почти полное, но почти ничего не проверяют. */
class WeakTest {

    private final PaymentService service = new PaymentService();

    @Test
    void feeIsCalculated() {
        assertNotNull(service.fee(100.0));
    }

    @Test
    void sameCurrency() {
        assertTrue(service.isSameCurrency("RUB", "RUB"));      // зелёный из-за интернирования литералов; в проде строки приходят из JSON
    }

    @Test
    void notifyUserDoesNotFail() {
        service.notifyUser("u-1", "привет");
        service.notifyUser(null, "привет");                    // исключение проглочено, тест «зелёный»
    }

    @Test
    void maskIsCalculated() {
        assertNotNull(service.mask("1234567890123456"));
    }

    @Test
    void passwordIsSet() {
        assertNotNull(service.password());
    }
}
