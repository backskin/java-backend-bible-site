package dq;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Тесты после ревью: проверяют точные значения, границы и поведение при ошибке. */
class StrongTest {

    private final PaymentServiceFixed service = new PaymentServiceFixed();

    @Test
    void feeIsExactAndRoundedHalfUp() {
        assertEquals(new BigDecimal("1.50"), service.fee(new BigDecimal("100.00")));
        assertEquals(new BigDecimal("0.02"), service.fee(new BigDecimal("1.00")));      // 0,015 округляется вверх
        assertEquals(new BigDecimal("0.00"), service.fee(new BigDecimal("0.00")));
        assertThrows(NullPointerException.class, () -> service.fee(null));
    }

    @Test
    void currencyIsComparedByValue() {
        assertTrue(service.isSameCurrency(new String("RUB"), "RUB"));                   // в черновике здесь false
        assertFalse(service.isSameCurrency("RUB", "USD"));
        assertTrue(service.isSameCurrency(null, null));
        assertFalse(service.isSameCurrency(null, "RUB"));
    }

    @Test
    void notifyReportsFailureInsteadOfSwallowingIt() {
        assertTrue(service.notifyUser("u-1", "привет"));
        assertFalse(service.notifyUser(null, "привет"));
    }

    @Test
    void maskShowsLastFourDigitsAndRejectsShortInput() {
        assertEquals("****3456", service.mask("1234567890123456"));
        assertEquals("****1234", service.mask("1234"));
        assertThrows(IllegalArgumentException.class, () -> service.mask("123"));
        assertThrows(IllegalArgumentException.class, () -> service.mask(null));
    }
}
