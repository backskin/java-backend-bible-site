package dq;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Тот же класс после ревью: каждый дефект черновика исправлен, а поведение закреплено тестами, которые падают на сломанном коде. */
public class PaymentServiceFixed {

    private static final Logger LOG = Logger.getLogger(PaymentServiceFixed.class.getName());
    private static final BigDecimal FEE_RATE = new BigDecimal("0.015");

    /** Комиссия 1,5 % с округлением до копеек (HALF_UP). Сумма передаётся в виде BigDecimal. */
    public BigDecimal fee(BigDecimal amount) {
        Objects.requireNonNull(amount, "amount");
        return amount.multiply(FEE_RATE).setScale(2, RoundingMode.HALF_UP);
    }

    public boolean isSameCurrency(String a, String b) {
        return Objects.equals(a, b);
    }

    /** Ошибка отправки не должна ломать основную операцию, но обязана быть записана в журнал. */
    public boolean notifyUser(String userId, String text) {
        try {
            send(userId, text);
            return true;
        } catch (RuntimeException e) {
            LOG.log(Level.WARNING, "не удалось отправить уведомление пользователю " + clean(userId), e);
            return false;
        }
    }

    public List<String> findPayments(Connection connection, String payer) throws SQLException {
        List<String> ids = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("select id from payments where payer = ?")) {
            statement.setString(1, payer);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) ids.add(rs.getString(1));
            }
        }
        return ids;
    }

    public String mask(String card) {
        if (card == null || card.length() < 4) throw new IllegalArgumentException("номер карты слишком короткий");
        return "****" + card.substring(card.length() - 4);
    }

    /** Значение из внешнего источника нельзя писать в журнал как есть: переводы строк позволяют подделать соседние записи. */
    private static String clean(String value) {
        return value == null ? "null" : value.replaceAll("[\r\n]", "_");
    }

    void send(String userId, String text) {
        if (userId == null) throw new IllegalArgumentException("userId");
    }
}
