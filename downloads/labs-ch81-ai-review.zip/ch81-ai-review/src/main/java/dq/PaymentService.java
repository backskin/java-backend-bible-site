package dq;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Черновик «от ИИ»: компилируется, выглядит разумно и сопровождается тестами с полным покрытием строк,
 * но содержит пять типичных дефектов. Нужен только для демонстрации контрольных точек качества.
 */
public class PaymentService {

    private static final String DB_PASSWORD = "admin123";                                  // дефект 1: секрет в коде

    /** Комиссия 1,5 % от суммы платежа. */
    public BigDecimal fee(double amount) {
        return new BigDecimal(amount).multiply(new BigDecimal(0.015));                    // дефект 2: BigDecimal из double, нет округления
    }

    public boolean isSameCurrency(String a, String b) {
        return a == b;                                                                    // дефект 3: сравнение строк по ссылке
    }

    public void notifyUser(String userId, String text) {
        try {
            send(userId, text);
        } catch (Exception e) {
            // дефект 4: исключение проглочено, ошибка отправки исчезает бесследно
        }
    }

    public ResultSet findPayments(Connection connection, String payer) throws SQLException {
        Statement statement = connection.createStatement();
        return statement.executeQuery("select * from payments where payer = '" + payer + "'");   // дефект 5: SQL-инъекция и незакрытый ресурс
    }

    public String mask(String card) {
        return "****" + card.substring(card.length() - 4);                                // падает на null и на короткой строке
    }

    void send(String userId, String text) {
        if (userId == null) throw new IllegalArgumentException("userId");
    }

    String password() {
        return DB_PASSWORD;
    }
}
