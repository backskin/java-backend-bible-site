# Spring MVC на Spring Boot 4.1: путь запроса, фильтры, ошибки RFC 9457, валидация, Jackson 3, multipart, асинхронность, HTTP-клиенты

Стенд к главе 14. `WebLab` с контроллерами из `Api.java` (Spring Boot 4.1.1, Framework 7.0.9, Tomcat 11.0.24, Jackson 3.1.5, Hibernate Validator 9.1.3) поднимает приложение и по очереди проверяет утверждения главы: параметры Tomcat по умолчанию, порядок фильтров, ответы на несуществующий путь и без параметра, `Optional` в контроллере, `application/problem+json`, валидация, настройки Jackson, multipart, `DeferredResult` с тайм-аутом 30 с, виртуальные потоки в Tomcat, фабрики `RestClient` при HC5 и Reactor Netty (профиль Maven `hc5`). `jackson-plain/PlainDefaults.java` - значения Jackson 3 без Spring; `s14-starters.txt` - проверка описаний стартеров в Maven Central. Выводы автора - `s14-mvc.txt`, `s14-factories.txt`, `s14-jackson-plain.txt`, `s14-starters.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile exec:java -Dexec.mainClass=dev.team.web.WebLab
```

С Apache HttpClient 5 в classpath: `mvn -q -P hc5 compile exec:java -Dexec.mainClass=dev.team.web.WebLab`. В IDEA есть конфигурация `WebLab`.

## Что должно получиться

У коннектора Tomcat `connectionTimeout = 60000`, а не 20 с из книги Витале; бин Jackson в Boot 4.1 называется `jacksonJsonMapper` класса `tools.jackson.databind.json.JsonMapper`; `GET /api/deferred` отвечает 503 через 30,9 с; с `spring.threads.virtual.enabled=true` исполнитель коннектора - `VirtualThreadExecutor` и `maxThreads = -1`.
