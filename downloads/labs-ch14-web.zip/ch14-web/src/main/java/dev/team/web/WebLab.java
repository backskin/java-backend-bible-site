package dev.team.web;

import java.lang.reflect.Field;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootVersion;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.SpringVersion;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * Гл. 14: прогон проверок Spring MVC. Поднимает приложение на случайном порту трижды
 * (по умолчанию; с ProblemDetail и виртуальными потоками; с тайм-аутами HTTP-клиента)
 * и печатает, что вернул сервер. Вывод — s14-mvc.txt.
 */
@SpringBootApplication
public class WebLab {
    static final HttpClient HTTP = HttpClient.newHttpClient();
    static String base;

    public static void main(String[] args) throws Exception {
        System.out.println("spring-boot " + SpringBootVersion.getVersion() + ", spring-framework " + SpringVersion.getVersion()
                + ", tomcat " + org.apache.catalina.util.ServerInfo.getServerNumber()
                + ", jackson " + tools.jackson.databind.cfg.PackageVersion.VERSION + ", java " + System.getProperty("java.version"));

        if ("factories".equals(System.getProperty("lab.only"))) {
            try (var ctx = start(Map.of())) {
                section("9. Фабрики запросов при текущем classpath (" + System.getProperty("lab.classpath", "-") + ")");
                clients(ctx);
            }
            return;
        }
        try (var ctx = start(Map.of())) {
            section("Контекст по умолчанию");
            tomcatDefaults(ctx);
            filterChain(ctx);
            jacksonBeans(ctx);

            section("2. Возврат Optional.empty() из @ResponseBody-метода");
            show(get("/api/payments/0"));
            section("2. Точка в переменной пути и завершающая косая черта");
            show(get("/files/report.2026.pdf"));
            show(get("/api/limits/"));
            section("2. Нет обязательного @RequestParam");
            show(get("/api/report"));
            section("2. consumes/produces: 415 и 406");
            show(send("POST", "/api/payments", "text/plain", null, "{\"account\":\"a\",\"amount\":1}"));
            show(send("GET", "/api/payments/7", null, "application/xml", null));

            section("3. Порядок фильтров и перехватчика: обычный запрос");
            traced(get("/api/payments/7"));
            section("3. То же, обработчик бросил необработанное исключение");
            traced(get("/api/boom"));
            section("3. То же, исключение обработано @ExceptionHandler");
            traced(get("/api/limit-exceeded"));

            section("4. Ошибка без ProblemDetail (spring.mvc.problemdetails.enabled не задано)");
            show(get("/nope"));
            show(json("/api/payments", "{\"account\":\"\",\"amount\":-5,\"priority\":1}"));

            section("5. Валидация параметров метода (Framework 7, встроенная проверка)");
            show(get("/api/accounts/-1"));
            section("5. Тот же параметр в контроллере с @Validated на классе (AOP-прокси)");
            show(get("/strict/accounts/-1"));

            section("6. Jackson 3: незнакомое поле, null в примитив, мусор после объекта, формат дат");
            show(json("/api/payments", "{\"account\":\"40817\",\"amount\":10,\"priority\":1,\"comment\":\"x\"}"));
            show(json("/api/payments", "{\"account\":\"40817\",\"amount\":10,\"priority\":null}"));
            show(json("/api/payments", "{\"account\":\"40817\",\"amount\":10}"));
            show(json("/api/payments", "{\"account\":\"40817\",\"amount\":10,\"priority\":1} {\"x\":1}"));
            show(get("/api/snapshot"));

            section("7. Multipart: файл 2 МБ при лимитах по умолчанию");
            show(multipart("/api/upload", 2 * 1024 * 1024));

            section("Servlet 6.1 / Tomcat 11: HTTP/2 server push");
            show(get("/api/push"));

            section("8. DeferredResult без тайм-аута: сколько ждёт Tomcat");
            long t0 = System.nanoTime();
            var r = get("/api/deferred");
            System.out.printf("   через %.1f с: %s%n", (System.nanoTime() - t0) / 1e9, brief(r));

            section("9. HTTP-клиенты: фабрики запросов и тайм-ауты по умолчанию");
            clients(ctx);
        }

        try (var ctx = start(Map.of("spring.mvc.problemdetails.enabled", "true", "spring.threads.virtual.enabled", "true"))) {
            section("4. Ошибки с spring.mvc.problemdetails.enabled=true");
            show(get("/nope"));
            show(json("/api/payments", "{\"account\":\"\",\"amount\":-5,\"priority\":1}"));
            show(get("/api/limit-exceeded"));
            show(get("/api/boom"));
            section("8. spring.threads.virtual.enabled=true: поток обработчика");
            show(get("/api/thread"));
            tomcatDefaults(ctx);
        }

        for (String prop : new String[] {"server.error.include-message", "spring.web.error.include-message"}) {
            try (var ctx = start(Map.of(prop, "always"))) {
                section("4. " + prop + "=always: тело ответа на необработанное исключение");
                show(get("/api/boom"));
            }
        }

        try (var ctx = start(Map.of("spring.http.clients.read-timeout", "1s", "spring.http.clients.connect-timeout", "500ms"))) {
            section("9. RestClient из RestClient.Builder Boot при spring.http.clients.read-timeout=1s");
            RestClient rc = ctx.getBean(RestClient.Builder.class).baseUrl(base).build();
            System.out.println("   фабрика: " + describeFactory(field(rc, "clientRequestFactory")));
            long t1 = System.nanoTime();
            try {
                rc.get().uri("/api/slow?ms=3000").retrieve().body(String.class);
                System.out.println("   ответ получен");
            } catch (Exception e) {
                System.out.printf("   через %.2f с: %s / причина %s%n", (System.nanoTime() - t1) / 1e9, e.getClass().getName(),
                        e.getCause() == null ? "-" : e.getCause().getClass().getName());
            }
        }
    }

    static ConfigurableApplicationContext start(Map<String, Object> extra) {
        var app = new SpringApplication(WebLab.class);
        Map<String, Object> p = new HashMap<>(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        p.putAll(extra);
        app.setDefaultProperties(p);
        var ctx = app.run();
        base = "http://127.0.0.1:" + ctx.getEnvironment().getProperty("local.server.port");
        return ctx;
    }

    static void section(String s) { System.out.println("== " + s); }

    static void tomcatDefaults(ConfigurableApplicationContext ctx) throws Exception {
        Object server = ctx.getClass().getMethod("getWebServer").invoke(ctx);
        Object tomcat = server.getClass().getMethod("getTomcat").invoke(server);
        var connector = (org.apache.catalina.connector.Connector) tomcat.getClass().getMethod("getConnector").invoke(tomcat);
        System.out.println("   Tomcat connector: " + connector.getProtocolHandlerClassName());
        for (String k : new String[] {"connectionTimeout", "keepAliveTimeout", "maxThreads", "minSpareThreads", "acceptCount", "maxConnections", "maxKeepAliveRequests", "useVirtualThreads"})
            System.out.println("     " + k + " = " + connector.getProperty(k));
        System.out.println("     executor = " + connector.getProtocolHandler().getExecutor().getClass().getName());
    }

    static void filterChain(ConfigurableApplicationContext ctx) throws Exception {
        Object server = ctx.getClass().getMethod("getWebServer").invoke(ctx);
        var tomcat = (org.apache.catalina.startup.Tomcat) server.getClass().getMethod("getTomcat").invoke(server);
        var context = (org.apache.catalina.Context) tomcat.getHost().findChildren()[0];
        System.out.println("   Фильтры в порядке цепочки Tomcat (имя → класс, порядок бина, типы диспетчеризации):");
        for (var fm : context.findFilterMaps()) {
            var def = context.findFilterDef(fm.getFilterName());
            String cls = def == null ? "?" : def.getFilterClass();
            String order = "-";
            if (def != null && def.getFilter() instanceof org.springframework.core.Ordered o) order = String.valueOf(o.getOrder());
            else if (def != null && def.getFilter() != null) {
                var ann = org.springframework.core.annotation.AnnotationUtils.findAnnotation(def.getFilter().getClass(), org.springframework.core.annotation.Order.class);
                if (ann != null) order = "@Order(" + ann.value() + ")";
            }
            System.out.println("     " + fm.getFilterName() + " → " + cls.substring(cls.lastIndexOf('.') + 1) + ", order " + order + ", " + fm.getDispatcherNames().length + " типа: " + String.join(",", fm.getDispatcherNames()));
        }
    }

    static void jacksonBeans(ConfigurableApplicationContext ctx) {
        System.out.println("   бины tools.jackson.databind.ObjectMapper: " + String.join(", ", ctx.getBeanNamesForType(tools.jackson.databind.ObjectMapper.class))
                + " (" + ctx.getBean(tools.jackson.databind.ObjectMapper.class).getClass().getName() + ")");
        boolean jackson2;
        try { Class.forName("com.fasterxml.jackson.databind.ObjectMapper"); jackson2 = true; } catch (ClassNotFoundException e) { jackson2 = false; }
        System.out.println("   com.fasterxml.jackson.databind.ObjectMapper в classpath: " + jackson2);
        var m = ctx.getBean(tools.jackson.databind.ObjectMapper.class);
        var dc = m.deserializationConfig();
        for (var f : new tools.jackson.databind.DeserializationFeature[] {
                tools.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
                tools.jackson.databind.DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES,
                tools.jackson.databind.DeserializationFeature.FAIL_ON_TRAILING_TOKENS})
            System.out.println("     " + f + " = " + dc.isEnabled(f));
        System.out.println("     WRITE_DATES_AS_TIMESTAMPS = " + m.serializationConfig().isEnabled(tools.jackson.databind.cfg.DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS));
    }

    static void clients(ConfigurableApplicationContext ctx) throws Exception {
        RestTemplate rt = new RestTemplate();
        System.out.println("   new RestTemplate(): " + describeFactory(rt.getRequestFactory()));
        System.out.println("   RestTemplate @Deprecated: " + RestTemplate.class.getAnnotation(Deprecated.class));
        RestClient plain = RestClient.create();
        System.out.println("   RestClient.create(): " + describeFactory(field(plain, "clientRequestFactory")));
        RestClient boot = ctx.getBean(RestClient.Builder.class).build();
        System.out.println("   RestClient.Builder из Boot: " + describeFactory(field(boot, "clientRequestFactory")));
        RestClient rc = RestClient.create(base);
        int before = rc.get().uri("/api/hits").retrieve().body(Integer.class);
        rc.post().uri("/api/hits").retrieve();
        Thread.sleep(300);
        int afterRetrieveOnly = rc.get().uri("/api/hits").retrieve().body(Integer.class);
        rc.post().uri("/api/hits").retrieve().toBodilessEntity();
        int afterTerminal = rc.get().uri("/api/hits").retrieve().body(Integer.class);
        System.out.println("   post().retrieve() без терминальной операции: счётчик на сервере " + before + " → " + afterRetrieveOnly
                + "; с toBodilessEntity(): → " + afterTerminal);
    }

    static String describeFactory(Object f) throws Exception {
        StringBuilder sb = new StringBuilder(f.getClass().getSimpleName());
        for (String n : new String[] {"connectTimeout", "readTimeout"}) {
            try { sb.append(", ").append(n).append("=").append(field(f, n)); } catch (NoSuchFieldException ignored) { }
        }
        try {
            Object hc = field(f, "httpClient");
            if (hc instanceof HttpClient jdk) sb.append(", HttpClient.connectTimeout=").append(jdk.connectTimeout());
        } catch (NoSuchFieldException ignored) { }
        return sb.toString();
    }

    static Object field(Object o, String name) throws Exception {
        for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
            try { Field f = c.getDeclaredField(name); f.setAccessible(true); return f.get(o); } catch (NoSuchFieldException ignored) { }
        }
        throw new NoSuchFieldException(name);
    }

    static HttpResponse<String> get(String path) throws Exception { return send("GET", path, null, null, null); }

    static HttpResponse<String> json(String path, String body) throws Exception { return send("POST", path, "application/json", null, body); }

    static HttpResponse<String> send(String method, String path, String contentType, String accept, String body) throws Exception {
        var b = HttpRequest.newBuilder(URI.create(base + path)).timeout(Duration.ofSeconds(90))
                .method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body));
        if (contentType != null) b.header("Content-Type", contentType);
        if (accept != null) b.header("Accept", accept);
        Trace.EVENTS.clear();
        return HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString());
    }

    static HttpResponse<String> multipart(String path, int size) throws Exception {
        String boundary = "dev-team-boundary";
        byte[] head = ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"registry.csv\"\r\nContent-Type: text/csv\r\n\r\n").getBytes();
        byte[] tail = ("\r\n--" + boundary + "--\r\n").getBytes();
        byte[] all = new byte[head.length + size + tail.length];
        System.arraycopy(head, 0, all, 0, head.length);
        java.util.Arrays.fill(all, head.length, head.length + size, (byte) 'x');
        System.arraycopy(tail, 0, all, head.length + size, tail.length);
        var req = HttpRequest.newBuilder(URI.create(base + path)).header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(all)).build();
        return HTTP.send(req, HttpResponse.BodyHandlers.ofString());
    }

    static String brief(HttpResponse<String> r) {
        String ct = r.headers().firstValue("Content-Type").orElse("-");
        String body = r.body().length() > 400 ? r.body().substring(0, 400) + "…" : r.body();
        return r.request().method() + " " + r.uri().getPath() + " → " + r.statusCode() + " [" + ct + "] " + (body.isEmpty() ? "(пустое тело)" : body);
    }

    static void show(HttpResponse<String> r) { System.out.println("   " + brief(r)); }

    static void traced(HttpResponse<String> r) throws InterruptedException {
        Thread.sleep(200);
        show(r);
        for (String e : Trace.EVENTS) System.out.println("     · " + e);
    }
}
