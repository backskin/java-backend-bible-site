package dev.team.web;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/** Журнал событий одного запроса: фильтры, перехватчик, контроллер, обработчик ошибок. */
final class Trace {
    static final List<String> EVENTS = new CopyOnWriteArrayList<>();
    static void add(String e) { EVENTS.add(e); }
}

record Payment(long id, String account, BigDecimal amount) {}

record PaymentRequest(@NotBlank String account, @Positive BigDecimal amount, int priority) {}

record Snapshot(Instant at, LocalDate day, BigDecimal amount, Optional<String> note) {}

class LimitExceededException extends RuntimeException {
    LimitExceededException(String m) { super(m); }
}

@RestController
@RequestMapping("/api")
class PaymentController {
    @GetMapping("/payments/{id}")
    Optional<Payment> payment(@PathVariable long id) {
        Trace.add("controller");
        return id == 0 ? Optional.empty() : Optional.of(new Payment(id, "40817810000000000001", new BigDecimal("100.00")));
    }

    @PostMapping(path = "/payments", consumes = MediaType.APPLICATION_JSON_VALUE)
    PaymentRequest create(@Valid @RequestBody PaymentRequest r) { return r; }

    @GetMapping("/limits")
    String limits() { return "ok"; }

    @GetMapping("/report")
    String report(@RequestParam String from) { return from; }

    @GetMapping("/accounts/{id}")
    String account(@PathVariable @Positive long id) { return "account " + id; }

    @GetMapping("/boom")
    String boom() { Trace.add("controller"); throw new IllegalStateException("ledger offline"); }

    @GetMapping("/limit-exceeded")
    String limit() { Trace.add("controller"); throw new LimitExceededException("Дневной лимит 100000.00 RUB исчерпан"); }

    @GetMapping("/slow")
    String slow(@RequestParam long ms) throws InterruptedException { Thread.sleep(ms); return "slow " + ms; }

    @GetMapping("/deferred")
    DeferredResult<String> deferred() { return new DeferredResult<>(); }

    @PostMapping("/upload")
    String upload(@RequestParam MultipartFile file) { return "size " + file.getSize(); }

    @GetMapping("/push")
    String push(HttpServletRequest req) { return "newPushBuilder() = " + req.newPushBuilder(); }

    @GetMapping("/snapshot")
    Snapshot snapshot() {
        return new Snapshot(Instant.parse("2026-11-02T09:30:00Z"), LocalDate.of(2026, 11, 2), new BigDecimal("1500.10"), Optional.empty());
    }

    static final java.util.concurrent.atomic.AtomicInteger HITS = new java.util.concurrent.atomic.AtomicInteger();

    @GetMapping("/hits")
    int hits() { return HITS.get(); }

    @PostMapping("/hits")
    void hit() { HITS.incrementAndGet(); }

    @GetMapping("/thread")
    String thread() { return Thread.currentThread().toString(); }
}

@RestController
class FileController {
    @GetMapping("/files/{name}")
    String file(@PathVariable String name) { return name; }
}

@Validated
@RestController
@RequestMapping("/strict")
class StrictController {
    @GetMapping("/accounts/{id}")
    String account(@PathVariable @Positive long id) { return "account " + id; }
}

@RestControllerAdvice
class ApiErrors {
    @ExceptionHandler(LimitExceededException.class)
    ProblemDetail limit(LimitExceededException ex) {
        Trace.add("exceptionHandler");
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_CONTENT, ex.getMessage());
        pd.setType(URI.create("https://api.tundra.example/problems/limit-exceeded"));
        pd.setTitle("Limit exceeded");
        return pd;
    }
}

@Component
@Order(1)
class OnceFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws ServletException, IOException {
        Trace.add("onceFilter.before " + req.getDispatcherType() + " " + req.getRequestURI());
        try { chain.doFilter(req, res); }
        finally { Trace.add("onceFilter.after " + req.getDispatcherType() + " status=" + res.getStatus()); }
    }
}

@Component
@Order(2)
class PlainFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        var r = (HttpServletRequest) req;
        Trace.add("plainFilter " + r.getDispatcherType() + " " + r.getRequestURI());
        chain.doFilter(req, res);
    }
}

@Component
class Interceptors implements WebMvcConfigurer, HandlerInterceptor {
    @Override public void addInterceptors(InterceptorRegistry registry) { registry.addInterceptor(this).addPathPatterns("/api/**"); }
    @Override public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) {
        Trace.add("interceptor.preHandle " + req.getDispatcherType()); return true;
    }
    @Override public void postHandle(HttpServletRequest req, HttpServletResponse res, Object handler, ModelAndView mav) {
        Trace.add("interceptor.postHandle committed=" + res.isCommitted());
    }
    @Override public void afterCompletion(HttpServletRequest req, HttpServletResponse res, Object handler, Exception ex) {
        Trace.add("interceptor.afterCompletion ex=" + (ex == null ? null : ex.getClass().getSimpleName()));
    }
}
