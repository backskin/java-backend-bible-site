import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;
/** Гл. 14, разд. 6: значения по умолчанию у JsonMapper.builder().build() без Spring Boot (Jackson 3.1.5). */
public class PlainDefaults {
    record Order(String id, int priority) {}
    public static void main(String[] a) throws Exception {
        var m = JsonMapper.builder().build();
        System.out.println("jackson " + tools.jackson.databind.cfg.PackageVersion.VERSION + ", JsonMapper.builder().build() без Boot:");
        for (var f : new DeserializationFeature[] {DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, DeserializationFeature.FAIL_ON_TRAILING_TOKENS})
            System.out.println("   " + f + " = " + m.deserializationConfig().isEnabled(f));
        System.out.println("   WRITE_DATES_AS_TIMESTAMPS = " + m.serializationConfig().isEnabled(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS));
        System.out.println("   Instant → " + m.writeValueAsString(java.time.Instant.parse("2026-11-02T09:30:00Z")));
        for (String json : new String[] {"{\"id\":\"p-1\",\"priority\":1,\"comment\":\"x\"}", "{\"id\":\"p-1\"}"}) {
            try { System.out.println("   " + json + " → " + m.readValue(json, Order.class)); }
            catch (Exception e) { System.out.println("   " + json + " → " + e.getClass().getSimpleName() + ": " + e.getMessage().lines().findFirst().orElse("")); }
        }
    }
}
