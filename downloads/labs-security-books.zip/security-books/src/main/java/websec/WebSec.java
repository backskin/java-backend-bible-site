package websec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SpringBootApplication
public class WebSec {

    @RestController
    static class Api {
        @PostMapping({"/stateless/pay", "/basic/pay", "/cors-off/pay", "/cors-on/pay", "/form/pay"})
        String pay() { return "платёж принят"; }

        @GetMapping("/form/token")
        String token(CsrfToken token) { return token.getToken(); }
    }

    @Configuration
    @EnableWebSecurity
    static class Config {
        @Bean
        UserDetailsService users() {
            return new InMemoryUserDetailsManager(User.withUsername("alice").password("{noop}pw").roles("USER").build());
        }

        @Bean
        CorsConfigurationSource corsConfigurationSource() {
            CorsConfiguration c = new CorsConfiguration();
            c.setAllowedOrigins(List.of("https://app.example.com"));
            c.setAllowedMethods(List.of("GET", "POST"));
            c.setAllowedHeaders(List.of("authorization", "content-type"));
            UrlBasedCorsConfigurationSource s = new UrlBasedCorsConfigurationSource();
            s.registerCorsConfiguration("/cors-on/**", c);
            return s;
        }

        @Bean @Order(1)
        SecurityFilterChain stateless(HttpSecurity http) throws Exception {
            return http.securityMatcher("/stateless/**")
                    .authorizeHttpRequests(a -> a.anyRequest().authenticated())
                    .httpBasic(Customizer.withDefaults())
                    .csrf(AbstractHttpConfigurer::disable)
                    .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .build();
        }

        @Bean @Order(2)
        SecurityFilterChain basicWithCsrf(HttpSecurity http) throws Exception {
            return http.securityMatcher("/basic/**")
                    .authorizeHttpRequests(a -> a.anyRequest().authenticated())
                    .httpBasic(Customizer.withDefaults())          // CSRF оставлен включённым
                    .build();
        }

        @Bean @Order(3)
        SecurityFilterChain corsOff(HttpSecurity http) throws Exception {
            return http.securityMatcher("/cors-off/**")
                    .authorizeHttpRequests(a -> a.anyRequest().authenticated())
                    .httpBasic(Customizer.withDefaults())
                    .csrf(AbstractHttpConfigurer::disable)
                    .build();
        }

        @Bean @Order(4)
        SecurityFilterChain corsOn(HttpSecurity http) throws Exception {
            return http.securityMatcher("/cors-on/**")
                    .authorizeHttpRequests(a -> a.anyRequest().authenticated())
                    .httpBasic(Customizer.withDefaults())
                    .cors(Customizer.withDefaults())
                    .csrf(AbstractHttpConfigurer::disable)
                    .build();
        }

        /** Браузерная часть: форма входа и сессия. Позволяет выключить защиту от фиксации сессии. */
        @Bean @Order(5)
        SecurityFilterChain form(HttpSecurity http, @Value("${fixation.none:false}") boolean noProtection) throws Exception {
            return http.authorizeHttpRequests(a -> a.requestMatchers("/error").permitAll().anyRequest().authenticated())
                    .formLogin(Customizer.withDefaults())
                    .sessionManagement(s -> { if (noProtection) s.sessionFixation(f -> f.none()); })
                    .build();
        }
    }

    // ------------------------------------------------------------------ клиент

    static final HttpClient HTTP = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).build();

    static String basic(String user) {
        return "Basic " + Base64.getEncoder().encodeToString((user + ":pw").getBytes(StandardCharsets.UTF_8));
    }

    static HttpResponse<String> send(HttpRequest.Builder b) throws Exception {
        return HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString());
    }

    static String sessionCookie(HttpResponse<?> r) {
        return r.headers().allValues("Set-Cookie").stream().filter(c -> c.startsWith("JSESSIONID="))
                .map(c -> c.substring(0, c.indexOf(';'))).findFirst().orElse(null);
    }

    static String sessionCookieFull(HttpResponse<?> r) {
        return r.headers().allValues("Set-Cookie").stream().filter(c -> c.startsWith("JSESSIONID=")).findFirst().orElse("нет");
    }

    static void line(String title, HttpResponse<?> r) {
        String acao = r.headers().firstValue("Access-Control-Allow-Origin").map(v -> ", Access-Control-Allow-Origin: " + v).orElse("");
        System.out.printf("%-62s -> HTTP %d%s%n", title, r.statusCode(), acao);
    }

    static String short8(String cookie) { return cookie == null ? "нет" : cookie.substring(0, Math.min(cookie.length(), 18)) + "..."; }

    static void run(String base, boolean showAll) throws Exception {
        if (showAll) {
            System.out.println("--- CSRF и способ аутентификации");
            line("Basic, цепочка с csrf.disable(): POST без токена",
                    send(HttpRequest.newBuilder(URI.create(base + "/stateless/pay")).POST(HttpRequest.BodyPublishers.noBody()).header("Authorization", basic("alice"))));
            line("Basic, CSRF включён: POST без токена",
                    send(HttpRequest.newBuilder(URI.create(base + "/basic/pay")).POST(HttpRequest.BodyPublishers.noBody()).header("Authorization", basic("alice"))));
        }

        // форма входа: GET /login создаёт сессию и отдаёт токен в скрытом поле
        HttpResponse<String> login = send(HttpRequest.newBuilder(URI.create(base + "/login")).GET());
        String before = sessionCookie(login);
        Matcher m = Pattern.compile("name=\"_csrf\" type=\"hidden\" value=\"([^\"]+)\"").matcher(login.body());
        m.find();
        String csrf = m.group(1);
        String body = "username=alice&password=pw&_csrf=" + URLEncoder.encode(csrf, StandardCharsets.UTF_8);
        HttpResponse<String> post = send(HttpRequest.newBuilder(URI.create(base + "/login"))
                .header("Content-Type", "application/x-www-form-urlencoded").header("Cookie", before)
                .POST(HttpRequest.BodyPublishers.ofString(body)));
        String after = sessionCookie(post);
        System.out.println("--- сессия и фиксация");
        System.out.println("cookie до входа:   " + short8(before) + ";  после входа: " + (after == null ? "не менялась (Set-Cookie нет)" : short8(after)));
        System.out.println("идентификатор сессии сменился: " + (after != null && !after.equals(before)));
        if (!showAll) return;
        System.out.println("Set-Cookie при создании сессии: " + sessionCookieFull(login).replaceAll("JSESSIONID=[^;]+", "JSESSIONID=..."));
        String cookie = after != null ? after : before;
        System.out.println("--- CSRF в браузерной цепочке (сессия после входа)");
        line("POST /form/pay с сессией, без токена",
                send(HttpRequest.newBuilder(URI.create(base + "/form/pay")).POST(HttpRequest.BodyPublishers.noBody()).header("Cookie", cookie)));
        HttpResponse<String> tok = send(HttpRequest.newBuilder(URI.create(base + "/form/token")).GET().header("Cookie", cookie));
        line("POST /form/pay с сессией и заголовком X-CSRF-TOKEN",
                send(HttpRequest.newBuilder(URI.create(base + "/form/pay")).POST(HttpRequest.BodyPublishers.noBody())
                        .header("Cookie", cookie).header("X-CSRF-TOKEN", tok.body())));
        line("POST /form/pay с сессией и токеном, выданным до входа",
                send(HttpRequest.newBuilder(URI.create(base + "/form/pay")).POST(HttpRequest.BodyPublishers.noBody())
                        .header("Cookie", cookie).header("X-CSRF-TOKEN", csrf)));

        System.out.println("--- CORS: предварительный запрос (preflight) без учётных данных");
        for (String path : new String[]{"/cors-off/pay", "/cors-on/pay"}) {
            line("OPTIONS " + path + ", Origin: https://app.example.com",
                    send(HttpRequest.newBuilder(URI.create(base + path)).method("OPTIONS", HttpRequest.BodyPublishers.noBody())
                            .header("Origin", "https://app.example.com")
                            .header("Access-Control-Request-Method", "POST")
                            .header("Access-Control-Request-Headers", "authorization,content-type")));
        }
    }

    public static void main(String[] args) throws Exception {
        Map<String, Object> props = Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off");
        SpringApplication app = new SpringApplication(WebSec.class);
        app.setDefaultProperties(props);
        try (ConfigurableApplicationContext ctx = app.run(args)) {
            run("http://localhost:" + ctx.getEnvironment().getProperty("local.server.port"), true);
        }
        System.out.println("=== sessionFixation().none()");
        SpringApplication none = new SpringApplication(WebSec.class);
        none.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off", "fixation.none", "true"));
        try (ConfigurableApplicationContext ctx = none.run(args)) {
            run("http://localhost:" + ctx.getEnvironment().getProperty("local.server.port"), false);
        }
    }
}
