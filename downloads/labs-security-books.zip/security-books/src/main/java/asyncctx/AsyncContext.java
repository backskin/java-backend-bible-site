package asyncctx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.task.DelegatingSecurityContextAsyncTaskExecutor;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@SpringBootApplication
public class AsyncContext {

    @Configuration
    @EnableAsync
    static class Config {
        /** Обычный пул: контекст безопасности в рабочие потоки не передаётся. */
        @Bean("plain")
        Executor plain() { return pool("plain-"); }

        /** Тот же пул, обёрнутый так, что контекст копируется в задачу в момент отправки. */
        @Bean("propagating")
        Executor propagating() { return new DelegatingSecurityContextAsyncTaskExecutor(pool("prop-")); }
    }

    static ThreadPoolTaskExecutor pool(String prefix) {
        ThreadPoolTaskExecutor e = new ThreadPoolTaskExecutor();
        e.setCorePoolSize(1);                       // один рабочий поток: наглядно видно переиспользование
        e.setMaxPoolSize(1);
        e.setThreadNamePrefix(prefix);
        e.initialize();
        return e;
    }

    static String who() {
        Authentication a = SecurityContextHolder.getContext().getAuthentication();
        return (a == null ? "нет аутентификации" : a.getName()) + " (поток " + Thread.currentThread().getName() + ")";
    }

    @Service
    static class Worker {
        @Async("plain")
        public CompletableFuture<String> onPlainPool() { return CompletableFuture.completedFuture(who()); }

        @Async("propagating")
        public CompletableFuture<String> onPropagatingPool() { return CompletableFuture.completedFuture(who()); }
    }

    /** Как делает фильтр: кладёт в holder новый контекст. */
    static void login(String name) {
        SecurityContext ctx = SecurityContextHolder.createEmptyContext();
        ctx.setAuthentication(new UsernamePasswordAuthenticationToken(name, "n", AuthorityUtils.createAuthorityList("ROLE_USER")));
        SecurityContextHolder.setContext(ctx);
    }

    /** Меняет аутентификацию в уже существующем контексте. */
    static void loginInPlace(String name) {
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(name, "n", AuthorityUtils.createAuthorityList("ROLE_USER")));
    }

    static ThreadPoolTaskExecutor newInheritingPool(String prefix) {
        ThreadPoolTaskExecutor e = pool(prefix);        // пул создаётся после смены стратегии, поток появится при первой задаче
        return e;
    }

    public static void main(String[] args) throws Exception {
        try (ConfigurableApplicationContext ctx = new SpringApplication(AsyncContext.class).run(
                "--logging.level.root=OFF", "--spring.main.banner-mode=off", "--spring.main.web-application-type=none")) {
            Worker w = ctx.getBean(Worker.class);

            System.out.println("--- стратегия по умолчанию (ThreadLocal)");
            login("alice");
            System.out.println("в потоке запроса:             " + who());
            System.out.println("@Async, обычный пул:          " + w.onPlainPool().get());
            System.out.println("@Async, пул с передачей:      " + w.onPropagatingPool().get());
            login("bob");
            System.out.println("после смены на bob, с передачей: " + w.onPropagatingPool().get());
            SecurityContextHolder.clearContext();
            System.out.println("после clearContext, с передачей: " + w.onPropagatingPool().get());

            System.out.println("--- стратегия MODE_INHERITABLETHREADLOCAL, пул из одного потока");
            SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);
            ThreadPoolTaskExecutor p1 = newInheritingPool("inherit-");
            login("alice");
            System.out.println("первая задача (запрос от alice): " + p1.submit(AsyncContext::who).get());
            login("bob");                                   // фильтр кладёт в holder новый контекст
            System.out.println("вторая задача (запрос от bob):   " + p1.submit(AsyncContext::who).get());
            p1.shutdown();

            System.out.println("--- та же стратегия, но аутентификацию меняют в существующем контексте");
            ThreadPoolTaskExecutor p2 = newInheritingPool("shared-");
            SecurityContextHolder.clearContext();
            loginInPlace("alice");
            System.out.println("первая задача (alice):           " + p2.submit(AsyncContext::who).get());
            loginInPlace("bob");                            // тот же объект контекста, что получил рабочий поток
            System.out.println("вторая задача (после смены на bob): " + p2.submit(AsyncContext::who).get());
            p2.shutdown();
            SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_THREADLOCAL);
            SecurityContextHolder.clearContext();
        }
        System.exit(0);
    }
}
