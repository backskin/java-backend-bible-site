package behaviors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.AbstractPlatformTransactionManager;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.authorization.AuthorityAuthorizationManager;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.Map;

@SpringBootApplication
public class Behaviors {

    @RestController
    static class Api {
        @GetMapping("/api/payments") String payments() { return "платежи"; }
        @GetMapping("/api/admin/limits") String limits() { return "лимиты"; }
        @GetMapping("/ui") String ui() { return "страница"; }
    }

    @Service
    static class Methods {
        @PreAuthorize("hasRole('ADMIN')")
        public String byRole() { return "выполнено"; }

        @PreAuthorize("hasRole('ROLE_ADMIN')")
        public String byRoleWithPrefix() { return "выполнено"; }

        @PreAuthorize("hasAuthority('ADMIN')")
        public String byAuthorityAdmin() { return "выполнено"; }

        @PreAuthorize("hasAuthority('ROLE_ADMIN')")
        public String byAuthorityRoleAdmin() { return "выполнено"; }

        /** Сам метод не защищён, а внутри вызывает защищённый через this. */
        public String selfInvocation() { return byRole(); }
    }


    /** Бизнес-проверка, которую вызывают из SpEL. Печатает, идёт ли в этот момент транзакция. */
    @Service("perm")
    static class Perm {
        public boolean check(String where) {
            System.out.println("    проверка " + where + ": транзакция активна = "
                    + TransactionSynchronizationManager.isActualTransactionActive());
            return true;
        }
    }

    @Service
    static class Ledger {
        @Transactional
        @PreAuthorize("@perm.check('до метода')")
        @PostAuthorize("@perm.check('после метода')")
        public String post() {
            System.out.println("    внутри метода: транзакция активна = " + TransactionSynchronizationManager.isActualTransactionActive());
            return "готово";
        }
    }

    /** Минимальный менеджер транзакций без ресурсов: нужен только чтобы @Transactional включал транзакцию. */
    static class NoopTransactionManager extends AbstractPlatformTransactionManager {
        @Override protected Object doGetTransaction() { return new Object(); }
        @Override protected void doBegin(Object tx, TransactionDefinition d) { }
        @Override protected void doCommit(DefaultTransactionStatus s) { }
        @Override protected void doRollback(DefaultTransactionStatus s) { }
    }

    @Configuration
    @EnableWebSecurity
    @EnableMethodSecurity
    @org.springframework.transaction.annotation.EnableTransactionManagement
    static class Config {
        @Bean
        PlatformTransactionManager transactionManager() { return new NoopTransactionManager(); }

        @Bean
        UserDetailsService users() {
            return new InMemoryUserDetailsManager(
                    User.withUsername("alice").password("{noop}pw").roles("USER").build(),
                    User.withUsername("bob").password("{noop}pw").roles("ADMIN").build());
        }

        /** Правильный порядок: узкая цепочка API первой, общая цепочка UI последней. */
        @Bean @Order(1)
        SecurityFilterChain api(HttpSecurity http, @Value("${anonymous.disabled:false}") boolean noAnonymous) throws Exception {
            if (noAnonymous) http.anonymous(AbstractHttpConfigurer::disable);
            return http.securityMatcher("/api/**")
                    .authorizeHttpRequests(a -> a.requestMatchers("/api/admin/**").hasRole("ADMIN").anyRequest().authenticated())
                    .httpBasic(Customizer.withDefaults())
                    .csrf(AbstractHttpConfigurer::disable)
                    .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .build();
        }

        @Bean @Order(2) @Profile("!bad")
        SecurityFilterChain ui(HttpSecurity http, @Value("${permit.error:false}") boolean permitError) throws Exception {
            return http.authorizeHttpRequests(a -> {
                        if (permitError) a.requestMatchers("/error").permitAll();   // страница ошибок открыта для всех
                        a.anyRequest().authenticated();
                    })
                    .formLogin(Customizer.withDefaults())
                    .build();
        }
    }

    static final HttpClient HTTP = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).build();

    static void call(String base, String title, String path, String user, String accept) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + path)).GET();
        if (user != null) b.header("Authorization", "Basic " + Base64.getEncoder().encodeToString((user + ":pw").getBytes()));
        if (accept != null) b.header("Accept", accept);
        HttpResponse<String> r = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString());
        String extra = r.headers().firstValue("WWW-Authenticate").map(v -> ", WWW-Authenticate: " + v).orElse("")
                + r.headers().firstValue("Location").map(v -> ", Location: " + v.replaceAll("^http://localhost:\\d+", "")).orElse("");
        System.out.printf("%-44s -> HTTP %d%s%n", title, r.statusCode(), extra);
    }

    static void asUser(String name, String... authorities) {
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(name, "n", AuthorityUtils.createAuthorityList(authorities)));
    }

    static void tryRun(String title, java.util.function.Supplier<String> s) {
        try { System.out.printf("%-58s -> %s%n", title, s.get()); }
        catch (RuntimeException e) { System.out.printf("%-58s -> %s%n", title, e.getClass().getSimpleName()); }
    }

    public static void main(String[] args) throws Exception {
        SpringApplication app = new SpringApplication(Behaviors.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run(args)) {
            String base = "http://localhost:" + ctx.getEnvironment().getProperty("local.server.port");
            System.out.println("--- 401 и 403 (цепочка API: HTTP Basic, без сессии)");
            call(base, "аноним, GET /api/payments", "/api/payments", null, null);
            call(base, "alice (ROLE_USER), GET /api/payments", "/api/payments", "alice", null);
            call(base, "alice (ROLE_USER), GET /api/admin/limits", "/api/admin/limits", "alice", null);
            call(base, "bob (ROLE_ADMIN), GET /api/admin/limits", "/api/admin/limits", "bob", null);
            System.out.println("--- цепочка UI (form login)");
            call(base, "аноним, GET /ui, Accept: text/html", "/ui", null, "text/html");
            call(base, "аноним, GET /ui, Accept: application/json", "/ui", null, "application/json");

            System.out.println("--- hasRole и hasAuthority в @PreAuthorize (у пользователя authority ROLE_ADMIN)");
            Methods m = ctx.getBean(Methods.class);
            asUser("bob", "ROLE_ADMIN");
            tryRun("hasRole('ADMIN')", m::byRole);
            tryRun("hasRole('ROLE_ADMIN')", m::byRoleWithPrefix);
            tryRun("hasAuthority('ADMIN')", m::byAuthorityAdmin);
            tryRun("hasAuthority('ROLE_ADMIN')", m::byAuthorityRoleAdmin);
            tryRun("AuthorityAuthorizationManager.hasRole(\"ROLE_ADMIN\")", () -> {
                AuthorityAuthorizationManager.hasRole("ROLE_ADMIN");
                return "создан без ошибки";
            });
            System.out.println("--- вызов защищённого метода через this (alice, ROLE_USER)");
            asUser("alice", "ROLE_USER");
            tryRun("снаружи: methods.byRole()", m::byRole);
            tryRun("через this: methods.selfInvocation()", m::selfInvocation);
            System.out.println("--- порядок @PreAuthorize, @Transactional и @PostAuthorize");
            asUser("bob", "ROLE_ADMIN");
            ctx.getBean(Ledger.class).post();
            SecurityContextHolder.clearContext();
        }

        System.out.println("--- то же, но страница /error открыта для всех в цепочке UI");
        SpringApplication fixed = new SpringApplication(Behaviors.class);
        fixed.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off",
                "permit.error", "true"));
        try (ConfigurableApplicationContext ctx = fixed.run(args)) {
            String base = "http://localhost:" + ctx.getEnvironment().getProperty("local.server.port");
            call(base, "аноним, GET /api/payments", "/api/payments", null, null);
        }

        System.out.println("--- анонимная аутентификация отключена в цепочке API, /error открыта");
        SpringApplication noAnon = new SpringApplication(Behaviors.class);
        noAnon.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off",
                "permit.error", "true", "anonymous.disabled", "true"));
        try (ConfigurableApplicationContext ctx = noAnon.run(args)) {
            String base = "http://localhost:" + ctx.getEnvironment().getProperty("local.server.port");
            call(base, "аноним, GET /api/payments", "/api/payments", null, null);
            call(base, "alice (ROLE_USER), GET /api/admin/limits", "/api/admin/limits", "alice", null);
        }

        System.out.println("--- цепочка без securityMatcher стоит первой");
        SpringApplication bad = new SpringApplication(Behaviors.class);
        bad.setAdditionalProfiles("bad");
        bad.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = bad.run(args)) {
            System.out.println("приложение запустилось");
        } catch (Exception e) {
            Throwable r = e; while (r.getCause() != null) r = r.getCause();
            System.out.println("запуск не удался: " + r.getClass().getSimpleName() + ": " + r.getMessage());
        }
    }

    /** Меняет порядок: общая цепочка получает @Order(0) и перекрывает узкую. */
    @Configuration @Profile("bad")
    static class BadOrder {
        @Bean @Order(0)
        SecurityFilterChain uiFirst(HttpSecurity http) throws Exception {
            return http.authorizeHttpRequests(a -> a.anyRequest().authenticated()).formLogin(Customizer.withDefaults()).build();
        }
    }
}
