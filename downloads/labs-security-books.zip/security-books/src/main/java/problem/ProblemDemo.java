package problem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

/** Problem Details (RFC 9457) в Spring Boot. Зависимости: spring-boot-starter-webmvc (Boot 4.1.1). Запуск: main. */
@SpringBootApplication
public class ProblemDemo {

    static class LimitExceededException extends RuntimeException {
        final long limit;
        LimitExceededException(long limit) { super("лимит превышен"); this.limit = limit; }
    }

    @RestController
    static class Api {
        @GetMapping("/payments/{id}")
        String payment(@PathVariable long id) {
            if (id == 404) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "платёж не найден");
            if (id == 402) throw new LimitExceededException(1000);
            return "ok";
        }
    }

    /** В проекте подключена безопасность; для демонстрации ошибок открываем всё. */
    @org.springframework.context.annotation.Configuration
    static class Open {
        @org.springframework.context.annotation.Bean
        org.springframework.security.web.SecurityFilterChain chain(org.springframework.security.config.annotation.web.builders.HttpSecurity http) throws Exception {
            return http.authorizeHttpRequests(a -> a.anyRequest().permitAll()).csrf(c -> c.disable()).build();
        }
    }

    @RestControllerAdvice
    static class Errors {
        @ExceptionHandler(LimitExceededException.class)
        ProblemDetail limit(LimitExceededException e) {
            ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_ENTITY, "Суточный лимит превышен");
            p.setType(URI.create("https://errors.example.com/limit-exceeded"));
            p.setTitle("Лимит превышен");
            p.setProperty("limit", e.limit);                       // расширение: собственное поле
            return p;
        }
    }

    public static void main(String[] args) throws Exception {
        SpringApplication app = new SpringApplication(ProblemDemo.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off",
                "spring.mvc.problemdetails.enabled", "true", "spring.webmvc.problemdetails.enabled", "true"));
        try (ConfigurableApplicationContext ctx = app.run(args)) {
            String base = "http://localhost:" + ctx.getEnvironment().getProperty("local.server.port");
            HttpClient http = HttpClient.newHttpClient();
            for (String path : new String[]{"/payments/404", "/payments/402", "/payments/abc", "/nope"}) {
                HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(base + path)).header("Accept", "application/json").build(),
                        HttpResponse.BodyHandlers.ofString());
                System.out.println("GET " + path + " -> HTTP " + r.statusCode() + ", Content-Type: " + r.headers().firstValue("Content-Type").orElse("-"));
                System.out.println("  " + r.body());
            }
        }
        System.exit(0);
    }
}
