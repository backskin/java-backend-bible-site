package retobj;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authorization.AuthorizationResult;
import org.springframework.security.authorization.method.AuthorizeReturnObject;
import org.springframework.security.authorization.method.HandleAuthorizationDenied;
import org.springframework.security.authorization.method.MethodAuthorizationDeniedHandler;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Разд. 6.3 гл. 13: @AuthorizeReturnObject на списке DTO и маскирование поля через @HandleAuthorizationDenied (Security 7.1). */
@SpringBootApplication
@EnableMethodSecurity
public class ReturnObject {

    public static class PaymentDto {
        private final String counterpartyTaxId;
        private final BigDecimal amount;
        public PaymentDto(String taxId, BigDecimal amount) { this.counterpartyTaxId = taxId; this.amount = amount; }
        @PreAuthorize("hasRole('COMPLIANCE')")
        public String getCounterpartyTaxId() { return counterpartyTaxId; }
        @PreAuthorize("hasRole('COMPLIANCE')")
        @HandleAuthorizationDenied(handlerClass = Mask.class)
        public String getCounterpartyTaxIdMasked() { return counterpartyTaxId; }
        public BigDecimal getAmount() { return amount; }
    }

    /** Свой обработчик: такого класса в Spring Security нет, его пишут сами. */
    @Component
    public static class Mask implements MethodAuthorizationDeniedHandler {
        @Override public Object handleDeniedInvocation(MethodInvocation mi, AuthorizationResult r) { return "***"; }
    }

    @Service
    public static class Payments {
        @AuthorizeReturnObject
        public List<PaymentDto> findAll() {
            return new ArrayList<>(List.of(new PaymentDto("7707083893", new BigDecimal("1500.00")), new PaymentDto("7736050003", new BigDecimal("320.00"))));
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(ReturnObject.class);
        app.setDefaultProperties(Map.of("spring.main.web-application-type", "none", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            Payments payments = ctx.getBean(Payments.class);
            for (String role : List.of("OPERATOR", "COMPLIANCE")) {
                SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken("dev.team", null, AuthorityUtils.createAuthorityList("ROLE_" + role)));
                List<PaymentDto> list = payments.findAll();
                PaymentDto p = list.get(0);
                String plain;
                try { plain = p.getCounterpartyTaxId(); } catch (RuntimeException e) { plain = e.getClass().getSimpleName(); }
                System.out.printf("роль %-10s: класс списка %s, элемента %s; amount=%s, taxId=%s, taxIdMasked=%s%n", role,
                        list.getClass().getSimpleName(), (p.getClass() == PaymentDto.class ? "PaymentDto" : "прокси " + p.getClass().getSuperclass().getSimpleName()), p.getAmount(), plain, p.getCounterpartyTaxIdMasked());
            }
        }
    }
}
