package passwords;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.resilience.annotation.ConcurrencyLimit;
import org.springframework.resilience.annotation.EnableResilientMethods;
import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@SpringBootApplication
public class Passwords {

    @Configuration
    @EnableResilientMethods
    static class Resilience {}

    /** Проверка пароля, ограниченная по одновременности: по умолчанию лишние вызовы ждут. */
    @Service
    static class Checker {
        @ConcurrencyLimit(2)
        public String waiting() { return sleep(); }

        @ConcurrencyLimit(value = 2, policy = ConcurrencyLimit.ThrottlePolicy.REJECT)
        public String rejecting() { return sleep(); }

        private String sleep() {
            try { Thread.sleep(300); } catch (InterruptedException ignored) { }
            return "проверено";
        }
    }

    static void tryRun(String title, java.util.function.Supplier<String> s) {
        try { System.out.println(title + " -> " + s.get()); }
        catch (RuntimeException e) { System.out.println(title + " -> " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
    }

    static double millis(Runnable r) {
        long t = System.nanoTime();
        r.run();
        return (System.nanoTime() - t) / 1e6;
    }

    static void limit(String title, java.util.function.Supplier<String> call) throws Exception {
        ExecutorService ex = Executors.newFixedThreadPool(6);
        List<Future<String>> fs = new ArrayList<>();
        long t0 = System.nanoTime();
        for (int i = 0; i < 6; i++) fs.add(ex.submit(call::get));
        int ok = 0; int rejected = 0; String name = "";
        for (Future<String> f : fs) {
            try { f.get(); ok++; } catch (Exception e) { rejected++; name = e.getCause().getClass().getSimpleName(); }
        }
        ex.shutdown();
        System.out.printf("%-26s выполнено %d, отклонено %d %s, общее время %d мс%n", title, ok, rejected,
                name.isEmpty() ? "" : "(" + name + ")", (System.nanoTime() - t0) / 1_000_000);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("--- формат {id} и миграция");
        DelegatingPasswordEncoder delegating = (DelegatingPasswordEncoder) PasswordEncoderFactories.createDelegatingPasswordEncoder();
        String h1 = delegating.encode("secret"), h2 = delegating.encode("secret");
        System.out.println("encode(\"secret\") два раза даёт разные хеши: " + !h1.equals(h2));
        System.out.println("начало хеша: " + h1.substring(0, 20) + "...");
        System.out.println("matches по обоим: " + delegating.matches("secret", h1) + ", " + delegating.matches("secret", h2));
        String legacy = new BCryptPasswordEncoder().encode("secret");          // хеш без префикса {bcrypt}
        try { delegating.matches("secret", legacy); }
        catch (IllegalArgumentException e) { System.out.println("без префикса: IllegalArgumentException: " + e.getMessage()); }
        tryRun("неизвестный префикс {foo}: matches", () -> String.valueOf(delegating.matches("secret", "{foo}abc")));
        delegating.setDefaultPasswordEncoderForMatches(new BCryptPasswordEncoder());
        System.out.println("с setDefaultPasswordEncoderForMatches: " + delegating.matches("secret", legacy));
        System.out.println("upgradeEncoding(bcrypt strength 10): " + delegating.upgradeEncoding(h1)
                + "; для strength 4: " + delegating.upgradeEncoding("{bcrypt}" + new BCryptPasswordEncoder(4).encode("secret")));

        System.out.println("--- цена проверки пароля, мс (лучшее из 3 после прогрева)");
        for (int s : new int[]{4, 10, 12, 13}) {
            BCryptPasswordEncoder e = new BCryptPasswordEncoder(s);
            String h = e.encode("secret");
            e.matches("secret", h);
            double best = Double.MAX_VALUE;
            for (int i = 0; i < 3; i++) best = Math.min(best, millis(() -> e.matches("secret", h)));
            System.out.printf("bcrypt strength %2d: %7.1f мс%n", s, best);
        }
        PasswordEncoder pbkdf2 = Pbkdf2PasswordEncoder.defaultsForSpringSecurity_v5_8();
        String hp = pbkdf2.encode("secret");
        System.out.printf("PBKDF2 (по умолчанию):  %7.1f мс%n", millis(() -> pbkdf2.matches("secret", hp)));
        PasswordEncoder argon = Argon2PasswordEncoder.defaultsForSpringSecurity_v5_8();
        String ha = argon.encode("secret");
        argon.matches("secret", ha);
        System.out.printf("Argon2id (по умолчанию): %6.1f мс%n", millis(() -> argon.matches("secret", ha)));

        System.out.println("--- bcrypt и 72 байта");
        BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
        String a72 = "a".repeat(72);
        String h = bcrypt.encode(a72);
        System.out.println("ровно 72 байта ASCII: encode прошёл, matches = " + bcrypt.matches(a72, h));
        tryRun("73 байта ASCII: encode", () -> bcrypt.encode(a72 + "X"));
        String ru40 = "п".repeat(40);                                          // 40 символов = 80 байт в UTF-8
        tryRun("40 русских символов (80 байт): encode", () -> bcrypt.encode(ru40));
        tryRun("73 байта против готового хеша: matches", () -> String.valueOf(bcrypt.matches(a72 + "X", h)));

        System.out.println("--- @ConcurrencyLimit(2), шесть одновременных вызовов по 300 мс");
        try (ConfigurableApplicationContext ctx = new SpringApplication(Passwords.class).run(
                "--logging.level.root=OFF", "--spring.main.banner-mode=off", "--spring.main.web-application-type=none")) {
            Checker c = ctx.getBean(Checker.class);
            limit("по умолчанию (ждут)", c::waiting);
            limit("policy = REJECT", c::rejecting);
        }
    }
}
