package chain;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@SpringBootApplication
public class ChainOrder {

    /** Свой фильтр, который мы ставим перед AuthorizationFilter. */
    static class AuditFilter extends OncePerRequestFilter {
        @Override
        protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
                throws ServletException, IOException {
            chain.doFilter(req, res);
        }
    }

    /** Цепочка A: сначала csrf, cors, httpBasic, потом остальное. */
    @Bean @Order(1)
    SecurityFilterChain chainA(HttpSecurity http) throws Exception {
        return http.securityMatcher("/a/**")
                .csrf(Customizer.withDefaults())
                .cors(Customizer.withDefaults())
                .httpBasic(Customizer.withDefaults())
                .formLogin(Customizer.withDefaults())
                .oauth2ResourceServer(o -> o.jwt(j -> j.jwkSetUri("http://localhost:1/jwks")))
                .authorizeHttpRequests(a -> a.anyRequest().authenticated())
                .build();
    }

    /** Цепочка B: те же возможности, но вызовы DSL в обратном порядке. */
    @Bean @Order(2)
    SecurityFilterChain chainB(HttpSecurity http) throws Exception {
        return http.securityMatcher("/b/**")
                .authorizeHttpRequests(a -> a.anyRequest().authenticated())
                .oauth2ResourceServer(o -> o.jwt(j -> j.jwkSetUri("http://localhost:1/jwks")))
                .formLogin(Customizer.withDefaults())
                .httpBasic(Customizer.withDefaults())
                .cors(Customizer.withDefaults())
                .csrf(Customizer.withDefaults())
                .build();
    }

    /** Цепочка C: добавлен свой фильтр перед AuthorizationFilter. */
    @Bean @Order(3)
    SecurityFilterChain chainC(HttpSecurity http) throws Exception {
        return http.securityMatcher("/c/**")
                .httpBasic(Customizer.withDefaults())
                .addFilterBefore(new AuditFilter(), AuthorizationFilter.class)
                .authorizeHttpRequests(a -> a.anyRequest().authenticated())
                .build();
    }

    static List<String> names(SecurityFilterChain c) {
        return c.getFilters().stream().map(f -> f.getClass().getSimpleName()).collect(Collectors.toList());
    }

    @Bean
    CommandLineRunner print(FilterChainProxy proxy) {
        return args -> {
            List<SecurityFilterChain> chains = proxy.getFilterChains();
            List<String> a = names(chains.get(0)), b = names(chains.get(1)), c = names(chains.get(2));
            System.out.println("цепочка A (/a/**), фильтров " + a.size() + ":");
            for (int i = 0; i < a.size(); i++) System.out.printf("  %2d %s%n", i + 1, a.get(i));
            System.out.println("цепочка B (/b/**): тот же состав и порядок, что у A? " + a.equals(b));
            System.out.println("цепочка C (/c/**), последние три фильтра: " + c.subList(c.size() - 3, c.size()));
        };
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(ChainOrder.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        System.exit(SpringApplication.exit(app.run(args)));
    }
}
