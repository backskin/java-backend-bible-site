package jwtv;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.oauth2.jwt.JwtClaimValidator;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.security.oauth2.jwt.JwtTimestampValidator;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;

/** Запуск: нужен только spring-boot-starter-security-oauth2-resource-server (он приносит Nimbus). */
public class JwtValidation {

    static final String ISSUER = "https://idp.example.com/realms/bank";
    static final byte[] SECRET = "0123456789abcdef0123456789abcdef".getBytes();   // 256 бит для HS256

    static String token(String issuer, List<String> audience, Instant expires) throws Exception {
        Instant issued = expires.minusSeconds(300);
        JWTClaimsSet claims = new JWTClaimsSet.Builder()
                .issuer(issuer).subject("alice").audience(audience)
                .issueTime(Date.from(issued)).expirationTime(Date.from(expires)).build();
        SignedJWT jwt = new SignedJWT(new JWSHeader(JWSAlgorithm.HS256), claims);
        jwt.sign(new MACSigner(SECRET));
        return jwt.serialize();
    }

    static NimbusJwtDecoder decoder(OAuth2TokenValidator<Jwt> validator) {
        SecretKey key = new SecretKeySpec(SECRET, "HmacSHA256");
        NimbusJwtDecoder d = NimbusJwtDecoder.withSecretKey(key).build();
        d.setJwtValidator(validator);
        return d;
    }

    static void check(String title, NimbusJwtDecoder d, String token) {
        try { d.decode(token); System.out.printf("%-58s -> принят%n", title); }
        catch (JwtException e) { System.out.printf("%-58s -> отклонён: %s%n", title, e.getMessage()); }
    }

    public static void main(String[] args) throws Exception {
        Instant now = Instant.now();
        OAuth2TokenValidator<Jwt> byDefault = JwtValidators.createDefaultWithIssuer(ISSUER);
        OAuth2TokenValidator<Jwt> withAudience = new DelegatingOAuth2TokenValidator<>(byDefault,
                new JwtClaimValidator<List<String>>(JwtClaimNames.AUD, aud -> aud != null && aud.contains("payments-api")));
        OAuth2TokenValidator<Jwt> strictClock = new DelegatingOAuth2TokenValidator<>(
                new JwtTimestampValidator(Duration.ofSeconds(5)));

        NimbusJwtDecoder defaultDecoder = decoder(byDefault);
        NimbusJwtDecoder audienceDecoder = decoder(withAudience);

        System.out.println("--- aud");
        check("набор по умолчанию, aud = reports-api", defaultDecoder, token(ISSUER, List.of("reports-api"), now.plusSeconds(300)));
        check("с проверкой aud, aud = reports-api", audienceDecoder, token(ISSUER, List.of("reports-api"), now.plusSeconds(300)));
        check("с проверкой aud, aud = payments-api", audienceDecoder, token(ISSUER, List.of("payments-api"), now.plusSeconds(300)));

        System.out.println("--- iss");
        check("чужой издатель", defaultDecoder, token("https://evil.example.com", List.of("payments-api"), now.plusSeconds(300)));

        System.out.println("--- exp и допуск на расхождение часов");
        check("истёк 30 с назад, допуск по умолчанию", defaultDecoder, token(ISSUER, List.of("payments-api"), now.minusSeconds(30)));
        check("истёк 90 с назад, допуск по умолчанию", defaultDecoder, token(ISSUER, List.of("payments-api"), now.minusSeconds(90)));
        check("истёк 30 с назад, допуск 5 с", decoder(strictClock), token(ISSUER, List.of("payments-api"), now.minusSeconds(30)));
        System.out.println("--- setJwtValidator заменяет набор по умолчанию целиком");
        OAuth2TokenValidator<Jwt> onlyAudience = new JwtClaimValidator<List<String>>(JwtClaimNames.AUD,
                aud -> aud != null && aud.contains("payments-api"));
        NimbusJwtDecoder replaced = decoder(onlyAudience);       // вместо createDefaultWithIssuer: только aud
        check("только aud, истёк час назад", replaced, token(ISSUER, List.of("payments-api"), now.minusSeconds(3600)));
        check("только aud, чужой издатель", replaced, token("https://evil.example.com", List.of("payments-api"), now.plusSeconds(300)));
    }
}
