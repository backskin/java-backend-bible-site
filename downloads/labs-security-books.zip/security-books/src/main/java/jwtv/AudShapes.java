package jwtv;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;

import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Date;
import java.util.List;

/**
 * Как claim aud выглядит в теле токена (строка или массив) и что видит код, который разбирает JSON сам, и код Spring Security.
 * Нужен spring-boot-starter-security-oauth2-resource-server (приносит Nimbus). Запуск: main.
 */
public class AudShapes {

    static final byte[] SECRET = "0123456789abcdef0123456789abcdef".getBytes(StandardCharsets.UTF_8);

    static String token(List<String> audience) throws Exception {
        JWTClaimsSet claims = new JWTClaimsSet.Builder().issuer("https://idp.example.com/realms/bank").subject("alice").audience(audience)
                .expirationTime(new Date(System.currentTimeMillis() + 300_000)).build();
        SignedJWT jwt = new SignedJWT(new JWSHeader(JWSAlgorithm.HS256), claims);
        jwt.sign(new MACSigner(SECRET));
        return jwt.serialize();
    }

    static String body(String token) {
        return new String(Base64.getUrlDecoder().decode(token.split("\\.")[1]), StandardCharsets.UTF_8);
    }

    public static void main(String[] args) throws Exception {
        NimbusJwtDecoder decoder = NimbusJwtDecoder.withSecretKey(new SecretKeySpec(SECRET, "HmacSHA256")).build();
        System.out.println("=== 2.5 claim aud в теле токена и в коде проверки");
        for (List<String> aud : List.of(List.of("payments-api"), List.of("payments-api", "account"))) {
            String t = token(aud);
            String json = body(t);
            String raw = json.substring(json.indexOf("\"aud\""), json.indexOf("\"aud\"") + (aud.size() == 1 ? 20 : 32));
            Jwt jwt = decoder.decode(t);
            Object naive = com.nimbusds.jose.util.JSONObjectUtils.parse(json).get("aud");
            System.out.printf("  в теле: %-32s | Spring getAudience(): %-26s | свой разбор JSON: %s (%s) | naive equals(\"payments-api\"): %s%n",
                    raw, jwt.getAudience(), naive, naive.getClass().getSimpleName(), "payments-api".equals(naive));
        }
    }
}
