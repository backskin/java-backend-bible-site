package sectest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Тот же контроллер, но без @Import конфигурации безопасности: правило permitAll из неё не действует. */
@WebMvcTest(SecurityTests.Api.class)
@Import(SecurityTests.Api.class)
class NoSecurityConfigTest {

    @Autowired MockMvc mvc;

    @Test
    void public_endpoint_is_closed_without_import() throws Exception {
        mvc.perform(get("/api/public/ping")).andExpect(status().isUnauthorized());
    }
}
