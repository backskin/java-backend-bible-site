package sectest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Тесты безопасности: запуск `mvn test`. Зависимости: spring-boot-starter-webmvc, -security, -oauth2-resource-server, -webmvc-test, -security-test. */
@WebMvcTest(SecurityTests.Api.class)
@Import({SecurityTests.SecurityConfig.class, SecurityTests.Api.class})   // конфигурация безопасности в срез НЕ попадает сама; вложенный контроллер тоже подключаем явно
class SecurityTests {

    @SpringBootApplication
    static class TestApp {}

    @RestController
    static class Api {
        @GetMapping("/api/payments/1") String get() { return "платёж"; }
        @DeleteMapping("/api/payments/1") String delete() { return "удалён"; }
        @PostMapping("/api/payments") String create() { return "создан"; }
        @GetMapping("/api/public/ping") String ping() { return "pong"; }
        @GetMapping("/api/me") String me(@AuthenticationPrincipal Jwt jwt) { return jwt == null ? "principal = null" : "sub=" + jwt.getSubject(); }
    }

    @Configuration
    @EnableWebSecurity
    static class SecurityConfig {
        @Bean
        SecurityFilterChain chain(HttpSecurity http) throws Exception {
            return http.authorizeHttpRequests(a -> a
                            .requestMatchers("/api/public/**").permitAll()
                            .requestMatchers(HttpMethod.DELETE, "/api/payments/**").hasRole("ADMIN")
                            .requestMatchers(HttpMethod.POST, "/api/payments").hasAuthority("SCOPE_payments:write")
                            .anyRequest().authenticated())
                    .httpBasic(Customizer.withDefaults())
                    .build();
        }
    }

    @Autowired MockMvc mvc;

    @Test
    void anonymous_gets_401() throws Exception {
        mvc.perform(get("/api/payments/1")).andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(roles = "USER")
    void user_cannot_delete() throws Exception {
        mvc.perform(delete("/api/payments/1").with(csrf())).andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void admin_can_delete_with_csrf() throws Exception {
        mvc.perform(delete("/api/payments/1").with(csrf())).andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void admin_gets_403_without_csrf() throws Exception {            // 403 не из-за прав, а из-за CSRF
        mvc.perform(delete("/api/payments/1")).andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(authorities = "ADMIN")                              // authority ADMIN, а hasRole ищет ROLE_ADMIN
    void authority_admin_is_not_role_admin() throws Exception {
        mvc.perform(delete("/api/payments/1").with(csrf())).andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(authorities = "SCOPE_payments:write")
    void scope_allows_write() throws Exception {
        mvc.perform(post("/api/payments").with(csrf())).andExpect(status().isOk());
    }

    @Test
    @WithMockUser
    void mock_user_gives_null_jwt_principal() throws Exception {
        mvc.perform(get("/api/me")).andExpect(status().isOk()).andExpect(content().string("principal = null"));
    }

    @Test
    void jwt_post_processor_gives_jwt_principal() throws Exception {
        mvc.perform(get("/api/me").with(jwt().jwt(j -> j.subject("u-1"))))
                .andExpect(status().isOk()).andExpect(content().string("sub=u-1"));
    }

    @Test
    void public_endpoint_is_open() throws Exception {
        mvc.perform(get("/api/public/ping")).andExpect(status().isOk());
    }
}
