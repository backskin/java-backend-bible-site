# Spring Security 7.1 по книгам и по запуску: цепочки фильтров, 401 и 403, контекст в потоках, пароли, JWT, CSRF, тесты

Стенд к главе 13, разделы 2–10 и 12. Проект Maven (Spring Boot 4.1.1, Spring Security 7.1.1), где каждый опыт - класс с `main`: `chain.ChainOrder` (фактический порядок фильтров при разном порядке DSL и свой фильтр), `behaviors.Behaviors` (две цепочки, HTTP Basic против формы, 401 и 403, префикс `ROLE_`, вызов через `this`, порядок проверки и транзакции), `asyncctx.AsyncContext` (контекст в пуле с `DelegatingSecurityContextAsyncTaskExecutor` и `MODE_INHERITABLETHREADLOCAL`), `passwords.Passwords` (формат `{id}`, время bcrypt при разных strength, PBKDF2, Argon2id, длинные пароли, `@ConcurrencyLimit`), `jwtv.JwtValidation` и `jwtv.AudShapes` (валидаторы JWT, формы claim `aud`), `websec.WebSec` (CSRF и сессии при разных способах аутентификации), `problem.ProblemDemo` (`application/problem+json`), `retobj.ReturnObject` (`@AuthorizeReturnObject`); тесты `sectest.*` - `@WithMockUser`, `@WebMvcTest` без своей конфигурации. Выводы автора - `s13-<Класс>.txt`, `s13-tests.txt`.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, bash.

## Запуск

```bash
bash run.sh
```

Один класс: `bash run.sh chain.ChainOrder`; тесты: `bash run.sh tests` или `mvn -q test`. В IDEA на каждый класс есть конфигурация и есть `mvn test`.

## Что должно получиться

В цепочке API на Spring Security 7 - 19 фильтров, порядок не зависит от порядка вызовов DSL; аноним на цепочке с формой получает 302 на `/login`, на цепочке с Basic без сессии - 401; `OPERATOR` в `ReturnObject` видит `taxId` как `AuthorizationDeniedException`, `COMPLIANCE` - значение.
