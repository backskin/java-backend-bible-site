#!/usr/bin/env bash
# Опыты гл. 13 (Spring Security) на Spring Boot 4.1.1 / Spring Security 7.
# Запуск: ./run.sh [класс...] — без аргументов все; вывод каждого в s13-<класс>.txt; тесты (mvn test) — в s13-tests.txt.
set -uo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt >/dev/null || { mvn -q -DskipTests compile 2>&1 | grep ERROR | head -5; exit 1; }
CP="$(cygpath -w "$PWD/target/classes" 2>/dev/null || echo target/classes);$(cat cp.txt)"
[ "$(uname -o 2>/dev/null)" = "Msys" ] || CP="${CP//;/:}"
mains=("$@"); [ ${#mains[@]} -eq 0 ] && mains=(chain.ChainOrder behaviors.Behaviors asyncctx.AsyncContext passwords.Passwords jwtv.JwtValidation jwtv.AudShapes websec.WebSec problem.ProblemDemo retobj.ReturnObject tests)
for m in "${mains[@]}"; do
  echo "== $m"
  if [ "$m" = tests ]; then
    mvn -q test 2>&1 | grep -v "WARNING" | sed -e "s#$HOME#~#g" -e "s/$(whoami)/dev.team/g" > s13-tests.txt
    mvn test 2>&1 | grep -E "Tests run:|FAIL|BUILD" | tail -4 >> s13-tests.txt
  else
    timeout 300 "$J" -Dstdout.encoding=UTF-8 -cp "$CP" "$m" 2>&1 \
      | grep -v "WARNING.*\(sun.misc\|Unsafe\|restricted method\|native access\)" \
      | sed -e "s#$HOME#~#g" -e 's#C:\\Users\\[^\\]*#~#g' -e "s/$(whoami)/dev.team/g" > "s13-${m#*.}.txt"
  fi
  echo "   строк $(wc -l < "s13-${m#*.}.txt" 2>/dev/null || wc -l < s13-tests.txt)"
done
