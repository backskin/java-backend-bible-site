# s3-lab: опыты с S3-совместимым хранилищем (гл. 15, подразделы 11.7–11.13)

Сервер: MinIO (сообщественный форк `pgsty/minio`, RELEASE.2026-08-04) в kind, манифест `k8s/minio.yaml`; официальные образы MinIO с Docker Hub и Quay недоступны (см. 11.13).

```bash
kubectl apply -f k8s/minio.yaml
kubectl -n s3 port-forward pod/minio 59000:9000
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt
java -cp "target/classes;$(cat cp.txt)" S3Lab          # все опыты E1..E11, или S3Lab e4 e5
```

Клиент: AWS SDK for Java v2 2.57.1, учетные данные тестовые (`lab` / `labsecret1`). Kotlin-обертка `src/main/kotlin/KtS3.kt` компилируется скриптом `tmp/kc.sh` (см. репозиторий) или Maven-плагином Kotlin.

В `results/` лежит вывод опытов, который приведен в тексте книги.

## SeaweedFS

Те же опыты на SeaweedFS 4.50 (вывод `results/seaweedfs-all.txt`):

```bash
docker run -d --name s3lab-sw -p 59000:8333 -v "$PWD/seaweed-s3.json:/etc/s3.json" chrislusf/seaweedfs:latest server -s3 -s3.config=/etc/s3.json
java -cp "target/classes;$(cat cp.txt)" S3Lab
```

Garage 2.1.0: `docker run -d --name s3lab-garage -p 59000:3900 -v "$PWD/garage.toml:/etc/garage.toml:ro" dxflrs/garage:v2.1.0`, затем `garage layout assign -z dc1 -c 1G <id>`, `garage layout apply --version 1`, `garage key import`, `garage key allow --create-bucket lab`; запуск S3Lab с `-Ds3.checksum=when_required -Ds3.key=... -Ds3.secret=...` (вывод `results/garage-all.txt`).

MinIO без kubectl: `docker run -d --name s3lab-minio -p 59000:9000 -e MINIO_ROOT_USER=lab -e MINIO_ROOT_PASSWORD=labsecret1 pgsty/minio:latest server /data`.
