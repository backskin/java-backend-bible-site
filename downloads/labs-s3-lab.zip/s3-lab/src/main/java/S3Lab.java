import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.http.SdkHttpConfigurationOption;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.retries.DefaultRetryStrategy;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PutObjectPresignRequest;

/** Опыты с S3-совместимым хранилищем (MinIO) через AWS SDK for Java v2. Запуск: java -cp ... S3Lab [e1 e2 ...] */
public class S3Lab {
    static final String EP = "http://localhost:59000";
    static final AwsBasicCredentials CREDS = AwsBasicCredentials.create(System.getProperty("s3.key", "lab"), System.getProperty("s3.secret", "labsecret1"));

    static S3Client s3() {
        var b = S3Client.builder().endpointOverride(URI.create(EP)).region(Region.US_EAST_1).forcePathStyle(true)
                .credentialsProvider(StaticCredentialsProvider.create(CREDS));
        if ("when_required".equals(System.getProperty("s3.checksum")))   // для серверов без поддержки контрольных сумм по умолчанию SDK 2.30+
            b = b.requestChecksumCalculation(software.amazon.awssdk.core.checksums.RequestChecksumCalculation.WHEN_REQUIRED)
                 .responseChecksumValidation(software.amazon.awssdk.core.checksums.ResponseChecksumValidation.WHEN_REQUIRED);
        return b.build();
    }

    static S3Presigner presigner() {
        return S3Presigner.builder().endpointOverride(URI.create(EP)).region(Region.US_EAST_1)
                .serviceConfiguration(software.amazon.awssdk.services.s3.S3Configuration.builder().pathStyleAccessEnabled(true).build())
                .credentialsProvider(StaticCredentialsProvider.create(CREDS)).build();
    }

    static void reset(S3Client s3, String bucket) {
        try {
            s3.getBucketVersioning(b -> b.bucket(bucket));
            // удаляем все версии и маркеры
            try {
                for (var p : s3.listObjectVersionsPaginator(b -> b.bucket(bucket))) {
                    for (var v : p.versions()) s3.deleteObject(b -> b.bucket(bucket).key(v.key()).versionId(v.versionId()));
                    for (var m : p.deleteMarkers()) s3.deleteObject(b -> b.bucket(bucket).key(m.key()).versionId(m.versionId()));
                }
            } catch (S3Exception e) {
                if (e.statusCode() != 501) throw e;   // сервер без версионирования (Garage): удаляем обычным списком
                for (var p : s3.listObjectsV2Paginator(b -> b.bucket(bucket)))
                    for (var o : p.contents()) s3.deleteObject(b -> b.bucket(bucket).key(o.key()));
            }
            s3.deleteBucket(b -> b.bucket(bucket));
        } catch (NoSuchBucketException ignored) {
        } catch (S3Exception e) {
            if (e.statusCode() != 404) throw e;
        }
        s3.createBucket(b -> b.bucket(bucket));
    }

    static String md5(byte[]... parts) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        for (byte[] p : parts) md.update(p);
        return HexFormat.of().formatHex(md.digest());
    }

    static String err(Exception e) {
        if (e instanceof S3Exception s) {
            var d = s.awsErrorDetails();
            return "HTTP " + s.statusCode() + " " + (d == null ? "" : d.errorCode());
        }
        return e.getClass().getSimpleName() + ": " + e.getMessage();
    }

    static void h(String t) { System.out.println("\n== " + t); }

    interface Exp { void go() throws Exception; }
    static void run(String name, Exp e) {
        try { e.go(); } catch (Exception ex) { System.out.println("   " + name + " прерван: " + err(ex)); }
    }

    public static void main(String[] args) throws Exception {
        Set<String> want = new HashSet<>(Arrays.asList(args));
        try (S3Client s3 = s3()) {
            if (want.isEmpty() || want.contains("e1")) run("e1", () -> e1(s3));
            if (want.isEmpty() || want.contains("e2")) run("e2", () -> e2(s3));
            if (want.isEmpty() || want.contains("e3")) run("e3", () -> e3(s3));
            if (want.isEmpty() || want.contains("e4")) run("e4", () -> e4(s3));
            if (want.isEmpty() || want.contains("e5")) run("e5", () -> e5(s3));
            if (want.isEmpty() || want.contains("e6")) run("e6", () -> e6(s3));
            if (want.isEmpty() || want.contains("e7")) run("e7", () -> e7(s3));
            if (want.isEmpty() || want.contains("e8")) run("e8", () -> e8(s3));
            if (want.isEmpty() || want.contains("e9")) run("e9", () -> e9(s3));
            if (want.isEmpty() || want.contains("e10")) run("e10", () -> e10());
            if (want.isEmpty() || want.contains("e11")) run("e11", () -> e11(s3));
            if (want.isEmpty() || want.contains("e12")) run("e12", () -> e12(s3));
            if (want.isEmpty() || want.contains("e13")) run("e13", () -> e13(s3));
            if (want.isEmpty() || want.contains("e14")) run("e14", () -> e14(s3));
        }
    }

    // E1: bucket/key, ETag, метаданные, «папки» как префиксы, пустая папка исчезает
    static void e1(S3Client s3) throws Exception {
        h("E1 bucket, key, ETag, метаданные, префиксы");
        reset(s3, "lab-basic");
        byte[] body = "id,amount\n1,100\n2,250\n".getBytes(StandardCharsets.UTF_8);
        var put = s3.putObject(b -> b.bucket("lab-basic").key("payments/2026/10/21/stmt-001.csv").contentType("text/csv")
                .metadata(Map.of("source", "acquiring", "batch", "42")), RequestBody.fromBytes(body));
        System.out.println("PUT ETag=" + put.eTag() + "  md5(тела)=" + md5(body));
        s3.putObject(b -> b.bucket("lab-basic").key("payments/2026/10/22/stmt-002.csv"), RequestBody.fromString("x"));
        s3.putObject(b -> b.bucket("lab-basic").key("payments/2026/11/01/stmt-003.csv"), RequestBody.fromString("y"));
        var head = s3.headObject(b -> b.bucket("lab-basic").key("payments/2026/10/21/stmt-001.csv"));
        System.out.println("HEAD length=" + head.contentLength() + " type=" + head.contentType() + " metadata=" + new TreeMap<>(head.metadata()));
        System.out.println("GET тело: " + s3.getObjectAsBytes(b -> b.bucket("lab-basic").key("payments/2026/10/21/stmt-001.csv")).asUtf8String().replace("\n", "\\n"));
        var l1 = s3.listObjectsV2(b -> b.bucket("lab-basic").prefix("payments/2026/10/").delimiter("/"));
        System.out.println("list prefix=payments/2026/10/ delimiter=/ -> commonPrefixes=" + l1.commonPrefixes().stream().map(CommonPrefix::prefix).toList() + " contents=" + l1.contents().size());
        var l2 = s3.listObjectsV2(b -> b.bucket("lab-basic").prefix("payments/2026/10/"));
        System.out.println("list prefix=payments/2026/10/ (без delimiter) -> " + l2.contents().stream().map(S3Object::key).toList());
        s3.putObject(b -> b.bucket("lab-basic").key("a/b/c.txt"), RequestBody.fromString("z"));
        System.out.println("до удаления: list prefix=a/ delimiter=/ -> " + s3.listObjectsV2(b -> b.bucket("lab-basic").prefix("a/").delimiter("/")).commonPrefixes().stream().map(CommonPrefix::prefix).toList());
        s3.deleteObject(b -> b.bucket("lab-basic").key("a/b/c.txt"));
        System.out.println("после удаления единственного файла: " + s3.listObjectsV2(b -> b.bucket("lab-basic").prefix("a/").delimiter("/")).commonPrefixes().stream().map(CommonPrefix::prefix).toList() + " (папки a/b/ больше нет)");
        var del = s3.deleteObject(b -> b.bucket("lab-basic").key("нет/такого"));
        System.out.println("DELETE несуществующего: успех, HTTP " + del.sdkHttpResponse().statusCode());
        try { s3.getObject(b -> b.bucket("lab-basic").key("нет/такого")); } catch (Exception e) { System.out.println("GET несуществующего: " + err(e)); }
        String longKey = "я".repeat(600);
        try { s3.putObject(b -> b.bucket("lab-basic").key(longKey), RequestBody.fromString("x")); System.out.println("ключ из 600 кириллических символов (1200 байт): принят"); }
        catch (Exception e) { System.out.println("ключ из 600 кириллических символов (1200 байт): " + err(e)); }
        String okKey = "а".repeat(500);
        try { s3.putObject(b -> b.bucket("lab-basic").key(okKey), RequestBody.fromString("x")); System.out.println("ключ из 500 кириллических символов (1000 байт): принят"); }
        catch (Exception e) { System.out.println("ключ из 500 кириллических символов (1000 байт): " + err(e)); }
        String ascii1025 = "k".repeat(1025);
        try { s3.putObject(b -> b.bucket("lab-basic").key(ascii1025), RequestBody.fromString("x")); System.out.println("ключ из 1025 ASCII-символов: принят"); }
        catch (Exception e) { System.out.println("ключ из 1025 ASCII-символов: " + err(e)); }
    }

    // E2: согласованность чтения после записи
    static void e2(S3Client s3) throws Exception {
        h("E2 согласованность: чтение и список сразу после записи");
        reset(s3, "lab-consistency");
        int listMiss = 0, getStale = 0, n = 300;
        for (int i = 0; i < n; i++) {
            String key = "k/" + i;
            s3.putObject(b -> b.bucket("lab-consistency").key(key), RequestBody.fromString("v0"));
            var keys = s3.listObjectsV2(b -> b.bucket("lab-consistency").prefix("k/")).contents().stream().map(S3Object::key).collect(Collectors.toSet());
            if (!keys.contains(key)) listMiss++;
        }
        for (int i = 0; i < n; i++) {
            String v = "v" + i;
            s3.putObject(b -> b.bucket("lab-consistency").key("same"), RequestBody.fromString(v));
            if (!s3.getObjectAsBytes(b -> b.bucket("lab-consistency").key("same")).asUtf8String().equals(v)) getStale++;
        }
        System.out.println("новых ключей: " + n + ", не попали в list сразу после PUT: " + listMiss);
        System.out.println("перезаписей одного ключа: " + n + ", GET вернул старое значение: " + getStale);
        // удаление
        s3.deleteObject(b -> b.bucket("lab-consistency").key("same"));
        try { s3.headObject(b -> b.bucket("lab-consistency").key("same")); System.out.println("после DELETE HEAD видит объект"); }
        catch (Exception e) { System.out.println("после DELETE сразу HEAD: " + err(e)); }
    }

    // E3: переименование = копия + удаление
    static void e3(S3Client s3) throws Exception {
        h("E3 переименования нет: копия и удаление");
        reset(s3, "lab-rename");
        s3.putObject(b -> b.bucket("lab-rename").key("incoming/f.csv"), RequestBody.fromString("data"));
        s3.copyObject(b -> b.sourceBucket("lab-rename").sourceKey("incoming/f.csv").destinationBucket("lab-rename").destinationKey("done/f.csv"));
        System.out.println("после copyObject, до deleteObject (между двумя вызовами может оборваться процесс): " +
                s3.listObjectsV2(b -> b.bucket("lab-rename")).contents().stream().map(S3Object::key).sorted().toList());
        s3.deleteObject(b -> b.bucket("lab-rename").key("incoming/f.csv"));
        System.out.println("после deleteObject: " + s3.listObjectsV2(b -> b.bucket("lab-rename")).contents().stream().map(S3Object::key).sorted().toList());
    }

    // E4: multipart upload
    static void e4(S3Client s3) throws Exception {
        h("E4 multipart: ETag составного объекта, минимальный размер части, брошенные загрузки");
        reset(s3, "lab-multipart");
        int mb = 1024 * 1024;
        Random r = new Random(1);
        byte[][] parts = {new byte[5 * mb], new byte[5 * mb], new byte[2 * mb]};
        for (byte[] p : parts) r.nextBytes(p);
        var up = s3.createMultipartUpload(b -> b.bucket("lab-multipart").key("big.bin"));
        List<CompletedPart> done = new ArrayList<>();
        for (int i = 0; i < parts.length; i++) {
            int num = i + 1; byte[] p = parts[i];
            var res = s3.uploadPart(b -> b.bucket("lab-multipart").key("big.bin").uploadId(up.uploadId()).partNumber(num), RequestBody.fromBytes(p));
            done.add(CompletedPart.builder().partNumber(num).eTag(res.eTag()).build());
            System.out.println("часть " + num + ": " + p.length / mb + " МиБ, ETag=" + res.eTag());
        }
        var c = s3.completeMultipartUpload(b -> b.bucket("lab-multipart").key("big.bin").uploadId(up.uploadId()).multipartUpload(m -> m.parts(done)));
        MessageDigest md = MessageDigest.getInstance("MD5");
        for (byte[] p : parts) md.update(MessageDigest.getInstance("MD5").digest(p));
        System.out.println("ETag объекта: " + c.eTag() + "; md5(склейка md5 частей)-3 = " + HexFormat.of().formatHex(md.digest()) + "-3");
        long len = s3.headObject(b -> b.bucket("lab-multipart").key("big.bin")).contentLength();
        System.out.println("размер объекта: " + len / mb + " МиБ");
        // часть меньше минимума, не последняя
        var up2 = s3.createMultipartUpload(b -> b.bucket("lab-multipart").key("small.bin"));
        var p1 = s3.uploadPart(b -> b.bucket("lab-multipart").key("small.bin").uploadId(up2.uploadId()).partNumber(1), RequestBody.fromBytes(new byte[3 * mb]));
        var p2 = s3.uploadPart(b -> b.bucket("lab-multipart").key("small.bin").uploadId(up2.uploadId()).partNumber(2), RequestBody.fromBytes(new byte[mb]));
        try {
            s3.completeMultipartUpload(b -> b.bucket("lab-multipart").key("small.bin").uploadId(up2.uploadId()).multipartUpload(m -> m.parts(
                    CompletedPart.builder().partNumber(1).eTag(p1.eTag()).build(), CompletedPart.builder().partNumber(2).eTag(p2.eTag()).build())));
            System.out.println("часть 3 МиБ не последней: принята");
        } catch (Exception e) { System.out.println("часть 3 МиБ не последней: " + err(e)); }
        // брошенная загрузка
        var list = s3.listMultipartUploads(b -> b.bucket("lab-multipart"));
        System.out.println("незавершённые загрузки: " + list.uploads().stream().map(MultipartUpload::key).toList() + " (части хранятся и тарифицируются, пока загрузку не завершат или не прервут)");
        s3.abortMultipartUpload(b -> b.bucket("lab-multipart").key("small.bin").uploadId(up2.uploadId()));
        System.out.println("после abort: " + s3.listMultipartUploads(b -> b.bucket("lab-multipart")).uploads().size());
    }

    // E5: presigned URL
    static void e5(S3Client s3) throws Exception {
        h("E5 presigned URL: загрузка и скачивание без учётных данных");
        reset(s3, "lab-presign");
        HttpClient http = HttpClient.newHttpClient();
        try (S3Presigner p = presigner()) {
            var put = p.presignPutObject(PutObjectPresignRequest.builder().signatureDuration(Duration.ofMinutes(5))
                    .putObjectRequest(b -> b.bucket("lab-presign").key("uploads/doc-1.pdf")).build());
            String u = put.url().toString();
            System.out.println("URL (подпись скрыта): " + u.replaceAll("X-Amz-Signature=[0-9a-f]+", "X-Amz-Signature=...").replaceAll("X-Amz-Credential=[^&]+", "X-Amz-Credential=..."));
            System.out.println("подписанные заголовки: " + put.signedHeaders());
            var r = http.send(HttpRequest.newBuilder(URI.create(u)).PUT(HttpRequest.BodyPublishers.ofString("PDFDATA")).build(), HttpResponse.BodyHandlers.ofString());
            System.out.println("PUT по ссылке без подписи в заголовках: HTTP " + r.statusCode());
            var get = p.presignGetObject(GetObjectPresignRequest.builder().signatureDuration(Duration.ofMinutes(5))
                    .getObjectRequest(b -> b.bucket("lab-presign").key("uploads/doc-1.pdf")).build());
            var g = http.send(HttpRequest.newBuilder(URI.create(get.url().toString())).GET().build(), HttpResponse.BodyHandlers.ofString());
            System.out.println("GET по ссылке: HTTP " + g.statusCode() + ", тело=" + g.body());
            // подмена ключа
            String other = get.url().toString().replace("doc-1.pdf", "doc-2.pdf");
            var t = http.send(HttpRequest.newBuilder(URI.create(other)).GET().build(), HttpResponse.BodyHandlers.ofString());
            System.out.println("GET с подменённым ключом: HTTP " + t.statusCode() + " " + t.body().replaceAll("(?s).*<Code>(.*?)</Code>.*", "$1"));
            // истёкшая
            var exp = p.presignGetObject(GetObjectPresignRequest.builder().signatureDuration(Duration.ofSeconds(1))
                    .getObjectRequest(b -> b.bucket("lab-presign").key("uploads/doc-1.pdf")).build());
            Thread.sleep(2500);
            var e = http.send(HttpRequest.newBuilder(URI.create(exp.url().toString())).GET().build(), HttpResponse.BodyHandlers.ofString());
            System.out.println("GET по истёкшей через 2,5 с ссылке: HTTP " + e.statusCode() + " " + e.body().replaceAll("(?s).*<Code>(.*?)</Code>.*", "$1"));
            // ограничение размера не входит в подпись PUT: можно загрузить что угодно
            var big = http.send(HttpRequest.newBuilder(URI.create(u)).PUT(HttpRequest.BodyPublishers.ofByteArray(new byte[3_000_000])).build(), HttpResponse.BodyHandlers.ofString());
            System.out.println("повторный PUT по той же ссылке с телом 3 МБ (размер заранее не ограничен): HTTP " + big.statusCode()
                    + ", размер объекта теперь " + s3.headObject(b -> b.bucket("lab-presign").key("uploads/doc-1.pdf")).contentLength());
        }
    }

    // E6: условная запись
    static void e6(S3Client s3) throws Exception {
        h("E6 условная запись: If-None-Match и If-Match");
        reset(s3, "lab-cond");
        var first = s3.putObject(b -> b.bucket("lab-cond").key("locks/job-7").ifNoneMatch("*"), RequestBody.fromString("owner=A"));
        System.out.println("первый PUT с If-None-Match: *  -> успех, ETag=" + first.eTag());
        try { s3.putObject(b -> b.bucket("lab-cond").key("locks/job-7").ifNoneMatch("*"), RequestBody.fromString("owner=B")); System.out.println("второй PUT: принят (условие не поддержано)"); }
        catch (Exception e) { System.out.println("второй PUT с If-None-Match: *  -> " + err(e)); }
        System.out.println("в объекте: " + s3.getObjectAsBytes(b -> b.bucket("lab-cond").key("locks/job-7")).asUtf8String());
        try { s3.putObject(b -> b.bucket("lab-cond").key("locks/job-7").ifMatch("\"deadbeef\""), RequestBody.fromString("owner=C")); System.out.println("PUT с чужим If-Match: принят"); }
        catch (Exception e) { System.out.println("PUT с чужим If-Match -> " + err(e)); }
        s3.putObject(b -> b.bucket("lab-cond").key("locks/job-7").ifMatch(first.eTag()), RequestBody.fromString("owner=A,v2"));
        System.out.println("PUT со своим If-Match -> успех, в объекте: " + s3.getObjectAsBytes(b -> b.bucket("lab-cond").key("locks/job-7")).asUtf8String());
    }

    // E7: версии и lifecycle
    static void e7(S3Client s3) throws Exception {
        h("E7 версии объектов, маркер удаления, lifecycle");
        reset(s3, "lab-ver");
        s3.putBucketVersioning(b -> b.bucket("lab-ver").versioningConfiguration(v -> v.status(BucketVersioningStatus.ENABLED)));
        var v1 = s3.putObject(b -> b.bucket("lab-ver").key("limits.json"), RequestBody.fromString("{\"daily\":100}"));
        var v2 = s3.putObject(b -> b.bucket("lab-ver").key("limits.json"), RequestBody.fromString("{\"daily\":500}"));
        System.out.println("версий: v1=" + v1.versionId().substring(0, 8) + "… v2=" + v2.versionId().substring(0, 8) + "…");
        var del = s3.deleteObject(b -> b.bucket("lab-ver").key("limits.json"));
        System.out.println("DELETE без versionId: deleteMarker=" + del.deleteMarker());
        try { s3.getObject(b -> b.bucket("lab-ver").key("limits.json")); } catch (Exception e) { System.out.println("GET текущей: " + err(e)); }
        System.out.println("GET версии v1: " + s3.getObjectAsBytes(b -> b.bucket("lab-ver").key("limits.json").versionId(v1.versionId())).asUtf8String());
        var lv = s3.listObjectVersions(b -> b.bucket("lab-ver"));
        System.out.println("list versions: версий=" + lv.versions().size() + ", маркеров удаления=" + lv.deleteMarkers().size());
        s3.putBucketLifecycleConfiguration(b -> b.bucket("lab-ver").lifecycleConfiguration(c -> c.rules(
                LifecycleRule.builder().id("tmp-expire").status(ExpirationStatus.ENABLED).filter(f -> f.prefix("tmp/"))
                        .expiration(e -> e.days(1)).abortIncompleteMultipartUpload(a -> a.daysAfterInitiation(1)).build())));
        var cfg = s3.getBucketLifecycleConfiguration(b -> b.bucket("lab-ver"));
        var rule = cfg.rules().get(0);
        System.out.println("lifecycle прочитан обратно: id=" + rule.id() + " prefix=" + rule.filter().prefix() + " expire=" + rule.expiration().days() + " сут, abortIncompleteMultipartUpload="
                + (rule.abortIncompleteMultipartUpload() == null ? "сервер не вернул правило" : rule.abortIncompleteMultipartUpload().daysAfterInitiation() + " сут"));
    }

    // E8: пагинация списка
    static void e8(S3Client s3) throws Exception {
        h("E8 пагинация: список по 1000 ключей");
        reset(s3, "lab-page");
        int n = 2500;
        long t0 = System.nanoTime();
        var pool = java.util.concurrent.Executors.newFixedThreadPool(16);
        List<java.util.concurrent.Future<?>> fs = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String key = String.format("p/%05d", i);
            fs.add(pool.submit(() -> s3.putObject(b -> b.bucket("lab-page").key(key), RequestBody.empty())));
        }
        for (var f : fs) f.get();
        pool.shutdown();
        System.out.println("создано " + n + " пустых объектов за " + (System.nanoTime() - t0) / 1_000_000 + " мс");
        var page = s3.listObjectsV2(b -> b.bucket("lab-page").prefix("p/"));
        System.out.println("первая страница: " + page.contents().size() + " ключей, isTruncated=" + page.isTruncated() + ", maxKeys=" + page.maxKeys() + ", есть токен продолжения=" + (page.nextContinuationToken() != null));
        int pages = 0, total = 0;
        for (var p : s3.listObjectsV2Paginator(b -> b.bucket("lab-page").prefix("p/"))) { pages++; total += p.contents().size(); }
        System.out.println("через paginator: страниц=" + pages + ", ключей=" + total);
        var small = s3.listObjectsV2(b -> b.bucket("lab-page").prefix("p/").maxKeys(5).startAfter("p/00010"));
        System.out.println("maxKeys=5 startAfter=p/00010: " + small.contents().stream().map(S3Object::key).toList() + " (сортировка по байтам UTF-8)");
    }

    // E9: загрузка потока неизвестной длины
    static void e9(S3Client s3) throws Exception {
        h("E9 загрузка потока без известной длины");
        reset(s3, "lab-stream");
        byte[] data = new byte[1_000_000];
        try {
            s3.putObject(b -> b.bucket("lab-stream").key("s1"), RequestBody.fromInputStream(new java.io.ByteArrayInputStream(data), -1));
            System.out.println("fromInputStream(in, -1): принято");
        } catch (Exception e) { System.out.println("fromInputStream(in, -1): " + err(e)); }
        try {
            s3.putObject(b -> b.bucket("lab-stream").key("s2"), RequestBody.fromContentProvider(() -> new java.io.ByteArrayInputStream(data), "application/octet-stream"));
            System.out.println("fromContentProvider без длины: принято, размер=" + s3.headObject(b -> b.bucket("lab-stream").key("s2")).contentLength());
        } catch (Exception e) { System.out.println("fromContentProvider без длины: " + err(e)); }
        try {
            s3.putObject(b -> b.bucket("lab-stream").key("s3"), RequestBody.fromInputStream(new java.io.ByteArrayInputStream(data), data.length));
            System.out.println("fromInputStream(in, длина): принято, размер=" + s3.headObject(b -> b.bucket("lab-stream").key("s3")).contentLength());
        } catch (Exception e) { System.out.println("fromInputStream(in, длина): " + err(e)); }
    }

    // E10: значения по умолчанию клиента
    static void e10() {
        h("E10 значения по умолчанию HTTP-клиента и повторов AWS SDK for Java v2");
        var d = SdkHttpConfigurationOption.GLOBAL_HTTP_DEFAULTS;
        for (var o : List.of(SdkHttpConfigurationOption.CONNECTION_TIMEOUT, SdkHttpConfigurationOption.READ_TIMEOUT, SdkHttpConfigurationOption.WRITE_TIMEOUT,
                SdkHttpConfigurationOption.CONNECTION_ACQUIRE_TIMEOUT, SdkHttpConfigurationOption.CONNECTION_MAX_IDLE_TIMEOUT, SdkHttpConfigurationOption.MAX_CONNECTIONS,
                SdkHttpConfigurationOption.TCP_KEEPALIVE)) {
            System.out.println("  " + o + " = " + d.get(o));
        }
        var rs = software.amazon.awssdk.retries.StandardRetryStrategy.builder().build();
        System.out.println("  StandardRetryStrategy.maxAttempts = " + rs.maxAttempts());
        System.out.println("  apiCallTimeout / apiCallAttemptTimeout: по умолчанию не заданы (ClientOverrideConfiguration.apiCallTimeout() = "
                + software.amazon.awssdk.core.client.config.ClientOverrideConfiguration.builder().build().apiCallTimeout() + ")");
    }

    // E11: ограничения на имя ключа у сервера
    static void e11(S3Client s3) throws Exception {
        h("E11 длина ключа и сегмента");
        reset(s3, "lab-keys");
        for (int len : new int[]{100, 127, 128, 200, 255, 256}) {
            String seg = "а".repeat(len);
            try { s3.putObject(b -> b.bucket("lab-keys").key(seg), RequestBody.fromString("x")); System.out.println("сегмент " + len + " кириллических символов (" + len * 2 + " байт): принят"); }
            catch (Exception e) { System.out.println("сегмент " + len + " кириллических символов (" + len * 2 + " байт): " + err(e)); }
        }
        String segs = ("а".repeat(100) + "/").repeat(5) + "f";
        try { s3.putObject(b -> b.bucket("lab-keys").key(segs), RequestBody.fromString("x")); System.out.println("ключ из 5 сегментов по 100 символов (1000 байт целиком): принят"); }
        catch (Exception e) { System.out.println("ключ из 5 сегментов по 100 символов (1000 байт целиком): " + err(e)); }
        for (String k : new String[]{"a//b", "a/./b", "a/../b", "/lead", "trail/"}) {
            try { s3.putObject(b -> b.bucket("lab-keys").key(k), RequestBody.fromString("x")); System.out.println("ключ '" + k + "': принят"); }
            catch (Exception e) { System.out.println("ключ '" + k + "': " + err(e)); }
        }
    }

    // E12: в каком порядке ListObjectsV2 отдаёт ключи с не-ASCII-символами
    static void e12(S3Client s3) throws Exception {
        h("E12 порядок ключей с не-ASCII-символами");
        reset(s3, "lab-order");
        String[] keys = {"реестр/Б-2026.csv", "реестр/а-2026.csv", "реестр/Z-2026.csv", "реестр/z-2026.csv", "реестр/ё-2026.csv",
                "реестр/е-2026.csv", "реестр/10.csv", "реестр/9.csv", "реестр/été.csv", "реестр/été.csv", "реестр/€.csv", "реестр/𝔸.csv", "реестр/Ａ.csv"};
        for (String k : keys) s3.putObject(b -> b.bucket("lab-order").key(k), RequestBody.fromString("x"));
        var listed = s3.listObjectsV2(b -> b.bucket("lab-order")).contents().stream().map(o -> o.key()).toList();
        var byUtf8 = new java.util.ArrayList<>(java.util.List.of(keys));
        byUtf8.sort((x, y) -> java.util.Arrays.compareUnsigned(x.getBytes(java.nio.charset.StandardCharsets.UTF_8), y.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
        var byJava = new java.util.ArrayList<>(java.util.List.of(keys));
        java.util.Collections.sort(byJava);
        System.out.println("порядок в ListObjectsV2: " + listed.stream().map(k -> k.substring(7)).toList());
        System.out.println("совпадает с побайтным порядком UTF-8: " + listed.equals(byUtf8));
        System.out.println("совпадает с String.compareTo (UTF-16): " + listed.equals(byJava) + "; порядок Java: " + byJava.stream().map(k -> k.substring(7)).toList());
        System.out.println("составное é и e+U+0301 — разные ключи: " + (listed.size() == keys.length));
    }

    static long usedMb() {
        for (int i = 0; i < 3; i++) System.gc();
        Runtime r = Runtime.getRuntime();
        return (r.totalMemory() - r.freeMemory()) / (1024 * 1024);
    }

    /** Поток выгрузки неизвестной длины: генерирует n байт строк реестра, не держа их в памяти. */
    static java.io.InputStream registryStream(long n) {
        return new java.io.InputStream() {
            long left = n;
            @Override public int read() { if (left <= 0) return -1; left--; return 'x'; }
            @Override public int read(byte[] b, int off, int len) {
                if (left <= 0) return -1;
                int k = (int) Math.min(len, left);
                java.util.Arrays.fill(b, off, off + k, (byte) 'x');
                left -= k;
                return k;
            }
        };
    }

    // E13: поток неизвестной длины — RequestBody.fromContentProvider без длины и S3TransferManager
    static void e13(S3Client s3) throws Exception {
        h("E13 поток неизвестной длины, 200 МиБ");
        reset(s3, "lab-stream");
        long size = 200L * 1024 * 1024;
        long before = usedMb();
        var peak = new java.util.concurrent.atomic.AtomicLong();
        var sampler = new Thread(() -> { while (!Thread.currentThread().isInterrupted()) {
            Runtime r = Runtime.getRuntime(); peak.accumulateAndGet((r.totalMemory() - r.freeMemory()) / (1024 * 1024), Math::max);
            try { Thread.sleep(5); } catch (InterruptedException e) { return; } } });
        sampler.setDaemon(true); sampler.start();
        long t0 = System.nanoTime();
        try {
            s3.putObject(b -> b.bucket("lab-stream").key("sync.csv"), RequestBody.fromContentProvider(() -> registryStream(size), "text/csv"));
        } catch (OutOfMemoryError e) {
            sampler.interrupt();
            System.out.println("PutObject + RequestBody.fromContentProvider без длины: OutOfMemoryError при -Xmx" + Runtime.getRuntime().maxMemory() / (1024 * 1024) + "m");
            System.gc();
        }
        sampler.interrupt();
        if (s3.listObjectsV2(b -> b.bucket("lab-stream")).keyCount() > 0) System.out.printf("PutObject + RequestBody.fromContentProvider без длины: %d мс, пик кучи %d МиБ при исходных %d МиБ, размер объекта %d МиБ%n",
                (System.nanoTime() - t0) / 1_000_000, peak.get(), before,
                s3.headObject(b -> b.bucket("lab-stream").key("sync.csv")).contentLength() / (1024 * 1024));

        try (var async = software.amazon.awssdk.services.s3.S3AsyncClient.builder().endpointOverride(URI.create(EP)).region(Region.US_EAST_1)
                .forcePathStyle(true).credentialsProvider(StaticCredentialsProvider.create(CREDS)).multipartEnabled(true).build();
             var tm = software.amazon.awssdk.transfer.s3.S3TransferManager.builder().s3Client(async).build()) {
            var exec = java.util.concurrent.Executors.newSingleThreadExecutor();
            long before2 = usedMb();
            peak.set(0);
            var sampler2 = new Thread(() -> { while (!Thread.currentThread().isInterrupted()) {
                Runtime r = Runtime.getRuntime(); peak.accumulateAndGet((r.totalMemory() - r.freeMemory()) / (1024 * 1024), Math::max);
                try { Thread.sleep(5); } catch (InterruptedException e) { return; } } });
            sampler2.setDaemon(true); sampler2.start();
            long t1 = System.nanoTime();
            var body = software.amazon.awssdk.core.async.AsyncRequestBody.fromInputStream(registryStream(size), null, exec);
            var up = tm.upload(u -> u.putObjectRequest(r -> r.bucket("lab-stream").key("tm.csv")).requestBody(body));
            up.completionFuture().join();
            sampler2.interrupt();
            exec.shutdown();
            var head = s3.headObject(b -> b.bucket("lab-stream").key("tm.csv"));
            System.out.printf("S3TransferManager.upload, AsyncRequestBody.fromInputStream без длины: %d мс, пик кучи %d МиБ при исходных %d МиБ, размер %d МиБ, ETag %s%n",
                    (System.nanoTime() - t1) / 1_000_000, peak.get(), before2, head.contentLength() / (1024 * 1024), head.eTag());
        } catch (Exception e) {
            System.out.println("S3TransferManager: " + err(e));
        }
    }

    static byte[] hmac(byte[] key, String data) throws Exception {
        var mac = javax.crypto.Mac.getInstance("HmacSHA256");
        mac.init(new javax.crypto.spec.SecretKeySpec(key, "HmacSHA256"));
        return mac.doFinal(data.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    static String put(java.net.http.HttpClient http, java.net.URL url, byte[] body) throws Exception {
        var r = http.send(java.net.http.HttpRequest.newBuilder(url.toURI()).PUT(java.net.http.HttpRequest.BodyPublishers.ofByteArray(body)).build(),
                java.net.http.HttpResponse.BodyHandlers.ofString());
        var m = java.util.regex.Pattern.compile("<Code>([^<]+)</Code>").matcher(r.body());
        return "HTTP " + r.statusCode() + (m.find() ? " " + m.group(1) : "");
    }

    /** POST-форма загрузки (браузерная загрузка в бакет) с политикой, подписанной SigV4. */
    static String postForm(java.net.http.HttpClient http, String bucket, String key, byte[] file, long maxBytes) throws Exception {
        var now = java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC);
        String date = now.format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"));
        String amzDate = now.format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"));
        String cred = CREDS.accessKeyId() + "/" + date + "/us-east-1/s3/aws4_request";
        String policy = "{\"expiration\":\"" + now.plusMinutes(10).format(java.time.format.DateTimeFormatter.ISO_INSTANT) + "\",\"conditions\":["
                + "{\"bucket\":\"" + bucket + "\"},[\"starts-with\",\"$key\",\"uploads/\"],[\"content-length-range\",1," + maxBytes + "],"
                + "{\"x-amz-algorithm\":\"AWS4-HMAC-SHA256\"},{\"x-amz-credential\":\"" + cred + "\"},{\"x-amz-date\":\"" + amzDate + "\"}]}";
        String b64 = Base64.getEncoder().encodeToString(policy.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        byte[] k = hmac(("AWS4" + CREDS.secretAccessKey()).getBytes(java.nio.charset.StandardCharsets.UTF_8), date);
        k = hmac(k, "us-east-1"); k = hmac(k, "s3"); k = hmac(k, "aws4_request");
        String sig = HexFormat.of().formatHex(hmac(k, b64));
        String boundary = "----registry" + System.nanoTime();
        var out = new java.io.ByteArrayOutputStream();
        String crlf = new String(new char[]{13, 10});
        String q = String.valueOf((char) 34);
        java.util.function.BiConsumer<String, String> field = (n, v) -> out.writeBytes(("--" + boundary + crlf + "Content-Disposition: form-data; name=" + q + n + q + crlf + crlf + v + crlf).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        field.accept("key", key); field.accept("x-amz-algorithm", "AWS4-HMAC-SHA256"); field.accept("x-amz-credential", cred);
        field.accept("x-amz-date", amzDate); field.accept("policy", b64); field.accept("x-amz-signature", sig);
        out.writeBytes(("--" + boundary + crlf + "Content-Disposition: form-data; name=" + q + "file" + q + "; filename=" + q + "r.csv" + q + crlf + "Content-Type: text/csv" + crlf + crlf).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        out.writeBytes(file);
        out.writeBytes((crlf + "--" + boundary + "--" + crlf).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        var r = http.send(java.net.http.HttpRequest.newBuilder(URI.create(EP + "/" + bucket)).header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(java.net.http.HttpRequest.BodyPublishers.ofByteArray(out.toByteArray())).build(), java.net.http.HttpResponse.BodyHandlers.ofString());
        var m = java.util.regex.Pattern.compile("<Code>([^<]+)</Code>").matcher(r.body());
        return "HTTP " + r.statusCode() + (m.find() ? " " + m.group(1) : "");
    }

    // E14: как ограничить размер загрузки по ссылке — подписанный Content-Length у PUT и POST policy с content-length-range
    static void e14(S3Client s3) throws Exception {
        h("E14 ограничение размера загрузки по ссылке");
        reset(s3, "lab-upload");
        var http = java.net.http.HttpClient.newHttpClient();
        byte[] small = "a;b;c;1".getBytes(), big = new byte[3 * 1024 * 1024];
        try (var pre = presigner()) {
            var free = pre.presignPutObject(r -> r.signatureDuration(Duration.ofMinutes(10)).putObjectRequest(p -> p.bucket("lab-upload").key("uploads/free.csv")));
            System.out.println("ссылка PUT без длины, подписанные заголовки " + free.signedHeaders().keySet() + ": 7 байт → " + put(http, free.url(), small) + "; 3 МиБ → " + put(http, free.url(), big));
            var fixed = pre.presignPutObject(r -> r.signatureDuration(Duration.ofMinutes(10)).putObjectRequest(p -> p.bucket("lab-upload").key("uploads/fixed.csv").contentLength(7L)));
            System.out.println("ссылка PUT с contentLength(7), подписанные заголовки " + fixed.signedHeaders().keySet() + ": 7 байт → " + put(http, fixed.url(), small) + "; 3 МиБ → " + put(http, fixed.url(), big));
        }
        System.out.println("POST policy, content-length-range 1..1048576: 7 байт → " + postForm(http, "lab-upload", "uploads/form-small.csv", small, 1_048_576)
                + "; 3 МиБ → " + postForm(http, "lab-upload", "uploads/form-big.csv", big, 1_048_576));
        System.out.println("объекты в бакете: " + s3.listObjectsV2(b -> b.bucket("lab-upload")).contents().stream().map(o -> o.key() + "=" + o.size()).toList());
    }
}
