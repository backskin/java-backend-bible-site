import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider
import software.amazon.awssdk.core.sync.RequestBody
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.s3.S3Client
import software.amazon.awssdk.services.s3.S3Configuration
import software.amazon.awssdk.services.s3.model.NoSuchKeyException
import software.amazon.awssdk.services.s3.model.S3Exception
import software.amazon.awssdk.services.s3.presigner.S3Presigner

private const val ENDPOINT = "http://localhost:59000"
private val creds = StaticCredentialsProvider.create(AwsBasicCredentials.create("lab", "labsecret1"))

/** Хранилище отчётов: тонкая обёртка, которая прячет SDK от остального кода. */
class ReportStore(private val s3: S3Client, private val bucket: String) {
    fun put(key: String, bytes: ByteArray, contentType: String = "application/octet-stream"): String =
        s3.putObject({ it.bucket(bucket).key(key).contentType(contentType) }, RequestBody.fromBytes(bytes)).eTag()

    /** Создаёт объект один раз: второй вызов с тем же ключом вернёт false, а не перезапишет. */
    fun putOnce(key: String, bytes: ByteArray): Boolean = try {
        s3.putObject({ it.bucket(bucket).key(key).ifNoneMatch("*") }, RequestBody.fromBytes(bytes))
        true
    } catch (e: S3Exception) {
        if (e.statusCode() == 412) false else throw e
    }

    fun get(key: String): ByteArray? = try {
        s3.getObjectAsBytes { it.bucket(bucket).key(key) }.asByteArray()
    } catch (_: NoSuchKeyException) {
        null
    }

    /** Ленивая последовательность ключей: страницы по 1000 запрашиваются по мере чтения. */
    fun keys(prefix: String): Sequence<String> =
        s3.listObjectsV2Paginator { it.bucket(bucket).prefix(prefix) }.contents().asSequence().map { it.key() }

    /** «Переименование» = копия и удаление. Если процесс оборвётся между вызовами, останутся оба ключа. */
    fun move(from: String, to: String) {
        s3.copyObject { it.sourceBucket(bucket).sourceKey(from).destinationBucket(bucket).destinationKey(to) }
        s3.deleteObject { it.bucket(bucket).key(from) }
    }

    fun uploadLink(key: String, ttl: Duration): String =
        S3Presigner.builder().endpointOverride(URI.create(ENDPOINT)).region(Region.US_EAST_1)
            .serviceConfiguration(S3Configuration.builder().pathStyleAccessEnabled(true).build())
            .credentialsProvider(creds).build().use { p ->
                p.presignPutObject { r -> r.signatureDuration(ttl).putObjectRequest { it.bucket(bucket).key(key) } }.url().toString()
            }
}

fun main() {
    S3Client.builder().endpointOverride(URI.create(ENDPOINT)).region(Region.US_EAST_1).forcePathStyle(true)
        .credentialsProvider(creds).build().use { s3 ->
            runCatching { s3.createBucket { it.bucket("lab-kotlin") } }
            val store = ReportStore(s3, "lab-kotlin")
            println("== Kotlin: ReportStore")
            println("put -> ETag " + store.put("reports/2026-10/a.csv", "id\n1\n".toByteArray(), "text/csv"))
            println("get -> " + store.get("reports/2026-10/a.csv")?.decodeToString()?.replace("\n", "\\n"))
            println("get несуществующего -> " + store.get("reports/нет"))
            println("putOnce первый раз -> " + store.putOnce("locks/close-day", "A".toByteArray()))
            println("putOnce второй раз -> " + store.putOnce("locks/close-day", "B".toByteArray()) + " (в объекте: " + store.get("locks/close-day")?.decodeToString() + ")")
            repeat(2500) { store.put("bulk/%05d".format(it), ByteArray(0)) }
            println("keys(bulk/).take(3) -> " + store.keys("bulk/").take(3).toList() + ", всего " + store.keys("bulk/").count())
            store.move("reports/2026-10/a.csv", "reports/archive/a.csv")
            println("после move -> " + store.keys("reports/").toList())
            val link = store.uploadLink("uploads/x.bin", Duration.ofMinutes(5))
            val code = HttpClient.newHttpClient().send(
                HttpRequest.newBuilder(URI.create(link)).PUT(HttpRequest.BodyPublishers.ofString("hello")).build(),
                HttpResponse.BodyHandlers.ofString()).statusCode()
            println("PUT по presigned-ссылке без ключей -> HTTP $code, объект: " + store.get("uploads/x.bin")?.decodeToString())
        }
}
