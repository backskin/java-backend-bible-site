#!/usr/bin/env bash
# Запрос на 20 с к конкретному поду, через 3 с под удаляют. Запуск: bash k8s/inflight.sh "<заголовок>" <kubeconfig>
K="$2"; kc() { kubectl --kubeconfig "$K" -n ch10 "$@"; }
pod=$(kc get pods -l app=gateway -o jsonpath='{.items[0].metadata.name}')
ip=$(kc get pod "$pod" -o jsonpath='{.status.podIP}')
kc delete pod client --ignore-not-found --wait=true >/dev/null 2>&1
kc run client --restart=Never --image=sbp-gateway:lab --image-pull-policy=Never --command -- sh -c \
  "s=\$(date +%s); r=\$(curl -s --max-time 60 -w ' code=%{http_code}' http://$ip:8080/api/transfer?ms=20000); echo \"\$r за \$(( \$(date +%s) - s )) с\"" >/dev/null
kc wait --for=condition=Ready pod/client --timeout=60s >/dev/null 2>&1
sleep 3
t0=$(date +%s)
kc delete pod "$pod" --wait=true >/dev/null
echo "== $1"
echo "   под удалён за $(( $(date +%s) - t0 )) с; запрос в обработке: $(kc logs client 2>/dev/null; kc wait --for=jsonpath='{.status.phase}'=Succeeded pod/client --timeout=60s >/dev/null 2>&1; kc logs client | sed 's/gateway-[a-z0-9-]*/<под>/')"
kc delete pod client --wait=false >/dev/null 2>&1
