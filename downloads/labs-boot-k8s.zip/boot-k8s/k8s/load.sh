#!/usr/bin/env bash
# Нагрузка на шлюз во время выкатки: 10 потоков по запросу на 200 мс, 60 секунд; печатает сводку кодов ответа.
# Запуск из labs/boot-k8s: bash k8s/load.sh "<заголовок>" <kubeconfig>
K="$2"; kc() { kubectl --kubeconfig "$K" -n ch10 "$@"; }
kc delete pod load --ignore-not-found --wait=true >/dev/null 2>&1
kc run load --restart=Never --image=sbp-gateway:lab --image-pull-policy=Never --command -- sh -c '
end=$(( $(date +%s) + 60 ))
for w in $(seq 1 10); do
  ( while [ $(date +%s) -lt $end ]; do curl -s -o /dev/null -w "%{http_code}\n" --max-time 5 "http://gateway/api/transfer?ms=200"; done > /tmp/w$w.txt ) &
done
wait
cat /tmp/w*.txt | sort | uniq -c' >/dev/null
kc wait --for=condition=Ready pod/load --timeout=60s >/dev/null 2>&1
sleep 8
kc rollout restart deploy/gateway >/dev/null
kc rollout status deploy/gateway --timeout=180s >/dev/null 2>&1
kc wait --for=jsonpath='{.status.phase}'=Succeeded pod/load --timeout=120s >/dev/null 2>&1
echo "== $1"
kc logs load | sed 's/^ */   /; s/ 000$/ 000 (соединение не установлено или оборвано)/'
kc delete pod load --wait=false >/dev/null 2>&1
