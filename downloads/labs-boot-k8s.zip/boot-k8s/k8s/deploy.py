"""Собирает манифест шлюза из шаблона и применяет его в kind (только через kubeconfig опыта).

python deploy.py KUBECONFIG run-id replicas grace probe_port liveness_path prestop_sec "ENV=V;ENV2=V2"
"""
import subprocess, sys, pathlib

kubeconfig, run, replicas, grace, probe_port, liveness, prestop, env = sys.argv[1:9]
t = (pathlib.Path(__file__).parent / "gateway.tmpl.yaml").read_text(encoding="utf-8")
env_lines = []
for pair in filter(None, env.split(";")):
    k, v = pair.split("=", 1)
    env_lines.append(f"            - {{ name: {k}, value: \"{v}\" }}")
if not env_lines:
    env_lines.append("            - { name: LAB, value: \"1\" }")
lifecycle = ""
if prestop != "0":
    lifecycle = ("          lifecycle:\n"
                 "            preStop:\n"
                 f"              exec: {{ command: [\"sh\", \"-c\", \"sleep {prestop}\"] }}")
m = (t.replace("__REPLICAS__", replicas).replace("__RUN__", run).replace("__GRACE__", grace)
      .replace("__PROBE_PORT__", probe_port).replace("__LIVENESS_PATH__", liveness)
      .replace("__ENV__", "\n".join(env_lines)).replace("__LIFECYCLE__", lifecycle))
pathlib.Path(__file__).with_name("gateway.last.yaml").write_text(m, encoding="utf-8")
subprocess.run(["kubectl", "--kubeconfig", kubeconfig, "apply", "-f", "-"], input=m.encode("utf-8"), check=True)
