#!/usr/bin/env bash
# База недоступна 60 с; сколько раз перезапустятся поды шлюза. Запуск: bash k8s/dbdown.sh "<заголовок>" <kubeconfig>
K="$2"; kc() { kubectl --kubeconfig "$K" -n ch10 "$@"; }
before=$(kc get pods -l app=gateway -o jsonpath='{range .items[*]}{.status.containerStatuses[0].restartCount}{" "}{end}')
kc scale deploy/pg --replicas=0 >/dev/null
kc wait --for=delete pod -l app=pg --timeout=60s >/dev/null 2>&1
sleep 60
mid=$(kc get pods -l app=gateway --no-headers | awk '{print $2}' | tr '\n' ' ')
after=$(kc get pods -l app=gateway -o jsonpath='{range .items[*]}{.status.containerStatuses[0].restartCount}{" "}{end}')
kc scale deploy/pg --replicas=1 >/dev/null
kc rollout status deploy/pg --timeout=120s >/dev/null 2>&1
echo "== $1"
echo "   перезапусков до: $before; после 60 с без базы: $after; готовность подов без базы: $mid"
