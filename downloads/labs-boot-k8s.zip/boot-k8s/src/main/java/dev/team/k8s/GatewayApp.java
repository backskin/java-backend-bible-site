package dev.team.k8s;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.InetAddress;

/** Шлюз СБП для опытов в Kubernetes: перевод «отправляется в НСПК» заданное число миллисекунд. */
@SpringBootApplication
public class GatewayApp {
    public static void main(String[] args) { SpringApplication.run(GatewayApp.class, args); }

    @RestController
    static class TransferController {
        @GetMapping("/api/transfer")
        String transfer(@RequestParam(defaultValue = "50") long ms) throws Exception {
            Thread.sleep(ms);
            return "ACCEPTED by " + InetAddress.getLocalHost().getHostName();
        }
    }
}
