# Spring Boot в Kubernetes: пробы на management-порту, graceful shutdown и preStop при выкатке, запросы в полете

Стенд к главе 10, раздел 7.3. Шлюз СБП `GatewayApp` (Spring Boot 4.1.1, Actuator, JDBC с PostgreSQL) упаковывается в образ `sbp-gateway:lab` и выкатывается в кластер kind из трех узлов; скрипты в `k8s/` ставят опыты: пробы на `management.server.port=8081` с адресом `127.0.0.1` и без (`deploy.py`, `gateway.tmpl.yaml`), выкатка трех подов под нагрузкой с `preStop sleep 10` и без (`load.sh`), запрос на 20 с при `terminationGracePeriodSeconds=5` (`inflight.sh`), недоступная база (`dbdown.sh`). Вывод автора - `s10-k8s.txt`, Kubernetes v1.37.0.

## Что нужно

- JDK 21, Maven, Docker, кластер kind (`kind create cluster --config k8s/base.yaml`), `kubectl`, Python 3 и bash.

## Запуск

```bash
mvn -q package -DskipTests && docker build -t sbp-gateway:lab . && kind load docker-image sbp-gateway:lab
```

Затем сценарии: `python k8s/deploy.py`, `bash k8s/load.sh`, `bash k8s/inflight.sh`, `bash k8s/dbdown.sh`; что делает каждый, написано в его шапке. В IDEA есть конфигурация `GatewayApp` для локального запуска без кластера.

## Что должно получиться

С `management.server.address=127.0.0.1` kubelet до проб не достучится и под не станет Ready; при выкатке без `preStop` часть запросов получает ошибку соединения, с `preStop sleep 10` - нет; запрос длиннее grace-периода обрывается.
