package pay;

import java.math.BigDecimal;

/** Комиссия за перевод: 1,5 % суммы, но не меньше 50 и не больше 150 рублей. */
public final class TransferFee {

    public Money fee(Money amount) {
        //КУРСОР
    }

    private static final BigDecimal RATE = new BigDecimal("0.015");
    private static final Money MIN_FEE = Money.ofMinor(5_000, "RUB");
    private static final Money MAX_FEE = Money.ofMinor(15_000, "RUB");
}
