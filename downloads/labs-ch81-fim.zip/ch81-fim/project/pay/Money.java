package pay;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Сумма в минимальных единицах валюты (копейках) и код валюты. */
public record Money(long minor, String currency) {

    public static Money ofMinor(long minor, String currency) {
        return new Money(minor, currency);
    }

    /** Доля суммы, округленная до копейки по правилу HALF_UP. */
    public Money percentOf(BigDecimal rate) {
        long value = BigDecimal.valueOf(minor).multiply(rate)
                .setScale(0, RoundingMode.HALF_UP).longValueExact();
        return new Money(value, currency);
    }

    public Money atLeast(Money floor) {
        return minor < floor.minor ? floor : this;
    }

    public Money atMost(Money ceiling) {
        return minor > ceiling.minor ? ceiling : this;
    }
}
