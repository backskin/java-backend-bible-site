import javax.tools.ToolProvider;
import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.URLClassLoader;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Как автодополнение кода получает контекст: модель дописывает тело метода TransferFee.fee
 * в трех режимах, а стенд подставляет ответ в файл, компилирует его и проверяет на трех суммах.
 *
 * <ul>
 *   <li>PREFIX - модель видит только текст выше курсора, как обычное продолжение текста;</li>
 *   <li>FIM - fill-in-the-middle: модель видит и текст выше курсора, и текст ниже него;</li>
 *   <li>FIM+СОСЕД - то же, плюс соседний файл Money.java в виде комментария в начале,
 *       так автодополнение в IDE подмешивает открытые вкладки.</li>
 * </ul>
 *
 * Запуск: java src/FimLab.java [модели через запятую] [число попыток с температурой 0.8].
 * Нужен Ollama на 127.0.0.1:11434 с моделями qwen2.5-coder (README.md).
 */
public class FimLab {

    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    static final String CURSOR = "//КУРСОР";

    public static void main(String[] args) throws Exception {
        List<String> models = List.of((args.length > 0 ? args[0] : "qwen2.5-coder:1.5b,qwen2.5-coder:7b").split(","));
        int samples = args.length > 1 ? Integer.parseInt(args[1]) : 10;
        Path project = Path.of("project/pay");
        String money = Files.readString(project.resolve("Money.java"));
        String target = Files.readString(project.resolve("TransferFee.java"));
        int at = target.indexOf(CURSOR);
        String prefix = target.substring(0, at);
        String suffix = target.substring(at + CURSOR.length());
        // Соседний файл в начале промпта комментарием с путем - так собирает контекст Copilot.
        String neighbor = "// Path: pay/Money.java\n" + money.lines().map(l -> "// " + l)
                .reduce("", (a, b) -> a + b + "\n") + "// Path: pay/TransferFee.java\n";

        for (String model : models) {
            System.out.println("=== модель " + model + ", температура 0");
            for (Mode mode : Mode.values()) {
                Result r = complete(model, mode, prefix, suffix, neighbor, 0.0);
                System.out.printf("%-10s %s | промпт %d ток., ответ %d ток., %.1f ток./с, всего %.1f с%n",
                        mode.label, check(money, prefix, r.middle, suffix), r.promptTokens, r.evalTokens,
                        r.tokensPerSecond(), r.totalSeconds());
                System.out.println("           тело: " + r.middle.strip().replace("\n", "\n                 "));
            }
        }
        for (String model : samples > 0 ? models : List.<String>of()) {
            System.out.println("=== модель " + model + ", температура 0.8, попыток " + samples);
            for (Mode mode : Mode.values()) {
                int compiled = 0, correct = 0;
                for (int i = 0; i < samples; i++) {
                    String verdict = check(money, prefix, complete(model, mode, prefix, suffix, neighbor, 0.8).middle, suffix);
                    if (!verdict.startsWith("не компилируется")) compiled++;
                    if (verdict.startsWith("верно")) correct++;
                }
                System.out.printf("%-10s компилируется %d из %d, верно %d из %d%n", mode.label, compiled, samples, correct, samples);
            }
        }
    }

    enum Mode {
        PREFIX("PREFIX"), FIM("FIM"), FIM_NEIGHBOR("FIM+СОСЕД");
        final String label;
        Mode(String label) { this.label = label; }
    }

    record Result(String middle, long promptTokens, long evalTokens, long evalNanos, long totalNanos) {
        double tokensPerSecond() { return evalNanos == 0 ? 0 : evalTokens * 1e9 / evalNanos; }
        double totalSeconds() { return totalNanos / 1e9; }
    }

    static Result complete(String model, Mode mode, String prefix, String suffix, String neighbor, double temperature) throws Exception {
        String body;
        if (mode == Mode.PREFIX) {
            // raw: текст уходит в модель как есть, без шаблона чата и без суффикса.
            body = "{\"model\":\"%s\",\"prompt\":%s,\"raw\":true,\"stream\":false,\"options\":{\"temperature\":%s,\"num_predict\":200%s}}"
                    .formatted(model, json(prefix), temperature, seed(temperature));
        } else {
            // Есть suffix - Ollama собирает промпт по шаблону модели: <|fim_prefix|>…<|fim_suffix|>…<|fim_middle|>.
            String p = mode == Mode.FIM_NEIGHBOR ? neighbor + prefix : prefix;
            body = "{\"model\":\"%s\",\"prompt\":%s,\"suffix\":%s,\"stream\":false,\"options\":{\"temperature\":%s,\"num_predict\":200%s}}"
                    .formatted(model, json(p), json(suffix), temperature, seed(temperature));
        }
        HttpRequest request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:11434/api/generate"))
                .timeout(Duration.ofMinutes(5)).POST(HttpRequest.BodyPublishers.ofString(body)).build();
        String out = HTTP.send(request, HttpResponse.BodyHandlers.ofString()).body();
        String text = unjson(field(out, "\"response\":\"((?:[^\"\\\\]|\\\\.)*)\""));
        if (mode == Mode.PREFIX) text = untilMethodEnds(text);
        return new Result(text, num(out, "prompt_eval_count"), num(out, "eval_count"),
                num(out, "eval_duration"), num(out, "total_duration"));
    }

    /** При температуре 0 фиксируем зерно, при выборке каждая попытка получает свое, иначе все попытки совпадут. */
    static String seed(double temperature) {
        return temperature == 0 ? ",\"seed\":7" : "";
    }

    /** Продолжение без суффикса не знает, где остановиться: берем текст до закрывающей скобки метода. */
    static String untilMethodEnds(String text) {
        int depth = 1;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '{') depth++;
            if (c == '}' && --depth == 0) return text.substring(0, i);
        }
        return text;
    }

    /** Подставляет тело в файл, компилирует вместе с Money.java и проверяет 1000, 5000 и 12 500 рублей. */
    static String check(String money, String prefix, String middle, String suffix) throws Exception {
        Path dir = Files.createTempDirectory("fim");
        Path src = Files.createDirectories(dir.resolve("pay"));
        Files.writeString(src.resolve("Money.java"), money);
        Files.writeString(src.resolve("TransferFee.java"), prefix + middle + suffix);
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        int rc = ToolProvider.getSystemJavaCompiler().run(null, null, err, "-d", dir.toString(),
                src.resolve("Money.java").toString(), src.resolve("TransferFee.java").toString());
        if (rc != 0) {
            String first = err.toString().lines().filter(l -> l.contains("error:")).findFirst().orElse("?");
            return "не компилируется: " + first.substring(first.indexOf("error:") + 7);
        }
        try (URLClassLoader cl = new URLClassLoader(new java.net.URL[]{dir.toUri().toURL()})) {
            Class<?> moneyType = cl.loadClass("pay.Money");
            Object fee = cl.loadClass("pay.TransferFee").getConstructor().newInstance();
            var ofMinor = moneyType.getMethod("ofMinor", long.class, String.class);
            var feeMethod = fee.getClass().getMethod("fee", moneyType);
            long[][] cases = {{100_000, 5_000}, {500_000, 7_500}, {1_250_000, 15_000}};
            StringBuilder got = new StringBuilder();
            boolean ok = true;
            for (long[] c : cases) {
                Object r = feeMethod.invoke(fee, ofMinor.invoke(null, c[0], "RUB"));
                long minor = (long) moneyType.getMethod("minor").invoke(r);
                got.append(c[0] / 100).append("->").append(minor / 100.0).append(' ');
                ok &= minor == c[1];
            }
            return (ok ? "верно       " : "неверно     ") + got.toString().strip();
        } catch (ReflectiveOperationException e) {
            return "ошибка при вызове: " + (e.getCause() != null ? e.getCause() : e);
        }
    }

    static String json(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> b.append(c < 0x20 ? String.format("\\u%04x", (int) c) : String.valueOf(c));
            }
        }
        return b.append('"').toString();
    }

    static String unjson(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '\\') { b.append(c); continue; }
            char n = s.charAt(++i);
            switch (n) {
                case 'n' -> b.append('\n');
                case 't' -> b.append('\t');
                case 'r' -> b.append('\r');
                case 'u' -> { b.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; }
                default -> b.append(n);
            }
        }
        return b.toString();
    }

    static String field(String json, String regex) {
        Matcher m = Pattern.compile(regex).matcher(json);
        if (!m.find()) throw new IllegalStateException("нет поля в ответе: " + json);
        return m.group(1);
    }

    static long num(String json, String name) {
        Matcher m = Pattern.compile("\"" + name + "\":(\\d+)").matcher(json);
        return m.find() ? Long.parseLong(m.group(1)) : 0;
    }
}
