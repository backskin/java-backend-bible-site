# Миграция с Java 8 на 25: что удалено и что изменилось, проверка на JDK 11, 17, 21, 25 и 26

Стенд к главе 02, раздел 8. Программы в `src/` запускаются на нескольких JDK подряд, чтобы увидеть разницу: `SecurityManagerCheck` (установка менеджера безопасности на 17, 21 и 25), `Finalization` (`--finalization=disabled` и `Cleaner`), `ThreadApis` (`Thread.stop()` на 17 и позже), `UnsafeMemory` (методы `Unsafe` для памяти на 21, 25 и 26), `DefaultCharset` (кодировка по умолчанию до и после JEP 400). `migration.sh` - опыты из командной строки: JAXB в JDK 11+, `--illegal-access`, `jdeps`, `-source/-target` против `--release`, удаленные флаги JVM. Выводы автора - в `s8-*.txt`.

## Что нужно

- Temurin JDK 11.0.29, 17.0.17, 21.0.10, 25.0.5 и 26.0.2.1 в `~/.jdks` (словарь `ALL` в `run.py`, переменные `J11`–`J25` в `migration.sh`). Если какой-то версии нет, уберите ее из строки `// JDKS:` в заголовке программы.
- Python 3 и sh (Git Bash на Windows).

## Запуск

```bash
python -X utf8 run.py
```

```bash
sh migration.sh > s8-migration.txt 2>&1
```

## Что должно получиться

На 17 `Thread.stop()` еще работает, на 21 бросает `UnsupportedOperationException`; `setSecurityManager` на 17 ставит менеджер с предупреждением, на 25 бросает исключение; на 26 `Unsafe.allocateMemory` печатает предупреждение при первом вызове. Кодировка по умолчанию на 17 зависит от системы (у автора `windows-1251`), с 18 всегда UTF-8.
