#!/bin/sh
# Опыты раздела 8: JAXB, --illegal-access, String.value, jdeps, -source/-target против --release,
# устаревшие флаги JVM и SecurityManager из командной строки.
# Запуск: sh migration.sh > s8-migration.txt 2>&1
cd "$(dirname "$0")"
J11=~/.jdks/temurin-11.0.29/bin; J17=~/.jdks/temurin-17.0.17/bin; J21=~/.jdks/temurin-21.0.10/bin; J25=~/.jdks/jdk-25.0.5+8/bin
T=$(mktemp -d)
L="-J-Duser.language=en"
cat > $T/UseJaxb.java <<'J'
import javax.xml.bind.JAXBContext;
public class UseJaxb { public static void main(String[] a) { System.out.println(JAXBContext.class); } }
J
cat > $T/Hello.java <<'J'
public class Hello {
    public static void main(String[] a) throws Exception {
        System.out.println("hello");
        var f = String.class.getDeclaredField("value");
        f.setAccessible(true);
        System.out.println("String.value opened");
    }
}
J
cat > $T/NewApi.java <<'J'
import java.util.stream.Stream;
public class NewApi { public static void main(String[] a) { System.out.println(Stream.of("RUB", "USD").toList()); } }
J
echo "== 1. JAXB в JDK 11+"
echo '$ javac --release 21 UseJaxb.java'; (cd $T && $J21/javac $L --release 21 UseJaxb.java 2>&1 | head -2)
echo "== 2. --illegal-access и рефлексия во внутренности java.base"
for J in $J11 $J17 $J21; do echo "# $($J/java -version 2>&1 | head -1)"; (cd $T && $J/javac -d . Hello.java 2>/dev/null; $J/java -Duser.language=en --illegal-access=permit -cp . Hello 2>&1 | sed 's/^\tat .*//' | grep -v '^$' | head -4); done
echo '$ java --add-opens java.base/java.lang=ALL-UNNAMED -cp . Hello  (JDK 21)'; (cd $T && $J21/java --add-opens java.base/java.lang=ALL-UNNAMED -cp . Hello 2>&1)
echo "== 3. jdeps --jdk-internals по guava-18.0.jar"
$J21/jdeps --jdk-internals --multi-release 21 ~/.m2/repository/com/google/guava/guava/18.0/guava-18.0.jar 2>&1 | head -12 | sed "s#$HOME#~#g"
echo "== 4. -source/-target против --release: Stream.toList() (Java 16) в коде для Java 11"
echo '$ javac (JDK 21) -source 11 -target 11 NewApi.java; java (JDK 11) NewApi'
(cd $T && mkdir -p st && $J21/javac $L -source 11 -target 11 -d st NewApi.java 2>&1 | head -2; $J11/java -cp st NewApi 2>&1 | head -2)
echo '$ javac (JDK 21) --release 11 NewApi.java'
(cd $T && $J21/javac $L --release 11 -d st2 NewApi.java 2>&1 | head -3)
echo "== 5. Удалённые флаги JVM"
for J in $J17 $J21 $J25; do echo "# $($J/java -version 2>&1 | head -1)"; $J/java -XX:+UseBiasedLocking -version 2>&1 | grep -v "^openjdk\|^OpenJDK Runtime\|^OpenJDK 64-Bit Server VM (" ; done
for J in $J21 $J25; do echo "# $($J/java -version 2>&1 | head -1): -Djdk.tracePinnedThreads=full"; $J/java -Djdk.tracePinnedThreads=full -version 2>&1 | grep -v "^openjdk\|^OpenJDK" ; echo "  (код возврата $?)"; done
echo "== 6. -Djava.security.manager=allow"
for J in $J17 $J21 $J25; do echo "# $($J/java -version 2>&1 | head -1)"; (cd $T && $J/javac -d . Hello.java 2>/dev/null; $J/java -Djava.security.manager=allow -cp . Hello 2>&1 | head -2); done
rm -rf $T
