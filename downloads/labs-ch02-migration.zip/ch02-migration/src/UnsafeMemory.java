// JDKS: 21 25 26
// OUT: s8-unsafe-memory
// Методы памяти sun.misc.Unsafe: deprecated for removal в 23 (JEP 471), предупреждение при первом вызове в 24+ (JEP 498).
import java.lang.reflect.Field;

public class UnsafeMemory {
    public static void main(String[] args) throws Exception {
        Field f = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        sun.misc.Unsafe unsafe = (sun.misc.Unsafe) f.get(null);
        try {
            long address = unsafe.allocateMemory(64);
            unsafe.putLong(address, 15_000L);
            System.out.println("java " + System.getProperty("java.version") + ": allocateMemory/putLong/getLong = " + unsafe.getLong(address));
            unsafe.freeMemory(address);
        } catch (UnsupportedOperationException e) {
            System.out.println("java " + System.getProperty("java.version") + ": " + e);
        }
    }
}
