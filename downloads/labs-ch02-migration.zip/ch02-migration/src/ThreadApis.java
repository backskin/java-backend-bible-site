// JDKS: 17 21 25
// OUT: s8-thread-apis
// Thread.stop бросает UnsupportedOperationException с 20; Thread.getId deprecated с 19.
public class ThreadApis {
    @SuppressWarnings({"removal", "deprecation"})
    public static void main(String[] args) throws Exception {
        Thread t = new Thread(() -> { try { Thread.sleep(5_000); } catch (InterruptedException e) { } });
        t.start();
        try {
            t.stop();
            System.out.println("java " + System.getProperty("java.version") + ": Thread.stop() отработал");
        } catch (UnsupportedOperationException e) {
            System.out.println("java " + System.getProperty("java.version") + ": Thread.stop(): " + e.getClass().getSimpleName());
            t.interrupt();
        }
        t.join();
    }
}
