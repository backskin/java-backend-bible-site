// JDKS: 17 21 25
// OUT: s8-security-manager
// SecurityManager: deprecated в 17 (JEP 411), отключён навсегда в 24 (JEP 486).
public class SecurityManagerCheck {
    public static void main(String[] args) {
        System.out.println("java " + System.getProperty("java.version") + ", getSecurityManager() = " + System.getSecurityManager());
        try {
            System.setSecurityManager(new SecurityManager());
            System.out.println("setSecurityManager: установлен");
            System.setSecurityManager(null);
        } catch (UnsupportedOperationException e) {
            System.out.println("setSecurityManager: " + e);
        }
        String r = java.security.AccessController.doPrivileged((java.security.PrivilegedAction<String>) () -> "doPrivileged просто вызвал действие");
        System.out.println(r);
    }
}
