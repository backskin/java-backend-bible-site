// JDKS: 17 21 25
// OUT: s8-default-charset
// JEP 400 (18): UTF-8 по умолчанию. Запуск на Windows с русской локалью.
import java.nio.charset.Charset;

public class DefaultCharset {
    public static void main(String[] args) {
        System.out.println("java " + System.getProperty("java.version") + ": Charset.defaultCharset() = " + Charset.defaultCharset()
                + ", file.encoding = " + System.getProperty("file.encoding")
                + ", native.encoding = " + System.getProperty("native.encoding")
                + ", \"Тундра\".getBytes().length = " + "Тундра".getBytes().length);
    }
}
