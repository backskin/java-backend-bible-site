// JDKS: 21 25
// JAVA: --finalization=disabled
// OUT: s8-finalization
// Финализация: deprecated for removal в 18 (JEP 421); с --finalization=disabled finalize() не вызывается, Cleaner работает.
import java.lang.ref.Cleaner;

public class Finalization {
    static volatile boolean finalized, cleaned;

    static class LegacyFileHandle {
        @Override
        @SuppressWarnings("removal")
        protected void finalize() { finalized = true; }
    }

    public static void main(String[] args) throws Exception {
        Cleaner cleaner = Cleaner.create();
        Object owner = new Object();
        cleaner.register(owner, () -> cleaned = true);
        new LegacyFileHandle();
        owner = null;
        for (int i = 0; i < 20 && !(cleaned); i++) { System.gc(); Thread.sleep(50); }
        System.out.println("java " + System.getProperty("java.version") + " с --finalization=disabled: finalize() вызван: " + finalized + ", действие Cleaner выполнено: " + cleaned);
    }
}
