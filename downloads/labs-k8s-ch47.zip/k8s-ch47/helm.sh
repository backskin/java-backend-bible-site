#!/bin/bash
# Опыт 8.5 гл. 47: миграция как hook Helm 4.3.1 на kind (Kubernetes 1.37).
# Три выката: install v1, upgrade v2, upgrade v3 с падающей миграцией. Для каждого — когда отработала Job
# миграции и когда стартовали поды новой версии; после падения — что осталось работать.
# Запуск: bash labs/k8s-ch47/helm.sh > labs/k8s-ch47/s47-helm.txt
export MSYS_NO_PATHCONV=1
cd "$(dirname "$0")"
H=~/bin/helm.exe; ns=ch47h
kubectl delete ns $ns --ignore-not-found --wait >/dev/null; kubectl create ns $ns >/dev/null
show(){
  echo "  Job миграции: $(kubectl -n $ns logs job/orders-migrate 2>/dev/null | tr '\n' ' ') успешно: $(kubectl -n $ns get job orders-migrate -o jsonpath='{.status.succeeded}' 2>/dev/null) упало: $(kubectl -n $ns get job orders-migrate -o jsonpath='{.status.failed}' 2>/dev/null)"
  echo "  поды сервиса:"
  for p in $(kubectl -n $ns get pods -l app=orders-helm -o name); do echo "    ${p#pod/}  $(kubectl -n $ns get $p -o jsonpath='{.metadata.labels.version} {.status.phase}')  $(kubectl -n $ns logs $p 2>/dev/null)"; done
  echo "  helm history: $($H -n $ns history orders -o json 2>/dev/null | python -c "import json,sys;print(' '.join(str(r['revision'])+':'+r['status'] for r in json.load(sys.stdin)))")"
}
echo "=== 8.5 helm install v1"
$H -n $ns install orders ./helm-orders --set version=v1 --wait --timeout 3m 2>&1 | grep -E "^(STATUS|Error)" | sed 's/^/  /'
show
echo "=== 8.5 helm upgrade v2"
$H -n $ns upgrade orders ./helm-orders --set version=v2 --wait --timeout 3m 2>&1 | grep -E "^(STATUS|Error)" | sed 's/^/  /'
show
echo "=== 8.5 helm upgrade v3, миграция падает"
$H -n $ns upgrade orders ./helm-orders --set version=v3 --set failMigration=true --wait --timeout 3m 2>&1 | grep -E "^(STATUS|Error)" | cut -c1-160 | sed 's/^/  /'
sleep 3
show
kubectl delete ns $ns --wait=false >/dev/null
