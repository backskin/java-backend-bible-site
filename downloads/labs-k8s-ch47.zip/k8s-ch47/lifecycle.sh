#!/bin/bash
# Опыты гл. 47 на kind (Kubernetes 1.37): сообщение о завершении, postStart, readiness gates.
# Запуск: bash labs/k8s-ch47/lifecycle.sh > labs/k8s-ch47/s47-lifecycle.txt
export MSYS_NO_PATHCONV=1
ns=ch47
kubectl -n $ns delete pod tm-file tm-logs ps-slow ps-fail rg --ignore-not-found --wait >/dev/null

kubectl -n $ns apply -f - >/dev/null <<'EOF'
apiVersion: v1
kind: Pod
metadata: {name: tm-file}
spec:
  restartPolicy: Never
  containers:
    - name: app
      image: busybox:1.36
      # приложение само пишет причину в /dev/termination-log и выходит с кодом 3
      command: ["sh", "-c", "echo 'payments: нет соединения с БД ledger после 5 попыток' > /dev/termination-log; exit 3"]
---
apiVersion: v1
kind: Pod
metadata: {name: tm-logs}
spec:
  restartPolicy: Never
  containers:
    - name: app
      image: busybox:1.36
      terminationMessagePolicy: FallbackToLogsOnError
      # ничего не пишет в файл, падает с трассой стека в stdout
      command:
        - sh
        - -c
        - |
          echo 'Started PaymentsApplication'
          echo 'Exception in thread main java.lang.IllegalStateException: ledger.url не задан'
          echo '    at dev.team.payments.Config.ledger(Config.java:41)'
          exit 1
EOF
for p in tm-file tm-logs; do kubectl -n $ns wait --for=jsonpath='{.status.phase}'=Failed pod/$p --timeout=120s >/dev/null; done
echo "=== 9.5 сообщение о завершении контейнера"
for p in tm-file tm-logs; do
  echo "  $p: exitCode=$(kubectl -n $ns get pod $p -o jsonpath='{.status.containerStatuses[0].state.terminated.exitCode}') reason=$(kubectl -n $ns get pod $p -o jsonpath='{.status.containerStatuses[0].state.terminated.reason}')"
  kubectl -n $ns get pod $p -o jsonpath='{.status.containerStatuses[0].state.terminated.message}' | sed 's/^/      message: /'
done
echo "  в kubectl describe pod tm-file:"
kubectl -n $ns describe pod tm-file | grep -A1 -E "^\s+Message:" | sed 's/^/    /'

kubectl -n $ns apply -f - >/dev/null <<'EOF'
apiVersion: v1
kind: Pod
metadata: {name: ps-slow}
spec:
  containers:
    - name: app
      image: busybox:1.36
      command: ["sh", "-c", "echo старт основного процесса $(date +%T); sleep 3600"]
      lifecycle:
        postStart:
          exec: {command: ["sh", "-c", "sleep 15"]}
---
apiVersion: v1
kind: Pod
metadata: {name: ps-fail}
spec:
  containers:
    - name: app
      image: busybox:1.36
      command: ["sh", "-c", "sleep 3600"]
      lifecycle:
        postStart:
          exec: {command: ["sh", "-c", "echo 'нет ключа шифрования' >&2; exit 1"]}
EOF
echo "=== 7.2 postStart: что видно, пока хук работает (хук спит 15 с)"
t0=$(date +%s)
for i in $(seq 1 10); do
  st=$(kubectl -n $ns get pod ps-slow -o jsonpath='{.status.phase} {.status.containerStatuses[0].state}' 2>/dev/null | sed 's/"startedAt":"[^"]*"/…/; s/"reason":"\([^"]*\)"/\1/')
  echo "  +$(( $(date +%s) - t0 )) с  $st"
  case "$st" in Running*running*) break;; esac
  sleep 3
done
kubectl -n $ns logs ps-slow | sed 's/^/  лог: /'
sleep 20
echo "=== 7.2 postStart с ошибкой: контейнер убит, ждёт перезапуска"
kubectl -n $ns get pod ps-fail -o jsonpath='  restartCount={.status.containerStatuses[0].restartCount} state={.status.containerStatuses[0].state}{"\n"}' | sed 's/"startedAt":"[^"]*",\?//; s/"finishedAt":"[^"]*",\?//'
kubectl -n $ns get events --field-selector involvedObject.name=ps-fail -o jsonpath='{range .items[*]}{.reason}: {.message}{"\n"}{end}' | grep -i -E "poststart|hook" | sort -u | head -3 | sed 's/^/  событие /'

kubectl -n $ns apply -f - >/dev/null <<'EOF'
apiVersion: v1
kind: Pod
metadata: {name: rg}
spec:
  readinessGates:
    - conditionType: "example.com/lb-registered"
  containers:
    - name: app
      image: busybox:1.36
      command: ["sh", "-c", "sleep 3600"]
EOF
kubectl -n $ns wait --for=condition=ContainersReady pod/rg --timeout=120s >/dev/null
echo "=== 5.9 readiness gate: контейнер готов, под — нет, пока внешний контроллер не поставит условие"
show(){ kubectl -n $ns get pod rg -o jsonpath='{range .status.conditions[*]}{.type}={.status} {end}{"\n"}'; }
echo "  до:    $(show)"
echo "  READY в kubectl get: $(kubectl -n $ns get pod rg --no-headers | awk '{print $2}')"
kubectl -n $ns patch pod rg --subresource=status --type=json \
  -p '[{"op":"add","path":"/status/conditions/-","value":{"type":"example.com/lb-registered","status":"True","lastTransitionTime":"2026-10-28T00:00:00Z"}}]' >/dev/null
sleep 3
echo "  после: $(show)"
kubectl -n $ns delete pod tm-file tm-logs ps-slow ps-fail rg --wait=false >/dev/null
