import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * Опыт 6.3 гл. 47, уточнение: то же, что Burn.java (восемь потоков жгут процессор), но ещё печатает
 * сборщик мусора, время JIT-компиляции и потраченное контейнером процессорное время (usage_usec из cpu.stat),
 * а с аргументом warm сначала 3 секунды прогревает цикл и только потом меряет.
 * Запуск в контейнере: java /src/Burn2.java [warm]   (JDK 21, cgroup v2)
 */
public class Burn2 {

    static String cgroup(String file) {
        try { return Files.readString(Path.of("/sys/fs/cgroup/" + file)).trim(); } catch (Exception e) { return ""; }
    }

    static long usageUsec() {
        for (String l : cgroup("cpu.stat").split("\n")) if (l.startsWith("usage_usec ")) return Long.parseLong(l.substring(11).trim());
        return -1;
    }

    static long burn(int threads, long nanos) throws InterruptedException {
        AtomicLong work = new AtomicLong();
        long end = System.nanoTime() + nanos;
        Thread[] ts = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            ts[i] = new Thread(() -> {
                long local = 0;
                double x = 0;
                while (System.nanoTime() < end) { for (int k = 0; k < 20_000; k++) x += Math.sqrt(k + x % 7); local++; }
                work.addAndGet(local);
                if (x == 42) System.out.print("");
            });
            ts[i].start();
        }
        for (Thread t : ts) t.join();
        return work.get();
    }

    public static void main(String[] args) throws Exception {
        boolean warm = args.length > 0 && args[0].equals("warm");
        String gc = ManagementFactory.getGarbageCollectorMXBeans().stream().map(b -> b.getName()).collect(Collectors.joining(", "));
        System.out.println("процессоров " + Runtime.getRuntime().availableProcessors() + "; cpu.max " + cgroup("cpu.max") + "; сборщик: " + gc);
        if (warm) burn(8, 3_000_000_000L);
        long jit0 = ManagementFactory.getCompilationMXBean().getTotalCompilationTime();
        long u0 = usageUsec(), t0 = System.nanoTime();
        long work = burn(8, 10_000_000_000L);
        long u1 = usageUsec(), t1 = System.nanoTime();
        long jit1 = ManagementFactory.getCompilationMXBean().getTotalCompilationTime();
        double cpuSec = (u1 - u0) / 1e6, wallSec = (t1 - t0) / 1e9;
        System.out.printf("%s: работы %d; процессорного времени %.2f с за %.2f с (%.2f ядра); работы на секунду процессора %.0f; JIT за замер %d мс%n",
                warm ? "после прогрева" : "без прогрева", work, cpuSec, wallSec, cpuSec / wallSec, work / cpuSec, jit1 - jit0);
    }
}
