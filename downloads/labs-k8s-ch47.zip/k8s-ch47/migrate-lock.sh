#!/bin/bash
# Опыт 8.5 гл. 47 на kind (Kubernetes 1.37, PostgreSQL 17): под с миграцией убит посреди работы — остаётся ли блокировка.
# Liquibase держит блокировку строкой LOCKED=TRUE в таблице DATABASECHANGELOGLOCK, Flyway — advisory lock сессии PostgreSQL.
# Запуск: bash labs/k8s-ch47/migrate-lock.sh > labs/k8s-ch47/s47-migrate-lock.txt
export MSYS_NO_PATHCONV=1
ns=ch47
# в liquibase 5.0.4 драйвера PostgreSQL в образе нет («Cannot find database driver»), поэтому 4.33.0
LQ=${LQ:-liquibase/liquibase:4.33.0}
FW=flyway/flyway:13.11.1
pg=$(kubectl -n ai get pod -l app=pg17 -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
[ -z "$pg" ] && pg=$(kubectl -n ai get pods --no-headers | awk '/^pg17-/{print $1; exit}')
sql(){ kubectl -n ai exec "$pg" -- psql -U postgres -d "$1" -tAc "$2"; }
kubectl -n $ns delete pod lq-1 lq-2 fw-1 fw-2 --ignore-not-found --force --grace-period=0 >/dev/null 2>&1
for db in mig_lq mig_fw; do sql postgres "DROP DATABASE IF EXISTS $db WITH (FORCE)" >/dev/null; sql postgres "CREATE DATABASE $db" >/dev/null; done
kubectl -n $ns create configmap mig --dry-run=client -o yaml \
  --from-literal=changelog.yaml='databaseChangeLog:
  - changeSet:
      id: 1-slow
      author: dev.team
      changes:
        - sql: {sql: "select pg_sleep(60)"}' \
  --from-literal=V1__slow.sql='select pg_sleep(60);' | kubectl apply -f - >/dev/null

run(){ # имя образ команда...
  local name=$1 image=$2; shift 2
  local args=""; for a in "$@"; do args="$args\"$a\", "; done
  kubectl -n $ns apply -f - >/dev/null <<EOF
apiVersion: v1
kind: Pod
metadata: {name: $name}
spec:
  restartPolicy: Never
  containers:
    - name: m
      image: $image
      args: [${args%, }]
      volumeMounts: [{name: mig, mountPath: /mig}]
  volumes: [{name: mig, configMap: {name: mig}}]
EOF
}

echo "=== 8.5 Liquibase ($LQ): под убит посреди миграции"
run lq-1 $LQ --url=jdbc:postgresql://pg17.ai:5432/mig_lq --username=postgres --password=x --search-path=/mig --changelog-file=changelog.yaml update
for i in $(seq 1 60); do [ "$(sql mig_lq "select count(*) from pg_stat_activity where query like 'select pg_sleep%'" 2>/dev/null)" = 1 ] && break; sleep 2; done
echo "  миграция идёт; блокировка: $(sql mig_lq 'select locked, lockedby is not null from databasechangeloglock')"
kubectl -n $ns delete pod lq-1 --force --grace-period=0 >/dev/null 2>&1
sleep 5
echo "  под убит (kill -9); блокировка: $(sql mig_lq 'select locked from databasechangeloglock'); применено изменений: $(sql mig_lq 'select count(*) from databasechangelog')"
run lq-2 $LQ --url=jdbc:postgresql://pg17.ai:5432/mig_lq --username=postgres --password=x --search-path=/mig --changelog-file=changelog.yaml update
sleep 45
echo "  второй запуск через 45 с, последние строки лога:"
kubectl -n $ns logs lq-2 2>&1 | grep -v "^\s*$" | tail -3 | cut -c1-150 | sed 's/^/    /'
kubectl -n $ns delete pod lq-2 --force --grace-period=0 >/dev/null 2>&1

echo "=== 8.5 Flyway ($FW): под убит посреди миграции"
run fw-1 $FW -url=jdbc:postgresql://pg17.ai:5432/mig_fw -user=postgres -password=x -locations=filesystem:/mig migrate
for i in $(seq 1 60); do [ "$(sql mig_fw "select count(*) from pg_stat_activity where query like 'select pg_sleep%'" 2>/dev/null)" = 1 ] && break; sleep 2; done
echo "  миграция идёт; advisory-блокировок в БД: $(sql mig_fw "select count(*) from pg_locks where locktype='advisory'")"
kubectl -n $ns delete pod fw-1 --force --grace-period=0 >/dev/null 2>&1
sleep 5
echo "  под убит (kill -9); advisory-блокировок: $(sql mig_fw "select count(*) from pg_locks where locktype='advisory'")"
echo "  сессии к mig_fw после убийства клиента (pid, состояние, запрос):"
sql mig_fw "select pid, state, left(query,40) from pg_stat_activity where datname='mig_fw' and pid<>pg_backend_pid()" | sed 's/^/    /'
old=$(sql mig_fw "select pid from pg_stat_activity where datname='mig_fw' and pid<>pg_backend_pid() and query like 'select pg_sleep%' limit 1")
run fw-2 $FW -url=jdbc:postgresql://pg17.ai:5432/mig_fw -user=postgres -password=x -locations=filesystem:/mig migrate
kubectl -n $ns wait --for=condition=Ready pod/fw-2 --timeout=120s >/dev/null 2>&1
for i in $(seq 1 30); do [ "$(sql mig_fw "select count(*) from pg_stat_activity where query like 'select pg_sleep%' and pid<>${old:-0}" 2>/dev/null)" = 1 ] && break; sleep 2; done
echo "  второй запуск: новая сессия выполняет миграцию — $(sql mig_fw "select count(*) from pg_stat_activity where query like 'select pg_sleep%' and pid<>${old:-0}"); старая сессия ещё жива — $(sql mig_fw "select count(*) from pg_stat_activity where pid=${old:-0}")"
echo "  последние строки лога второго запуска:"
kubectl -n $ns logs fw-2 2>&1 | grep -v "^\s*$" | tail -2 | cut -c1-150 | sed 's/^/    /'
kubectl -n $ns delete pod fw-2 --force --grace-period=0 >/dev/null 2>&1
