#!/bin/bash
# Опыт 4.2 гл. 47 на kind (Kubernetes 1.37): Secret через kubectl, лишний перевод строки, хранение в etcd.
# Запуск: bash labs/k8s-ch47/secret.sh > labs/k8s-ch47/s47-secret.txt
export MSYS_NO_PATHCONV=1
ns=ch47; kubectl create ns $ns --dry-run=client -o yaml | kubectl apply -f - >/dev/null
kubectl -n $ns delete secret orders-db orders-db-echo --ignore-not-found >/dev/null
kubectl -n $ns delete pod secret-reader --ignore-not-found --wait >/dev/null

echo "=== 4.2 Secret через kubectl: --from-literal против data из echo"
kubectl -n $ns create secret generic orders-db --from-literal=password='S3cr3t-Value!' >/dev/null
echo "  kubectl get secret orders-db: data.password = $(kubectl -n $ns get secret orders-db -o jsonpath='{.data.password}')"
echo "  декодировали без ключа: $(kubectl -n $ns get secret orders-db -o jsonpath='{.data.password}' | base64 -d)"
enc=$(echo "S3cr3t-Value!" | base64)
kubectl -n $ns apply -f - >/dev/null <<EOF
apiVersion: v1
kind: Secret
metadata: {name: orders-db-echo}
data: {password: $enc}
EOF
echo "  data из echo без -n: $enc"

kubectl -n $ns apply -f - >/dev/null <<'EOF'
apiVersion: v1
kind: Pod
metadata: {name: secret-reader}
spec:
  restartPolicy: Never
  containers:
    - name: c
      image: busybox:1.36
      command: ["sh", "-c", "for f in /a/password /b/password; do echo \"$f: $(wc -c < $f) байт, последний байт $(tail -c1 $f | od -An -c | tr -d ' ')\"; done; sleep 3600"]
      volumeMounts: [{name: a, mountPath: /a, readOnly: true}, {name: b, mountPath: /b, readOnly: true}]
  volumes:
    - {name: a, secret: {secretName: orders-db}}
    - {name: b, secret: {secretName: orders-db-echo}}
EOF
kubectl -n $ns wait --for=condition=Ready pod/secret-reader --timeout=120s >/dev/null
sleep 2
echo "  в поде (файлы тома):"
kubectl -n $ns logs secret-reader | sed 's/^/    /'

echo "=== 4.2 что лежит в etcd (шифрование at rest на kind не включено)"
cert=/etc/kubernetes/pki/etcd
kubectl -n kube-system exec etcd-jbb-control-plane -- etcdctl --cacert $cert/ca.crt --cert $cert/server.crt --key $cert/server.key \
  get /registry/secrets/$ns/orders-db --print-value-only 2>/dev/null | tr -c '[:print:]' '.' | grep -o "k8s.\{0,4\}v1.\{0,30\}\|S3cr3t-Value!" | sort -u | sed 's/^/  /'
kubectl -n kube-system get pod -l component=kube-apiserver -o jsonpath='{.items[0].spec.containers[0].command}' | tr ',' '\n' | grep -c encryption-provider-config | sed 's/^/  флагов --encryption-provider-config у API-сервера: /'
kubectl -n $ns delete pod secret-reader --wait=false >/dev/null
