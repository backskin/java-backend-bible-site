#!/bin/bash
# Опыт 8.5, уточнение: когда Flyway 13 держит advisory lock в PostgreSQL 17 — раз в секунду смотрим pg_locks и сессии.
# Запуск: bash labs/k8s-ch47/flyway-locks.sh > labs/k8s-ch47/s47-flyway-locks.txt
export MSYS_NO_PATHCONV=1
ns=ch47; FW=flyway/flyway:13.11.1
pg=$(kubectl -n ai get pods --no-headers | awk '/^pg17-/{print $1; exit}')
sql(){ kubectl -n ai exec "$pg" -- psql -U postgres -d "$1" -tAc "$2"; }
kubectl -n $ns delete pod fw-a --ignore-not-found --force --grace-period=0 >/dev/null 2>&1
sql postgres "DROP DATABASE IF EXISTS mig_fw2 WITH (FORCE)" >/dev/null; sql postgres "CREATE DATABASE mig_fw2" >/dev/null
kubectl -n $ns apply -f - >/dev/null <<EOF
apiVersion: v1
kind: Pod
metadata: {name: fw-a}
spec:
  restartPolicy: Never
  containers:
    - name: m
      image: $FW
      args: ["-url=jdbc:postgresql://pg17.ai:5432/mig_fw2", "-user=postgres", "-password=x", "-locations=filesystem:/mig", "migrate"]
      volumeMounts: [{name: mig, mountPath: /mig}]
  volumes: [{name: mig, configMap: {name: mig}}]
EOF
echo "=== 8.5 Flyway 13.11.1 на PostgreSQL 17: блокировки и сессии раз в секунду"
t0=$(date +%s)
for i in $(seq 1 25); do
  l=$(sql mig_fw2 "select string_agg(l.locktype||':'||coalesce(l.objid::text,'')||':'||case when l.granted then 'взята' else 'ждёт' end||' pid '||l.pid, '; ') from pg_locks l join pg_stat_activity a on a.pid=l.pid where a.datname='mig_fw2' and l.locktype in ('advisory') ")
  q=$(sql mig_fw2 "select string_agg(pid||' '||state||' '||left(query,30), ' | ') from pg_stat_activity where datname='mig_fw2' and pid<>pg_backend_pid()")
  echo "  +$(( $(date +%s) - t0 )) с  advisory: ${l:-нет}  ||  сессии: ${q:-нет}"
  sleep 1
done
kubectl -n $ns logs fw-a 2>&1 | grep -v "^\s*$" | head -12 | cut -c1-140 | sed 's/^/  лог: /'
kubectl -n $ns delete pod fw-a --force --grace-period=0 >/dev/null 2>&1
