#!/bin/bash
# Опыт 5.6/9.5 гл. 47 на kind (Kubernetes 1.37): пауза CrashLoopBackOff по умолчанию и с потолком
# crashLoopBackOff.maxContainerRestartPeriod (KubeletCrashLoopBackOffMax, beta с 1.35, включён по умолчанию).
# На jbb-worker2 потолок 5 с в конфигурации kubelet, на jbb-worker — умолчание. Контейнер падает сразу после старта.
# Запуск: bash labs/k8s-ch47/backoff.sh > labs/k8s-ch47/s47-backoff.txt
export MSYS_NO_PATHCONV=1
ns=ch47; cfg=/var/lib/kubelet/config.yaml
# в конфигурации kind уже есть пустой ключ «crashLoopBackOff: {}»: сохраняем копию файла и меняем ровно эту строку
docker exec jbb-worker2 cp $cfg /root/kubelet-config.bak
docker exec jbb-worker2 sh -c "awk '{ if (\$0 == \"crashLoopBackOff: {}\") { print \"crashLoopBackOff:\"; print \"  maxContainerRestartPeriod: 5s\" } else print }' /root/kubelet-config.bak > $cfg && systemctl restart kubelet"
for i in $(seq 1 30); do [ "$(kubectl get node jbb-worker2 --no-headers | awk '{print $2}')" = Ready ] && break; sleep 2; done
sleep 5
kubectl -n $ns delete pod crash-default crash-capped --ignore-not-found --force --grace-period=0 >/dev/null 2>&1
for v in default:jbb-worker capped:jbb-worker2; do
  kubectl -n $ns apply -f - >/dev/null <<EOF
apiVersion: v1
kind: Pod
metadata: {name: crash-${v%%:*}}
spec:
  nodeSelector: {kubernetes.io/hostname: ${v##*:}}
  containers: [{name: app, image: busybox:1.36, command: ["sh", "-c", "exit 1"]}]
EOF
done
echo "=== 5.6 пауза перед перезапуском упавшего контейнера: умолчание против maxContainerRestartPeriod 5s"
echo "  конфигурация kubelet на jbb-worker2: $(docker exec jbb-worker2 sh -c "grep -A1 crashLoopBackOff $cfg | tr '\n' ' '")"
t0=$(date +%s); declare -A last
for i in $(seq 1 60); do
  line=""
  for p in crash-default crash-capped; do
    r=$(kubectl -n $ns get pod $p -o jsonpath='{.status.containerStatuses[0].restartCount}' 2>/dev/null)
    if [ -n "$r" ] && [ "$r" != "${last[$p]}" ]; then line="$line $p→рестарт $r;"; last[$p]=$r; fi
  done
  [ -n "$line" ] && echo "  +$(( $(date +%s) - t0 )) с $line"
  sleep 2
done
kubectl -n $ns get pod crash-default -o jsonpath='  crash-default сейчас: {.status.containerStatuses[0].state.waiting.message}{"\n"}' | cut -c1-120
kubectl -n $ns delete pod crash-default crash-capped --force --grace-period=0 >/dev/null 2>&1
# вернуть узел к умолчанию
docker exec jbb-worker2 sh -c "cp /root/kubelet-config.bak $cfg && systemctl restart kubelet"
