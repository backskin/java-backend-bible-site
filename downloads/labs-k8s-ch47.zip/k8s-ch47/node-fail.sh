#!/bin/bash
# Опыт 9.5 гл. 47 на kind (Kubernetes 1.37): узел перестал отвечать — что видно у узла и у пода.
# Узел jbb-worker2 замораживается (docker pause): kubelet молчит, процессы стоят, как при зависшей машине.
# Запуск: bash labs/k8s-ch47/node-fail.sh > labs/k8s-ch47/s47-node-fail.txt
export MSYS_NO_PATHCONV=1
ns=ch47
kubectl -n $ns delete deploy orders-nf --ignore-not-found --wait >/dev/null
# под должен встать на jbb-worker2: второй рабочий узел на время создания закрыт для планирования
kubectl cordon jbb-worker >/dev/null
kubectl -n $ns apply -f - >/dev/null <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata: {name: orders-nf}
spec:
  replicas: 1
  selector: {matchLabels: {app: orders-nf}}
  template:
    metadata: {labels: {app: orders-nf}}
    spec:
      # вместо умолчания 300 с — 30 с, чтобы увидеть вытеснение за пару минут
      tolerations:
        - {key: node.kubernetes.io/unreachable, operator: Exists, effect: NoExecute, tolerationSeconds: 30}
        - {key: node.kubernetes.io/not-ready, operator: Exists, effect: NoExecute, tolerationSeconds: 30}
      containers:
        - {name: app, image: busybox:1.36, command: ["sh", "-c", "sleep 3600"]}
EOF
kubectl -n $ns rollout status deploy/orders-nf --timeout=120s >/dev/null
kubectl uncordon jbb-worker >/dev/null
first=$(kubectl -n $ns get pod -l app=orders-nf -o jsonpath='{.items[0].metadata.name}')
node=$(kubectl -n $ns get pod $first -o jsonpath='{.spec.nodeName}')
echo "=== 9.5 узел перестал отвечать: под $first на узле $node"
echo "  kube-controller-manager: $(kubectl -n kube-system get pod -l component=kube-controller-manager -o jsonpath='{.items[0].spec.containers[0].command}' | tr ',' '\n' | grep -o 'node-monitor-grace-period=[^"]*' || echo 'node-monitor-grace-period не задан — умолчание')"
docker pause jbb-worker2 >/dev/null
t0=$(date +%s)
for i in $(seq 1 18); do
  n=$(kubectl get node jbb-worker2 --no-headers | awk '{print $2}')
  taints=$(kubectl get node jbb-worker2 -o jsonpath='{range .spec.taints[*]}{.key}:{.effect} {end}' | sed 's/node.kubernetes.io\///g')
  pods=$(kubectl -n $ns get pods -l app=orders-nf --no-headers -o custom-columns=N:.metadata.name,ST:.status.phase,R:.status.conditions[?\(@.type==\"Ready\"\)].status,D:.metadata.deletionTimestamp,NODE:.spec.nodeName | awk '{printf "%s %s ready=%s %s %s; ", substr($1,length($1)-4), $2, $3, ($4=="<none>"?"":"удаляется"), $5}')
  view=$(kubectl -n $ns get pods -l app=orders-nf --no-headers | awk '{printf "%s:%s ", substr($1,length($1)-4), $3}')
  echo "  +$(( $(date +%s) - t0 )) с  узел $n [$taints]  поды: $pods  kubectl get: $view"
  sleep 10
done
docker unpause jbb-worker2 >/dev/null
for i in $(seq 1 20); do [ "$(kubectl get node jbb-worker2 --no-headers | awk '{print $2}')" = Ready ] && break; sleep 3; done
sleep 10
echo "=== после возвращения узла"
kubectl -n $ns get pods -l app=orders-nf --no-headers -o wide | awk '{print "  " $1, $3, $7}'
kubectl -n $ns delete deploy orders-nf --wait=false >/dev/null
