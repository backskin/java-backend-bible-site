import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Восемь потоков жгут процессор 10 секунд; ещё один поток раз в миллисекунду проверяет, насколько он опоздал.
 * Печатает: сколько процессоров видит JVM, лимит из cgroup, сколько работы сделано, самое долгое опоздание и счётчики троттлинга из cpu.stat.
 * Запуск внутри контейнера: java Burn.java (JDK 21, cgroup v2).
 */
public class Burn {

    static String cgroup(String file) {
        try { return Files.readString(Path.of("/sys/fs/cgroup/" + file)).trim().replace("\n", "; "); } catch (Exception e) { return "нет файла " + file; }
    }

    public static void main(String[] args) throws Exception {
        int burners = 8, seconds = 10;
        AtomicLong work = new AtomicLong();
        long end = System.nanoTime() + seconds * 1_000_000_000L;
        System.out.println("JVM видит процессоров: " + Runtime.getRuntime().availableProcessors() + "; cpu.max: " + cgroup("cpu.max"));
        System.out.println("cpu.stat до:    " + cgroup("cpu.stat").replaceAll("(usage_usec|user_usec|system_usec) \\d+; ?", ""));
        for (int i = 0; i < burners; i++) {
            Thread t = new Thread(() -> {
                long local = 0;
                double x = 0;
                while (System.nanoTime() < end) { for (int k = 0; k < 20_000; k++) x += Math.sqrt(k + x % 7); local++; }
                work.addAndGet(local);
                if (x == 42) System.out.print("");
            });
            t.setDaemon(true);
            t.start();
        }
        long maxLateNs = 0;
        while (System.nanoTime() < end) {
            long t0 = System.nanoTime();
            Thread.sleep(1);
            maxLateNs = Math.max(maxLateNs, System.nanoTime() - t0 - 1_000_000L);
        }
        Thread.sleep(300);
        System.out.println("работы сделано (условных единиц): " + work.get() + "; самое долгое опоздание потока с таймером 1 мс: " + maxLateNs / 1_000_000 + " мс");
        System.out.println("cpu.stat после: " + cgroup("cpu.stat").replaceAll("(usage_usec|user_usec|system_usec) \\d+; ?", ""));
    }
}
