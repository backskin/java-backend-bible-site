#!/bin/bash
# Опыт 5.2–5.3 гл. 47 на kind (Kubernetes 1.37): что делает kubelet, когда проба зависит от общей БД, а БД упала.
# «Приложение» — маленький HTTP-сервер на Python: /live всегда 200, /live-db и /ready-db — 200, только если
# открывается TCP-соединение к сервису db:5432. Три Deployment по три реплики: liveness с БД, readiness с БД,
# пробы без зависимостей. БД гасится (replicas=0) на 60 с, затем возвращается.
# Запуск: bash labs/k8s-ch47/probe-db.sh > labs/k8s-ch47/s47-probe-db.txt
export MSYS_NO_PATHCONV=1
ns=ch47
kubectl -n $ns delete deploy db app-live-db app-ready-db app-plain --ignore-not-found --wait >/dev/null
kubectl -n $ns wait --for=delete pod -l 'app in (db,app-live-db,app-ready-db,app-plain)' --timeout=120s >/dev/null 2>&1
kubectl -n $ns apply -f - >/dev/null <<'EOF'
apiVersion: v1
kind: ConfigMap
metadata: {name: probe-app}
data:
  app.py: |
    import http.server, socket
    def db_ok():
        try:
            socket.create_connection(("db", 5432), timeout=0.5).close(); return True
        except OSError:
            return False
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            code = 200 if self.path == "/live" or db_ok() else 503
            self.send_response(code); self.end_headers(); self.wfile.write(b"ok" if code == 200 else b"db down")
        def log_message(self, *a): pass
    http.server.ThreadingHTTPServer(("", 8080), H).serve_forever()
---
apiVersion: apps/v1
kind: Deployment
metadata: {name: db}
spec:
  replicas: 1
  selector: {matchLabels: {app: db}}
  template:
    metadata: {labels: {app: db}}
    spec:
      # python как PID 1 не обрабатывает SIGTERM; без нуля «БД» дожила бы до конца grace period (30 с)
      terminationGracePeriodSeconds: 0
      containers: [{name: db, image: "python:3.12-alpine", command: ["python", "-m", "http.server", "5432"]}]
---
apiVersion: v1
kind: Service
metadata: {name: db}
spec: {selector: {app: db}, ports: [{port: 5432}]}
EOF
for d in live-db ready-db plain; do
  case $d in
    live-db)  probes='livenessProbe: {httpGet: {path: /live-db, port: 8080}, periodSeconds: 2, failureThreshold: 3, timeoutSeconds: 1}
          readinessProbe: {httpGet: {path: /live, port: 8080}, periodSeconds: 2}';;
    ready-db) probes='livenessProbe: {httpGet: {path: /live, port: 8080}, periodSeconds: 2, failureThreshold: 3, timeoutSeconds: 1}
          readinessProbe: {httpGet: {path: /ready-db, port: 8080}, periodSeconds: 2, failureThreshold: 3}';;
    plain)    probes='livenessProbe: {httpGet: {path: /live, port: 8080}, periodSeconds: 2, failureThreshold: 3, timeoutSeconds: 1}
          readinessProbe: {httpGet: {path: /live, port: 8080}, periodSeconds: 2}';;
  esac
  kubectl -n $ns apply -f - >/dev/null <<EOF
apiVersion: apps/v1
kind: Deployment
metadata: {name: app-$d}
spec:
  replicas: 3
  selector: {matchLabels: {app: app-$d}}
  template:
    metadata: {labels: {app: app-$d}}
    spec:
      containers:
        - name: app
          image: "python:3.12-alpine"
          command: ["python", "/src/app.py"]
          volumeMounts: [{name: src, mountPath: /src}]
          $probes
      volumes: [{name: src, configMap: {name: probe-app}}]
---
apiVersion: v1
kind: Service
metadata: {name: app-$d}
spec: {selector: {app: app-$d}, ports: [{port: 8080}]}
EOF
done
for d in db app-live-db app-ready-db app-plain; do kubectl -n $ns rollout status deploy/$d --timeout=240s >/dev/null; done
sleep 5
state(){
  for d in live-db ready-db plain; do
    r=$(kubectl -n $ns get pods -l app=app-$d -o jsonpath='{range .items[*]}{.status.containerStatuses[0].restartCount}{" "}{end}')
    e=$(kubectl -n $ns get endpointslice -l kubernetes.io/service-name=app-$d -o jsonpath='{range .items[*].endpoints[*]}{.conditions.ready}{" "}{end}' | grep -o true | wc -l)
    printf "%-9s рестарты [%s] в эндпоинтах %s из 3;  " "$d" "$(echo $r)" "$e"
  done
  echo
}
echo "=== 5.2 БД доступна"
echo "  $(state)"
echo "=== 5.2 БД остановлена (db replicas=0); проба раз в 2 с, failureThreshold 3"
kubectl -n $ns scale deploy db --replicas=0 >/dev/null
t0=$(date +%s)
for i in $(seq 1 9); do sleep 5; echo "  +$(( $(date +%s) - t0 )) с  $(state)"; done
kubectl -n $ns get pods -l app=app-live-db --no-headers | awk '{print "  " $1, $3, "рестартов " $4}'
echo "=== 5.2 БД вернулась"
kubectl -n $ns scale deploy db --replicas=1 >/dev/null
t1=$(date +%s)
for i in $(seq 1 5); do sleep 10; echo "  +$(( $(date +%s) - t1 )) с  $(state)"; done
kubectl -n $ns get pods -l app=app-live-db --no-headers | awk '{print "  " $1, $3, "рестартов " $4}'
kubectl -n $ns delete deploy db app-live-db app-ready-db app-plain --wait=false >/dev/null
kubectl -n $ns delete svc db app-live-db app-ready-db app-plain --wait=false >/dev/null
