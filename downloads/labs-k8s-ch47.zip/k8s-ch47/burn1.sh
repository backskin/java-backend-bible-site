#!/bin/bash
# Опыт 6.3: исходная программа Burn.java (с потоком-таймером) в тех же условиях, что burn2.sh.
# Запуск: bash labs/k8s-ch47/burn1.sh > labs/k8s-ch47/s47-burn1.txt
export MSYS_NO_PATHCONV=1
cd "$(dirname "$0")"
ns=ch47
kubectl -n $ns create configmap burn1 --from-file=Burn.java --dry-run=client -o yaml | kubectl apply -f - >/dev/null
for mode in cold; do
  for v in limited free; do
    name=burn1-$v-$mode
    kubectl -n $ns delete pod $name --ignore-not-found --wait >/dev/null
    lim=""; [ $v = limited ] && lim="cpu: 500m, "
    arg=""; [ $mode = warm ] && arg=', "warm"'
    kubectl -n $ns apply -f - >/dev/null <<EOF
apiVersion: v1
kind: Pod
metadata: {name: $name}
spec:
  restartPolicy: Never
  nodeSelector: {kubernetes.io/hostname: jbb-worker2}
  containers:
    - name: c
      image: eclipse-temurin:21-jdk-alpine
      command: ["java", "/src/Burn.java"$arg]
      volumeMounts: [{name: src, mountPath: /src}]
      resources:
        requests: {cpu: 500m, memory: 256Mi}
        limits: {${lim}memory: 512Mi}
  volumes:
    - {name: src, configMap: {name: burn1}}
EOF
    kubectl -n $ns wait --for=jsonpath='{.status.phase}'=Succeeded pod/$name --timeout=300s >/dev/null
    echo "--- $name"
    kubectl -n $ns logs $name | sed 's/^/  /'
    kubectl -n $ns delete pod $name --wait=false >/dev/null
  done
done
