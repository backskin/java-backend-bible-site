# Kubernetes 1.37 на kind: Secret в etcd, пробы с зависимостью от базы, CrashLoopBackOff, лимит CPU и JVM, миграции как Job и hook Helm, отказ узла

Стенд к главе 47. Скрипты bash против кластера kind `jbb` из трех узлов, каждый пишет вывод в `s47-<имя>.txt`: `secret.sh` (Secret через `kubectl` и через `echo` без `-n`, чтение из etcd), `probe-db.sh` (три Deployment, у которых проверка базы стоит в liveness, в readiness или нигде, и база гасится на 60 с), `backoff.sh` (пауза CrashLoopBackOff по умолчанию и с `crashLoopBackOff.maxContainerRestartPeriod` в конфигурации kubelet), `burn1.sh` и `burn2.sh` с `Burn.java` и `Burn2.java` (сколько процессоров видит JVM при `cpu: 500m` и какой сборщик выбирает), `migrate-lock.sh` и `flyway-locks.sh` (под с миграцией Liquibase или Flyway убит посреди работы: остается ли блокировка в PostgreSQL 17), `helm.sh` с чартом `helm-orders/` (миграция как hook Helm 4.3.1: install, upgrade, падающая миграция), `lifecycle.sh` (termination message, postStart, readiness gates), `node-fail.sh` (узел заморожен через `docker pause`: что видят контроллеры и под).

## Что нужно

- Docker, kind с кластером `jbb` (узлы `jbb-control-plane`, `jbb-worker`, `jbb-worker2`), `kubectl`, Helm 4.3 (путь `~/bin/helm.exe` в `helm.sh`), PostgreSQL 17 в пространстве `ai` (`pg17`) для опытов с миграциями, Git Bash (`MSYS_NO_PATHCONV=1` ставят сами скрипты).

## Запуск

```bash
bash secret.sh > s47-secret.txt
```

и так для каждого скрипта; `backoff.sh` правит конфигурацию kubelet на `jbb-worker2` и перезапускает его, `node-fail.sh` ставит узел на паузу и снимает ее. В IDEA на каждый скрипт есть Shell-конфигурация.

## Что должно получиться

Secret в etcd лежит открытым текстом base64, а значение из `echo` без `-n` длиннее на байт; при недоступной базе Deployment с проверкой базы в liveness перезапускается на всех репликах, с проверкой в readiness только выпадает из эндпоинтов; при `cpu: 500m` JVM видит один процессор и выбирает Serial GC; после `kill -9` пода Liquibase оставляет `LOCKED=TRUE` в `DATABASECHANGELOGLOCK` и ноль примененных изменений; что происходит с блокировкой Flyway 13, показывают `s47-migrate-lock.txt` и `s47-flyway-locks.txt`.
