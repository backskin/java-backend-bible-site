# Что Keycloak 26.1 кладет в access token: realm_access, resource_access, aud, azp и Full Scope Allowed

Стенд к главе 13, разделы 7.4 и 7.6. Скрипт `run.sh` поднимает Keycloak 26.1 в Docker, через `kcadm.sh` создает realm `tundra`, клиент API `payments-api` с ролью `PAYMENT_APPROVE`, публичный клиент `mobile-app` и пользователя `dev.team` с realm-ролью `OPERATOR`, затем получает токен по password grant в пяти состояниях: только realm-роль; плюс клиентская роль; состав мапперов области `roles`; с выключенным Full Scope Allowed (роли и `aud` пропадают); с ролями, назначенными клиенту в scope. `decode.py` печатает нужные claim из токена, `mappers.py` - мапперы области. Вывод автора - `s13-keycloak-claims.txt`. Программ Java в стенде нет.

## Что нужно

- Docker, bash с `curl`, Python 3; свободный порт 18180.

## Запуск

```bash
bash run.sh
```

Контейнер `kc-lab` скрипт удаляет в конце. В IDEA есть Shell-конфигурация `run`.

## Что должно получиться

После выдачи клиентской роли в токене появляются `resource_access.payments-api.roles` и `payments-api` в `aud`; после выключения Full Scope Allowed и то и другое исчезает, пока роли не назначены клиенту в scope.
