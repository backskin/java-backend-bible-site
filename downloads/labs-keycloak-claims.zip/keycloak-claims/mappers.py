"""Печатает мапперы клиентской области (stdin — JSON из kcadm get .../protocol-mappers/models)."""
import json
import sys

for m in json.load(sys.stdin):
    cfg = m.get("config", {})
    print("   маппер", repr(m["name"]), m["protocolMapper"], "access.token.claim=" + str(cfg.get("access.token.claim")))
