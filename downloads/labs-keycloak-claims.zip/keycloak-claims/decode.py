"""Печатает интересные claims access token из ответа token endpoint Keycloak (stdin)."""
import base64
import json
import sys

resp = json.load(sys.stdin)
if "access_token" not in resp:
    print("   ошибка:", resp)
    sys.exit()
part = resp["access_token"].split(".")[1]
part += "=" * (-len(part) % 4)
claims = json.loads(base64.urlsafe_b64decode(part))
keys = ["iss", "aud", "azp", "typ", "scope", "realm_access", "resource_access", "preferred_username"]
print("  ", json.dumps({k: claims.get(k) for k in keys}, ensure_ascii=False))
