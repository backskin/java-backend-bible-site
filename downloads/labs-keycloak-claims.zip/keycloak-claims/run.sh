#!/usr/bin/env bash
# Разд. 7.4 и 7.6 гл. 13: что Keycloak кладёт в access token по умолчанию — realm_access, resource_access, aud, azp.
# Нужен Docker и образ quay.io/keycloak/keycloak:26.1. Вывод — s13-keycloak-claims.txt.
# Сценарий: realm tundra, клиент API payments-api с ролью PAYMENT_APPROVE, мобильный клиент mobile-app (public, Direct Access Grants),
# пользователь dev.team с realm-ролью OPERATOR; затем ему же выдаётся клиентская роль payments-api/PAYMENT_APPROVE.
set -uo pipefail
cd "$(dirname "$0")"
export MSYS_NO_PATHCONV=1
IMG="${KC_IMAGE:-quay.io/keycloak/keycloak:26.1}"
PORT=18180
docker rm -f kc-lab >/dev/null 2>&1
docker run -d --name kc-lab -p $PORT:8080 -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=admin "$IMG" start-dev >/dev/null
for i in $(seq 1 90); do curl -s -m 5 -o /dev/null -w "%{http_code}" http://127.0.0.1:$PORT/realms/master | grep -q 200 && break; sleep 2; done
sleep 5
kc() { timeout 60 docker exec kc-lab /opt/keycloak/bin/kcadm.sh "$@"; }
id_of() { kc get "$1" -r tundra -q "$2" --fields id --format csv --noquotes; }
kc config credentials --server http://localhost:8080 --realm master --user admin --password admin >/dev/null
kc create realms -s realm=tundra -s enabled=true >/dev/null
kc create clients -r tundra -s clientId=payments-api -s publicClient=false -s secret=api-secret -s standardFlowEnabled=false >/dev/null
kc create clients -r tundra -s clientId=mobile-app -s publicClient=true -s directAccessGrantsEnabled=true -s standardFlowEnabled=false >/dev/null
kc create "clients/$(id_of clients clientId=payments-api)/roles" -r tundra -s name=PAYMENT_APPROVE >/dev/null
kc create roles -r tundra -s name=OPERATOR >/dev/null
kc create users -r tundra -s username=dev.team -s enabled=true -s email=dev.team@example.org -s emailVerified=true -s firstName=Dev -s lastName=Team >/dev/null
kc set-password -r tundra --username dev.team --new-password pw >/dev/null
kc add-roles -r tundra --uusername dev.team --rolename OPERATOR >/dev/null
token() {
  curl -s -m 20 -X POST "http://127.0.0.1:$PORT/realms/tundra/protocol/openid-connect/token" \
    -d grant_type=password -d client_id=mobile-app -d username=dev.team -d password=pw -d scope=openid \
    | python -X utf8 decode.py
}
{
  echo "== Keycloak 26.1 (образ $IMG); токен мобильного клиента mobile-app, password grant, scope=openid"
  echo "-- 1. у пользователя только realm-роль OPERATOR"
  token
  kc add-roles -r tundra --uusername dev.team --cclientid payments-api --rolename PAYMENT_APPROVE >/dev/null
  echo "-- 2. пользователю выдана клиентская роль payments-api/PAYMENT_APPROVE"
  token
  echo "-- 3. клиентские области по умолчанию у mobile-app и мапперы области roles"
  echo "   $(kc get "clients/$(id_of clients clientId=mobile-app)/default-client-scopes" -r tundra --fields name --format csv --noquotes | paste -sd' ' -)"
  RS=$(kc get client-scopes -r tundra --fields id,name --format csv --noquotes | grep ',roles$' | cut -d, -f1)
  kc get "client-scopes/$RS/protocol-mappers/models" -r tundra --format json | python -X utf8 mappers.py
  echo "   fullScopeAllowed у mobile-app: $(kc get "clients/$(id_of clients clientId=mobile-app)" -r tundra --fields fullScopeAllowed --format csv --noquotes)"
  MOB=$(id_of clients clientId=mobile-app)
  kc update "clients/$MOB" -r tundra -s fullScopeAllowed=false >/dev/null
  echo "-- 4. у mobile-app выключен Full Scope Allowed, ролей в scope клиента нет"
  token
  kc add-roles -r tundra --cid "$MOB" --rolename OPERATOR --target scope >/dev/null 2>&1 || kc create "clients/$MOB/scope-mappings/realm" -r tundra -b "[$(kc get roles/OPERATOR -r tundra --fields id,name --format json)]" >/dev/null
  API=$(id_of clients clientId=payments-api)
  kc create "clients/$MOB/scope-mappings/clients/$API" -r tundra -b "[$(kc get "clients/$API/roles/PAYMENT_APPROVE" -r tundra --fields id,name --format json)]" >/dev/null
  echo "-- 5. клиенту mobile-app назначены в scope роли OPERATOR и payments-api/PAYMENT_APPROVE"
  token
} | tee s13-keycloak-claims.txt
docker rm -f kc-lab >/dev/null
