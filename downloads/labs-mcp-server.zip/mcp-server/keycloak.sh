#!/usr/bin/env bash
# Гл. 82: Keycloak 26.1 как сервер авторизации для MCP-сервера «Помощник операциониста».
# realm tundra; клиент operator-agent (confidential, client_credentials); клиентские области payments:read и disputes:write;
# маппер аудитории кладёт в aud адрес MCP-сервера. Затем — запросы к MCP-серверу (запущен с -Dlab.oauth=true).
set -uo pipefail
cd "$(dirname "$0")"
export MSYS_NO_PATHCONV=1
IMG="${KC_IMAGE:-quay.io/keycloak/keycloak:26.1}"
PORT=18180
docker rm -f kc-mcp >/dev/null 2>&1
docker run -d --name kc-mcp -p $PORT:8080 -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=admin "$IMG" start-dev >/dev/null
for i in $(seq 1 90); do curl -s -m 5 -o /dev/null -w "%{http_code}" http://127.0.0.1:$PORT/realms/master | grep -q 200 && break; sleep 2; done
sleep 5
kc() { timeout 60 docker exec kc-mcp /opt/keycloak/bin/kcadm.sh "$@"; }
kc config credentials --server http://localhost:8080 --realm master --user admin --password admin >/dev/null
# адрес выдачи в токене должен совпасть с тем, что видит MCP-сервер: задаём hostname явно
kc create realms -s realm=tundra -s enabled=true -s 'attributes."frontendUrl"=http://127.0.0.1:18180' >/dev/null
for s in payments:read disputes:write; do
  kc create client-scopes -r tundra -s name=$s -s protocol=openid-connect -s 'attributes."include.in.token.scope"=true' >/dev/null
done
kc create clients -r tundra -s clientId=operator-agent -s publicClient=false -s secret=agent-secret \
  -s serviceAccountsEnabled=true -s standardFlowEnabled=false >/dev/null
CID=$(kc get clients -r tundra -q clientId=operator-agent --fields id --format csv --noquotes)
for s in payments:read disputes:write; do
  SID=$(kc get client-scopes -r tundra --fields id,name --format csv --noquotes | grep ",$s$" | cut -d, -f1)
  kc update "clients/$CID/optional-client-scopes/$SID" -r tundra >/dev/null
done
kc create "clients/$CID/protocol-mappers/models" -r tundra -s name=mcp-audience -s protocol=openid-connect \
  -s protocolMapper=oidc-audience-mapper -s 'config."included.custom.audience"=http://localhost:8079/mcp' \
  -s 'config."access.token.claim"=true' >/dev/null

tok() { curl -s -X POST "http://127.0.0.1:$PORT/realms/tundra/protocol/openid-connect/token" \
  -d grant_type=client_credentials -d client_id=operator-agent -d client_secret=agent-secret "$@" \
  | python -X utf8 -c "import sys,json;print(json.load(sys.stdin).get('access_token',''))"; }
claims() { python -X utf8 -c "import sys,json,base64;p=sys.argv[1].split('.')[1];p+='='*(-len(p)%4);c=json.loads(base64.urlsafe_b64decode(p));print({k:c.get(k) for k in ('iss','aud','azp','scope')})" "$1"; }
echo "$(tok -d scope=payments:read)" > token-read.txt
echo "$(tok -d 'scope=payments:read disputes:write')" > token-write.txt
echo "$(tok -d scope=payments:read -d resource=https://other.example/api)" > token-resource.txt
echo "== Keycloak 26.1, client_credentials клиента operator-agent"
echo "-- токен scope=payments:read:"; claims "$(cat token-read.txt)"
echo "-- токен scope=payments:read disputes:write:"; claims "$(cat token-write.txt)"
echo "-- токен с resource=https://other.example/api (RFC 8707):"; claims "$(cat token-resource.txt)"
