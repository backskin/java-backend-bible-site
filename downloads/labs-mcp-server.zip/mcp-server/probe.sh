#!/usr/bin/env bash
# Гл. 79: разговор с MCP-сервером по Streamable HTTP вручную, curl'ом: initialize → initialized → tools/list → tools/call.
# ./probe.sh [токен] — без токена заголовок Authorization не отправляется.
U=http://localhost:8079/mcp
TOKEN=${1:-}
AUTH=(); [ -n "$TOKEN" ] && AUTH=(-H "Authorization: Bearer $TOKEN")
H=(-H "Content-Type: application/json" -H "Accept: application/json, text/event-stream")

say() { echo; echo "### $*"; }

say "1. initialize (заголовки ответа и тело)"
curl -s -D hdr.txt "${H[@]}" "${AUTH[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{"elicitation":{}},"clientInfo":{"name":"probe","version":"1"}}}'
echo; tr -d '\r' < hdr.txt | grep -iE "^HTTP|content-type|mcp-session-id"
SID=$(tr -d '\r' < hdr.txt | grep -i '^mcp-session-id' | awk '{print $2}')
S=(-H "Mcp-Session-Id: $SID" -H "MCP-Protocol-Version: 2025-11-25")

say "2. notifications/initialized (ждём 202 без тела)"
curl -s -o /dev/null -w "%{http_code}\n" "${H[@]}" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","method":"notifications/initialized"}'

say "3. tools/list"
curl -s "${H[@]}" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":2,"method":"tools/list"}'; echo

say "4. tools/call payment_status PAY-1001"
curl -s "${H[@]}" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"payment_status","arguments":{"paymentId":"PAY-1001"}}}'; echo

say "5. tools/call client_payments limit=50 (за пределами схемы)"
curl -s "${H[@]}" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"client_payments","arguments":{"clientId":"CL-42","limit":50}}}'; echo

say "6. tools/call open_dispute_draft дважды с одним ключом"
for i in 1 2; do
curl -s "${H[@]}" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":5'$i',"method":"tools/call","params":{"name":"open_dispute_draft","arguments":{"paymentId":"PAY-1001","reason":"деньги списаны, перевод отклонён","idempotencyKey":"7f9c0b9e-1"}}}'; echo
done

say "7. tools/call несуществующего инструмента"
curl -s "${H[@]}" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":6,"method":"tools/call","params":{"name":"transfer_money","arguments":{}}}'; echo

say "8. resources/read reglament://disputes"
curl -s "${H[@]}" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":7,"method":"resources/read","params":{"uri":"reglament://disputes"}}'; echo

say "9. запрос без Mcp-Session-Id"
curl -s -w "\nHTTP %{http_code}\n" "${H[@]}" "${AUTH[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":8,"method":"tools/list"}'

say "10. запрос с чужим Origin"
curl -s -w "\nHTTP %{http_code}\n" "${H[@]}" "${AUTH[@]}" "${S[@]}" -H "Origin: https://evil.example" -X POST $U -d '{"jsonrpc":"2.0","id":9,"method":"tools/list"}' | tail -c 300

say "11. Accept только application/json"
curl -s -w "\nHTTP %{http_code}\n" -H "Content-Type: application/json" -H "Accept: application/json" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":10,"method":"tools/list"}' | tail -c 300

say "12. DELETE сессии, затем запрос в неё"
curl -s -o /dev/null -w "DELETE %{http_code}\n" "${AUTH[@]}" "${S[@]}" -X DELETE $U
curl -s -w "\nHTTP %{http_code}\n" "${H[@]}" "${AUTH[@]}" "${S[@]}" -X POST $U -d '{"jsonrpc":"2.0","id":11,"method":"tools/list"}' | tail -c 300
rm -f hdr.txt
