# MCP-сервер "Помощник операциониста" на Spring AI 2.0 с OAuth 2.1 через Keycloak и агент на локальной модели

Стенд к главе 79. `McpApp` (Spring Boot 4.1.2, `spring-ai-starter-mcp-server-webmvc`, сервер ресурсов OAuth2) отдает инструменты `payment_status`, `open_dispute_draft` и другие по Streamable HTTP на порту 8079; флаги `-Dlab.secure=true` (подтверждение человеком, идемпотентность записи) и `-Dlab.oauth=true` (проверка токена Keycloak с аудиторией и областями `payments:read`, `disputes:write`). `probe.sh` ведет разговор с сервером вручную через `curl` (`initialize` → `initialized` → `tools/list` → `tools/call`), `keycloak.sh` поднимает Keycloak 26.1 и настраивает realm, `tokens.sh` берет токены агента. `Agent` - клиент на официальном Java SDK с моделью из Ollama (`qwen2.5:7b` по умолчанию); `run.sh` прогоняет пять сценариев: чтение, запись без подтверждения и с ним, внедрение команды в текст обращения, бюджет шагов. Выводы автора - `s79-*.txt`.

## Что нужно

- JDK 21, Maven, Docker (Keycloak), bash с `curl` и Python 3; для агента - Ollama на `localhost:11434` с моделью `qwen2.5:7b` (у автора в kind через `kubectl -n ai port-forward deploy/ollama 11434:11434`).

## Запуск

```bash
mvn -q package -DskipTests && java -Dlab.secure=true -jar target/mcp-server-1.0.0.jar
```

Разговор вручную: `bash probe.sh`. С OAuth: `bash keycloak.sh`, затем сервер с `-Dlab.oauth=true`, `bash tokens.sh` и `bash probe.sh "$(cat token-read.txt)"`. Агент: `mvn -q dependency:build-classpath -Dmdep.outputFile=cp.txt && bash run.sh`. В IDEA есть конфигурации `McpApp`, `Agent` и Shell-конфигурации для скриптов.

## Что должно получиться

Без `spring.ai.mcp.server.protocol=STREAMABLE` сервер Spring AI 2.0.2 отвечает 404 на `POST /mcp` и открывает устаревший `GET /sse`; в stdio-режиме без выключенного баннера в stdout 25 строк и одна из них JSON-RPC; при внедренной в обращение "команде" агент с токеном только на чтение вызывает лишь `payment_status`, хотя в ответе обещает завести черновики; два прогона записи с подтверждением дают один черновик благодаря ключу идемпотентности.
