#!/usr/bin/env bash
# Гл. 82: свежие токены агента из Keycloak (срок жизни access token в realm по умолчанию — 300 с).
tok() { curl -s -X POST "http://127.0.0.1:18180/realms/tundra/protocol/openid-connect/token" \
  -d grant_type=client_credentials -d client_id=operator-agent -d client_secret=agent-secret "$@" \
  | python -X utf8 -c "import sys,json;d=json.load(sys.stdin);print(d['access_token']);print('expires_in', d['expires_in'], file=sys.stderr)"; }
tok -d scope=payments:read > token-read.txt
tok -d 'scope=payments:read disputes:write' > token-write.txt
