package dev.team.mcp;

import io.modelcontextprotocol.common.McpTransportContext;
import io.modelcontextprotocol.server.transport.DefaultServerTransportSecurityValidator;
import org.springframework.ai.mcp.annotation.McpResource;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.ai.mcp.annotation.McpToolParam;
import org.springframework.ai.mcp.annotation.context.McpSyncRequestContext;
import org.springframework.ai.mcp.server.webmvc.transport.WebMvcStreamableServerTransportProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import tools.jackson.databind.json.JsonMapper;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Гл. 82: MCP-сервер «Помощник операциониста» Тундра-Банка.
 * Два инструмента читают платёжный шлюз, третий заводит черновик претензии (запись, с ключом идемпотентности).
 * С -Dlab.secure=true транспорт собирается вручную: проверка Origin/Host, токен из заголовка в контекст, срок жизни сессии.
 * Без него работает автонастройка Spring AI как есть.
 */
@SpringBootApplication
public class McpApp {

    public static void main(String[] args) {
        SpringApplication.run(McpApp.class, args);
    }

    /** Токены стенда: в банке их выдаёт Keycloak, здесь — таблица «токен → сотрудник и права». */
    static final Map<String, Operator> TOKENS = Map.of(
            "op-read", new Operator("operator-17", Set.of("payments:read")),
            "op-write", new Operator("operator-17", Set.of("payments:read", "disputes:write")));

    record Operator(String id, Set<String> scopes) {}

    @Bean
    @ConditionalOnProperty(name = "lab.secure", havingValue = "true")
    WebMvcStreamableServerTransportProvider securedTransport(JsonMapper jsonMapper) {
        return WebMvcStreamableServerTransportProvider.builder()
                .jsonMapper(new io.modelcontextprotocol.json.jackson3.JacksonMcpJsonMapper(jsonMapper))
                .mcpEndpoint("/mcp")
                // Origin и Host: защита от DNS rebinding, которой спецификация требует от HTTP-сервера
                .securityValidator(DefaultServerTransportSecurityValidator.builder()
                        .allowedOrigin("https://ops.tundra-bank.test")
                        .allowedHost("localhost:*")
                        .build())
                // заголовок Authorization попадает в контекст транспорта и виден инструменту
                .contextExtractor(request -> McpTransportContext.create(Map.of(
                        "authorization", request.headers().firstHeader("Authorization") == null ? "" : request.headers().firstHeader("Authorization"))))
                .sessionIdleTimeout(Duration.ofMinutes(15))
                .maxSessions(500)
                .build();
    }
}

@Component
class OperatorTools {

    /** Платежи шлюза: в банке это REST платёжного шлюза, здесь — таблица в памяти. */
    record Payment(String id, String clientId, BigDecimal amount, String currency, String status, LocalDate date, String reason) {}

    record Dispute(String disputeId, String paymentId, String status, int attempt) {}

    private final List<Payment> payments = List.of(
            new Payment("PAY-1001", "CL-42", new BigDecimal("15000.00"), "RUB", "REJECTED", LocalDate.of(2026, 10, 27), "СБП: таймаут банка получателя"),
            new Payment("PAY-1002", "CL-42", new BigDecimal("2300.50"), "RUB", "COMPLETED", LocalDate.of(2026, 10, 26), null),
            new Payment("PAY-1003", "CL-77", new BigDecimal("990000.00"), "RUB", "ON_HOLD", LocalDate.of(2026, 10, 27), "антифрод: ручная проверка"));

    private final Map<String, Dispute> disputesByKey = new ConcurrentHashMap<>();
    private final AtomicInteger disputeSeq = new AtomicInteger(500);
    final AtomicInteger writeCalls = new AtomicInteger();

    @McpTool(name = "payment_status",
            description = "Статус платежа по номеру PAY-NNNN и причина отказа или задержки. Только чтение.",
            annotations = @McpTool.McpAnnotations(readOnlyHint = true, idempotentHint = true, openWorldHint = false))
    public Payment paymentStatus(@McpToolParam(description = "Номер платежа, например PAY-1001") String paymentId,
                                 McpSyncRequestContext ctx) {
        requireScope(ctx, "payments:read");
        Payment p = payments.stream().filter(x -> x.id().equals(paymentId)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Платёж " + paymentId + " не найден"));
        requireCaseClient(p.clientId());
        return p;
    }

    /**
     * Права у источника: хост передаёт клиента из открытого обращения заголовком X-Case-Client,
     * и инструмент не отдаёт платежи другого клиента, что бы ни попросила модель.
     * Синхронный инструмент выполняется в потоке запроса Tomcat, поэтому заголовок виден через RequestContextHolder.
     */
    private static void requireCaseClient(String clientId) {
        var attrs = org.springframework.web.context.request.RequestContextHolder.getRequestAttributes();
        if (!(attrs instanceof org.springframework.web.context.request.ServletRequestAttributes sra)) return;
        String caseClient = sra.getRequest().getHeader("X-Case-Client");
        if (caseClient != null && !caseClient.isBlank() && !caseClient.equals(clientId))
            throw new SecurityException("платёж принадлежит другому клиенту; в обращении клиент " + caseClient);
    }

    @McpTool(name = "client_payments",
            description = "Последние платежи клиента, не больше 20. Только чтение.",
            annotations = @McpTool.McpAnnotations(readOnlyHint = true, idempotentHint = true, openWorldHint = false))
    public List<Payment> clientPayments(@McpToolParam(description = "Идентификатор клиента CL-NN") String clientId,
                                        @McpToolParam(description = "Сколько платежей вернуть, 1–20", required = false) Integer limit,
                                        McpSyncRequestContext ctx) {
        requireScope(ctx, "payments:read");
        requireCaseClient(clientId);
        int n = limit == null ? 10 : limit;
        if (n < 1 || n > 20) throw new IllegalArgumentException("limit должен быть от 1 до 20, пришло " + n);
        return payments.stream().filter(p -> p.clientId().equals(clientId)).limit(n).toList();
    }

    @McpTool(name = "open_dispute_draft",
            description = "Заводит ЧЕРНОВИК претензии по платежу. Претензию отправляет операционист после проверки. "
                    + "Повтор с тем же idempotencyKey возвращает тот же черновик.",
            annotations = @McpTool.McpAnnotations(readOnlyHint = false, destructiveHint = false, idempotentHint = true, openWorldHint = false))
    public Dispute openDisputeDraft(@McpToolParam(description = "Номер платежа") String paymentId,
                                    @McpToolParam(description = "Суть претензии своими словами") String reason,
                                    @McpToolParam(description = "Ключ идемпотентности, UUID от клиента") String idempotencyKey,
                                    McpSyncRequestContext ctx) {
        requireScope(ctx, "disputes:write");
        writeCalls.incrementAndGet();
        payments.stream().filter(p -> p.id().equals(paymentId)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Платёж " + paymentId + " не найден"));
        Dispute d = disputesByKey.computeIfAbsent(idempotencyKey,
                k -> new Dispute("DSP-" + disputeSeq.incrementAndGet(), paymentId, "DRAFT", writeCalls.get()));
        ctx.info("черновик " + d.disputeId() + " по " + paymentId + ", вызов записи №" + writeCalls.get());
        return d;
    }

    @McpResource(uri = "reglament://disputes", name = "Регламент претензий",
            description = "Сроки и порядок разбора претензий по переводам", mimeType = "text/markdown")
    public String disputesReglament() {
        return "# Регламент претензий\n1. Претензия по переводу СБП принимается в течение 30 дней.\n"
                + "2. Ответ клиенту — не позже 15 рабочих дней.\n3. Отправляет претензию только сотрудник.";
    }

    /** Права проверяет сам инструмент: описание и подсказки readOnlyHint модель может не читать, а клиент — подделать. */
    private static void requireScope(McpSyncRequestContext ctx, String scope) {
        // режим lab.oauth: токен проверил Spring Security; виден ли он в потоке, где выполняется инструмент?
        var a = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        if (Boolean.getBoolean("lab.oauth")) {
            System.out.println("инструмент в потоке " + Thread.currentThread().getName() + ", authentication=" + (a == null ? "null" : a.getName() + " " + a.getAuthorities()));
            if (a == null) throw new SecurityException("в потоке инструмента нет аутентификации");
            if (a.getAuthorities().stream().noneMatch(g -> g.getAuthority().equals("SCOPE_" + scope)))
                throw new SecurityException("нет права " + scope + " у " + a.getName());
            return;
        }
        Object auth = ctx.transportContext().get("authorization");
        if (auth == null) return;   // режим без проверки (автонастройка по умолчанию): токен до инструмента не доходит
        String token = auth.toString().replaceFirst("^Bearer ", "");
        McpApp.Operator op = McpApp.TOKENS.get(token);
        if (op == null) throw new SecurityException("неизвестный токен");
        if (!op.scopes().contains(scope)) throw new SecurityException("нет права " + scope + " у " + op.id());
    }
}
