package dev.team.mcp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Гл. 82. С -Dlab.oauth=true MCP-сервер — ресурсный сервер OAuth 2.1: JWT от Keycloak, проверка iss и aud,
 * метаданные защищённого ресурса (RFC 9728) на /.well-known/oauth-protected-resource.
 * Без него Spring Security пропускает всё: проверку делают режимы по умолчанию и lab.secure.
 */
@Configuration
@org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication
class SecurityConfig {

    @Bean
    SecurityFilterChain chain(HttpSecurity http, @Value("${lab.oauth:false}") boolean oauth,
                              @Value("${lab.issuer:http://127.0.0.1:18180/realms/tundra}") String issuer) throws Exception {
        http.csrf(c -> c.disable()).sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
        if (!oauth) {
            return http.authorizeHttpRequests(a -> a.anyRequest().permitAll()).build();
        }
        return http
                .authorizeHttpRequests(a -> a.requestMatchers("/mcp/**", "/mcp").hasAuthority("SCOPE_payments:read")
                        .anyRequest().permitAll())
                .oauth2ResourceServer(rs -> rs
                        .jwt(j -> {})
                        .protectedResourceMetadata(m -> m.protectedResourceMetadataCustomizer(b -> b
                                .resource("http://localhost:8079/mcp")
                                .authorizationServer(issuer)
                                .scope("payments:read").scope("disputes:write")
                                .resourceName("Помощник операциониста"))))
                .build();
    }
}
