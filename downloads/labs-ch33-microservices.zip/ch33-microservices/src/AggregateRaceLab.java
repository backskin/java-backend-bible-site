
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Два редких случая агрегата: «неизменяемый» список наружу оказывается представлением, а проверка инварианта без блокировки
 * пропускает нарушение при двух параллельных добавлениях. Зависимостей нет (JDK 21). Запуск: main.
 */
public class AggregateRaceLab {

    static class Order {
        private final long limit = 1000;
        private final List<Long> lines = new ArrayList<>();

        void add(long amount) {
            if (total() + amount > limit) throw new IllegalStateException("лимит " + limit);
            lines.add(amount);
        }

        long total() { long s = 0; for (long l : lines) s += l; return s; }

        List<Long> viewLines() { return Collections.unmodifiableList(lines); }

        List<Long> copyLines() { return List.copyOf(lines); }
    }

    static void viewVersusCopy() {
        System.out.println("=== 4.2 «неизменяемый» список наружу: представление против копии");
        Order order = new Order();
        order.add(300);
        List<Long> view = order.viewLines();
        List<Long> copy = order.copyLines();
        order.add(400);
        System.out.println("  после добавления 400 корнем: представление " + view + ", копия " + copy);
        try { view.add(999L); } catch (UnsupportedOperationException e) { System.out.println("  запись через представление: UnsupportedOperationException"); }
    }

    static void checkThenActRace() throws Exception {
        System.out.println("=== 4.2 проверка инварианта без блокировки: два потока добавляют по 600 при лимите 1000");
        int rounds = 20_000, violated = 0, rejected = 0;
        AtomicInteger crashed = new AtomicInteger();
        for (int i = 0; i < rounds; i++) {
            Order order = new Order();
            CyclicBarrier start = new CyclicBarrier(2);
            Runnable add = () -> {
                try { start.await(); order.add(600); } catch (IllegalStateException ignored) { } catch (java.util.ConcurrentModificationException e) { crashed.incrementAndGet(); } catch (Exception e) { throw new RuntimeException(e); }
            };
            Thread a = new Thread(add), b = new Thread(add);
            a.start(); b.start(); a.join(); b.join();
            if (order.total() > order.limit) violated++; else rejected++;
        }
        System.out.println("  из " + rounds + " раундов лимит нарушен в " + violated + ", второе добавление отклонено в " + rejected + ", поток упал с ConcurrentModificationException в " + crashed.get());
    }

    public static void main(String[] args) throws Exception {
        viewVersusCopy();
        checkThenActRace();
    }
}
