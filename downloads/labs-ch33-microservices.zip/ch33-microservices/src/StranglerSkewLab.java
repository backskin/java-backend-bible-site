
import java.util.Arrays;
import java.util.Random;

/**
 * Постепенный перенос по ключу клиента: какую долю трафика получает новый сервис, если в него отправлены 10% клиентов.
 * Нагрузка по клиентам неравномерна (закон Ципфа: клиент номер k даёт трафик, пропорциональный 1/k). Зависимостей нет (JDK 21). Запуск: main.
 */
public class StranglerSkewLab {

    public static void main(String[] args) {
        int clients = 10_000, trials = 1000, percent = 10;
        double[] weight = new double[clients];
        double total = 0;
        for (int k = 0; k < clients; k++) { weight[k] = 1.0 / (k + 1); total += weight[k]; }
        double[] share = new double[trials];
        for (int t = 0; t < trials; t++) {
            Random hash = new Random(t);                       // другая «соль» хеша ключа в каждом прогоне
            double toNew = 0;
            int moved = 0;
            for (int k = 0; k < clients; k++) if (hash.nextInt(100) < percent) { toNew += weight[k]; moved++; }
            share[t] = 100 * toNew / total;
        }
        Arrays.sort(share);
        System.out.printf("=== 7.1 перенос по ключу клиента: в новый сервис отправлено %d%% клиентов (%d клиентов, %d прогонов с разной солью хеша)%n", percent, clients, trials);
        System.out.printf("  доля трафика нового сервиса: минимум %.1f%%, медиана %.1f%%, максимум %.1f%%%n", share[0], share[trials / 2], share[trials - 1]);
        double top = 100 * weight[0] / total;
        System.out.printf("  самый крупный клиент даёт %.1f%% трафика всей системы; на 10%% клиентов он попадает случайно%n", top);
    }
}
