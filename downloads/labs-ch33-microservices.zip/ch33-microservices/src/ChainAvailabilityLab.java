import java.util.Random;

/**
 * Опыт гл. 33, разд. 1.4: доступность цепочки синхронных вызовов.
 * Каждый сервис отвечает успешно с вероятностью 0,995 независимо от остальных; запрос успешен, только если ответили все.
 * Моделирование сверяется с формулой 0,995^n, а доля отказов переводится в часы в году.
 * Запуск: java ChainAvailabilityLab.java (JDK 21, без зависимостей).
 */
public class ChainAvailabilityLab {

    public static void main(String[] args) {
        Random rnd = new Random(7);
        int calls = 1_000_000;
        double p = 0.995;
        for (int depth : new int[] {1, 3, 5, 8, 20}) {
            int ok = 0;
            for (int i = 0; i < calls; i++) {
                boolean all = true;
                for (int s = 0; s < depth && all; s++) all = rnd.nextDouble() < p;
                if (all) ok++;
            }
            double formula = Math.pow(p, depth);
            System.out.printf("цепочка из %2d: моделирование %.2f%%, формула 0,995^%d = %.2f%%, недоступность в год по формуле %.0f ч%n",
                    depth, 100.0 * ok / calls, depth, 100 * formula, (1 - formula) * 365 * 24);
        }
    }
}
