

import com.sun.net.httpserver.HttpServer;

import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.function.LongUnaryOperator;

/**
 * Распределённый монолит, цена сетевого вызова, агрегат, контексты и постепенный перенос (strangler fig).
 * Зависимостей нет (только JDK 21): запуск main.
 */
public class MicroservicesDemo {

    // ---------------------------------------------------------------- 1.4: сколько стоит сетевой вызов вместо вызова метода
    static long limitFor(long clientId) { return 1000 + clientId % 7; }

    static void callCost() throws Exception {
        System.out.println("=== 1.4 цена границы между модулями: вызов метода и HTTP-вызов на localhost");
        HttpServer server = HttpServer.create(new InetSocketAddress(0), 0);
        server.createContext("/limit", ex -> {
            byte[] body = Long.toString(limitFor(42)).getBytes();
            ex.sendResponseHeaders(200, body.length);
            ex.getResponseBody().write(body);
            ex.close();
        });
        server.start();
        HttpClient http = HttpClient.newHttpClient();
        HttpRequest req = HttpRequest.newBuilder(URI.create("http://localhost:" + server.getAddress().getPort() + "/limit")).build();
        for (int i = 0; i < 300; i++) http.send(req, HttpResponse.BodyHandlers.ofString());          // прогрев
        long sink = 0;
        for (int i = 0; i < 1_000_000; i++) sink += limitFor(i);                                      // прогрев
        long t0 = System.nanoTime();
        for (int i = 0; i < 5_000_000; i++) sink += limitFor(i);
        double method = (System.nanoTime() - t0) / 5e6;
        t0 = System.nanoTime();
        for (int i = 0; i < 2000; i++) http.send(req, HttpResponse.BodyHandlers.ofString());
        double network = (System.nanoTime() - t0) / 2000.0;
        server.stop(0);
        System.out.printf("  вызов метода: %.1f нс; HTTP на localhost (без сети, без TLS): %.0f мкс, то есть примерно в %.0f тысяч раз дольше (sink=%d)%n",
                method, network / 1000, network / Math.max(method, 0.1) / 1000, sink % 10);
    }

    // ---------------------------------------------------------------- 1.6: распределённый монолит и доступность
    static void chainAvailability() {
        System.out.println("=== 1.6 доступность цепочки синхронных вызовов: каждый сервис доступен на 99,5%");
        Random rnd = new Random(7);
        int calls = 1_000_000;
        for (int depth : new int[]{1, 3, 5, 8}) {
            int ok = 0;
            for (int i = 0; i < calls; i++) {
                boolean all = true;
                for (int s = 0; s < depth && all; s++) all = rnd.nextDouble() < 0.995;
                if (all) ok++;
            }
            System.out.printf("  цепочка из %d сервисов: доступность %.2f%% (расчёт 0,995^%d = %.2f%%)%n", depth, 100.0 * ok / calls, depth, 100 * Math.pow(0.995, depth));
        }
    }

    // ---------------------------------------------------------------- 4.2: агрегат как граница согласованности
    static class OrderLine { final String sku; final long amount; OrderLine(String sku, long amount) { this.sku = sku; this.amount = amount; } }

    /** Анемичная модель: список наружу, инвариант проверяет кто угодно и когда угодно. */
    static class LooseOrder {
        final long limit = 1000;
        final List<OrderLine> lines = new ArrayList<>();
        long total() { return lines.stream().mapToLong(l -> l.amount).sum(); }
    }

    /** Агрегат: инвариант «сумма не больше лимита» проверяет корень, наружу отдаётся только неизменяемое представление. */
    static class Order {
        private final long limit = 1000;
        private final List<OrderLine> lines = new ArrayList<>();
        void add(String sku, long amount) {
            if (total() + amount > limit) throw new IllegalStateException("превышен лимит заказа " + limit + ": было бы " + (total() + amount));
            lines.add(new OrderLine(sku, amount));
        }
        long total() { return lines.stream().mapToLong(l -> l.amount).sum(); }
        List<OrderLine> lines() { return Collections.unmodifiableList(lines); }
    }

    static void aggregate() {
        System.out.println("=== 4.2 агрегат как граница согласованности: лимит заказа 1000");
        LooseOrder loose = new LooseOrder();
        loose.lines.add(new OrderLine("A", 700));
        loose.lines.add(new OrderLine("B", 700));                              // код снаружи добавил строку мимо проверки
        System.out.println("  модель без корня: сумма " + loose.total() + " при лимите " + loose.limit + " (инвариант нарушен, ошибки нет)");
        Order order = new Order();
        order.add("A", 700);
        try { order.add("B", 700); } catch (IllegalStateException e) { System.out.println("  агрегат: " + e.getMessage()); }
        try { order.lines().add(new OrderLine("C", 700)); } catch (UnsupportedOperationException e) { System.out.println("  агрегат: добавить строку в обход корня нельзя (UnsupportedOperationException), сумма " + order.total()); }
    }

    // ---------------------------------------------------------------- 3.3: ограниченный контекст
    record PaymentsClient(String id, String name, String inn) {}                // клиент в платежах: реквизиты
    record CreditClient(String id, int creditScore, boolean employed) {}        // клиент в кредитах: платёжеспособность

    /** Слой перевода (anti-corruption layer): принимает чужую модель и отдаёт свою, не пропуская чужие термины внутрь. */
    static CreditClient toCredit(PaymentsClient p) { return new CreditClient(p.id(), p.inn().endsWith("7") ? 540 : 710, true); }

    static void boundedContext() {
        System.out.println("=== 3.3 ограниченный контекст: одно слово «клиент», две разные модели");
        PaymentsClient p = new PaymentsClient("c-1", "ООО Ромашка", "7701234567");
        System.out.println("  в платежах: " + p);
        System.out.println("  в кредитах: " + toCredit(p) + " (через слой перевода; общей модели «Клиент» нет)");
    }

    // ---------------------------------------------------------------- 7.1: strangler fig
    static void strangler() {
        System.out.println("=== 7.1 постепенный перенос (strangler fig): 1000 запросов, доля нового сервиса растёт");
        LongUnaryOperator legacy = amount -> amount * 3 / 100;                                       // комиссия в старой системе
        LongUnaryOperator fresh = amount -> amount > 900 ? amount * 2 / 100 : amount * 3 / 100;      // в новой сервис содержит ошибку на крупных суммах
        for (int percent : new int[]{0, 10, 50, 100}) {
            int toNew = 0, mismatch = 0;
            for (int id = 0; id < 1000; id++) {
                long amount = 1 + (id * 37L) % 1000;
                boolean routeToNew = (id * 31 % 100) < percent;                                      // детерминированная маршрутизация по ключу
                if (routeToNew) toNew++;
                if (legacy.applyAsLong(amount) != fresh.applyAsLong(amount)) mismatch++;             // теневое сравнение: считаем оба и сверяем
            }
            System.out.printf("  доля нового сервиса %3d%%: запросов в новый %4d, расхождений в теневом сравнении %d%n", percent, toNew, mismatch);
        }
    }

    public static void main(String[] args) throws Exception {
        callCost();
        chainAvailability();
        aggregate();
        boundedContext();
        strangler();
    }
}
