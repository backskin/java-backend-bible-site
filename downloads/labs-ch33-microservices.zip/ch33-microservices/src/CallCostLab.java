import com.sun.net.httpserver.HttpServer;

import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;

/**
 * Опыт гл. 33, разд. 1.2: сколько стоит граница модуля, вынесенная в сеть.
 * Вызов метода в процессе и HTTP-вызов того же расчета лимита через loopback (без TLS, без настоящей сети).
 * Запуск: java CallCostLab.java (JDK 21, без зависимостей).
 */
public class CallCostLab {

    static long limitFor(long clientId) {
        return 100_000 + clientId % 7 * 10_000;
    }

    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/limit", ex -> {
            long id = Long.parseLong(ex.getRequestURI().getQuery().substring(3));
            byte[] body = ("{\"clientId\":" + id + ",\"limit\":" + limitFor(id) + "}").getBytes();
            ex.getResponseHeaders().add("Content-Type", "application/json");
            ex.sendResponseHeaders(200, body.length);
            ex.getResponseBody().write(body);
            ex.close();
        });
        server.start();
        String base = "http://127.0.0.1:" + server.getAddress().getPort() + "/limit?id=";
        HttpClient http = HttpClient.newHttpClient();

        long sink = 0;
        for (int i = 0; i < 2_000; i++) {
            sink += http.send(HttpRequest.newBuilder(URI.create(base + i)).build(), HttpResponse.BodyHandlers.ofString()).body().length();
        }
        int n = 5_000;
        long[] lat = new long[n];
        for (int i = 0; i < n; i++) {
            long t = System.nanoTime();
            sink += http.send(HttpRequest.newBuilder(URI.create(base + i)).build(), HttpResponse.BodyHandlers.ofString()).body().length();
            lat[i] = System.nanoTime() - t;
        }
        server.stop(0);
        Arrays.sort(lat);

        for (int i = 0; i < 10_000_000; i++) sink += limitFor(i);
        int m = 50_000_000;
        long t = System.nanoTime();
        for (int i = 0; i < m; i++) sink += limitFor(i);
        double method = (System.nanoTime() - t) / (double) m;

        System.out.println("java.version=" + System.getProperty("java.version") + ", os=" + System.getProperty("os.name"));
        System.out.printf("вызов метода в процессе: %.1f нс в среднем на %,d вызовов%n", method, m);
        System.out.printf("HTTP через loopback, %d вызовов после прогрева: медиана %d мкс, 99-й процентиль %d мкс, максимум %d мкс%n",
                n, lat[n / 2] / 1000, lat[n * 99 / 100] / 1000, lat[n - 1] / 1000);
        System.out.println("(sink=" + sink % 10 + ")");
    }
}
