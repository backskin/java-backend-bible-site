
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Доля совместных изменений двух частей репозитория по истории git: чем чаще коммит трогает обе части, тем слабее граница между ними.
 * Зависимостей нет (JDK 21, git в PATH). Запуск: main с аргументами «путь_репозитория префикс_A префикс_B», например «. book/ tools/».
 */
public class CoChangeLab {

    public static void main(String[] args) throws Exception {
        String repo = args.length > 0 ? args[0] : ".";
        String a = args.length > 1 ? args[1] : "book/";
        String b = args.length > 2 ? args[2] : "tools/";
        Process p = new ProcessBuilder("git", "-C", repo, "log", "--name-only", "--pretty=format:@@%h", "--no-merges").redirectErrorStream(true).start();
        int commits = 0, withA = 0, withB = 0, both = 0;
        boolean hasA = false, hasB = false, open = false;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("@@")) {
                    if (open) { commits++; if (hasA) withA++; if (hasB) withB++; if (hasA && hasB) both++; }
                    open = true; hasA = false; hasB = false;
                } else {
                    String f = line.replace("\"", "");
                    if (f.startsWith(a)) hasA = true;
                    if (f.startsWith(b)) hasB = true;
                }
            }
            if (open) { commits++; if (hasA) withA++; if (hasB) withB++; if (hasA && hasB) both++; }
        }
        p.waitFor();
        System.out.printf("=== 5.3 совместные изменения «%s» и «%s» по истории git%n", a, b);
        System.out.printf("  коммитов: %d; трогают %s: %d; трогают %s: %d; трогают обе части: %d%n", commits, a, withA, b, withB, both);
        System.out.printf("  доля совместных от коммитов с %s: %.0f%%; от коммитов с %s: %.0f%%%n", a, 100.0 * both / Math.max(withA, 1), b, 100.0 * both / Math.max(withB, 1));
    }
}
