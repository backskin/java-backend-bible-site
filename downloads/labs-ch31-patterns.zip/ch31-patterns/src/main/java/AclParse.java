import java.math.BigDecimal;
import java.util.Random;

/**
 * Опыт 11.6 главы 31: слой защиты от унаследованной системы (ACL) разбирает суммы АБС в формате «1 234,50»
 * (пробел между разрядами, запятая как десятичный знак). 1000 случайных сумм: прямой разбор, нормализация с BigDecimal
 * и нормализация с double. Запуск: mvn -q compile exec:java -Dexec.mainClass=AclParse
 */
public class AclParse {

    /** Сумма в копейках в формате АБС: группы разрядов через пробел, запятая перед копейками. */
    static String absFormat(long kop) {
        String rub = String.format("%,d", kop / 100).replace(',', ' ').replace(' ', ' ');
        return rub + "," + String.format("%02d", kop % 100);
    }

    public static void main(String[] args) {
        Random rnd = new Random(31);
        int directErrors = 0, decimalMismatch = 0, doubleMismatch = 0;
        for (int i = 0; i < 1000; i++) {
            long kop = 100_000 + (long) (rnd.nextDouble() * 10_000_000_000L);        // от 1 000,00 до ~100 млн руб.
            String s = absFormat(kop);
            BigDecimal expected = BigDecimal.valueOf(kop, 2);
            try { Double.parseDouble(s); } catch (NumberFormatException e) { directErrors++; }
            String normalized = s.replace(" ", "").replace(',', '.');
            if (new BigDecimal(normalized).compareTo(expected) != 0) decimalMismatch++;
            if (BigDecimal.valueOf(Double.parseDouble(normalized)).compareTo(expected) != 0) doubleMismatch++;
        }
        System.out.println("=== 11.6 ACL: 1000 сумм АБС в формате «1 234,50», пример: " + absFormat(123450));
        System.out.println("  Double.parseDouble(строка) без нормализации:              ошибок разбора " + directErrors + " из 1000");
        System.out.println("  нормализация (убрать пробелы, запятую на точку) и BigDecimal: расхождений " + decimalMismatch);
        System.out.println("  нормализация и double:                                     расхождений " + doubleMismatch + " (на этих значениях; для денег double не годится)");
    }
}
