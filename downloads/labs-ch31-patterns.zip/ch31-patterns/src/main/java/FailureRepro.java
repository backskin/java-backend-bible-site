import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Глава 31, раздел 13: опыты к упражнениям «Воспроизвести сбой», которых нет в других классах стенда.
 * 13.2 — неактивный слот логической репликации удерживает WAL, пока его не удалят или пока не сработает
 * {@code max_slot_wal_keep_size}; 13.4 — дедлайн саги со значением {@code 'infinity'} не виден заданию таймаутов.
 */
public class FailureRepro {
    static String url;

    static Connection open() throws SQLException { return DriverManager.getConnection(url); }

    static void exec(Connection c, String sql) throws SQLException { try (Statement s = c.createStatement()) { s.execute(sql); } }

    static String one(Connection c, String sql) throws SQLException {
        try (Statement s = c.createStatement(); ResultSet r = s.executeQuery(sql)) { return r.next() ? r.getString(1) : "нет строк"; }
    }

    static String walSize(Connection c) throws SQLException { return one(c, "SELECT pg_size_pretty(sum(size)) FROM pg_ls_waldir()"); }

    static String slot(Connection c) throws SQLException {
        return one(c, "SELECT 'active=' || active || ', wal_status=' || coalesce(wal_status, '-') || ', удерживает ' "
                + "|| coalesce(pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn)), '-') FROM pg_replication_slots WHERE slot_name = 'dbz_payments_stage'");
    }

    /** Около 100 МБ журнала: 400 тысяч строк по 200 символов. */
    static void writeWal(Connection c) throws SQLException {
        exec(c, "INSERT INTO payments_pad SELECT g, repeat('x', 200) FROM generate_series(1, 400000) g");
        exec(c, "SELECT pg_switch_wal()");
        exec(c, "CHECKPOINT");
    }

    static void slotKeepsWal() throws SQLException {
        System.out.println("=== 13.2 неактивный слот логической репликации и WAL");
        try (Connection c = open()) {
            exec(c, "CREATE TABLE payments_pad(id int, s text)");
            System.out.println("  max_slot_wal_keep_size = " + one(c, "SHOW max_slot_wal_keep_size") + ", pg_wal до опыта: " + walSize(c));
            exec(c, "SELECT pg_create_logical_replication_slot('dbz_payments_stage', 'test_decoding')");
            writeWal(c);
            System.out.println("  слот создан, читателя нет, записано ~100 МБ: " + slot(c) + "; pg_wal " + walSize(c));
            writeWal(c);
            System.out.println("  ещё ~100 МБ:                              " + slot(c) + "; pg_wal " + walSize(c));
            exec(c, "SELECT pg_drop_replication_slot('dbz_payments_stage')");
            exec(c, "CHECKPOINT");
            System.out.println("  pg_drop_replication_slot + CHECKPOINT: pg_wal " + walSize(c));

            exec(c, "ALTER SYSTEM SET max_slot_wal_keep_size = '64MB'");
            exec(c, "SELECT pg_reload_conf()");
            exec(c, "SELECT pg_create_logical_replication_slot('dbz_payments_stage', 'test_decoding')");
            writeWal(c);
            writeWal(c);
            System.out.println("  max_slot_wal_keep_size = " + one(c, "SHOW max_slot_wal_keep_size") + ", новый слот, записано ~200 МБ: " + slot(c) + "; pg_wal " + walSize(c));
            try {
                exec(c, "SELECT * FROM pg_logical_slot_get_changes('dbz_payments_stage', NULL, 1)");
                System.out.println("  чтение из слота: прошло");
            } catch (SQLException e) {
                System.out.println("  чтение из слота: " + e.getMessage().lines().findFirst().orElse(""));
            }
            exec(c, "SELECT pg_drop_replication_slot('dbz_payments_stage')");
            exec(c, "DROP TABLE payments_pad");
        }
    }

    static void infiniteDeadline() throws SQLException {
        System.out.println("=== 13.4 дедлайн шага саги по умолчанию 'infinity'");
        try (Connection c = open()) {
            exec(c, "CREATE TABLE transfer_saga(id text PRIMARY KEY, state text, created_at timestamptz NOT NULL DEFAULT now(), "
                    + "deadline_at timestamptz NOT NULL DEFAULT 'infinity')");
            exec(c, "INSERT INTO transfer_saga(id, state, created_at, deadline_at) VALUES ('S-1', 'HOLDING', now() - interval '3 days', now() - interval '3 days' + interval '15 minutes')");
            exec(c, "INSERT INTO transfer_saga(id, state, created_at) VALUES ('S-2', 'CREDITING', now() - interval '3 days')");
            System.out.println("  саги:                                  " + one(c, "SELECT string_agg(id || ' ' || state || ' deadline ' || deadline_at::text, '; ' ORDER BY id) FROM transfer_saga"));
            System.out.println("  задание таймаутов, deadline_at < now(): " + one(c, "SELECT coalesce(string_agg(id, ', '), 'никого') FROM transfer_saga WHERE deadline_at < now()"));
            System.out.println("  мониторинг по возрасту, created_at < now() - 15 мин: " + one(c, "SELECT string_agg(id, ', ' ORDER BY id) FROM transfer_saga WHERE state NOT IN ('COMPLETED', 'FAILED') AND created_at < now() - interval '15 minutes'"));
            exec(c, "DELETE FROM transfer_saga WHERE id = 'S-2'");
            exec(c, "ALTER TABLE transfer_saga ALTER COLUMN deadline_at DROP DEFAULT");
            exec(c, "ALTER TABLE transfer_saga ADD CONSTRAINT deadline_bounded CHECK (deadline_at < created_at + interval '1 day')");
            try {
                exec(c, "INSERT INTO transfer_saga(id, state, created_at) VALUES ('S-3', 'CREDITING', now())");
                System.out.println("  вставка без дедлайна: прошла");
            } catch (SQLException e) {
                System.out.println("  вставка без дедлайна:  " + e.getMessage().lines().findFirst().orElse(""));
            }
            try {
                exec(c, "INSERT INTO transfer_saga(id, state, deadline_at) VALUES ('S-4', 'CREDITING', 'infinity')");
                System.out.println("  вставка с 'infinity': прошла");
            } catch (SQLException e) {
                System.out.println("  вставка с 'infinity':  " + e.getMessage().lines().findFirst().orElse(""));
            }
            exec(c, "DROP TABLE transfer_saga");
        }
    }

    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.builder()
                .setServerConfig("wal_level", "logical")
                .setServerConfig("max_replication_slots", "4")
                .setServerConfig("max_wal_senders", "4")
                .setServerConfig("min_wal_size", "32MB")
                .setServerConfig("max_wal_size", "64MB")
                .setServerConfig("fsync", "on")
                .setServerConfig("synchronous_commit", "on")
                .start()) {
            url = pg.getJdbcUrl("postgres", "postgres");
            slotKeepsWal();
            infiniteDeadline();
        }
    }
}
