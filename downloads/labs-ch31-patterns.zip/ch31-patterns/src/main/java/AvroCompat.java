import org.apache.avro.Schema;
import org.apache.avro.SchemaCompatibility;

/**
 * Совместимость схем Avro для типичных изменений события: какие изменения проходят в сторону BACKWARD (новый читатель старых данных)
 * и FORWARD (старый читатель новых данных). Зависимость Maven: org.apache.avro:avro:1.12.0. Запуск: main.
 */
public class AvroCompat {

    static Schema parse(String json) { return new Schema.Parser().parse(json); }

    static String verdict(Schema reader, Schema writer) {
        return SchemaCompatibility.checkReaderWriterCompatibility(reader, writer).getType() == SchemaCompatibility.SchemaCompatibilityType.COMPATIBLE ? "проходит" : "ломает";
    }

    static String payment(String fields) {
        return "{\"type\":\"record\",\"name\":\"Payment\",\"namespace\":\"bank\",\"fields\":[" + fields + "]}";
    }

    static void row(String title, String oldS, String newS) {
        Schema o = parse(oldS), n = parse(newS);
        System.out.printf("  %-52s BACKWARD (новый читает старые данные): %-9s FORWARD (старый читает новые): %s%n", title, verdict(n, o), verdict(o, n));
    }

    public static void main(String[] args) {
        System.out.println("=== 7.5 совместимость схем Avro 1.12.0 для типичных изменений события Payment");
        String base = payment("{\"name\":\"id\",\"type\":\"string\"},{\"name\":\"amount\",\"type\":\"long\"},{\"name\":\"qty\",\"type\":\"int\"}");
        row("добавили поле currency без значения по умолчанию", base,
                payment("{\"name\":\"id\",\"type\":\"string\"},{\"name\":\"amount\",\"type\":\"long\"},{\"name\":\"qty\",\"type\":\"int\"},{\"name\":\"currency\",\"type\":\"string\"}"));
        row("добавили поле currency со значением по умолчанию", base,
                payment("{\"name\":\"id\",\"type\":\"string\"},{\"name\":\"amount\",\"type\":\"long\"},{\"name\":\"qty\",\"type\":\"int\"},{\"name\":\"currency\",\"type\":\"string\",\"default\":\"RUB\"}"));
        row("удалили поле qty (у него не было значения по умолчанию)", base,
                payment("{\"name\":\"id\",\"type\":\"string\"},{\"name\":\"amount\",\"type\":\"long\"}"));
        row("переименовали amount в sum без алиаса", base,
                payment("{\"name\":\"id\",\"type\":\"string\"},{\"name\":\"sum\",\"type\":\"long\"},{\"name\":\"qty\",\"type\":\"int\"}"));
        row("переименовали amount в sum с алиасом amount", base,
                payment("{\"name\":\"id\",\"type\":\"string\"},{\"name\":\"sum\",\"type\":\"long\",\"aliases\":[\"amount\"]},{\"name\":\"qty\",\"type\":\"int\"}"));
        row("расширили тип qty с int до long", base,
                payment("{\"name\":\"id\",\"type\":\"string\"},{\"name\":\"amount\",\"type\":\"long\"},{\"name\":\"qty\",\"type\":\"long\"}"));
        row("сузили тип amount с long до int", base,
                payment("{\"name\":\"id\",\"type\":\"string\"},{\"name\":\"amount\",\"type\":\"int\"},{\"name\":\"qty\",\"type\":\"int\"}"));
        String enumOld = payment("{\"name\":\"status\",\"type\":{\"type\":\"enum\",\"name\":\"Status\",\"symbols\":[\"NEW\",\"PAID\"]}}");
        row("добавили значение CANCELLED в enum", enumOld,
                payment("{\"name\":\"status\",\"type\":{\"type\":\"enum\",\"name\":\"Status\",\"symbols\":[\"NEW\",\"PAID\",\"CANCELLED\"]}}"));
        row("то же, но в enum задан default для неизвестных значений", payment("{\"name\":\"status\",\"type\":{\"type\":\"enum\",\"name\":\"Status\",\"symbols\":[\"NEW\",\"PAID\",\"UNKNOWN\"],\"default\":\"UNKNOWN\"}}"),
                payment("{\"name\":\"status\",\"type\":{\"type\":\"enum\",\"name\":\"Status\",\"symbols\":[\"NEW\",\"PAID\",\"UNKNOWN\",\"CANCELLED\"],\"default\":\"UNKNOWN\"}}"));
    }
}
