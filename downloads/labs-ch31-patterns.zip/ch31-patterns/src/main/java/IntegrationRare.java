import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;

import java.sql.*;
import java.util.*;

/**
 * Редкие случаи интеграции на PostgreSQL 15.5: порядок записей outbox при чтении «с отметки», абсолютная и относительная
 * компенсация саги, граница суток при сверке, запрос зависших саг с частичным индексом.
 * Зависимости Maven: io.zonky.test:embedded-postgres:2.0.7, бинарники сервера под вашу ОС, org.postgresql:postgresql:42.7.4.
 * Запуск: main (около минуты).
 */
public class IntegrationRare {

    static String url;

    static Connection open(boolean auto) throws SQLException {
        Connection c = DriverManager.getConnection(url, "postgres", "postgres");
        c.setAutoCommit(auto);
        return c;
    }

    static void exec(Connection c, String sql) throws SQLException {
        try (Statement st = c.createStatement()) { st.execute(sql); }
    }

    static List<String> rows(Connection c, String sql) throws SQLException {
        List<String> out = new ArrayList<>();
        try (Statement st = c.createStatement(); ResultSet r = st.executeQuery(sql)) {
            int n = r.getMetaData().getColumnCount();
            while (r.next()) { StringBuilder sb = new StringBuilder(); for (int i = 1; i <= n; i++) sb.append(i > 1 ? " | " : "").append(r.getString(i)); out.add(sb.toString()); }
        }
        return out;
    }

    // ---------------------------------------------------------------- 3.1 и 3.7 порядок записей outbox
    static void outboxOrder() throws Exception {
        System.out.println("=== 3.1 и 3.7 outbox: читатель «id > отметки» против читателя «published = false»");
        try (Connection setup = open(true)) { exec(setup, "DROP TABLE IF EXISTS outbox"); exec(setup, "CREATE TABLE outbox(id bigserial PRIMARY KEY, payload text, published boolean NOT NULL DEFAULT false)"); }
        try (Connection a = open(false); Connection b = open(true); Connection poller = open(false)) {
            exec(a, "INSERT INTO outbox(payload) VALUES ('A')");                         // id 1, транзакция ещё открыта
            exec(b, "INSERT INTO outbox(payload) VALUES ('B')");                         // id 2, зафиксирована сразу
            long watermark = 0;
            List<String> byWatermark = new ArrayList<>();
            for (String r : rows(poller, "SELECT id || ':' || payload FROM outbox WHERE id > " + watermark + " ORDER BY id")) { byWatermark.add(r); watermark = Long.parseLong(r.split(":")[0]); }
            poller.commit();
            a.commit();                                                                  // запись A (id 1) зафиксирована позже записи B (id 2)
            for (String r : rows(poller, "SELECT id || ':' || payload FROM outbox WHERE id > " + watermark + " ORDER BY id")) byWatermark.add(r);
            poller.commit();
            System.out.println("  чтение «id > отметки»: доставлено " + byWatermark + "; в таблице записей " + rows(poller, "SELECT count(*) FROM outbox").get(0));
        }
        try (Connection setup = open(true)) { exec(setup, "TRUNCATE outbox RESTART IDENTITY"); }
        try (Connection a = open(false); Connection b = open(true); Connection poller = open(false)) {
            exec(a, "INSERT INTO outbox(payload) VALUES ('A')");
            exec(b, "INSERT INTO outbox(payload) VALUES ('B')");
            List<String> byFlag = new ArrayList<>();
            for (int pass = 0; pass < 2; pass++) {
                for (String r : rows(poller, "SELECT id || ':' || payload FROM outbox WHERE NOT published ORDER BY id LIMIT 100 FOR UPDATE SKIP LOCKED")) {
                    byFlag.add(r);
                    exec(poller, "UPDATE outbox SET published = true WHERE id = " + r.split(":")[0]);
                }
                poller.commit();
                if (pass == 0) a.commit();
            }
            System.out.println("  чтение «published = false»: доставлено " + byFlag + " (запись A доставлена позже B, но не потеряна)");
        }
    }

    // ---------------------------------------------------------------- 5.4 абсолютная и относительная компенсация
    static void compensation() throws Exception {
        System.out.println("=== 5.4 компенсация саги: абсолютная («вернуть прежнее значение») и относительная («прибавить обратно»)");
        for (String mode : new String[]{"абсолютная: balance = 1000", "относительная: balance = balance + 300"}) {
            try (Connection c = open(true)) {
                exec(c, "DROP TABLE IF EXISTS acc"); exec(c, "CREATE TABLE acc(id int PRIMARY KEY, balance int)"); exec(c, "INSERT INTO acc VALUES (1, 1000)");
                exec(c, "UPDATE acc SET balance = balance - 300 WHERE id = 1");          // шаг 1 саги S1: списание 300
                exec(c, "UPDATE acc SET balance = balance + 500 WHERE id = 1");          // параллельная операция S2: пополнение 500
                exec(c, mode.startsWith("абсолютная") ? "UPDATE acc SET balance = 1000 WHERE id = 1" : "UPDATE acc SET balance = balance + 300 WHERE id = 1");   // компенсация S1
                System.out.printf("  %-42s итоговый баланс %s (ожидается 1500)%n", mode, rows(c, "SELECT balance FROM acc").get(0));
            }
        }
    }

    // ---------------------------------------------------------------- 9.4 граница суток при сверке
    static void cutoff() throws Exception {
        System.out.println("=== 9.4 сверка за сутки: мы считаем сутки по UTC, банк по Москве (1000 платежей на трёх сутках)");
        try (Connection c = open(true)) {
            exec(c, "DROP TABLE IF EXISTS pay"); exec(c, "CREATE TABLE pay(id int PRIMARY KEY, ts timestamptz NOT NULL, amount int)");
            exec(c, "INSERT INTO pay SELECT g, timestamptz '2026-10-19 00:00:00+00' + (g * 259.2) * interval '1 second', 100 FROM generate_series(0, 999) g");
            System.out.println("  по UTC за 20 октября:    " + rows(c, "SELECT count(*) || ' платежей, сумма ' || sum(amount) FROM pay WHERE (ts AT TIME ZONE 'UTC')::date = '2026-10-20'").get(0));
            System.out.println("  по Москве за 20 октября: " + rows(c, "SELECT count(*) || ' платежей, сумма ' || sum(amount) FROM pay WHERE (ts AT TIME ZONE 'Europe/Moscow')::date = '2026-10-20'").get(0));
            System.out.println("  платежей, попавших в разные сутки при двух способах счёта: "
                    + rows(c, "SELECT count(*) FROM pay WHERE (ts AT TIME ZONE 'UTC')::date <> (ts AT TIME ZONE 'Europe/Moscow')::date").get(0) + " из 1000 (ложные расхождения в сверке)");
            System.out.println("  сверка по идентификатору платежа с окном ±1 сутки: расхождений "
                    + rows(c, "SELECT count(*) FROM pay a JOIN pay b ON a.id = b.id WHERE abs(extract(epoch FROM (a.ts - b.ts))) > 86400").get(0));
        }
    }

    // ---------------------------------------------------------------- 13.4 запрос зависших саг
    static void stuckSagas() throws Exception {
        System.out.println("=== 13.4 запрос зависших саг по возрасту: 2 000 000 завершённых саг и 200 зависших");
        try (Connection c = open(true)) {
            exec(c, "DROP TABLE IF EXISTS saga"); exec(c, "CREATE TABLE saga(id bigint PRIMARY KEY, state text NOT NULL, updated_at timestamptz NOT NULL)");
            exec(c, "INSERT INTO saga SELECT g, 'DONE', now() - (g % 100000) * interval '1 second' FROM generate_series(1, 2000000) g");
            exec(c, "INSERT INTO saga SELECT 3000000 + g, 'HOLD', now() - interval '3 days' FROM generate_series(1, 200) g");
            exec(c, "ANALYZE saga");
            String q = "SELECT count(*) FROM saga WHERE state NOT IN ('DONE', 'FAILED') AND updated_at < now() - interval '1 hour'";
            System.out.println("  без индекса:                       " + plan(c, q));
            exec(c, "CREATE INDEX saga_open_idx ON saga(updated_at) WHERE state NOT IN ('DONE', 'FAILED')");
            exec(c, "ANALYZE saga");
            System.out.println("  с частичным индексом:               " + plan(c, q));
            System.out.println("  размер индекса / таблицы: " + rows(c, "SELECT pg_size_pretty(pg_relation_size('saga_open_idx')) || ' / ' || pg_size_pretty(pg_relation_size('saga'))").get(0));
        }
    }

    static String plan(Connection c, String q) throws SQLException {
        String access = "?", time = "?";
        for (String l : rows(c, "EXPLAIN (ANALYZE, TIMING OFF) " + q)) {
            if (l.contains("Seq Scan") || l.contains("Index") || l.contains("Bitmap")) access = l.trim().replaceAll("\\s*\\(cost.*", "");
            if (l.contains("Execution Time")) time = l.trim();
        }
        return access + "; " + time;
    }

    // ---------------------------------------------------------------- 3.9 чистка outbox: DELETE против DETACH CONCURRENTLY + DROP
    static long walBytes(Connection c, String from) throws SQLException {
        return Long.parseLong(rows(c, "SELECT pg_wal_lsn_diff(pg_current_wal_lsn(), '" + from + "')::bigint").get(0));
    }

    static void cleanup() throws Exception {
        System.out.println("=== 3.9 чистка одного дня outbox: DELETE против DETACH PARTITION CONCURRENTLY + DROP (2 млн строк за три дня)");
        for (String mode : new String[]{"DELETE", "DETACH+DROP"}) {
            try (Connection c = open(true)) {
                exec(c, "DROP TABLE IF EXISTS outbox CASCADE");
                exec(c, "CREATE TABLE outbox(id bigint, occurred_at timestamptz NOT NULL, payload text, PRIMARY KEY (occurred_at, id)) PARTITION BY RANGE (occurred_at)");
                for (int d = 15; d <= 17; d++)
                    exec(c, "CREATE TABLE outbox_2026_09_" + d + " PARTITION OF outbox FOR VALUES FROM ('2026-09-" + d + " 00:00+00') TO ('2026-09-" + (d + 1) + " 00:00+00')");
                exec(c, "INSERT INTO outbox SELECT g, timestamptz '2026-09-15 00:00:00+00' + (g * 0.1296) * interval '1 second', repeat('x', 100) FROM generate_series(0, 1999999) g");
                exec(c, "CHECKPOINT");
                String sizeBefore = rows(c, "SELECT pg_size_pretty(sum(pg_total_relation_size(inhrelid))) FROM pg_inherits WHERE inhparent = 'outbox'::regclass").get(0);
                String lsn = rows(c, "SELECT pg_current_wal_lsn()").get(0);
                long t0 = System.nanoTime();
                if (mode.equals("DELETE")) {
                    exec(c, "DELETE FROM outbox WHERE occurred_at < '2026-09-16 00:00+00'");
                } else {
                    exec(c, "ALTER TABLE outbox DETACH PARTITION outbox_2026_09_15 CONCURRENTLY");
                    exec(c, "DROP TABLE outbox_2026_09_15");
                }
                long ms = (System.nanoTime() - t0) / 1_000_000;
                long wal = walBytes(c, lsn);
                String sizeAfter = rows(c, "SELECT pg_size_pretty(sum(pg_total_relation_size(inhrelid))) FROM pg_inherits WHERE inhparent = 'outbox'::regclass").get(0);
                System.out.printf("  %-12s удалено строк дня 15.09, %5d мс, WAL %,d байт, размер outbox %s -> %s%n", mode, ms, wal, sizeBefore, sizeAfter);
            }
        }
        try (Connection c = open(false)) {
            exec(c, "ALTER TABLE outbox DETACH PARTITION outbox_2026_09_16 CONCURRENTLY");
            c.commit();
        } catch (SQLException e) {
            System.out.println("  DETACH CONCURRENTLY внутри транзакции: " + e.getMessage().lines().findFirst().orElse(""));
        }
    }

    // ---------------------------------------------------------------- 4.7 гонка на дубле: «проверить, затем вставить» против уникального ключа
    static void dupRace() throws Exception {
        System.out.println("=== 4.7 два потребителя одновременно получили одно сообщение m-1 (сумма 500)");
        for (boolean uniqueKey : new boolean[]{false, true}) {
            try (Connection c = open(true)) {
                exec(c, "DROP TABLE IF EXISTS inbox"); exec(c, "DROP TABLE IF EXISTS journal");
                exec(c, uniqueKey ? "CREATE TABLE inbox(msg_key text PRIMARY KEY)" : "CREATE TABLE inbox(msg_key text)");
                exec(c, "CREATE TABLE journal(msg_key text, amount int)");
            }
            java.util.concurrent.CyclicBarrier barrier = new java.util.concurrent.CyclicBarrier(2);
            Runnable consumer = () -> {
                try (Connection c = open(false)) {
                    if (!uniqueKey) {
                        boolean seen = !rows(c, "SELECT 1 FROM inbox WHERE msg_key = 'm-1'").isEmpty();
                        barrier.await();                                        // оба уже проверили, ни один ещё не вставил
                        if (!seen) { exec(c, "INSERT INTO journal VALUES ('m-1', 500)"); exec(c, "INSERT INTO inbox VALUES ('m-1')"); }
                    } else {
                        barrier.await();                                        // оба вставляют одновременно
                        int inserted;
                        try (Statement st = c.createStatement()) { inserted = st.executeUpdate("INSERT INTO inbox VALUES ('m-1') ON CONFLICT DO NOTHING"); }
                        if (inserted == 1) exec(c, "INSERT INTO journal VALUES ('m-1', 500)");   // второй ждёт фиксации первого и получает 0
                    }
                    c.commit();
                } catch (Exception e) { throw new RuntimeException(e); }
            };
            Thread a = new Thread(consumer), b = new Thread(consumer);
            a.start(); b.start(); a.join(); b.join();
            try (Connection c = open(true)) {
                String n = rows(c, "SELECT count(*) FROM journal").get(0);
                System.out.println(uniqueKey ? "  уникальный ключ + INSERT ... ON CONFLICT DO NOTHING:     проводок в журнале " + n
                                             : "  без уникального ключа, «проверить, затем вставить»:     проводок в журнале " + n + " (ожидали 1)");
            }
        }
    }

    // ---------------------------------------------------------------- 5.5 оркестратор саги падает: состояние в памяти против состояния в базе
    // Сага заказа: резерв товара, списание денег, отгрузка. 500 заказов; в 20 % отгрузка отказывает (компенсация: возврат денег
    // и снятие резерва), в 50 % оркестратор падает после первого или второго шага и перезапускается.
    static class Crash extends RuntimeException {}

    static void runSaga(Connection c, int o, boolean persisted, int crashAt, boolean shipFails) throws SQLException {
        int step = 0;
        if (persisted) {
            List<String> row = rows(c, "SELECT state || ':' || step FROM saga WHERE id = " + o);
            if (!row.isEmpty()) {
                String[] s = row.get(0).split(":");
                if (s[0].equals("DONE") || s[0].equals("COMPENSATED")) return;
                step = Integer.parseInt(s[1]);
            } else exec(c, "INSERT INTO saga VALUES (" + o + ", 'RUNNING', 0)");
        }
        boolean idem = persisted;                                   // идемпотентные шаги только во втором варианте
        try {
            if (step < 1) {
                exec(c, idem ? "INSERT INTO stock_res(order_id, qty) VALUES (" + o + ", 1) ON CONFLICT (order_id) DO NOTHING"
                             : "INSERT INTO stock_res(order_id, qty) VALUES (" + o + ", 1) ON CONFLICT (order_id) DO UPDATE SET qty = stock_res.qty + 1");
                step = 1;
                if (persisted) exec(c, "UPDATE saga SET step = 1 WHERE id = " + o);
                if (crashAt == 1) throw new Crash();
            }
            if (step < 2) {
                if (!(idem && !rows(c, "SELECT 1 FROM charges WHERE order_id = " + o).isEmpty()))
                    exec(c, "INSERT INTO charges(order_id, amount) VALUES (" + o + ", 100)");
                step = 2;
                if (persisted) exec(c, "UPDATE saga SET step = 2 WHERE id = " + o);
                if (crashAt == 2) throw new Crash();
            }
            if (step < 3) {
                if (shipFails) throw new IllegalStateException("склад отказал");
                exec(c, "INSERT INTO shipments VALUES (" + o + ") ON CONFLICT DO NOTHING");
                if (persisted) exec(c, "UPDATE saga SET step = 3, state = 'DONE' WHERE id = " + o);
            }
        } catch (IllegalStateException e) {                         // отказ шага: компенсации
            exec(c, "UPDATE charges SET refunded = true WHERE order_id = " + o);
            exec(c, "UPDATE stock_res SET released = true WHERE order_id = " + o);
            if (persisted) exec(c, "UPDATE saga SET state = 'COMPENSATED' WHERE id = " + o);
        }
    }

    static void sagaCrash() throws Exception {
        System.out.println("=== 5.5 оркестратор саги заказа падает: 500 заказов, 20 % отказов отгрузки, 50 % падений после шага 1 или 2");
        try (Connection c = open(true)) {
            for (String tb : new String[]{"saga", "stock_res", "charges", "shipments"}) exec(c, "DROP TABLE IF EXISTS " + tb);
            exec(c, "CREATE TABLE saga(id int PRIMARY KEY, state text, step int)");
            exec(c, "CREATE TABLE stock_res(order_id int PRIMARY KEY, qty int, released boolean DEFAULT false)");
            exec(c, "CREATE TABLE charges(id serial PRIMARY KEY, order_id int, amount int, refunded boolean DEFAULT false)");
            exec(c, "CREATE TABLE shipments(order_id int PRIMARY KEY)");
            for (boolean persisted : new boolean[]{false, true}) {
                exec(c, "TRUNCATE saga, stock_res, charges, shipments RESTART IDENTITY");
                Random rnd = new Random(2);
                int crashed = 0;
                for (int o = 1; o <= 500; o++) {
                    int crashAt = new int[]{0, 0, 1, 2}[rnd.nextInt(4)];
                    boolean shipFails = rnd.nextDouble() < 0.2;
                    try {
                        runSaga(c, o, persisted, crashAt, shipFails);
                    } catch (Crash e) {
                        crashed++;
                        runSaga(c, o, persisted, 0, shipFails);     // перезапуск: с сохранённого шага или, без состояния, с начала
                    }
                }
                String dupCharge = rows(c, "SELECT count(*) FROM (SELECT order_id FROM charges GROUP BY order_id HAVING count(*) > 1) x").get(0);
                String dupStock = rows(c, "SELECT count(*) FROM stock_res WHERE qty > 1").get(0);
                String paidNotShipped = rows(c, "SELECT count(*) FROM charges ch WHERE NOT ch.refunded AND NOT EXISTS (SELECT 1 FROM shipments s WHERE s.order_id = ch.order_id)").get(0);
                String stuckStock = rows(c, "SELECT count(*) FROM stock_res r WHERE NOT r.released AND NOT EXISTS (SELECT 1 FROM shipments s WHERE s.order_id = r.order_id)").get(0);
                System.out.println((persisted ? "  состояние в PostgreSQL, шаги идемпотентны, продолжение с сохранённого шага: "
                                              : "  состояние в памяти, при падении повтор с начала:     ")
                        + "падений " + crashed + "; двойных списаний " + dupCharge + "; двойных резервов " + dupStock
                        + "; оплачено и не отправлено без возврата " + paidNotShipped + "; резерв висит " + stuckStock);
            }
        }
    }

    // ---------------------------------------------------------------- 13.1 отложенная проверка: отказ переезжает на фиксацию
    static void deferredCheck() throws Exception {
        System.out.println("=== 13.1 лимит как отложенная проверка: где падает транзакция");
        try (Connection c = open(true)) {
            exec(c, "DROP TABLE IF EXISTS transfers");
            try { exec(c, "CREATE TABLE transfers(id int, amount int CHECK (amount <= 1000) DEFERRABLE INITIALLY DEFERRED)"); }
            catch (SQLException e) { System.out.println("  CHECK ... DEFERRABLE у колонки: " + e.getMessage().lines().findFirst().orElse("")); }
            try { exec(c, "CREATE TABLE transfers(id int, amount int, CONSTRAINT lim CHECK (amount <= 1000) DEFERRABLE INITIALLY DEFERRED)"); }
            catch (SQLException e) { System.out.println("  CHECK ... DEFERRABLE у таблицы: " + e.getMessage().lines().findFirst().orElse("")); }
            exec(c, "CREATE TABLE transfers(id int, amount int)");
            exec(c, "CREATE FUNCTION daily_limit() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN "
                  + "IF (SELECT sum(amount) FROM transfers) > 1000 THEN RAISE EXCEPTION 'daily limit exceeded'; END IF; RETURN NULL; END $$");
            exec(c, "CREATE CONSTRAINT TRIGGER transfers_daily_limit_trg AFTER INSERT ON transfers DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION daily_limit()");
        }
        try (Connection c = open(false)) {
            exec(c, "INSERT INTO transfers VALUES (1, 1500)");
            System.out.println("  INSERT суммы сверх лимита: прошёл, транзакция ещё открыта (здесь send() в брокер уже успел бы уйти)");
            try { c.commit(); System.out.println("  COMMIT: прошёл"); }
            catch (SQLException e) { System.out.println("  COMMIT: " + e.getMessage().lines().findFirst().orElse("")); }
        }
        try (Connection c = open(true)) { exec(c, "DROP TABLE transfers"); exec(c, "DROP FUNCTION daily_limit()"); }
    }

    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.builder().setServerConfig("fsync", "on").setServerConfig("synchronous_commit", "on").start()) {
            url = pg.getJdbcUrl("postgres", "postgres");
            outboxOrder();
            compensation();
            cutoff();
            stuckSagas();
            cleanup();
            dupRace();
            sagaCrash();
            deferredCheck();
        }
    }
}
