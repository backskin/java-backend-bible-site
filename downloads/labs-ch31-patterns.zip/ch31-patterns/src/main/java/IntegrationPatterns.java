import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Двойная запись, outbox, идемпотентный потребитель, сага, повторы, сверка и совместимость событий.
 * Зависимости: io.zonky.test:embedded-postgres:2.0.7, бинарники сервера под вашу ОС, org.postgresql:postgresql,
 * com.fasterxml.jackson.core:jackson-databind. Брокер имитируется списком в памяти: так проще управлять сбоями.
 */
public class IntegrationPatterns {

    static String url;

    static Connection open(boolean autocommit) throws SQLException {
        Connection c = DriverManager.getConnection(url, "postgres", "postgres");
        c.setAutoCommit(autocommit);
        return c;
    }

    static void exec(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            ps.execute();
        }
    }

    static int update(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            return ps.executeUpdate();
        }
    }

    static long one(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getLong(1); }
        }
    }

    static List<String> rows(Connection c, String sql) throws SQLException {
        List<String> out = new ArrayList<>();
        try (Statement st = c.createStatement(); ResultSet r = st.executeQuery(sql)) {
            int n = r.getMetaData().getColumnCount();
            while (r.next()) {
                StringBuilder sb = new StringBuilder();
                for (int i = 1; i <= n; i++) sb.append(i > 1 ? " | " : "").append(r.getString(i));
                out.add(sb.toString());
            }
        }
        return out;
    }

    /** Брокер, который можно «выключить». Хранит всё, что в него успели отправить. */
    static class Broker {
        final List<String> log = new CopyOnWriteArrayList<>();
        volatile boolean down;
        void send(String eventId) {
            if (down) throw new IllegalStateException("брокер недоступен");
            log.add(eventId);
        }
    }

    static void reset() throws SQLException {
        try (Connection c = open(true)) {
            for (String t : new String[]{"outbox", "processed_events", "orders", "wallet", "saga", "limits", "bank_statement", "payments"})
                exec(c, "drop table if exists " + t + " cascade");
            exec(c, "create table orders(id text primary key, amount int not null check (amount > 0))");
            exec(c, "create table outbox(id text primary key, payload text not null, published boolean not null default false, created_at timestamptz default now())");
            exec(c, "create table processed_events(consumer text not null, event_id text not null, primary key (consumer, event_id))");
            exec(c, "create table wallet(id int primary key, balance int not null)");
            exec(c, "insert into wallet values (1, 1000)");
        }
    }

    // ---------------------------------------------------------------- 2.1 двойная запись
    static void dualWrite() throws Exception {
        System.out.println("=== 2.1 двойная запись без outbox");
        Broker broker = new Broker();
        // вариант А: сначала коммит в БД, потом отправка; между ними брокер падает
        try (Connection c = open(false)) {
            exec(c, "insert into orders values ('A-1', 100)");
            c.commit();
            broker.down = true;
            try { broker.send("A-1"); } catch (IllegalStateException e) { /* событие потеряно */ }
        }
        System.out.println("А. commit, затем send, брокер упал:       заказов в БД " + count("orders where id='A-1'") + ", событий в брокере " + broker.log.size());
        // вариант Б: сначала отправка, потом коммит; коммит падает (нарушение ограничения)
        broker.down = false;
        try (Connection c = open(false)) {
            broker.send("B-1");
            try { exec(c, "insert into orders values ('B-1', -5)"); c.commit(); } catch (SQLException e) { c.rollback(); }
        }
        System.out.println("Б. send, затем commit, commit упал:        заказов в БД " + count("orders where id='B-1'") + ", событий в брокере " + broker.log.size());
    }

    static long count(String from) throws SQLException {
        try (Connection c = open(true)) { return one(c, "select count(*) from " + from); }
    }

    // ---------------------------------------------------------------- 3.1 outbox
    static void outbox() throws Exception {
        reset();
        System.out.println("=== 3.1 outbox: заказ и событие в одной транзакции");
        try (Connection c = open(false)) {
            try {
                exec(c, "insert into orders values ('O-1', -5)");              // нарушение ограничения
                exec(c, "insert into outbox(id, payload) values ('E-1', 'OrderCreated O-1')");
                c.commit();
            } catch (SQLException e) { c.rollback(); }
        }
        System.out.println("транзакция откатилась целиком: заказов " + count("orders") + ", записей в outbox " + count("outbox"));
        try (Connection c = open(false)) {
            exec(c, "insert into orders values ('O-2', 100)");
            exec(c, "insert into outbox(id, payload) values ('E-2', 'OrderCreated O-2')");
            c.commit();
        }
        System.out.println("успешная транзакция: заказов " + count("orders") + ", неотправленных записей в outbox " + count("outbox where not published"));
    }

    // ---------------------------------------------------------------- 3.2 / 3.7 поллер и at-least-once
    static void poll(Broker broker, boolean crashBeforeMark) throws SQLException {
        try (Connection c = open(false)) {
            List<String> ids = new ArrayList<>();
            try (Statement st = c.createStatement();
                 ResultSet r = st.executeQuery("select id from outbox where not published order by created_at limit 3 for update skip locked")) {
                while (r.next()) ids.add(r.getString(1));
            }
            for (String id : ids) broker.send(id);                               // отправили в брокер
            if (crashBeforeMark) { c.rollback(); return; }                       // «упали» до пометки
            for (String id : ids) update(c, "update outbox set published = true where id = ?", id);
            c.commit();
        }
    }

    static void atLeastOnce(Broker broker) throws Exception {
        System.out.println("=== 3.2 поллер и доставка at-least-once");
        reset();
        try (Connection c = open(true)) {
            for (int i = 1; i <= 6; i++) exec(c, "insert into outbox(id, payload) values (?, 'e')", "E-" + i);
        }
        poll(broker, true);          // упали после отправки трёх событий, до пометки
        poll(broker, false);         // повтор: те же три строки снова непомеченные
        poll(broker, false);         // оставшиеся три
        Map<String, Long> perEvent = new TreeMap<>();
        for (String id : broker.log) perEvent.merge(id, 1L, Long::sum);
        long dups = perEvent.values().stream().filter(n -> n > 1).count();
        System.out.println("в брокере сообщений " + broker.log.size() + " (событий 6), доставлено дважды: " + dups + " " + perEvent.entrySet().stream().filter(e -> e.getValue() > 1).map(Map.Entry::getKey).toList());
        System.out.println("неотправленных в outbox: " + count("outbox where not published"));
    }

    // ---------------------------------------------------------------- 4.2 идемпотентный потребитель
    static void consumer(Broker broker) throws Exception {
        System.out.println("=== 4.2 потребитель: наивный и с таблицей processed_events");
        try (Connection c = open(true)) { exec(c, "update wallet set balance = 1000"); }
        for (String id : broker.log) {                                           // наивный: списывает на каждое сообщение
            try (Connection c = open(true)) { exec(c, "update wallet set balance = balance - 100 where id = 1"); }
        }
        System.out.println("наивный потребитель: сообщений " + broker.log.size() + ", баланс " + balance() + " (ожидалось " + (1000 - 600) + ")");
        try (Connection c = open(true)) { exec(c, "update wallet set balance = 1000"); }
        int applied = 0;
        for (String id : broker.log) {
            try (Connection c = open(false)) {
                int inserted = update(c, "insert into processed_events values ('wallet', ?) on conflict do nothing", id);
                if (inserted == 1) { exec(c, "update wallet set balance = balance - 100 where id = 1"); applied++; }
                c.commit();                                                      // запись о событии и эффект в одной транзакции
            }
        }
        System.out.println("идемпотентный потребитель: применено " + applied + " из " + broker.log.size() + " сообщений, баланс " + balance());
    }

    static long balance() throws SQLException {
        try (Connection c = open(true)) { return one(c, "select balance from wallet where id = 1"); }
    }

    // ---------------------------------------------------------------- 3.3 CDC
    static void cdc() throws Exception {
        System.out.println("=== 3.3 CDC: что видит читатель журнала (test_decoding вместо pgoutput)");
        reset();
        try (Connection c = open(true)) {
            exec(c, "select pg_create_logical_replication_slot('outbox_slot', 'test_decoding')");
            try (Connection t = open(false)) {
                exec(t, "insert into orders values ('C-1', 50)");
                exec(t, "insert into outbox(id, payload) values ('E-C1', 'OrderCreated C-1')");
                t.commit();
            }
            for (String l : rows(c, "select data from pg_logical_slot_get_changes('outbox_slot', null, null)"))
                System.out.println("  " + l);
            exec(c, "select pg_drop_replication_slot('outbox_slot')");
        }
    }

    // ---------------------------------------------------------------- 5.x сага
    interface Step { void run() throws Exception; }

    static void saga() throws Exception {
        System.out.println("=== 5.2-5.4 сага с компенсациями и промежуточным состоянием");
        try (Connection c = open(true)) {
            exec(c, "create table limits(client int primary key, reserved int not null)");
            exec(c, "insert into limits values (1, 0)");
            exec(c, "create table saga(id text primary key, step text not null, status text not null, updated_at timestamptz not null default now())");
            exec(c, "create table payments(id text primary key, status text)");
        }
        for (String failAt : new String[]{"notify", "none", "after-pivot"}) runSaga(failAt);
    }

    static void runSaga(String failAt) throws Exception {
        String id = "S-" + failAt;
        List<String> log = new ArrayList<>();
        Deque<Step> compensations = new ArrayDeque<>();
        try (Connection c = open(true)) {
            exec(c, "insert into saga values (?, 'START', 'RUNNING')", id);
            try {
                // шаг 1: резерв лимита, локальная транзакция уже зафиксирована
                exec(c, "update limits set reserved = reserved + 100 where client = 1");
                compensations.push(() -> exec(c, "update limits set reserved = reserved - 100 where client = 1"));
                exec(c, "update saga set step='RESERVED', updated_at=now() where id=?", id);
                log.add("1 reserve: лимит зарезервирован");
                long seenByOthers = count("limits where reserved = 100");
                log.add("  параллельный читатель между шагами видит резерв: " + (seenByOthers == 1));
                // шаг 2: проведение платежа
                exec(c, "insert into payments values (?, 'DEBITED')", id);
                compensations.push(() -> exec(c, "delete from payments where id = '" + id + "'"));
                exec(c, "update saga set step='DEBITED', updated_at=now() where id=?", id);
                log.add("2 debit: платёж проведён");
                // шаг 3: уведомление банка (может упасть)
                if (failAt.equals("notify")) throw new IllegalStateException("банк отклонил запрос");
                // шаг 4 (pivot): отправка во внешнюю систему, после неё откатить нельзя
                exec(c, "update saga set step='PIVOT', updated_at=now() where id=?", id);
                log.add("3 pivot: платёж ушёл во внешнюю систему, компенсации после этого шага невозможны");
                if (failAt.equals("after-pivot")) throw new IllegalStateException("не пришло подтверждение");
                exec(c, "update saga set status='DONE' where id=?", id);
                log.add("сага завершена успешно");
            } catch (IllegalStateException e) {
                log.add("сбой: " + e.getMessage());
                if (failAt.equals("after-pivot")) {
                    exec(c, "update saga set status='STUCK_AFTER_PIVOT', updated_at=now() - interval '10 minutes' where id=?", id);
                    log.add("после pivot откат невозможен: сага помечена и ждёт повтора вперёд");
                } else {
                    while (!compensations.isEmpty()) { compensations.pop().run(); log.add("компенсация выполнена"); }
                    exec(c, "update saga set status='COMPENSATED' where id=?", id);
                }
            }
            log.add("итог: резерв лимита = " + one(c, "select reserved from limits where client = 1") + ", платёж в БД = " + one(c, "select count(*) from payments where id='" + id + "'"));
            if (!failAt.equals("none") && !failAt.equals("notify")) exec(c, "update limits set reserved = 0 where client = 1");
            if (failAt.equals("none")) exec(c, "update limits set reserved = 0 where client = 1");
        }
        System.out.println("--- сбой на шаге: " + failAt);
        for (String l : log) System.out.println("  " + l);
    }

    static void stuckSagas() throws Exception {
        try (Connection c = open(true)) {
            System.out.println("зависшие саги (не завершены и не обновлялись больше минуты):");
            for (String r : rows(c, "select id, step, status from saga where status not in ('DONE','COMPENSATED') and updated_at < now() - interval '1 minute'"))
                System.out.println("  " + r);
        }
    }

    // ---------------------------------------------------------------- 8.1 повторы
    static void retries() throws Exception {
        System.out.println("=== 8.1 блокирующий и неблокирующий повтор: порядок завершения пяти сообщений");
        List<String> blocking = new ArrayList<>(), nonBlocking = new ArrayList<>();
        int[] failsLeft = {0, 2, 0, 0, 0};                                      // сообщение №2 дважды не обработается
        for (int m = 0; m < 5; m++) {                                           // блокирующий: пока №2 повторяется, остальные стоят
            while (failsLeft[m] > 0) { failsLeft[m]--; Thread.sleep(100); }
            blocking.add("m" + (m + 1));
        }
        failsLeft = new int[]{0, 2, 0, 0, 0};
        Deque<Integer> retryTopic = new ArrayDeque<>();
        for (int m = 0; m < 5; m++) {                                           // неблокирующий: неудачное уходит в retry-топик
            if (failsLeft[m] > 0) { retryTopic.add(m); continue; }
            nonBlocking.add("m" + (m + 1));
        }
        while (!retryTopic.isEmpty()) {
            int m = retryTopic.poll();
            if (failsLeft[m]-- > 0) { retryTopic.add(m); continue; }
            nonBlocking.add("m" + (m + 1));
        }
        System.out.println("блокирующий:    " + blocking + " (остальные ждали повторов №2, около 200 мс)");
        System.out.println("неблокирующий:  " + nonBlocking + " (№2 ушло в retry-топик, остальные прошли сразу, порядок нарушен)");
    }

    // ---------------------------------------------------------------- 9.4 сверка
    static void reconciliation() throws Exception {
        System.out.println("=== 9.4 сверка: наши платежи против выписки банка");
        try (Connection c = open(true)) {
            exec(c, "create table bank_statement(ref text primary key, amount int)");
            exec(c, "delete from payments");
            exec(c, "insert into payments values ('P1','OK'),('P2','OK'),('P3','OK')");
            exec(c, "insert into bank_statement values ('P1',100),('P3',100),('P4',100)");   // P2 у банка нет, P4 у нас нет
            for (String r : rows(c, "select coalesce(p.id, b.ref) as ref, case when b.ref is null then 'есть у нас, нет в выписке' else 'есть в выписке, нет у нас' end "
                    + "from payments p full outer join bank_statement b on b.ref = p.id where p.id is null or b.ref is null order by 1"))
                System.out.println("  расхождение: " + r);
        }
    }

    // ---------------------------------------------------------------- 7.1 / 7.5 совместимость событий
    record OrderCreatedV1(String id, int amount) {}
    @JsonIgnoreProperties(ignoreUnknown = true)
    record OrderCreatedTolerant(String id, int amount) {}

    static void compatibility() throws Exception {
        System.out.println("=== 7.1/7.5 совместимость: производитель добавил поле, потом убрал");
        ObjectMapper strict = new ObjectMapper();                                // у Jackson 2 по умолчанию неизвестное поле = ошибка
        ObjectMapper tolerant = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String v2 = "{\"id\":\"O-1\",\"amount\":100,\"currency\":\"RUB\"}";    // новое поле currency
        String v3 = "{\"id\":\"O-1\",\"currency\":\"RUB\"}";                    // поле amount убрали
        for (Object[] c : new Object[][]{{"строгий потребитель, v2 с новым полем", strict, v2}, {"терпимый читатель, v2 с новым полем", tolerant, v2},
                {"терпимый читатель, v3 без поля amount", tolerant, v3}}) {
            try {
                OrderCreatedV1 e = ((ObjectMapper) c[1]).readValue((String) c[2], OrderCreatedV1.class);
                System.out.printf("  %-40s -> %s%n", c[0], e);
            } catch (Exception e) {
                System.out.printf("  %-40s -> %s%n", c[0], e.getClass().getSimpleName());
            }
        }
    }

    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.builder()
                .setServerConfig("wal_level", "logical")
                .setServerConfig("max_replication_slots", "4")      // во встроенной сборке без этого логическое декодирование ничего не отдаёт
                .setServerConfig("max_wal_senders", "4")
                .setServerConfig("fsync", "on")                     // во встроенной сборке fsync и synchronous_commit выключены,
                .setServerConfig("synchronous_commit", "on")        // а логическое декодирование видит только сброшенный на диск журнал
                .start()) {
            url = pg.getJdbcUrl("postgres", "postgres");
            reset();
            dualWrite();
            outbox();
            Broker broker = new Broker();
            atLeastOnce(broker);
            consumer(broker);
            cdc();
            reset();
            saga();
            stuckSagas();
            retries();
            reconciliation();
            compatibility();
        }
    }
}
