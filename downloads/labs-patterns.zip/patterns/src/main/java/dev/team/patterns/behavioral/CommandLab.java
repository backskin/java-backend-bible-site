package dev.team.patterns.behavioral;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Опыт разд. 2.16: команда как данные. Ночное списание комиссий хранится таблицей команд со статусом;
 * обработчик падает на шестой команде, после перезапуска доделывает остальные, а повторная доставка
 * уже выполненной команды отсекается ключом идемпотентности. Лямбду же сохранить нельзя.
 */
public class CommandLab {

    /** Команда - запись с данными и ключом идемпотентности; обработчик отдельно. */
    sealed interface BillingCommand extends Serializable {
        String key();
        record ChargeFee(String key, String account, BigDecimal amount) implements BillingCommand {}
        record ReverseFee(String key, String originalKey) implements BillingCommand {}
    }

    enum Status { PENDING, DONE }

    /** Таблица команд: ключ, команда, статус. */
    static final Map<String, BillingCommand> commands = new LinkedHashMap<>();
    static final Map<String, Status> status = new LinkedHashMap<>();
    /** Счета, по которым прошло списание: результат, который нельзя задвоить. */
    static final Map<String, BigDecimal> charged = new TreeMap<>();

    static void handle(BillingCommand c, String crashOnKey) {
        if (status.get(c.key()) == Status.DONE) {                   // повтор: уже выполнено
            System.out.println("  " + c.key() + " уже выполнена, пропуск");
            return;
        }
        if (c.key().equals(crashOnKey)) throw new IllegalStateException("узел упал на " + c.key());
        switch (c) {
            case BillingCommand.ChargeFee f -> charged.merge(f.account(), f.amount(), BigDecimal::add);
            case BillingCommand.ReverseFee r -> {
                var orig = (BillingCommand.ChargeFee) commands.get(r.originalKey());
                charged.merge(orig.account(), orig.amount().negate(), BigDecimal::add);
            }
        }
        status.put(c.key(), Status.DONE);
    }

    static void runWorker(String crashOnKey) {
        for (var e : commands.entrySet()) {
            if (status.get(e.getKey()) == Status.PENDING) handle(e.getValue(), crashOnKey);
        }
    }

    public static void main(String[] args) throws Exception {
        for (int i = 1; i <= 10; i++) {
            var c = new BillingCommand.ChargeFee("fee-" + i, "4070281000000000000" + (i % 3), new BigDecimal("99.00"));
            commands.put(c.key(), c);
            status.put(c.key(), Status.PENDING);
        }
        try {
            runWorker("fee-6");
        } catch (IllegalStateException e) {
            System.out.println("первый проход: " + e.getMessage() + "; выполнено " +
                    status.values().stream().filter(s -> s == Status.DONE).count() + " из 10");
        }
        runWorker(null);
        System.out.println("после перезапуска выполнено " + status.values().stream().filter(s -> s == Status.DONE).count() + " из 10");
        System.out.println("повторная доставка fee-3:");
        handle(commands.get("fee-3"), null);
        System.out.println("списано по счетам: " + charged);

        var reverse = new BillingCommand.ReverseFee("rev-1", "fee-1");
        commands.put(reverse.key(), reverse);
        status.put(reverse.key(), Status.PENDING);
        runWorker(null);
        System.out.println("после сторно fee-1: " + charged);

        System.out.println("сериализация команды-записи: " + serialize(commands.get("fee-2")) + " байт");
        Runnable lambda = () -> charged.merge("40702810000000000001", new BigDecimal("99.00"), BigDecimal::add);
        try {
            serialize(lambda);
        } catch (java.io.NotSerializableException e) {
            System.out.println("сериализация лямбды: NotSerializableException: " + e.getMessage());
        }
    }

    static int serialize(Object o) throws Exception {
        var bytes = new ByteArrayOutputStream();
        try (var out = new ObjectOutputStream(bytes)) { out.writeObject(o); }
        return bytes.size();
    }
}
