package dev.team.patterns.behavioral;

import java.time.Duration;
import java.time.Instant;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Опыт разд. 2.22: машина состояний платежа в перечислении и состояние с собственными данными
 * в запечатанной иерархии. Переход проверяется в одной точке, повторный переход в то же состояние
 * ничего не меняет, недопустимый - отклоняется; таблица переходов сверяется перебором всех пар.
 */
public class StateLab {

    enum PaymentState {
        CREATED { Set<PaymentState> next() { return EnumSet.of(VALIDATED, DECLINED, EXPIRED); } },
        VALIDATED { Set<PaymentState> next() { return EnumSet.of(AUTHORIZED, DECLINED, EXPIRED); } },
        AUTHORIZED { Set<PaymentState> next() { return EnumSet.of(CAPTURED, REVERSED, EXPIRED); } },
        CAPTURED { Set<PaymentState> next() { return EnumSet.of(SETTLED, REVERSED); } },
        SETTLED { Set<PaymentState> next() { return EnumSet.of(REFUNDED); } },
        DECLINED { Set<PaymentState> next() { return EnumSet.noneOf(PaymentState.class); } },
        REVERSED { Set<PaymentState> next() { return EnumSet.noneOf(PaymentState.class); } },
        REFUNDED { Set<PaymentState> next() { return EnumSet.noneOf(PaymentState.class); } },
        EXPIRED { Set<PaymentState> next() { return EnumSet.noneOf(PaymentState.class); } };

        abstract Set<PaymentState> next();
        boolean canMoveTo(PaymentState t) { return next().contains(t); }
    }

    static class Payment {
        PaymentState state = PaymentState.CREATED;
        /** Единственная точка смены состояния. */
        String moveTo(PaymentState target) {
            if (state == target) return "уже " + target + ", без изменений";
            if (!state.canMoveTo(target)) return "отклонено: " + state + " -> " + target;
            state = target;
            return "переход в " + target;
        }
    }

    /** Таблица переходов, согласованная с бизнесом, строками "ИЗ->В". */
    static final Set<String> SPEC = Set.of("CREATED->VALIDATED", "CREATED->DECLINED", "CREATED->EXPIRED",
            "VALIDATED->AUTHORIZED", "VALIDATED->DECLINED", "VALIDATED->EXPIRED",
            "AUTHORIZED->CAPTURED", "AUTHORIZED->REVERSED", "AUTHORIZED->EXPIRED",
            "CAPTURED->SETTLED", "CAPTURED->REVERSED", "SETTLED->REFUNDED");

    /** Состояние спора по операции: у каждого состояния свои поля. */
    sealed interface DisputeState permits Opened, EvidenceRequested, UnderReview, Expired {}
    record Opened(Instant at) implements DisputeState {}
    record EvidenceRequested(Instant at, Instant deadline) implements DisputeState {}
    record UnderReview(Instant at) implements DisputeState {}
    record Expired(Instant at) implements DisputeState {}

    static DisputeState submitEvidence(DisputeState s, Instant now) {
        return switch (s) {
            case EvidenceRequested r -> now.isAfter(r.deadline()) ? new Expired(now) : new UnderReview(now);
            case Opened o -> throw new IllegalStateException("документы не запрашивали");
            case UnderReview u -> throw new IllegalStateException("уже на рассмотрении");
            case Expired e -> throw new IllegalStateException("срок истек");
        };
    }

    public static void main(String[] args) {
        var p = new Payment();
        for (var t : List.of(PaymentState.VALIDATED, PaymentState.AUTHORIZED, PaymentState.REVERSED,
                PaymentState.CAPTURED, PaymentState.REVERSED)) {
            System.out.println(p.moveTo(t));
        }

        int checked = 0, mismatches = 0;
        for (var from : PaymentState.values())
            for (var to : PaymentState.values()) {
                checked++;
                if (from.canMoveTo(to) != SPEC.contains(from + "->" + to)) mismatches++;
            }
        System.out.println("проверено пар: " + checked + ", расхождений с таблицей: " + mismatches);

        Instant t0 = Instant.parse("2026-11-01T10:00:00Z");
        var requested = new EvidenceRequested(t0, t0.plus(Duration.ofDays(10)));
        System.out.println("документы на 5-й день: " + submitEvidence(requested, t0.plus(Duration.ofDays(5))));
        System.out.println("документы на 12-й день: " + submitEvidence(requested, t0.plus(Duration.ofDays(12))));
    }
}
