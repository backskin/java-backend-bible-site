package dev.team.patterns.behavioral;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Опыт разд. 2.17: правило антифрода как дерево выражений, которое вычисляется само и умеет себя показать.
 * Вторая часть заглядывает внутрь java.util.regex.Pattern: скомпилированное выражение хранится деревом узлов.
 * Запуск второй части требует --add-opens java.base/java.util.regex=ALL-UNNAMED.
 */
public class InterpreterLab {

    record Ctx(BigDecimal amount, int opsToday, int mcc) {}

    /** Грамматика: числовые выражения и логические правила. */
    sealed interface Num permits Amount, OpsToday, Const {}
    record Amount() implements Num { public String toString() { return "сумма"; } }
    record OpsToday() implements Num { public String toString() { return "операций_за_день"; } }
    record Const(BigDecimal v) implements Num { public String toString() { return v.toPlainString(); } }

    sealed interface Rule permits Gt, MccIn, And, Or, Not {}
    record Gt(Num l, Num r) implements Rule { public String toString() { return l + " > " + r; } }
    record MccIn(Set<Integer> codes) implements Rule { public String toString() { return "MCC in " + codes; } }
    record And(List<Rule> parts) implements Rule { public String toString() { return "(" + String.join(" И ", parts.stream().map(Object::toString).toList()) + ")"; } }
    record Or(List<Rule> parts) implements Rule { public String toString() { return "(" + String.join(" ИЛИ ", parts.stream().map(Object::toString).toList()) + ")"; } }
    record Not(Rule inner) implements Rule { public String toString() { return "НЕ " + inner; } }

    static BigDecimal value(Num n, Ctx c) {
        return switch (n) {
            case Amount a -> c.amount();
            case OpsToday o -> BigDecimal.valueOf(c.opsToday());
            case Const k -> k.v();
        };
    }

    static boolean matches(Rule r, Ctx c) {
        return switch (r) {
            case Gt(var l, var rr) -> value(l, c).compareTo(value(rr, c)) > 0;
            case MccIn(var codes) -> codes.contains(c.mcc());
            case And(var parts) -> parts.stream().allMatch(p -> matches(p, c));
            case Or(var parts) -> parts.stream().anyMatch(p -> matches(p, c));
            case Not(var inner) -> !matches(inner, c);
        };
    }

    public static void main(String[] args) throws Exception {
        // "крупная сумма в рискованной категории или больше 20 операций за день"
        Rule rule = new Or(List.of(
                new And(List.of(new Gt(new Amount(), new Const(new BigDecimal("100000"))), new MccIn(Set.of(6011, 7995)))),
                new Gt(new OpsToday(), new Const(new BigDecimal("20")))));
        System.out.println("правило: " + rule);
        for (var c : List.of(new Ctx(new BigDecimal("150000"), 3, 7995), new Ctx(new BigDecimal("150000"), 3, 5411),
                new Ctx(new BigDecimal("500"), 25, 5411))) {
            System.out.println("  " + c + " -> " + (matches(rule, c) ? "на проверку" : "пропустить"));
        }

        System.out.println("== узлы java.util.regex.Pattern для \"\\d{20}|[A-Z]{2}\\d+\"");
        Pattern p = Pattern.compile("\\d{20}|[A-Z]{2}\\d+");
        Field root = Pattern.class.getDeclaredField("root");
        root.setAccessible(true);
        Object node = root.get(p);
        List<String> names = new ArrayList<>();
        Class<?> nodeClass = Class.forName("java.util.regex.Pattern$Node");
        Field next = nodeClass.getDeclaredField("next");
        next.setAccessible(true);
        for (int i = 0; node != null && i < 10; i++) {
            names.add(node.getClass().getSimpleName());
            node = next.get(node);
        }
        System.out.println("  цепочка root.next: " + names);
        System.out.println("java " + System.getProperty("java.version"));
    }
}
