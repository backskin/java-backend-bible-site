package dev.team.patterns.structural;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.joining;

/** Опыт разд. 2.9: дерево суточных лимитов холдинга и дерево тарифа комиссии. */
public class CompositeLab {
    static int sumCalls;                                                      // сколько раз пересчитывали сумму узла

    // ---- компонент: лимит узла, израсходованное и доступное; клиенту всё равно, счёт перед ним или группа
    abstract static sealed class LimitNode permits Account, Group {
        final String name; final BigDecimal limit; Group parent;             // ссылка на родителя: проверка идёт вверх
        LimitNode(String name, String limit) { this.name = name; this.limit = new BigDecimal(limit); }
        abstract BigDecimal spent();
        BigDecimal headroom() {
            BigDecimal own = limit.subtract(spent());
            return parent == null ? own : own.min(parent.headroom());
        }
    }
    static final class Account extends LimitNode {
        private BigDecimal spent = BigDecimal.ZERO;
        Account(String name, String limit) { super(name, limit); }
        BigDecimal spent() { return spent; }
        String pay(String amount) {
            BigDecimal a = new BigDecimal(amount);
            if (a.compareTo(headroom()) > 0) return "отказ: " + amount + " больше доступного " + headroom() + " (" + bottleneck().name + ")";
            spent = spent.add(a);
            for (Group g = parent; g != null; g = g.parent) g.invalidate();   // сброс кэша у всех предков
            return "проведено " + amount + ", доступно ещё " + headroom();
        }
        LimitNode bottleneck() {
            LimitNode worst = this;
            for (LimitNode n = parent; n != null; n = n.parent)
                if (n.limit.subtract(n.spent()).compareTo(worst.limit.subtract(worst.spent())) < 0) worst = n;
            return worst;
        }
    }
    static final class Group extends LimitNode {
        private final List<LimitNode> children = new ArrayList<>();
        private final boolean cached; private BigDecimal spentCache;
        Group(String name, String limit, boolean cached) { super(name, limit); this.cached = cached; }
        Group add(LimitNode child) {
            for (LimitNode n = this; n != null; n = n.parent)
                if (n == child) throw new IllegalArgumentException("цикл: " + child.name + " уже предок " + name);
            child.parent = this; children.add(child); invalidate();
            return this;
        }
        Group addUnchecked(LimitNode child) { child.parent = this; children.add(child); return this; }
        void invalidate() { spentCache = null; }
        BigDecimal spent() {
            if (cached && spentCache != null) return spentCache;
            sumCalls++;
            BigDecimal s = children.stream().map(LimitNode::spent).reduce(BigDecimal.ZERO, BigDecimal::add);
            if (cached) spentCache = s;
            return s;
        }
    }

    // ---- второе дерево: тариф комиссии, где строка для чека строится тем же деревом, что и сумма
    sealed interface Fee permits Fixed, Percent, Capped, FeeGroup { BigDecimal amount(BigDecimal tx); String describe(); }
    record Fixed(String code, String value) implements Fee {
        public BigDecimal amount(BigDecimal tx) { return new BigDecimal(value); }
        public String describe() { return code + " " + value; }
    }
    record Percent(String code, String rate) implements Fee {
        public BigDecimal amount(BigDecimal tx) { return tx.multiply(new BigDecimal(rate)).movePointLeft(2).setScale(2, RoundingMode.HALF_EVEN); }
        public String describe() { return code + " " + rate + "%"; }
    }
    record Capped(Fee inner, String cap) implements Fee {
        public BigDecimal amount(BigDecimal tx) { return inner.amount(tx).min(new BigDecimal(cap)); }
        public String describe() { return "min(" + inner.describe() + ", " + cap + ")"; }
    }
    record FeeGroup(String code, List<Fee> parts) implements Fee {
        FeeGroup { parts = List.copyOf(parts); }
        public BigDecimal amount(BigDecimal tx) { return parts.stream().map(p -> p.amount(tx)).reduce(BigDecimal.ZERO, BigDecimal::add); }
        public String describe() { return code + "(" + parts.stream().map(Fee::describe).collect(joining(" + ")) + ")"; }
    }

    static Account[] holding(boolean cached, Group[] top) {
        var acc1 = new Account("счёт …0001 ООО «Северный лес»", "4000000");
        var acc2 = new Account("счёт …0002 ООО «Северный лес»", "4000000");
        var acc3 = new Account("счёт …0003 ООО «Северный лён»", "3000000");
        var les = new Group("ООО «Северный лес»", "6000000", cached).add(acc1).add(acc2);
        var len = new Group("ООО «Северный лён»", "5000000", cached).add(acc3);
        top[0] = new Group("холдинг «Северный»", "8000000", cached).add(les).add(len);
        return new Account[]{acc1, acc2, acc3};
    }

    public static void main(String[] args) {
        Group[] top = new Group[1];
        Account[] a = holding(true, top);
        System.out.println("== платежи с разных счетов холдинга");
        System.out.println("…0001: " + a[0].pay("3500000"));
        System.out.println("…0002: " + a[1].pay("3000000"));
        System.out.println("…0002: " + a[1].pay("2500000"));
        System.out.println("…0003: " + a[2].pay("3000000"));
        System.out.println("…0003: " + a[2].pay("2000000"));
        System.out.println("холдинг: израсходовано " + top[0].spent() + " из " + top[0].limit);

        System.out.println("== кэш суммы у групп");
        for (boolean cached : new boolean[]{false, true}) {
            Account[] b = holding(cached, new Group[1]);
            sumCalls = 0;
            for (int i = 0; i < 1000; i++) b[i % 3].headroom();
            System.out.println((cached ? "с кэшем" : "без кэша") + ": 1000 проверок доступного, пересчётов суммы у групп: " + sumCalls);
        }

        System.out.println("== цикл в дереве");
        try { ((Group) a[0].parent).add(top[0]); } catch (IllegalArgumentException e) { System.out.println("с проверкой: " + e.getMessage()); }
        var g1 = new Group("г1", "1", false); var g2 = new Group("г2", "1", false);
        g1.addUnchecked(g2); g2.addUnchecked(g1);
        try { g1.spent(); } catch (StackOverflowError e) { System.out.println("без проверки: StackOverflowError"); }

        System.out.println("== тариф комиссии");
        Fee swift = new FeeGroup("SWIFT", List.of(new Fixed("перевод", "1500.00"),
                new Capped(new Percent("конверсия", "1.5"), "3000.00")));
        for (String tx : List.of("50000.00", "500000.00"))
            System.out.println(tx + " → " + swift.amount(new BigDecimal(tx)) + " = " + swift.describe());
    }
}
