package dev.team.patterns.creational;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.HexFormat;

/** Опыт разд. 2.2: семейства согласованных объектов для двух банков-эквайреров. */
public class AbstractFactoryLab {
    record Purchase(String pan, long kopecks, String rrn) {}

    interface RequestFormat { String format(Purchase p); }
    interface Signer { String sign(String message); }
    interface ResponseParser { boolean approved(String response); }

    /** Абстрактная фабрика: один выбор банка даёт согласованное семейство. */
    interface AcquirerKit {
        RequestFormat requestFormat();
        Signer signer();
        ResponseParser responseParser();
    }

    static String hmac(String key, String msg) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal(msg.getBytes(StandardCharsets.UTF_8))).substring(0, 16);
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    /** Банк А: сообщение фиксированной длины в духе ISO 8583, MAC по ключу терминала. */
    static class BankAKit implements AcquirerKit {
        public RequestFormat requestFormat() { return p -> "0200|" + p.pan() + "|" + String.format("%012d", p.kopecks()) + "|" + p.rrn(); }
        public Signer signer() { return m -> hmac("terminal-key-A", m); }
        public ResponseParser responseParser() { return r -> r.startsWith("0210|00"); }
    }

    /** Банк Б: JSON и подпись по ключу мерчанта. */
    static class BankBKit implements AcquirerKit {
        public RequestFormat requestFormat() { return p -> "{\"pan\":\"" + p.pan() + "\",\"amount\":" + p.kopecks() + ",\"rrn\":\"" + p.rrn() + "\"}"; }
        public Signer signer() { return m -> hmac("merchant-key-B", m); }
        public ResponseParser responseParser() { return r -> r.contains("\"status\":\"APPROVED\""); }
    }

    /** Имитация банка: проверяет подпись своим ключом. */
    static boolean bankAccepts(String bankKey, String message, String signature) { return hmac(bankKey, message).equals(signature); }

    public static void main(String[] args) {
        var p = new Purchase("2200700000000001", 150_000, "629718000017");
        for (var kit : new AcquirerKit[] {new BankAKit(), new BankBKit()}) {
            String msg = kit.requestFormat().format(p);
            String sig = kit.signer().sign(msg);
            String key = kit instanceof BankAKit ? "terminal-key-A" : "merchant-key-B";
            System.out.printf("%-9s запрос %s%n          подпись %s, банк принял подпись: %s%n",
                    kit.getClass().getSimpleName(), msg, sig, bankAccepts(key, msg, sig));
        }
        System.out.println("== детали из разных семейств: формат банка Б, подпись банка А");
        String msg = new BankBKit().requestFormat().format(p);
        String sig = new BankAKit().signer().sign(msg);
        System.out.println("банк Б принял подпись: " + bankAccepts("merchant-key-B", msg, sig));
    }
}
