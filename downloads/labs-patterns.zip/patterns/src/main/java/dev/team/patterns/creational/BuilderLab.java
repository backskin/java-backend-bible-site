package dev.team.patterns.creational;

import java.math.BigDecimal;
import java.util.Objects;

/** Опыт разд. 2.3: платёжное поручение через конструктор, строитель и построитель тестовых данных. */
public class BuilderLab {
    /** Платёжное поручение: девять реквизитов, из них семь строк. */
    record PaymentOrder(String payerInn, String payerAccount, String payeeInn, String payeeKpp,
                        String payeeBik, String payeeAccount, BigDecimal amount, String purpose, int priority) {
        PaymentOrder {
            Objects.requireNonNull(amount, "amount");
            if (!payerInn.matches("\\d{10}|\\d{12}")) throw new IllegalArgumentException("ИНН плательщика: " + payerInn);
            if (!payeeBik.matches("\\d{9}")) throw new IllegalArgumentException("БИК получателя: " + payeeBik);
            if (!payeeAccount.matches("\\d{20}")) throw new IllegalArgumentException("счёт получателя: " + payeeAccount);
            if (amount.signum() <= 0) throw new IllegalArgumentException("сумма должна быть положительной");
            if (priority < 1 || priority > 5) throw new IllegalArgumentException("очерёдность 1–5: " + priority);
        }

        static Builder builder() { return new Builder(); }

        static final class Builder {
            private String payerInn, payerAccount, payeeInn, payeeKpp = "0", payeeBik, payeeAccount, purpose = "";
            private BigDecimal amount;
            private int priority = 5;                                          // очерёдность по умолчанию
            Builder payerInn(String v) { payerInn = v; return this; }
            Builder payerAccount(String v) { payerAccount = v; return this; }
            Builder payeeInn(String v) { payeeInn = v; return this; }
            Builder payeeKpp(String v) { payeeKpp = v; return this; }
            Builder payeeBik(String v) { payeeBik = v; return this; }
            Builder payeeAccount(String v) { payeeAccount = v; return this; }
            Builder amount(String rub) { amount = new BigDecimal(rub); return this; }
            Builder purpose(String text) { purpose = text; return this; }
            Builder priority(int p) { priority = p; return this; }
            PaymentOrder build() {
                return new PaymentOrder(payerInn, payerAccount, payeeInn, payeeKpp, payeeBik, payeeAccount, amount, purpose, priority);
            }
        }
    }

    /** Построитель тестовых данных: безопасные значения по умолчанию, в тесте меняется только важное. */
    static final class PaymentOrderTestBuilder {
        private final PaymentOrder.Builder b = PaymentOrder.builder()
                .payerInn("7707083893").payerAccount("40702810938000000001")
                .payeeInn("7728168971").payeeKpp("770801001")
                .payeeBik("044525225").payeeAccount("40702810400000000002")
                .amount("1000.00").purpose("Оплата по счёту 15");
        static PaymentOrderTestBuilder aPaymentOrder() { return new PaymentOrderTestBuilder(); }
        PaymentOrderTestBuilder withAmount(String rub) { b.amount(rub); return this; }
        PaymentOrderTestBuilder withPriority(int p) { b.priority(p); return this; }
        PaymentOrder build() { return b.build(); }
    }

    public static void main(String[] args) {
        System.out.println("== конструктор: БИК и счёт получателя перепутаны местами");
        try {
            var order = new PaymentOrder("7707083893", "40702810938000000001", "7728168971", "770801001",
                    "40702810400000000002", "044525225", new BigDecimal("1000.00"), "Оплата по счёту 15", 5);
            System.out.println("создано: " + order);
        } catch (IllegalArgumentException e) { System.out.println("компилятор пропустил, упал компактный конструктор: " + e.getMessage()); }

        System.out.println("== КПП и ИНН получателя перепутаны: обе строки проходят проверки");
        var swapped = new PaymentOrder("7707083893", "40702810938000000001", "770801001", "7728168971",
                "044525225", "40702810400000000002", new BigDecimal("1000.00"), "Оплата по счёту 15", 5);
        System.out.println("создано без ошибки: payeeInn=" + swapped.payeeInn() + ", payeeKpp=" + swapped.payeeKpp());

        System.out.println("== строитель: имена методов связывают значение с реквизитом");
        var order = PaymentOrder.builder()
                .payerInn("7707083893").payerAccount("40702810938000000001")
                .payeeInn("7728168971").payeeKpp("770801001")
                .payeeBik("044525225").payeeAccount("40702810400000000002")
                .amount("1000.00").purpose("Оплата по счёту 15").build();
        System.out.println("создано: очерёдность " + order.priority() + ", КПП " + order.payeeKpp());
        try { PaymentOrder.builder().payerInn("7707083893").payeeBik("044525225").payeeAccount("40702810400000000002").amount("0").build(); }
        catch (IllegalArgumentException e) { System.out.println("build() с нулевой суммой: " + e.getMessage()); }

        System.out.println("== построитель тестовых данных и общее состояние");
        var base = PaymentOrderTestBuilder.aPaymentOrder().withPriority(3);
        var big = base.withAmount("900000.00").build();
        var urgent = base.withPriority(1).build();
        System.out.println("big: сумма " + big.amount() + ", очерёдность " + big.priority());
        System.out.println("urgent: сумма " + urgent.amount() + " (ожидали 1000.00), очерёдность " + urgent.priority());
    }
}
