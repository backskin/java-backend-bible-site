package dev.team.patterns.structural;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Опыт разд. 2.13: виртуальный, защитный и кэширующий заместители; динамический заместитель JDK и самовызов. */
public class ProxyLab {
    // ---- виртуальный заместитель: выписка за год грузится только тогда, когда нужны проводки
    interface Statement { String account(); int year(); List<String> entries(); }
    static class LoadedStatement implements Statement {
        static int loads;
        private final String account; private final int year; private final List<String> entries = new ArrayList<>();
        LoadedStatement(String account, int year) {
            loads++;
            this.account = account; this.year = year;
            for (int i = 1; i <= 48_000; i++) entries.add(year + ";проводка " + i);   // в жизни — запрос к архиву на секунды
        }
        public String account() { return account; } public int year() { return year; } public List<String> entries() { return entries; }
    }
    static class LazyStatement implements Statement {
        private final String account; private final int year; private Statement real;
        LazyStatement(String account, int year) { this.account = account; this.year = year; }
        public String account() { return account; }                         // отвечает сам, без загрузки
        public int year() { return year; }
        public List<String> entries() { if (real == null) real = new LoadedStatement(account, year); return real.entries(); }
    }

    // ---- защитный заместитель на динамическом прокси JDK: доступ к полям карточки по роли и журнал
    interface ClientCard {
        String fullName(); String phone(); String passport();
        default String summary() { return fullName() + ", " + phone(); }   // метод по умолчанию зовёт другие методы
    }
    record Card(String fullName, String phone, String passport) implements ClientCard {
        public String summary() { return fullName() + " (" + passport() + ")"; }
    }
    static final Map<String, Set<String>> ROLES = Map.of(
            "operator", Set.of("fullName", "phone", "summary"),
            "compliance", Set.of("fullName", "phone", "passport", "summary"));
    static final List<String> audit = new ArrayList<>();

    static ClientCard guarded(ClientCard target, String user, String role, boolean callDefault) {
        InvocationHandler h = (proxy, method, args) -> {
            if (!ROLES.get(role).contains(method.getName()))
                throw new SecurityException(user + " (" + role + "): нет доступа к " + method.getName());
            audit.add(user + " → " + method.getName());
            if (callDefault && method.isDefault()) return InvocationHandler.invokeDefault(proxy, method, args);
            try { return method.invoke(target, args); }
            catch (InvocationTargetException e) { throw e.getCause(); }        // наружу — исключение цели, а не обёртка
        };
        return (ClientCard) Proxy.newProxyInstance(ClientCard.class.getClassLoader(), new Class<?>[]{ClientCard.class}, h);
    }

    // ---- кэширующий заместитель удалённого справочника курсов
    interface Rates { String rate(String pair); }
    static class RemoteRates implements Rates {
        int calls;
        public String rate(String pair) { calls++; return pair.equals("CNY/RUB") ? "11.42" : "81.15"; }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== виртуальный заместитель");
        List<Statement> archive = new ArrayList<>();
        for (int y = 2016; y <= 2025; y++) archive.add(new LazyStatement("40702810900000000001", y));
        System.out.println("список выписок за 10 лет показан, загрузок: " + LoadedStatement.loads);
        System.out.println("открыта выписка за 2024: " + archive.get(8).entries().size() + " проводок, загрузок: " + LoadedStatement.loads);

        System.out.println("== защитный заместитель");
        ClientCard card = new Card("Петров Пётр Петрович", "+7 900 000-00-03", "1100 123456");
        ClientCard op = guarded(card, "dev.team", "operator", false);
        System.out.println("operator.fullName(): " + op.fullName());
        try { op.passport(); } catch (SecurityException e) { System.out.println("operator.passport(): " + e.getMessage()); }
        System.out.println("operator.summary(): " + op.summary() + "   ← цель вызвала passport() у себя, заместитель этого не видел");
        System.out.println("журнал: " + audit);
        System.out.println("класс заместителя: " + op.getClass().getName() + ", Proxy.isProxyClass: " + Proxy.isProxyClass(op.getClass())
                + ", op instanceof Card: " + (op instanceof Card));

        System.out.println("== метод по умолчанию через InvocationHandler.invokeDefault");
        audit.clear();
        ClientCard viaDefault = guarded(card, "dev.team", "operator", true);
        System.out.println("summary(): " + viaDefault.summary() + "; журнал: " + audit);

        System.out.println("== кэширующий заместитель");
        RemoteRates remote = new RemoteRates();
        Map<String, String> cache = new java.util.concurrent.ConcurrentHashMap<>();
        Rates rates = pair -> cache.computeIfAbsent(pair, remote::rate);
        for (int i = 0; i < 1000; i++) rates.rate(i % 2 == 0 ? "CNY/RUB" : "USD/RUB");
        System.out.println("1000 запросов курса → обращений к удалённому справочнику: " + remote.calls);
    }
}
