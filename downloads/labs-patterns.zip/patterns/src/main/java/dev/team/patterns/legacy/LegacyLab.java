package dev.team.patterns.legacy;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.ZoneId;
import java.util.List;

/**
 * Опыт разд. 9: унаследованный расчёт комиссии без тестов. Шов "извлечь и переопределить" (Физерс, гл. 25)
 * заменяет текущее время и внешний курс в подклассе, после чего характеристический тест (гл. 13)
 * фиксирует фактическое поведение на границах, в том числе странное.
 */
public class LegacyLab {

    /** Унаследованный код: время и курс берутся прямо внутри метода. */
    static class LegacyFeeCalculator {
        BigDecimal fee(BigDecimal amount, String product) {
            long now = currentTimeMillis();
            BigDecimal rate = externalRate();
            int hour = Instant.ofEpochMilli(now).atZone(ZoneId.of("Europe/Moscow")).getHour();
            if (product.equals("SBP")) {
                if (amount.compareTo(new BigDecimal("100000")) < 0) return BigDecimal.ZERO.setScale(2);
                return amount.subtract(new BigDecimal("100000")).multiply(new BigDecimal("0.005")).setScale(2, RoundingMode.HALF_UP);
            }
            if (product.equals("CARD")) {
                BigDecimal base = amount.multiply(rate).setScale(2, RoundingMode.HALF_UP);
                return hour >= 23 ? base.add(new BigDecimal("50")) : base;   // ночная надбавка
            }
            return new BigDecimal("-1");                                    // неизвестный продукт: так было всегда
        }

        // Шов: эти методы извлечены из тела fee() без изменения поведения.
        protected long currentTimeMillis() { return System.currentTimeMillis(); }
        protected BigDecimal externalRate() { throw new IllegalStateException("в тесте нет доступа к сервису курсов"); }
    }

    /** Тестовый подкласс подменяет время и курс. */
    static class TestableCalculator extends LegacyFeeCalculator {
        final long fixedTime;
        TestableCalculator(String isoTime) { fixedTime = Instant.parse(isoTime).toEpochMilli(); }
        @Override protected long currentTimeMillis() { return fixedTime; }
        @Override protected BigDecimal externalRate() { return new BigDecimal("0.015"); }
    }

    public static void main(String[] args) {
        try {
            new LegacyFeeCalculator().fee(new BigDecimal("1000"), "CARD");
        } catch (IllegalStateException e) {
            System.out.println("без шва: " + e.getMessage());
        }
        var day = new TestableCalculator("2026-11-12T09:00:00Z");     // 12:00 по Москве
        var night = new TestableCalculator("2026-11-12T20:30:00Z");   // 23:30 по Москве
        System.out.println("== характеристический тест: фактические значения");
        for (String amount : List.of("99999.99", "100000", "100000.01", "250000")) {
            System.out.println("  SBP " + amount + " -> " + day.fee(new BigDecimal(amount), "SBP"));
        }
        System.out.println("  CARD 1000, 12:00 МСК -> " + day.fee(new BigDecimal("1000"), "CARD"));
        System.out.println("  CARD 1000, 23:30 МСК -> " + night.fee(new BigDecimal("1000"), "CARD"));
        System.out.println("  QR 1000 -> " + day.fee(new BigDecimal("1000"), "QR"));
    }
}
