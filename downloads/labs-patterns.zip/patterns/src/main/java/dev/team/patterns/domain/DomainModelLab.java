package dev.team.patterns.domain;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * Опыт разд. 7: объекты-значения проверяют себя при создании, а богатая модель не даёт создать
 * заказ в несогласованном состоянии, которое анемичная модель принимает без ошибок.
 * Номер IBAN - пример из стандарта ISO 13616, номер карты - общеизвестный тестовый номер Visa.
 */
public class DomainModelLab {

    /** IBAN: формат и контрольная сумма mod 97 (ISO 13616, ISO 7064). */
    record Iban(String value) {
        private static final Pattern FORMAT = Pattern.compile("[A-Z]{2}\\d{2}[A-Z0-9]{11,30}");
        Iban {
            value = value.replaceAll("\\s", "").toUpperCase(Locale.ROOT);
            if (!FORMAT.matcher(value).matches()) throw new IllegalArgumentException("неверный формат IBAN");
            String r = value.substring(4) + value.substring(0, 4);
            StringBuilder d = new StringBuilder();
            for (char c : r.toCharArray()) d.append(Character.isDigit(c) ? String.valueOf(c) : String.valueOf(Character.getNumericValue(c)));
            if (new BigInteger(d.toString()).mod(BigInteger.valueOf(97)).intValue() != 1) throw new IllegalArgumentException("не сошлась контрольная сумма IBAN");
        }
    }

    /** Номер карты: проверка Луна, в журнал попадает только маска. */
    record Pan(String value) {
        Pan {
            value = value.replaceAll("\\s", "");
            if (!value.matches("\\d{13,19}") || !luhn(value)) throw new IllegalArgumentException("неверный номер карты");
        }
        static boolean luhn(String s) {
            int sum = 0;
            for (int i = 0; i < s.length(); i++) {
                int digit = s.charAt(s.length() - 1 - i) - '0';
                if (i % 2 == 1) { digit *= 2; if (digit > 9) digit -= 9; }
                sum += digit;
            }
            return sum % 10 == 0;
        }
        @Override public String toString() { return value.substring(0, 6) + "******" + value.substring(value.length() - 4); }
    }

    record Email(String value) {
        Email {
            value = value.strip().toLowerCase(Locale.ROOT);
            if (!value.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) throw new IllegalArgumentException("неверный адрес");
        }
    }

    // ---------- заказ: анемичный и богатый ----------
    static class AnemicOrder {
        BigDecimal total; List<BigDecimal> lines = new ArrayList<>(); BigDecimal discountPercent;
        void setTotal(BigDecimal t) { total = t; }
        void setLines(List<BigDecimal> l) { lines = l; }
        void setDiscountPercent(BigDecimal d) { discountPercent = d; }
    }

    static final class Order {
        private final List<BigDecimal> lines;
        private final BigDecimal discountPercent;
        Order(List<BigDecimal> lines, BigDecimal discountPercent) {
            if (lines.isEmpty()) throw new IllegalArgumentException("заказ без строк");
            if (discountPercent.compareTo(new BigDecimal("30")) > 0) throw new IllegalArgumentException("скидка больше 30 %");
            this.lines = List.copyOf(lines);
            this.discountPercent = discountPercent;
        }
        /** Итог вычисляется из строк, поэтому не может с ними разойтись. */
        BigDecimal total() {
            BigDecimal gross = lines.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
            return gross.subtract(gross.multiply(discountPercent).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP));
        }
    }

    static String attempt(String name, Supplier<Object> s) {
        try { return name + " -> " + s.get(); }
        catch (IllegalArgumentException e) { return name + " -> отказ: " + e.getMessage(); }
    }

    public static void main(String[] args) {
        System.out.println("== объекты-значения");
        System.out.println(attempt("Iban(\"GB82 WEST 1234 5698 7654 32\")", () -> new Iban("GB82 WEST 1234 5698 7654 32")));
        System.out.println(attempt("Iban(\"GB82 WEST 1234 5698 7654 33\")", () -> new Iban("GB82 WEST 1234 5698 7654 33")));
        System.out.println(attempt("Pan(\"4111 1111 1111 1111\")", () -> new Pan("4111 1111 1111 1111")));
        System.out.println(attempt("Pan(\"4111 1111 1111 1112\")", () -> new Pan("4111 1111 1111 1112")));
        System.out.println(attempt("Email(\" Client@Example.RU \")", () -> new Email(" Client@Example.RU ")));
        System.out.println("равны ли Email(\"a@b.ru\") и Email(\"A@B.RU\"): " + new Email("a@b.ru").equals(new Email("A@B.RU")));

        System.out.println("== заказ");
        var anemic = new AnemicOrder();
        anemic.setTotal(new BigDecimal("1000.00"));
        anemic.setLines(List.of(new BigDecimal("500.00")));
        anemic.setDiscountPercent(new BigDecimal("80"));
        System.out.println("анемичный: total=" + anemic.total + ", сумма строк=" + anemic.lines.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                + ", скидка=" + anemic.discountPercent + " % - объект создан без ошибок");
        System.out.println(attempt("богатый, скидка 80 %", () -> new Order(List.of(new BigDecimal("500.00")), new BigDecimal("80")).total()));
        System.out.println(attempt("богатый, без строк", () -> new Order(List.of(), BigDecimal.ZERO).total()));
        System.out.println(attempt("богатый, строки 500 и 300, скидка 10 %", () -> new Order(List.of(new BigDecimal("500.00"), new BigDecimal("300.00")), new BigDecimal("10")).total()));
    }
}
