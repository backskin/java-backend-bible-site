package dev.team.patterns.creational;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Опыт разд. 2.3: строитель GoF — один распорядитель разбирает реестр, разные строители получают разные результаты. */
public class RegistryBuilderLab {
    record Payment(String account, BigDecimal amount, String purpose) {}

    /** Строитель: шаги построения, которые вызывает распорядитель. Пустые по умолчанию, как советует каталог. */
    interface RegistryBuilder {
        default void startRegistry(String number, String date) { }
        default void addPayment(String account, BigDecimal amount, String purpose) { }
        default void finishRegistry(int declaredCount, BigDecimal declaredTotal) { }
    }

    /** Распорядитель: знает формат файла реестра и ничего не знает о том, что строится. */
    static class RegistryReader {
        void read(List<String> lines, RegistryBuilder builder) {
            for (String line : lines) {
                String[] f = line.split(";");
                switch (f[0]) {
                    case "H" -> builder.startRegistry(f[1], f[2]);
                    case "P" -> builder.addPayment(f[1], new BigDecimal(f[2]), f[3]);
                    case "T" -> builder.finishRegistry(Integer.parseInt(f[1]), new BigDecimal(f[2]));
                    default -> throw new IllegalArgumentException("неизвестная строка: " + line);
                }
            }
        }
    }

    /** Строит доменные объекты для проведения. */
    static class PaymentsBuilder implements RegistryBuilder {
        private final List<Payment> payments = new ArrayList<>();
        @Override public void addPayment(String account, BigDecimal amount, String purpose) {
            payments.add(new Payment(account, amount, purpose));
        }
        List<Payment> result() { return List.copyOf(payments); }
    }

    /** Ничего не строит: только сверяет итоговую строку с содержимым, как счётчик из каталога. */
    static class ControlSumBuilder implements RegistryBuilder {
        private int count; private BigDecimal total = BigDecimal.ZERO; private String verdict;
        @Override public void addPayment(String account, BigDecimal amount, String purpose) { count++; total = total.add(amount); }
        @Override public void finishRegistry(int declaredCount, BigDecimal declaredTotal) {
            verdict = (count == declaredCount && total.compareTo(declaredTotal) == 0)
                    ? "сходится: " + count + " платежей на " + total
                    : "НЕ сходится: в файле " + count + " на " + total + ", в итоге " + declaredCount + " на " + declaredTotal;
        }
        String result() { return verdict; }
    }

    /** Строит текст квитанции для отправителя реестра. */
    static class ReceiptBuilder implements RegistryBuilder {
        private final StringBuilder text = new StringBuilder();
        @Override public void startRegistry(String number, String date) { text.append("Реестр № ").append(number).append(" от ").append(date).append(" принят"); }
        @Override public void finishRegistry(int declaredCount, BigDecimal declaredTotal) { text.append(", платежей: ").append(declaredCount); }
        String result() { return text.toString(); }
    }

    public static void main(String[] args) {
        var good = List.of("H;117;2026-10-26",
                "P;40817810000000000001;1200.00;Зарплата за октябрь",
                "P;40817810000000000002;980.50;Зарплата за октябрь",
                "T;2;2180.50");
        var broken = List.of("H;118;2026-10-26",
                "P;40817810000000000001;1200.00;Зарплата за октябрь",
                "T;2;2180.50");
        var reader = new RegistryReader();

        System.out.println("== реестр 117, три строителя, один распорядитель");
        var check = new ControlSumBuilder(); reader.read(good, check);
        System.out.println("контроль: " + check.result());
        var payments = new PaymentsBuilder(); reader.read(good, payments);
        System.out.println("платежи: " + payments.result().size() + ", первый " + payments.result().get(0));
        var receipt = new ReceiptBuilder(); reader.read(good, receipt);
        System.out.println("квитанция: " + receipt.result());

        System.out.println("== реестр 118 с пропавшей строкой");
        var check2 = new ControlSumBuilder(); reader.read(broken, check2);
        System.out.println("контроль: " + check2.result());
    }
}
