package dev.team.patterns.creational;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Опыт разд. 2.4: шаблон платежа, копирование через clone и через конструктор копирования. */
public class PrototypeLab {
    static int constructorCalls;

    /** Шаблон платежа в интернет-банке: «ЖКХ, квартира», «Детский сад». */
    static class PaymentTemplate implements Cloneable {
        String name;
        String payeeAccount;
        BigDecimal amount;
        List<String> notifyPhones = new ArrayList<>();      // кому прислать СМС о платеже

        PaymentTemplate(String name, String payeeAccount, BigDecimal amount) {
            constructorCalls++;
            if (!payeeAccount.matches("\\d{20}")) throw new IllegalArgumentException("счёт: " + payeeAccount);
            this.name = name; this.payeeAccount = payeeAccount; this.amount = amount;
        }

        /** Конструктор копирования: новый список, проверки конструктора выполняются. */
        PaymentTemplate(PaymentTemplate src) {
            this(src.name, src.payeeAccount, src.amount);
            this.notifyPhones = new ArrayList<>(src.notifyPhones);
        }

        @Override public PaymentTemplate clone() {
            try { return (PaymentTemplate) super.clone(); }
            catch (CloneNotSupportedException e) { throw new AssertionError(e); }
        }
    }

    /** Неизменяемый вариант: record и метод with* вместо копирования изменяемого объекта. */
    record Template(String name, String payeeAccount, BigDecimal amount, List<String> notifyPhones) {
        Template { notifyPhones = List.copyOf(notifyPhones); }
        Template withAmount(BigDecimal a) { return new Template(name, payeeAccount, a, notifyPhones); }
    }

    public static void main(String[] args) {
        var flat = new PaymentTemplate("ЖКХ, квартира", "40702810400000000002", new BigDecimal("6420.15"));
        flat.notifyPhones.add("+7 900 000-00-01");
        constructorCalls = 0;

        System.out.println("== clone()");
        var garage = flat.clone();
        garage.name = "ЖКХ, гараж";
        garage.amount = new BigDecimal("830.00");
        garage.notifyPhones.add("+7 900 000-00-02");
        System.out.println("конструктор при clone() вызван раз: " + constructorCalls);
        System.out.println("у исходного шаблона телефоны: " + flat.notifyPhones + ", сумма " + flat.amount);
        System.out.println("один и тот же список: " + (flat.notifyPhones == garage.notifyPhones));

        System.out.println("== clone() обходит проверки конструктора");
        flat.payeeAccount = "ошибка";                       // испорченный объект
        var copyOfBroken = flat.clone();
        System.out.println("копия испорченного шаблона создана, счёт: " + copyOfBroken.payeeAccount);
        try { new PaymentTemplate(flat); }
        catch (IllegalArgumentException e) { System.out.println("конструктор копирования отказал: " + e.getMessage()); }
        flat.payeeAccount = "40702810400000000002";

        System.out.println("== конструктор копирования");
        var school = new PaymentTemplate(flat);
        school.notifyPhones.add("+7 900 000-00-03");
        System.out.println("у исходного шаблона телефоны: " + flat.notifyPhones);

        System.out.println("== record и with*");
        var t = new Template("Детский сад", "40702810400000000002", new BigDecimal("4500.00"), List.of("+7 900 000-00-01"));
        var march = t.withAmount(new BigDecimal("3900.00"));
        System.out.println(t.amount() + " -> " + march.amount() + ", список общий и неизменяемый: " + (t.notifyPhones() == march.notifyPhones()));
        try { march.notifyPhones().add("+7 900 000-00-04"); }
        catch (UnsupportedOperationException e) { System.out.println("изменить список копии нельзя: " + e.getClass().getSimpleName()); }
    }
}
