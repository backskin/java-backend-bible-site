package dev.team.patterns.modern;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

/**
 * Опыт разд. 1.2: тестовая задача "аномальные транзакции" решена одним классом, без декоратора и синглтона.
 * Входных данных проверяющей платформы нет, поэтому три набора ниже составлены под условие:
 * интервал 20 минут с включительным концом, AP - платеж от 10 000, AS - три одинаковые суммы подряд,
 * некорректные строки (время вне 00:00-23:30, сумма вне 50-50 000, мусор) отбрасываются до разбиения.
 */
public class AnomalyTaskLab {

    static class TransactionAnalyser {
        private static final Pattern TX = Pattern.compile("([01]\\d|2[0-3]):([0-5]\\d);(\\d{1,5})");

        public List<String> processInputLines(List<String> lines) {
            List<int[]> txs = lines.stream()
                    .map(line -> TX.matcher(line.trim()))
                    .filter(Matcher::matches)
                    .map(m -> new int[]{Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2)),
                            Integer.parseInt(m.group(3))})
                    .filter(t -> t[0] <= 23 * 60 + 30 && t[1] >= 50 && t[1] <= 50_000)
                    .toList();

            List<String> result = new ArrayList<>();
            for (int i = 0, j; i < txs.size(); i = j) {
                int start = txs.get(i)[0], end = start + 20;
                j = i;
                while (j < txs.size() && txs.get(j)[0] <= end) {
                    j++;
                }
                List<int[]> window = txs.subList(i, j);
                boolean ap = window.stream().anyMatch(t -> t[1] >= 10_000);
                boolean as = IntStream.range(2, window.size())
                        .anyMatch(k -> window.get(k)[1] == window.get(k - 1)[1] && window.get(k)[1] == window.get(k - 2)[1]);
                String flags = ((ap ? "AP " : "") + (as ? "AS" : "")).trim();
                result.add("%02d:%02d - %02d:%02d - %s".formatted(start / 60, start % 60, end / 60, end % 60,
                        flags.isEmpty() ? "none" : flags));
            }
            return result;
        }
    }

    public static void main(String[] args) {
        var analyser = new TransactionAnalyser();
        List<List<String>> inputs = List.of(
                List.of("10:01;500", "10:15;700", "10:50;15000"),
                List.of("09:30;300", "09:35;300", "09:40;300", "10:00;12000", "10:05;400", "10:10;400", "10:20;400"),
                List.of("17:00;100", "17:05;100", "17:10;100", "17:25;100",
                        "25:00;100", "17:30;20", "23:45;100", "мусор"));
        for (var in : inputs) {
            System.out.println("вход:  " + in);
            analyser.processInputLines(in).forEach(r -> System.out.println("выход: " + r));
        }
    }
}
