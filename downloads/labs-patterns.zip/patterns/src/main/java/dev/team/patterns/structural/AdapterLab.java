package dev.team.patterns.structural;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/** Опыт разд. 2.7: адаптер объекта и адаптер класса к АБС, встраиваемый адаптер и адаптеры JDK. */
public class AdapterLab {
    // ---- целевой интерфейс платёжного шлюза: суммы в рублях, исходы в терминах шлюза
    enum Outcome { APPROVED, DECLINED_FUNDS, DECLINED_LIMIT, UNAVAILABLE }
    record Payment(String account, BigDecimal amount, String purpose) { }
    record Result(Outcome outcome, String reference) { }
    interface CoreBanking { Result debit(Payment p); }

    // ---- адаптируемый класс: клиент АБС «Полюс», чужой и неизменяемый
    static class PolusException extends Exception { PolusException(String m) { super(m); } }
    static class PolusClient {
        private int docNo = 70_400;
        /** Сумма в копейках, назначение не длиннее 140 знаков, ответ — код из двух цифр и номер документа. */
        String[] post(String acc, long kopecks, String text) throws PolusException {
            if (text.length() > 140) return new String[]{"30", ""};
            if (acc.endsWith("9999")) throw new PolusException("ABS-TIMEOUT 30s");
            if (kopecks > 50_000_000) return new String[]{"61", ""};
            if (acc.endsWith("0051")) return new String[]{"51", ""};
            return new String[]{"00", "DOC-" + (++docNo)};
        }
        protected String codePage() { return "CP1251"; }
    }

    // ---- адаптер объекта: композиция, работает с PolusClient и всеми его подклассами
    static class PolusAdapter implements CoreBanking {
        static final Map<String, Outcome> CODES = Map.of("00", Outcome.APPROVED, "51", Outcome.DECLINED_FUNDS, "61", Outcome.DECLINED_LIMIT);
        private final PolusClient polus;
        PolusAdapter(PolusClient polus) { this.polus = polus; }

        @Override public Result debit(Payment p) {
            long kopecks = p.amount().movePointRight(2).longValueExact();   // ArithmeticException на дробных копейках
            try {
                String[] r = polus.post(p.account(), kopecks, p.purpose());
                Outcome o = CODES.get(r[0]);
                if (o == null) throw new IllegalStateException("АБС вернула неизвестный код " + r[0]);
                return new Result(o, r[1]);
            } catch (PolusException e) {
                return new Result(Outcome.UNAVAILABLE, "");
            }
        }
    }

    // ---- адаптер класса: наследует адаптируемый и может переопределить его поведение
    static class PolusClassAdapter extends PolusClient implements CoreBanking {
        @Override protected String codePage() { return "UTF-8"; }          // доступ к защищённому — плюс наследования
        @Override public Result debit(Payment p) {
            try {
                String[] r = post(p.account(), p.amount().movePointRight(2).longValueExact(), p.purpose());
                return new Result(PolusAdapter.CODES.getOrDefault(r[0], Outcome.UNAVAILABLE), r[1]);
            } catch (PolusException e) { return new Result(Outcome.UNAVAILABLE, ""); }
        }
    }

    /** Новая версия клиента АБС: адаптер объекта примет её без правки, адаптер класса — нет. */
    static class PolusClientV2 extends PolusClient {
        @Override String[] post(String acc, long kopecks, String text) throws PolusException {
            String[] r = super.post(acc, kopecks, text);
            return new String[]{r[0], r[1].replace("DOC-", "D2-")};
        }
    }

    // ---- встраиваемый адаптер: узкий интерфейс, адаптация передаётся функциями
    record Column<T>(String title, Function<T, String> value) { }
    static <T> String csv(List<T> rows, List<Column<T>> cols) {
        StringBuilder sb = new StringBuilder(String.join(";", cols.stream().map(Column::title).toList())).append('\n');
        for (T r : rows) sb.append(String.join(";", cols.stream().map(c -> c.value().apply(r)).toList())).append('\n');
        return sb.toString();
    }
    record CardTxn(String pan, long minor, String mcc) { }

    public static void main(String[] args) throws Exception {
        var cases = List.of(
                new Payment("40702810900000000001", new BigDecimal("15000.00"), "Оплата по счёту 17"),
                new Payment("40702810900000000051", new BigDecimal("15000.00"), "Оплата по счёту 18"),
                new Payment("40702810900000000001", new BigDecimal("600000.00"), "Оплата оборудования"),
                new Payment("40702810900000009999", new BigDecimal("100.00"), "Комиссия"),
                new Payment("40702810900000000001", new BigDecimal("100.00"), "x".repeat(141)));
        CoreBanking object = new PolusAdapter(new PolusClient());
        System.out.println("== адаптер объекта");
        for (Payment p : cases) {
            try { System.out.println(p.amount() + " со счёта …" + p.account().substring(16) + " → " + object.debit(p)); }
            catch (RuntimeException e) { System.out.println(p.amount() + " со счёта …" + p.account().substring(16) + " → " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
        }
        try { object.debit(new Payment("40702810900000000001", new BigDecimal("10.005"), "дробные копейки")); }
        catch (ArithmeticException e) { System.out.println("10.005 → ArithmeticException: " + e.getMessage()); }

        System.out.println("== адаптер объекта и новая версия клиента");
        System.out.println(new PolusAdapter(new PolusClientV2()).debit(cases.get(0)));
        System.out.println("== адаптер класса");
        PolusClassAdapter cls = new PolusClassAdapter();
        System.out.println(cls.debit(cases.get(0)) + ", кодировка " + cls.codePage() + "; с PolusClientV2 работать не может: он наследует PolusClient");

        System.out.println("== встраиваемый адаптер: одна выгрузка для чужих типов");
        System.out.print(csv(List.of(new CardTxn("2200123456789010", 125_050, "5411")),
                List.of(new Column<>("карта", t -> "****" + t.pan().substring(12)),
                        new Column<>("сумма", t -> BigDecimal.valueOf(t.minor(), 2).toPlainString()),
                        new Column<>("MCC", CardTxn::mcc))));
        System.out.print(csv(cases.subList(0, 2),
                List.of(new Column<>("счёт", Payment::account), new Column<>("сумма", p -> p.amount().toPlainString()))));

        System.out.println("== адаптеры JDK");
        String[] limits = {"100000", "500000"};
        List<String> view = Arrays.asList(limits);
        view.set(0, "250000");
        System.out.println("Arrays.asList: set изменил массив → limits[0] = " + limits[0]);
        try { view.add("900000"); } catch (UnsupportedOperationException e) { System.out.println("Arrays.asList: add → UnsupportedOperationException"); }
        byte[] cp1251 = "Северный лес".getBytes(Charset.forName("windows-1251"));
        try (Reader r = new InputStreamReader(new ByteArrayInputStream(cp1251), Charset.forName("windows-1251"))) {
            char[] buf = new char[32]; int n = r.read(buf);
            System.out.println("InputStreamReader: " + cp1251.length + " байт → " + n + " символов «" + new String(buf, 0, n) + "»");
        }
    }
}
