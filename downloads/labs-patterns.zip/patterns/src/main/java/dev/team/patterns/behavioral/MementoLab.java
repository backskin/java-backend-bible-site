package dev.team.patterns.behavioral;

import java.math.BigDecimal;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Опыт разд. 2.20: черновик кредитной заявки и откат на шаг назад. Снимок непрозрачен для истории
 * (интерфейс без методов), копирует коллекцию; вариант со ссылкой на ту же коллекцию "откатывается"
 * в уже измененное состояние. История ограничена глубиной.
 */
public class MementoLab {

    static final class LoanDraft {
        private BigDecimal amount;
        private int termMonths;
        private Set<String> documents = new LinkedHashSet<>();

        /** Снимок, в который снаружи заглянуть нельзя. */
        public interface Snapshot {}
        private record State(BigDecimal amount, int term, Set<String> docs) implements Snapshot {}

        Snapshot snapshot() { return new State(amount, termMonths, Set.copyOf(documents)); }
        /** Ошибка: снимок хранит ссылку на изменяемое множество черновика. */
        Snapshot shallowSnapshot() { return new State(amount, termMonths, documents); }

        void restore(Snapshot s) {
            if (!(s instanceof State st)) throw new IllegalArgumentException("чужой снимок");
            amount = st.amount(); termMonths = st.term(); documents = new LinkedHashSet<>(st.docs());
        }
        public String toString() { return amount + " руб. на " + termMonths + " мес., документы " + documents; }
    }

    /** Опекун: хранит снимки и не видит, что в них. */
    static final class History {
        static final int MAX_DEPTH = 20;
        private final Deque<LoanDraft.Snapshot> stack = new ArrayDeque<>();
        void push(LoanDraft.Snapshot s) { stack.push(s); while (stack.size() > MAX_DEPTH) stack.removeLast(); }
        LoanDraft.Snapshot pop() { return stack.pop(); }
        int size() { return stack.size(); }
    }

    public static void main(String[] args) {
        var draft = new LoanDraft();
        draft.amount = new BigDecimal("1200000"); draft.termMonths = 36; draft.documents.add("паспорт");
        var history = new History();

        history.push(draft.snapshot());
        draft.amount = new BigDecimal("1500000"); draft.documents.add("справка о доходах");
        System.out.println("после шага 2: " + draft);
        draft.restore(history.pop());
        System.out.println("откат (копия множества): " + draft);

        history.push(draft.shallowSnapshot());
        draft.documents.add("справка о доходах");
        draft.restore(history.pop());
        System.out.println("откат (ссылка на то же множество): " + draft);

        for (int i = 0; i < 50; i++) history.push(draft.snapshot());
        System.out.println("в истории после 50 шагов: " + history.size() + " снимков");
    }
}
