package dev.team.patterns.structural;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/** Опыт разд. 2.8: мост между видами уведомлений и каналами доставки. */
public class BridgeLab {
    record Client(String name, String phone, String pushToken, String email) { }
    record Message(String subject, String body, Duration ttl) { }

    // ---- реализация: примитивные операции канала, о видах уведомлений ничего не знает
    interface Channel {
        String name();
        boolean reaches(Client c);
        int maxLength();
        String deliver(Client c, Message m);
    }
    static class Sms implements Channel {
        public String name() { return "SMS"; }
        public boolean reaches(Client c) { return c.phone() != null; }
        public int maxLength() { return 70; }                               // один сегмент кириллицы в UCS-2
        public String deliver(Client c, Message m) { return "SMS " + c.phone() + ": " + m.body(); }
    }
    static class Push implements Channel {
        public String name() { return "push"; }
        public boolean reaches(Client c) { return c.pushToken() != null; }
        public int maxLength() { return 178; }
        public String deliver(Client c, Message m) { return "push " + c.pushToken() + ": [" + m.subject() + "] " + m.body() + " (живёт " + m.ttl().toMinutes() + " мин)"; }
    }
    static class Email implements Channel {
        public String name() { return "e-mail"; }
        public boolean reaches(Client c) { return c.email() != null; }
        public int maxLength() { return 10_000; }
        public String deliver(Client c, Message m) { return "e-mail " + c.email() + ": «" + m.subject() + "» " + m.body(); }
    }

    // ---- абстракция: что сказать клиенту и по каким правилам; канал получает готовое сообщение
    abstract static class Notification {
        private final List<Channel> channels;                                // порядок предпочтения, выбирается во время работы
        Notification(List<Channel> channels) { this.channels = channels; }
        abstract Message compose();

        final String sendTo(Client c) {
            Message m = compose();
            for (Channel ch : channels) {
                if (!ch.reaches(c)) continue;
                String body = m.body().length() <= ch.maxLength() ? m.body()
                        : m.body().substring(0, ch.maxLength() - 1) + "…";   // общее правило для всех видов
                return ch.deliver(c, new Message(m.subject(), body, m.ttl()));
            }
            return "не доставлено: ни один канал не дотягивается до " + c.name();
        }
    }
    static class Otp extends Notification {
        private final String code;
        Otp(List<Channel> ch, String code) { super(ch); this.code = code; }
        Message compose() { return new Message("Код", "Код " + code + " для подтверждения платежа. Никому его не сообщайте.", Duration.ofMinutes(5)); }
    }
    static class LimitAlmostSpent extends Notification {
        private final BigDecimal spent, limit;
        LimitAlmostSpent(List<Channel> ch, BigDecimal spent, BigDecimal limit) { super(ch); this.spent = spent; this.limit = limit; }
        Message compose() {
            return new Message("Лимит", "Израсходовано " + spent + " из " + limit + " ₽ суточного лимита по карте. Повысить лимит можно в приложении Тундра-Банка в разделе «Карты».",
                    Duration.ofHours(12));
        }
    }
    static class CardBlocked extends Notification {
        private final String last4;
        CardBlocked(List<Channel> ch, String last4) { super(ch); this.last4 = last4; }
        Message compose() { return new Message("Карта заблокирована", "Карта *" + last4 + " заблокирована антифродом. Позвоните 8 800 000-00-00.", Duration.ofDays(1)); }
    }

    public static void main(String[] args) {
        Channel sms = new Sms(), push = new Push(), email = new Email();
        var anna = new Client("Анна", "+7 900 000-00-01", "fcm:aa17", "anna@example.ru");
        var oleg = new Client("Олег", "+7 900 000-00-02", null, null);           // приложения нет
        var firm = new Client("ООО «Северный лес»", null, null, "buh@example.ru");

        List<Notification> all = new ArrayList<>(List.of(
                new Otp(List.of(push, sms), "4417"),                          // одноразовый код — быстрые каналы
                new LimitAlmostSpent(List.of(push, sms, email), new BigDecimal("80000"), new BigDecimal("100000")),
                new CardBlocked(List.of(sms, push, email), "9010")));
        for (Notification n : all)
            for (Client c : List.of(anna, oleg, firm))
                System.out.println(n.getClass().getSimpleName() + " → " + n.sendTo(c));

        System.out.println("== число классов");
        for (int kinds = 3, channels = 3; channels <= 5; channels++)
            System.out.println(kinds + " вида × " + channels + (channels < 5 ? " канала" : " каналов") + ": наследованием " + kinds * channels + ", мостом " + (kinds + channels));
    }
}
