package dev.team.patterns.modern;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Опыт разд. 1.3: что из каталога GoF в Java 21 делает сам язык и что при этом теряется.
 * Strategy - лямбдой, Command - через {@link Runnable}, Template Method - через функцию в конструкторе,
 * Visitor - через {@code sealed} и {@code switch} с шаблонами записей.
 */
public class LanguageReplacesPatternLab {

    enum Product { DEBIT_CARD, CREDIT_CARD, SBP }

    // ---------- Strategy: интерфейс и класс на каждый вариант против таблицы функций ----------

    /** Классическая форма: абстрактная стратегия и конкретная стратегия отдельным классом. */
    interface FeeCalculator { BigDecimal fee(BigDecimal amount); }

    static class CreditCardFee implements FeeCalculator {
        @Override public BigDecimal fee(BigDecimal amount) {          // 3,9 % от суммы, не меньше 390 руб.
            return amount.multiply(new BigDecimal("0.039")).max(new BigDecimal("390")).setScale(2, RoundingMode.HALF_UP);
        }
    }

    /** Та же стратегия без классов-реализаций: функциональный интерфейс и лямбды в таблице. */
    static final Map<Product, Function<BigDecimal, BigDecimal>> FEES = new EnumMap<>(Map.of(
            Product.DEBIT_CARD, a -> BigDecimal.ZERO.setScale(2),
            Product.CREDIT_CARD, a -> a.multiply(new BigDecimal("0.039")).max(new BigDecimal("390")).setScale(2, RoundingMode.HALF_UP),
            Product.SBP, a -> a.compareTo(new BigDecimal("100000")) > 0
                    ? a.subtract(new BigDecimal("100000")).multiply(new BigDecimal("0.005")).setScale(2, RoundingMode.HALF_UP)
                    : BigDecimal.ZERO.setScale(2)));

    // ---------- Command: Runnable против объекта-команды с данными и отменой ----------

    /** Команда GoF: запрос как объект, который знает, что он делает, и умеет себя отменить. */
    interface Command { void execute(); void undo(); }

    record Hold(Map<String, BigDecimal> balances, String account, BigDecimal amount) implements Command {
        @Override public void execute() { balances.merge(account, amount.negate(), BigDecimal::add); }
        @Override public void undo() { balances.merge(account, amount, BigDecimal::add); }
    }

    // ---------- Template Method: подкласс против функции ----------

    /** Шаблонный метод: подкласс переопределяет шаг removeEldestEntry, который вызывает put. */
    static class RecentPaymentsBySubclass extends LinkedHashMap<String, BigDecimal> {
        private final int limit;
        RecentPaymentsBySubclass(int limit) { this.limit = limit; }
        @Override protected boolean removeEldestEntry(Map.Entry<String, BigDecimal> eldest) { return size() > limit; }
    }

    /** То же поведение без наследования: шаг передан функцией в конструктор (Блох, разд. 7.3). */
    static class RecentPayments {
        private final LinkedHashMap<String, BigDecimal> map = new LinkedHashMap<>();
        private final Predicate<Map<String, BigDecimal>> evict;
        RecentPayments(Predicate<Map<String, BigDecimal>> evict) { this.evict = evict; }
        void put(String id, BigDecimal amount) {
            map.put(id, amount);
            if (evict.test(map)) map.remove(map.keySet().iterator().next());
        }
        @Override public String toString() { return map.keySet().toString(); }
    }

    // ---------- Visitor: sealed-иерархия и switch с шаблонами записей ----------

    sealed interface PaymentEvent permits Authorized, Captured, Refunded {}
    record Authorized(String id, BigDecimal amount) implements PaymentEvent {}
    record Captured(String id, BigDecimal amount) implements PaymentEvent {}
    record Refunded(String id, BigDecimal amount, String reason) implements PaymentEvent {}

    /** Новая операция над иерархией - новый метод со switch, классы событий не меняются. */
    static String toLedgerLine(PaymentEvent e) {
        return switch (e) {
            case Authorized(var id, var amount) -> "HOLD     " + id + " " + amount;
            case Captured(var id, var amount) -> "DEBIT    " + id + " " + amount;
            case Refunded(var id, var amount, var reason) -> "CREDIT   " + id + " " + amount + " (" + reason + ")";
        };
    }

    public static void main(String[] args) {
        var amount = new BigDecimal("25000.00");

        System.out.println("== Strategy");
        System.out.println("класс CreditCardFee:         " + new CreditCardFee().fee(amount));
        System.out.println("лямбда из таблицы:           " + FEES.get(Product.CREDIT_CARD).apply(amount));
        for (var p : Product.values()) System.out.println("  " + p + " -> " + FEES.get(p).apply(new BigDecimal("150000.00")));

        System.out.println("== Command");
        Map<String, BigDecimal> balances = new LinkedHashMap<>(Map.of("40817810000000000001", new BigDecimal("50000.00")));
        Queue<Runnable> lambdas = new ArrayDeque<>();
        lambdas.add(() -> balances.merge("40817810000000000001", new BigDecimal("-1200.00"), BigDecimal::add));
        System.out.println("лямбда в очереди выглядит так: " + lambdas.peek());
        lambdas.poll().run();
        System.out.println("баланс после лямбды: " + balances);
        List<Command> journal = new ArrayList<>();
        Command hold = new Hold(balances, "40817810000000000001", new BigDecimal("3000.00"));
        hold.execute();
        journal.add(hold);
        System.out.println("команда в журнале выглядит так: " + journal.get(0));
        journal.get(0).undo();
        System.out.println("баланс после отмены команды: " + balances);

        System.out.println("== Template Method");
        var bySubclass = new RecentPaymentsBySubclass(3);
        var byFunction = new RecentPayments(m -> m.size() > 3);
        for (int i = 1; i <= 5; i++) {
            bySubclass.put("p" + i, BigDecimal.TEN);
            byFunction.put("p" + i, BigDecimal.TEN);
        }
        System.out.println("подкласс LinkedHashMap: " + bySubclass.keySet());
        System.out.println("функция в конструкторе: " + byFunction);

        System.out.println("== Visitor");
        List<PaymentEvent> events = List.of(
                new Authorized("op-1", new BigDecimal("990.00")),
                new Captured("op-1", new BigDecimal("990.00")),
                new Refunded("op-1", new BigDecimal("990.00"), "товар не доставлен"));
        events.forEach(e -> System.out.println(toLedgerLine(e)));
        System.out.println("java " + System.getProperty("java.version") + ", " + System.getProperty("java.vendor"));
    }
}
