package dev.team.patterns.behavioral;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Опыт разд. 2.19: посредник сделки с аккредитивом. Счет покрытия, документооборот и уведомления
 * ничего не знают друг о друге; порядок их вызовов (протокол сделки) записан в одном классе.
 */
public class MediatorLab {

    static final List<String> log = new ArrayList<>();

    /** Коллеги: каждый знает только свою работу. */
    static class Escrow {
        void hold(String deal, BigDecimal a) { log.add("счет покрытия: заблокировано " + a + " по " + deal); }
        void release(String deal) { log.add("счет покрытия: выплата продавцу по " + deal); }
        void refund(String deal) { log.add("счет покрытия: возврат покупателю по " + deal); }
    }
    static class Documents {
        void request(String deal) { log.add("документы: запрошен акт приемки по " + deal); }
        void archive(String deal) { log.add("документы: акт в архиве по " + deal); }
    }
    static class Notifications {
        void send(String who, String text) { log.add("уведомление " + who + ": " + text); }
    }

    sealed interface DealEvent permits Funded, AcceptanceSigned, Cancelled {}
    record Funded(BigDecimal amount) implements DealEvent {}
    record AcceptanceSigned() implements DealEvent {}
    record Cancelled(String reason) implements DealEvent {}

    /** Посредник: протокол сделки целиком. */
    static class DealMediator {
        final Escrow escrow = new Escrow();
        final Documents documents = new Documents();
        final Notifications notifications = new Notifications();
        boolean funded;

        void on(String deal, DealEvent e) {
            switch (e) {
                case Funded f -> {
                    escrow.hold(deal, f.amount());
                    documents.request(deal);
                    notifications.send("продавцу", "покупатель внес " + f.amount());
                    funded = true;
                }
                case AcceptanceSigned a -> {
                    if (!funded) throw new IllegalStateException("акт приемки до внесения денег по " + deal);
                    escrow.release(deal);
                    documents.archive(deal);
                    notifications.send("сторонам", "сделка закрыта");
                }
                case Cancelled c -> {
                    escrow.refund(deal);
                    notifications.send("сторонам", "сделка отменена: " + c.reason());
                }
            }
        }
    }

    public static void main(String[] args) {
        var m = new DealMediator();
        try {
            m.on("сделка-1", new AcceptanceSigned());
        } catch (IllegalStateException e) {
            System.out.println("отказ: " + e.getMessage());
        }
        m.on("сделка-1", new Funded(new BigDecimal("4500000.00")));
        m.on("сделка-1", new AcceptanceSigned());
        log.forEach(System.out::println);
    }
}
