package dev.team.patterns.behavioral;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Опыт разд. 2.15: цепочка проверок платежа. Первое нарушение обрывает цепочку, и следующие звенья
 * (в том числе запрос остатка) не вызываются; вариант для формы собирает все нарушения сразу.
 */
public class ChainLab {

    record Payment(String key, String payeeInn, BigDecimal amount, BigDecimal spentToday) {}

    /** Звено цепочки: пустой Optional значит "проверка пройдена, передать дальше". */
    interface PaymentCheck { Optional<String> check(Payment p); }

    static final List<String> calls = new ArrayList<>();

    static PaymentCheck named(String name, PaymentCheck c) {
        return p -> { calls.add(name); return c.check(p); };
    }

    static final Set<String> SEEN_KEYS = Set.of("k-1");
    static final Set<String> SANCTIONED_INN = Set.of("7700000001");

    static final List<PaymentCheck> CHECKS = List.of(
            named("дубликат", p -> SEEN_KEYS.contains(p.key()) ? Optional.of("повтор ключа " + p.key()) : Optional.empty()),
            named("санкции", p -> SANCTIONED_INN.contains(p.payeeInn()) ? Optional.of("получатель в санкционном перечне") : Optional.empty()),
            named("суточный лимит", p -> p.spentToday().add(p.amount()).compareTo(new BigDecimal("1000000")) > 0
                    ? Optional.of("превышен суточный лимит") : Optional.empty()),
            named("остаток (запрос в АБС)", p -> p.amount().compareTo(new BigDecimal("300000")) > 0
                    ? Optional.of("недостаточно средств") : Optional.empty()));

    /** Цепочка с коротким замыканием: возвращает первое нарушение. */
    static Optional<String> firstRejection(Payment p) {
        for (PaymentCheck c : CHECKS) {
            Optional<String> r = c.check(p);
            if (r.isPresent()) return r;
        }
        return Optional.empty();
    }

    /** Тот же список без замыкания: все нарушения, как нужно форме ввода. */
    static List<String> allViolations(Payment p) {
        return CHECKS.stream().map(c -> c.check(p)).flatMap(Optional::stream).toList();
    }

    public static void main(String[] args) {
        var payments = List.of(
                new Payment("k-2", "7700000002", new BigDecimal("15000"), new BigDecimal("0")),
                new Payment("k-3", "7700000001", new BigDecimal("950000"), new BigDecimal("200000")),
                new Payment("k-1", "7700000002", new BigDecimal("15000"), new BigDecimal("0")));
        for (var p : payments) {
            calls.clear();
            var r = firstRejection(p);
            System.out.println(p.key() + ": " + r.orElse("пропущен") + "; вызваны звенья " + calls);
        }
        calls.clear();
        System.out.println("все нарушения платежа k-3: " + allViolations(payments.get(1)) + "; вызваны звенья " + calls);
    }
}
