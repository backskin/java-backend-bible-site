package dev.team.patterns.creational;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;

/** Опыт разд. 2.5: нумератор платёжных поручений как синглтон и пять способов получить второй экземпляр. */
public class SingletonLab {
    /** Классическая ленивая реализация без синхронизации. */
    public static class LazyNumerator {
        private static LazyNumerator instance;
        private final AtomicLong next = new AtomicLong(1);
        private LazyNumerator() { sleep(50); }                 // «дорогая» инициализация: чтение последнего номера из базы
        public static LazyNumerator getInstance() {
            if (instance == null) instance = new LazyNumerator();
            return instance;
        }
        public long nextNumber() { return next.getAndIncrement(); }
    }

    /** Та же ленивая реализация, второй класс — чтобы гонка началась с пустого поля. */
    public static class LazyNumerator2 {
        private static LazyNumerator2 instance;
        private final AtomicLong next = new AtomicLong(1);
        private LazyNumerator2() { sleep(50); }
        public static LazyNumerator2 getInstance() { if (instance == null) instance = new LazyNumerator2(); return instance; }
        public long nextNumber() { return next.getAndIncrement(); }
    }

    /** Ленивая и потокобезопасная реализация: класс-держатель. */
    public static class HolderNumerator implements Serializable {
        private HolderNumerator() { sleep(50); }
        private static class Holder { static final HolderNumerator INSTANCE = new HolderNumerator(); }
        public static HolderNumerator getInstance() { return Holder.INSTANCE; }
    }

    public static class ResolvingNumerator implements Serializable {
        public static final ResolvingNumerator INSTANCE = new ResolvingNumerator();
        private ResolvingNumerator() { }
        private Object readResolve() { return INSTANCE; }
    }

    public enum EnumNumerator { INSTANCE; private final AtomicLong next = new AtomicLong(1); public long nextNumber() { return next.getAndIncrement(); } }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    static Set<Object> race(java.util.function.Supplier<Object> get) throws Exception {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        CountDownLatch start = new CountDownLatch(1);
        Thread[] ts = new Thread[8];
        for (int i = 0; i < ts.length; i++) { ts[i] = new Thread(() -> { try { start.await(); } catch (InterruptedException e) { } seen.add(get.get()); }); ts[i].start(); }
        start.countDown();
        for (Thread t : ts) t.join();
        return seen;
    }

    @SuppressWarnings("unchecked")
    static <T> T roundTrip(T obj) throws Exception {
        var bytes = new ByteArrayOutputStream();
        try (var out = new ObjectOutputStream(bytes)) { out.writeObject(obj); }
        try (var in = new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()))) { return (T) in.readObject(); }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== 1. гонка: 8 потоков одновременно вызывают getInstance()");
        System.out.println("LazyNumerator: экземпляров " + race(LazyNumerator::getInstance).size());
        System.out.println("HolderNumerator: экземпляров " + race(HolderNumerator::getInstance).size());
        var numbers = new java.util.concurrent.ConcurrentLinkedQueue<Long>();
        race(() -> { numbers.add(LazyNumerator2.getInstance().nextNumber()); return new Object(); });
        System.out.println("номера поручений, выданные восемью потоками: " + numbers);

        System.out.println("== 2. рефлексия");
        Constructor<HolderNumerator> c = HolderNumerator.class.getDeclaredConstructor();
        c.setAccessible(true);
        System.out.println("закрытый конструктор вызван, второй экземпляр тот же: " + (c.newInstance() == HolderNumerator.getInstance()));
        try {
            Constructor<EnumNumerator> ec = EnumNumerator.class.getDeclaredConstructor(String.class, int.class);
            ec.setAccessible(true);
            ec.newInstance("COPY", 1);
        } catch (Exception e) { System.out.println("enum: " + e.getClass().getSimpleName() + ": " + e.getMessage()); }

        System.out.println("== 3. сериализация");
        System.out.println("без readResolve тот же объект после десериализации: " + (roundTrip(HolderNumerator.getInstance()) == HolderNumerator.getInstance()));
        System.out.println("с readResolve: " + (roundTrip(ResolvingNumerator.INSTANCE) == ResolvingNumerator.INSTANCE));
        System.out.println("enum: " + (roundTrip(EnumNumerator.INSTANCE) == EnumNumerator.INSTANCE));

        System.out.println("== 4. два загрузчика классов");
        URL classes = Path.of("target/classes").toUri().toURL();
        try (var l1 = new URLClassLoader(new URL[] {classes}, null); var l2 = new URLClassLoader(new URL[] {classes}, null)) {
            String name = EnumNumerator.class.getName();
            Object a = Enum.valueOf(l1.loadClass(name).asSubclass(Enum.class), "INSTANCE");
            Object b = Enum.valueOf(l2.loadClass(name).asSubclass(Enum.class), "INSTANCE");
            System.out.println("EnumNumerator.INSTANCE из двух загрузчиков — один объект: " + (a == b) + "; классы равны: " + (a.getClass() == b.getClass()));
        }
    }
}
