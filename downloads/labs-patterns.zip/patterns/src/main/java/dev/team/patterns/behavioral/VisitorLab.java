package dev.team.patterns.behavioral;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

/**
 * Опыт разд. 2.25: две операции над частями платежа классическим посетителем и той же парой операций
 * через switch по запечатанному интерфейсу; ветка default, которая скрывает новый подтип; обход каталога
 * реестров посетителем JDK с пропуском поддерева.
 */
public class VisitorLab {

    // ---------- классический посетитель: accept + visit на каждый класс ----------
    interface LegVisitor<R> { R visitCard(CardLeg l); R visitSbp(SbpLeg l); R visitInternal(InternalLeg l); }

    sealed interface Leg permits CardLeg, SbpLeg, InternalLeg, QrLeg { <R> R accept(LegVisitor<R> v); }
    record CardLeg(String pan, BigDecimal amount) implements Leg { public <R> R accept(LegVisitor<R> v) { return v.visitCard(this); } }
    record SbpLeg(String phone, BigDecimal amount) implements Leg { public <R> R accept(LegVisitor<R> v) { return v.visitSbp(this); } }
    record InternalLeg(String account, BigDecimal amount) implements Leg { public <R> R accept(LegVisitor<R> v) { return v.visitInternal(this); } }
    /** Новый вид оплаты, добавленный позже; классическому посетителю о нём не сказали. */
    record QrLeg(String qrId, BigDecimal amount) implements Leg { public <R> R accept(LegVisitor<R> v) { throw new UnsupportedOperationException("visitQr нет"); } }

    static final LegVisitor<String> STATEMENT = new LegVisitor<>() {
        public String visitCard(CardLeg l) { return "Карта " + l.pan(); }
        public String visitSbp(SbpLeg l) { return "СБП " + l.phone(); }
        public String visitInternal(InternalLeg l) { return "Перевод на " + l.account(); }
    };

    // ---------- та же операция через switch ----------
    static String statementLine(Leg leg) {
        return switch (leg) {
            case CardLeg(var pan, var a) -> "Карта " + pan;
            case SbpLeg(var phone, var a) -> "СБП " + phone;
            case InternalLeg(var acc, var a) -> "Перевод на " + acc;
            case QrLeg(var id, var a) -> "Оплата по QR " + id;
        };
    }

    /** Ошибка: default делает switch полным для компилятора и скрывает новый подтип. */
    static BigDecimal feeWithDefault(Leg leg) {
        return switch (leg) {
            case CardLeg c -> c.amount().multiply(new BigDecimal("0.01"));
            case SbpLeg s -> BigDecimal.ZERO;
            default -> BigDecimal.ZERO;
        };
    }

    public static void main(String[] args) throws IOException {
        List<Leg> legs = List.of(new CardLeg("2200 **** 0001", new BigDecimal("1500")),
                new SbpLeg("+7 900 000-00-01", new BigDecimal("700")),
                new InternalLeg("40817810000000000003", new BigDecimal("300")));
        for (var l : legs) System.out.println("посетитель: " + l.accept(STATEMENT) + " | switch: " + statementLine(l));

        var qr = new QrLeg("QR-77", new BigDecimal("2000"));
        System.out.println("switch для нового вида: " + statementLine(qr));
        try { qr.accept(STATEMENT); } catch (UnsupportedOperationException e) { System.out.println("посетитель для нового вида: " + e.getMessage()); }
        System.out.println("комиссия с default для QR: " + feeWithDefault(qr) + " (а должна была считаться)");

        Path root = Files.createTempDirectory("registries");
        Files.createDirectories(root.resolve("2026-11-12"));
        Files.createDirectories(root.resolve("archive"));
        Files.writeString(root.resolve("2026-11-12/salary.csv"), "x");
        Files.writeString(root.resolve("2026-11-12/fees.csv"), "x");
        Files.writeString(root.resolve("archive/old.csv"), "x");
        List<String> visited = new ArrayList<>();
        Files.walkFileTree(root, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) {
                return dir.getFileName().toString().equals("archive") ? FileVisitResult.SKIP_SUBTREE : FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path f, BasicFileAttributes a) {
                visited.add(root.relativize(f).toString().replace('\\', '/'));
                return FileVisitResult.CONTINUE;
            }
        });
        visited.sort(null);
        System.out.println("walkFileTree без archive: " + visited);
    }
}
