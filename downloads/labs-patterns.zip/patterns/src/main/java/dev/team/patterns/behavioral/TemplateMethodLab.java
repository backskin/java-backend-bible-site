package dev.team.patterns.behavioral;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Опыт разд. 2.24: импорт реестра шаблонным методом. Скелет final: журнал, карантин битых строк,
 * пачки; подкласс разбирает строку и сохраняет пачку. Вторая часть - тот же скелет функцией,
 * третья - ловушка: переопределяемый метод, вызванный из конструктора базового класса.
 */
public class TemplateMethodLab {

    static abstract class RegistryImport<T> {
        final List<String> journal = new ArrayList<>();

        protected abstract T parse(String line);
        protected abstract void persist(List<T> batch);
        protected int batchSize() { return 2; }

        /** Скелет: подкласс не может пропустить журнал или карантин. */
        public final String run(List<String> lines) {
            journal.add("старт " + getClass().getSimpleName());
            int ok = 0, bad = 0;
            List<T> batch = new ArrayList<>();
            for (String line : lines) {
                try {
                    batch.add(parse(line));
                    ok++;
                } catch (RuntimeException e) {
                    journal.add("карантин: \"" + line + "\" (" + e.getMessage() + ")");
                    bad++;
                }
                if (batch.size() == batchSize()) { persist(batch); batch = new ArrayList<>(); }
            }
            if (!batch.isEmpty()) persist(batch);
            journal.add("конец: принято " + ok + ", в карантине " + bad);
            return String.join("; ", journal);
        }
    }

    record SalaryLine(String account, BigDecimal amount) {}

    static class SalaryRegistry extends RegistryImport<SalaryLine> {
        protected SalaryLine parse(String line) {
            String[] f = line.split(";");
            if (!f[0].matches("\\d{20}")) throw new IllegalArgumentException("счет");
            return new SalaryLine(f[0], new BigDecimal(f[1]));
        }
        protected void persist(List<SalaryLine> batch) { System.out.println("  сохранена пачка из " + batch.size()); }
    }

    /** Тот же скелет без наследования: шаги переданы функциями. */
    static <T> int runWith(List<String> lines, Function<String, T> parse, Consumer<List<T>> persist) {
        List<T> ok = new ArrayList<>();
        for (String l : lines) { try { ok.add(parse.apply(l)); } catch (RuntimeException ignored) { } }
        persist.accept(ok);
        return ok.size();
    }

    /** Ловушка: базовый класс в конструкторе вызывает метод, который переопределил подкласс. */
    static abstract class Base {
        final int capacity;
        Base() { capacity = batchSize(); }
        protected abstract int batchSize();
    }
    static class Sub extends Base {
        private final int size;
        Sub(int size) { super(); this.size = size; }
        protected int batchSize() { return size; }
    }

    public static void main(String[] args) {
        var lines = List.of("40817810000000000001;85000.00", "40817810000000000002;91000.00",
                "4081781000000000000X;77000.00", "40817810000000000004;64000.00");
        System.out.println(new SalaryRegistry().run(lines));
        int n = runWith(lines, l -> new SalaryRegistry().parse(l), b -> System.out.println("  функцией сохранено " + b.size()));
        System.out.println("через функции принято: " + n);
        var sub = new Sub(500);
        System.out.println("Sub(500): capacity из конструктора базы = " + sub.capacity + ", batchSize() после создания = " + sub.batchSize());
    }
}
