package dev.team.patterns.structural;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Опыт разд. 2.12: приспособленец для реквизитов банков в миллионе проводок. Запуск с -Xmx1g. */
public class FlyweightLab {
    /** Внутреннее состояние: реквизиты банка, одинаковые у тысяч проводок. */
    record Bank(String bik, String name, String corrAccount, String city) {
        private static final Map<String, Bank> POOL = new ConcurrentHashMap<>();
        static Bank of(String bik, String name, String corr, String city) {   // фабрика приспособленцев
            return POOL.computeIfAbsent(bik, k -> new Bank(bik, name, corr, city));
        }
    }
    /** Внешнее состояние — сумма и счёт — остаётся в проводке. */
    record Posting(long amountMinor, String account, Bank bank) { }

    /** Изменяемый «приспособленец» — так делать нельзя. */
    static final class MutableBank { String name; MutableBank(String n) { name = n; } }

    static String[] line(int i) {                                          // строка реестра, как её отдаёт разборщик
        int b = i % 3000;
        return new String[]{"0440" + String.format("%05d", b), new String("АО Банк-" + b + " Северного региона"),
                new String("301018100" + String.format("%011d", b)), new String("Архангельск")};
    }

    static long usedMb() {
        Runtime rt = Runtime.getRuntime();
        for (int i = 0; i < 3; i++) System.gc();
        return (rt.totalMemory() - rt.freeMemory()) >> 20;
    }

    public static void main(String[] args) {
        int n = 1_000_000;
        boolean pooled = args.length > 0 && args[0].equals("pool");
        long before = usedMb();
        List<Posting> postings = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            String[] f = line(i);
            Bank bank = pooled ? Bank.of(f[0], f[1], f[2], f[3]) : new Bank(f[0], f[1], f[2], f[3]);
            postings.add(new Posting(150_000 + i, "4070281090000" + String.format("%07d", i), bank));
        }
        long after = usedMb();
        var ids = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<Bank, Boolean>());
        postings.forEach(p -> ids.add(p.bank()));
        long distinct = ids.size();
        System.out.println((pooled ? "с фабрикой" : "без фабрики") + ": проводок " + postings.size() + ", объектов Bank " + distinct
                + ", занято кучи ≈ " + (after - before) + " МБ");

        if (pooled) {
            System.out.println("== общее состояние должно быть неизменяемым");
            Map<String, MutableBank> pool = new ConcurrentHashMap<>();
            MutableBank forPayment1 = pool.computeIfAbsent("044000001", k -> new MutableBank("АО Банк-1"));
            MutableBank forPayment2 = pool.computeIfAbsent("044000001", k -> new MutableBank("АО Банк-1"));
            forPayment1.name = "АО Банк-1 (отозвана лицензия)";            // правка ради одной проводки
            System.out.println("вторая проводка видит: " + forPayment2.name);
            System.out.println("Integer.valueOf(1000) == Integer.valueOf(1000): " + (Integer.valueOf(1000) == Integer.valueOf(1000)));
        }
    }
}
