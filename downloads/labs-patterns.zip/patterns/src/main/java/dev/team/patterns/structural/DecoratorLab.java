package dev.team.patterns.structural;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FilterInputStream;
import java.io.FilterWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** Опыт разд. 2.10: декораторы java.io на реестре платежей, свой декоратор, порядок слоёв и тождество. */
public class DecoratorLab {
    /** Свой декоратор потока: считает байты, прошедшие через его слой. */
    static class CountingInputStream extends FilterInputStream {
        long bytes;
        CountingInputStream(InputStream in) { super(in); }
        @Override public int read() throws IOException { int b = super.read(); if (b >= 0) bytes++; return b; }
        @Override public int read(byte[] buf, int off, int len) throws IOException { int n = super.read(buf, off, len); if (n > 0) bytes += n; return n; }
    }

    /** Декоратор Writer: маскирует номера карт до того, как строка попадёт в журнал. */
    static class PanMaskingWriter extends FilterWriter {
        static final Pattern PAN = Pattern.compile("\\b(\\d{6})\\d{6}(\\d{4})\\b");
        PanMaskingWriter(Writer out) { super(out); }
        @Override public void write(String s, int off, int len) throws IOException {
            String masked = PAN.matcher(s.substring(off, off + len)).replaceAll("$1******$2");
            out.write(masked, 0, masked.length());
        }
    }

    // ---- декораторы своего интерфейса: повтор и замер времени
    interface Gateway { String send(String payment); }
    static class FlakyGateway implements Gateway {
        int calls;
        public String send(String p) {
            calls++;
            sleep(40);
            if (calls % 3 != 0) throw new IllegalStateException("таймаут эквайрера");
            return "одобрено " + p;
        }
    }
    static class Retrying implements Gateway {
        private final Gateway inner; private final int attempts;
        Retrying(Gateway inner, int attempts) { this.inner = inner; this.attempts = attempts; }
        public String send(String p) {
            for (int i = 1; ; i++) {
                try { return inner.send(p); }
                catch (IllegalStateException e) { if (i == attempts) throw e; sleep(100); }
            }
        }
    }
    static class Timed implements Gateway {
        private final Gateway inner; final List<Long> samples = new ArrayList<>();
        Timed(Gateway inner) { this.inner = inner; }
        public String send(String p) {
            long t = System.nanoTime();
            try { return inner.send(p); } finally { samples.add((System.nanoTime() - t) / 1_000_000); }
        }
    }
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); } }

    public static void main(String[] args) throws Exception {
        // реестр от бухгалтерии клиента: 2000 строк, сжат gzip, рядом прислан SHA-256 несжатого файла
        StringBuilder reg = new StringBuilder("H;R-1027;2026-10-26\n");
        for (int i = 1; i <= 2000; i++) reg.append("P;4070281090000000").append(String.format("%04d", i)).append(";1500.00;Зарплата за октябрь\n");
        reg.append("T;2000;3000000.00\n");
        byte[] plain = reg.toString().getBytes(StandardCharsets.UTF_8);
        String sentDigest = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(plain));
        var gz = new ByteArrayOutputStream();
        try (var out = new GZIPOutputStream(gz)) { out.write(plain); }

        System.out.println("== стопка декораторов java.io");
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        var compressed = new CountingInputStream(new ByteArrayInputStream(gz.toByteArray()));
        var unpacked = new CountingInputStream(new GZIPInputStream(compressed));
        int lines = 0;
        try (var r = new BufferedReader(new InputStreamReader(new DigestInputStream(unpacked, sha), StandardCharsets.UTF_8))) {
            while (r.readLine() != null) lines++;
        }
        String gotDigest = HexFormat.of().formatHex(sha.digest());
        System.out.println("строк " + lines + "; ниже GZIPInputStream прошло " + compressed.bytes + " байт, выше — " + unpacked.bytes);
        System.out.println("SHA-256 совпал с присланным: " + gotDigest.equals(sentDigest) + " (" + gotDigest.substring(0, 16) + "…)");

        System.out.println("== декоратор журнала");
        var log = new StringWriter();
        try (Writer w = new PanMaskingWriter(log)) { w.write("auth pan=2200123456789010 amount=1250.50 rrn=630012345678\n"); }
        System.out.print(log);

        System.out.println("== порядок слоёв: замер снаружи и внутри повтора");
        var outer = new Timed(new Retrying(new FlakyGateway(), 3));
        outer.send("платёж 1");
        System.out.println("Timed(Retrying(шлюз)): замеров " + outer.samples.size() + ", мс " + outer.samples);
        var inner = new Timed(new FlakyGateway());
        new Retrying(inner, 3).send("платёж 1");
        System.out.println("Retrying(Timed(шлюз)): замеров " + inner.samples.size() + ", мс " + inner.samples);

        System.out.println("== тождество после обёртки");
        Gateway raw = new FlakyGateway();
        Gateway wrapped = new Timed(raw);
        System.out.println("wrapped instanceof FlakyGateway: " + (wrapped instanceof FlakyGateway) + ", wrapped.equals(raw): " + wrapped.equals(raw)
                + ", в журнале: " + wrapped.toString().replaceAll("@.*", "@…"));
    }
}
