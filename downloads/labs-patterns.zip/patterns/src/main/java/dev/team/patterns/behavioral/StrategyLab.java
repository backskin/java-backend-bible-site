package dev.team.patterns.behavioral;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Опыт разд. 2.23: таблица стратегий из списка реализаций и что происходит при двух реализациях
 * на один ключ; стратегия округления как перечисление с телом.
 */
public class StrategyLab {

    enum Product { CARD_TO_CARD, SBP, INTERBANK }

    interface FeeCalculator {
        Product supports();
        BigDecimal fee(BigDecimal amount);
    }

    record Fixed(Product supports, BigDecimal value) implements FeeCalculator {
        public BigDecimal fee(BigDecimal amount) { return value; }
    }

    enum Rounding {
        BANKERS { BigDecimal apply(BigDecimal v) { return v.setScale(2, RoundingMode.HALF_EVEN); } },
        HALF_UP { BigDecimal apply(BigDecimal v) { return v.setScale(2, RoundingMode.HALF_UP); } },
        IN_FAVOR_OF_BANK { BigDecimal apply(BigDecimal v) { return v.setScale(2, v.signum() >= 0 ? RoundingMode.CEILING : RoundingMode.FLOOR); } };
        abstract BigDecimal apply(BigDecimal v);
    }

    public static void main(String[] args) {
        List<FeeCalculator> beans = List.of(
                new Fixed(Product.CARD_TO_CARD, new BigDecimal("30")),
                new Fixed(Product.SBP, BigDecimal.ZERO),
                new Fixed(Product.SBP, new BigDecimal("15")),        // вторая реализация на тот же ключ
                new Fixed(Product.INTERBANK, new BigDecimal("50")));

        Map<Product, FeeCalculator> byLoop = new HashMap<>();
        for (var c : beans) byLoop.put(c.supports(), c);
        System.out.println("цикл с put: " + byLoop.size() + " ключа, для SBP осталась " + byLoop.get(Product.SBP));

        for (var collector : List.of("toMap", "toUnmodifiableMap")) {
            try {
                Map<Product, FeeCalculator> m = collector.equals("toMap")
                        ? beans.stream().collect(Collectors.toMap(FeeCalculator::supports, Function.identity()))
                        : beans.stream().collect(Collectors.toUnmodifiableMap(FeeCalculator::supports, Function.identity()));
                System.out.println(collector + ": " + m.size());
            } catch (IllegalStateException e) {
                System.out.println(collector + ": IllegalStateException: " + e.getMessage());
            }
        }

        for (var v : List.of(new BigDecimal("10.005"), new BigDecimal("10.015"), new BigDecimal("-10.005"))) {
            StringBuilder sb = new StringBuilder(v.toPlainString() + ":");
            for (var r : Rounding.values()) sb.append(" ").append(r).append("=").append(r.apply(v));
            System.out.println(sb);
        }
        System.out.println("стратегия из строки БД: " + Rounding.valueOf("BANKERS").apply(new BigDecimal("2.675")));
    }
}
