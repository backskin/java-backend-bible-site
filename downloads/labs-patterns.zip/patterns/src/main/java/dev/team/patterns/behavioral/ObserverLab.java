package dev.team.patterns.behavioral;

import java.beans.PropertyChangeSupport;
import java.math.BigDecimal;
import java.util.Observable;
import java.util.concurrent.Flow;
import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.TimeUnit;

/**
 * Опыт разд. 2.21: наблюдатель в JDK. Статус java.util.Observable, модель "проталкивания"
 * в PropertyChangeSupport и наблюдатель с обратным давлением в Flow: подписчик получает
 * ровно столько элементов, сколько запросил.
 */
public class ObserverLab {

    /** Счет с остатком: при изменении уведомляет слушателей старым и новым значением. */
    static class Account {
        private final PropertyChangeSupport listeners = new PropertyChangeSupport(this);
        private BigDecimal balance = new BigDecimal("50000.00");
        void addListener(java.beans.PropertyChangeListener l) { listeners.addPropertyChangeListener("balance", l); }
        void debit(BigDecimal a) {
            var old = balance;
            balance = balance.subtract(a);
            listeners.firePropertyChange("balance", old, balance);
        }
    }

    @SuppressWarnings("deprecation")
    public static void main(String[] args) throws Exception {
        Deprecated d = Observable.class.getAnnotation(Deprecated.class);
        System.out.println("java.util.Observable: @Deprecated(since=\"" + d.since() + "\", forRemoval=" + d.forRemoval() + ")");

        var acc = new Account();
        acc.addListener(e -> System.out.println("антифрод: остаток " + e.getOldValue() + " -> " + e.getNewValue()));
        acc.addListener(e -> System.out.println("пуш клиенту: остаток " + e.getNewValue()));
        acc.debit(new BigDecimal("1200.00"));

        var done = new java.util.concurrent.CountDownLatch(1);
        try (var publisher = new SubmissionPublisher<String>()) {
            publisher.subscribe(new Flow.Subscriber<>() {
                Flow.Subscription s;
                int received;
                public void onSubscribe(Flow.Subscription s) { this.s = s; s.request(2); }
                public void onNext(String item) {
                    received++;
                    System.out.println("подписчик получил " + item);
                    if (received == 2) done.countDown();
                }
                public void onError(Throwable t) { }
                public void onComplete() { }
            });
            for (int i = 1; i <= 5; i++) publisher.submit("статус платежа " + i);
            done.await(2, TimeUnit.SECONDS);
            Thread.sleep(200);
            System.out.println("подписчик запросил 2, издатель держит в буфере ещё " + publisher.estimateMaximumLag());
        }
    }
}
