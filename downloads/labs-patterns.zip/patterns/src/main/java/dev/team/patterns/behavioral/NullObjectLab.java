package dev.team.patterns.behavioral;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Опыт разд. 2.26: пустой объект против Optional. Пустые объекты JDK, пустой отправитель уведомлений
 * и пустая проверка по санкционному перечню, которая пропускает платеж без единой ошибки.
 */
public class NullObjectLab {

    interface Notifier { void send(String to, String text); }
    static final Notifier NO_OP = (to, text) -> { };

    interface SanctionScreening { boolean isListed(String inn); }
    /** Заглушка для тестового стенда; в проде её быть не должно. */
    static final SanctionScreening NO_OP_SCREENING = inn -> false;
    static final SanctionScreening REAL = inn -> inn.equals("7700000001");

    record Merchant(String category) {}
    record Payment(String payeeInn, Optional<Merchant> merchant) {}

    static String pay(Payment p, SanctionScreening s, Notifier n) {
        if (s.isListed(p.payeeInn())) return "отклонен: получатель в перечне";
        n.send("клиент", "платеж проведен");
        return "проведен";
    }

    public static void main(String[] args) throws IOException {
        try {
            Collections.<String>emptyList().add("x");
        } catch (UnsupportedOperationException e) {
            System.out.println("Collections.emptyList().add: UnsupportedOperationException");
        }
        try (OutputStream out = OutputStream.nullOutputStream()) {
            out.write(new byte[1024]);
            System.out.println("OutputStream.nullOutputStream(): 1024 байта записаны в никуда");
        }

        var p2p = new Payment("7700000002", Optional.empty());
        System.out.println("категория без мерчанта: " + p2p.merchant().map(Merchant::category).orElse("P2P"));

        var toListed = new Payment("7700000001", Optional.of(new Merchant("5411")));
        System.out.println("с настоящей проверкой: " + pay(toListed, REAL, NO_OP));
        System.out.println("с пустой проверкой:    " + pay(toListed, NO_OP_SCREENING, NO_OP));
        System.out.println(List.of("java " + System.getProperty("java.version")));
    }
}
