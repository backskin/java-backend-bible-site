package dev.team.patterns.behavioral;

import java.util.ArrayList;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Опыт разд. 2.18: свой итератор поверх постраничного источника (страницы выписки тянутся по мере чтения),
 * повторный hasNext без лишнего запроса, ленивость Stream поверх итератора; fail-fast итератор ArrayList
 * и итератор-снимок CopyOnWriteArrayList.
 */
public class IteratorLab {

    record Page(List<String> lines, String nextCursor) {}

    /** Внешний API выписки: страницы по 10 строк, всего 25 строк. Считает обращения. */
    static class StatementApi {
        int fetches;
        Page fetch(String cursor) {
            fetches++;
            int from = cursor == null ? 0 : Integer.parseInt(cursor);
            int to = Math.min(from + 10, 25);
            List<String> lines = new ArrayList<>();
            for (int i = from; i < to; i++) lines.add("проводка " + (i + 1));
            return new Page(lines, to < 25 ? String.valueOf(to) : null);
        }
    }

    static class StatementLines implements Iterable<String> {
        final StatementApi api;
        StatementLines(StatementApi api) { this.api = api; }

        @Override public Iterator<String> iterator() {
            return new Iterator<>() {
                Iterator<String> page = Collections.emptyIterator();
                String cursor;
                boolean exhausted;

                @Override public boolean hasNext() {
                    while (!page.hasNext() && !exhausted) {     // страницу тянем, только если текущая кончилась
                        Page p = api.fetch(cursor);
                        page = p.lines().iterator();
                        cursor = p.nextCursor();
                        exhausted = cursor == null;
                    }
                    return page.hasNext();
                }

                @Override public String next() {
                    if (!hasNext()) throw new NoSuchElementException();
                    return page.next();
                }
            };
        }

        Stream<String> stream() { return StreamSupport.stream(spliterator(), false); }
    }

    public static void main(String[] args) {
        var api = new StatementApi();
        int n = 0;
        for (String ignored : new StatementLines(api)) n++;
        System.out.println("прочитано строк: " + n + ", запросов страниц: " + api.fetches);

        api = new StatementApi();
        var it = new StatementLines(api).iterator();
        it.hasNext(); it.hasNext(); it.hasNext();
        System.out.println("три hasNext подряд: запросов " + api.fetches);

        api = new StatementApi();
        var first5 = new StatementLines(api).stream().limit(5).toList();
        System.out.println("stream().limit(5): " + first5.size() + " строк, запросов " + api.fetches);

        List<String> list = new ArrayList<>(List.of("p1", "p2", "p3"));
        try {
            for (String s : list) if (s.equals("p1")) list.remove(s);
        } catch (ConcurrentModificationException e) {
            System.out.println("ArrayList: удаление внутри for-each -> ConcurrentModificationException");
        }
        List<String> cow = new CopyOnWriteArrayList<>(List.of("p1", "p2", "p3"));
        List<String> seen = new ArrayList<>();
        for (String s : cow) { seen.add(s); if (s.equals("p1")) cow.add("p4"); }
        System.out.println("CopyOnWriteArrayList: обход увидел " + seen + ", в списке теперь " + cow);
    }
}
