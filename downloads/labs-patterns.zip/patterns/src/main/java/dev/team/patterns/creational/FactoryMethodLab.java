package dev.team.patterns.creational;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.EnumSet;
import java.util.List;

/** Опыт разд. 2.1: фабричный метод в выгрузке выписки и статические фабрики JDK. */
public class FactoryMethodLab {
    record Entry(LocalDate date, String counterparty, BigDecimal amount) {}

    /** Строка выписки в конкретном формате. */
    interface LineWriter { String write(Entry e); }

    /** Создатель: общий алгоритм выгрузки, а формат строки выбирает подкласс. */
    abstract static class StatementExport {
        final String export(String account, List<Entry> entries) {
            LineWriter writer = createWriter();                 // фабричный метод
            StringBuilder out = new StringBuilder(header(account));
            BigDecimal total = BigDecimal.ZERO;
            for (Entry e : entries) { out.append(writer.write(e)).append('\n'); total = total.add(e.amount()); }
            return out.append(footer(total)).toString();
        }
        String header(String account) { return "выписка по счёту " + account + "\n"; }
        String footer(BigDecimal total) { return "итого: " + total; }
        protected abstract LineWriter createWriter();
    }

    static class CsvExport extends StatementExport {
        @Override protected LineWriter createWriter() { return e -> e.date() + ";" + e.counterparty() + ";" + e.amount(); }
    }

    static class Camt053Export extends StatementExport {
        @Override String header(String account) { return "<Stmt><Acct><Id><Othr><Id>" + account + "</Id></Othr></Id></Acct>\n"; }
        @Override String footer(BigDecimal total) { return "</Stmt>"; }
        @Override protected LineWriter createWriter() {
            return e -> "  <Ntry><Amt Ccy=\"RUB\">" + e.amount().abs() + "</Amt><CdtDbtInd>"
                    + (e.amount().signum() < 0 ? "DBIT" : "CRDT") + "</CdtDbtInd><BookgDt><Dt>" + e.date() + "</Dt></BookgDt></Ntry>";
        }
    }

    /** Создатель, который зовёт фабричный метод из своего конструктора: подкласс ещё не инициализирован. */
    abstract static class EagerExport {
        final LineWriter writer;
        EagerExport() { writer = createWriter(); }
        protected abstract LineWriter createWriter();
    }

    static class SeparatedCsvExport extends EagerExport {
        private final String separator;
        SeparatedCsvExport(String separator) { super(); this.separator = separator; }
        @Override protected LineWriter createWriter() {
            String sep = separator;                                  // читается до присваивания в конструкторе подкласса
            return e -> e.date() + sep + e.counterparty() + sep + e.amount();
        }
    }

    enum Small { A, B }
    enum Big { C00, C01, C02, C03, C04, C05, C06, C07, C08, C09, C10, C11, C12, C13, C14, C15, C16, C17, C18, C19,
        C20, C21, C22, C23, C24, C25, C26, C27, C28, C29, C30, C31, C32, C33, C34, C35, C36, C37, C38, C39,
        C40, C41, C42, C43, C44, C45, C46, C47, C48, C49, C50, C51, C52, C53, C54, C55, C56, C57, C58, C59,
        C60, C61, C62, C63, C64 }

    public static void main(String[] args) {
        var entries = List.of(new Entry(LocalDate.of(2026, 10, 1), "ООО Ромашка", new BigDecimal("15000.00")),
                new Entry(LocalDate.of(2026, 10, 2), "ИП Иванов", new BigDecimal("-2350.50")));
        for (StatementExport ex : List.of(new CsvExport(), new Camt053Export())) {
            System.out.println("== " + ex.getClass().getSimpleName());
            System.out.println(ex.export("40702810900000000001", entries));
        }
        System.out.println("== фабричный метод вызван из конструктора создателя");
        System.out.println(new SeparatedCsvExport("|").writer.write(entries.get(0)));
        System.out.println("== статические фабрики JDK");
        System.out.println("EnumSet.allOf(2 константы):  " + EnumSet.allOf(Small.class).getClass().getSimpleName());
        System.out.println("EnumSet.allOf(65 констант): " + EnumSet.allOf(Big.class).getClass().getSimpleName());
        System.out.println("Integer.valueOf(127) == Integer.valueOf(127): " + (Integer.valueOf(127) == Integer.valueOf(127)));
        System.out.println("Integer.valueOf(128) == Integer.valueOf(128): " + (Integer.valueOf(128) == Integer.valueOf(128)));
        System.out.println("List.of(1, 2).getClass(): " + List.of(1, 2).getClass().getName()
                + ", List.of(1, 2, 3).getClass(): " + List.of(1, 2, 3).getClass().getName());
    }
}
