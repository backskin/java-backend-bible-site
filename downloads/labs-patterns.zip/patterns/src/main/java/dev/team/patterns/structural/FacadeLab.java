package dev.team.patterns.structural;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Опыт разд. 2.11: фасад открытия расчётного счёта юрлицу поверх пяти подсистем банка. */
public class FacadeLab {
    // ---- подсистема: каждый класс самостоятелен и о фасаде не знает
    static class Compliance {
        String check(String inn) { return inn.startsWith("77000") ? "отказ: ИНН в перечне комплаенса" : "ok"; }
    }
    static class Polus {                                                    // АБС
        final Map<String, String> open = new LinkedHashMap<>();
        private int seq = 17;
        String openAccount(String inn) { String acc = "40702810" + String.format("%012d", ++seq); open.put(acc, inn); return acc; }
        void closeAccount(String acc) { open.remove(acc); }
    }
    static class Contracts {
        String issue(String inn, String acc) {
            if (inn.endsWith("13")) throw new IllegalStateException("шаблон договора для ОПФ не найден");
            return "Д-" + acc.substring(16) + "/2026";
        }
    }
    static class OnlineBank { String grantAccess(String inn, String acc) { return "доступ к " + acc + " выдан"; } }
    static class Notifier { void notify(String inn, String text) { System.out.println("   уведомление " + inn + ": " + text); } }

    // ---- фасад: одна операция уровня задачи, порядок шагов и компенсация живут здесь
    static class AccountOpening {
        private final Compliance compliance; private final Polus polus; private final Contracts contracts;
        private final OnlineBank online; private final Notifier notifier;
        AccountOpening(Compliance c, Polus p, Contracts k, OnlineBank o, Notifier n) { compliance = c; polus = p; contracts = k; online = o; notifier = n; }

        String open(String inn) {
            String verdict = compliance.check(inn);
            if (!verdict.equals("ok")) return verdict;
            String acc = polus.openAccount(inn);
            try {
                String contract = contracts.issue(inn, acc);
                online.grantAccess(inn, acc);
                notifier.notify(inn, "счёт " + acc + " открыт, договор " + contract);
                return "открыт " + acc + ", договор " + contract;
            } catch (RuntimeException e) {
                polus.closeAccount(acc);                                    // компенсация: счёт без договора не оставляем
                return "не открыт: " + e.getMessage() + " (счёт " + acc + " закрыт)";
            }
        }
    }

    /** Тот же сценарий, написанный вызывающим кодом без фасада: в отделении забыли компенсацию. */
    static String openAtBranchWithoutFacade(String inn, Compliance c, Polus p, Contracts k) {
        if (!c.check(inn).equals("ok")) return "отказ";
        String acc = p.openAccount(inn);
        return "открыт " + acc + ", договор " + k.issue(inn, acc);
    }

    public static void main(String[] args) {
        var compliance = new Compliance(); var polus = new Polus(); var contracts = new Contracts();
        var facade = new AccountOpening(compliance, polus, contracts, new OnlineBank(), new Notifier());
        System.out.println("== через фасад");
        for (String inn : List.of("2901000033", "7700012345", "2901000413"))
            System.out.println(inn + " → " + facade.open(inn));
        System.out.println("счетов в АБС: " + polus.open.size());

        System.out.println("== отделение без фасада");
        List<String> log = new ArrayList<>();
        try { log.add(openAtBranchWithoutFacade("2901000513", compliance, polus, contracts)); }
        catch (IllegalStateException e) { log.add("исключение: " + e.getMessage()); }
        System.out.println(log.get(0));
        System.out.println("счетов в АБС: " + polus.open.size() + " " + polus.open);

        System.out.println("== подсистема доступна напрямую");
        System.out.println("отчёт сверки читает АБС сам: " + polus.open.keySet());
    }
}
