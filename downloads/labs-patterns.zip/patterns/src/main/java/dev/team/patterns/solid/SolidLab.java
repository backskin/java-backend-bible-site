package dev.team.patterns.solid;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.function.Supplier;

/**
 * Опыт разд. 4: принцип подстановки Лисков и наследование.
 * Контрактная проверка, одна на все реализации интерфейса, ловит две формы нарушения: новое исключение
 * и суженное предусловие. Дальше - Stack поверх Vector, Arrays.asList и List.of, подсчет добавлений
 * в наследнике HashSet (пример Блоха).
 */
public class SolidLab {

    static class AccountNotFound extends RuntimeException {
        AccountNotFound(String id) { super("счет не найден: " + id); }
    }

    /** Контракт: существующий счет возвращается, отсутствующий - AccountNotFound и никакое другое исключение. */
    interface Accounts { BigDecimal balance(String account); }

    static class DbAccounts implements Accounts {
        final Map<String, BigDecimal> rows = Map.of("40817810000000000001", new BigDecimal("1500.00"));
        public BigDecimal balance(String a) {
            var b = rows.get(a);
            if (b == null) throw new AccountNotFound(a);
            return b;
        }
    }

    /** Нарушение: пока кэш не прогрет, реализация бросает исключение, которого нет в контракте. */
    static class CachingAccounts implements Accounts {
        final Map<String, BigDecimal> cache = Map.of();
        public BigDecimal balance(String a) {
            var b = cache.get(a);
            if (b == null) throw new IllegalStateException("кэш не прогрет");
            return b;
        }
    }

    /** Контракт: курс для любой пары валют из справочника. */
    interface Rates { BigDecimal rate(String from, String to); }

    static class TableRates implements Rates {
        public BigDecimal rate(String from, String to) { return from.equals(to) ? BigDecimal.ONE : new BigDecimal("0.0110"); }
    }

    /** Нарушение: реализация принимает только пары к рублю - предусловие сильнее, чем в контракте. */
    static class RubOnlyRates implements Rates {
        public BigDecimal rate(String from, String to) {
            if (!to.equals("RUB")) throw new UnsupportedOperationException("только курсы к рублю");
            return new BigDecimal("91.50");
        }
    }

    static String check(String name, Supplier<Object> call, Class<? extends Throwable> allowed) {
        try {
            call.get();
            return name + ": ok";
        } catch (Throwable t) {
            return name + ": " + (allowed != null && allowed.isInstance(t) ? "ok (" + t.getClass().getSimpleName() + ")"
                    : "НАРУШЕНИЕ - " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    /** Наследник HashSet, который считает добавленные элементы (Блох, разд. 4.4). */
    static class InstrumentedHashSet<E> extends HashSet<E> {
        int addCount;
        @Override public boolean add(E e) { addCount++; return super.add(e); }
        @Override public boolean addAll(Collection<? extends E> c) { addCount += c.size(); return super.addAll(c); }
    }

    public static void main(String[] args) {
        System.out.println("== контракт Accounts");
        for (Accounts impl : List.of(new DbAccounts(), new CachingAccounts())) {
            String n = impl.getClass().getSimpleName();
            System.out.println(check(n + ".balance(отсутствующий)", () -> impl.balance("40817810000000000999"), AccountNotFound.class));
        }
        System.out.println("== контракт Rates");
        for (Rates impl : List.of(new TableRates(), new RubOnlyRates())) {
            String n = impl.getClass().getSimpleName();
            System.out.println(check(n + ".rate(USD, EUR)", () -> impl.rate("USD", "EUR"), null));
        }

        System.out.println("== Stack extends Vector");
        Stack<String> stack = new Stack<>();
        stack.push("операция 1"); stack.push("операция 2"); stack.push("операция 3");
        stack.add(1, "вставлено в середину");            // метод Vector, у стека его быть не должно
        List<String> popped = new ArrayList<>();
        while (!stack.isEmpty()) popped.add(stack.pop());
        System.out.println("порядок pop: " + popped);

        System.out.println("== Arrays.asList и List.of");
        List<String> fixed = Arrays.asList("a", "b");
        System.out.println(check("Arrays.asList.set(0)", () -> fixed.set(0, "x"), null));
        System.out.println(check("Arrays.asList.add", () -> fixed.add("c"), UnsupportedOperationException.class));
        List<String> immutable = List.of("a", "b");
        System.out.println(check("List.of.set(0)", () -> immutable.set(0, "x"), UnsupportedOperationException.class));

        System.out.println("== наследник HashSet");
        var s = new InstrumentedHashSet<String>();
        s.addAll(List.of("перевод", "платеж", "сторно"));
        System.out.println("добавлено 3 элемента, addCount = " + s.addCount);
        System.out.println("java " + System.getProperty("java.version"));
    }
}
