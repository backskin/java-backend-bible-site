import java.util.List;
import java.util.stream.Gatherers;

/**
 * Опыт разд. 2.18: попарная склейка строк выписки готовым собирателем (JEP 485, Java 24),
 * без своего итератора. Запуск: java GathererCheck.java на JDK 24 и новее.
 */
public class GathererCheck {
    public static void main(String[] args) {
        var lines = List.of("проводка 1", "проводка 2", "проводка 3", "проводка 4", "проводка 5");
        System.out.println(lines.stream().gather(Gatherers.windowFixed(2)).toList());
        System.out.println(lines.stream().gather(Gatherers.windowSliding(2)).toList());
        System.out.println("java " + System.getProperty("java.version"));
    }
}
