import java.math.BigDecimal;

/**
 * Опыт разд. 1.3: switch без одного из разрешенных подтипов sealed-интерфейса не компилируется.
 * Файл лежит вне src/main, его собирает только run-missing-case.sh, и сборка должна упасть.
 */
public class MissingCase {
    sealed interface PaymentEvent permits Authorized, Captured, Refunded {}
    record Authorized(String id, BigDecimal amount) implements PaymentEvent {}
    record Captured(String id, BigDecimal amount) implements PaymentEvent {}
    record Refunded(String id, BigDecimal amount, String reason) implements PaymentEvent {}

    static String toLedgerLine(PaymentEvent e) {
        return switch (e) {                       // Refunded забыт
            case Authorized(var id, var amount) -> "HOLD " + id + " " + amount;
            case Captured(var id, var amount) -> "DEBIT " + id + " " + amount;
        };
    }
}
