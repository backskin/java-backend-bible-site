import java.util.function.Function;

/**
 * Опыт разд. 2.1: фабричный метод, вызванный из конструктора создателя, на JDK 25.
 * Поле подкласса присваивается до {@code super()} (гибкие тела конструкторов, JEP 513),
 * и переопределенный метод видит его заполненным. Запуск: java EarlyFieldCheck.java на JDK 25 и новее.
 */
public class EarlyFieldCheck {

    abstract static class EagerExport {
        final Function<String[], String> writer;

        EagerExport() {
            writer = createWriter();
        }

        protected abstract Function<String[], String> createWriter();
    }

    static class SeparatedCsvExport extends EagerExport {
        private final String separator;

        SeparatedCsvExport(String separator) {
            super();
            this.separator = separator;
        }

        @Override
        protected Function<String[], String> createWriter() {
            String sep = separator;
            return f -> f[0] + sep + f[1] + sep + f[2];
        }
    }

    static class EarlySeparatedCsvExport extends EagerExport {
        private final String separator;

        EarlySeparatedCsvExport(String separator) {
            this.separator = separator;                                  // до super(): JEP 513
            super();
        }

        @Override
        protected Function<String[], String> createWriter() {
            String sep = separator;
            return f -> f[0] + sep + f[1] + sep + f[2];
        }
    }

    public static void main(String[] args) {
        String[] line = {"2026-10-01", "ООО Ромашка", "15000.00"};
        System.out.println("java.version=" + System.getProperty("java.version"));
        System.out.println("присваивание после super(): " + new SeparatedCsvExport("|").writer.apply(line));
        System.out.println("присваивание до super():    " + new EarlySeparatedCsvExport("|").writer.apply(line));
    }
}
