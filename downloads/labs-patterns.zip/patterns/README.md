# Паттерны GoF на задачах платежного сервиса: порождающие и структурные, каждый с запуском

Стенд к главе 32. Проект Maven без зависимостей, где каждый паттерн - класс с `main` в `dev.team.patterns`: порождающие (`FactoryMethodLab`, `AbstractFactoryLab`, `RegistryBuilderLab`, `BuilderLab`, `PrototypeLab`, `SingletonLab`) и структурные (`AdapterLab`, `BridgeLab`, `CompositeLab`, `DecoratorLab`, `FacadeLab`, `FlyweightLab`, `ProxyLab`). Каждый разбор в главе устроен одинаково: задача и код, какую ось изменений паттерн выносит наружу, где он уже встроен в JDK и Spring, когда в современном сервисе не нужен. Выводы программ приведены в главе; банки, счета, ИНН, курсы и номера карт вымышлены.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile && java -Dstdout.encoding=UTF-8 -cp target/classes dev.team.patterns.structural.DecoratorLab
```

`FlyweightLab` запускают с `-Xmx1g` и повторяют с `-XX:AutoBoxCacheMax=2000`. В IDEA на каждый класс есть конфигурация.
