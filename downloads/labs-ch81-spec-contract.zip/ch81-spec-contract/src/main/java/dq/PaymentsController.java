package dq;

import dq.api.PaymentsApi;
import dq.model.CreatePaymentRequest;
import dq.model.Payment;
import dq.model.Problem;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Реализация, которая соблюдает контракт: интерфейс и модель сгенерированы из payments.yaml, человек пишет только поведение. */
@RestController
@Profile("!ai")
public class PaymentsController implements PaymentsApi {

    private final Map<UUID, Payment> store = new ConcurrentHashMap<>();

    @Override
    public ResponseEntity<Payment> createPayment(CreatePaymentRequest request) {
        Payment payment = new Payment()
                .id(UUID.randomUUID())
                .status(Payment.StatusEnum.NEW)
                .amountMinor(request.getAmountMinor())
                .currency(Payment.CurrencyEnum.valueOf(request.getCurrency().getValue()));
        store.put(payment.getId(), payment);
        return ResponseEntity.status(HttpStatus.CREATED).body(payment);
    }

    @Override
    @SuppressWarnings("unchecked")
    public ResponseEntity<Payment> getPayment(UUID id) {
        Payment payment = store.get(id);
        if (payment == null) {
            Problem problem = new Problem().type("about:blank").title("Платёж не найден").status(404).detail("id=" + id);
            return (ResponseEntity<Payment>) (ResponseEntity<?>) ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .contentType(MediaType.APPLICATION_PROBLEM_JSON).body(problem);
        }
        return ResponseEntity.ok(payment);
    }
}
