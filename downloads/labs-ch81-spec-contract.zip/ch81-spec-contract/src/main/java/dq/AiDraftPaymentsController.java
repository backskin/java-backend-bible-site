package dq;

import dq.api.PaymentsApi;
import dq.model.CreatePaymentRequest;
import dq.model.Payment;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Черновик «от ИИ» без ссылки на контракт: код компилируется и на глаз выглядит разумно, но нарушает спецификацию в трёх местах.
 * Нужен только для демонстрации: включается профилем ai.
 */
@RestController
@Profile("ai")
public class AiDraftPaymentsController implements PaymentsApi {

    private final Map<UUID, Payment> store = new ConcurrentHashMap<>();

    @Override
    @SuppressWarnings("unchecked")
    public ResponseEntity<Payment> createPayment(CreatePaymentRequest request) {
        // нарушение 1: контракт требует 201, здесь 200
        // нарушение 2: поле status принимает значение вне enum контракта
        Map<String, Object> body = Map.of(
                "id", UUID.randomUUID().toString(),
                "status", "CREATED",
                "amount", String.format("%.2f", request.getAmountMinor() / 100.0),   // нарушение 3: другое имя поля и тип «строка» вместо integer amountMinor
                "currency", request.getCurrency().getValue());
        int status = Boolean.getBoolean("ai.fixstatus") ? 201 : 200;   // вторая итерация: статус исправлен, остальное нет
        return (ResponseEntity<Payment>) (ResponseEntity<?>) ResponseEntity.status(status).body(body);
    }

    @Override
    public ResponseEntity<Payment> getPayment(UUID id) {
        // нарушение 4: «не найдено» отдаётся как 200 с пустым телом, а в контракте это 404 с Problem
        return ResponseEntity.ok(store.get(id));
    }
}
