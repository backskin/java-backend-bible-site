package dq;

import com.atlassian.oai.validator.model.Request;
import com.atlassian.oai.validator.report.ValidationReport;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

/** Контрактные проверки трёх сценариев. Профиль задаётся системным свойством: по умолчанию честная реализация, с -Dspring.profiles.active=ai черновик «от ИИ». */
@SpringBootTest
@AutoConfigureMockMvc(print = org.springframework.boot.webmvc.test.autoconfigure.MockMvcPrint.NONE)
class ContractTest {

    static final boolean AI = "ai".equals(System.getProperty("spring.profiles.active"));

    static int violations;

    @Autowired MockMvc mvc;

    @org.junit.jupiter.api.AfterAll
    static void aiDraftMustViolate() {
        if (AI) assertTrue(violations > 0, "ожидали, что черновик ИИ нарушит контракт");
    }

    private void verdict(String scenario, ValidationReport report) {
        System.out.println("  " + scenario + ": " + (report.hasErrors() ? "НАРУШЕНИЙ КОНТРАКТА " + report.getMessages().size() : "соответствует контракту"));
        if (report.hasErrors()) System.out.print(Contract.describe(report));
        if (report.hasErrors()) violations++;
        if (!AI) assertFalse(report.hasErrors(), Contract.describe(report));
    }

    @Test
    void createValid() throws Exception {
        String body = "{\"payer\":\"dev.team\",\"amountMinor\":150000,\"currency\":\"RUB\"}";
        MvcResult r = mvc.perform(post("/payments").contentType(MediaType.APPLICATION_JSON).content(body)).andReturn();
        verdict("POST /payments (верный запрос), статус " + r.getResponse().getStatus(), Contract.check(Request.Method.POST, "/payments", body, r));
    }

    @Test
    void createInvalid() throws Exception {
        String body = "{\"payer\":\"dev.team\",\"amountMinor\":0,\"currency\":\"RUB\"}";
        MvcResult r = mvc.perform(post("/payments").contentType(MediaType.APPLICATION_JSON).content(body)).andReturn();
        System.out.println("  POST /payments с суммой 0 вернул статус " + r.getResponse().getStatus() + " (" + r.getResponse().getContentType() + ")");
        // запрос сам нарушает контракт (minimum: 1), поэтому проверяем только ответ: он должен быть Problem
        var response = com.atlassian.oai.validator.model.SimpleResponse.Builder.status(r.getResponse().getStatus())
                .withContentType(r.getResponse().getContentType()).withBody(r.getResponse().getContentAsString(java.nio.charset.StandardCharsets.UTF_8)).build();
        ValidationReport report = Contract.VALIDATOR.validateResponse("/payments", Request.Method.POST, response);
        verdict("ответ на запрос с суммой 0", report);
    }

    @Test
    void getMissing() throws Exception {
        String path = "/payments/" + UUID.randomUUID();
        MvcResult r = mvc.perform(get(path)).andReturn();
        verdict("GET несуществующего платежа, статус " + r.getResponse().getStatus(), Contract.check(Request.Method.GET, path, null, r));
    }
}
