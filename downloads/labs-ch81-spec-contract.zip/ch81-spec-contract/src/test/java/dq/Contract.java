package dq;

import com.atlassian.oai.validator.OpenApiInteractionValidator;
import com.atlassian.oai.validator.model.Request;
import com.atlassian.oai.validator.model.SimpleRequest;
import com.atlassian.oai.validator.model.SimpleResponse;
import com.atlassian.oai.validator.report.ValidationReport;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MvcResult;

import java.nio.charset.StandardCharsets;

/** Сверка запроса и ответа с openapi/payments.yaml: спецификация лежит в репозитории и служит единственным источником контракта. */
final class Contract {

    static final OpenApiInteractionValidator VALIDATOR = OpenApiInteractionValidator.createFor("openapi/payments.yaml").build();

    private Contract() { }

    static ValidationReport check(Request.Method method, String path, String requestBody, MvcResult result) throws Exception {
        SimpleRequest.Builder request = new SimpleRequest.Builder(method, path);
        if (requestBody != null) request.withContentType("application/json").withBody(requestBody);
        MockHttpServletResponse raw = result.getResponse();
        SimpleResponse.Builder response = SimpleResponse.Builder.status(raw.getStatus());
        if (raw.getContentType() != null) response.withContentType(raw.getContentType());
        response.withBody(raw.getContentAsString(StandardCharsets.UTF_8));
        return VALIDATOR.validate(request.build(), response.build());
    }

    static String describe(ValidationReport report) {
        StringBuilder sb = new StringBuilder();
        report.getMessages().forEach(m -> sb.append("    ").append(m.getKey()).append(": ").append(m.getMessage().replace('\n', ' ')).append('\n'));
        return sb.toString();
    }
}
