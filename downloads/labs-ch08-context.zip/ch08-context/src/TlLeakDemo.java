import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.LinkedBlockingQueue;

public class TlLeakDemo {

    record Tenant(String name) {}

    /** Безопасная форма: контекст ставится на время тела и возвращается в прежнее состояние в finally. */
    static final class RequestContext {
        private static final ThreadLocal<Tenant> TENANT = new ThreadLocal<>();

        static void run(Tenant t, Runnable body) {
            Tenant previous = TENANT.get();
            TENANT.set(t);
            try { body.run(); }
            finally {
                if (previous == null) TENANT.remove();
                else TENANT.set(previous);
            }
        }
        static Tenant current() { return TENANT.get(); }
        static void set(Tenant t) { TENANT.set(t); }       // «небезопасный» вариант без remove
    }

    static void sequential(String title, ExecutorService pool, Runnable first, Runnable second) throws Exception {
        System.out.println("--- " + title);
        pool.submit(first).get();
        pool.submit(second).get();
        pool.shutdown();
    }

    public static void main(String[] args) throws Exception {
        Runnable readsContext = () -> System.out.println("запрос 2 видит: " + RequestContext.current());

        // 1. утечка: set без remove, поток пула переиспользуется
        sequential("1. set без remove() в пуле из одного потока", Executors.newFixedThreadPool(1),
                () -> RequestContext.set(new Tenant("клиент А")), readsContext);

        // 2. безопасная форма
        sequential("2. RequestContext.run: set и remove в finally", Executors.newFixedThreadPool(1),
                () -> RequestContext.run(new Tenant("клиент А"), () -> { }), readsContext);

        // 3. страховка: beforeExecute очищает контекст перед каждой задачей чужого кода
        ThreadPoolExecutor safe = new ThreadPoolExecutor(1, 1, 0, TimeUnit.SECONDS, new LinkedBlockingQueue<>()) {
            @Override protected void beforeExecute(Thread t, Runnable r) {
                RequestContext.TENANT.remove();            // чистим поток до чужой задачи
            }
        };
        sequential("3. страховка в beforeExecute (чужой код не вызвал remove)", safe,
                () -> RequestContext.set(new Tenant("клиент А")), readsContext);
    }
}
