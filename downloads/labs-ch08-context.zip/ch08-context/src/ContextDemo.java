import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * JDK 25 (--enable-preview для StructuredTaskScope):
 * 1) InheritableThreadLocal в пуле: значение от того, кто создал поток, а не от того, кто отправил задачу;
 * 2) виртуальный поток наследует InheritableThreadLocal отправителя;
 * 3) ScopedValue виден в подзадачах StructuredTaskScope и не виден в задаче обычного пула;
 * 4) 10 000 задач по 100 мс: пул из 200 платформенных потоков и поток на задачу;
 * 5) семафор ограничивает число одновременных вызовов на виртуальных потоках.
 */
public class ContextDemo {
    static final InheritableThreadLocal<String> CLIENT = new InheritableThreadLocal<>();
    static final ScopedValue<String> REQUEST_CLIENT = ScopedValue.newInstance();

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version"));

        CLIENT.set("клиент при старте");
        ExecutorService pool = Executors.newFixedThreadPool(1);
        pool.submit(() -> { }).get();                       // поток пула создан здесь и унаследовал значение
        CLIENT.set("клиент А");
        System.out.println("1. ITL в пуле, отправитель клиент А, задача видит: " + pool.submit(CLIENT::get).get());
        CLIENT.set("клиент Б");
        System.out.println("1. ITL в пуле, отправитель клиент Б, задача видит: " + pool.submit(CLIENT::get).get());
        try (ExecutorService vt = Executors.newVirtualThreadPerTaskExecutor()) {
            System.out.println("2. ITL, виртуальный поток на задачу, отправитель клиент Б: " + vt.submit(CLIENT::get).get());
        }
        CLIENT.remove();

        ScopedValue.where(REQUEST_CLIENT, "клиент В").run(() -> {
            try (var scope = StructuredTaskScope.open()) {
                var a = scope.fork(() -> REQUEST_CLIENT.isBound() ? REQUEST_CLIENT.get() : "не привязан");
                scope.join();
                System.out.println("3. ScopedValue в подзадаче StructuredTaskScope: " + a.get());
            } catch (Exception e) { throw new RuntimeException(e); }
            try {
                System.out.println("3. ScopedValue в задаче обычного пула: "
                        + pool.submit(() -> REQUEST_CLIENT.isBound() ? REQUEST_CLIENT.get() : "не привязан").get());
            } catch (Exception e) { throw new RuntimeException(e); }
        });
        pool.shutdown();

        long t0 = System.nanoTime();
        try (ExecutorService p = Executors.newFixedThreadPool(200)) {
            for (int i = 0; i < 10_000; i++) p.submit(() -> { Thread.sleep(100); return null; });
        }
        System.out.printf("4. 10 000 задач по 100 мс, пул из 200 платформенных потоков: %d мс%n", (System.nanoTime() - t0) / 1_000_000);
        t0 = System.nanoTime();
        try (ExecutorService p = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < 10_000; i++) p.submit(() -> { Thread.sleep(100); return null; });
        }
        System.out.printf("4. 10 000 задач по 100 мс, виртуальный поток на задачу: %d мс%n", (System.nanoTime() - t0) / 1_000_000);

        Semaphore permits = new Semaphore(50);
        AtomicInteger inFlight = new AtomicInteger(), maxInFlight = new AtomicInteger();
        t0 = System.nanoTime();
        try (ExecutorService p = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < 1_000; i++) p.submit(() -> {
                permits.acquire();
                try {
                    maxInFlight.accumulateAndGet(inFlight.incrementAndGet(), Math::max);
                    Thread.sleep(100);
                    inFlight.decrementAndGet();
                } finally { permits.release(); }
                return null;
            });
        }
        System.out.printf("5. 1000 вызовов через Semaphore(50) на виртуальных потоках: %d мс, одновременно не больше %d%n",
                (System.nanoTime() - t0) / 1_000_000, maxInFlight.get());
    }
}
