# Контекст запроса: ThreadLocal в пуле, InheritableThreadLocal, ScopedValue и виртуальные потоки

Стенд к главе 08, раздел 10. `TlLeakDemo` обслуживает два запроса подряд пулом из одного потока, как Tomcat двух клиентов: первый кладет клиента в `ThreadLocal` и не вызывает `remove()`, второй его видит. `ContextDemo` на JDK 25 сравнивает `InheritableThreadLocal` и `ScopedValue` в пуле из 200 платформенных потоков и с виртуальным потоком на задачу: 10 000 задач по 100 мс, семафор на 50 разрешений. Вывод автора - `s10-context.txt`.

## Что нужно

- JDK 21 для `TlLeakDemo`, JDK 25 для `ContextDemo` (`ScopedValue` там еще preview).

## Запуск

```bash
java -Dstdout.encoding=UTF-8 src/TlLeakDemo.java
```

```bash
java --enable-preview --source 25 -Dstdout.encoding=UTF-8 src/ContextDemo.java
```

В IDEA на каждую программу есть конфигурация `java src/<Класс>.java`; для `ContextDemo` добавьте в нее `--enable-preview --source 25`.

## Что должно получиться

`запрос 2 видит: Tenant[name=клиент А]` в первом блоке - это утечка контекста между запросами. Времена во втором опыте зависят от машины; у автора 10 000 задач по 100 мс заняли 5043 мс в пуле из 200 потоков и 120 мс на виртуальных потоках, а 1000 вызовов через `Semaphore(50)` - 2025 мс.
