package dev.team.wt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

/** Сервис курсов валют: печатает, какой тип приложения выбрал Boot и какой сервер поднялся. */
@SpringBootApplication
public class RatesApp {
    public static void main(String[] args) throws Exception {
        SpringApplication app = new SpringApplication(RatesApp.class);
        ConfigurableApplicationContext ctx = app.run(args);
        String server = "нет";
        try {
            Object ws = ctx.getClass().getMethod("getWebServer").invoke(ctx);
            server = ws.getClass().getSimpleName();
        } catch (NoSuchMethodException ignored) { }
        boolean webClient = isPresent("org.springframework.web.reactive.function.client.WebClient");
        System.out.println("   тип: " + app.getWebApplicationType() + "; контекст: " + ctx.getClass().getSimpleName()
                + "; сервер: " + server + "; WebClient в classpath: " + webClient
                + (webClient ? ", бин WebClient.Builder: " + ctx.getBeanNamesForType(loadClass("org.springframework.web.reactive.function.client.WebClient$Builder")).length : ""));
        ctx.close();
    }

    static boolean isPresent(String c) { try { Class.forName(c); return true; } catch (ClassNotFoundException e) { return false; } }
    static Class<?> loadClass(String c) { try { return Class.forName(c); } catch (ClassNotFoundException e) { throw new IllegalStateException(e); } }
}
