# Какой тип веб-приложения выбирает Spring Boot при разных стартерах: MVC, WebFlux, оба, WebClient

Стенд к главам 10 и 14. `RatesApp` (сервис курсов, Spring Boot 4.1.1) собирается в четырех профилях Maven с разным набором стартеров - `mvc`, `flux`, `both` (webmvc и webflux вместе), `both-wc` (webmvc и webclient) - и печатает тип приложения (`SERVLET` или `REACTIVE`), класс контекста, класс встроенного сервера и есть ли `WebClient` в classpath. Вывод автора - `s10-webtype.txt`; файлы `cp-*.txt` - classpath каждого профиля.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q -P flux compile exec:java -Dexec.mainClass=dev.team.wt.RatesApp
```

и так для каждого профиля. В IDEA есть конфигурация `RatesApp`, профиль выбирается в окне Maven.

## Что должно получиться

`mvc` и `both` дают `SERVLET` с Tomcat (при обоих стартерах Boot предпочитает сервлетный стек), `flux` - `REACTIVE` с Netty; `WebClient` появляется в classpath только с `webflux` или `webclient`.
