package dev.team.ch06;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/** Сервис статусов платежей: минимальное веб-приложение для замеров старта. */
@SpringBootApplication
@RestController
public class StatusService {
    private final Map<String, String> statuses = new ConcurrentHashMap<>(Map.of("p-1", "ACCEPTED"));

    @GetMapping("/payments/{id}/status")
    public Map<String, String> status(@PathVariable String id) {
        return Map.of("id", id, "status", statuses.getOrDefault(id, "UNKNOWN"));
    }

    public static void main(String[] args) {
        SpringApplication.run(StatusService.class, args);
    }
}
