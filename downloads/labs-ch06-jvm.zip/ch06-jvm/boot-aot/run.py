"""Гл. 06, разд. 8: время старта Spring Boot 4.1.1 без архива, с AppCDS (JDK 21) и с AOT-кэшем (JDK 25).

Сначала: mvn -q package -DskipTests (JAVA_HOME = JDK 21), затем python -X utf8 run.py.
Каждый замер - время процесса, который поднимает контекст и выходит (-Dspring.context.exit=onRefresh),
медиана из 5 запусков; доля классов из архива - по -Xlog:class+load отдельным запуском.
"""
import os, statistics, subprocess, time, datetime, shutil

HOME = os.path.expanduser('~')
J21 = os.path.join(HOME, '.jdks', 'temurin-21.0.10', 'bin', 'java')
J25 = os.path.join(HOME, '.jdks', 'jdk-25.0.5+8', 'bin', 'java')
ROOT = os.path.dirname(os.path.abspath(__file__))
T = os.path.join(ROOT, 'target')
FAT = os.path.join(T, 'status-service.jar')
EXT = os.path.join(T, 'extracted')
APP = os.path.join(EXT, 'status-service.jar')
COMMON = ['-Dspring.context.exit=onRefresh', '-Dserver.port=0', '-Dspring.main.banner-mode=off',
          '-Dlogging.level.root=WARN']


def run(java, flags, jar, log=None):
    cmd = [java, *flags, *COMMON]
    if log:
        cmd.insert(1, '-Xlog:class+load=info:file=' + log)
    cmd += ['-jar', jar]
    t0 = time.perf_counter()
    p = subprocess.run(cmd, capture_output=True, cwd=T)
    ms = (time.perf_counter() - t0) * 1000
    if p.returncode != 0:
        print(p.stdout.decode('utf-8', 'replace')[-2000:], p.stderr.decode('utf-8', 'replace')[-2000:])
    return ms


def measure(title, java, flags, jar):
    times = [run(java, flags, jar) for _ in range(5)]
    log = os.path.join(T, 'cl.log')
    run(java, flags, jar, log)
    lines = open(log, encoding='utf-8', errors='replace').read().splitlines()
    shared = sum(1 for l in lines if 'shared objects file' in l)
    os.remove(log)
    s = '%-62s %6.0f мс (медиана из 5), классов %5d, из архива %5d' % (title, statistics.median(times), len(lines), shared)
    print(s)
    return s


def main():
    if not os.path.isdir(EXT):
        subprocess.run([J21, '-Djarmode=tools', '-jar', FAT, 'extract', '--destination', EXT], check=True)
    out = ['# Запуск %s: labs/ch06-jvm/boot-aot, Spring Boot 4.1.1, spring-boot-starter-webmvc + actuator' % datetime.date.today(),
           '# Время процесса от запуска java до выхода после подъема контекста (spring.context.exit=onRefresh)']
    for f in ['app.jsa', 'app.aot', 'fat.aot']:
        if os.path.exists(os.path.join(T, f)):
            os.remove(os.path.join(T, f))
    out.append('## Temurin JDK 21.0.10')
    out.append(measure('fat jar (java -jar status-service.jar)', J21, [], FAT))
    out.append(measure('распакованный jar, CDS JDK по умолчанию', J21, [], APP))
    out.append(measure('распакованный jar, -Xshare:off', J21, ['-Xshare:off'], APP))
    run(J21, ['-XX:ArchiveClassesAtExit=app.jsa'], APP)
    out.append(measure('распакованный jar, AppCDS -XX:SharedArchiveFile=app.jsa', J21, ['-XX:SharedArchiveFile=app.jsa'], APP))
    out.append('## Temurin JDK 25.0.5')
    out.append(measure('распакованный jar, CDS JDK по умолчанию', J25, [], APP))
    out.append(measure('распакованный jar, -Xshare:off', J25, ['-Xshare:off'], APP))
    t0 = time.perf_counter()
    run(J25, ['-XX:AOTCacheOutput=app.aot'], APP)
    out.append('тренировочный запуск с -XX:AOTCacheOutput=app.aot: %.0f мс, размер кэша %.1f МБ' %
               ((time.perf_counter() - t0) * 1000, os.path.getsize(os.path.join(T, 'app.aot')) / 2**20))
    print(out[-1])
    out.append(measure('распакованный jar, -XX:AOTCache=app.aot', J25, ['-XX:AOTCache=app.aot'], APP))
    run(J25, ['-XX:AOTCacheOutput=fat.aot'], FAT)
    out.append(measure('fat jar, -XX:AOTCache=fat.aot', J25, ['-XX:AOTCache=fat.aot'], FAT))
    open(os.path.join(os.path.dirname(ROOT), 's8-boot-startup.txt'), 'w', encoding='utf-8', newline='\n').write('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
