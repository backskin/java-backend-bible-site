// MODE: exec JavacLimits
// OUT: s1-javac-limits
// Предел 65535 байт байткода на метод: статический массив тарифов из N констант, собранный javac
// из сгенерированного исходника; и кэш Integer.valueOf, который расширяет -XX:AutoBoxCacheMax.
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class JavacLimits {
    public static class Box {
        public static void main(String[] a) {
            Integer x = 1000, y = 1000, s1 = 100, s2 = 100;
            System.out.println("Integer 100 == 100: " + (s1 == s2) + ", Integer 1000 == 1000: " + (x == y));
        }
    }

    public static void main(String[] args) throws Exception {
        JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
        Path dir = Files.createTempDirectory("tariffs");
        for (int n : new int[] {5_000, 8_000, 10_000}) {
            StringBuilder src = new StringBuilder("public class Tariffs { static final long[] RATES = {");
            for (int i = 0; i < n; i++) src.append(i == 0 ? "" : ",").append(100_000L + i).append('L');
            src.append("}; }");
            Path file = dir.resolve("Tariffs.java");
            Files.writeString(file, src);
            ByteArrayOutputStream err = new ByteArrayOutputStream();
            int rc = javac.run(null, null, err, "-d", dir.toString(), file.toString());
            String msg = err.toString().lines().filter(l -> l.contains("error")).findFirst().orElse("");
            System.out.println("массив из " + n + " констант: javac код " + rc
                    + (msg.isEmpty() ? "" : ", " + msg.replaceAll(".*Tariffs.java:\\d+: ", "")));
            if (rc == 0) {
                ProcessBuilder pb = new ProcessBuilder(Path.of(System.getProperty("java.home"), "bin", "javap").toString(),
                        "-c", "-p", "-cp", dir.toString(), "Tariffs").redirectErrorStream(true);
                List<String> code = new String(pb.start().getInputStream().readAllBytes()).lines()
                        .filter(l -> l.matches("\\s+\\d+: \\w+.*")).toList();
                System.out.println("   <clinit>: последняя инструкция " + code.get(code.size() - 1).trim());
            }
        }
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        for (List<String> flags : List.of(List.<String>of(), List.of("-XX:AutoBoxCacheMax=20000"))) {
            List<String> cmd = new java.util.ArrayList<>(List.of(java));
            cmd.addAll(flags);
            cmd.addAll(List.of("-cp", System.getProperty("java.class.path"), "JavacLimits$Box"));
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            System.out.println((flags.isEmpty() ? "по умолчанию" : String.join(" ", flags)) + ": "
                    + new String(p.getInputStream().readAllBytes()).trim());
            p.waitFor();
        }
    }
}
