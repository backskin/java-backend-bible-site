// MODE: javap Feat Feat$1
// JAVAP: -c -p -v
// OUT: s1-feat-javap
// Восемь конструкций языка и байткод, который за ними стоит.
import java.util.List;
import java.util.function.Supplier;

public class Feat {
    enum Channel { CARD, SBP, CASH }

    static String concat(String account, int amount) { return "acc=" + account + ":" + amount; }

    static Supplier<String> lam(String s) { return () -> s.toUpperCase(); }

    static int sum(List<Integer> xs) { int t = 0; for (int x : xs) t += x; return t; }

    static Integer box(int i) { return i; }

    static void twr(java.io.Closeable c) throws Exception { try (var r = c) { r.toString(); } }

    static int sw(String s) { return switch (s) { case "a" -> 1; case "b" -> 2; default -> 0; }; }

    static int cutoff(java.time.DayOfWeek d) { return switch (d) { case SATURDAY, SUNDAY -> 0; default -> 1; }; }

    static int fee(Channel ch) { return switch (ch) { case CARD -> 15; case SBP -> 0; case CASH -> 30; }; }
}
