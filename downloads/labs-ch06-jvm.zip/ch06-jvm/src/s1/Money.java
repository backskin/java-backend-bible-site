// MODE: javap Money
// JAVAP: -c -p -v
// OUT: s1-money-javap
// Сумма в копейках: что javac кладет в class-файл (заголовок, пул констант, атрибут Code).
public final class Money {
    private final long minor;

    public Money(long minor) {
        this.minor = minor;
    }

    public Money plus(Money other) {
        long sum = Math.addExact(this.minor, other.minor);
        return new Money(sum);
    }
}
