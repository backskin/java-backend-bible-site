// MODE: javap Invoke$Payment
// GREP: invoke|static|public|private|final|void
// OUT: s1-invoke-javap
// Какие инструкции вызова javac выбирает для разных видов методов.
import java.util.HashMap;
import java.util.Map;

public class Invoke {
    static class Base { void audit() { } }

    static class Payment extends Base {
        private void validate() { }
        public final void post() { }
        @Override void audit() { super.audit(); }

        void process(Map<String, Long> m, HashMap<String, Long> hm) {
            validate();                       // private
            post();                           // final
            audit();                          // обычный виртуальный
            m.put("acc", 1L);                 // через интерфейс
            hm.put("acc", 1L);                // через класс
            Math.max(1, 2);                   // статический
            new Payment();                    // конструктор
        }
    }
}
