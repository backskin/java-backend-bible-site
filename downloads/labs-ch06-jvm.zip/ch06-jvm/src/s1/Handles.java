// MODE: exec Handles
// OUT: s1-handles
// MethodHandle и MethodType, связывание invokedynamic вручную (CallSite), VarHandle,
// скорость вызова через рефлексию и через дескриптор метода в static final и в обычном поле,
// и что из этого встраивает C2 (дочерняя JVM с PrintInlining).
import java.lang.invoke.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

public class Handles {
    static final class Account {
        volatile long balance;
        long fee(long amountMinor) { return amountMinor * 15 / 1000; }
    }

    static final MethodHandle FEE_CONST;      // static final: для C2 константа
    static MethodHandle feeField;             // обычное статическое поле: не константа
    static final Method FEE_REFLECT;
    static final VarHandle BALANCE;

    static {
        try {
            MethodHandles.Lookup lk = MethodHandles.lookup();
            FEE_CONST = lk.findVirtual(Account.class, "fee", MethodType.methodType(long.class, long.class));
            feeField = FEE_CONST;
            FEE_REFLECT = Account.class.getDeclaredMethod("fee", long.class);
            BALANCE = lk.findVarHandle(Account.class, "balance", long.class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    static String currency() { return "RUB"; }
    static long cardFee(long a) { return a * 15 / 1000; }
    static long sbpFee(long a) { return a / 250; }

    static long direct(Account a, int n) { long s = 0; for (int i = 0; i < n; i++) s += a.fee(i); return s; }
    static long constMh(Account a, int n) throws Throwable {
        long s = 0; for (int i = 0; i < n; i++) s += (long) FEE_CONST.invokeExact(a, (long) i); return s;
    }
    static long fieldMh(Account a, int n) throws Throwable {
        long s = 0; for (int i = 0; i < n; i++) s += (long) feeField.invokeExact(a, (long) i); return s;
    }
    static long reflect(Account a, int n) throws Exception {
        long s = 0; for (int i = 0; i < n; i++) s += (Long) FEE_REFLECT.invoke(a, (long) i); return s;
    }

    interface Body { long run(Account a, int n) throws Throwable; }

    static double best(Body b, Account a) throws Throwable {
        int n = 5_000_000;
        double best = Double.MAX_VALUE;
        long sink = 0;
        for (int r = 0; r < 12; r++) {
            long t0 = System.nanoTime();
            sink += b.run(a, n);
            best = Math.min(best, (System.nanoTime() - t0) / (double) n);
        }
        if (sink == 42) System.out.println();
        return best;
    }

    /** Дочерняя JVM: только прогрев, чтобы увидеть решения C2 о встраивании. */
    public static class Warm {
        public static void main(String[] x) throws Throwable {
            Account a = new Account();
            long s = 0;
            for (int r = 0; r < 20; r++) { s += constMh(a, 200_000); s += fieldMh(a, 200_000); }
            System.out.println("-- " + s);
        }
    }

    public static void main(String[] args) throws Throwable {
        Account acc = new Account();
        MethodHandles.Lookup lk = MethodHandles.lookup();

        System.out.println("-- MethodType дескриптора fee: " + FEE_CONST.type());
        System.out.println("-- invokeExact(acc, 150000L): " + (long) FEE_CONST.invokeExact(acc, 150_000L));
        try {
            long r = (long) FEE_CONST.invokeExact(acc, 150_000);            // int вместо long
            System.out.println(r);
        } catch (WrongMethodTypeException e) {
            System.out.println("-- invokeExact(acc, 150000) с int: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        System.out.println("-- invoke(acc, 150000) с int: " + (long) FEE_CONST.invoke(acc, 150_000));
        try {
            MethodHandles.publicLookup().findVirtual(Account.class, "fee", MethodType.methodType(long.class, long.class));
        } catch (IllegalAccessException e) {
            System.out.println("-- publicLookup().findVirtual: " + e.getClass().getSimpleName());
        }

        CallSite lambda = LambdaMetafactory.metafactory(lk, "get", MethodType.methodType(Supplier.class),
                MethodType.methodType(Object.class),
                lk.findStatic(Handles.class, "currency", MethodType.methodType(String.class)),
                MethodType.methodType(String.class));
        @SuppressWarnings("unchecked")
        Supplier<String> sup = (Supplier<String>) lambda.getTarget().invoke();
        System.out.println("-- LambdaMetafactory.metafactory вернул " + lambda.getClass().getSimpleName()
                + ", get() = " + sup.get() + ", класс " + sup.getClass().getName().replaceAll("0x[0-9a-f]+", "0x..."));
        CallSite concat = StringConcatFactory.makeConcatWithConstants(lk, "concat",
                MethodType.methodType(String.class, String.class, long.class), "acc=\u0001:\u0001");
        System.out.println("-- StringConcatFactory вернул " + concat.getClass().getSimpleName()
                + ", результат " + (String) concat.getTarget().invokeExact("40702810", 150_000L));

        MutableCallSite route = new MutableCallSite(MethodType.methodType(long.class, long.class));
        MethodHandle viaRoute = route.dynamicInvoker();
        route.setTarget(lk.findStatic(Handles.class, "cardFee", MethodType.methodType(long.class, long.class)));
        System.out.println("-- MutableCallSite -> cardFee: " + (long) viaRoute.invokeExact(150_000L));
        route.setTarget(lk.findStatic(Handles.class, "sbpFee", MethodType.methodType(long.class, long.class)));
        System.out.println("-- MutableCallSite -> sbpFee: " + (long) viaRoute.invokeExact(150_000L));

        System.out.println("-- VarHandle.compareAndSet(0 -> 500): " + BALANCE.compareAndSet(acc, 0L, 500L));
        System.out.println("-- VarHandle.compareAndSet(0 -> 700): " + BALANCE.compareAndSet(acc, 0L, 700L)
                + ", balance = " + acc.balance);
        for (Class<?> c : List.of(AtomicInteger.class, AtomicLong.class, AtomicReference.class)) {
            StringBuilder sb = new StringBuilder();
            for (Field f : c.getDeclaredFields())
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers()) && f.getType() != long.class)
                    sb.append(f.getType().getSimpleName()).append(' ');
            System.out.println("-- статические поля " + c.getSimpleName() + ": " + sb.toString().trim());
        }

        System.out.printf("-- прямой вызов:                %.2f нс%n", best(Handles::direct, acc));
        System.out.printf("-- MethodHandle в static final: %.2f нс%n", best(Handles::constMh, acc));
        System.out.printf("-- MethodHandle в обычном поле: %.2f нс%n", best(Handles::fieldMh, acc));
        System.out.printf("-- Method.invoke (рефлексия):   %.2f нс%n", best(Handles::reflect, acc));

        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        List<String> cmd = new ArrayList<>(List.of(java, "-XX:+UnlockDiagnosticVMOptions",
                "-XX:CompileCommand=quiet", "-XX:CompileCommand=PrintInlining,Handles::constMh",
                "-XX:CompileCommand=PrintInlining,Handles::fieldMh", "-XX:-BackgroundCompilation",
                "-cp", System.getProperty("java.class.path"), "Handles$Warm"));
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        for (String l : new String(p.getInputStream().readAllBytes(), "UTF-8").lines().toList())
            if (l.contains("Handles") || l.contains("invokeBasic") || l.contains("linkTo") || l.contains("Invokers"))
                System.out.println("   " + l.replaceAll("0x[0-9a-f]+", "0x...").stripTrailing());
        p.waitFor();
    }
}
