// MODE: exec LambdaRuntime
// OUT: s1-lambda-runtime
// Что лямбда представляет собой во время выполнения: скрытый класс, один экземпляр без захвата, новый с захватом.
import java.util.function.Supplier;

public class LambdaRuntime {
    static Supplier<String> noCapture() { return () -> "RUB"; }

    static Supplier<String> capture(String currency) { return () -> currency; }

    static Runnable printer() { return System.out::println; }

    public static void main(String[] args) {
        Supplier<String> a = noCapture(), b = noCapture();
        Supplier<String> c = capture("RUB"), d = capture("RUB");
        System.out.println("класс лямбды: " + a.getClass().getName());
        System.out.println("isHidden: " + a.getClass().isHidden() + ", isSynthetic: " + a.getClass().isSynthetic());
        System.out.println("загрузчик лямбды тот же, что у класса: " + (a.getClass().getClassLoader() == LambdaRuntime.class.getClassLoader()));
        System.out.println("без захвата, два вызова, один объект: " + (a == b));
        System.out.println("с захватом, два вызова, один объект: " + (c == d));
        System.out.println("System.out::println, один объект: " + (printer() == printer()));
        try {
            Class.forName(a.getClass().getName());
        } catch (ClassNotFoundException e) {
            System.out.println("Class.forName по имени лямбды: ClassNotFoundException");
        }
    }
}
