// MODE: javap Attrs Attrs$Status Attrs$Transfer
// JAVAP: -v -p
// GREP: ^(Record|PermittedSubclasses|NestHost|NestMembers|BootstrapMethods|InnerClasses|SourceFile)|= (MethodHandle|MethodType|InvokeDynamic|Dynamic) |major version|^\s+\d+: #\d+ REF_
// OUT: s1-attrs
// Атрибуты class-файла, через которые расширяется формат: записи, запечатанные типы, гнёзда, методы начальной загрузки.
public class Attrs {
    sealed interface Status permits Ok, Fail { }
    record Ok(long amountMinor) implements Status { }
    record Fail(String reason) implements Status { }

    record Transfer(String from, String to, long amountMinor) { }

    static String describe(Status s) {
        return switch (s) {
            case Ok ok -> "ok " + ok.amountMinor();
            case Fail f -> "fail " + f.reason();
        };
    }
}
