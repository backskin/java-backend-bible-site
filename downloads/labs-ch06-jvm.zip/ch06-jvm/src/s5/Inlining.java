// MODE: exec Inlining
// JAVA: -XX:+UnlockDiagnosticVMOptions -XX:+PrintInlining -XX:CompileCommand=quiet -XX:-BackgroundCompilation
// GREP: Inlining\$|Inlining::|^--
// OUT: s5-inlining
// Решения C2 о встраивании: маленький метод, большой горячий метод, вызов через интерфейс с 1, 2 и 4 реализациями.
public class Inlining {
    interface FeeRule { long fee(long amountMinor); }
    static final class CardFee  implements FeeRule { public long fee(long a) { return a * 15 / 1000; } }
    static final class SbpFee   implements FeeRule { public long fee(long a) { return 0; } }
    static final class CashFee  implements FeeRule { public long fee(long a) { return 3000; } }
    static final class PromoFee implements FeeRule { public long fee(long a) { return a / 200; } }

    static long round(long minor) { return (minor + 50) / 100 * 100; }          // маленький

    static long describe(long minor) {                                          // большой: > 325 байт байткода
        String s = "сумма " + minor / 100 + "," + minor % 100 + " руб.";
        if (minor > 1_000_000) s = s + " крупная";
        if (minor % 7 == 0) s = s.toUpperCase();
        if (minor % 11 == 0) s = s.replace(' ', '_');
        if (minor % 13 == 0) s = s.trim().strip();
        if (minor % 17 == 0) s = String.join("|", s, s);
        if (minor % 19 == 0) s = s.substring(1) + s.charAt(0);
        if (minor % 23 == 0) s = s.repeat(2);
        if (minor % 29 == 0) s = s.toLowerCase();
        if (minor % 31 == 0) s = s.concat("!");
        if (minor % 37 == 0) s = s.intern();
        if (minor % 41 == 0) s = s.isBlank() ? "-" : s;
        if (minor % 43 == 0) s = s + s.length();
        if (minor % 47 == 0) s = s.indent(1);
        if (minor % 53 == 0) s = s.replace("руб", "RUB");
        if (minor % 59 == 0) s = s.toUpperCase().trim();
        if (minor % 61 == 0) s = String.valueOf(s.hashCode());
        if (minor % 67 == 0) s = s + "/" + s.length() + "/" + minor;
        return s.length();
    }

    static long total(FeeRule r, long[] amounts) {
        long sum = 0;
        for (long a : amounts) sum += round(r.fee(a)) + describe(a);
        return sum;
    }

    public static void main(String[] args) throws Exception {
        long[] amounts = new long[256];
        for (int i = 0; i < amounts.length; i++) amounts[i] = 10_000 + i * 997L;
        FeeRule[][] phases = {
                { new CardFee() },
                { new CardFee(), new SbpFee() },
                { new CardFee(), new SbpFee(), new CashFee(), new PromoFee() } };
        long acc = 0;
        for (FeeRule[] rules : phases) {
            System.out.println("-- реализаций в точке вызова: " + rules.length);
            for (int i = 0; i < 20_000; i++) acc += total(rules[i % rules.length], amounts);
            Thread.sleep(200);
        }
        System.out.println("-- " + acc);
    }
}
