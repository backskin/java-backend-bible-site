// MODE: exec Escape
// OUT: s5-escape
// Сколько байт кучи выделяет одна итерация при разных условиях escape analysis (массивы - в jmh/EscapeArray).
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Escape {
    record Money(long minor) {
        Money plus(Money o) { return new Money(Math.addExact(minor, o.minor)); }
    }

    static Money sink;

    static long noEscape(long a, long b) {                       // объекты не покидают метод
        return new Money(a).plus(new Money(b)).minor();
    }

    static long merge(long a, long b, boolean card) {             // два new сливаются в одну переменную
        Money m = card ? new Money(a) : new Money(b);
        return m.minor() + 1;
    }

    static long mergeOneNew(long a, long b, boolean card) {       // один new после выбора значения
        Money m = new Money(card ? a : b);
        return m.minor() + 1;
    }

    static long rareEscape(long a, long b) {                      // объект убегает только по редкой ветке
        Money m = new Money(a + b);
        if (a == -1) sink = m;
        return m.minor();
    }

    static long array(int n, long a) {                            // массив из n элементов, заняты два
        long[] buf = new long[n];
        buf[0] = a; buf[1] = a + 1;
        return buf[0] + buf[1];
    }

    interface Case { long run(long i); }

    static void measure(String name, Case c) {
        var bean = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
        long r = 0;
        for (long i = 0; i < 2_000_000; i++) r += c.run(i);       // прогрев до C2
        long id = Thread.currentThread().threadId();
        long before = bean.getThreadAllocatedBytes(id);
        for (long i = 0; i < 1_000_000; i++) r += c.run(i);
        long bytes = bean.getThreadAllocatedBytes(id) - before;
        System.out.printf("%-48s %6.1f байт на итерацию (%d)%n", name, bytes / 1_000_000.0, r % 10);
    }

    public static class Child {
        public static void main(String[] args) {
            measure("noEscape: два new + plus", i -> noEscape(i, 7));
            measure("merge: card ? new Money(a) : new Money(b)", i -> merge(i, 7, (i & 1) == 0));
            measure("mergeOneNew: new Money(card ? a : b)", i -> mergeOneNew(i, 7, (i & 1) == 0));
            measure("rareEscape: ветка ни разу не исполнялась", i -> rareEscape(i, 7));
        }
    }

    public static void main(String[] args) throws Exception {
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String[][] modes = { {}, {"-XX:-DoEscapeAnalysis"}, {"-XX:CompileCommand=quiet", "-XX:CompileCommand=dontinline,Escape$Money::plus"},
                {"-XX:EliminateAllocationArraySizeLimit=65"} };
        for (String[] m : modes) {
            List<String> cmd = new ArrayList<>(List.of(java, "-Dstdout.encoding=UTF-8"));
            cmd.addAll(List.of(m));
            cmd.addAll(List.of("-cp", System.getProperty("java.class.path"), "Escape$Child"));
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            p.waitFor();
            System.out.println("== " + (m.length == 0 ? "по умолчанию" : String.join(" ", m)));
            System.out.print(out);
        }
    }
}
