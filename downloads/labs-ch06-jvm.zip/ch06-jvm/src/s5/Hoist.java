// MODE: exec Hoist
// OUT: s5-hoist
// Цикл ожидания по полю без volatile: интерпретатор видит запись, C2 выносит чтение из цикла.
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

public class Hoist {
    public static class Plain {
        static boolean stop;
        public static void main(String[] a) throws Exception {
            Thread w = new Thread(() -> { long n = 0; while (!stop) n++; System.out.println("рабочий поток вышел, итераций " + (n > 0)); });
            w.setDaemon(true);
            w.start();
            Thread.sleep(1000);
            stop = true;
            w.join(2000);
            System.out.println("через 2 с после stop=true рабочий поток жив: " + w.isAlive());
        }
    }

    public static class Volatile {
        static volatile boolean stop;
        public static void main(String[] a) throws Exception {
            Thread w = new Thread(() -> { long n = 0; while (!stop) n++; System.out.println("рабочий поток вышел, итераций " + (n > 0)); });
            w.setDaemon(true);
            w.start();
            Thread.sleep(1000);
            stop = true;
            w.join(2000);
            System.out.println("через 2 с после stop=true рабочий поток жив: " + w.isAlive());
        }
    }

    static void run(String cls, String... flags) throws Exception {
        String bin = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        var cmd = new java.util.ArrayList<>(java.util.List.of(bin, "-Dstdout.encoding=UTF-8"));
        cmd.addAll(java.util.List.of(flags));
        cmd.addAll(java.util.List.of("-cp", System.getProperty("java.class.path"), "Hoist$" + cls));
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        p.waitFor();
        System.out.println("== " + cls + " " + String.join(" ", flags));
        System.out.print(out);
    }

    public static void main(String[] args) throws Exception {
        run("Plain");
        run("Plain", "-Xint");
        run("Plain", "-XX:TieredStopAtLevel=1");
        run("Volatile");
    }
}
