// MODE: exec Safepoint
// OUT: s6-safepoint
// Время до безопасной точки (TTSP): счётный цикл без вызовов в рабочем потоке и System.gc() в главном,
// при разных настройках опроса в счётных циклах; затем какие операции JVM идут через безопасную точку,
// а какие через рукопожатие с отдельным потоком.
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Safepoint {
    static final int[] DATA = new int[1024];
    static volatile long sink;
    static volatile long passes;

    /** Один проход: счётный цикл с int-счётчиком, без вызовов внутри. */
    static long pass() {
        long s = 0;
        for (int i = 0; i < 1_000_000_000; i++) s += DATA[i & 1023] ^ i;
        return s;
    }

    /** Дочерняя JVM: рабочий поток крутит pass(), главный трижды вызывает System.gc(). */
    public static class Ttsp {
        public static void main(String[] a) throws Exception {
            for (int i = 0; i < DATA.length; i++) DATA[i] = i * 31;
            Thread w = new Thread(() -> { while (true) { sink += pass(); passes++; } }, "ledger-worker");
            w.setDaemon(true);
            w.start();
            Thread.sleep(3000);                         // прогрев: pass() скомпилирован C2
            long p0 = passes, t0 = System.nanoTime();
            Thread.sleep(3000);
            double nsPerIter = (System.nanoTime() - t0) / ((passes - p0) * 1e9);
            System.out.printf("цикл: %.2f нс на итерацию%n", nsPerIter);
            for (int k = 0; k < 3; k++) {
                long g0 = System.nanoTime();
                System.gc();
                System.out.printf("System.gc() №%d занял %d мс%n", k + 1, (System.nanoTime() - g0) / 1_000_000);
                Thread.sleep(300);
            }
        }
    }

    interface Fee { long fee(long a); }
    static final class CardFee implements Fee { public long fee(long a) { return a * 15 / 1000; } }
    static final class SbpFee implements Fee { public long fee(long a) { return a / 250; } }
    static long total(Fee f, int n) { long s = 0; for (int i = 0; i < n; i++) s += f.fee(i); return s; }

    /** Дочерняя JVM: разные операции, которые требуют остановки потоков. */
    public static class Ops {
        public static void main(String[] a) throws Exception {
            Thread idle = new Thread(() -> { try { Thread.sleep(60_000); } catch (InterruptedException e) { } }, "idle");
            idle.setDaemon(true);
            idle.start();
            Fee card = new CardFee();
            for (int i = 0; i < 20_000; i++) sink += total(card, 1000);   // total скомпилирован с одним типом
            System.out.println("-- System.gc()");
            System.gc();
            System.out.println("-- Thread.getAllStackTraces()");
            sink += Thread.getAllStackTraces().size();
            System.out.println("-- idle.getStackTrace()");
            sink += idle.getStackTrace().length;
            System.out.println("-- загрузка второй реализации Fee (деоптимизация total)");
            sink += total(new SbpFee(), 1000);
            System.out.println("-- jcmd Thread.print");
            String jcmd = Path.of(System.getProperty("java.home"), "bin", "jcmd").toString();
            Process p = new ProcessBuilder(jcmd, Long.toString(ProcessHandle.current().pid()), "Thread.print")
                    .redirectErrorStream(true).start();
            p.getInputStream().readAllBytes();
            p.waitFor();
            System.out.println("-- конец");
        }
    }

    static List<String> child(String mainClass, String... flags) throws Exception {
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        List<String> cmd = new ArrayList<>(List.of(java, "-Dstdout.encoding=UTF-8", "-Duser.language=en"));
        cmd.addAll(List.of(flags));
        cmd.addAll(List.of("-cp", System.getProperty("java.class.path"), mainClass));
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        List<String> lines = new String(p.getInputStream().readAllBytes(), "UTF-8").lines().toList();
        p.waitFor();
        return lines;
    }

    public static void main(String[] args) throws Exception {
        Pattern sp = Pattern.compile("Safepoint \"(\\w+)\".*Reaching safepoint: (\\d+) ns.*Total: (\\d+) ns");
        String[][] modes = {
            {"по умолчанию"},
            {"-XX:-UseCountedLoopSafepoints", "-XX:-UseCountedLoopSafepoints"},
            {"-XX:LoopStripMiningIter=0", "-XX:LoopStripMiningIter=0"},
            {"-XX:-UseCountedLoopSafepoints -XX:+SafepointTimeout -XX:SafepointTimeoutDelay=50",
                    "-XX:-UseCountedLoopSafepoints", "-XX:+SafepointTimeout", "-XX:SafepointTimeoutDelay=50"},
        };
        for (String[] m : modes) {
            List<String> flags = new ArrayList<>(List.of("-Xlog:safepoint=info:stdout"));
            for (int i = 1; i < m.length; i++) flags.add(m[i]);
            System.out.println("== " + m[0]);
            for (String l : child("Safepoint$Ttsp", flags.toArray(String[]::new))) {
                Matcher x = sp.matcher(l);
                if (x.find()) {
                    if (x.group(1).contains("Collect"))
                        System.out.printf("  безопасная точка %s: достижение %.3f мс, всего %.3f мс%n",
                                x.group(1), Long.parseLong(x.group(2)) / 1e6, Long.parseLong(x.group(3)) / 1e6);
                } else if (!l.startsWith("[") || l.contains("did not reach") || l.contains("\"ledger-worker\"")) {
                    System.out.println("  " + l.replaceAll("^\\[[^\\]]*\\]", "").replaceAll("0x[0-9a-f]+", "0x...").trim());
                }
            }
        }
        System.out.println("== флаги по умолчанию");
        for (String l : child("Safepoint$Ttsp", "-XX:+PrintFlagsFinal", "-version"))
            if (l.matches(".*\\b(UseCountedLoopSafepoints|LoopStripMiningIter|LoopStripMiningIterShortLoop|SafepointTimeout|SafepointTimeoutDelay|GuaranteedSafepointInterval)\\b.*"))
                System.out.println("  " + l.trim().replaceAll("\\s+", " "));
        System.out.println("== флаги из книг 2018 года");
        for (String f : List.of("-XX:+PrintSafepointStatistics", "-XX:+PrintGCApplicationStoppedTime", "-XX:+UseBiasedLocking"))
            System.out.println("  " + f + ": " + child("Safepoint$Ttsp", f, "-version").get(0));
        System.out.println("== операции JVM: безопасная точка или рукопожатие");
        for (String l : child("Safepoint$Ops", "-Xlog:safepoint=info,handshake=info:stdout:tags")) {
            if (l.startsWith("--")) { System.out.println(l); continue; }
            Matcher x = Pattern.compile("(Safepoint|Handshake) \"(\\w+)\"").matcher(l);
            if (x.find()) System.out.println("  " + x.group(1) + " " + x.group(2));
        }
    }
}
