// MODE: exec Deopt
// OUT: s6-deopt
// Спекуляция C2 на единственной реализации и ее отмена при первом появлении второй, затем третьей.
public class Deopt {
    interface Rate { double apply(double amount); }
    static final class Flat implements Rate {
        private final double k;
        Flat(double k) { this.k = k; }
        public double apply(double amount) { return amount * k; }
    }
    static final class Fixed implements Rate { public double apply(double amount) { return amount + 1.0; } }
    static final class Capped implements Rate { public double apply(double amount) { return Math.min(amount, 500.0); } }

    static double total(Rate r, double[] xs) {
        double s = 0;
        for (int i = 0; i < xs.length; i++) s += r.apply(xs[i]);
        return s;
    }

    static void phase(String name, Rate[] rates, double[] xs) {
        long t0 = System.nanoTime();
        double acc = 0;
        for (int i = 0; i < 100_000; i++) acc += total(rates[i % rates.length], xs);
        if (quiet) { System.out.println("-- " + name); return; }
        System.out.printf("-- %s: %.2f нс на вызов apply (%.3e)%n", name, (System.nanoTime() - t0) / 100_000.0 / xs.length, acc);
    }

    public static void work() throws Exception {
        double[] xs = new double[1024];
        for (int i = 0; i < xs.length; i++) xs[i] = i;
        Rate flat = new Flat(1.5);
        phase("прогрев, только Flat", new Rate[] {flat}, xs);
        phase("только Flat", new Rate[] {flat}, xs);
        Thread.sleep(200);
        System.out.println("-- загружаем Fixed");
        phase("Flat и Fixed, первый проход", new Rate[] {flat, new Fixed()}, xs);
        phase("Flat и Fixed", new Rate[] {flat, new Fixed()}, xs);
        Thread.sleep(200);
        System.out.println("-- загружаем Capped");
        phase("три реализации, первый проход", new Rate[] {flat, new Fixed(), new Capped()}, xs);
        phase("три реализации", new Rate[] {flat, new Fixed(), new Capped()}, xs);
        Thread.sleep(200);
    }

    public static class Logs { public static void main(String[] a) throws Exception { quiet = true; work(); } }
    public static class Timing { public static void main(String[] a) throws Exception { work(); } }

    static boolean quiet;

    public static void main(String[] args) throws Exception {
        String bin = java.nio.file.Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String cp = System.getProperty("java.class.path");
        String[][] runs = { {"-XX:+PrintCompilation", "-Xlog:deoptimization=debug", "Deopt$Logs"}, {"Deopt$Timing"} };
        for (String[] r : runs) {
            var cmd = new java.util.ArrayList<>(java.util.List.of(bin, "-Dstdout.encoding=UTF-8", "-cp", cp));
            cmd.addAll(java.util.List.of(r));
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            String out = new String(p.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            p.waitFor();
            System.out.println("== java " + String.join(" ", r));
            out.lines().filter(l -> l.contains("Deopt") || l.startsWith("--"))
               .forEach(System.out::println);
        }
    }
}
