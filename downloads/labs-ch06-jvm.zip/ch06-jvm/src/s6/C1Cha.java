// JAVA: -XX:TieredStopAtLevel=1 -XX:+PrintCompilation -XX:+UnlockDiagnosticVMOptions -XX:+PrintInlining -Xlog:deoptimization=debug
// MODE: exec C1Cha
// GREP: C1Cha|^--|deoptimization
// OUT: s6-c1-cha
// Только C1 (уровень 1): встраивает ли он по CHA единственную реализацию,
// деоптимизирует ли код при загрузке второй и что делает с вызовом,
// мономорфным по профилю, но полиморфным по иерархии.
public class C1Cha {
    abstract static class Rate { abstract double apply(double x); }
    static final class Flat extends Rate { double apply(double x) { return x * 1.01; } }
    static final class Fixed extends Rate { double apply(double x) { return x + 1; } }

    abstract static class Fee { abstract long apply(long x); }
    static final class Card extends Fee { long apply(long x) { return x + 3; } }
    static final class Sbp extends Fee { long apply(long x) { return x + 1; } }

    static class Limit { long apply(long x) { return x - 1; } }
    static final class Vip extends Limit { long apply(long x) { return x; } }

    static long limits(Limit l, long[] a) {
        long s = 0;
        for (long x : a) s += l.apply(x);
        return s;
    }

    static double total(Rate r, double[] a) {
        double s = 0;
        for (double x : a) s += r.apply(x);
        return s;
    }

    static long fees(Fee f, long[] a) {
        long s = 0;
        for (long x : a) s += f.apply(x);
        return s;
    }

    public static void main(String[] args) throws Exception {
        double[] a = new double[1000];
        long[] b = new long[1000];
        // Обе реализации Fee загружены до прогрева, но вызывается только Card.
        Fee[] both = { new Card(), new Sbp() };
        Rate flat = new Flat();
        Limit lim = new Limit();
        double s = 0; long t = 0;
        System.out.println("-- прогрев: Rate знает только Flat, Fee вызывается только с Card");
        for (int i = 0; i < 20_000; i++) { s += total(flat, a); t += fees(both[0], b); t += limits(lim, b); }
        System.out.println("-- загружаем Fixed и Vip");
        Limit vip = (Limit) Class.forName("C1Cha$Vip").getDeclaredConstructor().newInstance();
        Rate fixed = (Rate) Class.forName("C1Cha$Fixed").getDeclaredConstructor().newInstance();
        System.out.println("-- Fixed загружен, вызываем total с Flat");
        for (int i = 0; i < 20_000; i++) { s += total(flat, a); t += limits(lim, b); }
        System.out.println("-- конец " + (s > 0) + " " + (t > 0) + " " + fixed.getClass().getSimpleName() + vip.getClass().getSimpleName());
    }
}
