// MODE: exec Loaders
// OUT: s2-loaders
// Встроенные загрузчики JDK 9+ и модули, которые они определяют.
public class Loaders {
    static String describe(Class<?> c) {
        ClassLoader l = c.getClassLoader();
        return String.format("%-28s модуль %-22s загрузчик %s", c.getName(), c.getModule().getName(),
                l == null ? "null (bootstrap)" : l.getName() + " / " + l.getClass().getName());
    }

    public static void main(String[] args) throws Exception {
        System.out.println(describe(String.class));
        System.out.println(describe(java.util.logging.Logger.class));
        System.out.println(describe(java.sql.Connection.class));
        System.out.println(describe(java.net.http.HttpClient.class));
        System.out.println(describe(Loaders.class));
        ClassLoader app = ClassLoader.getSystemClassLoader();
        System.out.println("цепочка родителей app: " + app.getName() + " -> " + app.getParent().getName() + " -> " + app.getParent().getParent());
        System.out.println("getSystemClassLoader() == загрузчик Loaders: " + (app == Loaders.class.getClassLoader()));
        System.out.println("TCCL потока main: " + Thread.currentThread().getContextClassLoader().getName());
        try {
            new java.net.URLClassLoader(new java.net.URL[0]) {
                Class<?> sneak() { return defineClass("java.lang.Evil", new byte[] {(byte) 0xCA, (byte) 0xFE}, 0, 2); }
            }.sneak();
        } catch (Throwable t) {
            System.out.println("defineClass в пакете java.*: " + t);
        }
    }
}
