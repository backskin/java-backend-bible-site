// MODE: exec Boom
// OUT: s2-boom
// Упавший статический инициализатор: первая ошибка с причиной, все следующие без нее.
public class Boom {
    static class TaxTables {
        static final double VAT = load();

        static double load() {
            return Double.parseDouble(System.getProperty("tax.vat", "20,0")); // запятая вместо точки
        }
    }

    public static void main(String[] a) {
        for (int i = 0; i < 3; i++) {
            try {
                System.out.println(TaxTables.VAT);
            } catch (Throwable t) {
                System.out.println(i + ": " + t);
                System.out.println("   cause: " + t.getCause());
            }
        }
    }
}
