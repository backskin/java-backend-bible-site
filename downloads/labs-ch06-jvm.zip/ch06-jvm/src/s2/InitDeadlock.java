// MODE: exec InitDeadlock
// OUT: s2-init-deadlock
// Взаимоблокировка на инициализации двух классов, которые ссылаются друг на друга из static-блоков.
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;

public class InitDeadlock {
    static final CountDownLatch BOTH_STARTED = new CountDownLatch(2);

    static class Tariffs {
        static final String DEFAULT;
        static {
            BOTH_STARTED.countDown();
            await();
            DEFAULT = "card:" + Limits.DAILY;
        }
    }

    static class Limits {
        static final String DAILY;
        static {
            BOTH_STARTED.countDown();
            await();
            DAILY = "100000/" + Tariffs.DEFAULT;
        }
    }

    static void await() {
        try { BOTH_STARTED.await(); Thread.sleep(100); } catch (InterruptedException e) { throw new RuntimeException(e); }
    }

    public static void main(String[] args) throws Exception {
        Thread t1 = new Thread(() -> System.out.println(Tariffs.DEFAULT), "tariffs-init");
        Thread t2 = new Thread(() -> System.out.println(Limits.DAILY), "limits-init");
        t1.setDaemon(true); t2.setDaemon(true);
        t1.start(); t2.start();
        t1.join(2000); t2.join(2000);
        System.out.println("через 2 с: tariffs-init " + t1.getState() + ", limits-init " + t2.getState());
        String jcmd = Path.of(System.getProperty("java.home"), "bin", "jcmd").toString();
        Process p = new ProcessBuilder(jcmd, Long.toString(ProcessHandle.current().pid()), "Thread.print")
                .redirectErrorStream(true).start();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            boolean in = false;
            for (String line; (line = r.readLine()) != null; ) {
                if (line.startsWith("\"tariffs-init\"") || line.startsWith("\"limits-init\"")) in = true;
                else if (line.isBlank()) in = false;
                if (in && !line.contains("Thread.java") && !line.contains("Runnable.run")) System.out.println(line.replaceAll("tid=\\S+ nid=\\S+", "tid=... nid=...").replaceAll("cpu=\\S+ elapsed=\\S+", "cpu=... elapsed=...").replaceAll("\\[0x\\S+\\]", "[...]"));
                if (line.contains("Java-level deadlock")) System.out.println(">> " + line);
            }
        }
        p.waitFor();
        System.out.println("строка \"Found one Java-level deadlock\" в выводе jcmd: нет, если выше нет строки с >>");
    }
}
