// MODE: exec ClassCount
// OUT: s2-class-count
// Сколько классов загружает пустая программа и сколько из них пришло из архива CDS.
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ClassCount {
    public static class Hello {
        public static void main(String[] a) { System.out.println("hello"); }
    }

    public static class Lambdas {
        public static void main(String[] a) {
            Runnable r = () -> { };
            r.run();
            System.out.println("сумма=" + java.util.stream.IntStream.range(0, 10).map(i -> i * 2).sum());
        }
    }

    static void run(String title, String... flags) throws Exception {
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        Path log = Files.createTempFile("cl", ".log");
        List<String> cmd = new ArrayList<>(List.of(java, "-Xlog:class+load=info:file=" + log.toAbsolutePath()));
        cmd.addAll(List.of(flags));
        cmd.addAll(List.of("-cp", System.getProperty("java.class.path")));
        cmd.add(title.startsWith("version") ? "-version" : "ClassCount$" + title.split(" ")[0]);
        if (title.startsWith("version")) { cmd.remove(cmd.size() - 2); cmd.remove(cmd.size() - 2); }
        long t0 = System.nanoTime();
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
        p.waitFor(60, TimeUnit.SECONDS);
        long ms = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t0);
        List<String> lines = Files.readAllLines(log);
        long shared = lines.stream().filter(l -> l.contains("shared objects file")).count();
        long generated = lines.stream().filter(l -> l.contains("__JVM_LookupDefineClass__") || l.contains("__JVM_DefineClass__") || l.contains("Lambda")).count();
        System.out.printf("%-34s классов %4d, из CDS %4d, сгенерировано на ходу %3d, время процесса %4d мс%n",
                title + " " + String.join(" ", flags), lines.size(), shared, generated, ms);
    }

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 2; i++) run("Hello");             // прогрев файлового кэша ОС
        run("version");
        run("Hello");
        run("Hello", "-Xshare:off");
        run("Lambdas");
        run("Lambdas", "-Xshare:off");
    }
}
