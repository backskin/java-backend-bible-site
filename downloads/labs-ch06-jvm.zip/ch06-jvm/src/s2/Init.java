// MODE: exec Init
// OUT: s2-init-triggers
// Какие обращения запускают инициализацию класса (JLS 12.4.1), а какие нет.
public class Init {
    static class Limits { static final int MAX_MINOR = 10_000_00; static { System.out.println("  Limits init"); } }
    static class Boxed  { static final Integer MAX = 100;         static { System.out.println("  Boxed init"); } }
    static class Base   { static int fee = 15;                    static { System.out.println("  Base init"); } }
    static class Card extends Base { static int bonus = 1;        static { System.out.println("  Card init"); } }
    static class Lazy   {                                         static { System.out.println("  Lazy init"); } }

    public static void main(String[] a) throws Exception {
        System.out.println("-- Limits.MAX_MINOR = " + Limits.MAX_MINOR);
        System.out.println("-- Boxed.MAX = " + Boxed.MAX);
        System.out.println("-- new Card[10].length = " + new Card[10].length);
        System.out.println("-- Card.class = " + Card.class.getSimpleName());
        System.out.println("-- Card.fee (поле унаследовано от Base) = " + Card.fee);
        System.out.println("-- Card.bonus = " + Card.bonus);
        ClassLoader cl = Init.class.getClassLoader();
        System.out.println("-- loadClass(Lazy) = " + cl.loadClass("Init$Lazy").getSimpleName());
        System.out.println("-- forName(Lazy, false) = " + Class.forName("Init$Lazy", false, cl).getSimpleName());
        System.out.println("-- forName(Lazy) = " + Class.forName("Init$Lazy").getSimpleName());
    }
}
