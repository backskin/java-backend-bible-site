// MODE: exec Unload
// JAVA: -Xlog:class+unload=info -Xmx128m
// GREP: ^[^\[]|Plugin
// OUT: s2-unload-threadlocal
// Утечка загрузчика: значение ThreadLocal в живом потоке держит класс плагина, класс держит загрузчик.
import java.lang.ref.WeakReference;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.tools.ToolProvider;

public class Unload {
    public static final ThreadLocal<Object> CONTEXT = new ThreadLocal<>();

    static Path compilePlugin() throws Exception {
        Path dir = Files.createTempDirectory("plugin");
        Path src = dir.resolve("PluginRule.java");
        Files.writeString(src, """
                public class PluginRule implements Runnable {
                    public void run() { Unload.CONTEXT.set(new PluginRule()); }
                }
                """);
        int rc = ToolProvider.getSystemJavaCompiler().run(null, null, null,
                "-cp", System.getProperty("java.class.path"), "-d", dir.toString(), src.toString());
        if (rc != 0) throw new IllegalStateException("javac " + rc);
        return dir;
    }

    static WeakReference<ClassLoader> loadAndRun(Path dir) throws Exception {
        URLClassLoader loader = new URLClassLoader("plugin", new URL[] { dir.toUri().toURL() }, Unload.class.getClassLoader());
        Runnable r = (Runnable) loader.loadClass("PluginRule").getDeclaredConstructor().newInstance();
        r.run();
        loader.close();
        return new WeakReference<>(loader);
    }

    static boolean collected(WeakReference<?> ref) throws InterruptedException {
        for (int i = 0; i < 5 && ref.get() != null; i++) { System.gc(); Thread.sleep(50); }
        return ref.get() == null;
    }

    public static void main(String[] args) throws Exception {
        Path dir = compilePlugin();
        WeakReference<ClassLoader> ref = loadAndRun(dir);
        System.out.println("1) значение осталось в ThreadLocal потока main, загрузчик собран: " + collected(ref));
        CONTEXT.remove();
        System.out.println("2) после CONTEXT.remove() загрузчик собран: " + collected(ref));
    }
}
