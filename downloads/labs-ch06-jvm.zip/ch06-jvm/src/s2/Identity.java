// MODE: exec Identity
// OUT: s2-identity
// Один и тот же class-файл, загруженный двумя загрузчиками, дает два разных типа.
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.tools.ToolProvider;

public class Identity {
    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("plugin");
        Path src = dir.resolve("FeeRule.java");
        Files.writeString(src, "public class FeeRule { public long fee(long minor) { return minor / 100; } public static FeeRule of(Object o) { return (FeeRule) o; } }");
        int rc = ToolProvider.getSystemJavaCompiler().run(null, null, null, "-d", dir.toString(), src.toString());
        System.out.println("javac: " + rc);
        URL[] urls = { dir.toUri().toURL() };
        try (URLClassLoader l1 = new URLClassLoader("plugin-a", urls, null);
             URLClassLoader l2 = new URLClassLoader("plugin-b", urls, null)) {
            Class<?> a = l1.loadClass("FeeRule");
            Class<?> b = l2.loadClass("FeeRule");
            Object fromB = b.getDeclaredConstructor().newInstance();
            System.out.println("имена равны: " + a.getName().equals(b.getName()) + ", классы равны: " + (a == b));
            System.out.println("a.isInstance(объект из plugin-b): " + a.isInstance(fromB));
            try {
                a.cast(fromB);
            } catch (ClassCastException e) {
                System.out.println("a.cast: " + e.getMessage());
            }
            try {
                a.getMethod("of", Object.class).invoke(null, fromB);   // checkcast внутри класса из plugin-a
            } catch (java.lang.reflect.InvocationTargetException e) {
                System.out.println("checkcast: " + e.getCause().getMessage().replaceAll("@[0-9a-f]+", "@..."));
            }
        }
    }
}
