// MODE: exec CodeCacheFull
// OUT: s7-codecache
// Состояние code cache обычного процесса и процесса с маленьким кэшем, который переполняется.
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javax.tools.ToolProvider;

public class CodeCacheFull {
    static final String NL = "\n";

    /** Генерирует класс с N методами расчета комиссии и делает каждый горячим. */
    static Path generate(int methods) throws Exception {
        Path dir = Files.createTempDirectory("cc");
        StringBuilder sb = new StringBuilder("import java.nio.file.Path;" + NL + "public class Rules {" + NL);
        for (int i = 0; i < methods; i++) {
            sb.append(" static long r").append(i).append("(long a) { long f = a * ").append(i % 50 + 1)
              .append(" / 1000; if (f < ").append(i).append(") f = ").append(i).append("; return f ^ (a >>> ").append(i % 17).append("); }").append(NL);
        }
        for (int c = 0; c < methods / 50; c++) {
            sb.append(" static long chunk").append(c).append("() { long s = 0;").append(NL);
            for (int i = c * 50; i < (c + 1) * 50; i++) {
                sb.append("  for (int j = 0; j < 12000; j++) s += r").append(i).append("(j);").append(NL);
            }
            sb.append("  return s; }").append(NL);
        }
        sb.append(" public static void main(String[] x) throws Exception {").append(NL)
          .append("  long t0 = System.nanoTime(); long s = 0;").append(NL)
          .append("  for (int k = 0; k < 3; k++) {").append(NL);
        for (int c = 0; c < methods / 50; c++) sb.append("   s += chunk").append(c).append("();").append(NL);
        sb.append("  }").append(NL)
          .append("  System.out.println(\"расчет: \" + (System.nanoTime() - t0) / 1_000_000 + \" мс \" + (s & 1));").append(NL)
          .append("  String jcmd = Path.of(System.getProperty(\"java.home\"), \"bin\", \"jcmd\").toString();").append(NL)
          .append("  Process p = new ProcessBuilder(jcmd, Long.toString(ProcessHandle.current().pid()), \"Compiler.codecache\").redirectErrorStream(true).start();").append(NL)
          .append("  System.out.print(new String(p.getInputStream().readAllBytes()));").append(NL)
          .append(" }").append(NL).append("}").append(NL);
        Path src = dir.resolve("Rules.java");
        Files.writeString(src, sb.toString());
        int rc = ToolProvider.getSystemJavaCompiler().run(null, null, null, "-encoding", "UTF-8", "-d", dir.toString(), src.toString());
        if (rc != 0) throw new IllegalStateException("javac " + rc);
        return dir;
    }

    public static void main(String[] args) throws Exception {
        Path dir = generate(3000);
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String[][] modes = { {}, {"-XX:ReservedCodeCacheSize=3m"}, {"-XX:ReservedCodeCacheSize=3m", "-XX:TieredStopAtLevel=1"} };
        for (String[] flags : modes) {
            List<String> cmd = new ArrayList<>(List.of(java, "-Dstdout.encoding=UTF-8"));
            cmd.addAll(List.of(flags));
            cmd.addAll(List.of("-cp", dir.toString(), "Rules"));
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            p.waitFor();
            System.out.println("== " + (flags.length == 0 ? "по умолчанию" : String.join(" ", flags)));
            out.lines().filter(l -> !l.startsWith(" bounds") && !l.matches("^\\d+:$")).forEach(System.out::println);
        }
    }
}
