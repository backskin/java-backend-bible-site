// MODE: exec HugeMethod
// OUT: s3-huge-method
// Метод больше 8000 байт байткода JIT не компилирует, пока не снят DontCompileHugeMethods.
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javax.tools.ToolProvider;

public class HugeMethod {
    static String source(String name, int terms) {
        StringBuilder sb = new StringBuilder("public class " + name + " {\n static long calc(long x) {\n  long r = 0;\n");
        for (int i = 0; i < terms; i++) sb.append("  r += x * ").append(i % 7 + 1).append(" ^ ").append(i).append(";\n");
        sb.append("  return r;\n }\n public static void main(String[] a) {\n  long t0 = System.nanoTime(); long s = 0;\n")
          .append("  for (int i = 0; i < 200_000; i++) s += calc(i);\n")
          .append("  System.out.println(\"calc: \" + (System.nanoTime() - t0) / 1_000_000 + \" мс, \" + s);\n }\n}\n");
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("huge");
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        String javap = Path.of(System.getProperty("java.home"), "bin", "javap").toString();
        for (Object[] c : new Object[][] { {"Small", 600}, {"Big", 700} }) {
            Path src = dir.resolve(c[0] + ".java");
            Files.writeString(src, source((String) c[0], (Integer) c[1]));
            ToolProvider.getSystemJavaCompiler().run(null, null, null, "-d", dir.toString(), src.toString());
            Process jp = new ProcessBuilder(javap, "-c", "-cp", dir.toString(), (String) c[0]).start();
            String code = new String(jp.getInputStream().readAllBytes());
            int idx = code.indexOf("lreturn");
            String before = code.substring(0, idx);
            String last = before.substring(before.lastIndexOf('\n') + 1).trim();
            System.out.println(c[0] + ".calc: последняя инструкция на смещении " + last);
            for (String[] flags : new String[][] { {}, {"-XX:-DontCompileHugeMethods"} }) {
                List<String> cmd = new ArrayList<>(List.of(java, "-Dstdout.encoding=UTF-8", "-XX:+PrintCompilation"));
                cmd.addAll(List.of(flags));
                cmd.addAll(List.of("-cp", dir.toString(), (String) c[0]));
                Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
                String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                p.waitFor();
                long compiled = out.lines().filter(l -> l.contains(c[0] + "::calc")).count();
                String time = out.lines().filter(l -> l.startsWith("calc:")).findFirst().orElse("?");
                System.out.printf("  %-30s строк PrintCompilation для calc: %d, %s%n",
                        flags.length == 0 ? "по умолчанию" : flags[0], compiled, time);
            }
        }
    }
}
