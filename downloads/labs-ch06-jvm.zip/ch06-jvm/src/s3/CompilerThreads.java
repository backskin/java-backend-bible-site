// MODE: exec CompilerThreads
// OUT: s3-compiler-threads
// Сколько компиляторных потоков JVM заводит при разном числе процессоров (как в контейнере с лимитом CPU).
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Path;

public class CompilerThreads {
    public static void main(String[] args) throws Exception {
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        for (int cpus : new int[] {1, 2, 4, 8, 16, 32, 64}) {
            Process p = new ProcessBuilder(java, "-XX:ActiveProcessorCount=" + cpus, "-XX:+PrintFlagsFinal", "-version")
                    .redirectErrorStream(true).start();
            String count = "?", c1 = "", c2 = "";
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                for (String l; (l = r.readLine()) != null; ) {
                    if (l.contains(" CICompilerCount ")) count = l.trim().split("\\s+")[3];
                }
            }
            p.waitFor();
            System.out.printf("ActiveProcessorCount=%-3d CICompilerCount=%s%n", cpus, count);
        }
    }
}
