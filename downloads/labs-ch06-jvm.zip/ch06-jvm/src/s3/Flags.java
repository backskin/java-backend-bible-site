// MODE: exec Flags
// JAVA: -XX:+UnlockDiagnosticVMOptions -XX:+UnlockExperimentalVMOptions -XX:+PrintFlagsFinal
// GREP: \b(Tier[0-9]\w*|TieredCompilation|TieredStopAtLevel|CompileThreshold\w*|CICompilerCount\w*|BackgroundCompilation|MaxInlineSize|FreqInlineSize|MaxFreqInlineSize|InlineSmallCode|MaxInlineLevel|MaxRecursiveInlineLevel|MaxTrivialSize|MaxNodeLimit|DesiredMethodLimit|TypeProfileWidth|TypeProfileMajorReceiverPercent|TypeProfileLevel|UseTypeSpeculation|PerBytecodeTrapLimit|PerMethodTrapLimit|PerBytecodeRecompilationCutoff|PerMethodRecompilationCutoff|DoEscapeAnalysis|EliminateAllocations|EliminateAllocationArraySizeLimit|EliminateLocks|ReduceAllocationMerges|UseSuperWord|LoopUnrollLimit|LoopStripMiningIter|ReservedCodeCacheSize|InitialCodeCacheSize|SegmentedCodeCache|NonNMethodCodeHeapSize|ProfiledCodeHeapSize|NonProfiledCodeHeapSize|UseCodeCacheFlushing|NmethodSweepActivity|StartAggressiveSweepingAt|OmitStackTraceInFastThrow|BytecodeVerificationLocal|BytecodeVerificationRemote|DontCompileHugeMethods|HugeMethodLimit|OnStackReplacePercentage|UseOnStackReplacement|AutoCreateSharedArchive|UseJVMCICompiler|EnableJVMCI|ShowCodeDetailsInExceptionMessages|UseAES|UseSHA|MaxVectorSize|UseAVX)\b
// OUT: s3-flags
// Значения по умолчанию флагов JIT, code cache и проверки байткода на этой машине.
public class Flags {
    public static void main(String[] args) {
        System.out.println("процессоров: " + Runtime.getRuntime().availableProcessors());
    }
}
