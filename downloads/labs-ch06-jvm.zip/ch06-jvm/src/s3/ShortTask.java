// MODE: exec ShortTask
// OUT: s3-short-task
// Короткая задача (разбор реестра платежей) и длинная при разных режимах компиляции.
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ShortTask {
    /** Разбирает N строк реестра вида "40702810...;сумма;назначение" и считает итог. */
    public static class Work {
        public static void main(String[] a) {
            int rows = Integer.parseInt(a[0]);
            long t0 = System.nanoTime();
            long total = 0;
            StringBuilder line = new StringBuilder();
            for (int i = 0; i < rows; i++) {
                line.setLength(0);
                line.append("4070281000000000").append(i % 10_000).append(';').append(i % 997 * 100 + 15).append(";оплата по счету ").append(i);
                String[] f = line.toString().split(";");
                total += Long.parseLong(f[1]) + f[2].hashCode() % 2;
            }
            System.out.println((System.nanoTime() - t0) / 1_000_000 + " " + total);
        }
    }

    static long[] run(String rows, String... flags) throws Exception {
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        long best = Long.MAX_VALUE, bestInner = 0;
        for (int i = 0; i < 5; i++) {
            List<String> cmd = new ArrayList<>(List.of(java));
            cmd.addAll(List.of(flags));
            cmd.addAll(List.of("-cp", System.getProperty("java.class.path"), "ShortTask$Work", rows));
            long t0 = System.nanoTime();
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            String out = new String(p.getInputStream().readAllBytes()).trim();
            p.waitFor();
            long ms = (System.nanoTime() - t0) / 1_000_000;
            if (ms < best) { best = ms; bestInner = Long.parseLong(out.split(" ")[0]); }
        }
        return new long[] {best, bestInner};
    }

    public static void main(String[] args) throws Exception {
        String[][] modes = { {}, {"-XX:TieredStopAtLevel=1"}, {"-XX:-TieredCompilation"}, {"-Xint"} };
        for (String rows : new String[] {"20000", "3000000"}) {
            for (String[] m : modes) {
                long[] r = run(rows, m);
                System.out.printf("строк %-8s %-26s процесс %5d мс, работа %5d мс (лучшее из 5)%n", rows,
                        m.length == 0 ? "по умолчанию (0-3-4)" : m[0], r[0], r[1]);
            }
        }
    }
}
