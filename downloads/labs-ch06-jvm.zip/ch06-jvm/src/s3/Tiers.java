// MODE: exec Tiers
// JAVA: -XX:+PrintCompilation
// GREP: Tiers|^--
// OUT: s3-tiers
// Путь методов по уровням компиляции: обычный горячий метод, геттер, OSR в цикле main.
public class Tiers {
    static final class Account {
        private final long balance;
        Account(long balance) { this.balance = balance; }
        long balance() { return balance; }                     // тривиальный геттер
    }

    static long commission(long amountMinor) {                  // обычный горячий метод
        long fee = amountMinor * 15 / 1000;
        return fee < 1000 ? 1000 : fee;
    }

    public static void main(String[] args) throws Exception {
        Account acc = new Account(500_000);
        long sum = 0;
        for (int i = 0; i < 300_000; i++) {                      // цикл в main: сюда придет OSR
            sum += commission(acc.balance() + i);
            if (i == 100_000) System.out.println("-- прошло 100 000 итераций");
        }
        System.out.println("-- сумма " + sum);
        Thread.sleep(300);                                        // дать компиляторам закончить и напечатать
    }
}
