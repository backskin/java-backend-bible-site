"""Опыты главы 06: запускает программы из src/sK/ на JDK 21 и JDK 25 и пишет вывод в sK-<имя>.txt.

Использование:
    python -X utf8 run.py                 # все программы
    python -X utf8 run.py src/s3/*.java

Заголовок программы (необязательные строки-комментарии в начале файла):
    // MODE: run            - java Файл.java (по умолчанию)
    // MODE: javap Класс... - компиляция и javap для перечисленных классов
    // MODE: exec Класс     - javac, затем java -cp <каталог классов> Класс (без загрузчика исходников)
    // JAVAP: -c -p -v      - флаги javap (по умолчанию -c -p)
    // JAVAC: -g:none       - флаги javac
    // JAVA: -Xlog:...      - флаги java
    // ARGS: a b            - аргументы программы
    // GREP: regex          - оставить в выводе только строки, где есть совпадение
    // JDK: 21              - запускать только на этой версии (21 или 25)
    // OUT: s3-tiers        - имя файла вывода (без .txt)
"""
import glob, os, re, shutil, subprocess, sys, tempfile, datetime

HOME = os.path.expanduser('~')
JDKS = {
    '21.0.10': os.path.join(HOME, '.jdks', 'temurin-21.0.10', 'bin'),
    '25.0.5': os.path.join(HOME, '.jdks', 'jdk-25.0.5+8', 'bin'),
}
ROOT = os.path.dirname(os.path.abspath(__file__))


def header(src, key):
    m = re.search(r'^//\s*%s:\s*(.*)$' % key, src, re.M)
    return m.group(1).strip() if m else None


def clean(text, tmp):
    text = text.replace(tmp, '<tmp>').replace(tmp.replace('\\', '/'), '<tmp>')
    text = text.replace(HOME, '~').replace(HOME.replace('\\', '/'), '~')
    text = re.sub(r'0x[0-9a-f]{8,16}', '0x...', text)
    return text.replace('\r\n', '\n')


def run_one(path):
    src = open(path, encoding='utf-8').read()
    mode = (header(src, 'MODE') or 'run').split()
    jflags = (header(src, 'JAVA') or '').split()
    cflags = (header(src, 'JAVAC') or '').split()
    pflags = (header(src, 'JAVAP') or '-c -p').split()
    args = (header(src, 'ARGS') or '').split()
    grep = header(src, 'GREP')
    only = header(src, 'JDK')
    results = {}
    for ver, bin_ in JDKS.items():
        if only and not ver.startswith(only):
            continue
        tmp = tempfile.mkdtemp(prefix='ch06-')
        try:
            env = dict(os.environ, LANG='C')
            env.pop('JAVA_TOOL_OPTIONS', None)
            env.pop('_JAVA_OPTIONS', None)
            if mode[0] == 'run':
                cmd = [os.path.join(bin_, 'java'), '-Duser.language=en', '-Dstdout.encoding=UTF-8',
                       '-Dstderr.encoding=UTF-8', *jflags, os.path.abspath(path), *args]
                p = subprocess.run(cmd, capture_output=True, cwd=tmp, env=env, timeout=900)
                out = p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
                if grep:
                    out = '\n'.join(l for l in out.splitlines() if re.search(grep, l)) + '\n'
                out = ('$ java %s %s\n' % (' '.join(jflags), os.path.basename(path))) + out
                out += '' if p.returncode == 0 else '[код возврата %d]\n' % p.returncode
            else:
                cmd = [os.path.join(bin_, 'javac'), '-J-Duser.language=en', '-J-Dstdout.encoding=UTF-8',
                       '-encoding', 'UTF-8', *cflags, '-d', tmp, os.path.abspath(path)]
                p = subprocess.run(cmd, capture_output=True, cwd=tmp, env=env)
                out = '$ javac %s %s\n' % (' '.join(cflags), os.path.basename(path))
                out += p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
                if p.returncode == 0:
                    for cls in mode[1:]:
                        q = subprocess.run([os.path.join(bin_, 'javap'), '-J-Duser.language=en',
                                            '-J-Dstdout.encoding=UTF-8', *pflags, '-cp', tmp, cls],
                                           capture_output=True)
                        o = q.stdout.decode('utf-8', 'replace') + q.stderr.decode('utf-8', 'replace')
                        if grep:
                            o = '\n'.join(l for l in o.splitlines() if re.search(grep, l)) + '\n'
                        out += '$ javap %s %s\n' % (' '.join(pflags), cls) + o
                else:
                    out += '[javac: код возврата %d]\n' % p.returncode
                if mode[0] == 'exec' and p.returncode == 0:
                    out = ''
                    cmd = [os.path.join(bin_, 'java'), '-Duser.language=en', '-Dstdout.encoding=UTF-8',
                           '-Dstderr.encoding=UTF-8', *jflags, '-cp', tmp, mode[1], *args]
                    q = subprocess.run(cmd, capture_output=True, cwd=tmp, env=env, timeout=900)
                    o = q.stdout.decode('utf-8', 'replace') + q.stderr.decode('utf-8', 'replace')
                    if grep:
                        o = '\n'.join(l for l in o.splitlines() if re.search(grep, l)) + '\n'
                    out = '$ java %s %s\n' % (' '.join(jflags), mode[1]) + o
                    out += '' if q.returncode == 0 else '[код возврата %d]\n' % q.returncode
            results[ver] = clean(out, tmp)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    rel = os.path.relpath(path, ROOT).replace('\\', '/')
    name = header(src, 'OUT') or os.path.splitext(os.path.basename(path))[0].lower()
    vers = list(results)
    lines = ['# Запуск %s: labs/ch06-jvm/%s' % (datetime.date.today().isoformat(), rel)]
    if len(vers) == 2 and results[vers[0]] == results[vers[1]]:
        lines.append('# Temurin JDK %s и JDK %s: вывод одинаковый' % tuple(vers))
        lines.append(results[vers[0]].rstrip('\n'))
    else:
        for v in vers:
            lines.append('# ---- Temurin JDK %s' % v)
            lines.append(results[v].rstrip('\n'))
    dst = os.path.join(ROOT, name + '.txt')
    open(dst, 'w', encoding='utf-8', newline='\n').write('\n'.join(lines) + '\n')
    print('==>', os.path.basename(dst))
    print('\n'.join(lines[1:])[:6000])


if __name__ == '__main__':
    files = sys.argv[1:] or sorted(glob.glob(os.path.join(ROOT, 'src', 's*', '*.java')))
    for f in files:
        for g in sorted(glob.glob(f)) or [f]:
            run_one(g)
