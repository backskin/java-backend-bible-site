package dev.team.ch06;

import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.*;

/**
 * Стоимость вызова через интерфейс в зависимости от числа реализаций, которые видела точка вызова.
 * Каждый бенчмарк идет в своем форке JVM, поэтому профиль типов у него собственный.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
@State(Scope.Thread)
public class Dispatch {
    public interface FeeRule { long fee(long amountMinor); }
    public static final class CardFee  implements FeeRule { public long fee(long a) { return a * 15 / 1000; } }
    public static final class SbpFee   implements FeeRule { public long fee(long a) { return a >> 10; } }
    public static final class CashFee  implements FeeRule { public long fee(long a) { return a / 100 + 30; } }
    public static final class PromoFee implements FeeRule { public long fee(long a) { return a / 200; } }

    private static final int N = 1024;
    private final long[] amounts = new long[N];
    private FeeRule[] mono, bi, mega3, mega4;

    @Setup
    public void setup() {
        java.util.Random rnd = new java.util.Random(42);
        for (int i = 0; i < N; i++) amounts[i] = 10_000 + rnd.nextInt(1_000_000);
        FeeRule[] all = { new CardFee(), new SbpFee(), new CashFee(), new PromoFee() };
        mono = fill(all, 1); bi = fill(all, 2); mega3 = fill(all, 3); mega4 = fill(all, 4);
    }

    private FeeRule[] fill(FeeRule[] all, int kinds) {
        java.util.Random rnd = new java.util.Random(7);
        FeeRule[] r = new FeeRule[N];
        for (int i = 0; i < N; i++) r[i] = all[rnd.nextInt(kinds)];
        return r;
    }

    private long total(FeeRule[] rules) {
        long s = 0;
        for (int i = 0; i < N; i++) s += rules[i].fee(amounts[i]);
        return s;
    }

    private long totalPeeled(FeeRule[] rules) {
        long s = 0;
        for (int i = 0; i < N; i++) {
            FeeRule r = rules[i];
            s += (r instanceof CardFee c) ? c.fee(amounts[i]) : r.fee(amounts[i]);
        }
        return s;
    }

    @Benchmark @OperationsPerInvocation(N) public long monomorphic() { return total(mono); }
    @Benchmark @OperationsPerInvocation(N) public long bimorphic()   { return total(bi); }
    @Benchmark @OperationsPerInvocation(N) public long megamorphic3() { return total(mega3); }
    @Benchmark @OperationsPerInvocation(N) public long megamorphic4() { return total(mega4); }
    @Benchmark @OperationsPerInvocation(N) public long megamorphic3Peeled() { return totalPeeled(mega3); }
}
