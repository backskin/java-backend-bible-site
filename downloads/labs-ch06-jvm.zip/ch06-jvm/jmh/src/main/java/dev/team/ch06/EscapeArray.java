package dev.team.ch06;

import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.*;

/**
 * Проверка утверждения из книги Optimizing Java (гл. 10): массив длиннее 64 элементов
 * не скаляризуется, даже если заняты два элемента. Запускать с -prof gc.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(1)
@State(Scope.Thread)
public class EscapeArray {
    private final java.util.Random random = new java.util.Random();

    @Benchmark public long arraySize63() { int[] a = new int[63]; a[0] = random.nextInt(); a[1] = random.nextInt(); return a[0] + a[1]; }
    @Benchmark public long arraySize64() { int[] a = new int[64]; a[0] = random.nextInt(); a[1] = random.nextInt(); return a[0] + a[1]; }
    @Benchmark public long arraySize65() { int[] a = new int[65]; a[0] = random.nextInt(); a[1] = random.nextInt(); return a[0] + a[1]; }

    /** Тот же массив, но читается в цикле: индексы перестают быть константами для разбора. */
    @Benchmark public long loopRead64() { int[] a = new int[64]; a[0] = random.nextInt(); a[1] = random.nextInt(); long s = 0; for (int i = 0; i < 2; i++) s += a[i]; return s; }
    @Benchmark public long loopRead65() { int[] a = new int[65]; a[0] = random.nextInt(); a[1] = random.nextInt(); long s = 0; for (int i = 0; i < 2; i++) s += a[i]; return s; }
}
