package dev.team.ch06;

import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.*;

/**
 * Проверка утверждения из книги Optimizing Java (гл. 10, JDK 8): цикл со счетчиком long
 * не разворачивается и проигрывает циклу со счетчиком int около 40 %.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(1)
@State(Scope.Thread)
public class LoopCounter {
    private static final int MAX = 1_000_000;
    private final long[] data = new long[MAX];

    @Setup
    public void setup() {
        java.util.Random r = new java.util.Random(1);
        for (int i = 0; i < MAX; i++) data[i] = r.nextLong();
    }

    @Benchmark public long intStride1() { long s = 0; for (int i = 0; i < MAX; i++) s += data[i]; return s; }
    @Benchmark public long longStride1() { long s = 0; for (long l = 0; l < MAX; l++) s += data[(int) l]; return s; }
}
