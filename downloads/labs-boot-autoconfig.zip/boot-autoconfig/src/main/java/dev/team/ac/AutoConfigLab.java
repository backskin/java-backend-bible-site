package dev.team.ac;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.context.annotation.Fallback;
import org.springframework.context.annotation.Primary;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Опыт разд. 3: условия и порядок автоконфигураций на внутренних стартерах Тундра-Банка.
 * Клиент сервиса лимитов (LimitsClient), его повторы (LimitsRetry) и аудит (AuditSink).
 */
public class AutoConfigLab {
    record LimitsClient(String origin) { }
    record LimitsRetry() { }
    record AuditSink(String origin) { }

    // ---- @ConditionalOnProperty и matchIfMissing
    @Configuration(proxyBeanMethods = false)
    static class RetryOffByDefault {
        @Bean @ConditionalOnProperty(prefix = "tundra.limits.retry", name = "enabled", havingValue = "true")
        LimitsRetry retry() { return new LimitsRetry(); }
    }
    @Configuration(proxyBeanMethods = false)
    static class RetryOnByDefault {
        @Bean @ConditionalOnProperty(prefix = "tundra.limits.retry", name = "enabled", havingValue = "true", matchIfMissing = true)
        LimitsRetry retry() { return new LimitsRetry(); }
    }

    // ---- @ConditionalOnMissingBean: отступление и конфликт двух автоконфигураций
    @AutoConfiguration
    static class LimitsAutoConfiguration {
        @Bean @ConditionalOnMissingBean LimitsClient limitsClient() { return new LimitsClient("стартер лимитов (OnMissingBean)"); }
    }
    @AutoConfiguration
    static class LegacyLimitsAutoConfiguration {
        @Bean LimitsClient limitsClient() { return new LimitsClient("старый стартер (без условия)"); }
    }
    // та же пара, но условный стартер по алфавиту идёт первым
    @AutoConfiguration
    static class ALimitsAutoConfiguration {
        @Bean @ConditionalOnMissingBean LimitsClient limitsClient() { return new LimitsClient("стартер лимитов (OnMissingBean)"); }
    }
    @AutoConfiguration
    static class BLegacyLimitsAutoConfiguration {
        @Bean LimitsClient limitsClient() { return new LimitsClient("старый стартер (без условия)"); }
    }
    @AutoConfiguration(after = LegacyLimits2AutoConfiguration.class)
    static class Limits2AutoConfiguration {
        @Bean @ConditionalOnMissingBean LimitsClient limitsClient() { return new LimitsClient("стартер лимитов (OnMissingBean, after старого)"); }
    }
    @AutoConfiguration
    static class LegacyLimits2AutoConfiguration {
        @Bean LimitsClient limitsClient() { return new LimitsClient("старый стартер (без условия)"); }
    }
    @Configuration(proxyBeanMethods = false)
    static class UserConfig {
        @Bean LimitsClient bankLimitsClient() { return new LimitsClient("свой бин приложения"); }
    }

    // ---- FactoryBean под @ConditionalOnMissingBean без явного типа
    static class LimitsClientFactory implements FactoryBean<LimitsClient> {
        public LimitsClient getObject() { return new LimitsClient("из FactoryBean"); }
        public Class<?> getObjectType() { return LimitsClient.class; }
    }
    @AutoConfiguration
    static class FactoryAutoConfiguration {
        @Bean @ConditionalOnMissingBean FactoryBean<LimitsClient> limitsClientFactory() { return new LimitsClientFactory(); }
    }
    @AutoConfiguration
    static class FactoryTypedAutoConfiguration {
        @Bean @ConditionalOnMissingBean(LimitsClient.class) FactoryBean<LimitsClient> limitsClientFactory() { return new LimitsClientFactory(); }
    }

    // ---- @ConditionalOnBean без порядка: аудит зависит от клиента лимитов из другой автоконфигурации.
    // Имена подобраны так, что по алфавиту аудит (a.Audit...) разбирается раньше клиента (z.Zlimits...).
    @AutoConfiguration
    static class AAuditAutoConfiguration {
        @Bean @ConditionalOnBean(LimitsClient.class) AuditSink auditSink() { return new AuditSink("аудит вызовов лимитов"); }
    }
    @AutoConfiguration(after = ZLimitsAutoConfiguration.class)
    static class AAuditAfterAutoConfiguration {
        @Bean @ConditionalOnBean(LimitsClient.class) AuditSink auditSink() { return new AuditSink("аудит вызовов лимитов (after)"); }
    }
    @AutoConfiguration
    static class ZLimitsAutoConfiguration {
        @Bean LimitsClient limitsClient() { return new LimitsClient("клиент лимитов"); }
    }

    // ---- Boot 3.4: defaultCandidate = false и @Fallback
    @Configuration(proxyBeanMethods = false)
    static class NonDefaultCandidateConfig {
        @Bean(defaultCandidate = false) LimitsClient reportingLimitsClient() { return new LimitsClient("клиент для отчётов, defaultCandidate=false"); }
    }
    @Configuration(proxyBeanMethods = false)
    static class TwoClientsFallback {
        @Bean LimitsClient onlineLimitsClient() { return new LimitsClient("онлайн"); }
        @Bean @Fallback LimitsClient batchLimitsClient() { return new LimitsClient("пакетный, @Fallback"); }
    }
    @Configuration(proxyBeanMethods = false)
    static class TwoClientsPlain {
        @Bean LimitsClient onlineLimitsClient() { return new LimitsClient("онлайн"); }
        @Bean LimitsClient batchLimitsClient() { return new LimitsClient("пакетный"); }
    }
    @Configuration(proxyBeanMethods = false)
    static class TwoClientsPrimary {
        @Bean @Primary LimitsClient onlineLimitsClient() { return new LimitsClient("онлайн, @Primary"); }
        @Bean LimitsClient batchLimitsClient() { return new LimitsClient("пакетный"); }
    }
    @AutoConfiguration
    static class SingleCandidateAuditAutoConfiguration {
        @Bean @ConditionalOnSingleCandidate(LimitsClient.class) AuditSink auditSink(LimitsClient client) { return new AuditSink("аудит для " + client.origin()); }
    }

    public static void main(String[] a) {
        System.out.println("== @ConditionalOnProperty");
        count("1. свойства нет, без matchIfMissing", new ApplicationContextRunner().withUserConfiguration(RetryOffByDefault.class));
        count("2. свойства нет, matchIfMissing=true", new ApplicationContextRunner().withUserConfiguration(RetryOnByDefault.class));
        count("3. enabled=false, matchIfMissing=true", new ApplicationContextRunner().withUserConfiguration(RetryOnByDefault.class).withPropertyValues("tundra.limits.retry.enabled=false"));
        count("4. enabled=true, без matchIfMissing", new ApplicationContextRunner().withUserConfiguration(RetryOffByDefault.class).withPropertyValues("tundra.limits.retry.enabled=true"));
        count("5. enabled= (пустое), matchIfMissing=true", new ApplicationContextRunner().withUserConfiguration(RetryOnByDefault.class).withPropertyValues("tundra.limits.retry.enabled="));

        System.out.println("== @ConditionalOnMissingBean");
        clients("6. автоконфигурация и свой бин приложения", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(LimitsAutoConfiguration.class)).withUserConfiguration(UserConfig.class));
        clients("7. два стартера без порядка", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(LimitsAutoConfiguration.class, LegacyLimitsAutoConfiguration.class)));
        clients("7б. два стартера без порядка, условный по алфавиту первым", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(ALimitsAutoConfiguration.class, BLegacyLimitsAutoConfiguration.class)));
        clients("8. условный стартер с after старого",  new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(Limits2AutoConfiguration.class, LegacyLimits2AutoConfiguration.class)));
        clients("9. порядок аргументов of() переставлен", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(LegacyLimits2AutoConfiguration.class, Limits2AutoConfiguration.class)));
        clients("10. FactoryBean без типа в условии", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(FactoryAutoConfiguration.class)).withUserConfiguration(UserConfig.class));
        clients("11. FactoryBean, @ConditionalOnMissingBean(LimitsClient.class)", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(FactoryTypedAutoConfiguration.class)).withUserConfiguration(UserConfig.class));

        System.out.println("== @ConditionalOnBean и порядок");
        audit("12. аудит разбирается раньше клиента, порядка нет", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(AAuditAutoConfiguration.class, ZLimitsAutoConfiguration.class)));
        audit("13. аудит с after = клиент лимитов", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(AAuditAfterAutoConfiguration.class, ZLimitsAutoConfiguration.class)));

        System.out.println("== Boot 3.4: defaultCandidate = false и @Fallback");
        clients("14. свой бин с defaultCandidate=false и автоконфигурация", new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(LimitsAutoConfiguration.class)).withUserConfiguration(NonDefaultCandidateConfig.class));
        single("15. @ConditionalOnSingleCandidate, два клиента, один @Fallback", TwoClientsFallback.class);
        single("16. @ConditionalOnSingleCandidate, два клиента без @Fallback и @Primary", TwoClientsPlain.class);
        single("17. @ConditionalOnSingleCandidate, два клиента, один @Primary", TwoClientsPrimary.class);
    }

    static void single(String what, Class<?> user) {
        new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(SingleCandidateAuditAutoConfiguration.class)).withUserConfiguration(user)
                .run(c -> System.out.println(what + ": аудит " + c.getBeansOfType(AuditSink.class).values().stream().map(AuditSink::origin).toList()));
    }

    static void count(String what, ApplicationContextRunner r) {
        r.run(c -> System.out.println(what + ": бинов LimitsRetry = " + c.getBeanNamesForType(LimitsRetry.class).length));
    }

    static void clients(String what, ApplicationContextRunner r) {
        r.run(c -> System.out.println(what + ": " + (c.getStartupFailure() != null ? "СБОЙ " + root(c.getStartupFailure())
                : c.getBeansOfType(LimitsClient.class).entrySet().stream().map(e -> e.getKey() + "=" + e.getValue().origin()).toList())));
    }

    static void audit(String what, ApplicationContextRunner r) {
        r.run(c -> System.out.println(what + ": клиент " + List.of(c.getBeanNamesForType(LimitsClient.class))
                + ", аудит " + List.of(c.getBeanNamesForType(AuditSink.class))));
    }

    static String root(Throwable t) {
        while (t.getCause() != null) t = t.getCause();
        String m = t.getMessage().split("\n")[0];
        return t.getClass().getSimpleName() + ": " + (m.length() > 150 ? m.substring(0, 150) + "…" : m);
    }
}
