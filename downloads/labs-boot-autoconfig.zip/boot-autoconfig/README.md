# Условия автоконфигурации: @ConditionalOnProperty, @ConditionalOnMissingBean, @ConditionalOnBean, @Fallback

Стенд к главе 10, раздел об автоконфигурации. `AutoConfigLab` на `ApplicationContextRunner` (Spring Boot 4.1.1) проверяет, когда срабатывает каждое условие: свойство отсутствует с `matchIfMissing` и без, `@ConditionalOnMissingBean` при разном порядке конфигураций, `@ConditionalOnBean`, `defaultCandidate = false` и `@Fallback` из Boot 3.4. Вывод автора - `s10-autoconfig.txt`, номера строк совпадают с текстом главы.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile exec:java -Dexec.mainClass=dev.team.ac.AutoConfigLab
```

В IDEA есть конфигурация `AutoConfigLab`. Приложение не поднимает веб-сервер: каждый сценарий - отдельный контекст в `ApplicationContextRunner`.
