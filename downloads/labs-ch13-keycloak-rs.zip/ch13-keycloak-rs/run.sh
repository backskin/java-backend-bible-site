#!/usr/bin/env bash
# Гл. 13, разд. 7 и 15: resource server (Spring Boot 4.1.1, Spring Security 7.1.1) против Keycloak 26.1 в Docker.
# Что проверяется: проверка aud по умолчанию и со свойством audiences; роли Keycloak и стандартный конвертер;
# ротация ключа realm (новый kid, удаление старого) и кеш JWKS в NimbusJwtDecoder (5 минут).
# Вывод — s07-keycloak-rs.txt. Длится около 8 минут: в конце два ожидания кеша JWKS.
set -uo pipefail
cd "$(dirname "$0")"
IMG="${KC_IMAGE:-quay.io/keycloak/keycloak:26.1}"
KP=18181; AP=18090; KC_URL="http://127.0.0.1:$KP"; ISS="$KC_URL/realms/tundra"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt >/dev/null || exit 1
CP="$(cygpath -w "$PWD/target/classes" 2>/dev/null || echo target/classes);$(cat cp.txt)"
[ "$(uname -o 2>/dev/null)" = "Msys" ] || CP="${CP//;/:}"
export MSYS_NO_PATHCONV=1   # после mvn: с этой переменной mvn.cmd в Git Bash не находит classworlds

docker rm -f kc-rs >/dev/null 2>&1
docker run -d --name kc-rs -p $KP:8080 -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=admin "$IMG" start-dev >/dev/null
for i in $(seq 1 90); do curl -s -m 5 -o /dev/null -w "%{http_code}" $KC_URL/realms/master | grep -q 200 && break; sleep 2; done
sleep 5
kc() { timeout 60 docker exec kc-rs /opt/keycloak/bin/kcadm.sh "$@"; }
id_of() { kc get "$1" -r tundra -q "$2" --fields id --format csv --noquotes; }
kc config credentials --server http://localhost:8080 --realm master --user admin --password admin >/dev/null
kc create realms -s realm=tundra -s enabled=true -s accessTokenLifespan=1800 >/dev/null   # 30 минут: опыт с кешем длится дольше срока по умолчанию (5 минут)
for c in mobile-app reports-ui; do
  kc create clients -r tundra -s clientId=$c -s publicClient=true -s directAccessGrantsEnabled=true -s standardFlowEnabled=false >/dev/null
done
aud_mapper() {  # клиенту $1 — Audience mapper с произвольной аудиторией $2
  kc create "clients/$(id_of clients clientId=$1)/protocol-mappers/models" -r tundra -s name=aud-$2 -s protocol=openid-connect \
    -s protocolMapper=oidc-audience-mapper -s "config.\"included.custom.audience\"=$2" -s 'config."access.token.claim"=true' -s 'config."id.token.claim"=false' >/dev/null
}
aud_mapper mobile-app payments-api
aud_mapper reports-ui reports-api
kc create roles -r tundra -s name=OPERATOR >/dev/null
kc create users -r tundra -s username=dev.team -s enabled=true -s email=dev.team@example.org -s emailVerified=true -s firstName=Dev -s lastName=Team >/dev/null
kc set-password -r tundra --username dev.team --new-password pw >/dev/null
kc add-roles -r tundra --uusername dev.team --rolename OPERATOR >/dev/null

token() { curl -s -m 20 -X POST "$ISS/protocol/openid-connect/token" -d grant_type=password -d client_id=$1 -d username=dev.team -d password=pw \
  | python -X utf8 -c "import json,sys; print(json.load(sys.stdin)['access_token'])"; }
claims() { python -X utf8 -c "
import base64,json,sys
h,p=[json.loads(base64.urlsafe_b64decode(x+'='*(-len(x)%4))) for x in sys.argv[1].split('.')[:2]]
print('   kid', h.get('kid'), '| typ', h.get('typ'), '| aud', p.get('aud'), '| azp', p.get('azp'), '| realm_access', p.get('realm_access'), '| срок, с', p['exp']-p['iat'])" "$1"; }
call() {  # call заголовок путь токен
  local r; r=$(curl -s -m 20 -o rs-body.txt -D - -H "Authorization: Bearer $3" "http://127.0.0.1:$AP$2" | tr -d '\r')
  printf "   %-46s -> HTTP %s%s\n" "$1" "$(echo "$r" | head -1 | cut -d' ' -f2)" \
    "$(echo "$r" | grep -i '^WWW-Authenticate' | sed 's/^/, /; s/localhost:[0-9]*/localhost:PORT/')"
  case "$2" in /api/whoami) [ -s rs-body.txt ] && echo "     тело: $(cat rs-body.txt)";; esac
}
APP=""
start_app() {
  "$J" -Dstdout.encoding=UTF-8 -cp "$CP" rs.RsApp --server.port=$AP --spring.main.banner-mode=off --logging.level.root=WARN \
     --spring.security.oauth2.resourceserver.jwt.issuer-uri=$ISS "$@" > app.log 2>&1 &
  APP=$!
  for i in $(seq 1 60); do curl -s -o rs-null.txt http://127.0.0.1:$AP/lab/jwks-fetches && break; sleep 1; done
}
stop_app() { kill $APP 2>/dev/null; wait $APP 2>/dev/null; }
fetches() { echo "   обращений к JWKS: $(curl -s http://127.0.0.1:$AP/lab/jwks-fetches)"; }

{
  echo "== Keycloak 26.1 ($IMG), Spring Boot 4.1.1, Spring Security 7.1.1, Temurin 21; realm tundra, пользователь dev.team с realm-ролью OPERATOR"
  T_MOB=$(token mobile-app); T_REP=$(token reports-ui)
  echo "-- токены: mobile-app (Audience mapper payments-api) и reports-ui (Audience mapper reports-api)"
  claims "$T_MOB"; claims "$T_REP"

  echo "-- 1. автонастройка Boot: только issuer-uri, стандартный конвертер, проверки aud нет"
  start_app
  call "mobile-app, GET /api/payments" /api/payments "$T_MOB"
  call "reports-ui (aud=reports-api), GET /api/payments" /api/payments "$T_REP"
  call "mobile-app, GET /api/limits (hasRole OPERATOR)" /api/limits "$T_MOB"
  call "mobile-app, GET /api/whoami" /api/whoami "$T_MOB"
  call "испорченная подпись, GET /api/payments" /api/payments "${T_MOB%?????}AAAAA"
  stop_app

  echo "-- 2. audiences=payments-api и конвертер ролей Keycloak"
  start_app --spring.security.oauth2.resourceserver.jwt.audiences=payments-api --lab.converter=keycloak
  call "reports-ui (aud=reports-api), GET /api/payments" /api/payments "$T_REP"
  call "mobile-app, GET /api/limits (hasRole OPERATOR)" /api/limits "$T_MOB"
  call "mobile-app, GET /api/whoami" /api/whoami "$T_MOB"
  stop_app

  echo "-- 3. ротация ключа: свой NimbusJwtDecoder.withIssuerLocation с HTTP-клиентом, считающим обращения к JWKS"
  start_app --lab.counting=true --lab.converter=keycloak
  call "старый токен (ключ A), первый запрос" /api/payments "$T_MOB"; fetches
  call "старый токен, второй запрос" /api/payments "$T_MOB"; fetches
  REALM_ID=$(kc get realms/tundra --fields id --format csv --noquotes)
  OLD=$(kc get components -r tundra -q type=org.keycloak.keys.KeyProvider --format csv --noquotes --fields id,name,providerId | grep ',rsa-generated$' | cut -d, -f1)
  kc create components -r tundra -s name=rsa-rotated -s providerId=rsa-generated -s providerType=org.keycloak.keys.KeyProvider \
     -s parentId=$REALM_ID -s 'config.priority=["200"]' -s 'config.keySize=["2048"]' >/dev/null
  echo "   в realm добавлен ключ rsa-rotated с приоритетом 200; ключей RS256 в JWKS: $(curl -s $ISS/protocol/openid-connect/certs | python -X utf8 -c "import json,sys; print(sum(1 for k in json.load(sys.stdin)['keys'] if k.get('alg')=='RS256'))")"
  T_NEW=$(token mobile-app); claims "$T_NEW"
  call "новый токен (ключ B), первый запрос" /api/payments "$T_NEW"; fetches
  kc delete components/$OLD -r tundra
  echo "   старый ключ удалён из realm; ключей RS256 в JWKS: $(curl -s $ISS/protocol/openid-connect/certs | python -X utf8 -c "import json,sys; print(sum(1 for k in json.load(sys.stdin)['keys'] if k.get('alg')=='RS256'))")"
  call "старый токен сразу после удаления ключа" /api/payments "$T_MOB"; fetches
  T0=$(date +%s)
  sleep 200
  call "старый токен через $(( $(date +%s) - T0 )) с" /api/payments "$T_MOB"; fetches
  sleep 130
  call "новый токен через $(( $(date +%s) - T0 )) с" /api/payments "$T_NEW"; fetches
  call "старый токен через $(( $(date +%s) - T0 )) с" /api/payments "$T_MOB"; fetches
  stop_app
} 2>&1 | tee s07-keycloak-rs.txt
grep -E "^\[jwks\]" app.log | tail -5 >> s07-keycloak-rs.txt
docker rm -f kc-rs >/dev/null
