package rs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.oauth2.jwt.JwtClaimValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Разд. 7 гл. 13: resource server против настоящего Keycloak 26.1.
 * lab.converter=keycloak — роли из realm_access в ROLE_*; lab.counting=true — свой декодер, считающий обращения к JWKS.
 * Проверка aud включается свойством spring.security.oauth2.resourceserver.jwt.audiences.
 */
@SpringBootApplication
public class RsApp {

    static final AtomicInteger JWKS_FETCHES = new AtomicInteger();

    @RestController
    static class Api {
        @GetMapping("/api/payments") String payments() { return "платежи"; }
        @GetMapping("/api/limits") String limits() { return "лимиты"; }
        @GetMapping("/api/whoami") Map<String, Object> whoami(Authentication a) {
            return Map.of("name", a.getName(), "type", a.getClass().getSimpleName(),
                    "authorities", a.getAuthorities().stream().map(GrantedAuthority::getAuthority).sorted().toList());
        }
        @GetMapping("/lab/jwks-fetches") int fetches() { return JWKS_FETCHES.get(); }
    }

    /** Роли Keycloak из realm_access.roles плюс стандартные SCOPE_. */
    static class KeycloakRoles implements Converter<Jwt, Collection<GrantedAuthority>> {
        private final JwtGrantedAuthoritiesConverter scopes = new JwtGrantedAuthoritiesConverter();
        @Override public Collection<GrantedAuthority> convert(Jwt jwt) {
            Set<GrantedAuthority> out = new HashSet<>(scopes.convert(jwt));
            Map<String, Object> realm = jwt.getClaimAsMap("realm_access");
            if (realm != null && realm.get("roles") instanceof Collection<?> roles)
                roles.forEach(r -> out.add(new SimpleGrantedAuthority("ROLE_" + r)));
            return out;
        }
    }

    @Configuration
    @EnableWebSecurity
    static class Security {
        @Bean
        SecurityFilterChain api(HttpSecurity http, @Value("${lab.converter:default}") String converter) throws Exception {
            JwtAuthenticationConverter c = new JwtAuthenticationConverter();
            if (converter.equals("keycloak")) c.setJwtGrantedAuthoritiesConverter(new KeycloakRoles());
            return http.authorizeHttpRequests(a -> a
                            .requestMatchers("/lab/**").permitAll()
                            .requestMatchers("/api/limits").hasRole("OPERATOR")
                            .anyRequest().authenticated())
                    .oauth2ResourceServer(o -> o.jwt(j -> j.jwtAuthenticationConverter(c)))
                    .csrf(AbstractHttpConfigurer::disable)
                    .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .build();
        }

        /** Только при lab.counting=true: тот же декодер, но HTTP-клиент считает обращения к JWKS. */
        @Bean
        @ConditionalOnProperty(name = "lab.counting", havingValue = "true")
        JwtDecoder countingDecoder(@Value("${spring.security.oauth2.resourceserver.jwt.issuer-uri}") String issuer) {
            RestTemplate rest = new RestTemplate();
            rest.getInterceptors().add((ClientHttpRequestInterceptor) (req, body, exec) -> {
                if (req.getURI().getPath().endsWith("/certs")) {
                    System.out.println("[jwks] обращение №" + JWKS_FETCHES.incrementAndGet() + " к " + req.getURI().getPath());
                }
                return exec.execute(req, body);
            });
            NimbusJwtDecoder d = NimbusJwtDecoder.withIssuerLocation(issuer).restOperations(rest).build();
            d.setJwtValidator(new DelegatingOAuth2TokenValidator<>(JwtValidators.createDefaultWithIssuer(issuer),
                    new JwtClaimValidator<List<String>>(JwtClaimNames.AUD, aud -> aud != null && aud.contains("payments-api"))));
            return d;
        }
    }

    public static void main(String[] args) {
        SpringApplication.run(RsApp.class, args);
    }
}
