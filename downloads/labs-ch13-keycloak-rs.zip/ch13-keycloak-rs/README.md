# Сервер ресурсов Spring Security 7.1 против Keycloak 26.1: проверка aud, роли из realm_access, ротация ключа и кэш JWKS

Стенд к главе 13, разделы 7 и 15. Скрипт `run.sh` поднимает Keycloak 26.1 в Docker, через `kcadm.sh` создает realm `tundra`, двух публичных клиентов с Audience mapper, роль `OPERATOR` и пользователя `dev.team`, затем запускает приложение `rs.RsApp` (Spring Boot 4.1.1) в трех конфигурациях: только `issuer-uri` (токен чужой аудитории принимается, `hasRole` дает 403), со свойством `audiences` и конвертером ролей Keycloak (401 для чужой аудитории, 200 для `OPERATOR`), со своим `NimbusJwtDecoder`, считающим обращения к JWKS, при добавлении нового ключа realm и удалении старого. `decode.py` раскодирует токен. Вывод автора - `s07-keycloak-rs.txt`; `s12-keycloak-admin-env.txt` - предупреждение Keycloak об устаревших переменных `KEYCLOAK_ADMIN`.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, Docker, bash с `curl` и Python 3; свободные порты 18181 (Keycloak) и 18090 (приложение). Прогон длится около 8 минут: в конце два ожидания кэша JWKS (200 и 330 с).

## Запуск

```bash
bash run.sh
```

Приложение отдельно, против уже поднятого Keycloak: конфигурация `RsApp` в IDEA с аргументом `--spring.security.oauth2.resourceserver.jwt.issuer-uri=http://127.0.0.1:18181/realms/tundra`.

## Что должно получиться

Старый токен после удаления ключа из realm принимается еще 5 минут, пока `NimbusJwtDecoder` не обновит JWKS (у автора 401 через 330 с, обращений к JWKS 4); новый токен с неизвестным `kid` вызывает обновление сразу.
