"""Опыты главы 05 со Spring Boot 4.1.2, Hibernate 7.4 и H2: собирает проект в трёх профилях и пишет вывод в sNN-*.txt.

    python -X utf8 run.py

Профили (pom.xml): full — kotlin-spring, kotlin-jpa и открытые сущности; closed-entities — сущности final;
no-spring-plugin — без kotlin-spring. Kotlin 2.4.21, Temurin 21.0.10.
"""
import os, subprocess, datetime, re

HOME = os.path.expanduser('~')
ROOT = os.path.dirname(os.path.abspath(__file__))
JAVA = os.path.join(HOME, '.jdks', 'temurin-21.0.10', 'bin', 'java')
SHELL = os.name == 'nt'

RUNS = [
    ('full', 's09-spring-full', []),
    ('full', 's09-validation-param', ['--acquiring.merchant-id=']),
    ('full', 's09-validation-field', ['--acquiring.terminal-id=']),
    ('closed-entities', 's10-closed-entities', []),
    ('no-spring-plugin', 's11-no-spring-plugin', []),
]


def clean(text):
    text = text.replace(HOME, '~').replace(HOME.replace('\\', '/'), '~').replace('\r\n', '\n')
    lines = [l for l in text.split('\n') if not re.match(r'\s+at ', l) and l.strip()]
    lines = [re.sub(r'^\d{4}-\d\d-\d\dT[\d:.+]+\s+', '', l) for l in lines]
    return '\n'.join(lines[:80]) + '\n'


def main():
    built = None
    for profile, out, args in RUNS:
        if built != profile:
            subprocess.run(['mvn', '-q', '-B', 'clean', 'package', '-DskipTests', '-P', profile], cwd=ROOT, check=True, shell=SHELL)
            built = profile
        cmd = [JAVA, '-Dstdout.encoding=UTF-8', '-jar', os.path.join('target', 'ch05-spring-1.0.jar'), *args]
        p = subprocess.run(cmd, capture_output=True, cwd=ROOT, timeout=300)
        text = p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
        head = '# %s: профиль %s, аргументы %s, запуск %s; Spring Boot 4.1.2, Kotlin 2.4.21, Temurin 21.0.10\n# (строки стека «at ...» и пустые строки убраны)\n\n' % (
            out, profile, ' '.join(args) or '-', datetime.date.today().isoformat())
        open(os.path.join(ROOT, out + '.txt'), 'w', encoding='utf-8', newline='\n').write(head + clean(text) + ('[код возврата %d]\n' % p.returncode if p.returncode else ''))
        print(out, p.returncode)
    subprocess.run(['mvn', '-q', '-B', 'clean', 'package', '-DskipTests', '-P', 'full'], cwd=ROOT, check=True, shell=SHELL)
    extra_runs()


GW = ['--gateway.url=https://acq.example/api', '--gateway.terminal-id=T-17', '--gateway.timeout=3s', '--gateway.hosts=h1,h2']
CP_RUNS = [
    ('s09-extra', 'dev.team.ch05extra.ExtraAppKt', GW + ['--loose.retry.attempts=50']),
    ('s09-extra-nested-invalid', 'dev.team.ch05extra.ExtraAppKt', GW + ['--gateway.retry.attempts=50']),
    ('s09-corepo-jpa', 'dev.team.ch05corepo.CoRepoAppKt', []),
]


def extra_runs():
    """Запуски отдельных приложений из target/classes с классовым путем Maven (профиль full)."""
    subprocess.run(['mvn', '-q', '-B', 'dependency:build-classpath', '-Dmdep.outputFile=cp.txt'], cwd=ROOT, check=True, shell=SHELL)
    cp = os.path.join(ROOT, 'target', 'classes') + os.pathsep + open(os.path.join(ROOT, 'cp.txt'), encoding='utf-8').read().strip()
    for out, main_class, args in CP_RUNS:
        p = subprocess.run([JAVA, '-Dstdout.encoding=UTF-8', '-cp', cp, main_class, *args], capture_output=True, cwd=ROOT, timeout=300)
        text = p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
        head = '# %s: класс %s, аргументы %s, запуск %s; Spring Boot 4.1.2, Kotlin 2.4.21, Temurin 21.0.10\n# (строки стека и пустые строки убраны)\n\n' % (
            out, main_class, ' '.join(args) or '-', datetime.date.today().isoformat())
        open(os.path.join(ROOT, out + '.txt'), 'w', encoding='utf-8', newline='\n').write(head + clean(text) + ('[код возврата %d]\n' % p.returncode if p.returncode else ''))
        print(out, p.returncode)


def aot_run():
    """Сборка с Spring AOT (профиль native без компиляции образа), выписка подсказок для Kotlin и запуск на JVM в режиме AOT."""
    import json
    subprocess.run(['mvn', '-q', '-B', '-P', 'full,native', 'clean', 'package', '-DskipTests'], cwd=ROOT, check=True, shell=SHELL)
    meta = os.path.join(ROOT, 'target', 'spring-aot', 'main', 'resources', 'META-INF', 'native-image', 'dev.team.ch05', 'ch05-spring', 'reachability-metadata.json')
    d = json.load(open(meta, encoding='utf-8'))
    lines = ['записей reflection: %d' % len(d['reflection'])]
    for e in d['reflection']:
        t = e['type'] if isinstance(e['type'], str) else json.dumps(e['type'], ensure_ascii=False)
        if t.startswith('dev.team') or t.startswith('kotlin'):
            lines.append(t + ' ' + json.dumps({k: v for k, v in e.items() if k != 'type'}, ensure_ascii=False))
    open(os.path.join(ROOT, 's09-aot-hints.txt'), 'w', encoding='utf-8', newline='\n').write(
        '# s09-aot-hints: подсказки reflection из reachability-metadata.json (mvn -P full,native package), запуск %s; Spring Boot 4.1.2, Kotlin 2.4.21\n\n' % datetime.date.today().isoformat()
        + '\n'.join(lines) + '\n')
    p = subprocess.run([JAVA, '-Dstdout.encoding=UTF-8', '-Dspring.aot.enabled=true', '-jar', os.path.join('target', 'ch05-spring-1.0.jar')], capture_output=True, cwd=ROOT, timeout=300)
    text = p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
    open(os.path.join(ROOT, 's09-aot-run.txt'), 'w', encoding='utf-8', newline='\n').write(
        '# s09-aot-run: java -Dspring.aot.enabled=true -jar (сборка -P full,native), запуск %s; Spring Boot 4.1.2, Kotlin 2.4.21, Temurin 21.0.10\n\n' % datetime.date.today().isoformat()
        + clean(text) + ('[код возврата %d]\n' % p.returncode if p.returncode else ''))
    print('aot', p.returncode)


if __name__ == '__main__':
    import sys
    {'extra': extra_runs, 'aot': aot_run}.get(sys.argv[1] if sys.argv[1:] else '', main)()
