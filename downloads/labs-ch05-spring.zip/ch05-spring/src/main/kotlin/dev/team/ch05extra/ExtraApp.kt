package dev.team.ch05extra

import dev.team.ch05.AccountNumber
import dev.team.ch05.Merchant
import dev.team.ch05.Payment
import jakarta.validation.Valid
import jakarta.validation.constraints.Max
import jakarta.validation.constraints.Min
import jakarta.validation.constraints.NotBlank
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.context.properties.ConfigurationPropertiesScan
import org.springframework.boot.persistence.autoconfigure.EntityScan
import org.springframework.boot.runApplication
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.repository.findByIdOrNull
import org.springframework.http.ResponseEntity
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.bind.annotation.RestControllerAdvice
import java.net.URI
import java.time.Duration

/** Настройки платежного шлюза с вложенным блоком повторов, проверяемым через @Valid. */
@Validated
@ConfigurationProperties("gateway")
data class GatewayProperties(
    val url: URI,
    @field:NotBlank val terminalId: String,
    val timeout: Duration = Duration.ofSeconds(5),
    @field:Valid val retry: Retry = Retry(),
    val hosts: List<String> = emptyList(),
) {
    /** Повторы вызова шлюза. */
    data class Retry(
        @field:Min(1) @field:Max(10) val attempts: Int = 3,
        val backoff: Duration = Duration.ofMillis(200),
    )
}

/** Те же настройки без @Valid на вложенном блоке. */
@Validated
@ConfigurationProperties("loose")
data class LooseProperties(
    val retry: GatewayProperties.Retry = GatewayProperties.Retry(),
)

/** Репозиторий JPA для платежей. */
interface ExtraPaymentRepository : JpaRepository<Payment, Long>

/** Котировка недоступна: доменная ошибка. */
class PricingUnavailable(val requestId: String, cause: Throwable) : RuntimeException("котировка недоступна", cause)

/** Контроллер котировок: таймаут как отмена и как доменная ошибка. */
@RestController
class QuoteController {
    @GetMapping("/quote/raw")
    suspend fun raw(): String = withTimeout(10) { delay(100); "курс" }

    @GetMapping("/quote/domain")
    suspend fun domain(): String = try {
        withTimeout(10) { delay(100); "курс" }
    } catch (e: TimeoutCancellationException) {
        throw PricingUnavailable("q-1", e)
    }

    @GetMapping("/limits")
    suspend fun limits(): String { delay(1); throw LimitUnavailable() }
}

/** Лимит недоступен: доменная ошибка для suspend-обработчика. */
class LimitUnavailable : RuntimeException("лимиты недоступны")

/** Обработчики ошибок: обычный метод и suspend-метод. */
@RestControllerAdvice
class ApiErrors {
    @ExceptionHandler(PricingUnavailable::class)
    fun pricing(e: PricingUnavailable): ResponseEntity<String> =
        ResponseEntity.status(503).body("PRICING_UNAVAILABLE ${e.requestId}")

    @ExceptionHandler(LimitUnavailable::class)
    suspend fun limits(e: LimitUnavailable): ResponseEntity<String> {
        delay(1)
        return ResponseEntity.status(503).body("LIMITS_UNAVAILABLE")
    }
}

@SpringBootApplication
@ConfigurationPropertiesScan
@EntityScan(basePackageClasses = [Payment::class])
open class ExtraApp

fun main(args: Array<String>) {
    val ctx = runApplication<ExtraApp>(*args)
    println("\n== 1 вложенные настройки")
    println(ctx.getBean(GatewayProperties::class.java))
    println(ctx.getBean(LooseProperties::class.java))

    println("\n== 2 findByIdOrNull")
    val repo = ctx.getBean(ExtraPaymentRepository::class.java)
    val em = ctx.getBean(jakarta.persistence.EntityManagerFactory::class.java).createEntityManager()
    em.transaction.begin()
    val m = Merchant(9, "КорзинаПлюс")
    em.persist(m)
    em.persist(Payment(merchant = m, amount = java.math.BigDecimal("1.00"), account = AccountNumber("40817810000000000009")))
    em.transaction.commit()
    println("findByIdOrNull(1) = ${repo.findByIdOrNull(1L)}, findByIdOrNull(999) = ${repo.findByIdOrNull(999L)}")
    println("findById(999) = ${repo.findById(999L)}")

    println("\n== 3 таймаут в suspend-обработчике")
    val port = ctx.environment.getProperty("local.server.port")
    val http = java.net.http.HttpClient.newHttpClient()
    for (path in listOf("/quote/raw", "/quote/domain", "/limits")) {
        val r = runCatching {
            http.send(java.net.http.HttpRequest.newBuilder(URI("http://localhost:$port$path")).build(),
                java.net.http.HttpResponse.BodyHandlers.ofString())
        }
        println("$path -> " + r.fold({ "HTTP ${it.statusCode()}: ${it.body().take(160)}" }, { "${it.javaClass.simpleName}: ${it.message}" }))
    }
    ctx.close()
}
