package dev.team.ch05valuerepo

import dev.team.ch05.AccountNumber
import dev.team.ch05.Payment
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.persistence.autoconfigure.EntityScan
import org.springframework.boot.runApplication
import org.springframework.data.jpa.repository.JpaRepository

/** Метод репозитория с value class в параметре: имя в байткоде искажается. */
interface PaymentByAccountRepository : JpaRepository<Payment, Long> {
    fun findByAccount(account: AccountNumber): List<Payment>
}

@SpringBootApplication
@EntityScan(basePackageClasses = [Payment::class])
open class ValueRepoApp

fun main(args: Array<String>) {
    println("методы репозитория: " + PaymentByAccountRepository::class.java.declaredMethods.map { it.name })
    val ctx = runApplication<ValueRepoApp>(*args, "--spring.main.web-application-type=none")
    println("контекст поднялся")
    val repo = ctx.getBean(PaymentByAccountRepository::class.java)
    val em = ctx.getBean(jakarta.persistence.EntityManagerFactory::class.java).createEntityManager()
    em.transaction.begin()
    val m = dev.team.ch05.Merchant(7, "КорзинаПлюс")
    em.persist(m)
    em.persist(Payment(merchant = m, amount = java.math.BigDecimal("1.00"), account = AccountNumber("40817810000000000009")))
    em.transaction.commit()
    println("findByAccount: " + repo.findByAccount(AccountNumber("40817810000000000009")).map { it.toString() + " " + it.account })
    ctx.close()
}
