package dev.team.ch05corepo

import dev.team.ch05.Payment
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.persistence.autoconfigure.EntityScan
import org.springframework.boot.runApplication
import org.springframework.data.repository.kotlin.CoroutineCrudRepository

/** Корутинный репозиторий в приложении, где есть только JPA. */
interface PaymentCoRepository : CoroutineCrudRepository<Payment, Long>

@SpringBootApplication
@EntityScan(basePackageClasses = [Payment::class])
open class CoRepoApp

fun main(args: Array<String>) {
    println("методы CoroutineCrudRepository: " + CoroutineCrudRepository::class.java.methods
        .filter { it.name in setOf("findById", "findAll", "save", "count") }
        .map { m -> m.name + m.parameterTypes.joinToString(",", "(", ")") { it.simpleName } + ": " + m.returnType.simpleName }
        .sorted())
    runCatching { runApplication<CoRepoApp>(*args, "--spring.main.web-application-type=none").close() }
        .onFailure { e ->
            var c: Throwable? = e
            while (c != null) { println("причина: ${c.javaClass.name}: ${c.message?.lines()?.first()}"); c = c.cause }
        }
    println("контекст: попытка запуска закончена")
}
