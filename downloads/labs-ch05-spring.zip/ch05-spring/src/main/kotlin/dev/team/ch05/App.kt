package dev.team.ch05

import jakarta.persistence.EntityManager
import jakarta.validation.constraints.NotBlank
import kotlinx.coroutines.*
import org.hibernate.Hibernate
import org.springframework.aop.support.AopUtils
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.ApplicationRunner
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.context.properties.ConfigurationPropertiesScan
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.transaction.support.TransactionTemplate
import org.springframework.transaction.support.TransactionSynchronizationManager
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RestController
import java.lang.reflect.Modifier
import java.math.BigDecimal

interface PaymentRepository : JpaRepository<Payment, Long>
interface RegistryLineRepository : JpaRepository<RegistryLine, Long>

/** Настройки эквайринга: data class с проверкой полей. */
@Validated
@ConfigurationProperties("acquiring")
data class AcquiringProperties(
    @NotBlank val merchantId: String,
    @field:NotBlank val terminalId: String,
    val timeoutMs: Long = 3000,
)

/** Сервис проводок: транзакционные методы, обычный и suspend. */
@Service
class PostingService(private val payments: PaymentRepository, private val jdbc: JdbcTemplate) {

    @Transactional
    fun postTwoBlocking(m: Merchant, fail: Boolean) {
        payments.save(Payment(merchant = m, amount = BigDecimal("10.00"), account = AccountNumber("40817810000000000001")))
        if (fail) throw IllegalStateException("сбой после первой проводки")
        payments.save(Payment(merchant = m, amount = BigDecimal("20.00"), account = AccountNumber("40817810000000000002")))
    }

    @Transactional
    suspend fun postTwoSuspend(m: Merchant, fail: Boolean) {
        payments.save(Payment(merchant = m, amount = BigDecimal("10.00"), account = AccountNumber("40817810000000000001")))
        println("suspend: до delay транзакция активна=${TransactionSynchronizationManager.isActualTransactionActive()}, поток ${Thread.currentThread().name}")
        delay(10)
        println("suspend: после delay транзакция активна=${TransactionSynchronizationManager.isActualTransactionActive()}, поток ${Thread.currentThread().name}")
        if (fail) throw IllegalStateException("сбой после первой проводки")
        payments.save(Payment(merchant = m, amount = BigDecimal("20.00"), account = AccountNumber("40817810000000000002")))
    }

    fun count(): Int = jdbc.queryForObject("select count(*) from payment", Int::class.java)!!
}

/** suspend-контроллер в Spring MVC. */
@RestController
class LimitController {
    @GetMapping("/limits/{account}")
    suspend fun limit(@PathVariable account: String): String {
        val before = Thread.currentThread().name
        delay(20)
        val after = Thread.currentThread().name
        return "limit=50000 before=$before after=$after"
    }
}

/** Журнал проходов запроса через цепочку фильтров: тип диспетчеризации, поток, начат ли асинхронный режим. */
class DispatchLogFilter : jakarta.servlet.Filter {
    override fun doFilter(req: jakarta.servlet.ServletRequest, res: jakarta.servlet.ServletResponse, chain: jakarta.servlet.FilterChain) {
        chain.doFilter(req, res)
        println("фильтр: проход ${req.dispatcherType}, поток ${Thread.currentThread().name}, isAsyncStarted=${req.isAsyncStarted}")
    }
}

/** Поток, на котором Spring MVC пишет тело ответа suspend-метода. */
@org.springframework.web.bind.annotation.ControllerAdvice
class BodyWriteLog : org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice<Any> {
    override fun supports(returnType: org.springframework.core.MethodParameter, converterType: Class<out org.springframework.http.converter.HttpMessageConverter<*>>) = true
    override fun beforeBodyWrite(body: Any?, returnType: org.springframework.core.MethodParameter, contentType: org.springframework.http.MediaType,
                                 converterType: Class<out org.springframework.http.converter.HttpMessageConverter<*>>,
                                 request: org.springframework.http.server.ServerHttpRequest, response: org.springframework.http.server.ServerHttpResponse): Any? {
        println("запись тела: поток ${Thread.currentThread().name}")
        return body
    }
}

/** Подсказка для native image: kotlin-reflect ищет value class по имени, когда Spring Data выбирает конструктор сущности. */
class ValueClassHints : org.springframework.aot.hint.RuntimeHintsRegistrar {
    override fun registerHints(hints: org.springframework.aot.hint.RuntimeHints, classLoader: ClassLoader?) {
        hints.reflection().registerType(AccountNumber::class.java)
    }
}

@SpringBootApplication
@ConfigurationPropertiesScan
@org.springframework.context.annotation.ImportRuntimeHints(ValueClassHints::class)
open class App {

    @Bean
    open fun dispatchLog() = org.springframework.boot.web.servlet.FilterRegistrationBean(DispatchLogFilter()).apply {
        addUrlPatterns("/limits/*")
        setDispatcherTypes(jakarta.servlet.DispatcherType.REQUEST, jakarta.servlet.DispatcherType.ASYNC)
    }

    @Bean
    open fun runner(
        @Value("\${exp:all}") exp: String,
        posting: PostingService,
        payments: PaymentRepository,
        lines: RegistryLineRepository,
        em: EntityManager,
        tx: TransactionTemplate,
        jdbc: JdbcTemplate,
        props: AcquiringProperties,
        env: org.springframework.core.env.Environment,
    ) = ApplicationRunner {
        fun section(t: String) = println("\n== $t")

        section("1 плагин kotlin-spring: модификаторы и прокси")
        println("PostingService final=${Modifier.isFinal(PostingService::class.java.modifiers)}, " +
            "бин — CGLIB-прокси: ${AopUtils.isCglibProxy(posting)}, класс бина ${posting.javaClass.simpleName}")
        println("Payment final=${Modifier.isFinal(Payment::class.java.modifiers)}, " +
            "конструктор без аргументов: ${Payment::class.java.declaredConstructors.any { it.parameterCount == 0 }}")
        println("AcquiringProperties: $props")

        section("2 ленивая связь и final-сущность")
        tx.executeWithoutResult {
            em.persist(Merchant(1, "КорзинаПлюс, магазин 17"))
            em.persist(Payment(merchant = em.getReference(Merchant::class.java, 1L), amount = BigDecimal("150.00"), account = AccountNumber("40817810000000000001")))
        }
        val id = jdbc.queryForObject("select max(id) from payment", Long::class.java)!!
        jdbc.update("update payment set comment = null where id = ?", id)
        tx.executeWithoutResult {
            em.clear()
            val p = em.find(Payment::class.java, id)
            println("merchant загружен сразу: ${Hibernate.isInitialized(p.merchant)}, класс ${p.merchant.javaClass.name}")
            println("value class в поле: account=${p.account}, тип колонки " +
                jdbc.queryForObject("select data_type from information_schema.columns where table_name='PAYMENT' and column_name='ACCOUNT'", String::class.java))
            println("comment из NULL-колонки: ${p.comment as String?} (тип в Kotlin — String)")
            println("@Transient checks после загрузки: ${(p.checks as MutableList<String>?)}")
            println("p.checks.size -> ${runCatching { p.checks.size }.exceptionOrNull()?.javaClass?.simpleName ?: "ok"}")
        }

        section("3 data class как сущность")
        val a = RegistryLine(account = "40702810000000000001", amountKop = 100_00)
        val b = RegistryLine(account = "40702810000000000001", amountKop = 100_00)
        val set = hashSetOf(a, b)
        println("две разные строки реестра в HashSet до сохранения: size=${set.size}")
        val c = RegistryLine(account = "40702810000000000003", amountKop = 5_00)
        val set2 = hashSetOf(c)
        lines.save(c)
        println("после save: id=${c.id}, set.contains(c)=${set2.contains(c)}")

        section("4 @Transactional: обычный метод и suspend с JPA")
        val m = em.getReference(Merchant::class.java, 1L)
        val before = posting.count()
        runCatching { posting.postTwoBlocking(m, fail = true) }.onFailure { println("обычный: ${it.message}") }
        println("обычный: проводок прибавилось ${posting.count() - before}")
        val before2 = posting.count()
        val r = runCatching { runBlocking { posting.postTwoSuspend(m, fail = true) } }
        println("suspend: ${r.exceptionOrNull()?.let { it.javaClass.name + ": " + it.message?.lines()?.first() }}")
        println("suspend: проводок прибавилось ${posting.count() - before2}")

        section("5 suspend-контроллер Spring MVC")
        val port = env.getProperty("local.server.port")
        val http = java.net.http.HttpClient.newHttpClient()
        repeat(2) {
            val resp = http.send(java.net.http.HttpRequest.newBuilder(java.net.URI("http://localhost:$port/limits/40817810000000000001")).build(),
                java.net.http.HttpResponse.BodyHandlers.ofString())
            println("HTTP ${resp.statusCode()}: ${resp.body()}")
        }
    }
}

fun main(args: Array<String>) {
    runApplication<App>(*args).close()
}
