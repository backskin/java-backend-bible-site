package dev.team.ch05

import jakarta.persistence.*
import java.math.BigDecimal

/** Номер счета как value class. */
@JvmInline
value class AccountNumber(val value: String)

/** Мерчант: на него ссылается платеж через ленивую связь. */
@Entity
@Table(name = "merchant")
class Merchant(
    @Id val id: Long,
    var name: String,
)

/** Платеж: обычный класс, equals по id, ленивая ссылка на мерчанта, value class в поле. */
@Entity
@Table(name = "payment")
class Payment(
    @Id @GeneratedValue var id: Long? = null,
    @ManyToOne(fetch = FetchType.LAZY) var merchant: Merchant,
    var amount: BigDecimal,
    var account: AccountNumber,
    /** В базе колонка допускает NULL, а в Kotlin тип ненулевой. */
    var comment: String = "",
) {
    /** Кэш, который не хранится в базе; инициализатор должен выполниться при создании объекта. */
    @Transient
    val checks: MutableList<String> = mutableListOf()

    override fun equals(other: Any?): Boolean = other is Payment && id != null && id == other.id
    override fun hashCode(): Int = Payment::class.hashCode()
    override fun toString(): String = "Payment(id=$id, amount=$amount)"
}

/** Строка реестра как data class: так делать не надо, опыт показывает почему. */
@Entity
@Table(name = "registry_line")
data class RegistryLine(
    @Id @GeneratedValue var id: Long? = null,
    val account: String,
    val amountKop: Long,
)
