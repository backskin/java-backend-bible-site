# Kotlin и Spring Boot 4.1: плагины kotlin-spring и kotlin-jpa, настройки на data class, корутины в MVC, AOT

Стенд к главе 05, разделы 9–11. Приложение Spring Boot 4.1.2 на Kotlin 2.4.21 с Hibernate 7.4 и H2 собирается в трех профилях Maven: `full` (kotlin-spring, kotlin-jpa, сущности открыты), `closed-entities` (сущности `final`, видно, что ломается), `no-spring-plugin` (без kotlin-spring, прокси не создаются). Отдельные приложения в том же проекте: `ExtraApp` (настройки с вложенными блоками и проверкой), `CoRepoApp` (корутинные репозитории Spring Data), `ValueRepoApp` (`value class` в методе репозитория). Профиль `native` добавляет AOT-обработку и сборку native-образа. Выводы автора - `s09-*.txt`, `s10-*.txt`, `s11-*.txt`.

## Что нужно

- Temurin JDK 21.0.10, Maven, Python 3; для `s09-native-run.txt` - Docker и JDK 25 (образ собирается Paketo).

## Запуск

```bash
python -X utf8 run.py
```

Скрипт собирает проект в каждом профиле и запускает JAR с нужными аргументами, затем запускает дополнительные приложения из `target/classes`. Вручную один профиль:

```bash
mvn -q clean package -DskipTests -P closed-entities && java -Dstdout.encoding=UTF-8 -jar target/ch05-spring-1.0.jar
```

В IDEA есть конфигурации `AppKt`, `ExtraAppKt`, `CoRepoAppKt`, `ValueRepoAppKt`; профиль выбирается в окне Maven.

## Что должно получиться

В профиле `closed-entities` обращение к ленивой связи `final`-сущности дает `NullPointerException` (`s10-closed-entities.txt`), в `no-spring-plugin` контекст не поднимается: `Could not generate CGLIB subclass of class dev.team.ch05.PostingService` (`s11-no-spring-plugin.txt`). Оба случая разобраны в главе.
