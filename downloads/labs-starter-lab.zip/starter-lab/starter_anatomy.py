"""Анатомия стартеров Spring Boot 4.1.1: что лежит в jar стартера и в модулях, на которые он ссылается."""
import json
import os
import re
import xml.etree.ElementTree as ET
import zipfile

M = os.path.expanduser("~/.m2/repository/org/springframework/boot")
V = "4.1.1"


def jar(name):
    return os.path.join(M, name, V, f"{name}-{V}.jar")


def pom_deps(name):
    t = ET.parse(os.path.join(M, name, V, f"{name}-{V}.pom"))
    ns = {"m": "http://maven.apache.org/POM/4.0.0"}
    out = []
    for d in t.getroot().findall("m:dependencies/m:dependency", ns):
        g = d.find("m:groupId", ns).text
        a = d.find("m:artifactId", ns).text
        s = d.find("m:scope", ns)
        o = d.find("m:optional", ns)
        out.append(f"{a}" + (f" [{s.text}]" if s is not None else "") + (" optional" if o is not None and o.text == "true" else ""))
    return out


def starter(name):
    z = zipfile.ZipFile(jar(name))
    names = z.namelist()
    classes = [n for n in names if n.endswith(".class")]
    print(f"== {name}: файлов в jar {len(names)}, классов {len(classes)}")
    for n in names:
        if not n.endswith("/"):
            print("   ", n)
    print("   зависимости из pom:")
    for d in pom_deps(name):
        print("     ", d)


def module(name, prefixes=()):
    z = zipfile.ZipFile(jar(name))
    names = z.namelist()
    classes = [n for n in names if n.endswith(".class")]
    print(f"== модуль {name}: классов {len(classes)}")
    for n in names:
        if n.startswith("META-INF/spring") and not n.endswith("/"):
            body = z.read(n).decode("utf-8", "replace")
            lines = [l for l in body.splitlines() if l.strip() and not l.startswith("#")]
            print(f"   {n}: {len(lines)} строк")
            if n.endswith("AutoConfiguration.imports"):
                for l in lines:
                    print("      ", l.rsplit(".", 1)[-1])
            if n.endswith("spring-configuration-metadata.json"):
                props = json.loads(body).get("properties", [])
                print(f"      свойств в метаданных: {len(props)}")
                for p in prefixes:
                    sel = [x for x in props if x["name"].startswith(p)]
                    print(f"      с префиксом {p}: {len(sel)}; первые: " + ", ".join(f"{x['name']}" + (f"={x['defaultValue']}" if "defaultValue" in x else "") for x in sel[:4]))


for s in ("spring-boot-starter-web", "spring-boot-starter-webmvc", "spring-boot-starter-jdbc", "spring-boot-starter-data-jpa"):
    starter(s)
print()
module("spring-boot-webmvc", ("spring.mvc.",))
module("spring-boot-tomcat", ("server.tomcat.",))
module("spring-boot-jdbc", ("spring.datasource.hikari.", "spring.datasource."))
module("spring-boot-autoconfigure")
