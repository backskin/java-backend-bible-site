import acme.Greeter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Тот же jar, но приложение запущено через Spring Boot. */
public class WithBoot {
    @Configuration @EnableAutoConfiguration static class App {}
    @Configuration @EnableAutoConfiguration static class AppOwn {
        @Bean Greeter greeter() { return new Greeter("Привет (свой бин)"); }
    }
    public static void main(String[] a) {
        var app = new SpringApplication(App.class);
        app.setWebApplicationType(WebApplicationType.NONE);
        app.setBannerMode(org.springframework.boot.Banner.Mode.OFF);
        try (var ctx = app.run(a)) {
            var g = ctx.getBeansOfType(Greeter.class);
            System.out.println("Spring Boot: бинов Greeter = " + g.size() + ", greet -> " + g.values().iterator().next().greet("Анна"));
        }
        var own = new SpringApplication(AppOwn.class);
        own.setWebApplicationType(WebApplicationType.NONE);
        own.setBannerMode(org.springframework.boot.Banner.Mode.OFF);
        try (var ctx = own.run("--acme.greeter.greeting=Добрый день")) {
            System.out.println("Spring Boot, свой бин объявлен: " + ctx.getBean(Greeter.class).greet("Анна") + " (автоконфигурация отступила)");
        }
        var cfg = new SpringApplication(App.class);
        cfg.setWebApplicationType(WebApplicationType.NONE);
        cfg.setBannerMode(org.springframework.boot.Banner.Mode.OFF);
        try (var ctx = cfg.run("--acme.greeter.greeting=Добрый день")) {
            System.out.println("Spring Boot, свойство acme.greeter.greeting: " + ctx.getBean(Greeter.class).greet("Анна"));
        }
    }
}
