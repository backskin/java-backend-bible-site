import acme.Greeter;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;

/** Обычный Spring Framework, без Boot: автоконфигурацию никто не читает. */
public class Plain {
    @Configuration static class Empty {}
    public static void main(String[] a) {
        try (var ctx = new AnnotationConfigApplicationContext(Empty.class)) {
            System.out.println("Spring без Boot: бинов Greeter = " + ctx.getBeansOfType(Greeter.class).size());
        }
    }
}
