package acme;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("acme.greeter")
public class AcmeProperties {
    private String greeting = "Здравствуйте";
    public String getGreeting() { return greeting; }
    public void setGreeting(String greeting) { this.greeting = greeting; }
}
