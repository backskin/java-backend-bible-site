package acme;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(AcmeProperties.class)
public class GreeterAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean
    Greeter greeter(AcmeProperties p) { return new Greeter(p.getGreeting()); }
}
