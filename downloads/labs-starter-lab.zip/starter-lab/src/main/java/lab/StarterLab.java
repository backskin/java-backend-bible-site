package lab;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.sql.DataSource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport.ConditionAndOutcomes;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Что делает стартер при запуске: сколько бинов и автоконфигураций добавилось и почему. Запуск: StarterLab [own-datasource] */
@SpringBootApplication
public class StarterLab {

    /** Собственный DataSource: автоконфигурация должна отступить. */
    @Configuration
    @org.springframework.context.annotation.Profile("own")
    static class OwnDs {
        @Bean
        DataSource dataSource() {
            var ds = new org.springframework.jdbc.datasource.DriverManagerDataSource("jdbc:h2:mem:own", "sa", "");
            return ds;
        }
    }

    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(StarterLab.class, args);
        var report = ConditionEvaluationReport.get(ctx.getBeanFactory());
        Map<String, ConditionAndOutcomes> all = report.getConditionAndOutcomesBySource();
        long matched = all.entrySet().stream().filter(e -> e.getValue().isFullMatch() && e.getKey().contains("AutoConfiguration")).count();
        long notMatched = all.entrySet().stream().filter(e -> !e.getValue().isFullMatch() && e.getKey().contains("AutoConfiguration")).count();
        System.out.println("БИНОВ в контексте: " + ctx.getBeanDefinitionCount());
        System.out.println("автоконфигураций сработало: " + matched + ", отступило или не подошло: " + notMatched + " (из " + report.getUnconditionalClasses().size() + " безусловных классов " + "и условных выше)");
        System.out.println("DataSource-бины: " + Arrays.toString(ctx.getBeanNamesForType(DataSource.class)));
        for (String n : ctx.getBeanNamesForType(DataSource.class)) System.out.println("  " + n + " -> " + ctx.getBean(n).getClass().getName());
        try {
            System.out.println("пул: " + ctx.getBeanNamesForType(Class.forName("com.zaxxer.hikari.HikariDataSource")).length + " HikariDataSource");
        } catch (ClassNotFoundException e) {
            System.out.println("пул: класса HikariDataSource нет в classpath");
        }
        for (var e : all.entrySet()) {
            String k = e.getKey();
            if (k.contains("DataSourceAutoConfiguration") || k.contains("DataSourceConfiguration$Hikari") || k.contains("JdbcTemplateAutoConfiguration")) {
                var c = e.getValue();
                System.out.println((c.isFullMatch() ? "СОВПАЛО " : "НЕ СОВПАЛО ") + k.substring(k.lastIndexOf('.') + 1));
                c.forEach(co -> System.out.println("    " + co.getCondition().getClass().getSimpleName() + ": " + co.getOutcome().getMessage()));
            }
        }
        if (System.getProperty("names") != null) {
            try {
                java.nio.file.Files.write(java.nio.file.Path.of(System.getProperty("names")),
                        Arrays.stream(ctx.getBeanDefinitionNames()).sorted().collect(Collectors.toList()));
            } catch (java.io.IOException e) { throw new RuntimeException(e); }
        }
        ctx.close();
    }
}
