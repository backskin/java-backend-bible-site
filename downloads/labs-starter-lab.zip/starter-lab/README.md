# starter-lab: что внутри стартера Spring Boot и что он добавляет в приложение (гл. 10, подраздел 4.1)

- `starter_anatomy.py` читает jar и pom стартеров из локального репозитория Maven (Spring Boot 4.1.1) и печатает, сколько в них классов, на что они ссылаются, сколько автоконфигураций и свойств в модулях. Вывод в `s10-starter-anatomy.txt`.
- `StarterLab.java` запускается трижды с разным classpath: только `spring-boot-starter-webmvc` (А), плюс `spring-boot-starter-jdbc` и H2 (Б), плюс свой бин `DataSource` через профиль `own` (В). Печатает число бинов, автоконфигураций и условия, по которым сработали `DataSource`, Hikari и `JdbcTemplate`. Вывод в `s10-starter-run.txt`.

```bash
mvn -q -Pjdbc compile dependency:build-classpath -Dmdep.outputFile=cpB.txt
mvn -q dependency:build-classpath -Dmdep.outputFile=cpA.txt
java -cp "target/classes;$(cat cpA.txt)" lab.StarterLab --server.port=0                          # А
java -cp "target/classes;$(cat cpB.txt)" lab.StarterLab --server.port=0                          # Б
java -cp "target/classes;$(cat cpB.txt)" lab.StarterLab --server.port=0 --spring.profiles.active=own   # В
```

## acme: минимальный стартер и граница Spring Boot

`acme/src` (класс `Greeter`, свойства, автоконфигурация и файл `AutoConfiguration.imports`) подключён к двум приложениям в `acme/app`: `Plain` (обычный Spring Framework) и `WithBoot` (Spring Boot). Вывод в `s10-starter-acme.txt`: без Boot бин не создан, с Boot создан, отступает перед своим бином и читает свойство `acme.greeter.greeting`.

```bash
javac -encoding UTF-8 -d out -cp "$(cat cpA.txt)" acme/src/acme/*.java acme/app/*.java && cp -r acme/src/META-INF out/
java -cp "out;$(cat cpA.txt)" Plain
java -cp "out;$(cat cpA.txt)" WithBoot
```
