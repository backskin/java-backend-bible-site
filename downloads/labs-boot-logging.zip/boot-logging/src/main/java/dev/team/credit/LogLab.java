package dev.team.credit;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Ведущий опыта разд. 9: запускает ScoringApp отдельными процессами с разными настройками журнала. */
public class LogLab {

    public static void main(String[] a) throws Exception {
        run("1. без настроек", List.of());
        run("2. уровень DEBUG для пакета и группа логгеров", List.of(),
                "--logging.group.scoring=dev.team.credit,dev.team.scoring", "--logging.level.scoring=debug");
        run("3. структурный журнал ECS", List.of(), "--logging.structured.format.console=ecs",
                "--logging.structured.ecs.service.version=2.3.0", "--logging.structured.ecs.service.environment=test");
        run("4. ECS: добавить, переименовать, исключить поля", List.of(), "--logging.structured.format.console=ecs",
                "--logging.structured.json.add.bank=tundra", "--logging.structured.json.rename.process.pid=pid",
                "--logging.structured.json.exclude=process.thread.name,ecs.version");
        run("5. logstash", List.of(), "--logging.structured.format.console=logstash");
        run("6. gelf", List.of(), "--logging.structured.format.console=gelf");
        run("7. исключение в ECS: корневая причина первой, длина ограничена", List.of("-Dlab.error=true"),
                "--logging.structured.format.console=ecs", "--logging.structured.json.stacktrace.root=first",
                "--logging.structured.json.stacktrace.max-length=300");
        run("8. MDC в шаблоне: applicationId", List.of(), "--logging.pattern.correlation=[%X{applicationId:-}] ");
        run("9. MDC и @Async с TaskDecorator", List.of(), "--logging.pattern.correlation=[%X{applicationId:-}] ", "--lab.mdc-decorator=true");
        long t = System.nanoTime(); exec(List.of("-Dlab.no-close=true"));
        System.out.println("== 11. без закрытия контекста в main: процесс завершился через " + (System.nanoTime() - t) / 1_000_000 + " мс");
        runCount("10. logging.level.org.springframework=debug", "--logging.level.org.springframework=debug");
    }

    static String exec(List<String> jvm, String... args) throws Exception {
        List<String> cmd = new ArrayList<>(List.of("java", "-Dstdout.encoding=UTF-8", "-cp", System.getProperty("java.class.path")));
        cmd.addAll(jvm);
        cmd.add(ScoringApp.class.getName());
        cmd.addAll(List.of(args));
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).directory(new File(".")).start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        p.waitFor();
        return out;
    }

    static void run(String label, List<String> jvm, String... args) throws Exception {
        System.out.println("== " + label);
        for (String line : exec(jvm, args).split("\\R"))
            if (!line.isBlank()) System.out.println("   " + line);
    }

    static void runCount(String label, String... args) throws Exception {
        System.out.println("== " + label);
        String[] lines = exec(List.of(), args).split("\\R");
        long report = java.util.Arrays.stream(lines).filter(l -> l.contains("CONDITIONS EVALUATION REPORT")).count();
        long debug = java.util.Arrays.stream(lines).filter(l -> l.contains(" DEBUG ")).count();
        System.out.println("   строк журнала: " + lines.length + ", из них DEBUG: " + debug + ", отчёт условий напечатан: " + (report > 0));
    }
}
