package dev.team.credit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Приложение опыта разд. 9: скоринг кредитных заявок Тундра-Банка.
 * Пишет в журнал через SLF4J, java.util.logging, Log4j API и Commons Logging; LogLab запускает его с разными настройками.
 */
@SpringBootApplication
@EnableAsync
public class ScoringApp {

    private static final Logger log = LoggerFactory.getLogger(ScoringApp.class);

    @Service
    static class BureauClient {
        private static final Logger log = LoggerFactory.getLogger(BureauClient.class);

        @Async
        public CompletableFuture<Integer> requestScore(String applicationId) {
            log.info("запрос в бюро кредитных историй по заявке {}", applicationId);
            return CompletableFuture.completedFuture(712);
        }
    }

    /** Переносит MDC вызывающего потока в поток исполнителя @Async. */
    @Bean
    @ConditionalOnProperty("lab.mdc-decorator")
    TaskDecorator mdcDecorator() {
        return task -> {
            Map<String, String> ctx = MDC.getCopyOfContextMap();
            return () -> {
                if (ctx != null) MDC.setContextMap(ctx);
                try { task.run(); } finally { MDC.clear(); }
            };
        };
    }

    @Bean
    ApplicationRunner score(BureauClient bureau) {
        return args -> {
            MDC.put("applicationId", "CR-2026-000154");
            try {
                log.info("заявка принята на скоринг, сумма 450000.00 RUB");
                log.debug("подробности скоринга: срок 36 мес., ставка 21.9%");
                LoggerFactory.getLogger("dev.team.scoring.Rules").debug("правило DTI сработало: 0.41");
                java.util.logging.Logger.getLogger("com.vendor.antifraud.Engine").info("антифрод: риск низкий (JUL)");
                org.apache.logging.log4j.LogManager.getLogger("com.vendor.bki.Client").info("ответ БКИ получен (Log4j API)");
                org.apache.commons.logging.LogFactory.getLog("com.vendor.legacy.Core").info("старый модуль ответил (Commons Logging)");
                int score = bureau.requestScore("CR-2026-000154").get();
                log.info("скоринговый балл {}", score);
                if (Boolean.getBoolean("lab.error"))
                    log.error("отказ сервиса решений", new IllegalStateException("decision engine timeout",
                            new java.net.SocketTimeoutException("Read timed out")));
            } finally {
                MDC.clear();
            }
        };
    }

    public static void main(String[] args) {
        var app = new SpringApplication(ScoringApp.class);
        if (Boolean.getBoolean("lab.jfr")) app.setApplicationStartup(new org.springframework.core.metrics.jfr.FlightRecorderApplicationStartup());
        var ctx = app.run(args);
        if (!Boolean.getBoolean("lab.no-close")) ctx.close();
    }
}
