# Журнал Spring Boot: уровни и группы, структурные форматы ECS, logstash и GELF, MDC в пуле задач, JFR на старте

Стенд к главе 10, раздел о журналировании. Ведущий `LogLab` запускает приложение `ScoringApp` (кредитный скоринг, Spring Boot 4.1.1, Logback) отдельными процессами в одиннадцати режимах: без настроек, уровень DEBUG для пакета и группа логгеров, структурный журнал в ECS, logstash и GELF с добавлением и исключением полей, запись исключения, MDC в шаблоне с декоратором задач и без, выход без закрытия контекста, `logging.level.org.springframework=debug`. Отдельно: тот же класс, скомпилированный под Java 17 и запущенный на Temurin 17 (`s10-java17.txt`), и запись шагов старта в JFR (`s10-jfr.txt`). Вывод автора - `s10-logging.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q package -DskipTests && mvn -q exec:java -Dexec.mainClass=dev.team.credit.LogLab
```

Один режим вручную, например ECS: `java -jar target/credit-scoring-logging-*.jar --logging.structured.format.console=ecs`. В IDEA есть конфигурации `LogLab` и `ScoringApp`.

## Что должно получиться

Одиннадцать блоков `== N.` с первой строкой журнала в каждом формате; в режиме без декоратора задач поле MDC в фоновом потоке пустое, с декоратором - перенесено.
