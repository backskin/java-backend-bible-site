#!/bin/bash
# Опыт гл. 30: Redis Streams как брокер. Сервер: docker run -d --name rd30 -p 6379:6379 redis:8
r(){ echo "> $*"; docker exec rd30 redis-cli "$@"; }
docker exec rd30 redis-server --version
r DEL payments
r XADD payments '*' id P-1 amount 1500
r XADD payments '*' id P-2 amount 700
echo "> XADD payments * id P-3 amount 90000"; ID3=$(docker exec rd30 redis-cli XADD payments '*' id P-3 amount 90000); echo $ID3
r XGROUP CREATE payments antifraud 0
echo "# worker-1 берёт два сообщения и падает до XACK"
r XREADGROUP GROUP antifraud worker-1 COUNT 2 STREAMS payments '>'
echo "# worker-2 читает новые: получит только P-3"
r XREADGROUP GROUP antifraud worker-2 COUNT 10 STREAMS payments '>'
echo "# worker-2 обработал P-3 и подтвердил"; r XACK payments antifraud $ID3
echo "# висящие (pending) сообщения группы"
r XPENDING payments antifraud - + 10
sleep 2
echo "# worker-2 забирает зависшие дольше 1000 мс"
r XAUTOCLAIM payments antifraud worker-2 1000 0 COUNT 10
r XPENDING payments antifraud - + 10
echo "# вторая группа читает поток с начала независимо"
r XGROUP CREATE payments ledger 0
r XREADGROUP GROUP ledger l-1 COUNT 10 STREAMS payments '>'
r XLEN payments
echo "# после XACK запись остаётся в потоке; удаление — XDEL/XTRIM или XACKDEL (Redis 8.2+)"
r XACKDEL payments antifraud KEEPREF IDS 1 $(docker exec rd30 redis-cli XRANGE payments - + COUNT 1 | head -1)
r XLEN payments
echo "# список как очередь: RPOP удаляет сразу, LMOVE перекладывает в список «в работе»"
r DEL jobs jobs:processing
r LPUSH jobs J-1 J-2
r RPOP jobs
r LMOVE jobs jobs:processing RIGHT LEFT
r LRANGE jobs:processing 0 -1
