# Redis Streams как брокер: группы потребителей, XREADGROUP, XACK, XPENDING и XAUTOCLAIM

Стенд к главе 30, раздел о Redis Streams. `redis-streams.sh` командами `redis-cli` в контейнере `redis:8` разыгрывает сценарий антифрода: три платежа в потоке, группа `antifraud`, `worker-1` берет два сообщения и "падает" до `XACK`, `worker-2` читает новые, подтверждает свое, смотрит зависшие через `XPENDING` и забирает их `XAUTOCLAIM` через секунду; вторая группа `ledger` читает поток с начала независимо. Вывод автора - `s30-redis-streams.txt` (Redis 8.10.3). Программ Java нет.

## Что нужно

- Docker, bash.

## Запуск

```bash
docker run -d --name rd30 -p 6379:6379 redis:8 && bash redis-streams.sh
```

В IDEA есть Shell-конфигурация `redis-streams`.

## Что должно получиться

После падения `worker-1` его два сообщения висят в `XPENDING`, пока `XAUTOCLAIM` не передаст их `worker-2`; после `XACK` запись остается в потоке (`XLEN` не меняется), удаление - `XDEL`, `XTRIM` или `XACKDEL` в Redis 8.2+.
