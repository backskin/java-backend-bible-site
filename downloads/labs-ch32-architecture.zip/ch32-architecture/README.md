# Пакетная структура, ArchUnit и Spring Modulith

Стенд к главе 32, раздел 6. Учебный сервис карт `com.bank.cards` (модули `shared`, `issuing`, `limits`) разложен по модулям предметной области с пакетной видимостью реализаций; рядом лежат пакет `com.bank.bad` с намеренными нарушениями и приложение `com.bank.badmod`, где один модуль обращается к внутренностям другого.

## Что нужно

- JDK 21 и Maven 3.9; Docker и база не нужны.

## Запуск

```bash
mvn -q test
```

Тесты ничего не проверяют утверждениями, а печатают результаты опыта:

- `ArchitectureRulesTest` - восемь правил ArchUnit на чистом сервисе и на пакете с нарушениями; видно, какое правило что нашло и какие правила падают с сообщением `failed to check any classes`, если под них не попал ни один класс;
- `FreezeAndModulithTest` - заморозка нарушений `FreezingArchRule` (без разрешения на хранилище, первый прогон, повтор, новое нарушение), проверка `ApplicationModules.verify()` для двух приложений и время и память импорта классов;
- `PackagePrivateBeanTest` - Spring создаёт бин из класса без модификатора `public`.

Отдельно проверяется, что подпакет не видит класс с пакетной видимостью родительского пакета (компиляция должна упасть):

```bash
mvn -q compile
javac -encoding UTF-8 -cp target/classes -d target/check src/check/java/com/bank/cards/limits/internal/UsesParent.java
```

Выводы, приведённые в главе, лежат в `s32-architecture.txt` и `s32-package-private.txt`.

## Версии

Spring Boot 4.1.2, Spring Modulith 2.1.2, ArchUnit 1.5.1, Temurin 21.0.10.
