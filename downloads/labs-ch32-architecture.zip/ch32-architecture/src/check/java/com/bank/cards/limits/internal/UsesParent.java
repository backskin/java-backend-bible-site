package com.bank.cards.limits.internal;

import com.bank.cards.limits.LimitService;

/**
 * Опыт разд. 6.2: подпакет не видит класс с пакетной видимостью из родительского пакета.
 * Файл компилируется отдельно (см. README), и компиляция должна упасть.
 */
public class UsesParent {
    Object service = new LimitService();
}
