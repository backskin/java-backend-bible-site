package com.bank;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

import com.bank.badmod.BadModApplication;
import com.bank.cards.CardsApplication;
import com.tngtech.archunit.ArchConfiguration;
import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.library.freeze.FreezingArchRule;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import org.junit.jupiter.api.Test;
import org.springframework.modulith.core.ApplicationModules;

/**
 * Заморозка нарушений (FreezingArchRule) и проверка модулей Spring Modulith.
 * Заморозка: без разрешения создать хранилище правило падает; с разрешением первый прогон
 * записывает текущие нарушения и проходит; новое нарушение после этого валит правило.
 */
class FreezeAndModulithTest {

    static String firstLine(Throwable e) { return e.getClass().getSimpleName() + ": " + e.getMessage().lines().findFirst().orElse(""); }

    @Test
    void freezingArchRule() throws Exception {
        Path store = Path.of("target", "archunit_store");
        if (Files.exists(store)) try (var s = Files.walk(store)) { s.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete()); }
        var cfg = ArchConfiguration.get();
        cfg.setProperty("freeze.store.default.path", store.toString());

        ArchRule rule = noClasses().should().accessClassesThat().haveFullyQualifiedName("java.io.PrintStream");
        JavaClasses old = new ClassFileImporter().importPackages("com.bank.bad.web");
        JavaClasses withNew = new ClassFileImporter().importPackages("com.bank.bad.web", "com.bank.bad.newcode");

        System.out.println("== FreezingArchRule");
        System.out.println("  нарушений до заморозки: " + rule.evaluate(old).getFailureReport().getDetails().size());
        cfg.setProperty("freeze.store.default.allowStoreCreation", "false");
        try {
            FreezingArchRule.freeze(rule).check(old);
            System.out.println("  без разрешения на хранилище: прошло");
        } catch (Throwable e) {
            System.out.println("  без разрешения на хранилище: " + firstLine(e));
        }
        cfg.setProperty("freeze.store.default.allowStoreCreation", "true");
        FreezingArchRule.freeze(rule).check(old);
        System.out.println("  первый прогон с разрешением: прошло, файлов в хранилище: " + Files.list(store).count());
        FreezingArchRule.freeze(rule).check(old);
        System.out.println("  повторный прогон на тех же классах: прошло");
        try {
            FreezingArchRule.freeze(rule).check(withNew);
            System.out.println("  после добавления класса с новым нарушением: прошло");
        } catch (Throwable e) {
            System.out.println("  после добавления класса с новым нарушением: " + firstLine(e));
        }
        cfg.reset();
    }

    @Test
    void modulith() {
        System.out.println("== Spring Modulith");
        var good = ApplicationModules.of(CardsApplication.class);
        good.forEach(m -> System.out.println("  модуль " + m.getIdentifier() + ", базовый пакет " + m.getBasePackage().getName()));
        try {
            good.verify();
            System.out.println("  CardsApplication: verify() прошло");
        } catch (Throwable e) {
            System.out.println("  CardsApplication: " + firstLine(e));
        }
        try {
            ApplicationModules.of(BadModApplication.class).verify();
            System.out.println("  BadModApplication: verify() прошло");
        } catch (Throwable e) {
            System.out.println("  BadModApplication: " + e.getClass().getSimpleName());
            e.getMessage().lines().limit(3).forEach(l -> System.out.println("    " + l));
        }
    }

    @Test
    void importCost() {
        System.out.println("== стоимость импорта");
        for (String pkg : new String[]{"com.bank", "org.springframework"}) {
            System.gc();
            long before = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            long t0 = System.nanoTime();
            JavaClasses c = new ClassFileImporter().withImportOption(ImportOption.Predefined.DO_NOT_INCLUDE_TESTS).importPackages(pkg);
            long ms = (System.nanoTime() - t0) / 1_000_000;
            long after = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            System.out.println("  " + pkg + ": классов " + c.size() + ", " + ms + " мс, прирост кучи ~" + (after - before) / (1024 * 1024) + " МБ");
        }
        System.out.println("  java " + System.getProperty("java.version") + ", -Xmx " + Runtime.getRuntime().maxMemory() / (1024 * 1024) + " МБ");
    }
}
