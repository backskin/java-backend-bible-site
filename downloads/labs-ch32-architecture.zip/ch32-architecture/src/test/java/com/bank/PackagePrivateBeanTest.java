package com.bank;

import com.bank.cards.CardsApplication;
import com.bank.cards.issuing.IssueCard;
import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;

/** Spring создаёт бины из классов с пакетной видимостью и внедряет их через публичный интерфейс. */
class PackagePrivateBeanTest {

    @Test
    void packagePrivateServicesAreBeans() {
        try (var ctx = new SpringApplication(CardsApplication.class).run("--spring.main.banner-mode=off", "--logging.level.root=warn")) {
            IssueCard issue = ctx.getBean(IssueCard.class);
            System.out.println("== бины с пакетной видимостью");
            System.out.println("  класс бина IssueCard: " + issue.getClass().getName()
                    + ", public: " + java.lang.reflect.Modifier.isPublic(issue.getClass().getModifiers()));
            System.out.println("  issue(\"client-7\") = " + issue.issue("client-7"));
        }
    }
}
