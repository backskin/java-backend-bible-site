package com.bank;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noFields;
import static com.tngtech.archunit.library.dependencies.SlicesRuleDefinition.slices;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.EvaluationResult;
import com.tngtech.archunit.library.GeneralCodingRules;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

/**
 * Правила зависимостей из разд. 6 главы 32, прогнанные на двух наборах классов:
 * чистом сервисе карт (com.bank.cards) и пакете с намеренными нарушениями (com.bank.bad).
 * Тест ничего не утверждает, а печатает, какое правило что нашло: вывод - это результат опыта.
 */
class ArchitectureRulesTest {

    static final Map<String, ArchRule> RULES = new LinkedHashMap<>();
    static {
        RULES.put("предметная область без Spring, JPA, Jackson", noClasses().that().resideInAPackage("..domain..")
                .should().dependOnClassesThat().resideInAnyPackage("org.springframework..", "jakarta.persistence..",
                        "com.fasterxml.jackson..", "org.hibernate.."));
        RULES.put("контроллер не обращается к репозиторию", noClasses().that().resideInAPackage("..web..")
                .should().dependOnClassesThat().haveSimpleNameEndingWith("Repository"));
        RULES.put("нет циклов между пакетами", slices().matching("com.bank.(*).(*)..").should().beFreeOfCycles());
        RULES.put("shared зависит только от JDK", classes().that().resideInAPackage("..shared..")
                .should().onlyDependOnClassesThat().resideInAnyPackage("java..", "..shared.."));
        RULES.put("нет инъекции в поля", GeneralCodingRules.NO_CLASSES_SHOULD_USE_FIELD_INJECTION);
        RULES.put("нет System.out и System.err", GeneralCodingRules.NO_CLASSES_SHOULD_ACCESS_STANDARD_STREAMS);
        RULES.put("нет java.util.Date", noClasses().should().dependOnClassesThat().belongToAnyOf(java.util.Date.class));
        RULES.put("деньги не в double", noFields().that().haveNameMatching(".*(amount|balance|fee).*")
                .should().haveRawType(double.class));
    }

    static void run(String title, String pkg) {
        JavaClasses classes = new ClassFileImporter().withImportOption(ImportOption.Predefined.DO_NOT_INCLUDE_TESTS).importPackages(pkg);
        System.out.println("== " + title + " (" + pkg + ", классов: " + classes.size() + ")");
        RULES.forEach((name, rule) -> {
            String verdict;
            try {
                EvaluationResult r = rule.evaluate(classes);
                verdict = r.hasViolation()
                        ? "нарушений " + r.getFailureReport().getDetails().size() + ": " + r.getFailureReport().getDetails().get(0)
                        : "ok";
            } catch (AssertionError | RuntimeException e) {
                verdict = "ошибка правила: " + e.getMessage().lines().findFirst().orElse("");
            }
            System.out.println("  " + name + " -> " + verdict);
        });
    }

    @Test
    void rulesOnCleanAndBrokenPackages() {
        run("чистый сервис карт", "com.bank.cards");
        run("пакет с нарушениями", "com.bank.bad");
    }
}
