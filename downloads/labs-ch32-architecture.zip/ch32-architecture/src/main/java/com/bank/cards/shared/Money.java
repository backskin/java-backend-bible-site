package com.bank.cards.shared;

import java.math.BigDecimal;

/** Общий тип без зависимостей, кроме JDK. */
public record Money(BigDecimal amount, String currency) {
}
