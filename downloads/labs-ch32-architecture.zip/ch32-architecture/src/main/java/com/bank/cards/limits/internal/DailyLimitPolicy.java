package com.bank.cards.limits.internal;

import com.bank.cards.shared.Money;
import java.math.BigDecimal;

/** Внутренний класс модуля: public, иначе его не увидит LimitService из родительского пакета. */
public class DailyLimitPolicy {
    public boolean fits(Money m) { return m.amount().compareTo(new BigDecimal("300000")) <= 0; }
}
