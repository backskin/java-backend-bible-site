package com.bank.cards.issuing;

/** Публичный API модуля выпуска карт. */
public interface IssueCard {
    String issue(String clientId);
}
