package com.bank.badmod;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BadModApplication {
}
