package com.bank.badmod.payments.internal;

/** Внутренность модуля payments. */
public class FeeTable {
    public static int feeFor(String product) { return product.length(); }
}
