package com.bank.bad.newcode;

/** Новое нарушение, появившееся после заморозки: печать в System.out. */
public class NewReport {
    public void print(String line) { System.out.println(line); }
}
