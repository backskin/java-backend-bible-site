package com.bank.bad.web;

import com.bank.bad.repo.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;

/** Нарушения: контроллер ходит в репозиторий, инъекция в поле, System.out. */
public class CardController {
    @Autowired
    private CardRepository repository;

    public String get(String id) {
        System.out.println("get " + id);
        return repository.find(id);
    }
}
