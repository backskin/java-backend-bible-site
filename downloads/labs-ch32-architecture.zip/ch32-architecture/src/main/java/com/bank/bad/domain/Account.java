package com.bank.bad.domain;

import java.util.Date;
import org.springframework.stereotype.Component;

/** Нарушения: предметная область зависит от Spring, деньги в double, java.util.Date. */
@Component
public class Account {
    private double balance;
    private Date openedAt = new Date();

    public double balance() { return balance; }
    public Date openedAt() { return openedAt; }

    /** Слепое пятно: зависимость от Spring через строку правило не видит. */
    public Object springByName() throws Exception {
        return Class.forName("org.springframework.context.support.GenericApplicationContext").getDeclaredConstructor().newInstance();
    }
}
