package com.bank.cards.limits;

import com.bank.cards.shared.Money;

/** Публичный API модуля лимитов. */
public interface CheckLimit {
    boolean allows(String cardId, Money amount);
}
