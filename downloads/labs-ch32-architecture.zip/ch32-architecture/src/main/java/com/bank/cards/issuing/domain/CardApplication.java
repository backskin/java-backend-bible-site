package com.bank.cards.issuing.domain;

/** Предметная область без импортов фреймворков. */
public record CardApplication(String clientId, String cardId) {
    public static CardApplication open(String clientId) { return new CardApplication(clientId, "card-" + clientId); }
}
