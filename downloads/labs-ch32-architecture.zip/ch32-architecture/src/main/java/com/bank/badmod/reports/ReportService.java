package com.bank.badmod.reports;

import com.bank.badmod.payments.internal.FeeTable;

/** Нарушение: модуль reports обращается к внутреннему пакету модуля payments. */
public class ReportService {
    public int fee() { return FeeTable.feeFor("sbp"); }
}
