package com.bank.bad.a;

import com.bank.bad.b.B;

public class A { B b; }
