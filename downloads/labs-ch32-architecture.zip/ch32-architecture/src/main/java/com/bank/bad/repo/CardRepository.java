package com.bank.bad.repo;

public class CardRepository {
    public String find(String id) { return id; }
}
