package com.bank.cards.limits;

import com.bank.cards.limits.internal.DailyLimitPolicy;
import com.bank.cards.shared.Money;
import org.springframework.stereotype.Service;

/** Реализация видна только внутри пакета; Spring всё равно создаёт бин. */
@Service
class LimitService implements CheckLimit {
    private final DailyLimitPolicy policy = new DailyLimitPolicy();

    LimitService() { }

    @Override public boolean allows(String cardId, Money amount) { return policy.fits(amount); }
}
