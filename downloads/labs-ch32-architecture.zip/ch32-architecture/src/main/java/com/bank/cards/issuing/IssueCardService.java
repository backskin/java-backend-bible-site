package com.bank.cards.issuing;

import com.bank.cards.issuing.domain.CardApplication;
import com.bank.cards.limits.CheckLimit;
import com.bank.cards.shared.Money;
import java.math.BigDecimal;
import org.springframework.stereotype.Service;

/** Обращается к лимитам только через их публичный API. */
@Service
class IssueCardService implements IssueCard {
    private final CheckLimit limits;

    IssueCardService(CheckLimit limits) { this.limits = limits; }

    @Override public String issue(String clientId) {
        var app = CardApplication.open(clientId);
        return limits.allows(app.cardId(), new Money(new BigDecimal("1000"), "RUB")) ? app.cardId() : "отказ";
    }
}
