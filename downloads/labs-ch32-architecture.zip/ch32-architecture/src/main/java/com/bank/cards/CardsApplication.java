package com.bank.cards;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Учебный сервис карт: прямые подпакеты - модули (shared, issuing, limits). */
@SpringBootApplication
public class CardsApplication {
}
