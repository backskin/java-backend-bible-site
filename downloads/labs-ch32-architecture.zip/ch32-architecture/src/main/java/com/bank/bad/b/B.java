package com.bank.bad.b;

import com.bank.bad.a.A;

public class B { A a; }
