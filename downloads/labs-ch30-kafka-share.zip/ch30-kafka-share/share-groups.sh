#!/bin/bash
# Опыт гл. 30: очередь поверх Kafka — share groups (KIP-932). Брокер: docker run -d --name k30 apache/kafka:4.2.0
export MSYS_NO_PATHCONV=1
B=/opt/kafka/bin
k(){ docker exec k30 "$@"; }
echo '$ kafka-features.sh describe (строка share.version)'
k $B/kafka-features.sh --bootstrap-server localhost:9092 describe | grep -i share
k $B/kafka-topics.sh --bootstrap-server localhost:9092 --create --if-not-exists --topic payments2 --partitions 1 >/dev/null
for c in a b; do
  docker exec -d k30 sh -c "$B/kafka-console-share-consumer.sh --bootstrap-server localhost:9092 --topic payments2 --group settle2 --timeout-ms 60000 > /tmp/share-$c.txt 2>&1"
done
sleep 10
k sh -c "for i in \$(seq 1 20000); do echo \"платёж \$i\"; done | $B/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic payments2"
sleep 40
for c in a b; do
  echo "# потребитель $c группы settle, топик из одной партиции:"
  k sh -c "grep -c 'платёж' /tmp/share-$c.txt"
done
echo '$ kafka-share-groups.sh --describe --group settle'
k $B/kafka-share-groups.sh --bootstrap-server localhost:9092 --describe --group settle2 2>&1 | head -5
