import java.time.*;

/** Переходы 2016 года в российских зонах по tzdata JDK. Запуск: java Russia2016.java */
public class Russia2016 {
    public static void main(String[] args) {
        for (String z : new String[]{"Europe/Astrakhan", "Europe/Ulyanovsk", "Europe/Saratov", "Asia/Novosibirsk", "Asia/Tomsk", "Asia/Barnaul", "Asia/Chita", "Asia/Magadan", "Asia/Sakhalin"})
            ZoneId.of(z).getRules().getTransitions().stream()
                .filter(t -> t.getInstant().isAfter(Instant.parse("2015-01-01T00:00:00Z")))
                .forEach(t -> System.out.println(z + " " + t));
    }
}
