# Время в Java: java.time, переходы поясов, week-year, cron при переводе часов

Стенд к главе 04, разделы 1–5. `TimeLab` - типы `java.time`, арифметика, `Clock`, форматирование, старые `Date` и `Calendar` (программа большая, блоки пронумерованы как в главе); `Russia2016` - переходы поясов Астрахани и Ульяновска в 2016 году из tzdata JDK; `WeekYear` - ловушка `YYYY` против `yyyy` в разных локалях; `NanoCost` - стоимость `System.nanoTime()` и `Instant.now()`; `sched/` - проект Maven, где `DstSched` показывает, как `CronTrigger` Spring и `CronExpression` Quartz ведут себя в ночь перевода часов. Выводы автора - `s04-*.txt`.

## Что нужно

- JDK 21 (для сравнения 25); для `sched/` - Maven.

## Запуск

```bash
java -Dstdout.encoding=UTF-8 TimeLab.java
```

```bash
cd sched && mvn -q compile exec:java -Dexec.mainClass=dev.team.ch04.DstSched
```

В IDEA на каждую программу есть конфигурация `java <Класс>.java`, на `sched` - конфигурация Maven.

## Что должно получиться

`TimeLab` печатает предупреждение компилятора о `Date.getHours()`, это намеренно: программа показывает устаревшее API. Вывод `WeekYear` зависит от локали по умолчанию только в первой строке, дальше локали заданы явно.
