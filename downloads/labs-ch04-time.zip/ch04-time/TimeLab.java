import java.lang.reflect.Modifier;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.chrono.ThaiBuddhistDate;
import java.time.format.*;
import java.time.temporal.*;
import java.time.zone.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Опыты главы 04 о времени. Запуск: java TimeLab.java (JDK 21 и 25, без зависимостей).
 * Каждый блок печатает заголовок и результаты; вывод сохраняется в s04-time-jdkNN.txt.
 */
public class TimeLab {

    static void h(String s) { System.out.println("--- " + s); }

    public static void main(String[] args) throws Exception {
        System.out.println("java.version=" + System.getProperty("java.version"));

        h("1. tzdata и число зон");
        System.out.println("версия tzdata: " + ZoneRulesProvider.getVersions("Europe/Moscow").lastEntry().getKey());
        System.out.println("зон: " + ZoneId.getAvailableZoneIds().size());
        System.out.println("SHORT_IDS EST -> " + ZoneId.SHORT_IDS.get("EST") + ", CST -> " + ZoneId.SHORT_IDS.get("CST"));

        h("2. Москва: смещения и переходы с 2009 года");
        ZoneRules msk = ZoneId.of("Europe/Moscow").getRules();
        System.out.println("2013-07-01: " + msk.getOffset(Instant.parse("2013-07-01T00:00:00Z")));
        System.out.println("2015-07-01: " + msk.getOffset(Instant.parse("2015-07-01T00:00:00Z")));
        msk.getTransitions().stream()
                .filter(t -> t.getInstant().isAfter(Instant.parse("2009-01-01T00:00:00Z")))
                .forEach(System.out::println);
        System.out.println("getTransitionRules: " + msk.getTransitionRules());
        ZoneRules samara = ZoneId.of("Europe/Samara").getRules();
        samara.getTransitions().stream()
                .filter(t -> t.getInstant().isAfter(Instant.parse("2009-01-01T00:00:00Z")))
                .forEach(t -> System.out.println("Samara " + t));

        h("3. Самоа 2011");
        ZoneId apia = ZoneId.of("Pacific/Apia");
        LocalDate thu = LocalDate.of(2011, 12, 29), sat = LocalDate.of(2011, 12, 31);
        System.out.println(ChronoUnit.DAYS.between(thu, sat));
        System.out.println(Duration.between(thu.atStartOfDay(apia), sat.atStartOfDay(apia)));
        System.out.println(LocalDate.of(2011, 12, 30).atStartOfDay(apia));
        System.out.println(apia.getRules().getValidOffsets(LocalDateTime.of(2011, 12, 30, 12, 0)));

        h("4. Берлин: разрыв и перекрытие");
        ZoneId berlin = ZoneId.of("Europe/Berlin");
        LocalDateTime gapT = LocalDateTime.of(2024, 3, 31, 2, 30), ovT = LocalDateTime.of(2024, 10, 27, 2, 30);
        System.out.println("gap atZone: " + gapT.atZone(berlin));
        System.out.println("overlap atZone: " + ovT.atZone(berlin));
        System.out.println("validOffsets gap: " + berlin.getRules().getValidOffsets(gapT)
                + ", transition " + berlin.getRules().getTransition(gapT));
        System.out.println("validOffsets overlap: " + berlin.getRules().getValidOffsets(ovT));
        System.out.println("validOffsets обычное: " + berlin.getRules().getValidOffsets(LocalDateTime.of(2024, 6, 1, 2, 30)));
        ZonedDateTime e = ovT.atZone(berlin).withEarlierOffsetAtOverlap(), l = ovT.atZone(berlin).withLaterOffsetAtOverlap();
        System.out.println("earlier " + e + " later " + l + " разница " + Duration.between(e, l));
        System.out.println("ZonedDateTime.ofStrict gap: " + tryIt(() -> ZonedDateTime.ofStrict(gapT, ZoneOffset.ofHours(1), berlin)));
        System.out.println("withLaterOffsetAtOverlap в обычное время: " + LocalDateTime.of(2024, 6, 1, 2, 30).atZone(berlin).withLaterOffsetAtOverlap());

        h("5. Сан-Паулу 2018-11-04: полночь в день перехода");
        LocalDate d = LocalDate.of(2018, 11, 4);
        ZoneId sp = ZoneId.of("America/Sao_Paulo");
        System.out.println(d.atStartOfDay() + " | " + d.atStartOfDay(sp));
        System.out.println("ZonedDateTime.of(d, 00:00): " + ZonedDateTime.of(d, LocalTime.MIDNIGHT, sp));

        h("6. plusDays(1) и plusHours(24)");
        ZonedDateTime spring = ZonedDateTime.of(2024, 3, 30, 12, 0, 0, 0, berlin);
        System.out.println(spring.plusDays(1) + " | " + spring.plusHours(24) + " | реально прошло " + Duration.between(spring, spring.plusDays(1)));
        ZonedDateTime autumn = ZonedDateTime.of(2024, 10, 26, 12, 0, 0, 0, berlin);
        System.out.println(autumn.plusDays(1) + " | " + autumn.plusHours(24) + " | реально прошло " + Duration.between(autumn, autumn.plusDays(1)));

        h("7. Месяцы и периоды");
        LocalDate jan31 = LocalDate.of(2024, 1, 31);
        System.out.println(jan31.plus(Period.ofMonths(1)) + " " + jan31.plusMonths(1).plusMonths(1) + " " + jan31.plusMonths(2));
        List<LocalDate> acc = new ArrayList<>(), fromStart = new ArrayList<>();
        LocalDate cur = jan31;
        for (int i = 0; i < 4; i++) { acc.add(cur); cur = cur.plusMonths(1); fromStart.add(jan31.plusMonths(i)); }
        System.out.println("накопительно: " + acc + "\nот начала:    " + fromStart);
        LocalDate a = LocalDate.of(2024, 1, 31), b = LocalDate.of(2024, 3, 1);
        System.out.println(Period.between(a, b) + " " + ChronoUnit.DAYS.between(a, b));
        LocalDate born = LocalDate.of(2000, 2, 29);
        System.out.println("возраст 2023-02-28: " + Period.between(born, LocalDate.of(2023, 2, 28)).getYears()
                + ", 2023-03-01: " + Period.between(born, LocalDate.of(2023, 3, 1)).getYears()
                + ", YEARS.between: " + ChronoUnit.YEARS.between(born, LocalDate.of(2023, 2, 28)));
        System.out.println("LocalDate.plus(Duration): " + tryIt(() -> LocalDate.of(2024, 1, 1).plus(Duration.ofDays(1))));
        System.out.println("Duration.ofDays(1).getSeconds(): " + Duration.ofDays(1).getSeconds());
        System.out.println("Duration.parse(PT15M)=" + Duration.parse("PT15M") + ", Period.parse(P1M)=" + Period.parse("P1M")
                + ", Duration.parse(P1M): " + tryIt(() -> Duration.parse("P1M")));

        h("8. ChronoUnit и truncatedTo");
        Instant ia = Instant.parse("2026-01-01T00:00:00Z"), ib = Instant.parse("2026-09-21T13:45:00Z");
        System.out.println(ChronoUnit.DAYS.between(ia, ib) + " " + ChronoUnit.HOURS.between(ia, ib)
                + " MONTHS: " + tryIt(() -> ChronoUnit.MONTHS.between(ia, ib)));
        System.out.println("10:00 -> 11:59 HOURS = " + ChronoUnit.HOURS.between(LocalTime.of(10, 0), LocalTime.of(11, 59)));
        System.out.println("Instant.truncatedTo(DAYS) " + ib.truncatedTo(ChronoUnit.DAYS)
                + ", MONTHS: " + tryIt(() -> ib.truncatedTo(ChronoUnit.MONTHS)));
        System.out.println("Сан-Паулу truncatedTo(DAYS) 2018-11-04T10:00: "
                + ZonedDateTime.of(2018, 11, 4, 10, 0, 0, 0, sp).truncatedTo(ChronoUnit.DAYS));

        h("9. TemporalAdjusters");
        LocalDate x = LocalDate.of(2026, 9, 21);
        System.out.println(x.getDayOfWeek() + " " + x.with(TemporalAdjusters.lastDayOfMonth()) + " "
                + x.with(TemporalAdjusters.firstDayOfNextMonth()) + " " + x.with(TemporalAdjusters.next(DayOfWeek.FRIDAY)) + " "
                + x.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY)) + " "
                + x.with(TemporalAdjusters.dayOfWeekInMonth(3, DayOfWeek.WEDNESDAY)) + " "
                + x.with(TemporalAdjusters.lastInMonth(DayOfWeek.FRIDAY)));

        h("10. Частичные типы");
        YearMonth card = YearMonth.of(2027, 11);
        System.out.println(card.atEndOfMonth() + " " + MonthDay.of(Month.FEBRUARY, 29).atYear(2024) + " "
                + MonthDay.of(Month.FEBRUARY, 29).atYear(2025) + " 2100 leap=" + Year.of(2100).isLeap() + " 2000 leap=" + Year.of(2000).isLeap());

        h("11. OffsetDateTime и equals");
        OffsetDateTime odt = OffsetDateTime.parse("2024-03-01T12:00+01:00");
        System.out.println(odt.plusMonths(1) + " | " + odt.atZoneSameInstant(berlin).plusMonths(1));
        OffsetDateTime o1 = OffsetDateTime.parse("2024-01-01T12:00+01:00"), o2 = OffsetDateTime.parse("2024-01-01T11:00Z");
        System.out.println("equals=" + o1.equals(o2) + " isEqual=" + o1.isEqual(o2) + " compareTo=" + o1.compareTo(o2));
        ZonedDateTime zm = ZonedDateTime.of(2024, 6, 1, 12, 0, 0, 0, ZoneId.of("Europe/Moscow"));
        ZonedDateTime zi = ZonedDateTime.of(2024, 6, 1, 12, 0, 0, 0, ZoneId.of("Europe/Istanbul"));
        System.out.println("Moscow vs Istanbul equals=" + zm.equals(zi) + " isEqual=" + zm.isEqual(zi));

        h("12. Точность Instant.now()");
        int nonMilli = 0;
        for (int i = 0; i < 1000; i++) if (Instant.now().getNano() % 1_000_000 != 0) nonMilli++;
        Instant t = Instant.now();
        System.out.println("из 1000 вызовов с долями мельче мс: " + nonMilli + ", пример " + t
                + ", equals после truncatedTo(MICROS): " + t.equals(t.truncatedTo(ChronoUnit.MICROS)));
        System.out.println("Instant.MIN " + Instant.MIN + " MAX " + Instant.MAX);

        h("13. Буква Y");
        System.out.println(LocalDate.of(2025, 12, 29).format(DateTimeFormatter.ofPattern("YYYY-MM-dd")) + " "
                + LocalDate.of(2025, 12, 29).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " "
                + LocalDate.of(2021, 1, 3).format(DateTimeFormatter.ofPattern("YYYY-MM-dd")) + " "
                + LocalDate.of(2025, 12, 29).getDayOfWeek());
        System.out.println("HH:mm:SS в 18:26:09.93 -> " + LocalTime.of(18, 26, 9, 930_000_000).format(DateTimeFormatter.ofPattern("HH:mm:SS")));

        h("14. ResolverStyle");
        DateTimeFormatter strict = DateTimeFormatter.ofPattern("uuuu-MM-dd").withResolverStyle(ResolverStyle.STRICT);
        DateTimeFormatter smart = DateTimeFormatter.ofPattern("uuuu-MM-dd");
        DateTimeFormatter lenient = DateTimeFormatter.ofPattern("uuuu-MM-dd").withResolverStyle(ResolverStyle.LENIENT);
        System.out.println("по умолчанию: " + smart.getResolverStyle());
        System.out.println("02-30 strict: " + tryIt(() -> LocalDate.parse("2026-02-30", strict)));
        System.out.println("02-30 smart: " + tryIt(() -> LocalDate.parse("2026-02-30", smart)));
        System.out.println("02-30 lenient: " + tryIt(() -> LocalDate.parse("2026-02-30", lenient)));
        System.out.println("13-01 smart: " + tryIt(() -> LocalDate.parse("2026-13-01", smart)));
        System.out.println("13-01 lenient: " + tryIt(() -> LocalDate.parse("2026-13-01", lenient)));
        DateTimeFormatter strictY = DateTimeFormatter.ofPattern("yyyy-MM-dd").withResolverStyle(ResolverStyle.STRICT);
        System.out.println("strict yyyy: " + tryIt(() -> LocalDate.parse("2026-02-10", strictY)));

        h("15. Локаль в форматтере");
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd MMMM yyyy");
        LocalDate sep = LocalDate.of(2026, 9, 21);
        System.out.println(sep.format(f.withLocale(Locale.forLanguageTag("ru"))) + " | " + sep.format(f.withLocale(Locale.ENGLISH)));
        System.out.println("разбор ru-строки английским: " + tryIt(() -> LocalDate.parse("21 сентября 2026", f.withLocale(Locale.ENGLISH))));
        DateTimeFormatter iso = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        Locale thai = Locale.forLanguageTag("th-TH-u-ca-buddhist-nu-thai");
        System.out.println("withLocale(th-buddhist): " + sep.format(iso.withLocale(thai)));
        System.out.println("localizedBy(th-buddhist): " + sep.format(iso.localizedBy(thai)));
        System.out.println("ThaiBuddhistDate: " + ThaiBuddhistDate.from(sep));
        System.out.println("localizedBy(ar-EG): " + sep.format(iso.localizedBy(Locale.forLanguageTag("ar-EG"))));
        DateTimeFormatter loc = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
                .withLocale(Locale.forLanguageTag("ru")).withZone(ZoneId.of("Europe/Moscow"));
        System.out.println("MEDIUM ru: " + loc.format(Instant.parse("2026-09-21T13:45:00Z")));

        h("16. WeekFields");
        for (LocalDate wd : List.of(LocalDate.of(2026, 1, 1), LocalDate.of(2027, 1, 1)))
            System.out.println(wd + " " + wd.getDayOfWeek() + " ISO неделя " + wd.get(WeekFields.ISO.weekOfWeekBasedYear())
                    + " год " + wd.get(WeekFields.ISO.weekBasedYear())
                    + "; US неделя " + wd.get(WeekFields.of(Locale.US).weekOfWeekBasedYear()));

        h("17. RFC_1123 и GMT");
        Instant moment = Instant.parse("2026-09-21T13:45:00Z");
        DateTimeFormatter rfc = DateTimeFormatter.RFC_1123_DATE_TIME;
        System.out.println(rfc.format(moment.atZone(ZoneId.of("GMT"))) + " | " + rfc.format(moment.atOffset(ZoneOffset.UTC))
                + " | " + rfc.format(moment.atZone(ZoneId.of("Europe/Moscow"))));
        System.out.println("ZoneId.of(GMT).equals(UTC)=" + ZoneId.of("GMT").equals(ZoneOffset.UTC)
                + ", normalized=" + ZoneId.of("GMT").normalized() + ", Instant.toString=" + moment);
        System.out.println("ISO_ZONED: " + moment.atZone(ZoneId.of("Europe/Moscow")));

        h("18. Високосная секунда в разборе");
        DateTimeFormatter parser = DateTimeFormatter.ISO_INSTANT;
        TemporalAccessor parsed = parser.parse("2016-12-31T23:59:60Z");
        System.out.println(Instant.from(parsed) + " parsedLeapSecond=" + parsed.query(DateTimeFormatter.parsedLeapSecond()));
        System.out.println("Instant.parse(23:59:60): " + tryIt(() -> Instant.parse("2016-12-31T23:59:60Z")));

        h("19. GPS, Exchange, шлюз");
        Instant gpsEpoch = Instant.parse("1980-01-06T00:00:00Z");
        int wn = 2048 % 1024;
        System.out.println(gpsEpoch.plus(Duration.ofDays(7L * wn)).plusSeconds(3600) + " "
                + gpsEpoch.plus(Duration.ofDays(7L * (2 * 1024 + wn))).plusSeconds(3600));
        long version = 2201010001L;
        System.out.println(Integer.MAX_VALUE + " " + (int) version + " " + tryIt(() -> Math.toIntExact(version))
                + " " + tryIt(() -> Integer.parseInt("2201010001")));
        long rtt = (1_483_228_800_000L - 1_000) - 1_483_228_800_000L;
        System.out.println("rtt=" + rtt + " " + tryIt(() -> ThreadLocalRandom.current().nextLong(rtt)));

        h("20. epoch: секунды и миллисекунды");
        System.out.println(Instant.ofEpochSecond(1789045500L) + " " + Instant.ofEpochMilli(1789045500L) + " "
                + Instant.ofEpochMilli(1789045500000L) + " " + Instant.ofEpochSecond(1789045500000L));

        h("21. Старый API");
        TimeZone.setDefault(TimeZone.getTimeZone("Europe/Moscow"));
        Date zero = new Date(0);
        @SuppressWarnings("deprecation") String ym = zero.getYear() + " " + zero.getMonth();
        System.out.println(zero + " getYear/getMonth=" + ym);
        Calendar cal = new GregorianCalendar(2026, Calendar.JANUARY, 32);
        System.out.println("lenient 32 января: " + cal.getTime() + ", isLenient=" + cal.isLenient());
        java.sql.Date sd = java.sql.Date.valueOf("2026-09-21");
        System.out.println("java.sql.Date.getHours: " + tryIt(() -> sd.getHours()));
        java.sql.Timestamp ts = new java.sql.Timestamp(1_000);
        Date du = new Date(1_000);
        System.out.println("Timestamp.equals(Date)=" + ts.equals(du) + ", Date.equals(Timestamp)=" + du.equals(ts));
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

        h("22. Общий SimpleDateFormat в 8 потоках");
        SimpleDateFormat shared = new SimpleDateFormat("yyyy-MM-dd");
        shared.setTimeZone(TimeZone.getTimeZone("UTC"));
        String[] inputs = {"2024-03-15", "2019-11-02"};
        AtomicInteger wrong = new AtomicInteger(), errors = new AtomicInteger(), total = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(8);
        List<Future<?>> fs = new ArrayList<>();
        for (int th = 0; th < 8; th++) {
            final String in = inputs[th % 2];
            fs.add(pool.submit(() -> {
                SimpleDateFormat own = new SimpleDateFormat("yyyy-MM-dd");
                own.setTimeZone(TimeZone.getTimeZone("UTC"));
                for (int i = 0; i < 20_000; i++) {
                    total.incrementAndGet();
                    try {
                        Date got = shared.parse(in);
                        if (!got.equals(own.parse(in))) wrong.incrementAndGet();
                    } catch (Exception ex) { errors.incrementAndGet(); }
                }
                return null;
            }));
        }
        for (Future<?> fu : fs) fu.get();
        pool.shutdown();
        System.out.println("разборов " + total + ", исключений " + errors + ", неверных дат без исключения " + wrong);

        h("23. Утверждения Java Cookbook 3rd ed. о java.time");
        for (String cn : List.of("java.time.Calendrical", "java.time.DateTimeFields"))
            System.out.println(cn + ": " + tryIt(() -> Class.forName(cn)));
        System.out.println("LocalDate abstract=" + Modifier.isAbstract(LocalDate.class.getModifiers())
                + " final=" + Modifier.isFinal(LocalDate.class.getModifiers()));

        h("24. Clock");
        Clock fixed = Clock.fixed(Instant.parse("2026-12-31T21:30:00Z"), ZoneId.of("Europe/Moscow"));
        System.out.println("LocalDate.now(fixed)=" + LocalDate.now(fixed) + " +1 = " + LocalDate.now(fixed).plusDays(1));
        System.out.println("offset +3d: " + Clock.offset(fixed, Duration.ofDays(3)).instant()
                + ", tickMinutes: " + Clock.tick(Clock.fixed(Instant.parse("2026-09-21T13:45:59.123Z"), ZoneOffset.UTC), Duration.ofMinutes(1)).instant());

        h("25. Грубый замер: форматирование и разбор (не JMH)");
        DateTimeFormatter isoInst = DateTimeFormatter.ISO_INSTANT;
        Instant now = Instant.parse("2026-09-21T13:45:00.123Z");
        String s = isoInst.format(now);
        long sink = 0;
        for (int w = 0; w < 3; w++) {
            long t0 = System.nanoTime();
            for (int i = 0; i < 1_000_000; i++) sink += isoInst.format(now.plusMillis(i)).length();
            long t1 = System.nanoTime();
            for (int i = 0; i < 1_000_000; i++) sink += now.plusMillis(i).toString().length();
            long t2 = System.nanoTime();
            for (int i = 0; i < 1_000_000; i++) sink += Instant.parse(s).getNano();
            long t3 = System.nanoTime();
            if (w == 2) System.out.printf("ISO_INSTANT.format %d нс, Instant.toString %d нс, Instant.parse %d нс на вызов%n",
                    (t1 - t0) / 1_000_000, (t2 - t1) / 1_000_000, (t3 - t2) / 1_000_000);
        }
        System.out.println("sink " + (sink % 10));

        h("26. Грубый замер: nanoTime и currentTimeMillis");
        for (int w = 0; w < 3; w++) {
            long t0 = System.nanoTime();
            for (int i = 0; i < 10_000_000; i++) sink += System.nanoTime();
            long t1 = System.nanoTime();
            for (int i = 0; i < 10_000_000; i++) sink += System.currentTimeMillis();
            long t2 = System.nanoTime();
            if (w == 2) System.out.printf("nanoTime %.1f нс, currentTimeMillis %.1f нс на вызов%n", (t1 - t0) / 1e7, (t2 - t1) / 1e7);
        }
        long m0 = System.currentTimeMillis(), m1;
        while ((m1 = System.currentTimeMillis()) == m0) { }
        System.out.println("шаг currentTimeMillis: " + (m1 - m0) + " мс; sink " + (sink % 10));
    }

    interface Call { Object run() throws Exception; }

    static String tryIt(Call c) {
        try { return String.valueOf(c.run()); }
        catch (Exception e) { return e.getClass().getSimpleName() + ": " + e.getMessage(); }
    }
}
