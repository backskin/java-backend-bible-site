import java.nio.file.Files;
import java.nio.file.Path;

/** Cost of System.nanoTime() and System.currentTimeMillis(); on Linux prints the kernel clocksource. Run: java NanoCost.java */
public class NanoCost {
    static long sink;

    public static void main(String[] args) throws Exception {
        Path cs = Path.of("/sys/devices/system/clocksource/clocksource0/current_clocksource");
        System.out.println("os=" + System.getProperty("os.name") + " java=" + System.getProperty("java.version")
                + " clocksource=" + (Files.exists(cs) ? Files.readString(cs).trim() : "n/a"));
        int n = 20_000_000;
        for (int round = 0; round < 3; round++) {
            long t0 = System.nanoTime();
            long s = 0;
            for (int i = 0; i < n; i++) s += System.nanoTime();
            long t1 = System.nanoTime();
            for (int i = 0; i < n; i++) s += System.currentTimeMillis();
            long t2 = System.nanoTime();
            sink = s;
            if (round == 2) System.out.printf("nanoTime %.1f ns/call, currentTimeMillis %.1f ns/call%n", (t1 - t0) / (double) n, (t2 - t1) / (double) n);
        }
    }
}
