package dev.team.ch04;

import org.quartz.CronExpression;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.scheduling.support.SimpleTriggerContext;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.TimeZone;

/**
 * Cron "02:30 every day" across the DST switches of Europe/Berlin in 2026:
 * 29 March 02:00 -> 03:00 (02:30 does not exist), 25 October 03:00 -> 02:00 (02:30 happens twice).
 * Spring: the same CronTrigger the scheduler uses (nextExecution from the last completion).
 * Quartz: CronExpression.getNextValidTimeAfter with the trigger's time zone.
 */
public class DstSched {
    static final ZoneId ZONE = ZoneId.of("Europe/Berlin");

    public static void main(String[] args) throws Exception {
        for (String night : new String[]{"2026-03-28T20:00:00", "2026-10-24T20:00:00"}) {
            Instant start = ZonedDateTime.of(java.time.LocalDateTime.parse(night), ZONE).toInstant();
            System.out.println("== from " + start.atZone(ZONE) + " (" + ZONE + ")");

            System.out.println("Spring CronTrigger \"0 30 2 * * *\" zone=" + ZONE + ":");
            CronTrigger trigger = new CronTrigger("0 30 2 * * *", ZONE);
            SimpleTriggerContext ctx = new SimpleTriggerContext();
            ctx.update(null, null, start);
            for (int i = 0; i < 3; i++) {
                Instant next = trigger.nextExecution(ctx);
                System.out.println("  " + next.atZone(ZONE) + "  (UTC " + next + ")");
                ctx.update(next, next, next);
            }

            System.out.println("Quartz CronExpression \"0 30 2 * * ?\" timeZone=" + ZONE + ":");
            CronExpression cron = new CronExpression("0 30 2 * * ?");
            cron.setTimeZone(TimeZone.getTimeZone(ZONE));
            Date after = Date.from(start);
            for (int i = 0; i < 3; i++) {
                after = cron.getNextValidTimeAfter(after);
                System.out.println("  " + after.toInstant().atZone(ZONE) + "  (UTC " + after.toInstant() + ")");
            }
        }
    }
}
