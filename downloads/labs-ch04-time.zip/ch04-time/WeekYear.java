import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Буква Y зависит от локали форматтера. Запуск: java WeekYear.java */
public class WeekYear {
    public static void main(String[] args) {
        System.out.println("Locale.getDefault(FORMAT)=" + Locale.getDefault(Locale.Category.FORMAT));
        for (LocalDate d : new LocalDate[]{LocalDate.of(2021, 1, 3), LocalDate.of(2025, 12, 29)})
            for (Locale l : new Locale[]{Locale.US, Locale.forLanguageTag("ru"), Locale.UK, Locale.ROOT})
                System.out.println(d + " " + d.getDayOfWeek() + " " + l + ": YYYY=" + d.format(DateTimeFormatter.ofPattern("YYYY-MM-dd", l)));
    }
}
