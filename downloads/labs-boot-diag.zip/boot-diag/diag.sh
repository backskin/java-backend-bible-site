#!/usr/bin/env bash
# Команды раздела 13 главы 10 против запущенного сервиса комиссий (Boot 4.1.1).
# Запуск: bash diag.sh [доп. аргументы приложения]; вывод — в s10-diag.txt.
cd "$(dirname "$0")"
M=localhost:8081
java -jar target/fee-service-1.0.0.jar "$@" > app.log 2>&1 &
PID=$!
for i in $(seq 1 60); do curl -s $M/actuator/health >/dev/null && break; sleep 1; done
h() { echo; echo "== $*"; }
cut1() { cut -c1-200 | head -${1:-12}; }

h "аргументы приложения: $*"
h "контекст в ответе /actuator/beans"
curl -s $M/actuator/beans | jq -c '.contexts | keys'
h "conditions: negativeMatches, первые 5 ключей"
curl -s $M/actuator/conditions | jq -c '.contexts.application.negativeMatches | keys | .[:5]'
h "conditions: путь через первый контекст"
curl -s $M/actuator/conditions | jq -c '.contexts | to_entries[0].value.negativeMatches | keys | length'
h "beans: имена с datasource"
curl -s $M/actuator/beans | jq -c '.contexts.application.beans | keys | map(select(test("(?i)datasource")))'
h "env/spring.datasource.url"
curl -s $M/actuator/env/spring.datasource.url | jq -c '{property, sources: [.propertySources[] | {name, value: .property.value}]}'
h "env: имена источников"
curl -s $M/actuator/env | jq -r '.propertySources[].name' | cut1 20
h "configprops: первые 5 бинов"
curl -s $M/actuator/configprops | jq -c '.contexts.application.beans | keys | .[:5]'
h "startup: GET, форма длительности и тегов"
curl -s $M/actuator/startup | jq -c '.timeline.events[0] | {duration, tags: .startupStep.tags[:2]}'
h "startup: двадцать самых долгих шагов (команда из книги), первые 5"
curl -s $M/actuator/startup | jq -c '
  [ .timeline.events[]
    | { name: .startupStep.name,
        bean: (.startupStep.tags[]? | select(.key=="beanName") | .value),
        ms: (.duration | ltrimstr("PT") | rtrimstr("S") | tonumber * 1000) } ]
  | sort_by(-.ms) | .[:20]' | cut -c1-600
h "startup: шагов всего и шагов без тега beanName"
curl -s $M/actuator/startup | jq -c '[.timeline.events | length, (map(select([.startupStep.tags[]? | select(.key=="beanName")] | length == 0)) | length)]'
h "startup: исправленная команда, первые 5"
curl -s $M/actuator/startup | jq -c '
  [ .timeline.events[]
    | { name: .startupStep.name,
        bean: ([.startupStep.tags[]? | select(.key=="beanName") | .value][0] // "-"),
        ms: (.duration | ltrimstr("PT") | rtrimstr("S") | tonumber * 1000 | round) } ]
  | sort_by(-.ms) | .[:5]' | cut -c1-600
h "mappings"
curl -s $M/actuator/mappings | jq -c '.contexts.application.mappings.dispatcherServlets.dispatcherServlet[]
        | {predicate: .details.requestMappingConditions.patterns, handler: .handler}' | cut1 6
h "loggers: чтение, DEBUG, сброс"
curl -s $M/actuator/loggers/org.hibernate.SQL; echo
curl -s -o /dev/null -w "POST DEBUG: %{http_code}\n" -X POST $M/actuator/loggers/org.hibernate.SQL -H 'Content-Type: application/json' -d '{"configuredLevel":"DEBUG"}'
curl -s $M/actuator/loggers/org.hibernate.SQL; echo
curl -s -o /dev/null -w "POST null: %{http_code}\n" -X POST $M/actuator/loggers/org.hibernate.SQL -H 'Content-Type: application/json' -d '{"configuredLevel":null}'
curl -s $M/actuator/loggers/org.hibernate.SQL; echo
h "health/readiness"
curl -s $M/actuator/health/readiness | jq -c
h "health: компонент — статус"
curl -s $M/actuator/health | jq -c '.components | to_entries | map({(.key): .value.status}) | add'
h "actuator на порту приложения 8080"
curl -s -o /dev/null -w "%{http_code}\n" localhost:8080/actuator/health
kill $PID; wait $PID 2>/dev/null
