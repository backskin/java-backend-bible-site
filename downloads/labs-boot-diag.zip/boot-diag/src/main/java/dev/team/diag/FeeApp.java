package dev.team.diag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.metrics.buffering.BufferingApplicationStartup;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

/** Сервис комиссий: один эндпоинт и полный набор Actuator на отдельном порту. */
@SpringBootApplication
public class FeeApp {

    @RestController
    static class FeeController {
        @GetMapping("/fees")
        BigDecimal fee(@RequestParam BigDecimal amount) {
            return amount.multiply(new BigDecimal("0.005")).max(new BigDecimal("30"));
        }
    }

    /** Клиент тарифного справочника, который не может стартовать без адреса (сбой без FailureAnalyzer). */
    @org.springframework.stereotype.Component
    @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty("lab.fail")
    static class TariffClient {
        TariffClient(org.springframework.core.env.Environment env) {
            if (env.getProperty("tundra.tariffs.url") == null) throw new IllegalStateException("не задан tundra.tariffs.url");
        }
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(FeeApp.class);
        app.setApplicationStartup(new BufferingApplicationStartup(8192));
        app.run(args);
    }
}
