package dev.team.diag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

/** Своё свойство даёт новый ключ кеша и, значит, новый контекст. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(properties = "tundra.fees.min=50")
class ThirdFeeTest { @Test void starts() { } }
