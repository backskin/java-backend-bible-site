# Диагностика Spring Boot: Actuator через jq, отчет --debug, состав jar и jarmode, configtree, spring.factories

Стенд к главе 10, раздел 13. Сервис комиссий `FeeApp` (Spring Boot 4.1.1, Actuator, JDBC с H2) собирается и Maven, и Gradle (`build.gradle`), чтобы сравнить дерево зависимостей и `dependencyInsight`. Скрипт `diag.sh` запускает jar и прогоняет команды раздела против `/actuator/beans`, `conditions`, `env`, `configprops`, `loggers`, `mappings` с разбором через `jq`. Отдельные опыты: отчет `--debug` и `-Ddebug`, манифест и `jarmode` на Boot 3.2–4.1, занятый порт, имя логгера через косые черты, configtree с перезаписью секрета, модуль `factories/` с автоконфигурацией, зарегистрированной в `spring.factories` и в `AutoConfiguration.imports`, на Boot 2.7, 3.0 и 4.1. Выводы автора - `s10-diag.txt` … `s10-diag6.txt`.

## Что нужно

- JDK 21, Maven, `jq`, bash; Gradle 9 только для сравнения сборок.

## Запуск

```bash
mvn -q package -DskipTests && bash diag.sh
```

Второй прогон с именем приложения: `bash diag.sh --spring.application.name=fee-service`. Сервис слушает порт 8081, скрипт останавливает его сам. В IDEA есть конфигурации `FeeApp`, `mvn test` и Shell-конфигурация `diag`.

## Что должно получиться

Без `spring.application.name` контекст в ответах Actuator называется `application`, с именем - `fee-service`, и пути в `jq` приходится менять; `GET /actuator/loggers/dev/team/diag` дает 404, имя логгера передают с точками.
