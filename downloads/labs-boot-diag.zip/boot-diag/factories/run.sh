#!/usr/bin/env bash
# Старый ключ EnableAutoConfiguration в spring.factories против файла AutoConfiguration.imports на Boot 4.1.1.
cd "$(dirname "$0")"
[ -f ../cp.txt ] || (cd .. && mvn -q dependency:build-classpath -Dmdep.outputFile=cp.txt)
CP=$(cat ../cp.txt)
rm -rf out && mkdir out && javac -encoding UTF-8 -parameters -cp "$CP" -d out $(find src -name '*.java')
echo "== ключ EnableAutoConfiguration в META-INF/spring.factories"
java -Dstdout.encoding=UTF-8 -cp "out;res-old;$CP" probe.app.ProbeApp
echo "== файл META-INF/spring/…AutoConfiguration.imports"
java -Dstdout.encoding=UTF-8 -cp "out;res-new;$CP" probe.app.ProbeApp
rm -rf out
