package probe.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Приложение в своём пакете: автоконфигурацию из probe.auto сканирование не видит. */
@SpringBootApplication
public class ProbeApp {
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(ProbeApp.class);
        app.setWebApplicationType(WebApplicationType.NONE);
        var ctx = app.run("--spring.main.banner-mode=off", "--logging.level.root=warn");
        System.out.println("   бин limitsMarker в контексте: " + ctx.containsBean("limitsMarker"));
        ctx.close();
    }
}
