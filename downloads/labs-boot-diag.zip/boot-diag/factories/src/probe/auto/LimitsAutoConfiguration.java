package probe.auto;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Автоконфигурация, которую регистрируют то старым ключом spring.factories, то файлом imports. */
@Configuration(proxyBeanMethods = false)
public class LimitsAutoConfiguration {
    @Bean String limitsMarker() { return "лимиты"; }
}
