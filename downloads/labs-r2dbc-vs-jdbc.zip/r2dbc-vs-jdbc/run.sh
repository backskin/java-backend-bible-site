#!/usr/bin/env bash
# Разд. 11.9 гл. 11: поднимает PostgreSQL 17.9 в Docker, наполняет таблицу payments на 100 000 строк
# и прогоняет DbBench в режимах jdbc и r2dbc. Каждый прогон — в отдельной JVM, клиенты 100 и 1000,
# запрос по ключу и запрос с паузой 5 мс в базе, пул 20. Вывод — s11-dbbench.txt.
set -euo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
PORT=55432
docker rm -f jbb-bench-pg >/dev/null 2>&1 || true
docker run -d --name jbb-bench-pg -e POSTGRES_USER=bench -e POSTGRES_PASSWORD=bench -e POSTGRES_DB=bench \
  -p $PORT:5432 --cpus 4 --memory 2g postgres:17.9 -c max_connections=200 >/dev/null
until docker exec jbb-bench-pg pg_isready -U bench >/dev/null 2>&1; do sleep 1; done
sleep 2
docker exec -i jbb-bench-pg psql -q -U bench -d bench <<'SQL'
CREATE TABLE payments(id bigint PRIMARY KEY, account text NOT NULL, amount numeric(18,2) NOT NULL);
INSERT INTO payments SELECT g, '408178100000000' || lpad(g::text, 5, '0'), (random() * 100000)::numeric(18,2) FROM generate_series(1, 100000) g;
ANALYZE payments;
SQL
CP="target/classes;$(cat cp.txt)"
{
  echo "== 11.9. JDBC + HikariCP на виртуальных потоках против R2DBC + r2dbc-pool, PostgreSQL 17.9 (--cpus 4), 15 с на прогон"
  "$J" -version 2>&1 | head -1
  for sleep in 0 5; do
    for clients in 100 1000; do
      for mode in ${MODES:-jdbc r2dbc}; do
        "$J" -Xmx1g -Dstdout.encoding=UTF-8 -cp "$CP" dev.team.db.DbBench $mode $clients 15 $sleep 20 $PORT
      done
    done
  done
} | tee s11-dbbench.txt
docker rm -f jbb-bench-pg >/dev/null
