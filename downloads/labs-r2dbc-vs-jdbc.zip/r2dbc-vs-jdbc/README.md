# JDBC с HikariCP на виртуальных потоках против R2DBC с r2dbc-pool: пропускная способность и хвост задержек

Стенд к главе 11, раздел 11.9. `DbBench` выполняет запрос по ключу к таблице `payments` на 100 000 строк в PostgreSQL 17.9 (Docker, `--cpus 4`) 15 секунд при 100 и 1000 клиентах, с паузой `pg_sleep(0.005)` в базе и без, пул 20 соединений в обоих режимах: `jdbc` (HikariCP, `newVirtualThreadPerTaskExecutor`) и `r2dbc` (r2dbc-postgresql и r2dbc-pool, `flatMap(..., клиентов)`). Отдельный вариант оборачивает `getConnection()` в честный `Semaphore(20, true)`. Каждый прогон в своей JVM. Вывод автора - `s11-dbbench.txt`.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, Docker, bash; свободный порт 55432.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && bash run.sh
```

Скрипт поднимает контейнер `jbb-bench-pg`, наполняет таблицу, прогоняет восемь комбинаций (около 2,5 минут) и удаляет контейнер. Один режим вручную: `java -cp "target/classes;$(cat cp.txt)" dev.team.db.DbBench jdbc 1000 15 5 20 55432` (режим, клиентов, секунд, пауза мс, пул, порт). В IDEA есть конфигурации `DbBench` и Shell-конфигурация `run`.

## Что должно получиться

Пропускная способность у JDBC и R2DBC близка (около 3,4 тыс. запросов в секунду с паузой 5 мс при 1000 клиентах), но у HikariCP без семафора p50 около 6 мс при p99 в секунды, а с честным семафором и у R2DBC p50 и p99 сходятся к 300 мс. Цифры зависят от машины.
