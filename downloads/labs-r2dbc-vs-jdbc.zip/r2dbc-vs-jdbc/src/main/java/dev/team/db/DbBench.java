package dev.team.db;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.pool.ConnectionPoolConfiguration;
import io.r2dbc.postgresql.PostgresqlConnectionConfiguration;
import io.r2dbc.postgresql.PostgresqlConnectionFactory;
import io.r2dbc.spi.Connection;
import java.lang.management.ManagementFactory;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Duration;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Разд. 11.9 гл. 11. N одновременных клиентов в течение заданного времени выполняют запрос к PostgreSQL:
 * через JDBC (HikariCP) на виртуальных потоках или через R2DBC (r2dbc-pool) в цепочке Reactor.
 * Пул в обоих случаях одного размера. Печатает пропускную способность, p50/p99, пик потоков JVM и кучи.
 * Аргументы: jdbc|jdbc-fair|r2dbc (jdbc-fair — справедливый Semaphore(пул, true) перед HikariCP)  клиентов  секунд  sleepMs(0 — запрос по ключу)  размер_пула  порт
 */
public final class DbBench {

    static final int ROWS = 100_000;

    static String sql(int sleepMs, boolean jdbc) {
        String p = jdbc ? "?" : "$1";
        return sleepMs == 0 ? "SELECT id, amount FROM payments WHERE id = " + p
                : "SELECT id, amount, pg_sleep(" + sleepMs / 1000.0 + ") FROM payments WHERE id = " + p;
    }

    public static void main(String[] a) throws Exception {
        String mode = a[0];
        int clients = Integer.parseInt(a[1]), seconds = Integer.parseInt(a[2]), sleepMs = Integer.parseInt(a[3]), pool = Integer.parseInt(a[4]);
        int port = Integer.parseInt(a[5]);
        long[] lat = new long[4_000_000];
        AtomicInteger n = new AtomicInteger();
        LongAdder errors = new LongAdder();
        AtomicBoolean stop = new AtomicBoolean();
        AtomicLong peakThreads = new AtomicLong(), peakHeap = new AtomicLong();
        Thread sampler = Thread.ofPlatform().daemon().start(() -> {
            var mx = ManagementFactory.getThreadMXBean(); var mem = ManagementFactory.getMemoryMXBean();
            while (!stop.get()) {
                peakThreads.accumulateAndGet(mx.getThreadCount(), Math::max);
                peakHeap.accumulateAndGet(mem.getHeapMemoryUsage().getUsed(), Math::max);
                try { Thread.sleep(100); } catch (InterruptedException e) { return; }
            }
        });
        long t0, end;
        if (mode.startsWith("jdbc")) {
            java.util.concurrent.Semaphore fair = mode.equals("jdbc-fair") ? new java.util.concurrent.Semaphore(pool, true) : null;
            HikariConfig c = new HikariConfig();
            c.setJdbcUrl("jdbc:postgresql://127.0.0.1:" + port + "/bench"); c.setUsername("bench"); c.setPassword("bench");
            c.setMaximumPoolSize(pool); c.setMinimumIdle(pool); c.setConnectionTimeout(30_000);
            try (HikariDataSource ds = new HikariDataSource(c); ExecutorService ex = Executors.newVirtualThreadPerTaskExecutor()) {
                warmJdbc(ds, sleepMs);
                t0 = System.nanoTime(); end = t0 + seconds * 1_000_000_000L;
                for (int i = 0; i < clients; i++) ex.submit(() -> {
                    while (System.nanoTime() < end) {
                        long s = System.nanoTime();
                        if (fair != null) fair.acquireUninterruptibly();
                        try (var con = ds.getConnection(); PreparedStatement ps = con.prepareStatement(sql(sleepMs, true))) {
                            ps.setLong(1, ThreadLocalRandom.current().nextInt(1, ROWS + 1));
                            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) rs.getBigDecimal(2); }
                            int k = n.getAndIncrement(); if (k < lat.length) lat[k] = System.nanoTime() - s;
                        } catch (Exception e) { errors.increment(); }
                        finally { if (fair != null) fair.release(); }
                    }
                    return null;
                });
                ex.shutdown(); ex.awaitTermination(seconds + 60L, java.util.concurrent.TimeUnit.SECONDS);
            }
        } else {
            var cf = new PostgresqlConnectionFactory(PostgresqlConnectionConfiguration.builder()
                    .host("127.0.0.1").port(port).database("bench").username("bench").password("bench").build());
            ConnectionPool cp = new ConnectionPool(ConnectionPoolConfiguration.builder(cf)
                    .initialSize(pool).maxSize(pool).maxAcquireTime(Duration.ofSeconds(30)).build());
            cp.warmup().block();
            String q = sql(sleepMs, false);
            Flux.range(0, 2000).flatMap(i -> one(cp, q), 50).blockLast();
            t0 = System.nanoTime(); end = t0 + seconds * 1_000_000_000L;
            Flux.range(0, clients).flatMap(c -> Mono.defer(() -> {
                        long s = System.nanoTime();
                        return one(cp, q).doOnNext(x -> { int k = n.getAndIncrement(); if (k < lat.length) lat[k] = System.nanoTime() - s; })
                                .onErrorResume(e -> { errors.increment(); return Mono.empty(); });
                    }).repeat(() -> System.nanoTime() < end), clients).blockLast();
            cp.dispose();
        }
        long took = System.nanoTime() - t0;
        stop.set(true);
        int cnt = Math.min(n.get(), lat.length);
        long[] l = Arrays.copyOf(lat, cnt); Arrays.sort(l);
        System.out.printf("   %-5s клиентов %5d, пауза в БД %2d мс, пул %d: %8.0f запр./с, p50 %6.2f мс, p99 %7.2f мс, ошибок %d, потоков JVM до %d, куча до %d МБ%n",
                mode, clients, sleepMs, pool, cnt / (took / 1e9), l[cnt / 2] / 1e6, l[(int) (cnt * 0.99)] / 1e6, errors.sum(),
                peakThreads.get(), peakHeap.get() >> 20);
    }

    static Mono<BigDecimal> one(ConnectionPool cp, String q) {
        return Mono.usingWhen(cp.create(),
                (Connection c) -> Mono.from(c.createStatement(q).bind("$1", (long) ThreadLocalRandom.current().nextInt(1, ROWS + 1)).execute())
                        .flatMap(r -> Mono.from(r.map((row, m) -> row.get("amount", BigDecimal.class)))),
                Connection::close);
    }

    static void warmJdbc(HikariDataSource ds, int sleepMs) throws Exception {
        try (ExecutorService ex = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < 2000; i++) ex.submit(() -> {
                try (var con = ds.getConnection(); var ps = con.prepareStatement(sql(sleepMs, true))) {
                    ps.setLong(1, 1); ps.executeQuery().close();
                }
                return null;
            });
        }
    }
}
