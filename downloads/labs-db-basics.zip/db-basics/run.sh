#!/usr/bin/env bash
# Разд. 5.5 гл. 16: первичный ключ bigint против случайного UUID (и UUIDv7 на PostgreSQL 18).
# Нужен Docker; образы postgres:15 и postgres:18. Вывод — s16-pk-15.txt и s16-pk-18.txt.
set -uo pipefail
cd "$(dirname "$0")"
export MSYS_NO_PATHCONV=1
for v in 15 18; do
  docker rm -f db-basics-$v >/dev/null 2>&1
  docker run -d --name db-basics-$v -e POSTGRES_PASSWORD=pw "postgres:$v" >/dev/null
  until docker exec db-basics-$v pg_isready -U postgres >/dev/null 2>&1; do sleep 1; done
  sleep 2
  extra=""; [ "$v" = 18 ] && extra="-v with_uuidv7=1"
  docker exec -i db-basics-$v psql -U postgres -X $extra < pk.sql 2>&1 | tee "s16-pk-$v.txt"
  docker rm -f db-basics-$v >/dev/null
done
# MySQL 8.4 (разд. 5 гл. 16): docker run -d --name db-mysql -e MYSQL_ROOT_PASSWORD=pw mysql:8.4; docker exec -i db-mysql mysql -uroot -ppw -t < mysql.sql > s16-mysql.txt
