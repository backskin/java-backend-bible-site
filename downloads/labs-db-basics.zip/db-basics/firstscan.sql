-- Разд. 14, упражнение 5 гл. 16: откуда лишние страницы при первом точечном поиске в сессии.
-- Счётчики pg_statio_* показывают, какие отношения читались: индекс, куча или системный каталог.
-- Запуск: psql -X -f firstscan.sql (таблица operation должна быть создана page.sql или exercises.sql).
SELECT version();
\echo '== новая сессия: первый поиск, затем второй'
\c
SELECT pg_stat_force_next_flush();
SELECT (SELECT idx_blks_hit + idx_blks_read FROM pg_statio_all_indexes WHERE indexrelname = 'operation_pkey') AS idx,
       (SELECT heap_blks_hit + heap_blks_read FROM pg_statio_all_tables WHERE relname = 'operation') AS heap,
       (SELECT sum(heap_blks_hit + heap_blks_read + coalesce(idx_blks_hit, 0) + coalesce(idx_blks_read, 0)) FROM pg_statio_sys_tables) AS cat \gset b_
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, TIMING OFF) SELECT * FROM operation WHERE id = 523456;
SELECT pg_stat_force_next_flush();
\echo 'страницы первого поиска по отношениям (каталог считает и запросы к самой статистике, сравнивать со вторым поиском):'
SELECT (SELECT idx_blks_hit + idx_blks_read FROM pg_statio_all_indexes WHERE indexrelname = 'operation_pkey') - :b_idx AS index_pages,
       (SELECT heap_blks_hit + heap_blks_read FROM pg_statio_all_tables WHERE relname = 'operation') - :b_heap AS heap_pages,
       (SELECT sum(heap_blks_hit + heap_blks_read + coalesce(idx_blks_hit, 0) + coalesce(idx_blks_read, 0)) FROM pg_statio_sys_tables) - :b_cat AS catalog_pages \gset f_
\echo index :f_index_pages heap :f_heap_pages catalog :f_catalog_pages
SELECT (SELECT idx_blks_hit + idx_blks_read FROM pg_statio_all_indexes WHERE indexrelname = 'operation_pkey') AS idx,
       (SELECT heap_blks_hit + heap_blks_read FROM pg_statio_all_tables WHERE relname = 'operation') AS heap,
       (SELECT sum(heap_blks_hit + heap_blks_read + coalesce(idx_blks_hit, 0) + coalesce(idx_blks_read, 0)) FROM pg_statio_sys_tables) AS cat \gset b_
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, TIMING OFF) SELECT * FROM operation WHERE id = 523456;
SELECT pg_stat_force_next_flush();
\echo 'страницы второго поиска по отношениям:'
SELECT (SELECT idx_blks_hit + idx_blks_read FROM pg_statio_all_indexes WHERE indexrelname = 'operation_pkey') - :b_idx AS index_pages,
       (SELECT heap_blks_hit + heap_blks_read FROM pg_statio_all_tables WHERE relname = 'operation') - :b_heap AS heap_pages,
       (SELECT sum(heap_blks_hit + heap_blks_read + coalesce(idx_blks_hit, 0) + coalesce(idx_blks_read, 0)) FROM pg_statio_sys_tables) - :b_cat AS catalog_pages;
\echo '== метастраница индекса: блок 0, корень в ней указан отдельно'
SELECT root, level, fastroot, fastlevel FROM bt_metap('operation_pkey');
\echo '== новая сессия: сначала поиск другого ключа, потом 523456'
\c
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, TIMING OFF) SELECT * FROM operation WHERE id = 1;
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, TIMING OFF) SELECT * FROM operation WHERE id = 523456;
