-- Разд. 14 гл. 16: упражнения 1, 3, 4, 5, 6, 8, 10 на той же таблице operation, что в 5.2.
SELECT version();
\echo '== 1. размер страницы и параметры долговечности'
SHOW block_size; SHOW shared_buffers; SHOW checkpoint_timeout; SHOW max_wal_size; SHOW fsync; SHOW full_page_writes;
CREATE EXTENSION IF NOT EXISTS pageinspect;
CREATE TABLE operation (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  account_id bigint NOT NULL,
  amount     numeric(18,2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO operation (account_id, amount, created_at)
SELECT (random()*100000)::bigint, round((random()*100000)::numeric, 2), now() - (g || ' seconds')::interval
FROM generate_series(1, 1000000) g;
VACUUM ANALYZE operation;
\echo '== 3. строки на страницу'
SELECT relpages, reltuples, round(reltuples/relpages) AS rows_per_page FROM pg_class WHERE relname = 'operation';
\echo '== 4. высота B-дерева'
SELECT root, level FROM bt_metap('operation_pkey');
\echo '== 5. точечный поиск, два раза'
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, TIMING OFF) SELECT * FROM operation WHERE id = 523456;
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, TIMING OFF) SELECT * FROM operation WHERE id = 523456;
\echo '== 6. полный просмотр'
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) SELECT sum(amount) FROM operation;
\echo '== 10. объём журнала: сразу после CHECKPOINT и повторно'
CHECKPOINT;
SELECT pg_current_wal_lsn() AS l1 \gset
UPDATE operation SET amount = amount + 1 WHERE id < 100000;
SELECT pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), :'l1')) AS wal_after_checkpoint;
SELECT pg_current_wal_lsn() AS l2 \gset
UPDATE operation SET amount = amount + 1 WHERE id < 100000;
SELECT pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), :'l2')) AS wal_repeat;
\echo '== 8. DELETE половины и VACUUM'
DELETE FROM operation WHERE id % 2 = 0;
SELECT pg_stat_force_next_flush();
SELECT n_dead_tup FROM pg_stat_user_tables WHERE relname = 'operation';
SELECT pg_size_pretty(pg_relation_size('operation')) AS size_before_vacuum;
VACUUM operation;
SELECT pg_size_pretty(pg_relation_size('operation')) AS size_after_vacuum;
