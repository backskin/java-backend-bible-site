#!/usr/bin/env bash
# Разд. 7.3, 7.4, 10.3 и упражнение 12 гл. 16: асинхронная реплика теряет зафиксированный платёж
# при переключении, синхронная не даёт зафиксировать его без реплики.
# Нужен Docker и образ postgres:18. Вывод - s16-replica-18.txt.
#
# Ход опыта:
#  1. Ведущий pgp и потоковая реплика pgr, снятая pg_basebackup, в одной сети Docker.
#  2. Асинхронный режим: реплику отрезают от сети, на ведущем фиксируют платёж,
#     ведущий "сгорает" (docker kill), реплику возвращают в сеть и повышают до ведущего.
#     Платежа на ней нет, хотя клиенту ответили COMMIT.
#  3. Синхронный режим: тот же сценарий, но COMMIT на ведущем ждёт реплику и не возвращается;
#     отмена ожидания даёт предупреждение, что транзакция уже зафиксирована локально.
#  4. Отставание: массовый UPDATE на ведущем и replay_lag в pg_stat_replication.
set -uo pipefail
cd "$(dirname "$0")"
export MSYS_NO_PATHCONV=1
NET=jbb16net
PSQL="psql -U postgres -X -A -t"

up() {
  docker rm -f pgp pgr >/dev/null 2>&1
  docker network rm $NET >/dev/null 2>&1
  docker network create $NET >/dev/null
  docker run -d --name pgp --network $NET -e POSTGRES_PASSWORD=pw postgres:18 \
    -c wal_level=replica >/dev/null
  until docker exec pgp pg_isready -U postgres >/dev/null 2>&1; do sleep 1; done
  sleep 2
  # репликационное подключение без пароля только внутри сети стенда
  docker exec pgp bash -c 'echo "host replication all all trust" >> "$PGDATA/pg_hba.conf"'
  docker exec pgp $PSQL -c "SELECT pg_reload_conf()" >/dev/null
  docker exec pgp $PSQL -c "CREATE TABLE payment(id int PRIMARY KEY, amount numeric(18,2))" >/dev/null
  docker run -d --name pgr --network $NET -u postgres postgres:18 bash -c \
    "pg_basebackup -h pgp -U postgres -D /tmp/r -R -X stream -c fast -d 'application_name=pgr' && chmod 700 /tmp/r && exec postgres -D /tmp/r" >/dev/null
  until docker exec pgr pg_isready -U postgres >/dev/null 2>&1; do sleep 1; done
  sleep 2
  # синхронный режим включается, когда реплика уже подключена: иначе ждал бы и CREATE TABLE
  if [ -n "$1" ]; then
    docker exec pgp $PSQL -c "ALTER SYSTEM SET synchronous_standby_names = '$1'" -c "SELECT pg_reload_conf()" >/dev/null
    sleep 1
  fi
}

{
echo "== версия"
docker run --rm postgres:18 postgres --version

echo; echo "== 1. асинхронная реплика"
up ""
docker exec pgp $PSQL -c "INSERT INTO payment VALUES (1, 1500.00)"
sleep 1
echo "pg_stat_replication на ведущем (application_name|state|sync_state):"
docker exec pgp $PSQL -c "SELECT application_name, state, sync_state FROM pg_stat_replication"
echo "платежи на реплике до сбоя:"
docker exec pgr $PSQL -c "SELECT id, amount FROM payment ORDER BY id"
docker network disconnect $NET pgr
echo "реплика отрезана от сети; на ведущем фиксируем платёж 2:"
docker exec pgp $PSQL -c "INSERT INTO payment VALUES (2, 9900.00)"
echo "платежи на ведущем:"
docker exec pgp $PSQL -c "SELECT id, amount FROM payment ORDER BY id"
docker kill pgp >/dev/null
echo "ведущий остановлен docker kill; реплику возвращаем в сеть и повышаем:"
docker network connect $NET pgr
docker exec pgr $PSQL -c "SELECT pg_promote()"
echo "платежи на новом ведущем:"
docker exec pgr $PSQL -c "SELECT id, amount FROM payment ORDER BY id"

echo; echo "== 2. синхронная реплика (synchronous_standby_names = 'ANY 1 (pgr)')"
up "ANY 1 (pgr)"
docker exec pgp $PSQL -c "INSERT INTO payment VALUES (1, 1500.00)"
echo "pg_stat_replication на ведущем (application_name|state|sync_state):"
docker exec pgp $PSQL -c "SELECT application_name, state, sync_state FROM pg_stat_replication"
docker network disconnect $NET pgr
echo "реплика отрезана; INSERT платежа 2; через 5 секунд ожидание прерывается отменой запроса (timeout -s INT):"
start=$(date +%s)
docker exec pgp timeout -s INT 5 $PSQL -c "INSERT INTO payment VALUES (2, 9900.00)" 2>&1
echo "код выхода: $?, прошло секунд: $(( $(date +%s) - start ))"
echo "платежи на ведущем после отмены ожидания:"
docker exec pgp $PSQL -c "SELECT id, amount FROM payment ORDER BY id"
docker network connect $NET pgr

echo; echo "== 3. отставание реплики под нагрузкой (упражнение 12)"
up ""
docker exec pgp $PSQL -c "CREATE TABLE operation AS SELECT g AS id, 1.00::numeric(18,2) AS amount FROM generate_series(1, 2000000) g" >/dev/null
sleep 3
docker exec -d pgp $PSQL -c "UPDATE operation SET amount = amount + 1"
for i in 1 2 3 4 5 6 7 8; do
  docker exec pgp $PSQL -F ' ' -c "SELECT now()::time(0), sync_state, write_lag, replay_lag, pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn)) FROM pg_stat_replication"
  sleep 1
done
sleep 5
echo "после окончания нагрузки:"
docker exec pgp $PSQL -F ' ' -c "SELECT now()::time(0), sync_state, write_lag, replay_lag, pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn)) FROM pg_stat_replication"

docker rm -f pgp pgr >/dev/null 2>&1
docker network rm $NET >/dev/null 2>&1
} 2>&1 | tee s16-replica-18.txt
