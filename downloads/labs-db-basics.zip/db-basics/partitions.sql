-- Разд. 14, упражнение 9 гл. 16: удаление старого месяца через DROP секции против DELETE.
SELECT version();
CREATE TABLE operation_p (id bigint GENERATED ALWAYS AS IDENTITY, amount numeric(18,2), created_at timestamptz NOT NULL) PARTITION BY RANGE (created_at);
CREATE TABLE operation_p_2026_08 PARTITION OF operation_p FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
CREATE TABLE operation_p_2026_09 PARTITION OF operation_p FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');
CREATE TABLE operation_p_2026_10 PARTITION OF operation_p FOR VALUES FROM ('2026-10-01') TO ('2026-11-01');
INSERT INTO operation_p(amount, created_at)
SELECT round((random()*100000)::numeric, 2), timestamptz '2026-08-01' + (g * interval '7 seconds') FROM generate_series(1, 1100000) g;
CREATE TABLE operation_flat AS SELECT * FROM operation_p;
SELECT pg_size_pretty(pg_database_size(current_database())) AS db_before;
SELECT pg_size_pretty(pg_relation_size('operation_p_2026_08')) AS aug_partition, (SELECT count(*) FROM operation_p_2026_08) AS aug_rows;
\timing on
DROP TABLE operation_p_2026_08;
DELETE FROM operation_flat WHERE created_at < '2026-09-01';
\timing off
SELECT pg_size_pretty(pg_database_size(current_database())) AS db_after;
SELECT pg_size_pretty(pg_relation_size('operation_flat')) AS flat_after_delete;
