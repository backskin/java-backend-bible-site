# Устройство базы данных на запросах: страницы, B-дерево, bigint против UUID в первичном ключе, секции, MySQL InnoDB

Стенд к главе 16. Скрипты SQL, которые выполняются в Docker: `page.sql` (размер страницы, `pageinspect`, заголовки), `btree.sql` (структура B-дерева и деление страниц), `pk.sql` с `run.sh` (вставка с `bigint`, случайным UUID и UUIDv7 на PostgreSQL 15 и 18, плотность листьев по `pgstattuple`), `partitions.sql`, `exercises.sql` (упражнения главы), `mysql.sql` и `mysql-pk.sql` (размер страницы InnoDB, кластерный ключ, случайный порядок через `ORDER BY RAND()`). Выводы автора - `s16-*.txt`, суффикс - версия сервера.

## Что нужно

- Docker (образы `postgres:15`, `postgres:18`, `mysql:8.4`), bash.

## Запуск

```bash
bash run.sh
```

Любой другой скрипт на PostgreSQL 18:

```bash
docker run -d --name db18 -e POSTGRES_PASSWORD=pw postgres:18 && sleep 5 && docker exec -i db18 psql -U postgres -X < btree.sql
```

MySQL: `docker run -d --name db-mysql -e MYSQL_ROOT_PASSWORD=pw mysql:8.4`, затем `docker exec -i db-mysql mysql -uroot -ppw -t < mysql.sql`. В Git Bash перед `docker exec` нужен `export MSYS_NO_PATHCONV=1`.

## Что должно получиться

Случайный UUID дает индекс с заметно меньшей плотностью листьев и дольшую вставку, чем `bigint` и UUIDv7; абсолютные времена зависят от машины, соотношения устойчивы.
