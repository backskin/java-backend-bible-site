-- Разд. 5.2 гл. 16: страница таблицы operation, запросы ровно из главы
SELECT version();
CREATE EXTENSION IF NOT EXISTS pageinspect;
CREATE TABLE operation (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  account_id bigint NOT NULL,
  amount     numeric(18,2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO operation (account_id, amount, created_at)
SELECT (random()*100000)::bigint, round((random()*100000)::numeric, 2),
       now() - (g || ' seconds')::interval
FROM generate_series(1, 1000000) g;
VACUUM ANALYZE operation;

SELECT lower, upper, special, pagesize FROM page_header(get_raw_page('operation', 0));
--  lower | upper | special | pagesize
-- -------+-------+---------+----------
--    512 |   512 |    8192 |     8192

SELECT lp, lp_off, lp_len, t_ctid FROM heap_page_items(get_raw_page('operation', 0)) LIMIT 3;
--  lp | lp_off | lp_len | t_ctid
-- ----+--------+--------+--------
--   1 |   8136 |     56 | (0,1)
--   2 |   8080 |     56 | (0,2)
--   3 |   8016 |     64 | (0,3)

SELECT count(*) AS items_on_page0 FROM heap_page_items(get_raw_page('operation', 0));
SELECT root, level FROM bt_metap('operation_pkey');
