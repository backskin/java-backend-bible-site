-- Разд. 5.5 гл. 16: миллион строк журнала операций с тремя видами первичного ключа.
\timing on
CREATE EXTENSION IF NOT EXISTS pgstattuple;
SELECT version();
DROP TABLE IF EXISTS op_seq, op_uuid, op_uuid7;
CREATE TABLE op_seq   (id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, amount numeric(18,2));
CREATE TABLE op_uuid  (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), amount numeric(18,2));
INSERT INTO op_seq(amount)  SELECT 1 FROM generate_series(1, 1000000);
INSERT INTO op_uuid(amount) SELECT 1 FROM generate_series(1, 1000000);
\if :{?with_uuidv7}
CREATE TABLE op_uuid7 (id uuid PRIMARY KEY DEFAULT uuidv7(), amount numeric(18,2));
INSERT INTO op_uuid7(amount) SELECT 1 FROM generate_series(1, 1000000);
\endif
\timing off
SELECT 'op_seq_pkey' AS idx, round(avg_leaf_density::numeric, 2) AS leaf_density, round(leaf_fragmentation::numeric, 2) AS leaf_fragmentation,
       pg_size_pretty(pg_relation_size('op_seq_pkey')) AS size FROM pgstatindex('op_seq_pkey')
UNION ALL
SELECT 'op_uuid_pkey', round(avg_leaf_density::numeric, 2), round(leaf_fragmentation::numeric, 2), pg_size_pretty(pg_relation_size('op_uuid_pkey')) FROM pgstatindex('op_uuid_pkey');
\if :{?with_uuidv7}
SELECT 'op_uuid7_pkey' AS idx, round(avg_leaf_density::numeric, 2) AS leaf_density, round(leaf_fragmentation::numeric, 2) AS leaf_fragmentation,
       pg_size_pretty(pg_relation_size('op_uuid7_pkey')) AS size FROM pgstatindex('op_uuid7_pkey');
\endif
SHOW block_size;
