#!/usr/bin/env bash
# Разд. 4, 5.2, 5.7 и 14 гл. 16: page.sql, exercises.sql и firstscan.sql на одной версии PostgreSQL.
# Использование: bash run-pg.sh 15   (или 18). Вывод - s16-page-V.txt, s16-exercises-V.txt, s16-firstscan-V.txt.
set -uo pipefail
cd "$(dirname "$0")"
export MSYS_NO_PATHCONV=1
v=${1:-18}
c=db-basics-run-$v
docker rm -f $c >/dev/null 2>&1
docker run -d --name $c -e POSTGRES_PASSWORD=pw "postgres:$v" >/dev/null
until docker exec $c pg_isready -U postgres >/dev/null 2>&1; do sleep 1; done
sleep 2
docker exec $c psql -U postgres -X -q -c "CREATE DATABASE page" -c "CREATE DATABASE ex"
# готовые выводы не перезаписываются: на их числа ссылается глава; чтобы повторить, удалите файл
out=page.out; [ -e "s16-page-$v.txt" ] || out="s16-page-$v.txt"
docker exec -i $c psql -U postgres -X -d page < page.sql > "$out" 2>&1
out=ex.out; [ -e "s16-exercises-$v.txt" ] || out="s16-exercises-$v.txt"
docker exec -i $c psql -U postgres -X -d ex < exercises.sql > "$out" 2>&1
docker exec -i $c psql -U postgres -X -d page < firstscan.sql > "s16-firstscan-$v.txt" 2>&1
docker rm -f $c >/dev/null
rm -f page.out ex.out
tail -n +1 "s16-page-$v.txt" "s16-exercises-$v.txt" "s16-firstscan-$v.txt"
