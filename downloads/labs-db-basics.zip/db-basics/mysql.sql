-- Разд. 5 гл. 16: страница InnoDB и выбор кластерного индекса в MySQL 8.4.
SELECT VERSION() AS version, @@innodb_page_size AS innodb_page_size;
CREATE DATABASE IF NOT EXISTS lab;
USE lab;
DROP TABLE IF EXISTS op_nopk, op_uniq, op_pk;
CREATE TABLE op_nopk (amount DECIMAL(18,2), note VARCHAR(40));
CREATE TABLE op_uniq (doc_no VARCHAR(20) NOT NULL, amount DECIMAL(18,2), UNIQUE KEY uq_doc (doc_no));
CREATE TABLE op_pk   (id BIGINT AUTO_INCREMENT PRIMARY KEY, amount DECIMAL(18,2));
SELECT t.NAME AS table_name, i.NAME AS index_name, i.TYPE AS type_flags
FROM information_schema.INNODB_INDEXES i JOIN information_schema.INNODB_TABLES t ON t.TABLE_ID = i.TABLE_ID
WHERE t.NAME LIKE 'lab/op_%' ORDER BY t.NAME, i.INDEX_ID;
