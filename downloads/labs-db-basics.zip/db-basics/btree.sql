-- Разд. 5.7 гл. 16: высота и заполнение B-дерева PostgreSQL на миллионе ключей bigint —
-- индекс, выросший вставками, и тот же индекс, построенный заново (REINDEX).
CREATE EXTENSION IF NOT EXISTS pageinspect;
SELECT version();
DROP TABLE IF EXISTS op_seq;
CREATE TABLE op_seq (id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, amount numeric(18,2));
INSERT INTO op_seq(amount) SELECT 1 FROM generate_series(1, 1000000);
\echo '-- индекс, выросший вставками'
SELECT root, level, level + 1 AS levels FROM bt_metap('op_seq_pkey');
SELECT type, count(*) AS pages, round(avg(live_items)) AS avg_items, max(live_items) AS max_items
FROM generate_series(1, pg_relation_size('op_seq_pkey') / 8192 - 1) AS blk, LATERAL bt_page_stats('op_seq_pkey', blk::int)
GROUP BY type ORDER BY type;
REINDEX INDEX op_seq_pkey;
\echo '-- тот же индекс после REINDEX (построение с BTREE_NONLEAF_FILLFACTOR)'
SELECT root, level, level + 1 AS levels FROM bt_metap('op_seq_pkey');
SELECT type, count(*) AS pages, round(avg(live_items)) AS avg_items, max(live_items) AS max_items
FROM generate_series(1, pg_relation_size('op_seq_pkey') / 8192 - 1) AS blk, LATERAL bt_page_stats('op_seq_pkey', blk::int)
GROUP BY type ORDER BY type;
