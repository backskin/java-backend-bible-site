-- Разд. 10.1 гл. 16: кластерный индекс InnoDB по случайному UUID против монотонных ключей, миллион событий заявок.
SELECT VERSION() AS version, @@innodb_buffer_pool_size / 1024 / 1024 AS buffer_pool_mb;
CREATE DATABASE IF NOT EXISTS lab; USE lab;
SET SESSION cte_max_recursion_depth = 2000000;
CREATE TABLE seq1m (n INT PRIMARY KEY);
INSERT INTO seq1m WITH RECURSIVE s(n) AS (SELECT 1 UNION ALL SELECT n + 1 FROM s WHERE n < 1000000) SELECT n FROM s;
CREATE TABLE ev_auto (id BIGINT AUTO_INCREMENT PRIMARY KEY, payload CHAR(100) NOT NULL);
CREATE TABLE ev_uuid4 (id BINARY(16) PRIMARY KEY, payload CHAR(100) NOT NULL);
CREATE TABLE ev_uuid1s (id BINARY(16) PRIMARY KEY, payload CHAR(100) NOT NULL);
SET @t = NOW(6); INSERT INTO ev_auto(payload) SELECT 'событие заявки' FROM seq1m;
SELECT 'ev_auto' AS t, TIMESTAMPDIFF(MICROSECOND, @t, NOW(6)) / 1000 AS insert_ms;
SET @t = NOW(6); INSERT INTO ev_uuid4 SELECT UUID_TO_BIN(UUID()), 'событие заявки' FROM seq1m ORDER BY RAND();
SELECT 'ev_uuid4 (UUID в случайном порядке)' AS t, TIMESTAMPDIFF(MICROSECOND, @t, NOW(6)) / 1000 AS insert_ms;
SET @t = NOW(6); INSERT INTO ev_uuid1s SELECT UUID_TO_BIN(UUID(), 1), 'событие заявки' FROM seq1m;
SELECT 'ev_uuid1s (UUID_TO_BIN(UUID(), 1))' AS t, TIMESTAMPDIFF(MICROSECOND, @t, NOW(6)) / 1000 AS insert_ms;
ANALYZE TABLE ev_auto, ev_uuid4, ev_uuid1s;
SELECT TABLE_NAME, ROUND(DATA_LENGTH / 1024 / 1024) AS data_mb FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'lab' AND TABLE_NAME LIKE 'ev_%' ORDER BY TABLE_NAME;
