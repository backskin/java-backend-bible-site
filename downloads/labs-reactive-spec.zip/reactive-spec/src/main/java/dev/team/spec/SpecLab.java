package dev.team.spec;

import org.reactivestreams.Subscription;
import reactor.adapter.JdkFlowAdapter;
import reactor.core.publisher.BaseSubscriber;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

/** Разд. 2: как Reactor 3.8.7 выполняет правила Reactive Streams 1.0.4. */
public final class SpecLab {

    public static void main(String[] a) throws Exception {
        subscribeDemand();
        publishOnPrefetch();
        intervalOverflow();
        unboundedBuffer();
        requestZero();
        errorWithoutDemand();
        submissionPublisher();
        flowAdapters();
    }

    static void subscribeDemand() {
        System.out.println("== 2.3. какой спрос посылает subscribe() без аргументов");
        List<Long> req = new CopyOnWriteArrayList<>();
        Flux.range(1, 3).doOnRequest(req::add).subscribe();
        System.out.println("   request(" + req + "), Long.MAX_VALUE = " + Long.MAX_VALUE);
    }

    static void publishOnPrefetch() {
        System.out.println("== 2.3. prefetch и пополнение у publishOn");
        List<Long> req = new CopyOnWriteArrayList<>();
        Flux.range(1, 1000).doOnRequest(req::add).publishOn(Schedulers.single()).blockLast();
        System.out.println("   publishOn по умолчанию запросил у источника: первые " + req.subList(0, Math.min(5, req.size())) + ", всего запросов " + req.size());
        req.clear();
        Flux.range(1, 1000).doOnRequest(req::add).limitRate(100).blockLast();
        System.out.println("   limitRate(100): первые " + req.subList(0, Math.min(5, req.size())));
    }

    static void intervalOverflow() throws InterruptedException {
        System.out.println("== 2.3. Flux.interval(1 мс) и подписчик, который берёт по одному элементу в 50 мс");
        AtomicReference<String> res = new AtomicReference<>("нет ошибки");
        CountDownLatch done = new CountDownLatch(1);
        Flux.interval(Duration.ofMillis(1)).subscribe(new BaseSubscriber<>() {
            @Override protected void hookOnSubscribe(Subscription s) { request(1); }
            @Override protected void hookOnNext(Long v) {
                try { Thread.sleep(50); } catch (InterruptedException ignored) { }
                request(1);
            }
            @Override protected void hookOnError(Throwable t) { res.set(t.getClass().getName() + ": " + t.getMessage()); done.countDown(); }
        });
        done.await(5, TimeUnit.SECONDS);
        System.out.println("   подписчик спит на потоке таймера: " + res.get() + " (сон останавливает и сам таймер)");
        AtomicReference<String> res2 = new AtomicReference<>("нет ошибки за 5 с");
        CountDownLatch done2 = new CountDownLatch(1);
        Flux.interval(Duration.ofMillis(1)).publishOn(Schedulers.boundedElastic(), 1)
                .subscribe(v -> { try { Thread.sleep(50); } catch (InterruptedException ignored) { } },
                        t -> { res2.set(t.getClass().getName() + ": " + t.getMessage()); done2.countDown(); });
        done2.await(5, TimeUnit.SECONDS);
        System.out.println("   обработка на другом потоке, publishOn(…, 1): " + res2.get());
    }

    static void unboundedBuffer() {
        System.out.println("== 2.3. onBackpressureBuffer() без лимита: какой спрос уходит к источнику");
        List<Long> req = new CopyOnWriteArrayList<>();
        Flux.range(1, 10).doOnRequest(req::add).onBackpressureBuffer().subscribe(new BaseSubscriber<>() {
            @Override protected void hookOnSubscribe(Subscription s) { request(1); }
        });
        System.out.println("   подписчик запросил 1, источник получил request(" + req + ")");
    }

    static void requestZero() {
        System.out.println("== 2.5. request(0) у Flux.range (правило 3.9)");
        AtomicReference<String> res = new AtomicReference<>("ни ошибки, ни элементов");
        Flux.range(1, 5).subscribe(new BaseSubscriber<>() {
            @Override protected void hookOnSubscribe(Subscription s) {
                try { s.request(0); } catch (Exception e) { res.set("исключение вызывающему: " + e); }
            }
            @Override protected void hookOnNext(Integer v) { res.set("пришёл элемент " + v); }
            @Override protected void hookOnError(Throwable t) { res.set("onError: " + t.getClass().getName() + ": " + t.getMessage()); }
        });
        System.out.println("   свой подписчик Reactor (BaseSubscriber, CoreSubscriber): " + res.get());
        AtomicReference<String> res2 = new AtomicReference<>("ни ошибки, ни элементов");
        Flux.range(1, 5).subscribe(new org.reactivestreams.Subscriber<Integer>() {
            public void onSubscribe(Subscription s) { s.request(0); }
            public void onNext(Integer v) { res2.set("пришёл элемент " + v); }
            public void onError(Throwable t) { res2.set("onError: " + t.getClass().getName() + ": " + t.getMessage()); }
            public void onComplete() { }
        });
        System.out.println("   «чужой» org.reactivestreams.Subscriber: " + res2.get());
    }

    static void errorWithoutDemand() {
        System.out.println("== 2.5. Mono.error без единого request (правила 1.2, 2.10)");
        AtomicReference<String> res = new AtomicReference<>("ничего");
        Mono.error(new IllegalStateException("лимит исчерпан")).subscribe(new BaseSubscriber<>() {
            @Override protected void hookOnSubscribe(Subscription s) { /* спрос не посылаем */ }
            @Override protected void hookOnError(Throwable t) { res.set("onError: " + t.getMessage()); }
        });
        System.out.println("   " + res.get());
        AtomicReference<String> res2 = new AtomicReference<>("ничего");
        Flux.empty().subscribe(new BaseSubscriber<>() {
            @Override protected void hookOnSubscribe(Subscription s) { }
            @Override protected void hookOnComplete() { res2.set("onComplete"); }
        });
        System.out.println("   Flux.empty() без спроса: " + res2.get());
    }

    static void submissionPublisher() throws Exception {
        System.out.println("== 2.4. SubmissionPublisher из JDK");
        System.out.println("   Flow.defaultBufferSize() = " + Flow.defaultBufferSize());
        SubmissionPublisher<Integer> pub = new SubmissionPublisher<>(ForkJoinPool.commonPool(), 4);
        {
            CountDownLatch never = new CountDownLatch(1);
            pub.subscribe(new Flow.Subscriber<>() {
                Flow.Subscription sub;
                public void onSubscribe(Flow.Subscription s) { sub = s; s.request(1); }
                public void onNext(Integer i) { try { never.await(); } catch (InterruptedException ignored) { } sub.request(1); }
                public void onError(Throwable t) { }
                public void onComplete() { }
            });
            ExecutorService ex = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r); t.setDaemon(true); return t; });
            Future<Integer> f = ex.submit(() -> { int n = 0; for (int i = 0; i < 20; i++) { pub.submit(i); n++; } return n; });
            Thread.sleep(500);
            System.out.println("   буфер 4, подписчик завис на первом элементе: submit() отправил и вернулся " + (f.isDone() ? "все 20 раз" : "не дождавшись места — поток заблокирован"));
            never.countDown();
            System.out.println("   после того как подписчик ожил, submit() дошёл до конца: " + f.get(5, TimeUnit.SECONDS) + " элементов");
            ex.shutdownNow();
        }
    }

    static void flowAdapters() throws Exception {
        System.out.println("== 2.4. мосты между org.reactivestreams и java.util.concurrent.Flow");
        Flow.Publisher<String> jdk = JdkFlowAdapter.publisherToFlowPublisher(Flux.just("платёж 1", "платёж 2"));
        System.out.println("   Flux → Flow.Publisher → Flux: " + JdkFlowAdapter.flowPublisherToFlux(jdk).collectList().block());
        Class<?> fa = Class.forName("org.reactivestreams.FlowAdapters");
        System.out.println("   org.reactivestreams.FlowAdapters есть в " + fa.getProtectionDomain().getCodeSource().getLocation().getPath().replaceAll(".*/", ""));
    }
}
