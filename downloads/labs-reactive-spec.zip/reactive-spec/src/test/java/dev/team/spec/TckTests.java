package dev.team.spec;

import org.reactivestreams.Publisher;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import org.reactivestreams.tck.PublisherVerification;
import org.reactivestreams.tck.TestEnvironment;
import reactor.core.publisher.Flux;

/**
 * Разд. 2.6: TCK reactive-streams 1.0.4 против Flux.range и против самописного издателя,
 * который отдаёт элементы из колбэка «как пришли», без учёта спроса и без защиты от рекурсии.
 */
public final class TckTests {

    /** Reactor: ожидаем, что проходит всё обязательное. */
    public static class FluxRangeTck extends PublisherVerification<Integer> {
        public FluxRangeTck() { super(new TestEnvironment(300L)); }
        @Override public Publisher<Integer> createPublisher(long elements) { return Flux.range(0, (int) Math.min(elements, Integer.MAX_VALUE)); }
        @Override public Publisher<Integer> createFailedPublisher() { return Flux.error(new IllegalStateException("банк-корреспондент недоступен")); }
        @Override public long maxElementsFromPublisher() { return Integer.MAX_VALUE; }
    }

    /** Наивный издатель: в request отдаёт n элементов прямо в onNext, рекурсивно и без проверок. */
    public static class NaivePublisherTck extends PublisherVerification<Integer> {
        public NaivePublisherTck() { super(new TestEnvironment(300L)); }
        @Override public Publisher<Integer> createPublisher(long elements) { return new NaivePublisher(elements); }
        @Override public Publisher<Integer> createFailedPublisher() { return null; }
    }

    static final class NaivePublisher implements Publisher<Integer> {
        final long total;
        NaivePublisher(long total) { this.total = total; }

        @Override public void subscribe(Subscriber<? super Integer> s) {
            s.onSubscribe(new Subscription() {
                long sent;
                @Override public void request(long n) {
                    for (long i = 0; i < n && sent < total; i++) s.onNext((int) sent++);   // рекурсия, если подписчик просит из onNext
                    if (sent == total) s.onComplete();                                      // может прийти дважды
                }
                @Override public void cancel() { }                                         // отмена ничего не делает
            });
        }
    }
}
