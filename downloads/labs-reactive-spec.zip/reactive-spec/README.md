# Reactive Streams: спрос при subscribe(), interval под медленным подписчиком, TCK для своего издателя

Стенд к главе 11, раздел 2. `SpecLab` печатает через `doOnRequest`, какой спрос посылает `subscribe()` без аргументов (`Long.MAX_VALUE`) и что делает `Flux.interval(1 мс)` с подписчиком, который спит 50 мс на элемент, на потоке таймера и после `publishOn(Schedulers.single(), 1)`. `TckTests` прогоняет `reactive-streams-tck` 1.0.4 (TestNG) по `Flux.range` и по наивному издателю, написанному без учета спроса; `tck_sum.py` сводит отчет Surefire в две строки. Выводы автора - `s11-spec.txt`, `s11-tck.txt`.

## Что нужно

- JDK 21, Maven, Python 3 для сводки.

## Запуск

```bash
mvn -q compile exec:java -Dexec.mainClass=dev.team.spec.SpecLab
```

```bash
mvn -q test && python tck_sum.py target/surefire-reports
```

В IDEA есть конфигурации `SpecLab` и `mvn test`.

## Что должно получиться

`request(9223372036854775807)` у `subscribe()` без аргументов; подписчик, спящий на потоке таймера, останавливает сам таймер и ошибки нет, а после `publishOn(..., 1)` приходит `OverflowException: Could not emit tick 1 due to lack of requests`. TCK: у `FluxRangeTck` 0 провалов из 38 тестов, у `NaivePublisherTck` 11.
