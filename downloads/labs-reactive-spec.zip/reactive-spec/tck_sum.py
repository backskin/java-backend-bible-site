"""Сводка отчётов TCK: сколько тестов, какие правила провалены. python -X utf8 tck_sum.py > s11-tck.txt"""
import glob, os, re
for f in sorted(glob.glob('target/surefire-reports/junitreports/*.xml')):
    t = open(f, encoding='utf-8').read()
    cases = re.findall(r'<testcase[^>]*name="([^"]+)"[^>]*?(?:/>|>(.*?)</testcase>)', t, re.S)
    fail = [c for c in cases if '<failure' in c[1] or '<error' in c[1]]
    skip = [c for c in cases if '<skipped' in c[1]]
    print('==', os.path.basename(f).replace('TEST-dev.team.spec.TckTests$', '').replace('.xml', ''),
          '— тестов', len(cases), ', провалено', len(fail), ', пропущено', len(skip))
    for name, body in fail:
        msg = re.search(r'message="([^"]*)"', body)
        print('   ПРОВАЛ', name, '—', (msg.group(1) if msg else '')[:150].replace('&quot;', '"').replace('&#10;', ' '))
