# Время и деньги в PostgreSQL через JDBC: timestamp, timestamptz, numeric

Стенд к главе 04, раздел 5. Программа `PgLab` поднимает встроенный PostgreSQL 15.5 (zonky `embedded-postgres`, сервер не нужен) и через pgJDBC выполняет запросы из главы: как `timestamp` и `timestamptz` хранятся и печатаются, сколько байт занимают, что делает `at time zone` в обе стороны, `date_trunc` по дню в сессии и в поясе, `now()` против `clock_timestamp()` и `statement_timestamp()`, `isoyear` и `IW` против `WW`, границы `tstzrange`, чтение `numeric` в `BigDecimal`. Вывод автора - `s04-pg.txt`, номера блоков совпадают с главой.

## Что нужно

- JDK 21 и Maven. В `pom.xml` подключены бинарники PostgreSQL для Windows x64; на Linux или macOS замените артефакт `embedded-postgres-binaries-windows-amd64` на `-linux-amd64` или `-darwin-arm64v8`.

## Запуск

```bash
mvn -q compile exec:java
```

Первый запуск распаковывает PostgreSQL во временную папку, это занимает около десяти секунд. В IDEA есть конфигурация `PgLab`.
