package dev.team.ch04;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;

import java.sql.*;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.TimeZone;

/** Опыты главы 04 на PostgreSQL 15.5: время, деньги, текст. Каждый запрос печатается вместе с результатом. */
public class PgLab {

    static Connection c;

    public static void main(String[] args) throws Exception {
        try (EmbeddedPostgres pg = EmbeddedPostgres.builder().start()) {
            c = pg.getPostgresDatabase().getConnection();
            q("select version()");
            h("1. timestamptz и timestamp при смене зоны сессии");
            x("set timezone = 'Europe/Moscow'");
            x("create temp table t (a timestamptz, b timestamp)");
            x("insert into t values ('2026-09-21 12:00:00+03', '2026-09-21 12:00:00+03')");
            q("select a::text, b::text from t");
            x("set timezone = 'UTC'");
            q("select a::text, b::text from t");
            q("select pg_column_size(a) as tz_bytes, pg_column_size(b) as ts_bytes from t");

            h("2. at time zone и date_trunc");
            q("select (timestamp '2026-09-21 12:00' at time zone 'Europe/Moscow')::text");
            q("select (timestamptz '2026-09-21 21:30:00+00' at time zone 'Europe/Moscow')::text");
            q("select date_trunc('day', timestamptz '2026-09-21 21:30:00+00')::text as by_session_utc,"
                    + " date_trunc('day', timestamptz '2026-09-21 21:30:00+00' at time zone 'Europe/Moscow')::text as moscow_day,"
                    + " date_trunc('day', timestamptz '2026-09-21 21:30:00+00', 'Europe/Moscow')::text as three_args");

            h("3. now() и clock_timestamp() внутри транзакции");
            c.setAutoCommit(false);
            q("select now() = transaction_timestamp() as same_tx, now() < clock_timestamp() as clock_moves");
            q("select pg_sleep(0.05), now() = transaction_timestamp() as still_same, statement_timestamp() > transaction_timestamp() as stmt_later");
            c.commit();
            c.setAutoCommit(true);

            h("4. Недели: ISO и to_char");
            q("select extract(isoyear from date '2027-01-01') as isoyear, extract(week from date '2027-01-01') as week,"
                    + " to_char(date '2027-01-01', 'IW') as iw, to_char(date '2027-01-01', 'WW') as ww,"
                    + " to_char(date '2026-01-07', 'WW') as ww_jan7, to_char(date '2026-01-07', 'IW') as iw_jan7");

            h("5. Диапазоны");
            q("select tstzrange('2026-09-21 00:00+00', '2026-09-22 00:00+00')::text as default_bounds,"
                    + " tstzrange('2026-09-21 00:00+00', '2026-09-22 00:00+00') @> timestamptz '2026-09-22 00:00+00' as contains_end");

            h("6. JDBC: Instant, OffsetDateTime и getTimestamp");
            x("create table event (at timestamptz)");
            Instant at = Instant.parse("2026-09-21T13:45:00.123456789Z");
            try (PreparedStatement ps = c.prepareStatement("insert into event values (?)")) {
                ps.setObject(1, at.atOffset(java.time.ZoneOffset.UTC));
                ps.executeUpdate();
            }
            try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("select at from event")) {
                rs.next();
                OffsetDateTime odt = rs.getObject(1, OffsetDateTime.class);
                System.out.println("записали " + at + ", прочли " + odt + ", equals Instant=" + odt.toInstant().equals(at)
                        + ", equals после truncatedTo(MICROS)=" + odt.toInstant().equals(at.truncatedTo(java.time.temporal.ChronoUnit.MICROS)));
                for (String tz : new String[]{"UTC", "Europe/Moscow"}) {
                    TimeZone.setDefault(TimeZone.getTimeZone(tz));
                    System.out.println("user.timezone=" + tz + ": getTimestamp=" + rs.getTimestamp(1)
                            + ", getTimestamp(1).toInstant()=" + rs.getTimestamp(1).toInstant());
                }
                TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
            }
            try (PreparedStatement ps = c.prepareStatement("select ?::text")) {
                ps.setObject(1, at);
                try (ResultSet rs = ps.executeQuery()) { rs.next(); System.out.println("setObject(Instant): " + rs.getString(1)); }
            } catch (SQLException e) { System.out.println("setObject(Instant): " + e.getMessage()); }
            try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("select at from event")) {
                rs.next();
                System.out.println("getObject(Instant.class): " + rs.getObject(1, Instant.class));
            } catch (SQLException e) { System.out.println("getObject(Instant.class): " + e.getMessage()); }

            h("7. numeric, NaN, round, money");
            x("create table posting (id bigint primary key, amount numeric(19,4) not null, currency char(3) not null)");
            x("insert into posting values (1, 100.12345, 'RUB')");
            q("select amount::text from posting where id = 1");
            x("insert into posting values (2, 'NaN', 'RUB')");
            q("select amount::text, amount = amount as nan_eq_nan from posting where id = 2");
            x("insert into posting values (3, 'Infinity', 'RUB')");
            q("select round(-2.5::numeric) as n, round(-2.5::double precision) as d, round(2.5::numeric) as n25, round(2.5::double precision) as d25");
            q("select 'NaN'::numeric > 1e300::numeric as nan_greater, (0.1::numeric + 0.2::numeric)::text as num_sum, (0.1::float8 + 0.2::float8)::text as dbl_sum");
            q("select ('10.00'::money / 3)::text as money_div, current_setting('lc_monetary') as lc_monetary");
            x("delete from posting where amount = 'NaN'::numeric");
            x("alter table posting add constraint amount_not_nan check (amount <> 'NaN'::numeric)");
            x("insert into posting values (4, 'NaN', 'RUB')");
            q("select 100.00::numeric = 100.0000::numeric as numeric_eq, '100.00' = '100.0000' as text_eq");

            h("8. Текст: нормализация, длина, кодировки");
            q("select current_setting('server_encoding') as server_enc, current_setting('client_encoding') as client_enc");
            q("select length(U&'\\0065\\0301') as len_nfd, length(normalize(U&'\\0065\\0301', NFC)) as len_nfc,"
                    + " U&'\\0065\\0301' is nfc normalized as is_nfc, octet_length('Привет') as bytes, length('Привет') as chars");
            x("create table app_user (login text unique)");
            x("insert into app_user values ('jos' || U&'\\00E9'), ('jos' || U&'\\0065\\0301')");
            q("select count(*) as rows_with_unique_index, count(distinct normalize(login, NFC)) as distinct_after_nfc from app_user");
            q("select length(U&'\\+01F44D') as emoji_len, octet_length(U&'\\+01F44D') as emoji_bytes, lower('ИВАНОВ') as lower_ru");
            x("create table c2 (login text check (login is nfc normalized))");
            x("insert into c2 values ('jos' || U&'\\0065\\0301')");

            h("9. Правила сортировки");
            q("select string_agg(x, ', ' order by x collate \"C\") as c_order from (values ('Ящик'),('яблоко'),('Арбуз'),('ёлка'),('Енот')) v(x)");
            q("select count(*) as icu_collations from pg_collation where collprovider = 'i'");
            x("create collation ru_ci (provider = icu, locale = 'ru-RU-u-ks-level2', deterministic = false)");
            x("create table client (name text collate ru_ci)");
            x("create unique index on client (name)");
            x("insert into client values ('Иванов')");
            x("insert into client values ('иванов')");
            q("select string_agg(x, ', ' order by x collate ru_ci) as icu_order from (values ('Ящик'),('яблоко'),('Арбуз'),('ёлка'),('Енот')) v(x)");
            q("select 'Иванов' = 'ИВАНОВ' collate ru_ci as ci_equal");
            x("select * from client where name like 'Ив%'");
        }
    }

    static void h(String s) { System.out.println("--- " + s); }

    static void x(String sql) {
        try (Statement st = c.createStatement()) {
            st.execute(sql);
            System.out.println("ok: " + sql);
        } catch (SQLException e) {
            System.out.println("ERROR: " + sql + " -> " + e.getMessage().split("\n")[0]);
        }
    }

    static void q(String sql) {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            ResultSetMetaData md = rs.getMetaData();
            System.out.println("> " + sql);
            while (rs.next()) {
                StringBuilder sb = new StringBuilder("  ");
                for (int i = 1; i <= md.getColumnCount(); i++)
                    sb.append(md.getColumnLabel(i)).append('=').append(rs.getString(i)).append(i < md.getColumnCount() ? " | " : "");
                System.out.println(sb);
            }
        } catch (SQLException e) {
            System.out.println("ERROR: " + sql + " -> " + e.getMessage().split("\n")[0]);
        }
    }
}
