# Тесты Spring Boot: @SpringBootTest, слайсы @WebMvcTest и @JdbcTest, @MockitoBean, кэш контекстов, Testcontainers

Стенд к главе 10, раздел о тестировании. Сервис переводов СБП `TransferApp` (Spring Boot 4.1.1, JDBC с H2, валидация, `RestClient`) и пятнадцать тестовых классов, названных по порядку прогона `A1…`, которые различаются режимом `webEnvironment`, слайсом, подменой бинов через `@MockitoBean`, свойствами и `@DirtiesContext`; по журналу кэша контекстов видно, какие классы разделили контекст. Класс `F1PostgresContainerTests` поднимает PostgreSQL 17 в Testcontainers и включается только с `-Ddocker=true`. Выводы автора - `s10-test.txt`, `s10-test-docker.txt`.

## Что нужно

- JDK 21 и Maven; Docker для контейнерных тестов.

## Запуск

```bash
mvn -q test
```

С контейнерами: `mvn -q test -Ddocker=true`. В IDEA есть конфигурации `TransferApp` и `mvn test`.

## Что должно получиться

Строка `Started <Класс> in … seconds` появляется только у тестов, которым понадобился новый контекст; у остальных контекст взят из кэша, и в статистике растет `hitCount`.
