package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.test.autoconfigure.JdbcTest;
import org.springframework.context.annotation.Import;

import javax.sql.DataSource;

/** Слайс JDBC с контейнером, но без replace=NONE: какая база победит? */
@JdbcTest
@Import({TransferRepository.class, F1PostgresContainerTests.Containers.class})
@EnabledIfSystemProperty(named = "docker", matches = "true")
class G3JdbcSliceContainerDefaultReplaceTests {

    @Autowired DataSource ds;

    @Test
    void whichDatabase() throws Exception {
        try (var c = ds.getConnection()) {
            System.out.println("   ► @JdbcTest + контейнер без replace=NONE: " + c.getMetaData().getDatabaseProductName() + " " + c.getMetaData().getDatabaseProductVersion());
        }
    }
}
