package dev.team.tr;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.assertj.MockMvcTester;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/** Настройка заглушки живёт один тестовый метод. */
@WebMvcTest(TransferController.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class A2MockResetTests {

    @Autowired MockMvcTester mvc;
    @MockitoBean TransferService service;

    @Test @Order(1)
    void firstMethodStubs() {
        given(service.find("T-7")).willReturn(Optional.of(new Transfer("T-7", "+79990000007", BigDecimal.TEN, "ACCEPTED")));
        assertThat(mvc.get().uri("/api/transfers/T-7")).hasStatusOk();
        System.out.println("   ► метод 1: заглушка настроена, GET /api/transfers/T-7 → 200");
    }

    @Test @Order(2)
    void secondMethodSeesResetMock() {
        var result = mvc.get().uri("/api/transfers/T-7").exchange();
        System.out.println("   ► метод 2: та же заглушка без настройки, GET /api/transfers/T-7 → " + result.getResponse().getStatus()
                + ", find() вернул " + service.find("T-7"));
        assertThat(result).hasStatus(404);
    }
}
