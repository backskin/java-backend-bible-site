package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

/** Своя заглушка — тоже другой ключ кеша. */
@SpringBootTest
class D3OtherMockTests {

    @MockitoBean NspkClient nspk;
    @Autowired TransferRepository repo;

    @Test
    void newContext() {
        System.out.println("   ► D3 (@MockitoBean NspkClient): новый контекст");
    }
}
