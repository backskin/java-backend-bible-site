package dev.team.tr;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/** @Transactional на тесте: каждая запись откатывается после метода. */
@SpringBootTest
@Transactional
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class C1RollbackTests {

    @Autowired TransferRepository repo;

    @Test @Order(1)
    void insertsInsideTestTransaction() {
        int before = repo.count();
        repo.save(new Transfer("T-RB-1", "+79990000005", BigDecimal.ONE, "ACCEPTED"));
        System.out.println("   ► @Transactional, метод 1: было " + before + ", после вставки " + repo.count());
    }

    @Test @Order(2)
    void previousInsertIsRolledBack() {
        System.out.println("   ► @Transactional, метод 2: T-RB-1 в базе: " + repo.find("T-RB-1").isPresent());
        assertThat(repo.find("T-RB-1")).isEmpty();
    }
}
