package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/** Та же конфигурация, что у C2LeakTests: контекст берётся из кеша, и данные C2 видны здесь. */
@SpringBootTest
class D1SameConfigTests {

    @Autowired TransferRepository repo;

    @Test
    void seesDataFromAnotherClass() {
        System.out.println("   ► D1 (та же конфигурация, что C2): T-LEAK-1 в базе: " + repo.find("T-LEAK-1").isPresent());
    }
}
