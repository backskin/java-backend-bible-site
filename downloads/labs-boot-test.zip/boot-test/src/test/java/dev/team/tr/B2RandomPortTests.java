package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.resttestclient.TestRestTemplate;
import org.springframework.boot.resttestclient.autoconfigure.AutoConfigureRestTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.client.RestTestClient;

import static org.assertj.core.api.Assertions.assertThat;

/** Полный контекст с настоящим Tomcat на случайном порту. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureRestTestClient
class B2RandomPortTests {

    @LocalServerPort int port;
    @Autowired RestTestClient client;
    @Autowired ApplicationContext ctx;

    @Test
    void createsTransferOverRealHttp() {
        Transfer t = client.post().uri("/api/transfers").contentType(MediaType.APPLICATION_JSON)
                .body("{\"phone\":\"+79990000003\",\"amount\":700}")
                .exchange().expectStatus().isCreated().expectBody(Transfer.class).returnResult().getResponseBody();
        assertThat(t.status()).isEqualTo("ACCEPTED");
        System.out.println("   ► RANDOM_PORT: порт " + port + "; бинов TestRestTemplate без @AutoConfigureTestRestTemplate: "
                + ctx.getBeanNamesForType(TestRestTemplate.class).length);
    }
}
