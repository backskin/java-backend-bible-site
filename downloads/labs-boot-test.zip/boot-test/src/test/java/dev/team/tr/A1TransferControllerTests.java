package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.assertj.MockMvcTester;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

/** Слайс веб-слоя: один контроллер, сервис подменён заглушкой. */
@WebMvcTest(TransferController.class)
class A1TransferControllerTests {

    @Autowired MockMvcTester mvc;
    @Autowired ApplicationContext ctx;
    @MockitoBean TransferService service;

    @Test
    void returns404ForUnknownTransfer() {
        given(service.find("T-404")).willReturn(Optional.empty());
        assertThat(mvc.get().uri("/api/transfers/T-404")).hasStatus(404);
    }

    @Test
    void returnsTransfer() {
        given(service.find("T-1")).willReturn(Optional.of(new Transfer("T-1", "+79990000001", new BigDecimal("1500.00"), "ACCEPTED")));
        assertThat(mvc.get().uri("/api/transfers/T-1")).hasStatusOk()
                .bodyJson().extractingPath("$.status").isEqualTo("ACCEPTED");
    }

    @Test
    void rejectsNegativeAmountBeforeService() {
        assertThat(mvc.post().uri("/api/transfers").contentType(MediaType.APPLICATION_JSON)
                .content("{\"phone\":\"+79990000001\",\"amount\":-5}")).hasStatus(400);
        org.mockito.Mockito.verify(service, org.mockito.Mockito.never()).create(any());
    }

    @Test
    void sliceHasNoDataLayer() {
        System.out.println("   ► слайс @WebMvcTest: бинов " + ctx.getBeanDefinitionCount()
                + "; TransferRepository=" + ctx.getBeanNamesForType(TransferRepository.class).length
                + ", DataSource=" + ctx.getBeanNamesForType(javax.sql.DataSource.class).length
                + ", NspkClient=" + ctx.getBeanNamesForType(NspkClient.class).length
                + ", LimitController=" + ctx.getBeanNamesForType(LimitController.class).length
                + ", заглушка TransferService: " + org.mockito.Mockito.mockingDetails(service).isMock());
        assertThat(ctx.getBeanNamesForType(TransferRepository.class)).isEmpty();
    }
}
