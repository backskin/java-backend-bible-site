package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.assertj.MockMvcTester;

import static org.assertj.core.api.Assertions.assertThat;

/** Полный контекст без сервера: запрос идёт через DispatcherServlet, но не через сеть. */
@SpringBootTest
@AutoConfigureMockMvc
class B1MockEnvironmentTests {

    @Autowired MockMvcTester mvc;
    @Autowired Environment env;

    @Test
    void createsAndReadsTransferThroughAllLayers() throws Exception {
        var created = mvc.post().uri("/api/transfers").contentType(MediaType.APPLICATION_JSON)
                .content("{\"phone\":\"+79990000002\",\"amount\":2500.00}").exchange();
        assertThat(created).hasStatus(201);
        String id = com.jayway.jsonpath.JsonPath.read(created.getResponse().getContentAsString(java.nio.charset.StandardCharsets.UTF_8), "$.id");
        assertThat(mvc.get().uri("/api/transfers/" + id)).hasStatusOk().bodyJson().extractingPath("$.amount").isEqualTo(2500.0);
        System.out.println("   ► MOCK: сервер не запущен, local.server.port=" + env.getProperty("local.server.port"));
    }
}
