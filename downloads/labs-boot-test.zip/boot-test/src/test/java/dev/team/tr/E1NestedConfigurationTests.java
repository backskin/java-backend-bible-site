package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

/** Вложенный @Configuration заменяет конфигурацию приложения целиком. */
@SpringBootTest
class E1NestedConfigurationTests {

    @Configuration
    static class Clocks {
        @Bean Clock clock() { return Clock.fixed(Instant.parse("2026-01-01T00:00:00Z"), ZoneOffset.UTC); }
    }

    @Autowired ApplicationContext ctx;

    @Test
    void applicationConfigurationIsGone() {
        System.out.println("   ► вложенный @Configuration: бинов " + ctx.getBeanDefinitionCount()
                + "; TransferService=" + ctx.getBeanNamesForType(TransferService.class).length
                + ", JdbcTemplate=" + ctx.getBeanNamesForType(org.springframework.jdbc.core.JdbcTemplate.class).length
                + ", Clock=" + ctx.getBeanNamesForType(Clock.class).length);
    }
}
