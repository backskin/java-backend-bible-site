package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import org.springframework.boot.jdbc.test.autoconfigure.JdbcTest;
import org.springframework.context.annotation.Import;

import javax.sql.DataSource;

/** Слайс JDBC на PostgreSQL из контейнера, подмена базы выключена. */
@JdbcTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import({TransferRepository.class, F1PostgresContainerTests.Containers.class})
@EnabledIfSystemProperty(named = "docker", matches = "true")
class G2JdbcSlicePostgresTests {

    @Autowired DataSource ds;

    @Test
    void usesContainer() throws Exception {
        try (var c = ds.getConnection()) {
            System.out.println("   ► @JdbcTest + replace=NONE + контейнер: " + c.getMetaData().getDatabaseProductName() + " " + c.getMetaData().getDatabaseProductVersion());
        }
    }
}
