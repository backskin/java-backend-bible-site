package dev.team.tr;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;

/** Без @Transactional встроенная база общая для всех тестов одного контекста. */
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class C2LeakTests {

    @Autowired TransferRepository repo;

    @Test @Order(1)
    void insertsWithoutTransaction() {
        repo.save(new Transfer("T-LEAK-1", "+79990000006", BigDecimal.ONE, "ACCEPTED"));
    }

    @Test @Order(2)
    void dataSurvivesBetweenMethods() {
        System.out.println("   ► без @Transactional, метод 2: T-LEAK-1 в базе: " + repo.find("T-LEAK-1").isPresent()
                + ", всего переводов " + repo.count());
    }
}
