package dev.team.tr;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.test.autoconfigure.JdbcTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Import;

import javax.sql.DataSource;
import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/** Слайс JDBC: DataSource, JdbcTemplate, транзакция с откатом; репозиторий подключён явно. */
@JdbcTest
@Import(TransferRepository.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class G1JdbcSliceTests {

    @Autowired TransferRepository repo;
    @Autowired DataSource ds;
    @Autowired ApplicationContext ctx;

    @Test @Order(1)
    void insertsInSliceTransaction() throws Exception {
        repo.save(new Transfer("T-JDBC-1", "+79990000010", BigDecimal.ONE, "ACCEPTED"));
        try (var c = ds.getConnection()) {
            System.out.println("   ► @JdbcTest: бинов " + ctx.getBeanDefinitionCount() + "; TransferController="
                    + ctx.getBeanNamesForType(TransferController.class).length + ", TransferService=" + ctx.getBeanNamesForType(TransferService.class).length
                    + "; база " + c.getMetaData().getURL() + " вместо jdbc:h2:mem:transfers; переводов после вставки " + repo.count());
        }
    }

    @Test @Order(2)
    void rolledBack() {
        System.out.println("   ► @JdbcTest, метод 2: T-JDBC-1 в базе: " + repo.find("T-JDBC-1").isPresent());
        assertThat(repo.find("T-JDBC-1")).isEmpty();
    }
}
