package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

/** Конфигурация как у C2 и D1, но @DirtiesContext выбрасывает контекст после класса. */
@SpringBootTest
@DirtiesContext
class D4DirtiesTests {

    @Test
    void usesCachedThenEvicts() {
        System.out.println("   ► D4 (@DirtiesContext): контекст из кеша, после класса будет закрыт");
    }
}
