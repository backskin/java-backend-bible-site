package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/** Одно лишнее свойство — другой ключ кеша и новый контекст. */
@SpringBootTest(properties = "tundra.nspk.timeout=2s")
class D2OtherPropertyTests {

    @Autowired TransferRepository repo;

    @Test
    void newContext() {
        System.out.println("   ► D2 (properties): T-LEAK-1 в базе: " + repo.find("T-LEAK-1").isPresent());
    }
}
