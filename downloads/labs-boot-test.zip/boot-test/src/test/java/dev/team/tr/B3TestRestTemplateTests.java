package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.resttestclient.TestRestTemplate;
import org.springframework.boot.resttestclient.autoconfigure.AutoConfigureTestRestTemplate;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

/** TestRestTemplate в Boot 4 появляется только с явной аннотацией. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestRestTemplate
class B3TestRestTemplateTests {

    @Autowired TestRestTemplate rest;

    @Test
    void readsLimit() {
        var r = rest.getForEntity("/api/limits/+79990000004", String.class);
        System.out.println("   ► TestRestTemplate с @AutoConfigureTestRestTemplate: " + r.getStatusCode() + " " + r.getBody());
        assertThat(r.getStatusCode().value()).isEqualTo(200);
    }
}
