package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

/** Вложенный @TestConfiguration дополняет конфигурацию приложения. */
@SpringBootTest
class E2NestedTestConfigurationTests {

    @TestConfiguration(proxyBeanMethods = false)
    static class Clocks {
        @Bean Clock clock() { return Clock.fixed(Instant.parse("2026-01-01T00:00:00Z"), ZoneOffset.UTC); }
    }

    @Autowired ApplicationContext ctx;
    @Autowired BusinessClock clock;

    @Test
    void applicationConfigurationPlusClock() {
        System.out.println("   ► вложенный @TestConfiguration: бинов " + ctx.getBeanDefinitionCount()
                + "; TransferService=" + ctx.getBeanNamesForType(TransferService.class).length
                + ", JdbcTemplate=" + ctx.getBeanNamesForType(org.springframework.jdbc.core.JdbcTemplate.class).length
                + ", время по BusinessClock: " + clock.now());
    }
}
