package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

/**
 * @WebMvcTest без списка контроллеров поднимает все контроллеры приложения.
 * Имя не подходит под шаблоны Surefire; запуск: mvn -o test -Dtest=AllControllersSliceProbe
 */
@WebMvcTest
class AllControllersSliceProbe {

    @MockitoBean TransferService service;

    @Test
    void contextLoads() { }
}
