package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/** После @DirtiesContext та же конфигурация поднимается заново, и база пустая. */
@SpringBootTest
class D5AfterDirtiesTests {

    @Autowired TransferRepository repo;

    @Test
    void contextRebuilt() {
        System.out.println("   ► D5 (после D4): T-LEAK-1 в базе: " + repo.find("T-LEAK-1").isPresent());
    }
}
