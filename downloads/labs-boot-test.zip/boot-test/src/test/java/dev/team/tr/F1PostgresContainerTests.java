package dev.team.tr;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.testcontainers.postgresql.PostgreSQLContainer;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/** Тест на настоящем PostgreSQL; нужен Docker, поэтому запускается только с -Ddocker=true. */
@SpringBootTest
@Import(F1PostgresContainerTests.Containers.class)
@EnabledIfSystemProperty(named = "docker", matches = "true")
class F1PostgresContainerTests {

    @TestConfiguration(proxyBeanMethods = false)
    static class Containers {
        @Bean
        @ServiceConnection
        PostgreSQLContainer postgres() { return new PostgreSQLContainer("postgres:17-alpine"); }
    }

    @Autowired TransferRepository repo;
    @Autowired javax.sql.DataSource ds;

    @Test
    void savesIntoPostgres() throws Exception {
        repo.save(new Transfer("T-PG-1", "+79990000009", BigDecimal.TEN, "ACCEPTED"));
        assertThat(repo.find("T-PG-1")).isPresent();
        try (var c = ds.getConnection()) {
            var md = c.getMetaData();
            System.out.println("   ► база: " + md.getDatabaseProductName() + " " + md.getDatabaseProductVersion()
                    + ", адрес " + md.getURL().replaceAll("localhost:\\d+", "localhost:<порт>") + ", T-PG-1 найден: " + repo.find("T-PG-1").isPresent());
        }
    }
}
