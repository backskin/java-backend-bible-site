package dev.team.tr;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.Optional;
import java.util.UUID;

/** Приложение опыта разд. 8: переводы СБП по номеру телефона в Тундра-Банке. */
@SpringBootApplication
public class TransferApp {
    public static void main(String[] args) { SpringApplication.run(TransferApp.class, args); }
}

record TransferRequest(@NotBlank String phone, @Positive BigDecimal amount) { }

record Transfer(String id, String phone, BigDecimal amount, String status) { }

@RestController
class TransferController {
    private final TransferService service;

    TransferController(TransferService service) { this.service = service; }

    @GetMapping("/api/transfers/{id}")
    ResponseEntity<Transfer> one(@PathVariable String id) {
        return service.find(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/api/transfers")
    ResponseEntity<Transfer> create(@Valid @RequestBody TransferRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(req));
    }
}

/** Второй контроллер приложения: дневной лимит переводов клиента. */
@RestController
class LimitController {
    private final LimitService limits;

    LimitController(LimitService limits) { this.limits = limits; }

    @GetMapping("/api/limits/{phone}")
    BigDecimal left(@PathVariable String phone) { return limits.leftToday(phone); }
}

@Service
class LimitService {
    BigDecimal leftToday(String phone) { return new BigDecimal("150000.00"); }
}

@Service
class TransferService {
    private final TransferRepository repo;
    private final NspkClient nspk;

    TransferService(TransferRepository repo, NspkClient nspk) { this.repo = repo; this.nspk = nspk; }

    Optional<Transfer> find(String id) { return repo.find(id); }

    Transfer create(TransferRequest req) {
        Transfer t = new Transfer("T-" + UUID.randomUUID().toString().substring(0, 8), req.phone(), req.amount(), nspk.send(req));
        repo.save(t);
        return t;
    }
}

@Repository
class TransferRepository {
    private final JdbcTemplate jdbc;

    TransferRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    void save(Transfer t) {
        jdbc.update("insert into transfers(id, phone, amount, status) values (?, ?, ?, ?)", t.id(), t.phone(), t.amount(), t.status());
    }

    Optional<Transfer> find(String id) {
        return jdbc.query("select id, phone, amount, status from transfers where id = ?",
                (rs, n) -> new Transfer(rs.getString(1), rs.getString(2), rs.getBigDecimal(3), rs.getString(4)), id).stream().findFirst();
    }

    int count() { return jdbc.queryForObject("select count(*) from transfers", Integer.class); }
}

/** Клиент НСПК: в бою ходит по сети, в опыте отвечает сразу. */
@Component
class NspkClient {
    String send(TransferRequest req) { return "ACCEPTED"; }
}

/** Часы приложения: тесты подменяют их фиксированными. */
@Component
class BusinessClock {
    private final Clock clock;
    BusinessClock(Optional<Clock> clock) { this.clock = clock.orElse(Clock.systemUTC()); }
    java.time.Instant now() { return clock.instant(); }
}
