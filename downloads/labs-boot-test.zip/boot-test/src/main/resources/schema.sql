create table if not exists transfers (id varchar(20) primary key, phone varchar(20) not null, amount decimal(12, 2) not null, status varchar(20) not null);
