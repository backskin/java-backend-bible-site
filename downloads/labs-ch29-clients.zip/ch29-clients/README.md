# Опыты главы 29, разделы 1–7: клиенты Kafka, сегмент на диске, проверка книг

Проверено 2026-11-02: Windows + Git Bash, JDK 21.0.10 (Temurin), Maven 3.9.16, Docker. Spring Boot 4.1.1 (`spring-kafka` и `spring-kafka-test` 4.1.1).

## Состав

| Класс или скрипт | Что проверяет | Раздел главы | Вывод |
|---|---|---|---|
| `KafkaBasics` | лидер, реплики и ISR; `acks` и `min.insync.replicas` при остановке брокера; ключи и партиции; идемпотентность и несовместимые настройки; что видит читатель транзакции | 4.1, 4.3, 5.4, 5.5, 5.6 | `s29-KafkaBasics.txt` |
| `KafkaConsumers` | жадная и кооперативная перебалансировка; `max.poll.interval.ms`; фиксация до и после обработки; дубли после перебалансировки; `DefaultErrorHandler` и DLT; отравленное сообщение | 6.3, 6.7, 6.8, 11.4, 14.2, 14.3 | `s29-KafkaConsumers.txt` |
| `KafkaRare` | `max.poll.records`; `offset` против `offset + 1`; отсечение по `transactional.id`; автофиксация с пулом потоков; ключ дедупликации; статическое членство; `ErrorHandlingDeserializer` | 5.6, 6.5, 6.7, 6.8, 7.4, 14.x | `s29-KafkaRare.txt` |
| `K29c` | нечистые выборы лидера: потеря подтвержденных записей, ELR | 4.4 | `s29-K29c.txt` |
| `K29d` | стабильный и случайный `transactional.id`; степень сжатия lz4 и zstd при разном `linger.ms` | 5.3, 5.6 | `s29-K29d.txt` |
| `dumplog.sh` + `DumpLogFeed` | каталог партиции, заранее выделенные индексы и их обрезка, разбор сегмента `kafka-dump-log.sh`, проверка индексов, снимок производителей | 2.1, 2.4, 2.6 | `s29-dumplog.txt` |
| `bookchecks.sh` + `BookChecks` | ошибка `Math.abs` в разделителе из *Kafka: The Definitive Guide*; `delivery.timeout.ms` меньше `linger.ms + request.timeout.ms`; два потребителя с одним `group.instance.id` в классическом протоколе и в KIP-848; метка времени из 2087 года; запись в 5 МБ; лаг 1 на транзакционном топике | 2.4, 2.5, 5.2, 5.4, 5.6, 6.5 | `s29-bookchecks.txt` |
| `hotgroup.sh` + `HotGroup` | горячая группа и соседние группы на той же и на другой партиции `__consumer_offsets`: задержка `commitSync`, ответ на сигнал "я жив", перебалансировки; брокер `--cpus 1` и `0.5`, `group.coordinator.threads` 4 и 1 (2026-11-03) | 6.2 | `s29-hotgroup.txt` |

Первые пять классов поднимают брокеры внутри процесса (`EmbeddedKafkaKraftBroker`, `KafkaClusterTestKit`), Docker им не нужен. `dumplog.sh` и `bookchecks.sh` поднимают один узел `apache/kafka:4.3.1` в Docker (контейнер `k29`, порт 39092) и удаляют его в конце. `hotgroup.sh` поднимает такой же узел `k29h` на порту 39093 с ограничением процессора; класс компилируется отдельно: `javac -d target/hot -cp "$(cat cp431.txt)" src/main/java/k/HotGroup.java`.

## Версии Kafka

- Встроенные брокеры работают на **Kafka 4.2.1** - версии, которую задает Spring Boot 4.1.1. С Kafka 4.3.1 (`-Dkafka.version=4.3.1`) классы `spring-kafka-test` 4.1.1 не запускаются: `NoSuchMethodError` в `KafkaClusterTestKit` (тестовый набор Kafka 4.3 поменял методы). Поэтому опыты на 4.3.1 идут на брокере в Docker.
- Для Docker-опытов клиент собирается с `kafka.version=4.3.1` (файл `cp431.txt`).
- Артефакты `kafka-test-common-runtime` и `kafka-test-common-internal-api` в `pom.xml` привязаны к `${kafka.version}`: без этого Maven брал их версии 4.2.1 при любом `kafka.version`.

## Запуск

```bash
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt
mvn -q -Dkafka.version=4.3.1 dependency:build-classpath -Dmdep.outputFile=cp431.txt
CP="target/classes;$(cat cp.txt)"        # на Linux и macOS разделитель ":"
for c in KafkaBasics KafkaConsumers KafkaRare K29c K29d; do
  java -Dstdout.encoding=UTF-8 -Dorg.slf4j.simpleLogger.defaultLogLevel=off -cp "$CP" k.$c > s29-$c.txt
done
./dumplog.sh > s29-dumplog.txt
./bookchecks.sh > s29-bookchecks.txt
```

В Git Bash на Windows скрипты выставляют `MSYS_NO_PATHCONV=1`, иначе путь `/var/lib/kafka/data` в аргументах Docker превращается в путь Windows и брокер не стартует.

## Что ожидать

- `KafkaBasics`: при `min.insync.replicas = 3` и остановленном брокере `acks=all` получает `NotEnoughReplicasException`, `acks=1` пишет; ключи `acc-2..4` в одной партиции.
- `KafkaConsumers`: Range отзывает 6 партиций при входе третьего потребителя, CooperativeSticky - 2.
- `KafkaRare`: автофиксация с пулом теряет 10–14 записей из 30 (зависит от прогона).
- `K29c`: подтвержденные `после-0..2` пропадают после нечистых выборов.
- `dumplog.sh`: пакет из 100 записей zstd - 1304 байта; маркер транзакции - 78 байт с `producerEpoch: 1`; `--verify-index-only` на активном сегменте сообщает о ложном расхождении.
- `bookchecks.sh`: ключ `a7d6506c` с murmur2 = `Integer.MIN_VALUE` находится перебором примерно за 20–30 с и роняет разделитель из книги с `IllegalArgumentException`.
