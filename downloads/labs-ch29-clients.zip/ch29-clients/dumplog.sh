#!/usr/bin/env bash
# Сегмент партиции глазами kafka-dump-log.sh (подразделы 2.1, 2.4, 2.6 главы 29).
# Поднимает один узел apache/kafka:4.3.1 в Docker, пишет в него DumpLogFeed и разбирает файлы партиции.
# Запуск из labs/ch29-clients после сборки: ./dumplog.sh > s29-dumplog.txt
set -u
export MSYS_NO_PATHCONV=1   # Git Bash на Windows иначе переписывает /var/... в путь Windows
IMG=apache/kafka:4.3.1
D=/var/lib/kafka/data
docker rm -f k29 >/dev/null 2>&1
docker run -d --name k29 -p 39092:39092 \
  -e KAFKA_NODE_ID=1 -e KAFKA_PROCESS_ROLES=broker,controller \
  -e KAFKA_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093,EXTERNAL://:39092 \
  -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092,EXTERNAL://localhost:39092 \
  -e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT,CONTROLLER:PLAINTEXT,EXTERNAL:PLAINTEXT \
  -e KAFKA_CONTROLLER_LISTENER_NAMES=CONTROLLER -e KAFKA_CONTROLLER_QUORUM_VOTERS=1@localhost:9093 \
  -e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT -e KAFKA_LOG_DIRS=$D \
  -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 -e KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR=1 \
  -e KAFKA_TRANSACTION_STATE_LOG_MIN_ISR=1 $IMG >/dev/null
for i in $(seq 1 60); do docker exec k29 /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list >/dev/null 2>&1 && break; sleep 1; done
echo "=== брокер $IMG готов"
CP="target/classes;$(cat cp431.txt)"   # клиент Kafka 4.3.1
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dorg.slf4j.simpleLogger.defaultLogLevel=error -cp "$CP" k.DumpLogFeed localhost:39092
P=$D/payments-0
echo "=== 2.1 каталог партиции (активный сегмент)"
docker exec k29 ls -l $P
echo "=== 2.6 заголовки пакетов"
docker exec k29 /opt/kafka/bin/kafka-dump-log.sh --files $P/00000000000000000000.log
echo "=== 2.6 записи первого пакета (--deep-iteration --print-data-log), первые 3"
docker exec k29 /opt/kafka/bin/kafka-dump-log.sh --files $P/00000000000000000000.log --deep-iteration --print-data-log | sed -n '1,6p'
echo "=== 2.6 проверка индексов"
docker exec k29 /opt/kafka/bin/kafka-dump-log.sh --files $P/00000000000000000000.index --index-sanity-check
docker exec k29 /opt/kafka/bin/kafka-dump-log.sh --files $P/00000000000000000000.index --verify-index-only
echo "=== 2.1 принудительный роллинг: segment.ms=1000, ещё одна запись"
docker exec k29 /opt/kafka/bin/kafka-configs.sh --bootstrap-server localhost:9092 --alter --entity-type topics --entity-name payments --add-config segment.ms=1000 >/dev/null
sleep 3
docker exec k29 bash -c "echo 'k:{\"paymentId\":\"pay-roll\"}' | /opt/kafka/bin/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic payments --property parse.key=true --property key.separator=:" 2>/dev/null
sleep 3
docker exec k29 ls -l $P
echo "=== 2.6 снимок состояния производителей"
for f in $(docker exec k29 bash -c "ls $P/*.snapshot"); do docker exec k29 /opt/kafka/bin/kafka-dump-log.sh --files $f; done
echo "=== 2.6 leader-epoch-checkpoint и partition.metadata"
docker exec k29 cat $P/leader-epoch-checkpoint
docker exec k29 cat $P/partition.metadata
echo "=== 2.6 --verify-index-only после роллинга: закрытый сегмент 0 и новый активный 111"
docker exec k29 /opt/kafka/bin/kafka-dump-log.sh --files $P/00000000000000000000.index --verify-index-only
docker exec k29 /opt/kafka/bin/kafka-dump-log.sh --files $P/00000000000000000000.timeindex
docker exec k29 /opt/kafka/bin/kafka-dump-log.sh --files $P/00000000000000000111.index --verify-index-only
docker rm -f k29 >/dev/null
