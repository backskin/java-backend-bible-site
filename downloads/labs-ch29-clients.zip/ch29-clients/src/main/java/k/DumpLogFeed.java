package k;

import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * Пишет в тему payments (1 партиция) три пакета для разбора kafka-dump-log.sh (подраздел 2.6 главы 29):
 * транзакционный пакет из 100 платежей со сжатием zstd и двумя заголовками, затем идемпотентный пакет без сжатия.
 * Брокер — Docker-контейнер из dumplog.sh, адрес localhost:39092.
 */
public class DumpLogFeed {
    public static void main(String[] args) throws Exception {
        String bs = args.length > 0 ? args[0] : "localhost:39092";
        try (Admin a = Admin.create(Map.of("bootstrap.servers", bs))) {
            a.createTopics(List.of(new NewTopic("payments", 1, (short) 1))).all().get();
        }
        Map<String, Object> base = Map.of(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bs,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.LINGER_MS_CONFIG, 50,
                ProducerConfig.BATCH_SIZE_CONFIG, 1 << 20);
        var tx = new java.util.HashMap<String, Object>(base);
        tx.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, "payment-enricher-0");
        tx.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "zstd");
        try (var p = new KafkaProducer<String, String>(tx)) {
            p.initTransactions();
            p.beginTransaction();
            for (int i = 0; i < 100; i++) {
                String json = String.format("{\"paymentId\":\"pay-%06d\",\"account\":\"40817810%012d\",\"amount\":\"%d.00\",\"currency\":\"RUB\",\"merchant\":\"mcc-5411-korzina-plus\",\"status\":\"AUTHORIZED\",\"channel\":\"card-present\"}",
                        i, 991200 + i % 7, 100 + i * 13);
                var r = new ProducerRecord<>("payments", "acct-" + (991200 + i % 7), json);
                r.headers().add("traceparent", ("00-4bf92f3577b34da6a3ce929d0e0e" + String.format("%04d", i) + "-00f067aa0ba902b7-01").getBytes(StandardCharsets.UTF_8));
                r.headers().add("eventType", "PaymentAuthorized".getBytes(StandardCharsets.UTF_8));
                p.send(r);
            }
            p.commitTransaction();
        }
        var idem = new java.util.HashMap<String, Object>(base);
        try (var p = new KafkaProducer<String, String>(idem)) {
            for (int i = 0; i < 10; i++)
                p.send(new ProducerRecord<>("payments", "acct-" + (991200 + i), "{\"paymentId\":\"pay-x" + i + "\",\"amount\":\"1.00\"}"));
            p.flush();
        }
        System.out.println("записано: транзакция из 100 записей (zstd) и 10 записей идемпотентного производителя без сжатия");
    }
}
