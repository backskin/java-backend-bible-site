package k;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.admin.TopicDescription;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.kafka.test.EmbeddedKafkaKraftBroker;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Брокер, партиции, acks, идемпотентность и транзакции на настоящем Kafka 4.x, поднятом внутри процесса.
 * Зависимости Maven: org.springframework.kafka:spring-kafka и spring-kafka-test (версии задаёт Spring Boot 4.1.1).
 */
public class KafkaBasics {

    static String bootstrap;

    static Map<String, Object> producerProps(Object... kv) {
        Map<String, Object> p = new HashMap<>();
        p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        for (int i = 0; i < kv.length; i += 2) p.put((String) kv[i], kv[i + 1]);
        return p;
    }

    static KafkaConsumer<String, String> consumer(String group, Object... kv) {
        Map<String, Object> p = new HashMap<>();
        p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        p.put(ConsumerConfig.GROUP_ID_CONFIG, group);
        p.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        for (int i = 0; i < kv.length; i += 2) p.put((String) kv[i], kv[i + 1]);
        return new KafkaConsumer<>(p);
    }

    /** Читает тему до тишины и возвращает все записи. */
    static List<ConsumerRecord<String, String>> readAll(String topic, String group, Object... kv) {
        List<ConsumerRecord<String, String>> out = new ArrayList<>();
        try (KafkaConsumer<String, String> c = consumer(group, kv)) {
            c.subscribe(List.of(topic));
            int idle = 0;
            while (idle < 3) {
                var recs = c.poll(Duration.ofMillis(500));
                if (recs.isEmpty()) idle++;
                else { idle = 0; recs.forEach(out::add); }
            }
        }
        return out;
    }

    static void describe(AdminClient admin, String topic) throws Exception {
        TopicDescription d = admin.describeTopics(List.of(topic)).allTopicNames().get().get(topic);
        d.partitions().forEach(p -> System.out.printf("  партиция %d: лидер брокер %d, реплики %s, ISR %s%n", p.partition(), p.leader().id(),
                p.replicas().stream().map(n -> n.id()).toList(), p.isr().stream().map(n -> n.id()).toList()));
    }

    public static void main(String[] args) throws Exception {
        // ---- кластер из трёх брокеров: реплики, ISR, acks
        EmbeddedKafkaKraftBroker three = new EmbeddedKafkaKraftBroker(3, 3);
        three.brokerProperty("replica.lag.time.max.ms", "3000");
        three.afterPropertiesSet();
        bootstrap = three.getBrokersAsString();
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            admin.createTopics(List.of(
                    new NewTopic("payments", 3, (short) 3),
                    new NewTopic("strict", 1, (short) 3).configs(Map.of("min.insync.replicas", "3")))).all().get();

            System.out.println("=== 4.1 лидер, реплики, ISR: тема payments, 3 партиции, фактор репликации 3");
            describe(admin, "payments");

            System.out.println("=== 4.3 acks и min.insync.replicas: тема strict (3 реплики, min.insync.replicas = 3)");
            try (KafkaProducer<String, String> p = new KafkaProducer<>(producerProps(ProducerConfig.ACKS_CONFIG, "all"))) {
                System.out.println("  все три реплики в ISR, acks=all: запись принята, офсет " + p.send(new ProducerRecord<>("strict", "k", "v")).get().offset());
            }
            int leader = admin.describeTopics(List.of("strict")).allTopicNames().get().get("strict").partitions().get(0).leader().id();
            int controller = admin.describeMetadataQuorum().quorumInfo().get(10, TimeUnit.SECONDS).leaderId();   // активный контроллер кворума
            int victim = three.getCluster().brokers().keySet().stream().filter(i -> i != leader && i != controller).findFirst().orElseThrow();
            Thread.ofPlatform().start(() -> three.getCluster().brokers().get(victim).shutdown());   // не лидер партиции и не контроллер
            System.out.println("  останавливаем брокер " + victim + " (не лидер партиции и не активный контроллер); ждём, пока ISR сократится");
            for (int i = 0; i < 80; i++) {
                int isr = admin.describeTopics(List.of("strict")).allTopicNames().get().get("strict").partitions().get(0).isr().size();
                if (isr < 3) break;
                Thread.sleep(500);
            }
            for (String acks : new String[]{"all", "1"}) {
                try (KafkaProducer<String, String> p = new KafkaProducer<>(producerProps(
                        ProducerConfig.ACKS_CONFIG, acks, ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "false",
                        ProducerConfig.RETRIES_CONFIG, 0, ProducerConfig.MAX_BLOCK_MS_CONFIG, 5000))) {
                    try {
                        var md = p.send(new ProducerRecord<>("strict", "k", "v2")).get();
                        System.out.println("  acks=" + acks + ": запись принята, офсет " + md.offset());
                    } catch (ExecutionException e) {
                        System.out.println("  acks=" + acks + ": " + e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage());
                    }
                }
            }
            admin.incrementalAlterConfigs(Map.of(new org.apache.kafka.common.config.ConfigResource(org.apache.kafka.common.config.ConfigResource.Type.TOPIC, "strict"),
                    List.of(new org.apache.kafka.clients.admin.AlterConfigOp(new org.apache.kafka.clients.admin.ConfigEntry("min.insync.replicas", "2"),
                            org.apache.kafka.clients.admin.AlterConfigOp.OpType.SET)))).all().get();
            System.out.println("  min.insync.replicas темы strict снижен до 2");
            try (KafkaProducer<String, String> p = new KafkaProducer<>(producerProps(ProducerConfig.ACKS_CONFIG, "all"))) {
                for (int i = 0; i < 20; i++) {
                    try {
                        var md = p.send(new ProducerRecord<>("strict", "k", "v3")).get();
                        System.out.println("  acks=all при ISR из двух реплик и min.insync.replicas=2: запись принята, офсет " + md.offset());
                        break;
                    } catch (ExecutionException e) { Thread.sleep(500); }
                }
            }
        }
        three.destroy();

        // ---- один брокер: остальное быстрее, а транзакциям нужна тема состояния с фактором репликации 1
        EmbeddedKafkaKraftBroker one = new EmbeddedKafkaKraftBroker(1, 3);
        one.brokerProperty("transaction.state.log.replication.factor", "1");
        one.brokerProperty("transaction.state.log.min.isr", "1");
        one.brokerProperty("offsets.topic.replication.factor", "1");
        one.afterPropertiesSet();
        bootstrap = one.getBrokersAsString();
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            admin.createTopics(List.of(new NewTopic("payments", 3, (short) 1), new NewTopic("tx", 1, (short) 1))).all().get();
        }

        System.out.println("=== 5.4 партиционирование и порядок: 4 ключа по 3 сообщения, 3 партиции");
        try (KafkaProducer<String, String> p = new KafkaProducer<>(producerProps())) {
            for (int round = 1; round <= 3; round++)
                for (String key : List.of("acc-1", "acc-2", "acc-3", "acc-4"))
                    p.send(new ProducerRecord<>("payments", key, key + "#" + round)).get();
        }
        Map<Integer, List<String>> byPartition = new TreeMap<>();
        for (var r : readAll("payments", "g-order")) byPartition.computeIfAbsent(r.partition(), x -> new ArrayList<>()).add(r.value());
        byPartition.forEach((part, vals) -> System.out.println("  партиция " + part + ": " + vals));

        System.out.println("=== 5.5 идемпотентный продюсер: настройки по умолчанию и несовместимые");
        try (KafkaProducer<String, String> p = new KafkaProducer<>(producerProps(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true", ProducerConfig.ACKS_CONFIG, "1"))) {
            System.out.println("  enable.idempotence=true, acks=1: продюсер создан");
        } catch (Exception e) {
            System.out.println("  enable.idempotence=true и acks=1: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        try (KafkaProducer<String, String> p = new KafkaProducer<>(producerProps(ProducerConfig.ACKS_CONFIG, "1"))) {
            System.out.println("  только acks=1, идемпотентность не задана: продюсер создан (идемпотентность отключена молча)");
        } catch (Exception e) {
            System.out.println("  только acks=1: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        try (KafkaProducer<String, String> p = new KafkaProducer<>(producerProps())) {
            System.out.println("  без настроек: продюсер создан; в Kafka 3.0+ по умолчанию enable.idempotence=true и acks=all");
        }

        System.out.println("=== 5.6 и 7.2 транзакции продюсера: что видит читатель");
        try (KafkaProducer<String, String> p = new KafkaProducer<>(producerProps(ProducerConfig.TRANSACTIONAL_ID_CONFIG, "tx-1"))) {
            p.initTransactions();
            p.beginTransaction();
            for (int i = 1; i <= 3; i++) p.send(new ProducerRecord<>("tx", "k", "отменённая-" + i));
            p.flush();
            p.abortTransaction();
            p.beginTransaction();
            for (int i = 1; i <= 2; i++) p.send(new ProducerRecord<>("tx", "k", "зафиксированная-" + i));
            p.commitTransaction();
        }
        var uncommitted = readAll("tx", "g-ru", ConsumerConfig.ISOLATION_LEVEL_CONFIG, "read_uncommitted");
        var committed = readAll("tx", "g-rc", ConsumerConfig.ISOLATION_LEVEL_CONFIG, "read_committed");
        System.out.println("  read_uncommitted видит " + uncommitted.size() + " записей: " + uncommitted.stream().map(ConsumerRecord::value).toList());
        System.out.println("  read_committed видит   " + committed.size() + " записей: " + committed.stream().map(ConsumerRecord::value).toList());
        try (KafkaConsumer<String, String> c = consumer("g-pos")) {
            TopicPartition tp = new TopicPartition("tx", 0);
            c.assign(List.of(tp));
            System.out.println("  конец журнала партиции (endOffsets): " + c.endOffsets(List.of(tp)).get(tp)
                    + " (3 отменённых + 2 зафиксированных + 2 маркера транзакций)");
        }
        one.destroy();
        System.exit(0);
    }
}
