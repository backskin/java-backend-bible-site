package k;

import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.test.KafkaClusterTestKit;
import org.apache.kafka.common.test.TestKitNodes;

import java.time.Duration;
import java.util.*;

/** Нечистый лидер для главы 29: подтверждённые acks=all записи пропадают, когда лидером становится отставшая реплика. */
public class K29c {
    static String bs;

    static String state(Admin a) throws Exception {
        var p = a.describeTopics(List.of("unclean")).allTopicNames().get().get("unclean").partitions().get(0);
        return "лидер " + (p.leader() == null ? "нет" : p.leader().id()) + ", ISR " + p.isr().stream().map(n -> n.id()).toList()
                + ", ELR " + (p.elr() == null ? "-" : p.elr().stream().map(n -> n.id()).toList());
    }

    static List<String> read() {
        KafkaBasics.bootstrap = bs;
        List<String> out = new ArrayList<>();
        try (var c = KafkaBasics.consumer("unused", ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false")) {
            var tp = new TopicPartition("unclean", 0);
            c.assign(List.of(tp));
            c.seekToBeginning(List.of(tp));
            int idle = 0;
            while (idle < 6) { var r = c.poll(Duration.ofMillis(500)); if (r.isEmpty()) idle++; else { idle = 0; r.forEach(x -> out.add(x.value())); } }
        }
        return out;
    }

    public static void main(String[] args) throws Exception {
        var cl = new KafkaClusterTestKit.Builder(new TestKitNodes.Builder().setCombined(false).setNumControllerNodes(1).setNumBrokerNodes(3).build())
                .setConfigProp("replica.lag.time.max.ms", "3000").build();
        cl.format();
        cl.startup();
        cl.waitForReadyBrokers();
        bs = cl.bootstrapServers();
        List<Integer> ids = new ArrayList<>(cl.brokers().keySet());
        int lead = ids.get(0), fol = ids.get(1);
        KafkaBasics.bootstrap = bs;
        try (Admin a = Admin.create(Map.of("bootstrap.servers", bs))) {
            a.createTopics(List.of(new NewTopic("unclean", Map.of(0, List.of(lead, fol)))
                    .configs(Map.of("min.insync.replicas", "1", "unclean.leader.election.enable", "true")))).all().get();
            Thread.sleep(2000);
            try (var p = new KafkaProducer<String, String>(KafkaBasics.producerProps(ProducerConfig.ACKS_CONFIG, "all"))) {
                for (int i = 0; i < 3; i++) p.send(new ProducerRecord<>("unclean", "k", "до-" + i)).get();
            }
            System.out.println("1) записаны до-0..до-2, обе реплики в ISR: " + state(a));
            cl.brokers().get(fol).shutdown();
            cl.brokers().get(fol).awaitShutdown();
            for (int i = 0; i < 40 && state(a).contains(", " + fol + "]"); i++) Thread.sleep(500);
            System.out.println("2) последователь " + fol + " остановлен: " + state(a));
            try (var p = new KafkaProducer<String, String>(KafkaBasics.producerProps(ProducerConfig.ACKS_CONFIG, "all"))) {
                for (int i = 0; i < 3; i++) System.out.println("   acks=all подтверждено: после-" + i + ", офсет " + p.send(new ProducerRecord<>("unclean", "k", "после-" + i)).get().offset());
            }
            System.out.println("   в теме: " + read());
            cl.brokers().get(lead).shutdown();
            cl.brokers().get(lead).awaitShutdown();
            Thread.sleep(3000);
            System.out.println("3) лидер " + lead + " тоже остановлен: " + state(a));
            cl.brokers().get(fol).startup();
            String st = "";
            for (int i = 0; i < 80; i++) { st = state(a); if (st.startsWith("лидер " + fol)) break; Thread.sleep(500); }
            System.out.println("4) отставший " + fol + " запущен: " + st);
            System.out.println("   в теме: " + read());
            cl.brokers().get(lead).startup();
            for (int i = 0; i < 80 && !(state(a).contains("ISR [" + fol + ", " + lead) || state(a).contains("ISR [" + lead + ", " + fol)); i++) Thread.sleep(500);
            System.out.println("5) прежний лидер " + lead + " вернулся: " + state(a));
            System.out.println("   в теме: " + read());
        } finally {
            try { cl.close(); } catch (Exception ignored) { }
        }
        System.exit(0);
    }
}
