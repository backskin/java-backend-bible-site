package k;

import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Опыт к разделу 6.2 главы 29: мешает ли "горячая" группа с частыми фиксациями
 * соседним группам, которые попали на ту же партицию {@code __consumer_offsets}.
 *
 * <p>Горячая группа: N потоков, каждый фиксирует смещения 100 партиций в цикле без пауз.
 * Две группы-жертвы (классический протокол, {@code session.timeout.ms=6000}): одна на той же
 * партиции служебного топика, что и горячая, другая на другой партиции. У жертв замеряются
 * задержка {@code commitSync}, максимальное время ответа на сигнал "я жив" и число перебалансировок.
 *
 * <p>Аргументы: адрес брокера, число потоков горячей группы, секунд нагрузки.
 */
public class HotGroup {

    static int shard(String group) {
        return (group.hashCode() & 0x7fffffff) % 50; // Utils.abs(hashCode) % 50 совпадает для всех, кроме MIN_VALUE
    }

    /** Группа-жертва: опрашивает тихий топик и раз в 200 мс фиксирует смещение. */
    static final class Victim implements Runnable {
        final String bootstrap, group;
        final AtomicBoolean stop = new AtomicBoolean();
        final List<Long> lat = Collections.synchronizedList(new ArrayList<>());
        final AtomicInteger rebalances = new AtomicInteger();
        final AtomicInteger errors = new AtomicInteger();
        volatile double hbMax;
        volatile boolean measuring;

        Victim(String bootstrap, String group) { this.bootstrap = bootstrap; this.group = group; }

        public void run() {
            Properties p = new Properties();
            p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
            p.put(ConsumerConfig.GROUP_ID_CONFIG, group);
            p.put(ConsumerConfig.GROUP_PROTOCOL_CONFIG, "classic");
            p.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "6000");
            p.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, "2000");
            p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
            p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(p)) {
                c.subscribe(List.of("quiet"), new ConsumerRebalanceListener() {
                    public void onPartitionsRevoked(Collection<TopicPartition> parts) { if (measuring) rebalances.incrementAndGet(); }
                    public void onPartitionsAssigned(Collection<TopicPartition> parts) { }
                    public void onPartitionsLost(Collection<TopicPartition> parts) { if (measuring) rebalances.incrementAndGet(); }
                });
                TopicPartition tp = new TopicPartition("quiet", 0);
                long off = 0;
                while (!stop.get()) {
                    c.poll(Duration.ofMillis(100));
                    if (!c.assignment().contains(tp)) continue;
                    long t0 = System.nanoTime();
                    try {
                        c.commitSync(Map.of(tp, new OffsetAndMetadata(0, "n" + (off++))), Duration.ofSeconds(30));
                        if (measuring) lat.add((System.nanoTime() - t0) / 1_000_000);
                    } catch (Exception e) {
                        if (measuring) errors.incrementAndGet();
                    }
                    for (Map.Entry<MetricName, ? extends Metric> m : c.metrics().entrySet()) {
                        if (m.getKey().name().equals("heartbeat-response-time-max") && measuring) {
                            Object v = m.getValue().metricValue();
                            if (v instanceof Double d && !d.isNaN()) hbMax = Math.max(hbMax, d);
                        }
                    }
                    try { Thread.sleep(200); } catch (InterruptedException e) { return; }
                }
            }
        }

        void reset() { lat.clear(); rebalances.set(0); errors.set(0); hbMax = 0; }

        String report() {
            List<Long> s;
            synchronized (lat) { s = new ArrayList<>(lat); }
            Collections.sort(s);
            if (s.isEmpty()) return String.format("%-10s фиксаций 0, ошибок %d, перебалансировок %d", group, errors.get(), rebalances.get());
            return String.format("%-10s партиция %2d: фиксаций %4d, мс p50 %4d, p99 %5d, макс %5d; ответ на «я жив» макс %5.0f мс; ошибок %d; перебалансировок %d",
                    group, shard(group), s.size(), s.get(s.size() / 2), s.get((int) (s.size() * 0.99)), s.get(s.size() - 1),
                    hbMax, errors.get(), rebalances.get());
        }
    }

    public static void main(String[] args) throws Exception {
        String bootstrap = args[0];
        int threads = Integer.parseInt(args[1]);
        int seconds = Integer.parseInt(args[2]);

        String hot = "hot";
        String same = null, other = null;
        for (int i = 0; same == null || other == null; i++) {
            String g = "victim-" + i;
            if (same == null && shard(g) == shard(hot)) same = g;
            if (other == null && shard(g) != shard(hot)) other = g;
        }
        System.out.printf("горячая группа %s -> партиция __consumer_offsets %d; жертвы %s -> %d, %s -> %d%n",
                hot, shard(hot), same, shard(same), other, shard(other));

        try (Admin a = Admin.create(Map.of(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap))) {
            a.createTopics(List.of(new NewTopic("quiet", 1, (short) 1), new NewTopic("wide", 100, (short) 1))).all().get();
        }

        Victim vs = new Victim(bootstrap, same), vo = new Victim(bootstrap, other);
        Thread t1 = new Thread(vs), t2 = new Thread(vo);
        t1.start(); t2.start();
        Thread.sleep(8000); // жертвы вступают в группы
        vs.measuring = vo.measuring = true;
        Thread.sleep(15000);
        System.out.println("--- без нагрузки, 15 с");
        System.out.println(vs.report());
        System.out.println(vo.report());
        vs.reset(); vo.reset();

        AtomicBoolean stopHot = new AtomicBoolean();
        AtomicLong hotCommits = new AtomicLong();
        List<Thread> hotThreads = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            Thread t = new Thread(() -> {
                Properties p = new Properties();
                p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
                p.put(ConsumerConfig.GROUP_ID_CONFIG, hot);
                p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
                p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
                try (KafkaConsumer<String, String> c = new KafkaConsumer<>(p)) {
                    List<TopicPartition> parts = new ArrayList<>();
                    for (int k = 0; k < 100; k++) parts.add(new TopicPartition("wide", k));
                    c.assign(parts); // фиксации без членства в группе: только нагрузка на координатор
                    long off = 0;
                    String meta = "x".repeat(200);
                    while (!stopHot.get()) {
                        Map<TopicPartition, OffsetAndMetadata> m = new HashMap<>();
                        for (TopicPartition tp : parts) m.put(tp, new OffsetAndMetadata(0, meta + off));
                        off++;
                        try { c.commitSync(m, Duration.ofSeconds(30)); hotCommits.incrementAndGet(); } catch (Exception e) { /* под нагрузкой */ }
                    }
                }
            });
            t.start();
            hotThreads.add(t);
        }
        long start = System.nanoTime();
        Thread.sleep(seconds * 1000L);
        stopHot.set(true);
        for (Thread t : hotThreads) t.join();
        double sec = (System.nanoTime() - start) / 1e9;
        System.out.printf("--- горячая группа: %d потоков, %d с, %.0f фиксаций по 100 партиций в секунду (%.0f записей смещений в секунду)%n",
                threads, seconds, hotCommits.get() / sec, hotCommits.get() * 100 / sec);
        System.out.println(vs.report());
        System.out.println(vo.report());
        vs.stop.set(true); vo.stop.set(true);
        t1.join(); t2.join();
    }
}
