package k;

import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;
import org.springframework.kafka.test.EmbeddedKafkaKraftBroker;

import java.util.*;

/** Глава 29: фенсинг при стабильном и случайном transactional.id; степень сжатия JSON в зависимости от linger.ms. */
public class K29d {
    static void tx(String label, String id1, String id2) {
        var p1 = new KafkaProducer<String, String>(KafkaBasics.producerProps(ProducerConfig.TRANSACTIONAL_ID_CONFIG, id1));
        var p2 = new KafkaProducer<String, String>(KafkaBasics.producerProps(ProducerConfig.TRANSACTIONAL_ID_CONFIG, id2));
        p1.initTransactions();
        p1.beginTransaction();
        p1.send(new ProducerRecord<>("tx-out", "k", label + "-первый"));
        p2.initTransactions();          // второй экземпляр стартует, пока первый «завис» с открытой транзакцией
        p2.beginTransaction();
        p2.send(new ProducerRecord<>("tx-out", "k", label + "-второй"));
        p2.commitTransaction();
        try {
            p1.commitTransaction();
            System.out.println("  " + label + ": первый экземпляр тоже зафиксировал транзакцию");
        } catch (Exception e) {
            System.out.println("  " + label + ": первый экземпляр отгорожен: " + e.getClass().getSimpleName());
        }
        p1.close();
        p2.close();
    }

    static double metric(KafkaProducer<?, ?> p, String name) {
        for (Map.Entry<MetricName, ? extends Metric> e : p.metrics().entrySet())
            if (e.getKey().name().equals(name) && e.getKey().group().equals("producer-metrics")) return ((Number) e.getValue().metricValue()).doubleValue();
        return Double.NaN;
    }

    public static void main(String[] args) throws Exception {
        EmbeddedKafkaKraftBroker b = new EmbeddedKafkaKraftBroker(1, 1);
        b.brokerProperty("transaction.state.log.replication.factor", "1");
        b.brokerProperty("transaction.state.log.min.isr", "1");
        b.afterPropertiesSet();
        KafkaBasics.bootstrap = b.getBrokersAsString();
        try (Admin a = Admin.create(Map.of("bootstrap.servers", KafkaBasics.bootstrap))) {
            a.createTopics(List.of(new NewTopic("tx-out", 1, (short) 1), new NewTopic("json", 1, (short) 1))).all().get();
        }
        System.out.println("=== transactional.id");
        tx("стабильный", "payments-tx-0", "payments-tx-0");
        tx("случайный", "payments-" + UUID.randomUUID(), "payments-" + UUID.randomUUID());
        var got = KafkaBasics.readAll("tx-out", "rd", "isolation.level", "read_committed").stream().map(r -> r.value()).toList();
        System.out.println("  в выходной теме (read_committed): " + got);

        System.out.println("\n=== сжатие однотипного JSON, 1000 записей/с примерно по 300 байт, 5 секунд");
        Random rnd = new Random(42);
        for (String codec : List.of("lz4", "zstd")) {
            for (int linger : List.of(5, 50)) {
                try (var p = new KafkaProducer<String, String>(KafkaBasics.producerProps(ProducerConfig.COMPRESSION_TYPE_CONFIG, codec,
                        ProducerConfig.LINGER_MS_CONFIG, linger))) {
                    long start = System.nanoTime();
                    for (int i = 0; i < 5000; i++) {
                        String json = String.format("{\"paymentId\":\"%s\",\"accountFrom\":\"40817810%012d\",\"accountTo\":\"40702810%012d\","
                                        + "\"amount\":%d.%02d,\"currency\":\"RUB\",\"status\":\"AUTHORIZED\",\"channel\":\"MOBILE\",\"mcc\":\"5411\","
                                        + "\"createdAt\":\"2026-10-22T23:%02d:%02d.%03dZ\",\"merchant\":\"ООО Ромашка\",\"region\":\"77\"}",
                                UUID.randomUUID(), rnd.nextInt(1_000_000_000), rnd.nextInt(1_000_000_000), rnd.nextInt(100_000), rnd.nextInt(100),
                                i / 60000 % 60, i / 1000 % 60, i % 1000);
                        p.send(new ProducerRecord<>("json", "acc-" + rnd.nextInt(1000), json));
                        long due = start + (i + 1) * 1_000_000L;        // 1000 записей в секунду
                        while (System.nanoTime() < due) Thread.onSpinWait();
                    }
                    p.flush();
                    System.out.printf("  %s, linger.ms=%d: записей в пакете %.1f, средний размер пакета %.0f Б, compression-rate-avg %.3f (сжатие в %.1f раза)%n",
                            codec, linger, metric(p, "records-per-request-avg"), metric(p, "batch-size-avg"),
                            metric(p, "compression-rate-avg"), 1 / metric(p, "compression-rate-avg"));
                }
            }
        }
        b.destroy();
        System.exit(0);
    }
}
