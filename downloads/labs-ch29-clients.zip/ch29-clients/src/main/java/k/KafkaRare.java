package k;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.ProducerFencedException;
import org.apache.kafka.common.serialization.IntegerDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.test.EmbeddedKafkaKraftBroker;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Редкие случаи потребителя и продюсера Kafka: max.poll.records, смещение коммита, фенсинг транзакций,
 * автокоммит с передачей обработки в другой поток, ключ дедупликации, статическое членство, ErrorHandlingDeserializer.
 * Зависимости Maven: org.springframework.kafka:spring-kafka и spring-kafka-test (версии задаёт Spring Boot 4.1.1).
 * Один встроенный брокер Kafka 4.x. Запуск: main (около двух минут).
 */
public class KafkaRare {

    static String bootstrap;

    static Map<String, Object> cprops(String group, Object... kv) {
        Map<String, Object> p = new HashMap<>();
        p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        p.put(ConsumerConfig.GROUP_ID_CONFIG, group);
        p.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        p.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        for (int i = 0; i < kv.length; i += 2) p.put((String) kv[i], kv[i + 1]);
        return p;
    }

    static KafkaProducer<String, String> producer(Object... kv) {
        Map<String, Object> p = new HashMap<>();
        p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        for (int i = 0; i < kv.length; i += 2) p.put((String) kv[i], kv[i + 1]);
        return new KafkaProducer<>(p);
    }

    static void send(String topic, List<String> values) throws Exception {
        try (KafkaProducer<String, String> p = producer()) { for (String v : values) p.send(new ProducerRecord<>(topic, v.split("#")[0], v)).get(); }
    }

    static List<String> range(String prefix, int n) { List<String> l = new ArrayList<>(); for (int i = 1; i <= n; i++) l.add(prefix + i); return l; }

    // ------------------------------------------------------------------ 6.6 max.poll.records
    static void maxPollRecords() throws Exception {
        System.out.println("=== 6.6 max.poll.records и max.poll.interval.ms (обработка записи 100 мс, интервал 1500 мс)");
        for (int perPoll : new int[]{20, 5}) {
            String topic = "slow-" + perPoll;
            send(topic, range("m", 20));
            String result;
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cprops("g-" + topic, ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, 1500, ConsumerConfig.MAX_POLL_RECORDS_CONFIG, perPoll))) {
                c.subscribe(List.of(topic));
                ConsumerRecords<String, String> recs = ConsumerRecords.empty();
                for (int i = 0; i < 20 && recs.isEmpty(); i++) recs = c.poll(Duration.ofMillis(500));
                for (ConsumerRecord<String, String> r : recs) Thread.sleep(100);
                try { c.commitSync(); result = "commitSync прошёл (обработано " + recs.count() + " за " + recs.count() * 100 + " мс)"; }
                catch (CommitFailedException e) { result = "CommitFailedException (обработано " + recs.count() + " за " + recs.count() * 100 + " мс)"; }
            }
            System.out.printf("  max.poll.records=%-3d %s%n", perPoll, result);
        }
    }

    // ------------------------------------------------------------------ 6.7 смещение коммита
    static void commitOffsetByOne() throws Exception {
        System.out.println("=== 6.7 что именно коммитить: offset записи или offset + 1");
        for (int shift : new int[]{0, 1}) {
            String topic = "off-" + shift;
            send(topic, range("m", 5));
            int reread = 0;
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cprops("g-" + topic))) {
                c.subscribe(List.of(topic));
                int seen = 0;
                for (int i = 0; i < 20 && seen < 5; i++) for (ConsumerRecord<String, String> r : c.poll(Duration.ofMillis(500))) {
                    seen++;
                    c.commitSync(Map.of(new TopicPartition(topic, r.partition()), new OffsetAndMetadata(r.offset() + shift)));
                }
            }
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cprops("g-" + topic))) {
                c.subscribe(List.of(topic));
                for (int i = 0; i < 4; i++) reread += c.poll(Duration.ofMillis(500)).count();
            }
            System.out.printf("  коммит offset%s: после перезапуска прочитано заново записей: %d%n", shift == 0 ? "     " : " + 1", reread);
        }
    }

    // ------------------------------------------------------------------ 7.2 фенсинг транзакционного продюсера
    static void fencing() throws Exception {
        System.out.println("=== 7.2 два продюсера с одним transactional.id");
        try (KafkaProducer<String, String> old = producer(ProducerConfig.TRANSACTIONAL_ID_CONFIG, "payments-tx-1")) {
            old.initTransactions();
            old.beginTransaction();
            old.send(new ProducerRecord<>("tx-out", "k", "от старого экземпляра")).get();
            try (KafkaProducer<String, String> fresh = producer(ProducerConfig.TRANSACTIONAL_ID_CONFIG, "payments-tx-1")) {
                fresh.initTransactions();
                System.out.println("  новый экземпляр с тем же transactional.id выполнил initTransactions");
                try { old.commitTransaction(); System.out.println("  старый экземпляр: commitTransaction прошёл"); }
                catch (ProducerFencedException e) { System.out.println("  старый экземпляр: commitTransaction -> ProducerFencedException (его запись отброшена)"); }
                catch (Exception e) { System.out.println("  старый экземпляр: " + e.getClass().getSimpleName()); }
            }
        }
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cprops("g-tx-out", ConsumerConfig.ISOLATION_LEVEL_CONFIG, "read_committed"))) {
            c.subscribe(List.of("tx-out"));
            int n = 0;
            for (int i = 0; i < 4; i++) n += c.poll(Duration.ofMillis(500)).count();
            System.out.println("  читатель read_committed увидел записей: " + n);
        }
    }

    // ------------------------------------------------------------------ 7.1 автокоммит и передача обработки в другой поток
    static void autoCommitAsync() throws Exception {
        System.out.println("=== 7.1 автокоммит + обработка в пуле потоков, «падение» через 1 с (30 записей, обработка 200 мс, 4 потока)");
        send("async", range("m", 30));
        Set<String> processed = ConcurrentHashMap.newKeySet();
        ExecutorService pool = Executors.newFixedThreadPool(4);
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cprops("g-async", ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true", ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, 100, ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 10))) {
            c.subscribe(List.of("async"));
            long end = System.nanoTime() + 1_000_000_000L;
            while (System.nanoTime() < end) for (ConsumerRecord<String, String> r : c.poll(Duration.ofMillis(100)))
                pool.submit(() -> { try { Thread.sleep(200); } catch (InterruptedException e) { return; } processed.add(r.value()); });
            pool.shutdownNow();
            c.close(Duration.ofMillis(1));
        }
        int first = processed.size();
        int second = 0;
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cprops("g-async"))) {
            c.subscribe(List.of("async"));
            for (int i = 0; i < 4; i++) for (ConsumerRecord<String, String> r : c.poll(Duration.ofMillis(500))) { processed.add(r.value()); second++; }
        }
        System.out.printf("  до падения обработано %d, после перезапуска получено %d, итого обработано %d из 30 (потеряно %d)%n", first, second, processed.size(), 30 - processed.size());
    }

    // ------------------------------------------------------------------ 7.3 ключ дедупликации
    static void dedupeKey() throws Exception {
        System.out.println("=== 7.3 ключ дедупликации: клиент повторил платёж pay-2 после таймаута (две записи с разными offset)");
        send("dup", List.of("pay-1#a", "pay-2#a", "pay-2#b", "pay-3#a"));
        Set<String> byOffset = new HashSet<>(), byBusinessId = new HashSet<>();
        int processedByOffset = 0, processedById = 0;
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cprops("g-dup"))) {
            c.subscribe(List.of("dup"));
            for (int i = 0; i < 4; i++) for (ConsumerRecord<String, String> r : c.poll(Duration.ofMillis(500))) {
                if (byOffset.add(r.partition() + ":" + r.offset())) processedByOffset++;
                if (byBusinessId.add(r.key())) processedById++;
            }
        }
        System.out.println("  дедупликация по (partition, offset): платежей проведено " + processedByOffset + "; по бизнес-идентификатору: " + processedById);
    }

    // ------------------------------------------------------------------ 14.2 статическое членство
    static int rebalanceEvents(boolean statik) throws Exception {
        String topic = "stat-" + statik, group = "g-" + topic;
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) { admin.createTopics(List.of(new NewTopic(topic, 4, (short) 1))).all().get(); }
        AtomicInteger events = new AtomicInteger();
        AtomicBoolean stopB = new AtomicBoolean();
        Thread b = new Thread(() -> {
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(cprops(group, ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 20000, ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 500))) {
                c.subscribe(List.of(topic), new ConsumerRebalanceListener() {
                    public void onPartitionsRevoked(Collection<TopicPartition> p) { if (!p.isEmpty()) events.incrementAndGet(); }
                    public void onPartitionsAssigned(Collection<TopicPartition> p) { }
                });
                while (!stopB.get()) c.poll(Duration.ofMillis(200));
            }
        });
        b.start();
        Object[] aprops = statik ? new Object[]{ConsumerConfig.GROUP_INSTANCE_ID_CONFIG, "a-1", ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 20000, ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 500}
                : new Object[]{ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 20000, ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 500};
        KafkaConsumer<String, String> a = new KafkaConsumer<>(cprops(group, aprops));
        a.subscribe(List.of(topic));
        long end = System.nanoTime() + 5_000_000_000L;
        while (System.nanoTime() < end) a.poll(Duration.ofMillis(200));
        events.set(0);                                                                  // считаем только то, что происходит при перезапуске A
        a.close();
        Thread.sleep(1000);                                                             // перезапуск A занимает секунду
        a = new KafkaConsumer<>(cprops(group, aprops));
        a.subscribe(List.of(topic));
        end = System.nanoTime() + 6_000_000_000L;
        while (System.nanoTime() < end) a.poll(Duration.ofMillis(200));
        a.close();
        stopB.set(true);
        b.join();
        return events.get();
    }

    // ------------------------------------------------------------------ 14.3 ErrorHandlingDeserializer
    static void errorHandlingDeserializer() throws Exception {
        System.out.println("=== 14.3 битая запись в топике: обычный десериализатор и ErrorHandlingDeserializer");
        try (KafkaProducer<String, String> p = producer()) {
            for (String v : new String[]{"\u0000\u0000\u0000d", "oops!","\u0000\u0000\u0001,"}) p.send(new ProducerRecord<>("poison2", "k", v)).get();
        }
        Map<String, Object> props = cprops("g-poison2", ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
        props.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, IntegerDeserializer.class);
        try (KafkaConsumer<String, Integer> c = new KafkaConsumer<>(props)) {
            c.subscribe(List.of("poison2"));
            List<String> seen = new ArrayList<>();
            for (int i = 0; i < 4; i++) for (ConsumerRecord<String, Integer> r : c.poll(Duration.ofMillis(500)))
                seen.add(r.value() == null ? "битая запись (значение null, ошибка в заголовке " + (r.headers().lastHeader("springDeserializerExceptionValue") != null) + ")" : String.valueOf(r.value()));
            System.out.println("  потребитель с ErrorHandlingDeserializer прочитал без остановки: " + seen);
        }
    }

    public static void main(String[] args) throws Exception {
        EmbeddedKafkaKraftBroker broker = new EmbeddedKafkaKraftBroker(1, 3);
        broker.brokerProperty("offsets.topic.replication.factor", "1");
        broker.brokerProperty("transaction.state.log.replication.factor", "1");
        broker.brokerProperty("transaction.state.log.min.isr", "1");
        broker.afterPropertiesSet();
        bootstrap = broker.getBrokersAsString();
        maxPollRecords();
        commitOffsetByOne();
        fencing();
        autoCommitAsync();
        dedupeKey();
        System.out.println("=== 14.2 перезапуск участника группы (A уходит и возвращается через 1 с), события отзыва партиций у участника B");
        System.out.println("  динамическое членство: " + rebalanceEvents(false));
        System.out.println("  статическое членство (group.instance.id): " + rebalanceEvents(true));
        errorHandlingDeserializer();
        broker.destroy();
        System.exit(0);
    }
}
