package k;

import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.ListOffsetsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.admin.OffsetSpec;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.Cluster;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.utils.AppInfoParser;
import org.apache.kafka.common.utils.Utils;
import org.springframework.kafka.test.EmbeddedKafkaKraftBroker;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Проверки утверждений книг и старого текста главы 29 запуском (2026-11-02).
 * Один встроенный брокер (версию печатает первая строка). Запуск: main.
 */
public class BookChecks {

    static String bs;

    /** Разделитель из книги «Kafka: The Definitive Guide», 2-е изд., гл. 3: Math.abs(murmur2) % (n - 1). */
    public static class BookPartitioner implements Partitioner {
        public void configure(Map<String, ?> configs) { }
        public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
            int n = cluster.partitionsForTopic(topic).size();
            if ("Banana".equals(key)) return n - 1;
            return Math.abs(Utils.murmur2(keyBytes)) % (n - 1);
        }
        public void close() { }
    }

    static Map<String, Object> pp(Object... kv) {
        Map<String, Object> p = new HashMap<>();
        p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bs);
        p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.ByteArraySerializer.class);
        p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.ByteArraySerializer.class);
        for (int i = 0; i < kv.length; i += 2) p.put((String) kv[i], kv[i + 1]);
        return p;
    }

    static Map<String, Object> cp(String group, Object... kv) {
        Map<String, Object> p = new HashMap<>();
        p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bs);
        p.put(ConsumerConfig.GROUP_ID_CONFIG, group);
        p.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        p.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.ByteArrayDeserializer.class);
        p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.ByteArrayDeserializer.class);
        for (int i = 0; i < kv.length; i += 2) p.put((String) kv[i], kv[i + 1]);
        return p;
    }

    static String err(Throwable e) {
        Throwable c = e instanceof ExecutionException && e.getCause() != null ? e.getCause() : e;
        String s = c.getClass().getSimpleName() + ": " + c.getMessage();
        if (c.getCause() != null && c.getCause() != c) s += " <- " + c.getCause().getClass().getSimpleName() + ": " + c.getCause().getMessage();
        return s;
    }

    // -------------------------------------------------------------- 1. ключ, у которого murmur2 = Integer.MIN_VALUE
    static byte[] findMinValueKey() {
        byte[] b = new byte[4];
        for (long i = 0; i <= 0xFFFFFFFFL; i++) {
            int v = (int) i;
            b[0] = (byte) (v >>> 24); b[1] = (byte) (v >>> 16); b[2] = (byte) (v >>> 8); b[3] = (byte) v;
            if (Utils.murmur2(b) == Integer.MIN_VALUE) return b.clone();
        }
        return null;
    }

    static void partitionerBug(Admin admin) throws Exception {
        System.out.println("=== 1. разделитель из книги: Math.abs(murmur2(key)) % (n - 1), тема из 6 партиций");
        long t0 = System.currentTimeMillis();
        byte[] key = findMinValueKey();
        System.out.printf("  ключ найден перебором за %d с: %s, murmur2 = %d%n", (System.currentTimeMillis() - t0) / 1000, HexFormat.of().formatHex(key), Utils.murmur2(key));
        System.out.printf("  Math.abs(murmur2) = %d; Math.abs(...) %% 5 = %d%n", Math.abs(Utils.murmur2(key)), Math.abs(Utils.murmur2(key)) % 5);
        System.out.printf("  встроенный разделитель Kafka: Utils.toPositive(murmur2) %% 6 = %d%n", Utils.toPositive(Utils.murmur2(key)) % 6);
        admin.createTopics(List.of(new NewTopic("banana", 6, (short) 1))).all().get();
        try (var p = new KafkaProducer<byte[], byte[]>(pp(ProducerConfig.PARTITIONER_CLASS_CONFIG, BookPartitioner.class.getName(), ProducerConfig.MAX_BLOCK_MS_CONFIG, 5000))) {
            try {
                var md = p.send(new ProducerRecord<>("banana", key, "x".getBytes())).get();
                System.out.println("  send с этим ключом: записано в партицию " + md.partition());
            } catch (Exception e) {
                System.out.println("  send с этим ключом: " + err(e));
            }
        }
    }

    // -------------------------------------------------------------- 2. delivery.timeout.ms < linger.ms + request.timeout.ms
    static void deliveryTimeout() {
        System.out.println("=== 2. delivery.timeout.ms=1000 при linger.ms=5 и request.timeout.ms=30000");
        try (var p = new KafkaProducer<byte[], byte[]>(pp(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, 1000))) {
            System.out.println("  производитель создан");
        } catch (Exception e) {
            System.out.println("  " + err(e));
        }
    }

    // -------------------------------------------------------------- 3. два потребителя с одним group.instance.id
    static void sameInstanceId(Admin admin, String protocol) throws Exception {
        String topic = "static-" + protocol;
        admin.createTopics(List.of(new NewTopic(topic, 2, (short) 1))).all().get();
        System.out.println("=== 3. два потребителя с group.instance.id=billing-0, group.protocol=" + protocol);
        Object[] extra = protocol.equals("consumer")
                ? new Object[]{ConsumerConfig.GROUP_PROTOCOL_CONFIG, "consumer", ConsumerConfig.GROUP_INSTANCE_ID_CONFIG, "billing-0"}
                : new Object[]{ConsumerConfig.GROUP_PROTOCOL_CONFIG, "classic", ConsumerConfig.GROUP_INSTANCE_ID_CONFIG, "billing-0", ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 10000};
        AtomicReference<String> first = new AtomicReference<>("работает без ошибок"), second = new AtomicReference<>("работает без ошибок");
        KafkaConsumer<byte[], byte[]> a = new KafkaConsumer<>(cp("g-" + topic, extra));
        a.subscribe(List.of(topic));
        long end = System.currentTimeMillis() + 8000;
        while (System.currentTimeMillis() < end && a.assignment().isEmpty()) a.poll(Duration.ofMillis(200));
        System.out.println("  первый подключился, партиции " + a.assignment().size());
        KafkaConsumer<byte[], byte[]> b = new KafkaConsumer<>(cp("g-" + topic, extra));
        b.subscribe(List.of(topic));
        end = System.currentTimeMillis() + 15000;
        boolean aDone = false, bDone = false;
        while (System.currentTimeMillis() < end && !(aDone && bDone)) {
            if (!bDone) try { b.poll(Duration.ofMillis(200)); } catch (Exception e) { second.set(err(e)); bDone = true; }
            if (!aDone) try { a.poll(Duration.ofMillis(200)); } catch (Exception e) { first.set(err(e)); aDone = true; }
        }
        System.out.println("  первый (подключился раньше): " + first.get());
        System.out.println("  второй (подключился позже):  " + second.get());
        try { a.close(Duration.ofSeconds(2)); } catch (Exception ignored) { }
        try { b.close(Duration.ofSeconds(2)); } catch (Exception ignored) { }
    }

    // -------------------------------------------------------------- 4. запись с временем из будущего
    static void futureTimestamp(Admin admin) throws Exception {
        System.out.println("=== 4. запись с меткой времени 2087-01-01 (CreateTime), умолчания брокера");
        admin.createTopics(List.of(new NewTopic("ts-create", 1, (short) 1),
                new NewTopic("ts-append", 1, (short) 1).configs(Map.of("message.timestamp.type", "LogAppendTime")))).all().get();
        long future = java.time.Instant.parse("2087-01-01T00:00:00Z").toEpochMilli();
        try (var p = new KafkaProducer<byte[], byte[]>(pp())) {
            for (String t : List.of("ts-create", "ts-append")) {
                try {
                    var md = p.send(new ProducerRecord<>(t, null, future, null, "x".getBytes())).get();
                    System.out.println("  " + t + ": принята, смещение " + md.offset() + ", время в ответе " + java.time.Instant.ofEpochMilli(md.timestamp()));
                } catch (Exception e) {
                    System.out.println("  " + t + ": " + err(e));
                }
            }
        }
    }

    // -------------------------------------------------------------- 5. значение в 5 МБ
    static void tooLarge(Admin admin) throws Exception {
        System.out.println("=== 5. значение записи 5 МБ (выписка PDF)");
        admin.createTopics(List.of(new NewTopic("statements", 1, (short) 1))).all().get();
        byte[] pdf = new byte[5 * 1024 * 1024];
        new Random(1).nextBytes(pdf);
        for (int maxRequest : new int[]{1048576, 10 * 1024 * 1024}) {
            try (var p = new KafkaProducer<byte[], byte[]>(pp(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, maxRequest))) {
                p.send(new ProducerRecord<>("statements", pdf)).get();
                System.out.println("  max.request.size=" + maxRequest + ": принята");
            } catch (Exception e) {
                System.out.println("  max.request.size=" + maxRequest + ": " + err(e));
            }
        }
    }

    // -------------------------------------------------------------- 6. «лаг 1» на транзакционной теме
    static void txLag(Admin admin) throws Exception {
        System.out.println("=== 6. транзакционная тема: 5 записей в одной транзакции, потребитель read_committed дочитал всё");
        admin.createTopics(List.of(new NewTopic("tx-lag", 1, (short) 1))).all().get();
        try (var p = new KafkaProducer<byte[], byte[]>(pp(ProducerConfig.TRANSACTIONAL_ID_CONFIG, "tx-lag-1"))) {
            p.initTransactions();
            p.beginTransaction();
            for (int i = 0; i < 5; i++) p.send(new ProducerRecord<>("tx-lag", ("v" + i).getBytes()));
            p.commitTransaction();
        }
        TopicPartition tp = new TopicPartition("tx-lag", 0);
        for (String mode : List.of("offset+1 последней записи", "commitSync() без аргументов")) {
            String group = "g-txlag-" + mode.length();
            long last = -1, position;
            try (var c = new KafkaConsumer<byte[], byte[]>(cp(group, ConsumerConfig.ISOLATION_LEVEL_CONFIG, "read_committed"))) {
                c.subscribe(List.of("tx-lag"));
                int got = 0;
                long end = System.currentTimeMillis() + 15000;
                while (got < 5 && System.currentTimeMillis() < end) for (var r : c.poll(Duration.ofMillis(300))) { got++; last = r.offset(); }
                c.poll(Duration.ofMillis(500));
                position = c.position(tp);
                if (mode.startsWith("offset")) c.commitSync(Map.of(tp, new OffsetAndMetadata(last + 1)));
                else c.commitSync();
            }
            long committed = admin.listConsumerGroupOffsets(group).partitionsToOffsetAndMetadata().get().get(tp).offset();
            ListOffsetsResult lo = admin.listOffsets(Map.of(tp, OffsetSpec.latest()));
            long latest = lo.partitionResult(tp).get().offset();
            System.out.printf("  %-28s последняя запись %d, position %d, зафиксировано %d, конец журнала %d, лаг %d%n", mode + ":", last, position, committed, latest, latest - committed);
        }
    }

    public static void main(String[] args) throws Exception {
        EmbeddedKafkaKraftBroker broker = null;
        if (args.length > 0) {                     // внешний брокер, например Docker-контейнер из bookchecks.sh
            bs = args[0];
            System.out.println("клиент Kafka " + AppInfoParser.getVersion() + ", брокер " + bs + ", JDK " + Runtime.version());
        } else {
            broker = new EmbeddedKafkaKraftBroker(1, 1);
            broker.brokerProperty("offsets.topic.replication.factor", "1");
            broker.brokerProperty("transaction.state.log.replication.factor", "1");
            broker.brokerProperty("transaction.state.log.min.isr", "1");
            broker.afterPropertiesSet();
            bs = broker.getBrokersAsString();
            System.out.println("Kafka (клиент и встроенный брокер) " + AppInfoParser.getVersion() + ", JDK " + Runtime.version());
        }
        try (Admin admin = Admin.create(Map.of("bootstrap.servers", bs))) {
            deliveryTimeout();
            futureTimestamp(admin);
            tooLarge(admin);
            txLag(admin);
            sameInstanceId(admin, "classic");
            sameInstanceId(admin, "consumer");
            partitionerBug(admin);
        }
        if (broker != null) broker.destroy();
        System.exit(0);
    }
}
