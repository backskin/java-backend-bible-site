package k;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.CooperativeStickyAssignor;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.RangeAssignor;
import org.apache.kafka.clients.consumer.CommitFailedException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.RecordDeserializationException;
import org.apache.kafka.common.serialization.IntegerDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.test.EmbeddedKafkaKraftBroker;
import org.springframework.util.backoff.FixedBackOff;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Потребители Kafka: ребалансировка, таймауты, повторы и потери, обработка ошибок.
 * Зависимости Maven: org.springframework.kafka:spring-kafka и spring-kafka-test (версии задаёт Spring Boot 4.1.1).
 * Все эксперименты идут на настоящем брокере Kafka 4.x внутри процесса.
 */
public class KafkaConsumers {

    static String bootstrap;

    static Map<String, Object> consumerProps(String group, Object... kv) {
        Map<String, Object> p = new HashMap<>();
        p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        p.put(ConsumerConfig.GROUP_ID_CONFIG, group);
        p.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        for (int i = 0; i < kv.length; i += 2) p.put((String) kv[i], kv[i + 1]);
        return p;
    }

    static KafkaProducer<String, String> producer() {
        Map<String, Object> p = new HashMap<>();
        p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new KafkaProducer<>(p);
    }

    static void send(String topic, int n) throws Exception {
        try (KafkaProducer<String, String> p = producer()) {
            for (int i = 1; i <= n; i++) p.send(new ProducerRecord<>(topic, "k" + i, "m" + i)).get();
        }
    }

    // ---------------------------------------------------------------- 6.3 ребалансировка
    static class Member implements Runnable {
        final String name;
        final String assignor;
        final String topic;
        final List<String> events = new CopyOnWriteArrayList<>();
        final Set<Integer> owned = ConcurrentHashMap.newKeySet();
        final AtomicBoolean stop = new AtomicBoolean();
        final AtomicInteger revokedAfterJoin = new AtomicInteger();
        volatile boolean joinPhase;

        Member(String name, String assignor, String topic) { this.name = name; this.assignor = assignor; this.topic = topic; }

        @Override
        public void run() {
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(consumerProps("g-" + assignor,
                    ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG, assignor))) {
                c.subscribe(List.of(topic), new ConsumerRebalanceListener() {
                    public void onPartitionsRevoked(Collection<TopicPartition> parts) {
                        parts.forEach(p -> owned.remove(p.partition()));
                        if (joinPhase) revokedAfterJoin.addAndGet(parts.size());
                    }
                    public void onPartitionsAssigned(Collection<TopicPartition> parts) { parts.forEach(p -> owned.add(p.partition())); }
                });
                while (!stop.get()) c.poll(Duration.ofMillis(200));
            }
        }
    }

    static void waitFor(java.util.function.BooleanSupplier cond) throws Exception {
        for (int i = 0; i < 200 && !cond.getAsBoolean(); i++) Thread.sleep(200);
    }

    static void rebalance(String title, String assignor) throws Exception {
        String topic = "r-" + Math.abs(assignor.hashCode());
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            admin.createTopics(List.of(new NewTopic(topic, 6, (short) 1))).all().get();
        }
        Member a = new Member("A", assignor, topic), b = new Member("B", assignor, topic), c = new Member("C", assignor, topic);
        Thread ta = new Thread(a), tb = new Thread(b), tc = new Thread(c);
        ta.start(); tb.start();
        waitFor(() -> a.owned.size() + b.owned.size() == 6 && a.owned.size() == 3);
        a.joinPhase = true; b.joinPhase = true;
        tc.start();
        waitFor(() -> a.owned.size() == 2 && b.owned.size() == 2 && c.owned.size() == 2);
        Thread.sleep(500);
        System.out.printf("  %-28s после входа C у A=%s, B=%s, C=%s; отозвано у A и B при входе C: %d партиций%n", title,
                new TreeSet<>(a.owned), new TreeSet<>(b.owned), new TreeSet<>(c.owned), a.revokedAfterJoin.get() + b.revokedAfterJoin.get());
        a.stop.set(true); b.stop.set(true); c.stop.set(true);
        ta.join(); tb.join(); tc.join();
    }

    // ---------------------------------------------------------------- 6.6 таймауты потребителя
    static void timeouts() throws Exception {
        send("t", 3);
        for (long workMs : new long[]{1000, 6000}) {
            Map<String, Object> props = consumerProps("g-timeouts-" + workMs,
                    ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, 3000, ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 10000,
                    ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 1000, ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(props)) {
                c.subscribe(List.of("t"));
                ConsumerRecords<String, String> recs = ConsumerRecords.empty();
                for (int i = 0; i < 20 && recs.isEmpty(); i++) recs = c.poll(Duration.ofMillis(500));
                Thread.sleep(workMs);                                         // «обработка» без вызова poll
                String commit;
                try { c.commitSync(); commit = "commitSync прошёл"; }
                catch (CommitFailedException e) { commit = "CommitFailedException"; }
                catch (Exception e) { commit = e.getClass().getSimpleName(); }
                System.out.printf("  обработка %d мс при max.poll.interval.ms=3000, session.timeout.ms=10000: %s%n", workMs, commit);
            }
        }
    }

    // ---------------------------------------------------------------- 6.7 / 7.1 / 7.3 / 14.2 повторы и потери
    static int processAll(String group, String topic, boolean commitBeforeProcessing, boolean crashBeforeCommit, Set<String> sink, List<String> log) {
        int processed = 0;
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(consumerProps(group, ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false,
                ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 10))) {
            c.subscribe(List.of(topic));
            ConsumerRecords<String, String> recs = ConsumerRecords.empty();
            for (int i = 0; i < 20 && recs.isEmpty(); i++) recs = c.poll(Duration.ofMillis(500));
            if (commitBeforeProcessing) c.commitSync();
            for (ConsumerRecord<String, String> r : recs) {
                if (commitBeforeProcessing && processed == 2) return processed;         // «упали» в середине пачки: остаток потерян
                sink.add(r.value());
                log.add(r.value());
                processed++;
            }
            if (!crashBeforeCommit) c.commitSync();
        }
        return processed;
    }

    static void delivery() throws Exception {
        send("d1", 5);
        List<String> log1 = new ArrayList<>();
        int first = processAll("g-d1", "d1", false, true, new HashSet<>(), log1);
        int second = processAll("g-d1", "d1", false, false, new HashSet<>(), log1);
        System.out.println("  at-least-once (коммит после обработки), падение до коммита: первый запуск обработал " + first
                + ", второй после перезапуска " + second + ", всего обработок " + log1.size() + " при 5 сообщениях (дублей " + (log1.size() - 5) + ")");
        send("d2", 5);
        List<String> log2 = new ArrayList<>();
        int a1 = processAll("g-d2", "d2", true, false, new HashSet<>(), log2);
        int a2 = processAll("g-d2", "d2", true, false, new HashSet<>(), log2);
        System.out.println("  at-most-once (коммит до обработки), падение в середине: обработано " + log2.size() + " из 5, "
                + "после перезапуска второй запуск получил " + a2 + " (сообщения 3-5 потеряны)");
        send("d3", 5);
        Set<String> idempotentSink = new HashSet<>();
        List<String> log3 = new ArrayList<>();
        processAll("g-d3", "d3", false, true, idempotentSink, log3);
        processAll("g-d3", "d3", false, false, idempotentSink, log3);
        System.out.println("  at-least-once и идемпотентная запись (множество по ключу): обработок " + log3.size() + ", уникальных результатов в приёмнике " + idempotentSink.size());
    }

    static void duplicatesAfterRebalance() throws Exception {
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            admin.createTopics(List.of(new NewTopic("rd", 1, (short) 1))).all().get();
        }
        send("rd", 5);
        List<String> handled = new CopyOnWriteArrayList<>();
        Map<String, Object> slow = consumerProps("g-rd", ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false,
                ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, 2000, ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 6000, ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 1000);
        StringBuilder commitA = new StringBuilder();
        Thread a = new Thread(() -> {
            try (KafkaConsumer<String, String> c = new KafkaConsumer<>(slow)) {
                c.subscribe(List.of("rd"));
                ConsumerRecords<String, String> recs = ConsumerRecords.empty();
                for (int i = 0; i < 20 && recs.isEmpty(); i++) recs = c.poll(Duration.ofMillis(500));
                try { Thread.sleep(4500); } catch (InterruptedException ignored) { }     // обработка дольше max.poll.interval.ms
                recs.forEach(r -> handled.add("A:" + r.value()));
                try { c.commitSync(); commitA.append("commitSync прошёл"); }
                catch (CommitFailedException e) { commitA.append("CommitFailedException"); }
            }
        });
        a.start();
        Thread.sleep(3000);                                                               // A уже выбыл из группы, но ещё «обрабатывает»
        try (KafkaConsumer<String, String> b = new KafkaConsumer<>(consumerProps("g-rd", ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false))) {
            b.subscribe(List.of("rd"));
            for (int i = 0; i < 20 && handled.stream().noneMatch(h -> h.startsWith("B:")); i++)
                b.poll(Duration.ofMillis(500)).forEach(r -> handled.add("B:" + r.value()));
            b.commitSync();
        }
        a.join();
        System.out.println("  A «обрабатывает» 4,5 с при max.poll.interval.ms=2000, B вступает в группу и получает те же записи: " + handled);
        System.out.println("  коммит потребителя A: " + commitA);
    }

    // ---------------------------------------------------------------- 11.4 / 14.3 ошибки
    static void errorHandling() throws Exception {
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            admin.createTopics(List.of(new NewTopic("orders", 1, (short) 1), new NewTopic("orders-dlt", 1, (short) 1))).all().get();
        }
        try (KafkaProducer<String, String> p = producer()) {
            for (String v : List.of("ok-1", "POISON", "ok-2")) p.send(new ProducerRecord<>("orders", "k", v)).get();
        }
        DefaultKafkaProducerFactory<String, String> pf = new DefaultKafkaProducerFactory<>(Map.of(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class));
        KafkaTemplate<String, String> template = new KafkaTemplate<>(pf);
        DefaultErrorHandler handler = new DefaultErrorHandler(new DeadLetterPublishingRecoverer(template), new FixedBackOff(100, 2));
        List<String> attempts = new CopyOnWriteArrayList<>();
        ContainerProperties cp = new ContainerProperties("orders");
        cp.setGroupId("g-orders");
        cp.setMessageListener((org.springframework.kafka.listener.MessageListener<String, String>) r -> {
            attempts.add(r.value());
            if (r.value().equals("POISON")) throw new IllegalStateException("не удаётся разобрать сообщение");
        });
        ConcurrentMessageListenerContainer<String, String> container = new ConcurrentMessageListenerContainer<>(
                new DefaultKafkaConsumerFactory<>(consumerProps("g-orders")), cp);
        container.setCommonErrorHandler(handler);
        container.start();
        waitFor(() -> attempts.stream().filter(v -> v.equals("ok-2")).count() >= 1);
        Thread.sleep(500);
        container.stop();
        template.flush();
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            System.out.println("  темы с DLT в имени: " + admin.listTopics().names().get().stream().filter(n -> n.toLowerCase().contains("dlt")).sorted().toList());
        }
        System.out.println("  обработки по порядку: " + attempts + " (POISON: исходная попытка и два повтора)");
        try (KafkaConsumer<String, String> c = new KafkaConsumer<>(consumerProps("g-dlt-reader"))) {
            c.subscribe(List.of("orders-dlt"));
            for (int i = 0; i < 40; i++) {
                ConsumerRecords<String, String> got = c.poll(Duration.ofMillis(500));
                for (ConsumerRecord<String, String> r : got) {
                    System.out.println("  в orders-dlt: значение " + r.value() + ", заголовки: "
                            + java.util.stream.StreamSupport.stream(r.headers().spliterator(), false).map(h -> h.key()).filter(k -> k.startsWith("kafka_dlt")).sorted().toList());
                }
                if (!got.isEmpty()) break;
            }
        }
        pf.destroy();
    }

    static void poisonDeserialization() throws Exception {
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            admin.createTopics(List.of(new NewTopic("amounts", 1, (short) 1))).all().get();
        }
        try (KafkaProducer<String, byte[]> p = new KafkaProducer<>(Map.<String, Object>of(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap,
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class,
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.ByteArraySerializer.class))) {
            p.send(new ProducerRecord<>("amounts", "k", java.nio.ByteBuffer.allocate(4).putInt(100).array())).get();       // корректное Integer
            p.send(new ProducerRecord<>("amounts", "k", "не число".getBytes(java.nio.charset.StandardCharsets.UTF_8))).get(); // битая запись
            p.send(new ProducerRecord<>("amounts", "k", java.nio.ByteBuffer.allocate(4).putInt(300).array())).get();       // корректное Integer
        }
        Map<String, Object> props = consumerProps("g-amounts", ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, IntegerDeserializer.class);
        try (KafkaConsumer<String, Integer> c = new KafkaConsumer<>(props)) {
            c.subscribe(List.of("amounts"));
            int failures = 0;
            List<Integer> values = new ArrayList<>();
            for (int i = 0; i < 12; i++) {
                try { c.poll(Duration.ofMillis(500)).forEach(r -> values.add(r.value())); }
                catch (RecordDeserializationException e) {
                    failures++;
                    if (failures == 5) {                                               // «лечение»: перескочить через битую запись
                        c.seek(e.topicPartition(), e.offset() + 1);
                        System.out.println("  после " + failures + " одинаковых ошибок на офсете " + e.offset() + " выполнен seek на офсет " + (e.offset() + 1));
                    }
                }
            }
            System.out.println("  RecordDeserializationException на одной и той же записи: " + failures + " раз подряд до seek; прочитано " + values);
        }
    }

    public static void main(String[] args) throws Exception {
        EmbeddedKafkaKraftBroker one = new EmbeddedKafkaKraftBroker(1, 1);
        one.brokerProperty("offsets.topic.replication.factor", "1");
        one.afterPropertiesSet();
        bootstrap = one.getBrokersAsString();
        try (AdminClient admin = AdminClient.create(Map.of("bootstrap.servers", bootstrap))) {
            admin.createTopics(List.of(new NewTopic("t", 1, (short) 1), new NewTopic("d1", 1, (short) 1),
                    new NewTopic("d2", 1, (short) 1), new NewTopic("d3", 1, (short) 1))).all().get();
        }

        System.out.println("=== 6.3 ребалансировка: шесть партиций, к двум потребителям присоединяется третий");
        rebalance("Range (с остановкой мира)", RangeAssignor.class.getName());
        rebalance("CooperativeSticky", CooperativeStickyAssignor.class.getName());

        System.out.println("=== 6.6 таймауты потребителя");
        timeouts();

        System.out.println("=== 6.7, 7.1, 7.3 коммит оффсетов, повторы и потери");
        delivery();

        System.out.println("=== 14.2 дубли после ребаланса");
        duplicatesAfterRebalance();

        System.out.println("=== 11.4 DefaultErrorHandler и DLT");
        errorHandling();

        System.out.println("=== 14.3 отравленное сообщение: ошибка десериализации");
        poisonDeserialization();

        one.destroy();
        System.exit(0);
    }
}
