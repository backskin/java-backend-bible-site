#!/usr/bin/env bash
# Опыт к разделу 6.2: горячая группа и соседи по партиции __consumer_offsets (класс HotGroup).
# Один брокер apache/kafka:4.3.1 в Docker с ограничением процессора.
# Запуск из labs/ch29-clients: ./hotgroup.sh CPUS ПОТОКИ_КООРДИНАТОРА ПОТОКИ_ГОРЯЧЕЙ СЕКУНД
# Пример: ./hotgroup.sh 1 4 16 40 >> s29-hotgroup.txt
set -u
export MSYS_NO_PATHCONV=1
CPUS=${1:-1}; CT=${2:-4}; HT=${3:-16}; SEC=${4:-40}
IMG=apache/kafka:4.3.1
docker rm -f k29h >/dev/null 2>&1
docker run -d --name k29h --cpus "$CPUS" -p 39093:39092 \
  -e KAFKA_NODE_ID=1 -e KAFKA_PROCESS_ROLES=broker,controller \
  -e KAFKA_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093,EXTERNAL://:39092 \
  -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092,EXTERNAL://localhost:39093 \
  -e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT,CONTROLLER:PLAINTEXT,EXTERNAL:PLAINTEXT \
  -e KAFKA_CONTROLLER_LISTENER_NAMES=CONTROLLER -e KAFKA_CONTROLLER_QUORUM_VOTERS=1@localhost:9093 \
  -e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT -e KAFKA_LOG_DIRS=/var/lib/kafka/data \
  -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 -e KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR=1 \
  -e KAFKA_TRANSACTION_STATE_LOG_MIN_ISR=1 -e KAFKA_GROUP_COORDINATOR_THREADS=$CT $IMG >/dev/null
for i in $(seq 1 60); do docker exec k29h /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list >/dev/null 2>&1 && break; sleep 1; done
echo "=== $IMG, --cpus $CPUS, group.coordinator.threads=$(docker exec k29h grep -h 'group.coordinator.threads =' /opt/kafka/logs/server.log | head -1 | awk '{print $NF}'), потоков горячей группы $HT, нагрузка $SEC с"
java -Dstdout.encoding=UTF-8 -Dorg.slf4j.simpleLogger.defaultLogLevel=off -cp "target/hot;$(cat cp431.txt)" k.HotGroup localhost:39093 "$HT" "$SEC"
docker rm -f k29h >/dev/null
