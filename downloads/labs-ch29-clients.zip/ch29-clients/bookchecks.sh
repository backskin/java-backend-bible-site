#!/usr/bin/env bash
# Проверки утверждений книг и старого текста главы 29 (класс BookChecks) на брокере apache/kafka:4.3.1 в Docker.
# Запуск из labs/ch29-clients после сборки: ./bookchecks.sh > s29-bookchecks.txt
set -u
export MSYS_NO_PATHCONV=1   # Git Bash на Windows иначе переписывает /var/... в путь Windows
IMG=apache/kafka:4.3.1
D=/var/lib/kafka/data
docker rm -f k29 >/dev/null 2>&1
docker run -d --name k29 -p 39092:39092 \
  -e KAFKA_NODE_ID=1 -e KAFKA_PROCESS_ROLES=broker,controller \
  -e KAFKA_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093,EXTERNAL://:39092 \
  -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092,EXTERNAL://localhost:39092 \
  -e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT,CONTROLLER:PLAINTEXT,EXTERNAL:PLAINTEXT \
  -e KAFKA_CONTROLLER_LISTENER_NAMES=CONTROLLER -e KAFKA_CONTROLLER_QUORUM_VOTERS=1@localhost:9093 \
  -e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT -e KAFKA_LOG_DIRS=$D \
  -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 -e KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR=1 \
  -e KAFKA_TRANSACTION_STATE_LOG_MIN_ISR=1 $IMG >/dev/null
for i in $(seq 1 60); do docker exec k29 /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list >/dev/null 2>&1 && break; sleep 1; done
echo "=== брокер $IMG готов"
CP="target/classes;$(cat cp431.txt)"   # клиент Kafka 4.3.1
java -Dstdout.encoding=UTF-8 -Dorg.slf4j.simpleLogger.defaultLogLevel=off -cp "$CP" k.BookChecks localhost:39092
docker rm -f k29 >/dev/null
