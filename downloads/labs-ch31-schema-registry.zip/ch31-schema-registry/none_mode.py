"""Глава 31, раздел 13.5: что пропускает реестр в режиме NONE.

Запуск: python none_mode.py  (стенд поднят: docker compose up -d, реестр на localhost:58081)
Поле amount (long, копейки) заменяется записью {amount, currency}. Один и тот же переход
регистрируется в subject с режимом NONE и в subject с режимом BACKWARD.
"""
import json, urllib.request, urllib.error

URL = "http://localhost:58081"

def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(URL + path, data=data, method=method,
                                 headers={"Content-Type": "application/vnd.schemaregistry.v1+json"})
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"null")

def schema(fields):
    return {"type": "record", "name": "Payment", "namespace": "demo", "fields": fields}

def reg(subject, s):
    return call("POST", f"/subjects/{subject}/versions", {"schema": json.dumps(s)})

def compat(subject, s):
    st, b = call("POST", f"/compatibility/subjects/{subject}/versions/latest?verbose=true", {"schema": json.dumps(s)})
    return b.get("is_compatible"), (b.get("messages") or [""])[0][:160]

def set_mode(subject, mode):
    call("PUT", f"/config/{subject}", {"compatibility": mode})


base = [{"name": "id", "type": "string"}, {"name": "amount", "type": "long"}]
money = {"type": "record", "name": "Money", "fields": [{"name": "amount", "type": "long"},
                                                       {"name": "currency", "type": "string"}]}
v2 = [{"name": "id", "type": "string"}, {"name": "amount", "type": money}]

print("=== 13.5 amount long -> amount {amount, currency}: регистрация в разных режимах")
for mode in ("NONE", "BACKWARD"):
    subj = f"transfer-completed-{mode.lower()}-value"
    set_mode(subj, mode)
    reg(subj, schema(base))
    ok, msg = compat(subj, schema(v2))
    st, b = reg(subj, schema(v2))
    tail = ("id=" + str(b.get("id"))) if st == 200 else b.get("message", "")[:120]
    print(f"  режим {mode:8}: проверка совместимости {ok}; регистрация HTTP {st} {tail}")
    if not ok:
        print(f"      причина: {msg[:150]}")
    print(f"      версии subject: {call('GET', f'/subjects/{subj}/versions')[1]}")
