"""Проверка режимов совместимости Confluent Schema Registry через REST API.

Запуск: python run.py  (стенд поднят: docker compose up -d, реестр на localhost:58081)
Сценарии: (1) строки таблицы 7.5 для Avro в режимах BACKWARD, FORWARD, FULL;
(2) «туда и обратно»: tariff string (v1) -> удалено (v2) -> int с default (v3) в BACKWARD и BACKWARD_TRANSITIVE.
"""
import json, urllib.request, urllib.error

URL = "http://localhost:58081"

def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(URL + path, data=data, method=method,
                                 headers={"Content-Type": "application/vnd.schemaregistry.v1+json"})
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"null")

def schema(fields):
    return {"type": "record", "name": "Payment", "namespace": "demo", "fields": fields}

def reg(subject, s):
    return call("POST", f"/subjects/{subject}/versions", {"schema": json.dumps(s)})

def compat(subject, s):
    st, b = call("POST", f"/compatibility/subjects/{subject}/versions/latest?verbose=true", {"schema": json.dumps(s)})
    return b.get("is_compatible"), (b.get("messages") or [""])[0][:160]

def set_mode(subject, mode):
    call("PUT", f"/config/{subject}", {"compatibility": mode})

print("реестр:", call("GET", "/")[0], call("GET", "/config"))

base = [{"name": "id", "type": "string"}, {"name": "amount", "type": "long"},
        {"name": "status", "type": {"type": "enum", "name": "Status", "symbols": ["NEW", "DONE"]}}]
changes = {
    "добавить поле с default":   base + [{"name": "note", "type": "string", "default": ""}],
    "добавить поле без default": base + [{"name": "note", "type": "string"}],
    "удалить поле без default (amount)": [f for f in base if f["name"] != "amount"],
    "переименовать amount -> sum": [dict(f, name="sum") if f["name"] == "amount" else f for f in base],
    "сузить тип long -> int":  [dict(f, type="int") if f["name"] == "amount" else f for f in base],
    "добавить символ в enum":  [dict(f, type={"type": "enum", "name": "Status", "symbols": ["NEW", "DONE", "FAILED"]}) if f["name"] == "status" else f for f in base],
    "добавить символ в enum c default": [dict(f, type={"type": "enum", "name": "Status", "symbols": ["NEW", "DONE", "FAILED"], "default": "NEW"}) if f["name"] == "status" else f for f in base],
}
print("\n=== 1. типичные изменения схемы Avro; базовая схема: id string, amount long, status enum{NEW,DONE}")
print(f"{'изменение':40} {'BACKWARD':9} {'FORWARD':9} {'FULL':6}")
for name, s in changes.items():
    row = []
    for mode in ("BACKWARD", "FORWARD", "FULL"):
        subj = f"t-{mode.lower()}-{abs(hash(name)) % 10**6}-value"
        set_mode(subj, mode); reg(subj, schema(base))
        ok, msg = compat(subj, schema(s))
        row.append("✔" if ok else "✘")
    print(f"{name:40} {row[0]:9} {row[1]:9} {row[2]:6}")

print("\n=== 2. «туда и обратно»: v1 tariff:string -> v2 без tariff -> v3 tariff:int default 0")
v1 = schema(base + [{"name": "tariff", "type": "string"}])
v2 = schema(base)
v3 = schema(base + [{"name": "tariff", "type": "int", "default": 0}])
for mode in ("BACKWARD", "BACKWARD_TRANSITIVE"):
    subj = f"transfer-{mode.lower()}-value"
    set_mode(subj, mode)
    print(f"-- режим {mode}")
    for label, s in (("v1", v1), ("v2", v2), ("v3", v3)):
        ok, msg = compat(subj, s) if label != "v1" else (True, "")
        st, b = reg(subj, s)
        print(f"   {label}: совместимость {ok}, регистрация HTTP {st} {('id=' + str(b.get('id'))) if st == 200 else b.get('message', '')[:140]}")
        if msg and not ok:
            print("      причина:", msg)
