# Реестр схем: режимы совместимости за пять минут

Шаблон к главе 31, раздел 7.5. Поднимает Kafka (KRaft) и Confluent Schema Registry и проверяет через REST API, какие изменения схемы Avro проходят в режимах BACKWARD, FORWARD и FULL и чем BACKWARD_TRANSITIVE отличается от BACKWARD.

## Что нужно

- Docker с Compose; свободный порт 58081.
- Python 3 (только стандартная библиотека) для `run.py`.

## Запуск

```bash
docker compose up -d
curl localhost:58081/config          # {"compatibilityLevel":"BACKWARD"} - режим по умолчанию
python run.py
```

Скрипт для каждого изменения заводит отдельный subject, ставит ему режим (`PUT /config/<subject>`), регистрирует базовую схему и спрашивает реестр о совместимости новой (`POST /compatibility/subjects/<subject>/versions/latest`). Во второй части он регистрирует цепочку v1 → v2 → v3 с полем `tariff`, которое исчезло и вернулось с другим типом, в режимах BACKWARD и BACKWARD_TRANSITIVE.

Скрипт `none_mode.py` (глава 31, раздел 13.5) регистрирует замену поля `amount long` записью `{amount, currency}` в subject с режимом NONE и с режимом BACKWARD: `python none_mode.py`. Вывод автора - `s31-none-mode.txt`.

## Что должно получиться

Результаты автора - в `s31-schema-registry.txt`. В BACKWARD цепочка регистрируется целиком, в BACKWARD_TRANSITIVE v3 отклоняется с HTTP 409 и `errorType: TYPE_MISMATCH` (`reader type: INT not compatible with writer type: STRING`). Подвох: эндпоинт `/compatibility/.../versions/latest` отвечает "совместимо" и в транзитивном режиме, потому что сравнивает только с последней версией; проверять против всех версий нужно эндпоинтом `/compatibility/subjects/<subject>/versions` без `latest`.

## Остановка

```bash
docker compose down -v
```
