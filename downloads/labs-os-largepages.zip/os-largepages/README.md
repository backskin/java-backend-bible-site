# Большие страницы JVM в Windows и списки страниц памяти

Стенд к главе 15, раздел 2. `run.sh` запускает `java -XX:+UseLargePages -Xms<N> -Xmx<N> -Xlog:pagesize -version` на Temurin 21 и 25 при куче 64 МБ, 256 МБ, 512 МБ и 1 ГБ и показывает, получила ли куча страницы по 2 МБ или JVM откатилась на обычные с предупреждением. `s15-page-lists.txt` - счетчики списков свободных, обнуленных и резервных страниц Windows из Performance Monitor. Вывод автора - `s15-largepages.txt`.

## Что нужно

- Windows с привилегией `SeLockMemoryPrivilege` у учетной записи (проверить `whoami /priv`; без нее JVM пишет `Failed to reserve and commit memory using large pages`), Temurin 21 и 25 в `~/.jdks`, Git Bash.

## Запуск

```bash
bash run.sh
```

Счетчики страниц: `typeperf "\Memory\Free & Zero Page List Bytes" "\Memory\Standby Cache Reserve Bytes" -sc 1`.

## Что должно получиться

У автора куча 64 и 256 МБ получила `page_size=2M` на обоих JDK, а 512 МБ и 1 ГБ - `warning: Failed to reserve and commit memory using large pages`: большие страницы требуют непрерывной физической памяти, и после долгой работы системы ее на большую кучу не хватает.
