#!/usr/bin/env bash
# Разд. 2 гл. 15: большие страницы JVM в Windows. Вывод — s15-largepages.txt.
cd "$(dirname "$0")"
for j in "$HOME/.jdks/temurin-21.0.10" "$HOME/.jdks/jdk-25.0.5+8"; do
  v=$("$j/bin/java" -version 2>&1 | head -1)
  for x in 64m 256m 512m 1g; do
    echo "$v; -XX:+UseLargePages -Xms$x -Xmx$x: $("$j/bin/java" -XX:+UseLargePages -Xmx$x -Xms$x -Xlog:pagesize -version 2>&1 | grep -o "Heap: .*page_size=[0-9A-Z]*\|warning: Failed[^.]*" | tr "\n" " ")"
  done
done | tee s15-largepages.txt
