# Исполняемый jar Spring Boot: устройство, слои, jarmode tools, время старта, отчет --debug

Стенд к главе 10, разделы 1–2. Справочник БИК `BikDirectory` (Spring Boot 4.1.1, один контроллер) собирается в исполняемый jar, и по нему снимаются: размер и число записей, верхний уровень архива, `BOOT-INF/lib`, манифест, `layers.idx`, `java -Djarmode=tools list-layers` и `extract`, метод хранения вложенных jar, время старта упакованного и извлеченного jar по три запуска, ответ на запрос и фрагменты отчета `--debug`. Выводы автора - `s10-jar.txt`, `s10-run.txt`, `s10-bom.txt`, `s10-curl.txt`, `s10-debug.txt`. Коды БИК вымышлены.

## Что нужно

- JDK 21 и Maven; `unzip` для метода хранения.

## Запуск

```bash
mvn -q package -DskipTests && java -jar target/bik-directory-1.0.jar --server.port=8793
```

Проверка: `curl -s http://localhost:8793/bik/044525999`. Извлеченный вариант: `java -Djarmode=tools -jar target/bik-directory-1.0.jar extract --destination ex`, затем `java -jar ex/bik-directory-1.0.jar`. В IDEA есть конфигурация `BikDirectory`.

## Что должно получиться

Jar около 20 МБ со 169 записями и 34 jar в `BOOT-INF/lib`; старт из упакованного jar дольше, чем из извлеченного (у автора 1,8 с против меньшего, цифры в `s10-run.txt`).
