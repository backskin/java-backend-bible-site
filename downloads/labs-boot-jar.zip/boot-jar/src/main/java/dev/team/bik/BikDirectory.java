package dev.team.bik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** Справочник БИК: по коду банка отдаёт название и корреспондентский счёт. Данные вымышлены. */
@SpringBootApplication
@RestController
public class BikDirectory {
    static final Map<String, Map<String, String>> BANKS = Map.of(
            "044525999", Map.of("name", "АО «Тундра-Банк»", "corr", "30101810400000000999"),
            "041117601", Map.of("name", "Северный филиал АО «Тундра-Банк»", "corr", "30101810100000000601"));

    @GetMapping("/bik/{code}")
    Map<String, String> bik(@PathVariable String code) {
        return BANKS.getOrDefault(code, Map.of("error", "БИК " + code + " не найден"));
    }

    public static void main(String[] args) {
        SpringApplication.run(BikDirectory.class, args);
    }
}
