"""Хук PreToolUse: запрещает агенту любой инструмент, который касается файла .env.

Claude Code передает на stdin JSON с полями tool_name и tool_input. Код выхода 2 блокирует
вызов, а текст из stderr уходит модели как объяснение отказа. Код 0 без вывода ничего не решает:
вызов идет дальше по обычным правилам прав.
"""
import json
import re
import sys

sys.stderr.reconfigure(encoding="utf-8")

event = json.load(sys.stdin)
tool_input = json.dumps(event.get("tool_input", {}), ensure_ascii=False)
if re.search(r"(^|[\\/\s\"'*])\.env\b", tool_input):
    print(f"Хук deny_env: инструменту {event.get('tool_name')} запрещено касаться .env", file=sys.stderr)
    sys.exit(2)
sys.exit(0)
