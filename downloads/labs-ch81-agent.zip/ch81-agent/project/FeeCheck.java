import pay.Money;
import pay.TransferFee;

/** Приемочная проверка комиссии: 1000, 5000 и 12 500 рублей дают 50, 75 и 150 рублей. */
public class FeeCheck {
    public static void main(String[] args) {
        TransferFee fee = new TransferFee();
        long[][] cases = {{100_000, 5_000}, {500_000, 7_500}, {1_250_000, 15_000}};
        for (long[] c : cases) {
            long got = fee.fee(Money.ofMinor(c[0], "RUB")).minor();
            if (got != c[1]) {
                System.out.println("FAIL: " + c[0] + " -> " + got + ", ожидалось " + c[1]);
                System.exit(1);
            }
        }
        System.out.println("OK");
    }
}
