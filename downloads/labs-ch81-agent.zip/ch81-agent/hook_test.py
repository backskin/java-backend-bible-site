"""Где кончается защита хуком: подаем deny_env.py те же JSON, что прислал бы Claude Code.

Хук смотрит только на аргументы вызова. Прямое чтение .env он видит, а чтение, при котором
имя файла не названо (поиск по папке, скрипт, который собирает имя из частей), пропускает.
Запуск: python hook_test.py (Claude Code и сеть не нужны).
"""
import json
import subprocess
import sys
from pathlib import Path

HOOK = Path(__file__).parent / "project" / ".claude" / "hooks" / "deny_env.py"
CASES = [
    ("Read", {"file_path": "project/.env"}),
    ("Bash", {"command": "cat .env"}),
    ("Grep", {"pattern": "PAYMENT_API_KEY", "path": "."}),
    ("Bash", {"command": "grep -r PAYMENT_API_KEY ."}),
    ("Bash", {"command": "python -c \"print(open('.e'+'nv').read())\""}),
]
for tool, tool_input in CASES:
    event = {"hook_event_name": "PreToolUse", "tool_name": tool, "tool_input": tool_input}
    proc = subprocess.run([sys.executable, str(HOOK)], input=json.dumps(event), capture_output=True,
                          text=True, encoding="utf-8")
    verdict = "ЗАПРЕЩЕН" if proc.returncode == 2 else "пропущен"
    print(f"{verdict}  код {proc.returncode}  {tool:5} {json.dumps(tool_input, ensure_ascii=False)}")
