#!/bin/sh
# Умолчания Kafka 4.3.1 для гл. 29: брокер (цепочка synonyms) и клиенты (ConfigDef из kafka-clients).
export MSYS_NO_PATHCONV=1
docker rm -f k29 >/dev/null 2>&1
docker run -d --name k29 -p 19092:9092 apache/kafka:4.3.1 >/dev/null
until docker exec k29 /opt/kafka/bin/kafka-broker-api-versions.sh --bootstrap-server localhost:9092 >/dev/null 2>&1; do sleep 1; done
docker exec k29 /opt/kafka/bin/kafka-configs.sh --bootstrap-server localhost:9092 --entity-type brokers --entity-name 1 --describe --all \
  | grep -E "^  (offsets\.|transaction\.state\.log\.)" > s29-broker-defaults.txt
docker cp k29:/opt/kafka/libs/kafka-clients-4.3.1.jar ./kafka-clients-4.3.1.jar
javac --release 21 -cp kafka-clients-4.3.1.jar Defaults.java && rm kafka-clients-4.3.1.jar
docker cp Defaults.class k29:/tmp/Defaults.class
docker exec k29 sh -c 'java -cp "/opt/kafka/libs/*:/tmp" Defaults' > s29-defaults.txt
docker rm -f k29 >/dev/null
