#!/bin/sh
# Гл. 29, 1.3: почему у retention.ms и segment.ms темы synonyms={} — и что меняется, если задать log.retention.ms явно.
export MSYS_NO_PATHCONV=1
K=/opt/kafka/bin
docker rm -f k29 >/dev/null 2>&1
docker run -d --name k29 apache/kafka:4.3.1 >/dev/null
until docker exec k29 $K/kafka-broker-api-versions.sh --bootstrap-server localhost:9092 >/dev/null 2>&1; do sleep 1; done
docker exec k29 $K/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic payments.v1 >/dev/null
show(){ docker exec k29 $K/kafka-configs.sh --bootstrap-server localhost:9092 --entity-type topics --entity-name payments.v1 --describe --all | grep -E "^  (retention.ms|segment.ms)=" | sed 's/ sensitive=false//'; }
echo "=== 1.3 умолчания: в цепочке брокера есть только log.retention.hours / log.roll.hours"
show
docker exec k29 $K/kafka-configs.sh --bootstrap-server localhost:9092 --entity-type brokers --entity-default --alter --add-config log.retention.ms=86400000 >/dev/null
sleep 2
echo "=== 1.3 после log.retention.ms=86400000 для всех брокеров"
show
docker rm -f k29 >/dev/null
