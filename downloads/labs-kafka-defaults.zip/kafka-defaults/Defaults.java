import java.util.Map;
import java.util.TreeMap;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;

/**
 * Значения по умолчанию клиентов Kafka прямо из библиотеки, без документации (гл. 29, табл. умолчаний).
 * Запуск: docker cp Defaults.class в контейнер apache/kafka:4.3.1 и
 * java -cp /opt/kafka/libs/*:/tmp Defaults — вывод в s29-defaults.txt.
 */
public class Defaults {
    public static void main(String[] args) {
        print("producer", ProducerConfig.configDef().defaultValues());
        print("consumer", ConsumerConfig.configDef().defaultValues());
    }

    static void print(String who, Map<String, Object> d) {
        new TreeMap<>(d).forEach((k, v) -> System.out.println(who + " " + k + "=" + v));
    }
}
