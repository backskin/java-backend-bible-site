# Умолчания Kafka 4.3.1 из самого брокера и клиента, цепочка synonyms, динамические настройки, стоимость TLS

Стенд к главе 29, разделы 1.3 и 2.3. `run.sh` поднимает `apache/kafka:4.3.1` в Docker, снимает умолчания брокера через `kafka-configs --describe --all` (цепочка `synonyms` отделяет `DEFAULT_CONFIG` от переопределенного образом) и компилирует `Defaults.java`, который печатает умолчания производителя и потребителя прямо из `ConfigDef` библиотеки `kafka-clients`. `synonyms.sh` объясняет пустую цепочку у `retention.ms` темы и что меняется после `log.retention.ms` на всех брокерах; динамическая настройка на один узел и на все - `s29-dynamic-default.txt`. `tls.sh` сравнивает слушатели PLAINTEXT и SSL: пропускная способность `kafka-producer-perf-test` и `kafka-consumer-perf-test` и процессорное время брокера из cgroup, три раунда. Выводы автора - `s29-*.txt`.

## Что нужно

- Docker, JDK 21 (`javac --release 21` в `run.sh`), Git Bash (скрипты ставят `MSYS_NO_PATHCONV=1`).

## Запуск

```bash
sh run.sh
```

```bash
sh synonyms.sh > s29-synonyms.txt
```

```bash
sh tls.sh > s29-tls.txt
```

В IDEA на каждый скрипт есть Shell-конфигурация.

## Что должно получиться

У клиента 4.3.1 `acks=all`, `enable.idempotence=true`, `auto.offset.reset=latest`, `group.protocol=classic`; у темы `retention.ms=604800000 synonyms={}`, пока не задан `log.retention.ms`; TLS отнимает около пятой части пропускной способности на записи и шестой на чтении, а процессорного времени на чтение брокер тратит в 2–2,6 раза больше (потеря `sendfile`). Первые раунды искажены прогревом JVM.
