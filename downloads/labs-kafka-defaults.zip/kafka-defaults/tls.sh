#!/bin/sh
# Опыт 2.3 гл. 29: во что обходится TLS на брокере Kafka 4.3.1 (один брокер в Docker, JDK 21, AES-NI процессора хоста).
# Один и тот же поток записи и чтения через слушатель PLAINTEXT (9092) и SSL (9094); замер пропускной способности
# производителя и потребителя и процессорного времени брокера (usage_usec из cgroup его контейнера).
# Клиенты — в отдельном контейнере в сети брокера, три раунда с чередованием порядка, чтобы прогрев не исказил сравнение.
# Запуск: sh labs/kafka-defaults/tls.sh > labs/kafka-defaults/s29-tls.txt
export MSYS_NO_PATHCONV=1
K=/opt/kafka/bin
docker rm -f ktls kcli >/dev/null 2>&1
# свой server.properties и прямой запуск kafka-server-start.sh: скрипт образа для SSL требует файлы в /etc/kafka/secrets
docker run -d --name ktls --entrypoint sh apache/kafka:4.3.1 -c '
set -e; cd /tmp
keytool -genkeypair -alias b -keyalg EC -groupname secp256r1 -dname CN=localhost -ext SAN=dns:localhost -validity 30 -keystore ks.p12 -storetype PKCS12 -storepass changeit >/dev/null 2>&1
keytool -exportcert -alias b -keystore ks.p12 -storepass changeit -file b.crt >/dev/null 2>&1
keytool -importcert -noprompt -alias b -file b.crt -keystore ts.p12 -storetype PKCS12 -storepass changeit >/dev/null 2>&1
cat > s.properties <<P
node.id=1
process.roles=broker,controller
listeners=PLAINTEXT://:9092,SSL://:9094,CONTROLLER://:9093
advertised.listeners=PLAINTEXT://localhost:9092,SSL://localhost:9094
listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT,SSL:SSL
controller.listener.names=CONTROLLER
controller.quorum.bootstrap.servers=localhost:9093
log.dirs=/tmp/kraft
offsets.topic.replication.factor=1
transaction.state.log.replication.factor=1
transaction.state.log.min.isr=1
ssl.keystore.location=/tmp/ks.p12
ssl.keystore.password=changeit
ssl.key.password=changeit
ssl.keystore.type=PKCS12
P
/opt/kafka/bin/kafka-storage.sh format -t $(/opt/kafka/bin/kafka-storage.sh random-uuid) -c s.properties --standalone >/dev/null
exec /opt/kafka/bin/kafka-server-start.sh s.properties' >/dev/null
for i in $(seq 1 90); do docker exec ktls $K/kafka-broker-api-versions.sh --bootstrap-server localhost:9092 >/dev/null 2>&1 && break; [ "$(docker inspect -f {{.State.Running}} ktls)" = true ] || { echo "брокер не запустился:"; docker logs ktls 2>&1 | tail -5; exit 1; }; sleep 1; done
docker run -d --name kcli --network container:ktls --entrypoint sleep apache/kafka:4.3.1 infinity >/dev/null
docker exec ktls cat /tmp/ts.p12 | docker exec -i kcli sh -c 'cat > /tmp/ts.p12'
docker exec kcli sh -c 'printf "security.protocol=SSL\nssl.truststore.location=/tmp/ts.p12\nssl.truststore.password=changeit\nssl.truststore.type=PKCS12\n" > /tmp/ssl.properties; : > /tmp/plain.properties'
cpu(){ docker exec ktls sh -c 'grep usage_usec /sys/fs/cgroup/cpu.stat | cut -d" " -f2'; }
mbs(){ sed 's/.*(\([0-9.]*\) MB\/sec).*/\1/'; }
echo "=== 2.3 TLS против PLAINTEXT: 500 000 записей по 1 КБ (488 МБ), acks=all, без сжатия; JDK $(docker exec ktls java -version 2>&1 | head -1 | cut -d'"' -f2); клиенты в отдельном контейнере"
n=0
for round in plain:9092,ssl:9094 ssl:9094,plain:9092 plain:9092,ssl:9094; do
  for mode in $(echo $round | tr ',' ' '); do
    n=$((n+1)); name=${mode%%:*}; port=${mode##*:}; topic=t-$name-$n
    docker exec kcli $K/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic $topic --partitions 3 >/dev/null
    c0=$(cpu)
    w=$(docker exec kcli $K/kafka-producer-perf-test.sh --topic $topic --num-records 500000 --record-size 1024 --throughput -1 --producer.config /tmp/$name.properties --producer-props bootstrap.servers=localhost:$port acks=all compression.type=none 2>/dev/null | tail -1 | mbs)
    c1=$(cpu)
    r=$(docker exec kcli $K/kafka-consumer-perf-test.sh --bootstrap-server localhost:$port --topic $topic --messages 500000 --command-config /tmp/$name.properties 2>/dev/null | tail -1 | awk -F', ' '{printf "%.1f", $4}')
    c2=$(cpu)
    echo "  $name: запись $w МБ/с, процессор брокера $(( (c1-c0)/1000 )) мс | чтение $r МБ/с, процессор брокера $(( (c2-c1)/1000 )) мс"
  done
done
docker rm -f kcli ktls >/dev/null
