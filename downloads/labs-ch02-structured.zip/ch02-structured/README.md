# StructuredTaskScope и ScopedValue на JDK 21, 25 и 26

Стенд к главе 02, раздел 6. `Sts21` - API structured concurrency в первом preview (JDK 21), `Quotes25` и `Quotes26` - тот же сценарий "лучшая котировка из трех банков с отменой остальных" на API JDK 25 и 26 (они различаются), `FanOut` - для сравнения то же на `CompletableFuture`, где ненужный ответ все равно дожидается; `ScopedValues` и `ScopedInScope` - `ScopedValue` сам по себе и внутри scope. Выводы автора - в `s6-*.txt`.

## Что нужно

- Temurin JDK 21.0.10, 25.0.5 и 26.0.2.1 в `~/.jdks` (словарь `ALL` в `run.py`).
- Python 3.

## Запуск

```bash
python -X utf8 run.py
```

Все программы, кроме `FanOut`, используют preview-возможности, поэтому заголовок `// PREVIEW:` добавляет `--enable-preview --source N` сам. Одну программу без скрипта: `java --enable-preview --source 25 src/Quotes25.java`.

## Что должно получиться

На 25 лучшая котировка приходит через ~300 мс, а два оставшихся провайдера печатают "прерван"; на 26 `join()` возвращает список результатов. Времена зависят от машины, порядок событий нет.
