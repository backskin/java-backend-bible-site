// JDKS: 26
// PREVIEW: 26
// OUT: s6-quotes-26
// Тот же сбор котировок в API JDK 26 (JEP 525): allSuccessfulOrThrow возвращает список, anySuccessfulOrThrow.
import java.math.BigDecimal;
import java.time.Duration;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.StructuredTaskScope;
import java.util.concurrent.StructuredTaskScope.Joiner;

public class Quotes26 {
    record Quote(String provider, BigDecimal price) {}

    static Quote quote(String name, long delayMs, String price) throws InterruptedException {
        Thread.sleep(delayMs);
        return new Quote(name, new BigDecimal(price));
    }

    public static void main(String[] args) throws Exception {
        try (var scope = StructuredTaskScope.open(Joiner.<Quote>allSuccessfulOrThrow(), cfg -> cfg.withTimeout(Duration.ofSeconds(2)))) {
            scope.fork(() -> quote("bank-a", 100, "92.10"));
            scope.fork(() -> quote("bank-b", 300, "91.95"));
            List<Quote> all = scope.join();
            System.out.println("java " + System.getProperty("java.version") + ": join() вернул " + all.getClass().getSimpleName() + " " + all);
            System.out.println("лучшая: " + all.stream().min(Comparator.comparing(Quote::price)).orElseThrow());
        }
        try (var scope = StructuredTaskScope.open(Joiner.<Quote>anySuccessfulOrThrow())) {
            scope.fork(() -> quote("bank-a", 100, "92.10"));
            scope.fork(() -> quote("bank-b", 300, "91.95"));
            System.out.println("anySuccessfulOrThrow: " + scope.join());
        }
    }
}
