// JDKS: 21 25
// OUT: s6-fan-out
// Отмена при тайм-ауте: CompletableFuture.orTimeout не останавливает задачу, invokeAll с тайм-аутом прерывает её.
import java.util.List;
import java.util.concurrent.*;

public class FanOut {
    static String slowProvider(String name) throws InterruptedException {
        try {
            Thread.sleep(1000);
            System.out.println("  " + name + ": ответ получен, хотя он уже никому не нужен");
            return name;
        } catch (InterruptedException e) {
            System.out.println("  " + name + ": прерван");
            throw e;
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version") + ", common pool parallelism = "
                + ForkJoinPool.getCommonPoolParallelism() + " при " + Runtime.getRuntime().availableProcessors() + " процессорах");
        var executor = Executors.newVirtualThreadPerTaskExecutor();
        var cf = CompletableFuture.supplyAsync(() -> {
            try { return slowProvider("cf-provider"); } catch (InterruptedException e) { throw new CompletionException(e); }
        }, executor).orTimeout(200, TimeUnit.MILLISECONDS);
        try {
            cf.join();
        } catch (CompletionException e) {
            System.out.println("CompletableFuture.orTimeout(200 мс): " + e.getCause().getClass().getSimpleName());
        }
        Thread.sleep(1200);
        executor.close();

        try (var es = Executors.newVirtualThreadPerTaskExecutor()) {
            List<Callable<String>> tasks = List.of(() -> slowProvider("ia-provider"));
            var results = es.invokeAll(tasks, 200, TimeUnit.MILLISECONDS);
            System.out.println("invokeAll(200 мс): state=" + results.get(0).state());
        }
    }
}
