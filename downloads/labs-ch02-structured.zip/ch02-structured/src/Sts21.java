// JDKS: 21 25
// PREVIEW: 21 25
// OUT: s6-sts-21
// API structured concurrency в JDK 21 (JEP 453): конструктор ShutdownOnFailure. На 25 его уже нет.
import java.util.concurrent.StructuredTaskScope;

public class Sts21 {
    public static void main(String[] args) throws Exception {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
            var limit = scope.fork(() -> "лимит 100000");
            var score = scope.fork(() -> "скоринг 712");
            scope.join().throwIfFailed();
            System.out.println("java " + System.getProperty("java.version") + ": " + limit.get() + ", " + score.get());
        }
    }
}
