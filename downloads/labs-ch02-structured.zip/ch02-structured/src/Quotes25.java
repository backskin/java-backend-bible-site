// JDKS: 25 26
// PREVIEW: 25 26
// OUT: s6-quotes-25
// StructuredTaskScope в API JDK 25 (JEP 505): лучшая котировка, отмена, тайм-аут, правила владельца.
// Тот же файл на JDK 26 (JEP 525) показывает, что изменилось в API.
import java.math.BigDecimal;
import java.time.Duration;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.StructuredTaskScope;
import java.util.concurrent.StructuredTaskScope.Joiner;
import java.util.concurrent.StructuredTaskScope.Subtask;

public class Quotes25 {
    record Quote(String provider, BigDecimal price) {}
    record Provider(String name, long delayMs, String price) {
        Quote quote() throws InterruptedException {
            try {
                Thread.sleep(delayMs);
            } catch (InterruptedException e) {
                System.out.println("  " + name + ": прерван");
                throw e;
            }
            if (price == null) throw new IllegalStateException(name + " недоступен");
            return new Quote(name, new BigDecimal(price));
        }
    }

    static final List<Provider> OK = List.of(new Provider("bank-a", 100, "92.10"), new Provider("bank-b", 300, "91.95"), new Provider("bank-c", 200, "92.40"));
    static final List<Provider> ONE_FAILS = List.of(new Provider("bank-a", 100, null), new Provider("bank-b", 3000, "91.95"));

    static Quote best(List<Provider> providers, Duration timeout) throws InterruptedException {
        try (var scope = StructuredTaskScope.open(Joiner.<Quote>allSuccessfulOrThrow(), cfg -> cfg.withTimeout(timeout))) {
            providers.forEach(p -> scope.fork(p::quote));
            return scope.join().map(Subtask::get).min(Comparator.comparing(Quote::price)).orElseThrow();
        }
    }

    static Quote first(List<Provider> providers) throws InterruptedException {
        try (var scope = StructuredTaskScope.open(Joiner.<Quote>anySuccessfulResultOrThrow())) {
            providers.forEach(p -> scope.fork(p::quote));
            return scope.join();
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version"));
        long t0 = System.nanoTime();
        System.out.println("лучшая из трёх: " + best(OK, Duration.ofSeconds(2)) + " за " + (System.nanoTime() - t0) / 1_000_000 + " мс");
        t0 = System.nanoTime();
        try {
            best(ONE_FAILS, Duration.ofSeconds(5));
        } catch (StructuredTaskScope.FailedException e) {
            System.out.println("один провайдер упал: " + e.getClass().getSimpleName() + ", причина: " + e.getCause() + ", через " + (System.nanoTime() - t0) / 1_000_000 + " мс");
        }
        t0 = System.nanoTime();
        try {
            best(OK, Duration.ofMillis(150));
        } catch (StructuredTaskScope.TimeoutException e) {
            System.out.println("тайм-аут 150 мс: " + e.getClass().getName() + " через " + (System.nanoTime() - t0) / 1_000_000 + " мс");
        }
        t0 = System.nanoTime();
        System.out.println("первая успешная: " + first(OK) + " за " + (System.nanoTime() - t0) / 1_000_000 + " мс");

        try (var scope = StructuredTaskScope.open(Joiner.<String>awaitAll())) {
            scope.fork(() -> "ok");
            scope.fork(() -> { throw new IllegalStateException("отказ"); });
            Object r = scope.join();
            System.out.println("awaitAll().join() вернул: " + r);
        }
        try (var scope = StructuredTaskScope.open()) {
            scope.fork(() -> "ok");
            scope.join();
            scope.fork(() -> "late");
        } catch (IllegalStateException e) {
            System.out.println("fork после join: " + e);
        }
        try (var scope = StructuredTaskScope.open()) {
            scope.fork(() -> "ok");
            Thread other = Thread.ofVirtual().start(() -> {
                try { scope.join(); } catch (Exception e) { System.out.println("join из чужого потока: " + e); }
            });
            other.join();
            scope.join();
        }
        try {
            var scope = StructuredTaskScope.open();
            scope.fork(() -> "ok");
            scope.close();
        } catch (IllegalStateException e) {
            System.out.println("close без join: " + e);
        }
    }
}
