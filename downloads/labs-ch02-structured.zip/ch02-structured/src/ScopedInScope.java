// JDKS: 25
// PREVIEW: 25
// OUT: s6-scoped-in-scope
// Подзадачи StructuredTaskScope наследуют привязки ScopedValue родителя.
import java.util.concurrent.StructuredTaskScope;

public class ScopedInScope {
    record RequestContext(String traceId, String tenant) {}
    static final ScopedValue<RequestContext> CTX = ScopedValue.newInstance();

    public static void main(String[] args) throws Exception {
        ScopedValue.where(CTX, new RequestContext("trace-42", "bank-a")).call(() -> {
            try (var scope = StructuredTaskScope.open()) {
                var limit = scope.fork(() -> "лимит для " + CTX.get().tenant() + " (" + CTX.get().traceId() + ")");
                var audit = scope.fork(() -> "аудит в потоке virtual=" + Thread.currentThread().isVirtual() + ", tenant=" + CTX.get().tenant());
                scope.join();
                System.out.println(limit.get());
                System.out.println(audit.get());
            }
            return null;
        });
    }
}
