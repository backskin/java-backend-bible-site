// JDKS: 21 25
// PREVIEW: 21
// OUT: s6-scoped-values
// ScopedValue: привязка на время блока, перепривязка, null, наследование потоками и исполнителем.
import java.util.NoSuchElementException;
import java.util.concurrent.Executors;

public class ScopedValues {
    static final ScopedValue<String> TENANT = ScopedValue.newInstance();

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version"));
        System.out.println("isBound вне привязки: " + TENANT.isBound() + ", orElse: " + TENANT.orElse("none"));
        try {
            TENANT.get();
        } catch (NoSuchElementException e) {
            System.out.println("get вне привязки: " + e.getClass().getSimpleName());
        }
        ScopedValue.where(TENANT, "bank-a").run(() -> {
            System.out.println("внутри: " + TENANT.get());
            ScopedValue.where(TENANT, "system").run(() -> System.out.println("  вложенная привязка: " + TENANT.get()));
            System.out.println("после вложенной: " + TENANT.get());
            try {
                Thread t = Thread.ofVirtual().start(() -> System.out.println("  новый поток видит привязку: " + TENANT.isBound()));
                t.join();
                try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
                    System.out.println("  задача исполнителя видит привязку: " + ex.submit(TENANT::isBound).get());
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        System.out.println("после выхода из run: isBound=" + TENANT.isBound());
        String result = ScopedValue.where(TENANT, "bank-b").call(() -> "call вернул " + TENANT.get());
        System.out.println(result);
        try {
            ScopedValue.where(TENANT, null).run(() -> System.out.println("привязан null: get()=" + TENANT.get()));
        } catch (NullPointerException e) {
            System.out.println("where(TENANT, null): NullPointerException");
        }
        try {
            System.out.println("orElse(null): " + TENANT.orElse(null));
        } catch (NullPointerException e) {
            System.out.println("orElse(null): NullPointerException");
        }
    }
}
