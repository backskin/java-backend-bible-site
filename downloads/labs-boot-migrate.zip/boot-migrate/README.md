# Миграция Spring Boot 3.5 на 4.0 рецептом OpenRewrite

Стенд к главе 10, раздел о миграции. Сервис комиссий `FeeApp` с двумя тестами (`FeeApiTests`, `FeeControllerTests`), написанный под Boot 3.5.16, прогоняется через `rewrite-maven-plugin` с правилом миграции `org.openrewrite.java.spring.boot4.UpgradeSpringBoot_4_0`: что правило меняет в `pom.xml` и в коде (стартеры `webmvc`, `restclient`, тестовые стартеры), что остается сделать руками и проходят ли тесты до и после. `pom.xml` в репозитории - уже после миграции (родитель 4.0.9). Вывод автора - `s10-migrate.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

Проверить состояние после миграции:

```bash
mvn -q test
```

Повторить миграцию с нуля: вернуть в `pom.xml` родителя `3.5.16` и стартеры `web`, `test`, затем

```bash
mvn -U org.openrewrite.maven:rewrite-maven-plugin:run -Drewrite.recipeArtifactCoordinates=org.openrewrite.recipe:rewrite-spring:RELEASE -Drewrite.activeRecipes=org.openrewrite.java.spring.boot4.UpgradeSpringBoot_4_0
```

В IDEA есть конфигурации `FeeApp` и `mvn test`.

## Что должно получиться

Два теста проходят и на 3.5.16, и на 4.0.9 после правила; список измененных файлов и ручных правок - в `s10-migrate.txt`.
