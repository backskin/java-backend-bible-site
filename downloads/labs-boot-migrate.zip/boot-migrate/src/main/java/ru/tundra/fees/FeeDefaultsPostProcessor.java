package ru.tundra.fees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;

import java.util.Map;

/** Значения по умолчанию для сервиса комиссий, добавляются до чтения файлов конфигурации. */
public class FeeDefaultsPostProcessor implements EnvironmentPostProcessor {
    @Override
    public void postProcessEnvironment(ConfigurableEnvironment env, SpringApplication app) {
        env.getPropertySources().addLast(new MapPropertySource("feeDefaults", Map.of("tundra.fees.min", "30")));
    }
}
