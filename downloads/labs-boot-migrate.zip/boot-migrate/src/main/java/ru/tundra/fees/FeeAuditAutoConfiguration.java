package ru.tundra.fees;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Bean;

import javax.sql.DataSource;

/** Внутренний стартер аудита: порядок задан и классом, и строкой. */
@AutoConfiguration(after = DataSourceAutoConfiguration.class,
        afterName = "org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration")
public class FeeAuditAutoConfiguration {

    public static final String AFTER = "org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration";

    @Bean
    @ConditionalOnBean(DataSource.class)
    FeeAudit feeAudit(DataSource ds) { return new FeeAudit(); }

    public static class FeeAudit { }
}
