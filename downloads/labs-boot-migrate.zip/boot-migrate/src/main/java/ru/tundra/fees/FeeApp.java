package ru.tundra.fees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@SpringBootApplication
public class FeeApp {
    public static void main(String[] args) { SpringApplication.run(FeeApp.class, args); }
}

@Service
class FeeService {
    BigDecimal fee(BigDecimal amount) { return amount.multiply(new BigDecimal("0.005")).max(new BigDecimal("30")); }
}

@RestController
class FeeController {
    private final FeeService service;
    FeeController(FeeService service) { this.service = service; }

    @GetMapping("/api/fees/{amount}")
    BigDecimal fee(@PathVariable BigDecimal amount) { return service.fee(amount); }
}
