package ru.tundra.fees;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;

/** Добавлен после прогона рецепта: что осталось работать по-старому. */
@SpringBootTest
class FeeAfterMigrationTests {

    @Autowired Environment env;
    @Autowired ApplicationContext ctx;

    @Test
    void leftovers() {
        System.out.println("   ► после рецепта: tundra.fees.min из старого EnvironmentPostProcessor = " + env.getProperty("tundra.fees.min")
                + "; FeeAudit=" + ctx.getBeanNamesForType(FeeAuditAutoConfiguration.FeeAudit.class).length
                + "; DataSourceTransactionManagerAutoConfiguration исключена: "
                + (ctx.getBeanNamesForType(org.springframework.transaction.PlatformTransactionManager.class).length == 0));
    }
}
