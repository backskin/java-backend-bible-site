package ru.tundra.fees;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(FeeController.class)
class FeeControllerTests {

    @Autowired MockMvc mvc;
    @MockitoBean FeeService service;

    @Test
    void returnsFee() throws Exception {
        given(service.fee(new BigDecimal("10000"))).willReturn(new BigDecimal("50"));
        mvc.perform(get("/api/fees/10000")).andExpect(status().isOk()).andExpect(content().string("50"));
    }
}
