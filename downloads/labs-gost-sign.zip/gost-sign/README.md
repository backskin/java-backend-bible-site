# Подпись ГОСТ Р 34.10-2012 в формате CMS на Bouncy Castle: ключи, сертификат, подпись и проверка без КриптоПро

Стенд к главе 41. `GostCmsLab` (Bouncy Castle 1.80: `bcprov`, `bcpkix`, `bcutil`) генерирует ключевую пару ГОСТ Р 34.10-2012 и самоподписанный сертификат, подписывает документ в CMS (`SignedData`, с подписанными атрибутами) и проверяет подпись, разбирая структуру. КриптоПро на стенде не установлен, его поведение не проверялось; тестовые ключи создаются при каждом запуске.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp.txt)" dev.team.gost.GostCmsLab
```

В IDEA есть конфигурация `GostCmsLab`.
