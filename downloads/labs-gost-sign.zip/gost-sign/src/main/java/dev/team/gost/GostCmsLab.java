package dev.team.gost;

import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.KeyUsage;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECNamedCurveGenParameterSpec;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

/**
 * Опыт: шлюз подписи КорзиныПлюс подписывает кассовый чек отсоединённой подписью CMS по ГОСТ Р 34.10-2012
 * с хешем ГОСТ Р 34.11-2012 (Стрибог). Bouncy Castle стоит на месте КриптоПро JCP: формат CMS тот же,
 * но сертифицированным средством электронной подписи Bouncy Castle не является.
 */
public class GostCmsLab {
    static final String SIG_ALG = "GOST3411-2012-256WITHECGOST3410-2012-256";

    public static void main(String[] args) throws Exception {
        Security.addProvider(new BouncyCastleProvider());

        System.out.println("== 1. тестовый УЦ и сертификат шлюза подписи, ключи ГОСТ Р 34.10-2012 256 бит");
        KeyPair caKeys = gostKeys(), gwKeys = gostKeys();
        Instant now = Instant.now();
        X509Certificate ca = cert("CN=Тестовый УЦ Тундра-Банка, O=Тундра-Банк", "CN=Тестовый УЦ Тундра-Банка, O=Тундра-Банк",
                caKeys, caKeys, now.minus(1, ChronoUnit.DAYS), now.plus(3650, ChronoUnit.DAYS), true);
        X509Certificate gw = cert("CN=Тестовый УЦ Тундра-Банка, O=Тундра-Банк", "CN=Шлюз подписи документов, O=КорзинаПлюс",
                gwKeys, caKeys, now.minus(1, ChronoUnit.DAYS), now.plus(365, ChronoUnit.DAYS), false);
        System.out.println("   алгоритм ключа: " + gw.getPublicKey().getAlgorithm() + ", OID подписи сертификата: " + gw.getSigAlgOID() + " (" + gw.getSigAlgName() + ")");
        gw.verify(ca.getPublicKey(), "BC");
        System.out.println("   сертификат шлюза проверен открытым ключом УЦ");

        byte[] receipt = """
            {"store":"0417","pos":"17","check":"000042","date":"2026-10-26T14:03:11+05:00","totalMinor":159460,
             "items":[{"sku":"MILK-3.2-930","qty":2},{"sku":"COFFEE-250","qty":1}],"coupon":"MILK-5"}""".getBytes(StandardCharsets.UTF_8);

        System.out.println("== 2. отсоединённая подпись чека");
        byte[] detached = sign(receipt, gwKeys, gw, false);
        byte[] attached = sign(receipt, gwKeys, gw, true);
        System.out.println("   чек " + receipt.length + " байт; подпись CMS отсоединённая " + detached.length + " байт, присоединённая " + attached.length + " байт");
        CMSSignedData parsed = new CMSSignedData(new CMSProcessableByteArray(receipt), detached);
        SignerInformation si = parsed.getSignerInfos().getSigners().iterator().next();
        System.out.println("   OID хеша: " + si.getDigestAlgOID() + ", OID подписи: " + si.getEncryptionAlgOID());
        for (ASN1ObjectIdentifier oid : List.of(CMSAttributes.contentType, CMSAttributes.messageDigest, CMSAttributes.signingTime)) {
            Attribute a = si.getSignedAttributes().get(oid);
            System.out.println("   подписанный атрибут " + oid + " = " + (a == null ? "нет" : a.getAttrValues().getObjectAt(0)));
        }

        System.out.println("== 3. проверка подписи");
        System.out.println("   исходный чек: " + verify(receipt, detached));
        byte[] tampered = new String(receipt, StandardCharsets.UTF_8).replace("159460", "159461").getBytes(StandardCharsets.UTF_8);
        System.out.println("   сумма изменена на 1 копейку: " + verify(tampered, detached));

        System.out.println("== 4. подпись накладной СтальМагистрали и тот же документ после перезаписи");
        byte[] waybill = """
            <?xml version="1.0" encoding="UTF-8"?>
            <waybill xmlns="urn:stalmag:waybill:1" id='ЭН-2026102601'>
              <date>2026-10-26</date>
              <kind>ГРУППОВАЯ</kind>
            </waybill>
            """.getBytes(StandardCharsets.UTF_8);
        byte[] wbSig = sign(waybill, gwKeys, gw, false);
        var dbf = DocumentBuilderFactory.newInstance(); dbf.setNamespaceAware(true);
        var doc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(waybill));
        var out = new ByteArrayOutputStream();
        TransformerFactory.newInstance().newTransformer().transform(new DOMSource(doc), new StreamResult(out));
        byte[] rewritten = out.toByteArray();
        System.out.println("   исходные байты:      " + verify(waybill, wbSig));
        System.out.println("   после DOM и записи:  " + verify(rewritten, wbSig));
        System.out.println("   было:  " + new String(waybill, StandardCharsets.UTF_8).lines().limit(2).toList());
        System.out.println("   стало: " + new String(rewritten, StandardCharsets.UTF_8).substring(0, Math.min(110, rewritten.length)).replace("\n", "\\n"));

        System.out.println("== 5. скорость: 2000 подписей и проверок ГОСТ на Bouncy Castle");
        long t0 = System.nanoTime();
        byte[] last = null;
        for (int i = 0; i < 2000; i++) last = sign(receipt, gwKeys, gw, false);
        long signMs = (System.nanoTime() - t0) / 1_000_000;
        t0 = System.nanoTime();
        for (int i = 0; i < 2000; i++) verify(receipt, last);
        long verMs = (System.nanoTime() - t0) / 1_000_000;
        System.out.printf("   подпись: %.2f мс на документ, проверка: %.2f мс, один поток%n", signMs / 2000.0, verMs / 2000.0);
    }

    static KeyPair gostKeys() throws Exception {
        var g = KeyPairGenerator.getInstance("ECGOST3410-2012", "BC");
        g.initialize(new ECNamedCurveGenParameterSpec("Tc26-Gost-3410-12-256-paramSetA"));
        return g.generateKeyPair();
    }

    static X509Certificate cert(String issuer, String subject, KeyPair subj, KeyPair issuerKeys, Instant from, Instant to, boolean ca) throws Exception {
        var b = new JcaX509v3CertificateBuilder(new X500Name(issuer), BigInteger.valueOf(System.nanoTime()), Date.from(from), Date.from(to), new X500Name(subject), subj.getPublic());
        b.addExtension(Extension.basicConstraints, true, new BasicConstraints(ca));
        b.addExtension(Extension.keyUsage, true, new KeyUsage(ca ? KeyUsage.keyCertSign | KeyUsage.cRLSign : KeyUsage.digitalSignature | KeyUsage.nonRepudiation));
        ContentSigner s = new JcaContentSignerBuilder(SIG_ALG).setProvider("BC").build(issuerKeys.getPrivate());
        return new JcaX509CertificateConverter().setProvider("BC").getCertificate(b.build(s));
    }

    static byte[] sign(byte[] data, KeyPair keys, X509Certificate cert, boolean encapsulate) throws Exception {
        var gen = new CMSSignedDataGenerator();
        ContentSigner s = new JcaContentSignerBuilder(SIG_ALG).setProvider("BC").build(keys.getPrivate());
        gen.addSignerInfoGenerator(new JcaSignerInfoGeneratorBuilder(new JcaDigestCalculatorProviderBuilder().setProvider("BC").build()).build(s, cert));
        gen.addCertificates(new JcaCertStore(List.of(cert)));
        return gen.generate(new CMSProcessableByteArray(data), encapsulate).getEncoded();
    }

    static String verify(byte[] data, byte[] sig) {
        try {
            CMSSignedData d = new CMSSignedData(new CMSProcessableByteArray(data), sig);
            SignerInformation si = d.getSignerInfos().getSigners().iterator().next();
            @SuppressWarnings("unchecked")
            X509CertificateHolder h = (X509CertificateHolder) d.getCertificates().getMatches(si.getSID()).iterator().next();
            return si.verify(new JcaSimpleSignerInfoVerifierBuilder().setProvider("BC").build(h)) ? "подпись верна" : "подпись НЕВЕРНА";
        } catch (Exception e) {
            return "подпись НЕВЕРНА (" + e.getClass().getSimpleName() + ": " + e.getMessage() + ")";
        }
    }
}
