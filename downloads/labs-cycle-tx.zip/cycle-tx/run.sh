#!/usr/bin/env bash
# Инцидент 16.6 гл. 09 на четырёх версиях Spring; вывод — s09-cycle-tx.txt
set -e
cd "$(dirname "$0")"
out=s09-cycle-tx.txt
: > "$out"
for v in 5.3.31 6.1.21 6.2.19 7.0.9; do
  rm -rf target/classes
  mvn -q -Dspring.version=$v compile dependency:build-classpath -Dmdep.outputFile=cp-$v.txt >/dev/null
  java -Dstdout.encoding=UTF-8 -cp "target/classes;$(cat cp-$v.txt)" dev.team.cycletx.CycleTxLab >> "$out" 2>&1
done
cat "$out"
