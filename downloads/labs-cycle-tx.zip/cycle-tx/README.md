# Циклическая зависимость с @Transactional на Spring 5.3, 6.1, 6.2 и 7.0

Стенд к главе 09, инцидент 16.6. Один и тот же код `CycleTxLab` (два бина с циклом, один под `@Transactional`, постпроцессор замеров) собирается и запускается с `spring-context` 5.3.31, 6.1.21, 6.2.19 и 7.0.9, чтобы увидеть, где контейнер подставляет сырой бин вместо прокси, где предупреждает и где отказывает. Менеджер транзакций без ресурса, признак транзакции - `TransactionSynchronizationManager`. Вывод автора - `s09-cycle-tx.txt`.

## Что нужно

- JDK 21 (проект собирается под `--release 17`), Maven, bash.

## Запуск

```bash
bash run.sh
```

Скрипт для каждой версии задает `-Dspring.version`, собирает classpath в `cp-<версия>.txt` и запускает класс. Одна версия вручную:

```bash
mvn -q -Dspring.version=7.0.9 compile dependency:build-classpath -Dmdep.outputFile=cp.txt && java -cp "target/classes;$(cat cp.txt)" dev.team.cycletx.CycleTxLab
```

В IDEA есть конфигурация `CycleTxLab` (версия Spring - та, что в `pom.xml` по умолчанию).

## Что должно получиться

Четыре блока `== Spring <версия>` с разным исходом: на 5.3 цикл разрешается тихо, с 6.x появляются предупреждения, на 7.0 поведение описано в главе.
