package dev.team.cycletx;

import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.SpringVersion;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.AbstractPlatformTransactionManager;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Инцидент 16.6: сервисы платежей и лимитов ссылаются друг на друга через сеттеры,
 * у лимитов транзакционный метод, оба бина получают прокси от самописного постпроцессора замеров.
 * Что достаётся платежам в поле limits и идёт ли проверка лимита в транзакции.
 */
public class CycleTxLab {

    /** Метка прокси замеров. */
    public interface Metered { }

    public static class Payments {
        Limits limits;
        @Autowired public void setLimits(Limits limits) { this.limits = limits; }
        public void pay() { limits.check(); }
    }

    public static class Limits {
        Payments payments;
        static boolean txActive;
        @Autowired public void setPayments(Payments payments) { this.payments = payments; }
        @Transactional public void check() { txActive = TransactionSynchronizationManager.isActualTransactionActive(); }
    }

    static Object meter(Object bean) {
        ProxyFactory pf = new ProxyFactory(bean);
        pf.setProxyTargetClass(true);
        pf.addInterface(Metered.class);
        pf.addAdvice((MethodInterceptor) inv -> inv.proceed());
        return pf.getProxy();
    }

    static boolean ours(Object bean) { return bean instanceof Payments || bean instanceof Limits; }

    /** Замеры только после инициализации — так был написан постпроцессор в инциденте. */
    public static class LateMetrics implements BeanPostProcessor {
        @Override public Object postProcessAfterInitialization(Object bean, String name) { return ours(bean) ? meter(bean) : bean; }
    }

    /** Исправление: прокси замеров отдаётся и по ранней ссылке. */
    public static class EarlyMetrics implements SmartInstantiationAwareBeanPostProcessor {
        final Set<String> early = ConcurrentHashMap.newKeySet();
        @Override public Object getEarlyBeanReference(Object bean, String name) {
            if (!ours(bean)) return bean;
            early.add(name);
            return meter(bean);
        }
        @Override public Object postProcessAfterInitialization(Object bean, String name) {
            return ours(bean) && !early.remove(name) ? meter(bean) : bean;
        }
    }

    /** Менеджер транзакций без ресурса: нужен только флаг «транзакция открыта». */
    static class NoopTxManager extends AbstractPlatformTransactionManager {
        @Override protected Object doGetTransaction() { return new Object(); }
        @Override protected void doBegin(Object tx, TransactionDefinition def) { }
        @Override protected void doCommit(DefaultTransactionStatus status) { }
        @Override protected void doRollback(DefaultTransactionStatus status) { }
    }

    @Configuration @EnableTransactionManagement
    static class Base {
        @Bean PlatformTransactionManager txManager() { return new NoopTxManager(); }
        @Bean Payments payments() { return new Payments(); }
        @Bean Limits limits() { return new Limits(); }
    }

    @Configuration static class WithLate { @Bean static LateMetrics metrics() { return new LateMetrics(); } }
    @Configuration static class WithEarly { @Bean static EarlyMetrics metrics() { return new EarlyMetrics(); } }

    /** Слои обёрток: «замеры», «транзакция», внизу — класс исходного объекта. */
    static String layers(Object o) throws Exception {
        List<String> out = new ArrayList<>();
        while (o instanceof Advised a) {
            boolean tx = false;
            for (var adv : a.getAdvisors()) tx |= adv.getAdvice().getClass().getSimpleName().equals("TransactionInterceptor");
            out.add(o instanceof Metered && !tx ? "замеры" : tx ? "транзакция" : "прокси");
            o = a.getTargetSource().getTarget();
        }
        out.add(o.getClass().getSimpleName());
        return String.join(" → ", out);
    }

    static void run(String title, Class<?>... extra) {
        System.out.println("  " + title + ":");
        var ctx = new AnnotationConfigApplicationContext();
        ctx.register(Base.class);
        if (extra.length > 0) ctx.register(extra);
        try {
            ctx.refresh();
        } catch (Exception e) {
            Throwable c = e;
            while (c.getCause() != null) c = c.getCause();
            String msg = String.valueOf(c.getMessage());
            System.out.println("     контекст не поднялся: " + c.getClass().getSimpleName() + ": " + msg.substring(0, Math.min(msg.length(), 150)));
            return;
        }
        try {
            Payments p = ctx.getBean(Payments.class);
            Limits l = ctx.getBean(Limits.class);
            Payments pt = (Payments) unwrap(p);
            Limits lt = (Limits) unwrap(l);
            System.out.println("     в контексте Limits:     " + layers(l));
            System.out.println("     у Payments поле limits: " + layers(pt.limits));
            System.out.println("     у Limits поле payments: " + layers(lt.payments));
            Limits.txActive = false;
            p.pay();
            System.out.println("     payments.pay() → limits.check() в транзакции: " + Limits.txActive);
            Limits.txActive = false;
            l.check();
            System.out.println("     limits.check() из контекста в транзакции:   " + Limits.txActive);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            ctx.close();
        }
    }

    static Object unwrap(Object o) throws Exception {
        while (o instanceof Advised a) o = a.getTargetSource().getTarget();
        return o;
    }

    public static void main(String[] args) {
        System.out.println("== Spring " + SpringVersion.getVersion() + ", Java " + System.getProperty("java.version"));
        run("только транзакция, постпроцессора замеров нет");
        run("замеры после инициализации (как в инциденте)", WithLate.class);
        run("замеры и по ранней ссылке (исправление)", WithEarly.class);
    }
}
