# Упражнения главы 10: старт без драйвера базы, порядок источников свойств, кэш тестовых контекстов

Стенд к упражнениям 1, 3 и 7 главы 10. Реестр платежей `RegistryApp` (Spring Boot 4.1.1, Spring Data JPA, Actuator): упражнение 1 - запуск с `webmvc` и `data-jpa`, но без драйвера базы, и чтение отчета `--debug` и анализатора сбоя; упражнение 3 - одно свойство из файла, переменной окружения, `-D` и аргумента, кто победил по `/actuator/env`; упражнение 7 - восемь тестовых классов в пакете `many` с разными настройками и в пакете `shared` с едиными, статистика кэша контекстов. Выводы автора - `s10-tryit.txt`, `s10-tryit3.txt`, `s10-tryit7.txt`.

## Что нужно

- JDK 21 и Maven.

## Запуск

```bash
mvn -q package -DskipTests && java -jar target/registry-tryit-*.jar --debug
```

Тесты: `mvn -q test -Dtest='dev.team.tryit.many.*'` и то же для `shared`. В IDEA есть конфигурации `RegistryApp` и `mvn test`.

## Что должно получиться

Без драйвера приложение завершается с кодом 1 и сообщением анализатора `Failed to configure a DataSource`; в упражнении 3 побеждает `commandLineArgs`; в пакете `many` восемь контекстов (`size = 8, missCount = 8`), в `shared` один.
