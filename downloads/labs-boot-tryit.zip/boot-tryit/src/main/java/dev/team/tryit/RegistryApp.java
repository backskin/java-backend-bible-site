package dev.team.tryit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/** Реестр платежей: JPA в зависимостях, драйвера базы нет. */
@SpringBootApplication
@ConfigurationPropertiesScan
public class RegistryApp {

    /** Режим выгрузки реестра: им проверяют приоритет источников свойств. */
    @ConfigurationProperties("tundra.registry")
    public record RegistryProperties(String mode) { }

    public static void main(String[] args) {
        SpringApplication.run(RegistryApp.class, args);
    }
}
