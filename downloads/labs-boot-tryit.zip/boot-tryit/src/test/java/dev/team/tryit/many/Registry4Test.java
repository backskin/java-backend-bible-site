package dev.team.tryit.many;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import dev.team.tryit.RegistryApp;

@SpringBootTest(classes = RegistryApp.class, webEnvironment = SpringBootTest.WebEnvironment.NONE, properties = "test.n=4")
class Registry4Test { @Test void starts() { } }
