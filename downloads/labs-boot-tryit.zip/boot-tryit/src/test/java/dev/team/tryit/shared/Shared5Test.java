package dev.team.tryit.shared;

import org.junit.jupiter.api.Test;

@RegistryIntegrationTest
class Shared5Test { @Test void starts() { } }
