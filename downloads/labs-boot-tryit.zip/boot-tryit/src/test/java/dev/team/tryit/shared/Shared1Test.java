package dev.team.tryit.shared;

import org.junit.jupiter.api.Test;

@RegistryIntegrationTest
class Shared1Test { @Test void starts() { } }
