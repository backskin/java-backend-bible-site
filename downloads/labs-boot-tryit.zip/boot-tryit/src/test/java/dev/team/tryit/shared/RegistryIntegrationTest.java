package dev.team.tryit.shared;

import dev.team.tryit.RegistryApp;
import org.springframework.boot.test.context.SpringBootTest;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/** Одна мета-аннотация на все интеграционные тесты: один ключ кеша, один контекст. */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@SpringBootTest(classes = RegistryApp.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public @interface RegistryIntegrationTest { }
