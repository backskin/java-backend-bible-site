package dev.team.tryit.shared;

import org.junit.jupiter.api.Test;

@RegistryIntegrationTest
class Shared2Test { @Test void starts() { } }
