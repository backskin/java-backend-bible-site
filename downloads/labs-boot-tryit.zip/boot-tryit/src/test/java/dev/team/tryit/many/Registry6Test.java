package dev.team.tryit.many;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import dev.team.tryit.RegistryApp;

@SpringBootTest(classes = RegistryApp.class, webEnvironment = SpringBootTest.WebEnvironment.NONE, properties = "test.n=6")
class Registry6Test { @Test void starts() { } }
