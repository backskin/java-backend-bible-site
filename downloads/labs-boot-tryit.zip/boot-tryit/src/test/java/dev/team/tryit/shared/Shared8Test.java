package dev.team.tryit.shared;

import org.junit.jupiter.api.Test;

@RegistryIntegrationTest
class Shared8Test { @Test void starts() { } }
