package dev.team.tryit.many;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import dev.team.tryit.RegistryApp;

@SpringBootTest(classes = RegistryApp.class, webEnvironment = SpringBootTest.WebEnvironment.NONE, properties = "test.n=7")
class Registry7Test { @Test void starts() { } }
