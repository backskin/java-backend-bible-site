package dev.team.tryit.shared;

import org.junit.jupiter.api.Test;

@RegistryIntegrationTest
class Shared3Test { @Test void starts() { } }
