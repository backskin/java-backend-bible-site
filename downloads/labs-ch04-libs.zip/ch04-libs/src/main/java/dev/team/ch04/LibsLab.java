package dev.team.ch04;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.BreakIterator;
import com.ibm.icu.text.SpoofChecker;
import com.ibm.icu.util.ULocale;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Map;

/** Опыты главы 04 с библиотеками: Jackson 2.18.3, RE2/J 1.8, ICU4J 77.1. */
public class LibsLab {

    public record TypedDto(BigDecimal amount, String currency) {}
    public record ToStringDto(@JsonSerialize(using = ToStringSerializer.class) BigDecimal amount, String currency) {}
    public record FormatDto(@JsonFormat(shape = JsonFormat.Shape.STRING) BigDecimal amount, String currency) {}
    public record EventDto(Instant at) {}
    public record MeetingDto(ZonedDateTime start) {}

    static void h(String s) { System.out.println("--- " + s); }

    public static void main(String[] args) throws Exception {
        h("1. Jackson: чтение суммы 0.10");
        ObjectMapper plain = new ObjectMapper();
        String json = "{\"amount\": 0.10, \"currency\": \"RUB\"}";
        System.out.println("типизированное поле: " + plain.readValue(json, TypedDto.class).amount());
        Map<?, ?> asMap = plain.readValue(json, Map.class);
        System.out.println("Map: " + asMap.get("amount") + " " + asMap.get("amount").getClass().getSimpleName());
        JsonNode node = plain.readTree(json);
        System.out.println("JsonNode: " + node.get("amount") + " " + node.get("amount").getClass().getSimpleName());
        ObjectMapper big = new ObjectMapper().enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
        Map<?, ?> bigMap = big.readValue(json, Map.class);
        System.out.println("Map + USE_BIG_DECIMAL_FOR_FLOATS: " + bigMap.get("amount") + " " + bigMap.get("amount").getClass().getSimpleName());
        System.out.println("JsonNode + USE_BIG_DECIMAL_FOR_FLOATS: " + big.readTree(json).get("amount"));

        h("2. Jackson: запись суммы");
        BigDecimal thousand = new BigDecimal("1E+3");
        System.out.println(plain.writeValueAsString(new ToStringDto(new BigDecimal("1234.56"), "RUB")));
        System.out.println(plain.writeValueAsString(new ToStringDto(thousand, "RUB")));
        System.out.println(new ObjectMapper().enable(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN).writeValueAsString(new FormatDto(thousand, "RUB")));
        System.out.println(plain.writeValueAsString(new TypedDto(thousand, "RUB")));

        h("3. Jackson: время");
        Instant at = Instant.parse("2026-09-10T13:05:00.123456789Z");
        ObjectMapper defaults = JsonMapper.builder().addModule(new JavaTimeModule()).build();
        System.out.println("по умолчанию: " + defaults.writeValueAsString(new EventDto(at)));
        ObjectMapper iso = JsonMapper.builder().addModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE).build();
        System.out.println("без WRITE_DATES_AS_TIMESTAMPS: " + iso.writeValueAsString(new EventDto(at)));
        String meeting = "{\"start\":\"2026-09-21T10:00:00+03:00[Europe/Moscow]\"}";
        System.out.println("ZonedDateTime, ADJUST по умолчанию: " + defaults.readValue(meeting, MeetingDto.class).start());
        System.out.println("ZonedDateTime, ADJUST выключен:    " + iso.readValue(meeting, MeetingDto.class).start());
        System.out.println("ZonedDateTime на запись: " + iso.writeValueAsString(new MeetingDto(ZonedDateTime.of(2026, 9, 21, 10, 0, 0, 0, ZoneId.of("Europe/Moscow")))));

        h("4. RE2/J против java.util.regex");
        String evil = "a".repeat(28) + "!";
        long t0 = System.nanoTime();
        boolean jdk = java.util.regex.Pattern.compile("^(a+)\\1*(a+)+$").matcher(evil).matches();
        long t1 = System.nanoTime();
        System.out.printf("java.util.regex ^(a+)\\1*(a+)+$ на 28 символах: %s, %d мс%n", jdk, (t1 - t0) / 1_000_000);
        try { com.google.re2j.Pattern.compile("^(a+)\\1*(a+)+$"); }
        catch (Exception e) { System.out.println("RE2/J и обратная ссылка: " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
        try { com.google.re2j.Pattern.compile("a(?=b)"); }
        catch (Exception e) { System.out.println("RE2/J и lookahead: " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
        String huge = "a".repeat(100_000) + "!";
        t0 = System.nanoTime();
        boolean re2 = com.google.re2j.Pattern.compile("^(a+)+$").matcher(huge).matches();
        System.out.printf("RE2/J ^(a+)+$ на 100000: %s, %d мс%n", re2, (System.nanoTime() - t0) / 1_000_000);
        String spaces = "x" + " ".repeat(20_000) + "x";
        t0 = System.nanoTime();
        com.google.re2j.Pattern.compile("^[\\s\\x{200c}]+|[\\s\\x{200c}]+$").matcher(spaces).replaceAll("");
        System.out.printf("RE2/J обрезка пробелов, 20000 внутри: %d мс%n", (System.nanoTime() - t0) / 1_000_000);

        h("5. ICU4J: плюрализация");
        com.ibm.icu.text.MessageFormat mf = new com.ibm.icu.text.MessageFormat(
                "{count, plural, one{# платёж} few{# платежа} many{# платежей} other{# платежа}}", new ULocale("ru"));
        StringBuilder sb = new StringBuilder();
        for (Object n : new Object[]{1, 3, 5, 11, 21, 22, 1.5}) sb.append(mf.format(Map.of("count", n))).append("; ");
        System.out.println(sb);

        h("6. ICU4J: графемы, case folding, гомоглифы");
        String family = "👨‍👩‍👧‍👦";
        BreakIterator it = BreakIterator.getCharacterInstance(ULocale.ROOT);
        it.setText(family);
        int n = 0;
        while (it.next() != BreakIterator.DONE) n++;
        System.out.println("графем в семье: " + n);
        System.out.println("foldCase(Straße)=" + UCharacter.foldCase("Straße", true) + " foldCase(STRASSE)=" + UCharacter.foldCase("STRASSE", true));
        SpoofChecker sc = new SpoofChecker.Builder().build();
        String latin = "paypal", mixed = "pаypal";
        System.out.println("skeleton равны: " + sc.getSkeleton(latin).equals(sc.getSkeleton(mixed))
                + ", areConfusable=" + sc.areConfusable(latin, mixed)
                + ", failsChecks(mixed)=" + sc.failsChecks(mixed));
    }
}
