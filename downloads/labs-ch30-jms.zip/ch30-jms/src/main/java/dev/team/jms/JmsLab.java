package dev.team.jms;

import jakarta.jms.*;
import jakarta.jms.Queue;
import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Опыты гл. 30 на Jakarta Messaging и ActiveMQ Artemis.
 * Брокер: docker run -d --name a30 -p 61616:61616 -e ARTEMIS_USER=dev.team -e ARTEMIS_PASSWORD=devteam apache/activemq-artemis
 */
public class JmsLab {
    public record Payment(String id, BigDecimal amount) implements Serializable {}

    static void p(String f, Object... a) { System.out.println(String.format(f, a)); }

    static ConnectionFactory cf() {
        return new ActiveMQConnectionFactory("tcp://localhost:61616", "dev.team", "devteam");
    }

    public static void main(String[] args) throws Exception {
        String sc = args[0];
        try (Connection c = cf().createConnection()) {
            c.start();
            ConnectionMetaData md = c.getMetaData();
            p("JMS %s, провайдер %s %s, сценарий %s", md.getJMSVersion(), md.getJMSProviderName(), md.getProviderVersion(), sc);
            switch (sc) {
                case "defaults" -> defaults(c);
                case "txreply" -> txReply(c);
                case "durable" -> durable();
                case "redelivery" -> redelivery(c);
                case "expiration" -> expiration(c);
                case "object" -> object(c);
                case "selector" -> selector(c);
                default -> throw new IllegalArgumentException(sc);
            }
        }
    }

    static void defaults(Connection c) throws Exception {
        Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
        MessageProducer pr = s.createProducer(s.createQueue("lab.defaults"));
        p("MessageProducer: deliveryMode=%d (PERSISTENT=%d), priority=%d, timeToLive=%d, deliveryDelay=%d",
                pr.getDeliveryMode(), DeliveryMode.PERSISTENT, pr.getPriority(), pr.getTimeToLive(), pr.getDeliveryDelay());
        try (JMSContext ctx = cf().createContext()) {
            JMSProducer jp = ctx.createProducer();
            p("JMSContext: sessionMode=%d (AUTO_ACKNOWLEDGE=%d), JMSProducer.deliveryMode=%d", ctx.getSessionMode(), JMSContext.AUTO_ACKNOWLEDGE, jp.getDeliveryMode());
        }
    }

    // EIP, Transactional Client: запрос и ожидание ответа в одной транзакции
    static void txReply(Connection c) throws Exception {
        Session rs = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue req = rs.createQueue("lab.limits.request"), rep = rs.createQueue("lab.limits.reply");
        drain(rs, req); drain(rs, rep);
        MessageProducer repPr = rs.createProducer(rep);
        rs.createConsumer(req).setMessageListener(m -> {
            try {
                p("  сервис лимитов получил запрос %s", ((TextMessage) m).getText());
                repPr.send(rs.createTextMessage("лимит одобрен"));
            } catch (JMSException e) { throw new RuntimeException(e); }
        });
        Session tx = c.createSession(true, Session.SESSION_TRANSACTED);
        tx.createProducer(req).send(tx.createTextMessage("лимит для карты 4276…"));
        long st = System.currentTimeMillis();
        MessageConsumer replies = tx.createConsumer(rep);
        Message reply = replies.receive(3000);
        p("ожидание ответа внутри той же транзакции: ответ=%s через %d мс", reply == null ? null : ((TextMessage) reply).getText(), System.currentTimeMillis() - st);
        tx.commit();
        st = System.currentTimeMillis();
        reply = replies.receive(3000);
        p("после commit: ответ=%s через %d мс", reply == null ? null : ((TextMessage) reply).getText(), System.currentTimeMillis() - st);
        tx.commit();
    }

    // Jakarta Recipes 12-7: «одна подписка — один подписчик» и общие подписки JMS 2.0
    static void durable() throws Exception {
        try (Connection c = cf().createConnection()) {
            c.setClientID("audit-service");
            c.start();
            Session s1 = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic t = s1.createTopic("lab.payments.events");
            MessageConsumer first = s1.createDurableConsumer(t, "audit");
            try {
                c.createSession(false, Session.AUTO_ACKNOWLEDGE).createDurableConsumer(t, "audit");
                p("второй durable-потребитель той же подписки создан");
            } catch (JMSException e) {
                p("второй createDurableConsumer(\"audit\"): %s: %s", e.getClass().getSimpleName(), e.getMessage());
            }
            first.close();
            s1.unsubscribe("audit");
        }
        Map<String, AtomicInteger> got = new ConcurrentHashMap<>();
        List<Connection> conns = new ArrayList<>();
        for (String pod : List.of("антифрод-1", "антифрод-2")) {
            Connection c = cf().createConnection();
            conns.add(c);
            c.start();
            Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
            got.put(pod, new AtomicInteger());
            s.createSharedDurableConsumer(s.createTopic("lab.payments.events"), "antifraud").setMessageListener(m -> got.get(pod).incrementAndGet());
        }
        try (Connection c = cf().createConnection()) {
            Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
            MessageProducer pr = s.createProducer(s.createTopic("lab.payments.events"));
            for (int i = 0; i < 100; i++) pr.send(s.createTextMessage("платёж " + i));
        }
        Thread.sleep(1500);
        p("createSharedDurableConsumer(\"antifraud\") на двух соединениях: распределение %s", new TreeMap<>(got));
        for (Connection c : conns) c.close();
        try (Connection c = cf().createConnection()) {
            Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
            s.unsubscribe("antifraud");
        }
    }

    // Откат транзакции: JMSXDeliveryCount, JMSRedelivered, DLQ
    static void redelivery(Connection c) throws Exception {
        Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue q = s.createQueue("lab.jms.work"), dlq = s.createQueue("DLQ");
        drain(s, q); drain(s, dlq);
        s.createProducer(q).send(s.createTextMessage("{битый json"));
        Session tx = c.createSession(true, Session.SESSION_TRANSACTED);
        MessageConsumer mc = tx.createConsumer(q);
        int n = 0;
        Message m;
        while ((m = mc.receive(1000)) != null) {
            n++;
            p("  получение %d: JMSRedelivered=%s, JMSXDeliveryCount=%d", n, m.getJMSRedelivered(), m.getIntProperty("JMSXDeliveryCount"));
            tx.rollback();
        }
        Message dead = s.createConsumer(dlq).receive(2000);
        p("после %d откатов сообщение в DLQ: %s, _AMQ_ORIG_ADDRESS=%s", n, dead == null ? null : ((TextMessage) dead).getText(),
                dead == null ? null : dead.getStringProperty("_AMQ_ORIG_ADDRESS"));
    }

    // EIP, Message Expiration: setJMSExpiration перед send перезаписывается провайдером
    static void expiration(Connection c) throws Exception {
        Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue q = s.createQueue("lab.jms.quotes");
        drain(s, q);
        MessageProducer pr = s.createProducer(q);
        TextMessage m = s.createTextMessage("котировка USD/RUB");
        long wanted = System.currentTimeMillis() + 1000;
        m.setJMSExpiration(wanted);
        pr.send(m);
        p("setJMSExpiration(now+1000) и send без TTL: после send JMSExpiration=%d", m.getJMSExpiration());
        TextMessage m2 = s.createTextMessage("котировка EUR/RUB");
        pr.send(m2, DeliveryMode.NON_PERSISTENT, 4, 1000);
        p("send(..., timeToLive=1000): JMSExpiration - JMSTimestamp = %d мс", m2.getJMSExpiration() - m2.getJMSTimestamp());
        Thread.sleep(2000);
        MessageConsumer mc = s.createConsumer(q);
        List<String> got = new ArrayList<>();
        Message r;
        while ((r = mc.receive(500)) != null) got.add(((TextMessage) r).getText());
        p("через 2 с получено: %s", got);
        Message exp = s.createConsumer(s.createQueue("ExpiryQueue")).receive(1000);
        p("в ExpiryQueue: %s", exp == null ? null : ((TextMessage) exp).getText());
    }

    // ObjectMessage и Java-сериализация
    static void object(Connection c) throws Exception {
        Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue q = s.createQueue("lab.jms.object");
        drain(s, q);
        s.createProducer(q).send(s.createObjectMessage(new Payment("P-42", new BigDecimal("1500.00"))));
        ObjectMessage om = (ObjectMessage) s.createConsumer(q).receive(2000);
        try {
            p("ObjectMessage.getObject() без настроек: %s", om.getObject());
        } catch (JMSException e) {
            p("ObjectMessage.getObject(): %s: %s", e.getClass().getSimpleName(), e.getMessage());
        }
    }

    static void selector(Connection c) throws Exception {
        Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue q = s.createQueue("lab.jms.selector");
        drain(s, q);
        MessageProducer pr = s.createProducer(q);
        for (String cur : List.of("RUB", "USD", "RUB", "CNY")) {
            TextMessage m = s.createTextMessage("перевод в " + cur);
            m.setStringProperty("currency", cur);
            m.setLongProperty("amount", cur.equals("RUB") ? 1_000_000 : 5_000);
            pr.send(m);
        }
        MessageConsumer mc = s.createConsumer(q, "currency = 'RUB' AND amount > 600000");
        List<String> got = new ArrayList<>();
        Message r;
        while ((r = mc.receive(500)) != null) got.add(((TextMessage) r).getText());
        p("селектор currency = 'RUB' AND amount > 600000: %s", got);
        p("в очереди осталось для других: %d", Collections.list(s.createBrowser(q).getEnumeration()).size());
        drain(s, q);
    }

    static void drain(Session s, Queue q) throws JMSException {
        MessageConsumer mc = s.createConsumer(q);
        while (mc.receive(200) != null) { }
        mc.close();
    }
}
