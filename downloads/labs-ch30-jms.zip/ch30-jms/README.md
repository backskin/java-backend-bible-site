# JMS 3.1 на ActiveMQ Artemis: умолчания, селекторы, долговечные подписки, повторная доставка, срок жизни, ответ внутри транзакции

Стенд к главе 30, раздел о JMS. `JmsLab` (клиент `artemis-jakarta-client` 2.53.0 из Spring Boot 4.1.2) выполняет один сценарий за запуск: `defaults` (режим доставки, приоритет, TTL у `MessageProducer`), `selector`, `durable` (второй `createDurableConsumer` на той же подписке), `redelivery` (`JMSRedelivered`, `JMSXDeliveryCount`, DLQ после исчерпания попыток), `expiration` (`setJMSExpiration` без TTL ничего не дает), `object` (`ObjectMessage` и белый список классов), `txreply` (ожидание ответа внутри той же транзакции не приходит). Брокер - Artemis 2.44.0 в Docker с `broker.xml` образа. Выводы автора - `s30-jms-<сценарий>.txt`.

## Что нужно

- JDK 21, Maven, Docker, bash.

## Запуск

```bash
docker run -d --name a30 -p 61616:61616 -e ARTEMIS_USER=dev.team -e ARTEMIS_PASSWORD=devteam apache/activemq-artemis:latest
```

```bash
mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && bash run.sh txreply
```

В IDEA есть конфигурация `JmsLab` (сценарий - аргумент программы) и Shell-конфигурация `run`.

## Что должно получиться

`deliveryMode=2, priority=4, timeToLive=0`; второй долговечный подписчик получает `IllegalStateException: Cannot create a subscriber on the durable subscription`; ответ внутри той же транзакции - `null` через 3 с, потому что запрос еще не отправлен.
