#!/usr/bin/env bash
# Сценарий опыта: котировка в библиотечном кеше переживает перезапуск DevTools.
# Запуск из labs/boot-devtools: bash cce-run.sh "<заголовок>"
CP="target/classes;$(cat cp.txt)"
java -Dstdout.encoding=UTF-8 -cp "$CP" dev.team.dt.FeeApp > app.log 2>&1 &
for i in $(seq 1 60); do curl -s localhost:18095/fee > /dev/null && break; sleep 0.5; done
echo "== $1"
echo "   PUT:  $(curl -s localhost:18095/quote/put)"
echo "   GET до перезапуска:    $(curl -s localhost:18095/quote/get)"
javac -encoding UTF-8 -d target/classes -cp "$CP" src/main/java/dev/team/dt/FeeRule.java
before=$(grep -c "Restarting due to" app.log)
for i in $(seq 1 60); do [ "$(grep -c 'Restarting due to' app.log)" -gt "$before" ] && grep -q "Started FeeApp in" <(tail -n 3 app.log) && break; sleep 0.25; done
sleep 1
echo "   GET после перезапуска: $(curl -s localhost:18095/quote/get)"
echo "   журнал: $(grep -o 'Restarting due to.*' app.log | tail -1)"
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='java.exe'\" | Where-Object { \$_.CommandLine -match 'dev.team.dt.FeeApp' } | ForEach-Object { Stop-Process -Id \$_.ProcessId -Force }"
