# Spring Boot DevTools: перезапуск по изменению классов и объект из библиотечного кэша, переживший перезапуск

Стенд к главе 10, раздел о DevTools. Приложение `FeeApp` (калькулятор комиссий, Spring Boot 4.1.1) с `spring-boot-devtools` и библиотека `quote-cache` (отдельный модуль, попадает в базовый загрузчик DevTools). Сценарий `cce-run.sh`: положить котировку в кэш библиотеки, перекомпилировать `FeeRule`, дождаться перезапуска и прочитать котировку снова: объект из старого загрузчика классов остается в кэше, и при приведении типа получается `ClassCastException` с одинаковыми именами классов. Отдельно проверено, что `devtools` с `<optional>true</optional>` не попадает в `BOOT-INF/lib`. Вывод автора - `s10-devtools.txt`.

## Что нужно

- JDK 21, Maven, bash с `curl` (Git Bash на Windows; остановка процесса в скрипте через PowerShell).

## Запуск

```bash
mvn -q install -DskipTests -f quote-cache/pom.xml && mvn -q compile dependency:build-classpath -Dmdep.outputFile=cp.txt && bash cce-run.sh "котировка в кэше библиотеки"
```

Приложение слушает порт 18095. В IDEA есть конфигурация `FeeApp` и Shell-конфигурация `cce-run`.

## Что должно получиться

`GET до перезапуска` возвращает котировку, `GET после перезапуска` - ошибку приведения типа, в журнале строка `Restarting due to 1 class path change`.
