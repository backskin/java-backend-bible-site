package ru.tundra.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Кеш котировок на уровне библиотеки: живёт столько же, сколько загрузчик класса QuoteCache. */
public final class QuoteCache {
    private static final Map<String, Object> CACHE = new ConcurrentHashMap<>();

    private QuoteCache() { }

    public static void put(String key, Object value) { CACHE.put(key, value); }

    public static Object get(String key) { return CACHE.get(key); }

    public static String loader() { return QuoteCache.class.getClassLoader().getClass().getSimpleName(); }
}
