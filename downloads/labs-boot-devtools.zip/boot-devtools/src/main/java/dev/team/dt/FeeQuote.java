package dev.team.dt;

import java.math.BigDecimal;

/** Котировка комиссии, которую приложение кладёт в библиотечный кеш. */
public record FeeQuote(String currency, BigDecimal percent) { }
