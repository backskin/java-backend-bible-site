package dev.team.dt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** Калькулятор комиссии за перевод: правило комиссии меняется на лету, DevTools перезапускает контекст. */
@SpringBootApplication
public class FeeApp {
    public static void main(String[] args) { SpringApplication.run(FeeApp.class, args); }

    @RestController
    static class FeeController {
        private final Environment env;
        FeeController(Environment env) { this.env = env; }

        String devtoolsDefaults() {
            var ps = ((org.springframework.core.env.ConfigurableEnvironment) env).getPropertySources().get("devtools");
            return ps == null ? "нет" : ((java.util.Map<?, ?>) ps.getSource()).toString();
        }

        @GetMapping("/quote/put")
        String put() {
            ru.tundra.cache.QuoteCache.put("RUB", new FeeQuote("RUB", new java.math.BigDecimal("0.5")));
            return "положено; QuoteCache загружен " + ru.tundra.cache.QuoteCache.loader() + ", FeeQuote загружен " + FeeQuote.class.getClassLoader().getClass().getSimpleName();
        }

        @GetMapping("/quote/get")
        String get() {
            try {
                FeeQuote q = (FeeQuote) ru.tundra.cache.QuoteCache.get("RUB");
                return "прочитано: " + q;
            } catch (ClassCastException e) {
                return "ClassCastException: " + e.getMessage();
            }
        }

        @GetMapping("/fee")
        String fee() {
            return "rule=" + FeeRule.description()
                    + "; loader=" + FeeController.class.getClassLoader().getClass().getSimpleName()
                    + "; parent=" + FeeController.class.getClassLoader().getParent().getClass().getSimpleName()
                    + "; devtools=" + devtoolsDefaults();
        }
    }
}
