package dev.team.dt;

/** Правило комиссии; опыт пересобирает этот класс во время работы приложения. */
public class FeeRule {
    public static String description() { return "0.5% min 30 RUB"; }
}
