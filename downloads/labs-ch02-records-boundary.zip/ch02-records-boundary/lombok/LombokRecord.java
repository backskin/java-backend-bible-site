// Lombok @Builder и @With над записью (компилируется с lombok.jar как обработчиком аннотаций).
import java.math.BigDecimal;
import lombok.Builder;
import lombok.With;

public class LombokRecord {
    @Builder
    @With
    record Transfer(String from, String to, BigDecimal amount) {}

    public static void main(String[] args) {
        Transfer t = Transfer.builder().from("40817").to("40702").amount(new BigDecimal("150.00")).build();
        System.out.println(t);
        System.out.println(t.withAmount(new BigDecimal("99.00")));
    }
}
