#!/bin/sh
# Запуск опытов раздела 2.4 на JDK 21 и 25. Вывод: s2-<класс>.txt
# Использование: sh run.sh [Класс ...]
cd "$(dirname "$0")"
[ -f cp.txt ] || mvn -q dependency:build-classpath -Dmdep.outputFile=cp.txt
CP="target/classes;$(cat cp.txt)"
J21=~/.jdks/temurin-21.0.10/bin
J25=~/.jdks/jdk-25.0.5+8/bin
mkdir -p target/classes
$J21/javac -encoding UTF-8 --release 21 -cp "$(cat cp.txt)" -d target/classes src/main/java/dev/team/ch02/*.java || exit 1
for c in ${@:-JacksonRecords HibernateRecords MockSealed}; do
  out=s2-$(echo $c | sed 's/\([a-z]\)\([A-Z]\)/\1-\2/g' | tr 'A-Z' 'a-z').txt
  {
    echo "# Запуск $(date +%F): labs/ch02-records-boundary, класс dev.team.ch02.$c"
    for j in $J21 $J25; do
      echo "# ---- $($j/java -version 2>&1 | head -1)"
      $j/java -Dstdout.encoding=UTF-8 -Duser.language=en -cp "$CP" dev.team.ch02.$c 2>&1 | grep -v "^SLF4J\|^WARNING: A \|^WARNING: Please\|^WARNING: sun.misc\|^WARNING: Use --enable\|^WARNING: Restricted\|^WARNING: java.lang.System::load" | sed "s#$HOME#~#g"
    done
  } > $out
  echo "==> $out"; cat $out
done
