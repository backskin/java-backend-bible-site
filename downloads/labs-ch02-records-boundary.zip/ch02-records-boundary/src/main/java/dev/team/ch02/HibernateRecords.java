package dev.team.ch02;

import jakarta.persistence.*;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.math.BigDecimal;
import java.util.List;

/** Запись как встраиваемый тип, как сущность и как результат запроса в Hibernate. */
public class HibernateRecords {
    @Embeddable
    public record Money(BigDecimal amount, String currency) {}

    @Entity(name = "Payment")
    public static class Payment {
        @Id @GeneratedValue Long id;
        @Embedded Money sum;
        String merchant;
        public Payment() {}
        Payment(Money m, String merchant) { this.sum = m; this.merchant = merchant; }
    }

    public record MerchantTotal(String merchant, BigDecimal total) {}

    @Entity(name = "PayLimit")
    public record Limit(@Id Long id, BigDecimal maxAmount) {}

    static SessionFactory sf(Class<?>... cls) {
        Configuration c = new Configuration()
                .setProperty("hibernate.connection.url", "jdbc:h2:mem:t" + cls.length + ";DB_CLOSE_DELAY=-1")
                .setProperty("hibernate.hbm2ddl.auto", "create-drop")
                .setProperty("hibernate.show_sql", "false");
        for (Class<?> k : cls) c.addAnnotatedClass(k);
        return c.buildSessionFactory();
    }

    public static void main(String[] args) {
        System.out.println("java " + System.getProperty("java.version") + ", Hibernate " + org.hibernate.Version.getVersionString());
        try (var f = sf(Payment.class)) {
            Long id = f.fromTransaction(s -> {
                var p = new Payment(new Money(new BigDecimal("150.00"), "RUB"), "M-1");
                s.persist(p);
                s.persist(new Payment(new Money(new BigDecimal("50.00"), "RUB"), "M-1"));
                return p.id;
            });
            f.inTransaction(s -> System.out.println("@Embeddable record прочитан: " + s.find(Payment.class, id).sum));
            f.inTransaction(s -> {
                List<MerchantTotal> totals = s.createQuery(
                        "select new dev.team.ch02.HibernateRecords$MerchantTotal(p.merchant, sum(p.sum.amount)) from Payment p group by p.merchant",
                        MerchantTotal.class).getResultList();
                System.out.println("select new <record>: " + totals);
                List<MerchantTotal> byPosition = s.createQuery(
                        "select p.merchant, sum(p.sum.amount) from Payment p group by p.merchant", MerchantTotal.class).getResultList();
                System.out.println("запись по позициям без new: " + byPosition);
            });
        }
        System.out.println("-- @Entity над record");
        try (var f = sf(Limit.class)) {
            f.inTransaction(s -> { s.persist(new Limit(1L, new BigDecimal("100000"))); System.out.println("persist прошёл"); });
            f.inTransaction(s -> System.out.println("find: " + s.find(Limit.class, 1L)));
        } catch (Exception e) {
            Throwable t = e;
            while (t.getCause() != null) t = t.getCause();
            System.out.println("исключение: " + e.getClass().getName() + ": " + e.getMessage());
        }
    }
}
