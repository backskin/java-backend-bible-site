package dev.team.ch02;

import org.mockito.Mockito;

/** Можно ли подменить sealed-тип и запись заглушкой Mockito. */
public class MockSealed {
    public sealed interface LimitCheck permits Ok, Exceeded {}
    public record Ok() implements LimitCheck {}
    public record Exceeded(long limit) implements LimitCheck {}
    public interface OpenCheck {}

    public static void main(String[] args) {
        System.out.println("java " + System.getProperty("java.version"));
        try {
            Object m = Mockito.mock(OpenCheck.class);
            System.out.println("mock(обычный интерфейс): " + m.getClass().getSimpleName().replaceAll("\\$\\d+", ""));
        } catch (Exception e) {
            System.out.println("mock(обычный интерфейс): " + e.getClass().getSimpleName());
        }
        for (Class<?> c : new Class<?>[]{LimitCheck.class, Exceeded.class}) {
            try {
                Object m = Mockito.mock(c);
                System.out.println("mock(" + c.getSimpleName() + "): создан " + m.getClass().getName().replaceAll("\\$MockitoMock\\$\\w+", "\\$MockitoMock\\$..."));
            } catch (Exception e) {
                System.out.println("mock(" + c.getSimpleName() + "): " + e.getClass().getSimpleName() + ": "
                        + e.getMessage().lines().filter(l -> !l.isBlank()).limit(3).toList());
            }
        }
    }
}
