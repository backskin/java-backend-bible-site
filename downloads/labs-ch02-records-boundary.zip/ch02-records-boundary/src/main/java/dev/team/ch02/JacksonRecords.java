package dev.team.ch02;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.List;

/** Записи и Jackson 2 / Jackson 3: свойства, одна компонента, sealed-иерархия. */
public class JacksonRecords {
    public record Transfer(String from, String to, @JsonProperty("amt") BigDecimal amount) {}
    public record AccountNumber(String value) {}
    public record Holder(AccountNumber account) {}

    public sealed interface PaymentResult permits Approved, Declined {}
    public record Approved(String authCode) implements PaymentResult {}
    public record Declined(String reason) implements PaymentResult {}

    @JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
    @JsonSubTypes({
            @JsonSubTypes.Type(value = TypedApproved.class, name = "approved"),
            @JsonSubTypes.Type(value = TypedDeclined.class, name = "declined")
    })
    public sealed interface TypedResult permits TypedApproved, TypedDeclined {}
    public record TypedApproved(String authCode) implements TypedResult {}
    public record TypedDeclined(String reason) implements TypedResult {}

    public record Event(String id, java.util.Map<String, Object> payload) {}

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version"));
        jackson2();
        jackson3();
    }

    static void jackson2() throws Exception {
        var m = new com.fasterxml.jackson.databind.ObjectMapper();
        System.out.println("== Jackson 2 " + com.fasterxml.jackson.databind.cfg.PackageVersion.VERSION);
        String json = m.writeValueAsString(new Transfer("40817", "40702", new BigDecimal("150.00")));
        System.out.println("запись -> " + json);
        System.out.println("<- " + m.readValue(json, Transfer.class));
        String acc = m.writeValueAsString(new AccountNumber("40817810"));
        System.out.println("одна компонента -> " + acc + ", <- " + m.readValue(acc, AccountNumber.class));
        try {
            System.out.println("одна компонента из строки \"40817810\" <- " + m.readValue("\"40817810\"", AccountNumber.class));
        } catch (Exception e) {
            System.out.println("одна компонента из строки: " + e.getClass().getSimpleName());
        }
        String sealedJson = m.writeValueAsString(List.of(new Approved("A1")));
        System.out.println("sealed без @JsonTypeInfo -> " + sealedJson);
        try {
            m.readValue("{\"authCode\":\"A1\"}", PaymentResult.class);
        } catch (Exception e) {
            System.out.println("sealed без @JsonTypeInfo <- " + e.getClass().getSimpleName() + ": " + e.getMessage().lines().findFirst().orElse(""));
        }
        String typed = m.writeValueAsString(new TypedDeclined("51"));
        System.out.println("sealed с @JsonTypeInfo -> " + typed + ", <- " + m.readValue(typed, TypedResult.class));
        Event ev = m.readValue("{\"id\":\"E1\",\"payload\":{\"limit\":100}}", Event.class);
        ev.payload().put("limit", 1_000_000);
        System.out.println("payload записи после put: " + ev + ", класс " + ev.payload().getClass().getSimpleName());
    }

    static void jackson3() throws Exception {
        var m = tools.jackson.databind.json.JsonMapper.builder().build();
        System.out.println("== Jackson 3 " + tools.jackson.databind.cfg.PackageVersion.VERSION);
        String json = m.writeValueAsString(new Transfer("40817", "40702", new BigDecimal("150.00")));
        System.out.println("запись -> " + json + ", <- " + m.readValue(json, Transfer.class));
        String acc = m.writeValueAsString(new AccountNumber("40817810"));
        System.out.println("одна компонента -> " + acc + ", <- " + m.readValue(acc, AccountNumber.class));
        try {
            m.readValue("{\"authCode\":\"A1\"}", PaymentResult.class);
        } catch (Exception e) {
            System.out.println("sealed без @JsonTypeInfo <- " + e.getClass().getSimpleName() + ": " + e.getMessage().lines().findFirst().orElse(""));
        }
        String typed = m.writeValueAsString(new TypedApproved("A9"));
        System.out.println("sealed с @JsonTypeInfo -> " + typed + ", <- " + m.readValue(typed, TypedResult.class));
    }
}
