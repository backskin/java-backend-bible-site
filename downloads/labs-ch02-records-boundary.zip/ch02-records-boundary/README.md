# Записи на границе сервиса: Jackson 2 и 3, Hibernate, Mockito, Lombok

Стенд к главе 02, раздел 2.4. Три программы в `src/main/java/dev/team/ch02/`: `JacksonRecords` (запись в JSON и обратно в Jackson 2.22.3 и 3.1.7, включая `@JsonProperty` на компонентах), `HibernateRecords` (запись как встраиваемый тип и как результат запроса в Hibernate 7.4.13 с H2), `MockSealed` (Mockito 5.23 и sealed-интерфейсы, записи как значения). Отдельно `lombok/LombokRecord.java` - `@With` и `@Builder` на записи с Lombok 1.18.46. Выводы автора - в `s2-*.txt`.

## Что нужно

- Maven и Temurin JDK 21.0.10 и 25.0.5 в `~/.jdks` (пути `J21`, `J25` в `run.sh`).
- sh (Git Bash на Windows).

## Запуск

```bash
sh run.sh
```

Скрипт один раз собирает classpath зависимостей (`cp.txt`), компилирует классы на JDK 21 и запускает каждую программу на 21 и 25, складывая вывод в `s2-<класс>.txt`. Одну программу: `sh run.sh JacksonRecords`. Lombok-пример запускается вручную: `java -cp lombok.jar` с процессором аннотаций, как в заголовке `s2-lombok-record.txt`.

## Что должно получиться

Jackson 2 и 3 читают записи без модулей и настроек; Hibernate принимает запись как `@Embeddable`; Mockito на JDK 25 печатает предупреждение о самоприкреплении агента (ожидаемо, в главе это разобрано).
