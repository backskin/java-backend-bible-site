package dev.team.wallet

import org.springframework.beans.factory.annotation.Value
import org.springframework.jdbc.core.simple.JdbcClient
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

data class TransferCommand(val idempotencyKey: String, val from: Long, val to: Long, val amountKop: Long)

data class TransferResult(val transferId: Long, val replayed: Boolean)

class InsufficientFundsException(account: Long) : RuntimeException("недостаточно средств на счёте $account")

class IdempotencyConflictException(key: String) :
    RuntimeException("ключ $key уже использован для перевода с другими параметрами")

// open: плагина allopen в сборке нет, а @Transactional работает через CGLIB-подкласс.
// lockMode: NO KEY UPDATE совместим с блокировкой FOR KEY SHARE, которую ставит проверка внешнего ключа
// при вставке в transfer; UPDATE с ней несовместим и даёт взаимоблокировку (опыт ForUpdateDeadlockTest)
@Service
open class TransferService(
    private val jdbc: JdbcClient,
    @param:Value("\${wallet.lock-mode:NO KEY UPDATE}") private val lockMode: String,
) {

    @Transactional
    open fun transfer(cmd: TransferCommand): TransferResult {
        require(cmd.amountKop > 0) { "сумма должна быть положительной" }
        require(cmd.from != cmd.to) { "перевод самому себе" }

        // 1. Застолбить ключ. Повтор с тем же ключом ждёт здесь, пока первая транзакция не завершится
        val newId = jdbc.sql(
            """
            INSERT INTO transfer (idempotency_key, from_account, to_account, amount_kop)
            VALUES (:key, :from, :to, :amount)
            ON CONFLICT (idempotency_key) DO NOTHING
            RETURNING id
            """.trimIndent()
        )
            .param("key", cmd.idempotencyKey).param("from", cmd.from)
            .param("to", cmd.to).param("amount", cmd.amountKop)
            .query(Long::class.java).optional()

        if (newId.isEmpty) return replay(cmd)

        // 2. Заблокировать оба счёта в порядке id: встречные переводы не запирают друг друга
        val balances = jdbc.sql(
            "SELECT id, balance_kop FROM account WHERE id IN (:a, :b) ORDER BY id FOR $lockMode"
        )
            .param("a", cmd.from).param("b", cmd.to)
            .query { rs, _ -> rs.getLong("id") to rs.getLong("balance_kop") }
            .list().toMap()
        require(balances.size == 2) { "счёт не найден" }

        // 3. Проверить остаток под блокировкой и провести две проводки
        if (balances.getValue(cmd.from) < cmd.amountKop) throw InsufficientFundsException(cmd.from)
        move(cmd.from, -cmd.amountKop, newId.get())
        move(cmd.to, cmd.amountKop, newId.get())
        return TransferResult(newId.get(), replayed = false)
    }

    private fun move(account: Long, delta: Long, transferId: Long) {
        jdbc.sql("UPDATE account SET balance_kop = balance_kop + :d WHERE id = :id")
            .param("d", delta).param("id", account).update()
        jdbc.sql("INSERT INTO posting (transfer_id, account_id, amount_kop) VALUES (:t, :a, :d)")
            .param("t", transferId).param("a", account).param("d", delta).update()
    }

    private fun replay(cmd: TransferCommand): TransferResult {
        val existing = jdbc.sql(
            "SELECT id, from_account, to_account, amount_kop FROM transfer WHERE idempotency_key = :key"
        )
            .param("key", cmd.idempotencyKey)
            .query { rs, _ ->
                TransferCommand(cmd.idempotencyKey, rs.getLong("from_account"), rs.getLong("to_account"),
                    rs.getLong("amount_kop")) to rs.getLong("id")
            }
            .single()
        if (existing.first != cmd) throw IdempotencyConflictException(cmd.idempotencyKey)
        return TransferResult(existing.second, replayed = true)
    }
}
