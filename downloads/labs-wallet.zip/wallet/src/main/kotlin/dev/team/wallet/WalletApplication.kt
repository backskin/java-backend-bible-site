package dev.team.wallet

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

// proxyBeanMethods = false: класс не нужно делать open, CGLIB-подкласс конфигурации не строится
@SpringBootApplication(proxyBeanMethods = false)
class WalletApplication

fun main(args: Array<String>) {
    runApplication<WalletApplication>(*args)
}
