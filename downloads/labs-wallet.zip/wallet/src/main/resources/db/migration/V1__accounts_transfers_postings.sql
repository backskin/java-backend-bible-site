-- Счета: остаток хранится в копейках, отрицательным быть не может
CREATE TABLE account (
    id          bigint PRIMARY KEY,
    currency    char(3)   NOT NULL,
    balance_kop bigint    NOT NULL CHECK (balance_kop >= 0),
    created_at  timestamptz NOT NULL DEFAULT now()
);

-- Перевод: ключ идемпотентности уникален, повтор запроса находит уже созданный перевод
CREATE TABLE transfer (
    id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idempotency_key text     NOT NULL UNIQUE,
    from_account    bigint   NOT NULL REFERENCES account (id),
    to_account      bigint   NOT NULL REFERENCES account (id),
    amount_kop      bigint   NOT NULL CHECK (amount_kop > 0),
    created_at      timestamptz NOT NULL DEFAULT now(),
    CHECK (from_account <> to_account)
);

-- Проводки: каждая операция порождает две строки с суммой ноль (двойная запись)
CREATE TABLE posting (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    transfer_id bigint NOT NULL REFERENCES transfer (id),
    account_id  bigint NOT NULL REFERENCES account (id),
    amount_kop  bigint NOT NULL CHECK (amount_kop <> 0),
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX posting_account_idx ON posting (account_id, id);
