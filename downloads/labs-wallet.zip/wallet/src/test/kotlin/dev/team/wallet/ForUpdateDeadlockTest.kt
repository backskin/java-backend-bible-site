package dev.team.wallet

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.testcontainers.service.connection.ServiceConnection
import org.springframework.dao.PessimisticLockingFailureException
import org.springframework.jdbc.core.simple.JdbcClient
import org.testcontainers.junit.jupiter.Container
import org.testcontainers.junit.jupiter.Testcontainers
import org.testcontainers.postgresql.PostgreSQLContainer
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Опыт: те же встречные переводы, но счета блокируются FOR UPDATE.
 * Вставка в transfer уже взяла FOR KEY SHARE на оба счёта (проверка внешних ключей),
 * и FOR UPDATE несовместим с чужим KEY SHARE: транзакции ждут друг друга, хотя порядок захвата один.
 */
@SpringBootTest(properties = ["wallet.lock-mode=UPDATE", "spring.datasource.hikari.maximum-pool-size=8"])
@Testcontainers
class ForUpdateDeadlockTest {

    companion object {
        @Container
        @ServiceConnection
        @JvmField
        val postgres = PostgreSQLContainer("postgres:17-alpine")
    }

    @Autowired lateinit var service: TransferService
    @Autowired lateinit var jdbc: JdbcClient

    @Test
    fun `FOR UPDATE после вставки с внешними ключами даёт взаимоблокировки`() {
        jdbc.sql("TRUNCATE posting, transfer, account").update()
        jdbc.sql("INSERT INTO account (id, currency, balance_kop) VALUES (1, 'RUB', 100000), (2, 'RUB', 100000)").update()
        val deadlocks = AtomicInteger()
        val ok = AtomicInteger()
        val pool = Executors.newFixedThreadPool(8)
        val tasks = (1..100).map { i ->
            Callable {
                try {
                    if (i % 2 == 0) service.transfer(TransferCommand("ab-$i", 1, 2, 1))
                    else service.transfer(TransferCommand("ba-$i", 2, 1, 1))
                    ok.incrementAndGet()
                } catch (e: PessimisticLockingFailureException) {
                    deadlocks.incrementAndGet()
                }
            }
        }
        val started = System.nanoTime()
        pool.invokeAll(tasks).forEach { it.get(120, TimeUnit.SECONDS) }
        pool.shutdown()
        val ms = (System.nanoTime() - started) / 1_000_000
        println("FOR UPDATE: 100 встречных переводов, успешно ${ok.get()}, взаимоблокировок ${deadlocks.get()}, $ms мс")
        val b1 = jdbc.sql("SELECT balance_kop FROM account WHERE id = 1").query(Long::class.java).single()
        val b2 = jdbc.sql("SELECT balance_kop FROM account WHERE id = 2").query(Long::class.java).single()
        assertEquals(200_000, b1 + b2)                  // откаченные переводы деньги не теряют
        assertTrue(deadlocks.get() > 0)
    }
}
