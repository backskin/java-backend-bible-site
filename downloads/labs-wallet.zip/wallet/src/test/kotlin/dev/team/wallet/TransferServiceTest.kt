package dev.team.wallet

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.testcontainers.service.connection.ServiceConnection
import org.springframework.jdbc.core.simple.JdbcClient
import org.testcontainers.junit.jupiter.Container
import org.testcontainers.junit.jupiter.Testcontainers
import org.testcontainers.postgresql.PostgreSQLContainer
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

@SpringBootTest
@Testcontainers
class TransferServiceTest {

    companion object {
        @Container
        @ServiceConnection
        @JvmField
        val postgres = PostgreSQLContainer("postgres:17-alpine")
    }

    @Autowired lateinit var service: TransferService
    @Autowired lateinit var jdbc: JdbcClient

    @BeforeEach
    fun clean() {
        jdbc.sql("TRUNCATE posting, transfer, account").update()
        jdbc.sql("INSERT INTO account (id, currency, balance_kop) VALUES (1, 'RUB', 100000), (2, 'RUB', 100000)").update()
    }

    private fun balance(id: Long) =
        jdbc.sql("SELECT balance_kop FROM account WHERE id = :id").param("id", id).query(Long::class.java).single()

    private fun count(table: String) =
        jdbc.sql("SELECT count(*) FROM $table").query(Long::class.java).single()

    @Test
    fun `перевод меняет оба остатка и пишет две проводки с нулевой суммой`() {
        val r = service.transfer(TransferCommand("k-1", 1, 2, 25_000))
        assertFalse(r.replayed)
        assertEquals(75_000, balance(1))
        assertEquals(125_000, balance(2))
        assertEquals(2, count("posting"))
        assertEquals(0, jdbc.sql("SELECT sum(amount_kop) FROM posting").query(Long::class.java).single())
    }

    @Test
    fun `повтор с тем же ключом не списывает второй раз`() {
        val first = service.transfer(TransferCommand("k-2", 1, 2, 10_000))
        val second = service.transfer(TransferCommand("k-2", 1, 2, 10_000))
        assertTrue(second.replayed)
        assertEquals(first.transferId, second.transferId)
        assertEquals(90_000, balance(1))
        assertEquals(1, count("transfer"))
    }

    @Test
    fun `тот же ключ с другой суммой — конфликт`() {
        service.transfer(TransferCommand("k-3", 1, 2, 10_000))
        assertThrows<IdempotencyConflictException> { service.transfer(TransferCommand("k-3", 1, 2, 99_000)) }
        assertEquals(90_000, balance(1))
    }

    @Test
    fun `нехватка средств откатывает и перевод, и ключ`() {
        assertThrows<InsufficientFundsException> { service.transfer(TransferCommand("k-4", 1, 2, 500_000)) }
        assertEquals(100_000, balance(1))
        assertEquals(0, count("transfer"))
        // ключ свободен: исправленный запрос с тем же ключом проходит
        service.transfer(TransferCommand("k-4", 1, 2, 50_000))
        assertEquals(50_000, balance(1))
    }

    @Test
    fun `встречные переводы под нагрузкой не запирают друг друга и не теряют деньги`() {
        val pool = Executors.newFixedThreadPool(8)
        val tasks = (1..400).map { i ->
            Callable {
                if (i % 2 == 0) service.transfer(TransferCommand("ab-$i", 1, 2, 1))
                else service.transfer(TransferCommand("ba-$i", 2, 1, 1))
            }
        }
        val started = System.nanoTime()
        pool.invokeAll(tasks).forEach { it.get(30, TimeUnit.SECONDS) }
        pool.shutdown()
        val ms = (System.nanoTime() - started) / 1_000_000
        println("400 встречных переводов в 8 потоков: $ms мс")
        assertEquals(200_000, balance(1) + balance(2))
        assertEquals(100_000, balance(1))
        assertEquals(800, count("posting"))
    }

    @Test
    fun `пятьдесят одновременных запросов с одним ключом дают один перевод`() {
        val pool = Executors.newFixedThreadPool(16)
        val results = pool.invokeAll((1..50).map { Callable { service.transfer(TransferCommand("same", 1, 2, 7_000)) } })
            .map { it.get(30, TimeUnit.SECONDS) }
        pool.shutdown()
        println("одновременных запросов: 50, новых переводов: ${results.count { !it.replayed }}, повторов: ${results.count { it.replayed }}")
        assertEquals(1, results.count { !it.replayed })
        assertEquals(1, results.map { it.transferId }.toSet().size)
        assertEquals(93_000, balance(1))
    }
}
