# Кошелек: счета, проводки и идемпотентный перевод на Kotlin, Spring Boot 4.1 и PostgreSQL 17 с тестами в Testcontainers

Стенд к главам 18 и 84 (первая лабораторная практикума). Проект на Kotlin 2.3.21 и Spring Boot 4.1.1 с `JdbcClient` и Flyway: схема счетов, проводок и переводов, перевод с ключом идемпотентности и блокировкой обоих счетов `SELECT ... ORDER BY id FOR UPDATE`, тесты `TransferServiceTest` и `ForUpdateDeadlockTest`, среди них нагрузочные (встречные переводы в восемь потоков). Тесты поднимают PostgreSQL 17 в Testcontainers. Запуск, на котором глава 18 показывает ловушку: вставка в `transfer` с внешними ключами ставит `FOR KEY SHARE` на счета до `FOR UPDATE`, и встречные переводы попадают в `deadlock detected`.

## Что нужно

- JDK 21, Maven, Docker (образ `postgres:17-alpine`).

## Запуск

```bash
mvn -q test
```

В IDEA есть конфигурации `WalletApplicationKt` (нужен внешний PostgreSQL с настройками из `application.properties`) и `mvn test`.

## Что должно получиться

Тесты проходят; `ForUpdateDeadlockTest` воспроизводит ловушку из главы 18: в варианте "вставка до блокировки" из 100 встречных переводов проходят 2, остальные 98 завершаются `deadlock detected`, и прогон занимает около 98 с из-за `deadlock_timeout`.
