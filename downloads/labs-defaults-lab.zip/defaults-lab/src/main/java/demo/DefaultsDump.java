package demo;

import com.zaxxer.hikari.HikariConfig;
import io.github.resilience4j.bulkhead.BulkheadConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.ratelimiter.RateLimiterConfig;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.timelimiter.TimeLimiterConfig;
import java.net.http.HttpClient;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.springframework.boot.autoconfigure.task.TaskExecutionProperties;
import org.springframework.boot.autoconfigure.task.TaskSchedulingProperties;
import org.springframework.boot.tomcat.autoconfigure.TomcatServerProperties;
import org.springframework.boot.web.server.autoconfigure.ServerProperties;

/** Значения по умолчанию библиотек: пишутся прямо из классов настроек, без запуска приложения. */
public class DefaultsDump {
    public static void main(String[] a) {
        System.out.println("-- Tomcat (Spring Boot ServerProperties)");
        ServerProperties sp = new ServerProperties();
        var t = new TomcatServerProperties();
        System.out.println("  server.tomcat.threads.max = " + t.getThreads().getMax() + ", threads.min-spare = " + t.getThreads().getMinSpare());
        System.out.println("  server.tomcat.accept-count = " + t.getAcceptCount() + ", max-connections = " + t.getMaxConnections());
        System.out.println("  server.tomcat.connection-timeout = " + t.getConnectionTimeout() + ", keep-alive-timeout = " + t.getKeepAliveTimeout() + ", max-keep-alive-requests = " + t.getMaxKeepAliveRequests());
        System.out.println("  server.tomcat.max-http-form-post-size = " + t.getMaxHttpFormPostSize() + ", max-swallow-size = " + t.getMaxSwallowSize());
        System.out.println("  server.shutdown = " + sp.getShutdown() + ", server.port = " + sp.getPort());
        System.out.println("-- HikariCP (HikariConfig)");
        HikariConfig h = new HikariConfig();
        System.out.println("  maximumPoolSize = " + h.getMaximumPoolSize() + ", minimumIdle = " + h.getMinimumIdle() + " (отрицательное значение означает «равно maximumPoolSize»)");
        System.out.println("  connectionTimeout = " + h.getConnectionTimeout() + " мс, validationTimeout = " + h.getValidationTimeout() + " мс");
        System.out.println("  idleTimeout = " + h.getIdleTimeout() + " мс, maxLifetime = " + h.getMaxLifetime() + " мс, keepaliveTime = " + h.getKeepaliveTime() + " мс");
        System.out.println("  leakDetectionThreshold = " + h.getLeakDetectionThreshold() + " мс (0 — выключено), autoCommit = " + h.isAutoCommit());
        System.out.println("-- пулы потоков Spring Boot");
        var ex = new TaskExecutionProperties().getPool();
        System.out.println("  spring.task.execution.pool: core-size = " + ex.getCoreSize() + ", max-size = " + ex.getMaxSize() + ", queue-capacity = " + ex.getQueueCapacity() + ", keep-alive = " + ex.getKeepAlive());
        System.out.println("  spring.task.scheduling.pool.size = " + new TaskSchedulingProperties().getPool().getSize());
        System.out.println("-- Resilience4j (ofDefaults)");
        var cb = CircuitBreakerConfig.ofDefaults();
        System.out.println("  CircuitBreaker: failureRateThreshold = " + cb.getFailureRateThreshold() + ", slidingWindowSize = " + cb.getSlidingWindowSize() + ", minimumNumberOfCalls = " + cb.getMinimumNumberOfCalls()
                + ", slowCallDurationThreshold = " + cb.getSlowCallDurationThreshold() + ", permittedNumberOfCallsInHalfOpenState = " + cb.getPermittedNumberOfCallsInHalfOpenState());
        System.out.println("  CircuitBreaker: waitIntervalFunctionInOpenState(1) = " + cb.getWaitIntervalFunctionInOpenState().apply(1) + " мс");
        var rt = RetryConfig.ofDefaults();
        System.out.println("  Retry: maxAttempts = " + rt.getMaxAttempts() + ", waitDuration(1) = " + rt.getIntervalBiFunction().apply(1, null) + " мс");
        var rl = RateLimiterConfig.ofDefaults();
        System.out.println("  RateLimiter: limitForPeriod = " + rl.getLimitForPeriod() + ", limitRefreshPeriod = " + rl.getLimitRefreshPeriod() + ", timeoutDuration = " + rl.getTimeoutDuration());
        var bh = BulkheadConfig.ofDefaults();
        System.out.println("  Bulkhead: maxConcurrentCalls = " + bh.getMaxConcurrentCalls() + ", maxWaitDuration = " + bh.getMaxWaitDuration());
        System.out.println("  TimeLimiter: timeoutDuration = " + TimeLimiterConfig.ofDefaults().getTimeoutDuration());
        System.out.println("-- HTTP-клиенты");
        System.out.println("  JDK HttpClient: connectTimeout = " + HttpClient.newHttpClient().connectTimeout() + " (пусто — без ограничения), HttpRequest timeout по умолчанию не задан");
        System.out.println("  Apache HC5 RequestConfig.DEFAULT: " + RequestConfig.DEFAULT);
        System.out.println("  Apache HC5 ConnectionConfig.DEFAULT: " + ConnectionConfig.DEFAULT);
    }
}
