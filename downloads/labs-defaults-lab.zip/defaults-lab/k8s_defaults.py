"""Что API-сервер Kubernetes подставляет в под сам: читаем получившийся объект и сравниваем с манифестом."""
import json
import os
import subprocess

env = dict(os.environ, KUBECONFIG=r"C:\Users\backskin\java-backend-bible\tmp\kind-bin\kubeconfig", MSYS_NO_PATHCONV="1")


def k(*a):
    return subprocess.run(["kubectl", *a], capture_output=True, text=True, env=env).stdout


d = json.loads(k("-n", "ai", "get", "pod", "defpod", "-o", "json"))
s = d["spec"]
c = s["containers"][0]
print("$ kubectl get pod defpod -o json   (поля, которых не было в манифесте и которые подставил API-сервер)")
print("  restartPolicy =", s["restartPolicy"])
print("  terminationGracePeriodSeconds =", s["terminationGracePeriodSeconds"])
print("  dnsPolicy =", s["dnsPolicy"], "; schedulerName =", s["schedulerName"], "; serviceAccountName =", s.get("serviceAccountName"))
print("  imagePullPolicy =", c["imagePullPolicy"], "(образ с тегом nginx:1.27-alpine)")
print("  resources =", c["resources"], "; qosClass =", d["status"]["qosClass"])
for n in ("livenessProbe", "readinessProbe"):
    p = c[n]
    print(" ", n, {kk: v for kk, v in p.items() if kk != "httpGet"})
print("  tolerations (добавлены автоматически):", [(t["key"], t.get("effect"), t.get("tolerationSeconds")) for t in s.get("tolerations", [])])
for path in ("pod.spec.containers.livenessProbe.periodSeconds", "pod.spec.containers.livenessProbe.failureThreshold", "pod.spec.terminationGracePeriodSeconds", "pod.spec.containers.imagePullPolicy"):
    out = k("explain", path).strip().splitlines()
    text = " ".join(x.strip() for x in out[4:12] if x.strip())
    print(f"$ kubectl explain {path}\n   {text[:420]}")
