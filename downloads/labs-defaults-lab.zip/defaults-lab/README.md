# defaults-lab: значения по умолчанию и как их посмотреть

- `src/`, `pom.xml` - минимальное приложение Spring Boot с actuator; `actuator_probe.py` опрашивает `/actuator/env` и `/actuator/configprops` и показывает значение и источник (гл. 10, Tomcat и Hikari).
- `defpod.yaml`, `k8s_defaults.py` - под без полей `restartPolicy`, `terminationGracePeriodSeconds` и порогов проб; скрипт читает объект обратно и печатает то, что подставил API-сервер (гл. 47, 6.14).
