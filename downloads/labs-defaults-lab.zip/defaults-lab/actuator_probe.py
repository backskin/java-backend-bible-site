"""Опрос actuator запущенного приложения: откуда взялось значение и какое значение действует. Запуск: python actuator_probe.py"""
import json
import urllib.error
import urllib.request

B = "http://localhost:18090/actuator/"


def get(path):
    try:
        with urllib.request.urlopen(B + path, timeout=10) as r:
            return r.status, json.load(r)
    except urllib.error.HTTPError as e:
        return e.code, None


def find(x, prefix):
    if isinstance(x, dict):
        if x.get("prefix") == prefix and "properties" in x:
            return x
        for v in x.values():
            r = find(v, prefix)
            if r:
                return r


print("$ GET /actuator/env/server.tomcat.threads.max   (значение задано в application.properties)")
st, d = get("env/server.tomcat.threads.max")
print("  HTTP", st, json.dumps(d["property"], ensure_ascii=False))
print("$ GET /actuator/env/server.tomcat.accept-count   (не задано нигде)")
st, d = get("env/server.tomcat.accept-count")
print("  HTTP", st, "(нет в Environment: значение подставляет класс настроек)")
print("$ GET /actuator/configprops/server.tomcat   (эффективные значения, включая умолчания класса настроек)")
st, d = get("configprops/server.tomcat")
b = find(d, "server.tomcat")
p = b["properties"]
for k in ("threads", "acceptCount", "maxConnections", "connectionTimeout", "keepAliveTimeout", "maxKeepAliveRequests"):
    print("  ", k, "=", json.dumps(p.get(k), ensure_ascii=False))
print("$ GET /actuator/configprops/spring.datasource.hikari   (значение и источник)")
st, d = get("configprops/spring.datasource.hikari")
b = find(d, "spring.datasource.hikari")
p = b["properties"]
for k in ("maximumPoolSize", "minimumIdle", "connectionTimeout", "idleTimeout", "maxLifetime", "keepaliveTime", "leakDetectionThreshold"):
    inp = b["inputs"].get(k) or {}
    print("  ", k, "=", p.get(k), "| источник:", inp.get("origin", "не задано, значение по умолчанию"))
st, d = get("env")
print("$ GET /actuator/env   (источники значений по порядку приоритета)")
print("  ", [s["name"] for s in d["propertySources"]])
