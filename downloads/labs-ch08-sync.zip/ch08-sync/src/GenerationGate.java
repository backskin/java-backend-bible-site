import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;

/**
 * Ворота с номером поколения: поток, вставший у закрытых ворот, проходит, если с момента его прихода
 * ворота хоть раз открывались, даже если их уже успели закрыть (как ThreadGate в JCIP, листинг 14.9).
 * state = (поколение << 1) | признак «открыто».
 */
public final class GenerationGate {

    private static final class Sync extends AbstractQueuedSynchronizer {
        Sync(boolean open) { setState(open ? 1 : 0); }

        int generation() { return getState() >>> 1; }

        @Override protected int tryAcquireShared(int seenGeneration) {
            int s = getState();
            return ((s & 1) == 1 || (s >>> 1) != seenGeneration) ? 1 : -1;
        }

        @Override protected boolean tryReleaseShared(int open) {
            for (;;) {
                int s = getState();
                int next = open == 1 ? (((s >>> 1) + 1) << 1) | 1 : s & ~1;   // открыть: новое поколение
                if (compareAndSetState(s, next)) return open == 1;
            }
        }
    }

    private final Sync sync;
    public GenerationGate(boolean open) { sync = new Sync(open); }
    public void open()  { sync.releaseShared(1); }
    public void close() { sync.releaseShared(0); }
    public void await() throws InterruptedException { sync.acquireSharedInterruptibly(sync.generation()); }
    public boolean await(long timeout, TimeUnit unit) throws InterruptedException {
        return sync.tryAcquireSharedNanos(sync.generation(), unit.toNanos(timeout));
    }
}
