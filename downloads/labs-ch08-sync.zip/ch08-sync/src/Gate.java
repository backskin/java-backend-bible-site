import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;

/** Ворота: пока закрыты — все ждут; открыли — проходят все и последующие. */
public final class Gate {

    private static final class Sync extends AbstractQueuedSynchronizer {
        private static final int CLOSED = 0, OPEN = 1;

        Sync(boolean open) { setState(open ? OPEN : CLOSED); }

        @Override protected int tryAcquireShared(int ignored) {
            return getState() == OPEN ? 1 : -1;      // >= 0 — проходим, < 0 — в очередь
        }

        @Override protected boolean tryReleaseShared(int newState) {
            setState(newState);                      // идемпотентно: пишем явное состояние
            return newState == OPEN;                 // true — разбудить очередь
        }

        boolean isOpen() { return getState() == OPEN; }
    }

    private final Sync sync;

    public Gate(boolean open) { this.sync = new Sync(open); }

    /** Открыть ворота и выпустить всех ожидающих. */
    public void open()  { sync.releaseShared(Sync.OPEN); }

    /** Закрыть ворота: новые вызовы await() будут блокироваться. */
    public void close() { sync.releaseShared(Sync.CLOSED); }

    /** Ждать открытия; прерываемо. */
    public void await() throws InterruptedException { sync.acquireSharedInterruptibly(1); }

    /** Ждать открытия с таймаутом; false — не дождались. */
    public boolean await(long timeout, TimeUnit unit) throws InterruptedException {
        return sync.tryAcquireSharedNanos(1, unit.toNanos(timeout));
    }

    public boolean isOpen() { return sync.isOpen(); }
}
