import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** 8 потоков ждут у закрытых ворот; open() и сразу close(). Сравнение Gate и GenerationGate. */
public class GateTest {
    interface G { void open(); void close(); boolean await(long ms) throws InterruptedException; }

    static int round(G g) throws Exception {
        AtomicInteger passed = new AtomicInteger();
        CountDownLatch ready = new CountDownLatch(8);
        Thread[] ts = new Thread[8];
        for (int i = 0; i < 8; i++) {
            ts[i] = new Thread(() -> { ready.countDown(); try { if (g.await(500)) passed.incrementAndGet(); } catch (InterruptedException ignored) { } });
            ts[i].start();
        }
        ready.await(); Thread.sleep(50);
        g.open(); g.close();
        for (Thread t : ts) t.join();
        return passed.get();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version"));
        StringBuilder a = new StringBuilder(), b = new StringBuilder();
        for (int r = 0; r < 10; r++) {
            Gate g1 = new Gate(false);
            a.append(round(new G() { public void open() { g1.open(); } public void close() { g1.close(); }
                public boolean await(long ms) throws InterruptedException { return g1.await(ms, TimeUnit.MILLISECONDS); } })).append(' ');
            GenerationGate g2 = new GenerationGate(false);
            b.append(round(new G() { public void open() { g2.open(); } public void close() { g2.close(); }
                public boolean await(long ms) throws InterruptedException { return g2.await(ms, TimeUnit.MILLISECONDS); } })).append(' ');
        }
        System.out.println("Gate (только признак открытия), прошло из 8 за 10 раундов: " + a);
        System.out.println("GenerationGate (номер поколения), прошло из 8 за 10 раундов: " + b);
    }
}
