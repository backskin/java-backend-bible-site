import java.lang.foreign.*;
import java.lang.invoke.MethodHandle;
import java.util.ArrayList;
import java.util.List;

/**
 * Why "same carrier before and after a native call" does not prove pinning, and a different carrier does not disprove it.
 * Ten virtual threads call kernel32 Sleep(200) through FFM. Variant A records the carrier with System.out.println
 * (a synchronized PrintStream: on JDK 24+ a virtual thread blocked on that monitor unmounts and may resume on another carrier);
 * variant B records the carrier into an array without any blocking. Then the pinning itself is measured directly:
 * with one carrier, N native calls of 200 ms take N x 200 ms if they pin.
 * Run: java --enable-native-access=ALL-UNNAMED PinCarrier.java   (JDK 21 and 25, Windows)
 */
public class PinCarrier {
    static MethodHandle sleep;

    static String carrier() {
        String s = Thread.currentThread().toString();   // VirtualThread[#n]/runnable@ForkJoinPool-1-worker-k
        return s.substring(s.indexOf('@') + 1);
    }

    static void nativeSleep(int ms) {
        try { sleep.invokeExact(ms); } catch (Throwable t) { throw new RuntimeException(t); }
    }

    public static void main(String[] args) throws Throwable {
        Linker linker = Linker.nativeLinker();
        SymbolLookup kernel32 = SymbolLookup.libraryLookup("kernel32", Arena.global());
        sleep = linker.downcallHandle(kernel32.find("Sleep").orElseThrow(), FunctionDescriptor.ofVoid(ValueLayout.JAVA_INT));
        System.out.println("java " + System.getProperty("java.version"));

        System.out.println("A. carrier printed with System.out.println before and after the native call (10 virtual threads):");
        List<Thread> a = new ArrayList<>();
        for (int i = 0; i < 10; i++) a.add(Thread.ofVirtual().unstarted(() -> {
            String before = carrier();
            System.out.println("  before: " + before);
            nativeSleep(200);
            String after = carrier();
            System.out.println("  after:  " + after + (after.equals(before) ? "" : "   <- changed"));
        }));
        a.forEach(Thread::start);
        for (Thread t : a) t.join();

        System.out.println("B. carrier recorded into an array, no println between the two readings:");
        String[][] rec = new String[10][2];
        List<Thread> b = new ArrayList<>();
        for (int i = 0; i < 10; i++) { int k = i; b.add(Thread.ofVirtual().unstarted(() -> {
            rec[k][0] = carrier();
            nativeSleep(200);
            rec[k][1] = carrier();
        })); }
        b.forEach(Thread::start);
        for (Thread t : b) t.join();
        int changed = 0;
        for (String[] r : rec) if (!r[0].equals(r[1])) changed++;
        System.out.println("  carriers changed in " + changed + " of 10 threads");

        System.out.println("C. direct measurement: 5 x Sleep(200) on one carrier (-Djdk.virtualThreadScheduler.parallelism=1 -Djdk.virtualThreadScheduler.maxPoolSize=1):");
        long t0 = System.nanoTime();
        List<Thread> c = new ArrayList<>();
        for (int i = 0; i < 5; i++) c.add(Thread.ofVirtual().start(() -> nativeSleep(200)));
        for (Thread t : c) t.join();
        System.out.println("  took " + (System.nanoTime() - t0) / 1_000_000 + " ms (1000 ms = pinned, 200 ms = not pinned)");
    }
}
