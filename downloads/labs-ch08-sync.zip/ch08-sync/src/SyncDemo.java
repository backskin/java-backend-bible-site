import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Синхронизаторы: ворота на AQS (открыть и сразу закрыть), лишний release() у семафора,
 * CountDownLatch(5) как ограничитель (неверно), сломанный CyclicBarrier.
 * Запуск: java Gate.java нельзя (два файла) — javac -d out src/*.java && java -cp out SyncDemo
 */
public class SyncDemo {

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version"));

        // 1. Ворота: 8 потоков ждут, open() и сразу close(). Сколько прошло?
        for (int round = 1; round <= 5; round++) {
            Gate gate = new Gate(false);
            AtomicInteger passed = new AtomicInteger();
            CountDownLatch waiting = new CountDownLatch(8);
            Thread[] ts = new Thread[8];
            for (int i = 0; i < 8; i++) {
                ts[i] = new Thread(() -> {
                    waiting.countDown();
                    try { if (gate.await(500, TimeUnit.MILLISECONDS)) passed.incrementAndGet(); }
                    catch (InterruptedException ignored) { }
                });
                ts[i].start();
            }
            waiting.await();
            Thread.sleep(50);                 // все встали в очередь AQS
            gate.open();
            gate.close();
            for (Thread t : ts) t.join();
            System.out.println("1. ворота open()+close(): прошло " + passed.get() + " из 8");
        }

        // 2. Семафор без владельца: лишний release() поднимает лимит.
        Semaphore s = new Semaphore(2);
        s.release();
        System.out.println("2. Semaphore(2) после лишнего release(): availablePermits=" + s.availablePermits());

        // 3. CountDownLatch(5) как ограничитель «не больше пяти»: await() перед задачей.
        CountDownLatch latch = new CountDownLatch(5);
        ExecutorService pool = Executors.newFixedThreadPool(10);
        AtomicInteger started = new AtomicInteger();
        for (int i = 0; i < 10; i++) pool.submit(() -> {
            try { if (latch.await(300, TimeUnit.MILLISECONDS)) started.incrementAndGet(); } catch (InterruptedException ignored) { }
            latch.countDown();
            return null;
        });
        pool.shutdown();
        pool.awaitTermination(5, TimeUnit.SECONDS);
        System.out.println("3. CountDownLatch(5) как ограничитель: за 300 мс начали работу " + started.get() + " задач из 10, count=" + latch.getCount());

        // 4. CyclicBarrier: один участник ушёл по таймауту — остальные получают BrokenBarrierException.
        CyclicBarrier barrier = new CyclicBarrier(3);
        ExecutorService p2 = Executors.newFixedThreadPool(2);
        Future<String> a = p2.submit(() -> { try { barrier.await(); return "ok"; } catch (Exception e) { return e.getClass().getSimpleName(); } });
        Future<String> b = p2.submit(() -> { try { barrier.await(100, TimeUnit.MILLISECONDS); return "ok"; } catch (Exception e) { return e.getClass().getSimpleName(); } });
        System.out.println("4. CyclicBarrier(3), пришли двое: первый " + a.get() + ", второй (таймаут 100 мс) " + b.get() + ", isBroken=" + barrier.isBroken());
        p2.shutdown();
    }
}
