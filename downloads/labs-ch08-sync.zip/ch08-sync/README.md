# Синхронизаторы: семафор без владельца, ворота на wait/notify и их ошибка, прикрепление к носителю

Стенд к главе 08, раздел 5. `SyncDemo` - простые ворота `open()`/`close()`, `Semaphore` (лишний `release()` поднимает лимит), `CountDownLatch` как ограничитель и `CyclicBarrier`, к которому пришли двое из трех; `GateTest` - ошибка ворот из "Java Concurrency на практике": восемь потоков у закрытых ворот, `open()` и сразу `close()`, через простые ворота (`Gate`) не проходит никто, через ворота с поколением (`GenerationGate`) проходят все; `PinCarrier` - прикрепление виртуального потока к носителю в `synchronized` на JDK 21 и 25. Выводы автора - `s05-sync.txt`, `s05-gate.txt`, `s05-pin-carrier.txt`.

## Что нужно

- JDK 21 и 25 (`PinCarrier` на 21 требует `--enable-preview`).

## Запуск

```bash
java -Dstdout.encoding=UTF-8 src/GateTest.java
```

В IDEA на каждую программу есть конфигурация `java src/<Класс>.java`.

## Что должно получиться

`Gate: прошло из 8 за 10 раундов: 0 0 0 0 0 0 0 0 0 0`, `GenerationGate: 8 8 8 …`; семафор на два разрешения после лишнего `release()` показывает `availablePermits=3`.
