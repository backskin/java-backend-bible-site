package saga;

import java.io.File;
import java.nio.file.*;
import java.util.*;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.runtime.Incident;

/** 5.11: сага перевода как BPMN-процесс Camunda 7 на H2. Сценарии: успех, отказ зачисления с компенсациями, нехватка средств, падение процесса (без защиты и с защитой от повтора), повторы и инцидент. */
public class SagaRun {
    static Path fresh(String name) throws Exception {
        Path d = Paths.get("target", "saga-" + name).toAbsolutePath();
        if (Files.exists(d)) try (var w = Files.walk(d)) { w.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete()); }
        Files.createDirectories(d);
        return d;
    }

    static void runChild(Path dir, String action, String mode, String... props) throws Exception {
        List<String> cmd = new ArrayList<>(List.of(System.getProperty("java.home") + File.separator + "bin" + File.separator + "java", "-Dstdout.encoding=UTF-8",
                "-Dorg.slf4j.simpleLogger.defaultLogLevel=error"));
        cmd.addAll(Arrays.asList(props));
        cmd.addAll(List.of("-cp", System.getProperty("java.class.path"), "saga.SagaChild", dir.toString(), action, mode));
        Process pr = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String out = new String(pr.getInputStream().readAllBytes());
        pr.waitFor();
        for (String line : out.split("\n")) if (line.startsWith("  [процесс]")) System.out.println(line);
        System.out.println("  код завершения процесса: " + pr.exitValue() + (pr.exitValue() == 137 ? " (аварийно)" : ""));
    }

    static void simple(String title, String from, String to, long amount) throws Exception {
        Path dir = fresh("simple");
        Ledger.init(dir.toString(), true);
        long before = Ledger.total();
        ProcessEngine engine = Engines.open(dir.toString());
        try {
            Engines.deploy(engine);
            String id = Engines.start(engine, from, to, amount, "idem");
            Engines.awaitDone(engine, 20_000);
            System.out.println("== " + title);
            System.out.println("  путь по процессу: " + Engines.path(engine, id));
            System.out.println("  учёт: " + Ledger.state());
            System.out.println("  сумма всех балансов: было " + before + ", стало " + Ledger.total());
        } finally {
            engine.close();
        }
    }

    public static void main(String[] a) throws Exception {
        simple("1. успешный перевод A -> B на 10000", "A", "B", 10_000);
        simple("2. получатель C закрыт: отказ зачисления, компенсации", "A", "C", 10_000);
        simple("3. на счёте A нет столько средств: отказ на первом шаге", "A", "B", 500_000);

        System.out.println("== 4. падение процесса после коммита зачисления в учёт и до коммита движка; зачисление без защиты от повтора");
        Path d4 = fresh("crash-plain");
        Ledger.init(d4.toString(), true);
        runChild(d4, "start", "plain", "-DcrashIn=credit-after-ledger");
        runChild(d4, "resume", "plain");
        System.out.println("  учёт: " + Ledger.state() + "   (ожидалось 1 зачисление на 10000)");

        System.out.println("== 5. то же падение, зачисление с уникальной операцией (идемпотентное)");
        Path d5 = fresh("crash-idem");
        Ledger.init(d5.toString(), true);
        runChild(d5, "start", "idem", "-DcrashIn=credit-after-ledger");
        runChild(d5, "resume", "idem");
        System.out.println("  учёт: " + Ledger.state() + "   (ожидалось 1 зачисление на 10000)");

        System.out.println("== 6. временные сбои зачисления: первые 2 попытки падают, R3/PT1S");
        Path d6 = fresh("retry2");
        Ledger.init(d6.toString(), true);
        System.setProperty("failCredit", "2");
        ProcessEngine e6 = Engines.open(d6.toString());
        try {
            Engines.deploy(e6);
            long t0 = System.currentTimeMillis();
            String id = Engines.start(e6, "A", "B", 10_000, "idem");
            boolean ok = Engines.awaitDone(e6, 30_000);
            System.out.println("  завершён: " + ok + ", время " + (System.currentTimeMillis() - t0) + " мс, путь: " + Engines.path(e6, id));
            System.out.println("  попыток зачисления до успеха: " + Ledger.attempts("credit"));
            System.out.println("  учёт: " + Ledger.state());
        } finally {
            e6.close();
        }

        System.out.println("== 7. стойкий сбой зачисления: 10 попыток падают, повторов три; инцидент и ручное исправление");
        Path d7 = fresh("incident");
        Ledger.init(d7.toString(), true);
        System.setProperty("failCredit", "10");
        ProcessEngine e7 = Engines.open(d7.toString());
        try {
            Engines.deploy(e7);
            String id = Engines.start(e7, "A", "B", 10_000, "idem");
            boolean ok = Engines.awaitDone(e7, 30_000);
            List<Incident> inc = e7.getRuntimeService().createIncidentQuery().list();
            System.out.println("  завершён сам: " + ok + ", инцидентов: " + inc.size() + (inc.isEmpty() ? "" : " (" + inc.get(0).getIncidentType() + ", шаг " + inc.get(0).getActivityId() + ")"));
            var job = e7.getManagementService().createJobQuery().processInstanceId(id).singleResult();
            System.out.println("  задание: повторов осталось " + (job == null ? "?" : job.getRetries()) + ", последняя ошибка: " + (job == null ? "?" : job.getExceptionMessage()));
            System.out.println("  учёт до исправления: " + Ledger.state());
            System.setProperty("failCredit", "0");                        // «исправили причину»
            e7.getManagementService().setJobRetries(job.getId(), 1);       // оператор возвращает задание в работу
            boolean ok2 = Engines.awaitDone(e7, 20_000);
            System.out.println("  после исправления: завершён " + ok2 + ", путь: " + Engines.path(e7, id));
            System.out.println("  учёт: " + Ledger.state());
        } finally {
            e7.close();
        }

        System.out.println("== 8. отказ зачисления (C закрыт) и падение самой компенсации refundDebit: все попытки падают");
        Path d8 = fresh("comp-fail");
        Ledger.init(d8.toString(), true);
        System.setProperty("failCredit", "0");
        System.setProperty("failRefund", "10");
        ProcessEngine e8 = Engines.open(d8.toString());
        try {
            Engines.deploy(e8);
            String id = Engines.start(e8, "A", "C", 10_000, "idem");
            boolean ok = Engines.awaitDone(e8, 30_000);
            List<Incident> inc = e8.getRuntimeService().createIncidentQuery().list();
            System.out.println("  завершён сам: " + ok + ", инцидентов: " + inc.size() + (inc.isEmpty() ? "" : " (" + inc.get(0).getIncidentType() + ", шаг " + inc.get(0).getActivityId() + ")"));
            var job = e8.getManagementService().createJobQuery().processInstanceId(id).singleResult();
            System.out.println("  задание: повторов осталось " + (job == null ? "?" : job.getRetries()) + ", последняя ошибка: " + (job == null ? "?" : job.getExceptionMessage()));
            System.out.println("  путь по истории: " + Engines.path(e8, id));
            System.out.println("  учёт при открытом инциденте: " + Ledger.state());
            System.setProperty("failRefund", "0");
            e8.getManagementService().setJobRetries(job.getId(), 1);
            boolean ok2 = Engines.awaitDone(e8, 20_000);
            System.out.println("  после исправления: завершён " + ok2 + ", путь: " + Engines.path(e8, id));
            System.out.println("  учёт: " + Ledger.state());
        } finally {
            e8.close();
        }

        System.out.println("== 9. то же падение, но учёт в той же базе и транзакции, что движок (SpringProcessEngineConfiguration, один DataSource)");
        Path d9 = fresh("crash-spring");
        Ledger.initShared(d9.toString(), true);
        runChild(d9, "start", "spring", "-DcrashIn=credit-after-ledger");
        runChild(d9, "resume", "spring");
        System.out.println("  учёт: " + Ledger.state() + "   (ожидалось 1 зачисление на 10000)");
    }
}
