package saga;

import java.sql.*;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

/**
 * Шаги саги перевода. Каждый шаг пишет в «внешнюю» базу учёта своим соединением и коммитит сам.
 * Переменные процесса: from, to, amount, mode («plain» — шаг зачисления без защиты от повтора, «idem» — с уникальным ключом операции).
 * Сбои для опытов задаются системными свойствами: crashIn=credit-after-ledger (процесс убивается после коммита учёта, до коммита движка),
 * failCredit=N (зачисление бросает исключение первые N попыток).
 */
public final class Steps {
    private Steps() {}

    static long amount(DelegateExecution e) {
        return ((Number) e.getVariable("amount")).longValue();
    }

    static String opId(DelegateExecution e) {
        return e.getProcessInstanceId() + ":" + e.getCurrentActivityId();
    }

    static void journal(Connection c, String op, String account, long delta, String kind) throws SQLException {
        try (PreparedStatement p = c.prepareStatement("insert into journal(op_id, account, delta, kind) values (?,?,?,?)")) {
            p.setString(1, op);
            p.setString(2, account);
            p.setLong(3, delta);
            p.setString(4, kind);
            p.executeUpdate();
        }
    }

    static void exec(String sql, Object... args) throws SQLException {
        try (Connection c = Ledger.open(); PreparedStatement p = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) p.setObject(i + 1, args[i]);
            p.executeUpdate();
        }
    }

    public static class Reserve implements JavaDelegate {
        public void execute(DelegateExecution e) throws Exception {
            long a = amount(e);
            try (Connection c = Ledger.open(); PreparedStatement p = c.prepareStatement("update accounts set reserved = reserved + ? where id = ? and balance - reserved >= ?")) {
                p.setLong(1, a);
                p.setString(2, (String) e.getVariable("from"));
                p.setLong(3, a);
                if (p.executeUpdate() == 0) throw new BpmnError("NO_FUNDS");
            }
        }
    }

    public static class ReleaseReserve implements JavaDelegate {
        public void execute(DelegateExecution e) throws Exception {
            exec("update accounts set reserved = reserved - ? where id = ?", amount(e), e.getVariable("from"));
        }
    }

    public static class Debit implements JavaDelegate {
        public void execute(DelegateExecution e) throws Exception {
            exec("update accounts set balance = balance - ?, reserved = reserved - ? where id = ?", amount(e), amount(e), e.getVariable("from"));
        }
    }

    public static class RefundDebit implements JavaDelegate {
        public void execute(DelegateExecution e) throws Exception {
            int attempt = Ledger.attempt("refundDebit");
            int failN = Integer.getInteger("failRefund", 0);
            if (failN > 0) System.out.println("    компенсация refundDebit, попытка " + attempt + " в " + java.time.LocalTime.now().toString().substring(0, 12));
            if (attempt <= failN) throw new IllegalStateException("сервис возврата недоступен, попытка " + attempt);
            exec("update accounts set balance = balance + ?, reserved = reserved + ? where id = ?", amount(e), amount(e), e.getVariable("from"));
        }
    }

    public static class Credit implements JavaDelegate {
        public void execute(DelegateExecution e) throws Exception {
            String to = (String) e.getVariable("to");
            int attempt = Ledger.attempt("credit");
            int failN = Integer.getInteger("failCredit", 0);
            if (failN > 0) System.out.println("    попытка " + attempt + " в " + java.time.LocalTime.now().toString().substring(0, 12));
            if (attempt <= failN) throw new IllegalStateException("временный сбой зачисления, попытка " + attempt);
            boolean idem = "idem".equals(e.getVariable("mode"));
            boolean spring = "spring".equals(e.getVariable("mode"));
            // режим spring: соединение из транзакции движка (DataSourceUtils), ни commit, ни close здесь не делаем
            Connection c = spring ? org.springframework.jdbc.datasource.DataSourceUtils.getConnection(Ledger.shared) : Ledger.open();
            try {
                if (!spring) c.setAutoCommit(false);
                try (PreparedStatement q = c.prepareStatement("select closed from accounts where id = ?")) {
                    q.setString(1, to);
                    ResultSet rs = q.executeQuery();
                    if (rs.next() && rs.getBoolean(1)) throw new BpmnError("CREDIT_REJECTED");
                }
                if (idem) {   // защита от повтора: операция уже учтена — второй раз не применяем
                    try (PreparedStatement q = c.prepareStatement("select count(*) from journal where op_id = ? and kind = 'CREDIT'")) {
                        q.setString(1, opId(e));
                        ResultSet rs = q.executeQuery();
                        rs.next();
                        if (rs.getInt(1) > 0) { if (!spring) c.commit(); return; }
                    }
                }
                try (PreparedStatement p = c.prepareStatement("update accounts set balance = balance + ? where id = ?")) {
                    p.setLong(1, amount(e));
                    p.setString(2, to);
                    p.executeUpdate();
                }
                journal(c, opId(e), to, amount(e), "CREDIT");
                if (!spring) c.commit();
            } finally {
                if (!spring) c.close();
            }
            if ("credit-after-ledger".equals(System.getProperty("crashIn")) && Ledger.attempt("crash-marker") == 1) {
                System.out.println(spring ? "  [процесс] падение: зачисление записано в общей транзакции, движок её не закоммитил"
                                          : "  [процесс] падение: зачисление закоммитировано в учёт, движок свою транзакцию не закоммитил");
                System.out.flush();
                Runtime.getRuntime().halt(137);
            }
        }
    }
}
