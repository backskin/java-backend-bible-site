package saga;

import java.sql.*;

/** «Внешняя» система учёта денег: отдельная база H2 (файл), собственные соединения и собственные коммиты, не связанные с транзакцией движка процессов. */
public final class Ledger {
    private static String url;
    /** Общий с движком DataSource (сценарий 9): шаги берут соединение из транзакции Spring. */
    public static javax.sql.DataSource shared;

    private Ledger() {}

    public static void init(String dir, boolean reset) throws SQLException {
        init(dir, reset, "ledger");
    }

    /** Таблицы учёта в той же базе, что и движок (сценарий 9). */
    public static void initShared(String dir, boolean reset) throws SQLException {
        init(dir, reset, "engine");
    }

    private static void init(String dir, boolean reset, String db) throws SQLException {
        url = "jdbc:h2:file:" + dir.replace('\\', '/') + "/" + db + ";DB_CLOSE_ON_EXIT=FALSE";
        try (Connection c = DriverManager.getConnection(url); Statement s = c.createStatement()) {
            if (reset && db.equals("ledger")) s.execute("drop all objects");
            s.execute("create table if not exists accounts(id varchar primary key, balance bigint not null, reserved bigint not null default 0, closed boolean not null default false)");
            s.execute("create table if not exists journal(seq bigint auto_increment primary key, op_id varchar not null, account varchar not null, delta bigint not null, kind varchar not null)");
            s.execute("create table if not exists attempts(step varchar primary key, n int not null)");
            if (reset) {
                s.execute("delete from journal"); s.execute("delete from attempts"); s.execute("delete from accounts");
                s.execute("insert into accounts(id, balance) values ('A', 100000), ('B', 50000)");
                s.execute("insert into accounts(id, balance, closed) values ('C', 0, true)");
            }
        }
    }

    public static Connection open() throws SQLException {
        return DriverManager.getConnection(url);
    }

    public static String state() throws SQLException {
        StringBuilder sb = new StringBuilder();
        try (Connection c = open(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery("select id, balance, reserved from accounts order by id")) {
            while (rs.next()) sb.append(rs.getString(1)).append(": баланс ").append(rs.getLong(2)).append(", резерв ").append(rs.getLong(3)).append("; ");
        }
        try (Connection c = open(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery("select count(*), coalesce(sum(delta),0) from journal where kind='CREDIT'")) {
            rs.next();
            sb.append("проводок зачисления ").append(rs.getInt(1)).append(" на сумму ").append(rs.getLong(2));
        }
        return sb.toString();
    }

    public static long total() throws SQLException {
        try (Connection c = open(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery("select sum(balance) from accounts")) {
            rs.next();
            return rs.getLong(1);
        }
    }

    /** Сколько попыток шага уже было (без изменения счётчика). */
    public static int attempts(String step) throws SQLException {
        try (Connection c = open(); PreparedStatement q = c.prepareStatement("select n from attempts where step=?")) {
            q.setString(1, step);
            ResultSet rs = q.executeQuery();
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    /** Сколько раз вызывалась попытка шага (для сценария с повторами). */
    public static int attempt(String step) throws SQLException {
        try (Connection c = open()) {
            try (PreparedStatement up = c.prepareStatement("merge into attempts(step, n) key(step) values (?, coalesce((select n from attempts where step=?), 0) + 1)")) {
                up.setString(1, step);
                up.setString(2, step);
                up.executeUpdate();
            }
            try (PreparedStatement q = c.prepareStatement("select n from attempts where step=?")) {
                q.setString(1, step);
                ResultSet rs = q.executeQuery();
                rs.next();
                return rs.getInt(1);
            }
        }
    }
}
