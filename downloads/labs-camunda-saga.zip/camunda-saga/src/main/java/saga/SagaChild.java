package saga;

import org.camunda.bpm.engine.ProcessEngine;

/** Дочерний процесс для опытов с падением: start — запускает перевод и ждёт (падает по свойству crashIn), resume — открывает ту же базу и дожидается завершения. */
public class SagaChild {
    public static void main(String[] a) throws Exception {
        String dir = a[0], action = a[1], mode = a.length > 2 ? a[2] : "plain";
        boolean spring = mode.equals("spring");
        if (spring) Ledger.initShared(dir, false); else Ledger.init(dir, false);
        ProcessEngine engine = spring ? Engines.openSpring(dir) : Engines.open(dir);
        try {
            if (action.equals("start")) {
                Engines.deploy(engine);
                String id = Engines.start(engine, "A", "B", 10_000, mode);
                System.out.println("  [процесс] перевод запущен, экземпляр " + (id.length() > 8 ? id.substring(0, 8) : id));
                Engines.awaitDone(engine, 20_000);
                System.out.println("  [процесс] завершён без падения");
            } else {
                boolean done = Engines.awaitDone(engine, 30_000);
                System.out.println("  [процесс] после перезапуска: активных экземпляров " + engine.getRuntimeService().createProcessInstanceQuery().count() + ", завершено " + done);
            }
        } finally {
            engine.close();
        }
    }
}
