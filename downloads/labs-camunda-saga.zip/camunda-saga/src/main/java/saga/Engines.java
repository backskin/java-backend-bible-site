package saga;

import java.util.*;
import java.util.stream.Collectors;
import org.camunda.bpm.engine.*;
import org.camunda.bpm.engine.history.HistoricActivityInstance;
import org.camunda.bpm.engine.impl.jobexecutor.JobExecutor;

/** Настройка движка Camunda 7 на файловой H2: база движка лежит в файле, поэтому состояние процесса переживает перезапуск JVM. */
public final class Engines {
    private Engines() {}

    public static ProcessEngine open(String dir) {
        var cfg = ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration()
                .setJdbcUrl("jdbc:h2:file:" + dir.replace('\\', '/') + "/engine;DB_CLOSE_ON_EXIT=FALSE")
                .setJdbcDriver("org.h2.Driver").setJdbcUsername("sa").setJdbcPassword("")
                .setDatabaseSchemaUpdate("true")
                .setHistory("full")
                .setJobExecutorActivate(true);
        var impl = (org.camunda.bpm.engine.impl.cfg.ProcessEngineConfigurationImpl) cfg;
        impl.setHistoryTimeToLive("P1D");          // Camunda 7.2x требует срок хранения истории (в модели или в конфигурации)
        ProcessEngine engine = cfg.buildProcessEngine();
        JobExecutor je = impl.getJobExecutor();
        je.setWaitTimeInMillis(200);
        je.setMaxWait(500);
        je.setLockTimeInMillis(4000);          // по умолчанию 5 минут: упавший исполнитель держал бы задание так долго
        return engine;
    }

    /** Движок на SpringProcessEngineConfiguration с одним DataSource и DataSourceTransactionManager: шаги могут работать в транзакции движка. */
    public static ProcessEngine openSpring(String dir) {
        var ds = new org.springframework.jdbc.datasource.SimpleDriverDataSource(new org.h2.Driver(),
                "jdbc:h2:file:" + dir.replace('\\', '/') + "/engine;DB_CLOSE_ON_EXIT=FALSE", "", "");   // учёт открывает ту же базу без имени пользователя
        var txDs = new org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy(ds);
        Ledger.shared = txDs;
        var cfg = new org.camunda.bpm.engine.spring.SpringProcessEngineConfiguration();
        var ctx = new org.springframework.context.support.GenericApplicationContext();
        ctx.refresh();
        cfg.setApplicationContext(ctx);   // конфигурация Spring-движка ждёт контекст, пусть и пустой
        cfg.setDataSource(txDs);
        cfg.setTransactionManager(new org.springframework.jdbc.datasource.DataSourceTransactionManager(ds));
        cfg.setDatabaseSchemaUpdate("true");
        cfg.setHistory("full");
        cfg.setJobExecutorActivate(true);
        cfg.setHistoryTimeToLive("P1D");
        ProcessEngine engine = cfg.buildProcessEngine();
        JobExecutor je = cfg.getJobExecutor();
        je.setWaitTimeInMillis(200);
        je.setMaxWait(500);
        je.setLockTimeInMillis(4000);
        return engine;
    }

    public static void deploy(ProcessEngine engine) {
        engine.getRepositoryService().createDeployment().name("transfer").enableDuplicateFiltering(true).addClasspathResource("transfer.bpmn").deploy();
    }

    /** Ждёт, пока в движке не останется активных экземпляров процесса (или истечёт время). */
    public static boolean awaitDone(ProcessEngine engine, long timeoutMs) throws InterruptedException {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            if (engine.getRuntimeService().createProcessInstanceQuery().count() == 0) return true;
            if (engine.getRuntimeService().createIncidentQuery().count() > 0) return false;
            Thread.sleep(150);
        }
        return false;
    }

    public static String path(ProcessEngine engine, String instanceId) {
        return engine.getHistoryService().createHistoricActivityInstanceQuery().processInstanceId(instanceId).orderPartiallyByOccurrence().asc().list()
                .stream().filter(a -> !a.getActivityType().equals("multiInstanceBody")).map(HistoricActivityInstance::getActivityId).collect(Collectors.joining(" -> "));
    }

    public static String start(ProcessEngine engine, String from, String to, long amount, String mode) {
        Map<String, Object> vars = new HashMap<>(Map.of("from", from, "to", to, "amount", amount, "mode", mode));
        return engine.getRuntimeService().startProcessInstanceByKey("transfer", vars).getId();
    }
}
