# Сага перевода как BPMN-процесс на Camunda 7 (глава 31, подраздел 5.11)

Проверено 2026-10-21 и 2026-11-04: Camunda 7.24.0 (последний выпуск Community Edition), H2 2.3.232, JDK 21, Maven 3.9, Windows. Docker и внешние сервисы не нужны.

## Состав

- `src/main/resources/transfer.bpmn` — модель: резерв → списание → зачисление, компенсации (`refundDebit`, `releaseReserve`), граничные события ошибок, `asyncBefore` на шагах, `failedJobRetryTimeCycle="R3/PT1S"` на зачислении.
- `Steps.java` — шаги (`JavaDelegate`), пишут деньги в «внешнюю» базу `Ledger` своими соединениями.
- `Ledger.java` — база учёта (H2 в файле): счета, журнал проводок, счётчик попыток.
- `Engines.java` — настройка движка на файловой H2 (состояние переживает перезапуск), время блокировки задания 4 с.
- `SagaRun.java` — восемь сценариев (8: падение самой компенсации, инцидент на шаге `credit`); `SagaChild.java` — дочерний процесс для опытов с падением.

## Запуск

```bash
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt
java -Dstdout.encoding=UTF-8 -Dorg.slf4j.simpleLogger.defaultLogLevel=error -cp "target/classes;$(cat cp.txt)" saga.SagaRun
```

(на Linux и macOS разделитель пути в `-cp` — `:`). Рабочие базы создаются в `target/saga-*`.

## Что ожидать

- 1: путь `start → reserve → debit → credit → endOk`, сумма балансов 150000 не меняется.
- 2: путь с компенсациями `... creditRejected → undo → refundDebit → releaseReserve → endRejected`, остатки восстановлены.
- 4: после аварийного падения между коммитом учёта и коммитом движка зачисление выполняется дважды (проводок 2 на 20000); 5: с идемпотентной проверкой по ключу операции — одно.
- 6: две временные ошибки и успех (3 попытки); 7: три неудачи → инцидент `failedJob`, после `setJobRetries` процесс завершается.

Статус продукта: Camunda 7 Community Edition закончила жизненный цикл (репозиторий архивирован 2025-11-04); для нового проекта смотрите Camunda 8 или другой движок.

## Повторы: атрибут не работает, нужен элемент

2026-11-04 выяснилось, что `camunda:failedJobRetryTimeCycle="R3/PT1S"` как атрибут `serviceTask` движок не читает и ничего не сообщает: попытки шли через 20–200 мс, а три попытки - значение по умолчанию. Правильная форма - элемент внутри `extensionElements`, как сейчас в `transfer.bpmn`; с ней `R3/PT1S` даёт три попытки через 1,1–1,3 с, а `R5/PT2S` - пять через 2,1 с. Метки времени попыток печатает `Steps$Credit`; полный вывод семи сценариев - `s31-camunda.txt`.
