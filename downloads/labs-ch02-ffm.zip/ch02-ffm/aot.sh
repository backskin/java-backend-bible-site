#!/bin/sh
# Опыт 7.4: AOT-кэш Leyden на JDK 25 (JEP 483, 514): создание одной командой и время запуска с кэшем и без.
# AOT-кэш принимает только JAR-файлы в classpath: каталог с классами даёт «Cannot have non-empty directory in paths».
# Запуск: sh aot.sh > s7-aot.txt 2>&1
cd "$(dirname "$0")"
J=~/.jdks/jdk-25.0.5+8/bin
T=$(mktemp -d)
$J/javac -d $T/classes src/AotStartup.java
$J/jar --create --file $T/app.jar -C $T/classes .
echo "# $($J/java -version 2>&1 | head -1)"
echo '$ java -XX:AOTCacheOutput=app.aot -cp app.jar AotStartup'
$J/java -XX:AOTCacheOutput=$T/app.aot -cp $T/app.jar AotStartup 2>&1 | grep -v "^\[" | sed "s#$T#<tmp>#g"
echo "размер кэша: $(( $(stat -c %s $T/app.aot) / 1024 / 1024 )) МБ"
run() { s=$(date +%s%N); "$@" > /dev/null 2>&1; e=$(date +%s%N); echo $(( (e - s) / 1000000 )); }
for mode in "без кэша" "с -XX:AOTCache"; do
  total=0; min=999999
  for i in 1 2 3 4 5 6 7; do
    if [ "$mode" = "без кэша" ]; then ms=$(run $J/java -cp $T/app.jar AotStartup); else ms=$(run $J/java -XX:AOTCache=$T/app.aot -cp $T/app.jar AotStartup); fi
    [ $ms -lt $min ] && min=$ms
  done
  echo "$mode: лучшее из 7 запусков $min мс"
done
echo '$ java -XX:AOTCache=app.aot -Xlog:aot -cp app.jar AotStartup | head -3'
$J/java -XX:AOTCache=$T/app.aot -Xlog:aot -cp $T/app.jar AotStartup 2>&1 | head -3 | sed "s#$T#<tmp>#g"
rm -rf $T
