# FFM API, string templates, предупреждения JNI и AOT-кэш Leyden

Стенд к главе 02, раздел 7. `FfmBasics`, `NoPadding`, `LinkerOptions` и `LinkerOptions21` - Foreign Function & Memory API: выделение памяти в `Arena`, раскладка структуры с выравниванием, параметры компоновщика на 25 и в preview на 21; `JniWarning` - предупреждение JEP 472 при загрузке библиотеки; `StringTemplates` - шаблоны строк, которые работали в preview на 21 и удалены в 23; `AotStartup` с `aot.sh` - AOT-кэш JDK 25 и время запуска с ним и без. Выводы автора - в `s7-*.txt`.

## Что нужно

- Temurin JDK 21.0.10 и 25.0.5 в `~/.jdks` (словарь `ALL` в `run.py`, путь в `aot.sh`).
- Python 3; для `aot.sh` - sh и `stat` (Git Bash на Windows подходит).

## Запуск

```bash
python -X utf8 run.py
```

Ошибки компиляции на JDK 21 в `s7-ffm-basics.txt` и `s7-linker-options.txt` намеренные: программы написаны под API 25, а на 21 те же методы называются иначе или отсутствуют. AOT-кэш:

```bash
sh aot.sh > s7-aot.txt 2>&1
```

Скрипт собирает JAR (кэш принимает в classpath только JAR, не каталог классов), создает кэш одной командой `-XX:AOTCacheOutput` и берет лучшее из семи запусков с кэшем и без.

## Что должно получиться

Размер кэша и выигрыш в миллисекундах зависят от машины; у автора кэш около 10 МБ и запуск с ним быстрее. `PinNative` из соседнего стенда и `FfmBasics` здесь обращаются к `kernel32`, поэтому рассчитаны на Windows.
