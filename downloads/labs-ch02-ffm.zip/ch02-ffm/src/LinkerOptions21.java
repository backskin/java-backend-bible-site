// JDKS: 21 25
// PREVIEW: 21
// OUT: s7-linker-options-21
// Опция короткого вызова: Linker.Option.isTrivial() в preview 21, Linker.Option.critical(boolean) в финальном API 22+.
import java.lang.foreign.*;
import java.lang.invoke.MethodHandle;

public class LinkerOptions21 {
    public static void main(String[] args) throws Throwable {
        Linker linker = Linker.nativeLinker();
        MethodHandle strlen = linker.downcallHandle(
                linker.defaultLookup().find("strlen").orElseThrow(),
                FunctionDescriptor.of(ValueLayout.JAVA_LONG, ValueLayout.ADDRESS),
                Linker.Option.isTrivial());
        try (Arena arena = Arena.ofConfined()) {
            System.out.println("java " + System.getProperty("java.version") + ", isTrivial strlen: " + (long) strlen.invokeExact(arena.allocateUtf8String("RUB")));
        }
    }
}
