// JDKS: 25
// OUT: s7-no-padding
// Структура без явного выравнивания: structLayout проверяет выравнивание полей.
import java.lang.foreign.*;

public class NoPadding {
    public static void main(String[] args) {
        try {
            MemoryLayout l = MemoryLayout.structLayout(ValueLayout.JAVA_INT.withName("alg"), ValueLayout.JAVA_LONG.withName("key_id"));
            System.out.println("создано, размер " + l.byteSize());
        } catch (IllegalArgumentException e) {
            System.out.println("structLayout без paddingLayout(4): " + e.getMessage());
        }
        MemoryLayout packed = MemoryLayout.structLayout(ValueLayout.JAVA_INT.withName("alg"), ValueLayout.JAVA_LONG_UNALIGNED.withName("key_id"));
        System.out.println("с JAVA_LONG_UNALIGNED: размер " + packed.byteSize() + ", смещение key_id "
                + packed.byteOffset(MemoryLayout.PathElement.groupElement("key_id")));
    }
}
