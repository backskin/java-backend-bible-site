// JDKS: 21 25
// PREVIEW: 21
// OUT: s7-ffm-basics
// FFM API: вызов strlen, закрытая арена, раскладка структуры, точные типы invokeExact, предупреждение restricted-метода.
import java.lang.foreign.*;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.VarHandle;
import java.lang.foreign.MemoryLayout.PathElement;

public class FfmBasics {
    // struct sign_request { int32_t alg; int64_t key_id; void* data; int64_t len; };
    static final MemoryLayout SIGN_REQUEST = MemoryLayout.structLayout(
            ValueLayout.JAVA_INT.withName("alg"),
            MemoryLayout.paddingLayout(4),
            ValueLayout.JAVA_LONG.withName("key_id"),
            ValueLayout.ADDRESS.withName("data"),
            ValueLayout.JAVA_LONG.withName("len"));
    static final VarHandle KEY_ID = SIGN_REQUEST.varHandle(PathElement.groupElement("key_id"));

    public static void main(String[] args) throws Throwable {
        System.out.println("java " + System.getProperty("java.version"));
        Linker linker = Linker.nativeLinker();
        MethodHandle strlen = linker.downcallHandle(
                linker.defaultLookup().find("strlen").orElseThrow(),
                FunctionDescriptor.of(ValueLayout.JAVA_LONG, ValueLayout.ADDRESS));
        MemorySegment kept;
        try (Arena arena = Arena.ofConfined()) {
            MemorySegment str = arena.allocateFrom("40817810099910004312");
            long len = (long) strlen.invokeExact(str);
            System.out.println("strlen номера счёта: " + len);
            kept = str;
        }
        try {
            kept.get(ValueLayout.JAVA_BYTE, 0);
        } catch (IllegalStateException e) {
            System.out.println("доступ после close(): " + e);
        }
        System.out.println("размер struct sign_request: " + SIGN_REQUEST.byteSize() + " байт, смещение key_id: "
                + SIGN_REQUEST.byteOffset(PathElement.groupElement("key_id")));
        try (Arena arena = Arena.ofConfined()) {
            MemorySegment req = arena.allocate(SIGN_REQUEST);
            KEY_ID.set(req, 0L, 42L);
            System.out.println("key_id в сегменте: " + req.get(ValueLayout.JAVA_LONG, 8));
        } catch (Throwable t) {
            System.out.println("VarHandle без смещения: " + t.getClass().getSimpleName());
        }
        try {
            int wrong = (int) strlen.invokeExact(MemorySegment.NULL);
        } catch (java.lang.invoke.WrongMethodTypeException e) {
            System.out.println("invokeExact с int вместо long: WrongMethodTypeException");
        }
    }
}
