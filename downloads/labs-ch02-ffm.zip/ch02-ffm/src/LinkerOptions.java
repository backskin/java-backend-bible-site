// JDKS: 21 25
// PREVIEW: 21
// OUT: s7-linker-options
// Опция короткого вызова: Linker.Option.isTrivial() в preview 21, Linker.Option.critical(boolean) в финальном API 22+.
import java.lang.foreign.*;
import java.lang.invoke.MethodHandle;

public class LinkerOptions {
    public static void main(String[] args) throws Throwable {
        Linker linker = Linker.nativeLinker();
        MethodHandle strlen = linker.downcallHandle(
                linker.defaultLookup().find("strlen").orElseThrow(),
                FunctionDescriptor.of(ValueLayout.JAVA_LONG, ValueLayout.ADDRESS),
                Linker.Option.critical(false));
        try (Arena arena = Arena.ofConfined()) {
            System.out.println("java " + System.getProperty("java.version") + ", critical strlen: " + (long) strlen.invokeExact(arena.allocateFrom("RUB")));
        }
    }
}
