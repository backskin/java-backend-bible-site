// JDKS: 21 25
// PREVIEW: 21 25
// OUT: s7-string-templates
// String templates: preview в 21 (JEP 430), удалены в 23 — на 25 не компилируются даже с --enable-preview.
public class StringTemplates {
    public static void main(String[] args) {
        String account = "40817";
        long kopecks = 15_000;
        System.out.println(STR."Списание \{kopecks / 100} руб. со счёта \{account}");
    }
}
