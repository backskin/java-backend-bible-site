// Вспомогательная программа для aot.sh: при старте загружает классы HTTP-клиента, регулярных выражений, java.time и логирования.
import java.net.http.HttpClient;
import java.time.format.DateTimeFormatter;
import java.time.ZonedDateTime;
import java.util.logging.Logger;
import java.util.regex.Pattern;

public class AotStartup {
    public static void main(String[] args) {
        var client = HttpClient.newBuilder().build();
        var iban = Pattern.compile("[A-Z]{2}\\d{2}[A-Z0-9]{11,30}").matcher("DE89370400440532013000").matches();
        var ts = DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(ZonedDateTime.parse("2026-11-02T10:00:00+03:00"));
        Logger.getLogger("payments").fine("start");
        System.out.println("iban=" + iban + " ts=" + ts + " client=" + (client != null));
    }
}
