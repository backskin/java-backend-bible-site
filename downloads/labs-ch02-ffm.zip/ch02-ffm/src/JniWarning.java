// JDKS: 21 25
// OUT: s7-jni-warning
// JEP 472 (24): загрузка нативной библиотеки через System.loadLibrary без --enable-native-access даёт предупреждение.
public class JniWarning {
    public static void main(String[] args) {
        try {
            System.loadLibrary("ch02-no-such-lib");
        } catch (UnsatisfiedLinkError e) {
            System.out.println("java " + System.getProperty("java.version") + ": " + e.getMessage().replaceAll(":.*", ""));
        }
    }
}
