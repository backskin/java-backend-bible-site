import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class DeadlockDemo {

    static final class Account {
        final long id; long balance = 1_000_000;
        Account(long id) { this.id = id; }
        void debit(long a) { balance -= a; }
        void credit(long a) { balance += a; }
    }

    // ПЛОХО: порядок захвата зависит от аргументов
    static void transferBad(Account from, Account to, long amount) {
        synchronized (from) { synchronized (to) { from.debit(amount); to.credit(amount); } }
    }

    // ХОРОШО: канонический порядок по неизменяемому идентификатору
    static void transferGood(Account from, Account to, long amount) {
        Account first = from.id < to.id ? from : to;
        Account second = first == from ? to : from;
        synchronized (first) { synchronized (second) { from.debit(amount); to.credit(amount); } }
    }

    interface Transfer { void run(Account from, Account to, long amount); }

    static boolean runTwoWay(Transfer t) throws Exception {
        Account a = new Account(1), b = new Account(2);
        Thread t1 = new Thread(() -> { for (int i = 0; i < 2_000_000; i++) t.run(a, b, 1); });
        Thread t2 = new Thread(() -> { for (int i = 0; i < 2_000_000; i++) t.run(b, a, 1); });
        t1.setDaemon(true); t2.setDaemon(true);
        t1.start(); t2.start();
        t1.join(5000); t2.join(5000);
        boolean finished = !t1.isAlive() && !t2.isAlive();
        if (!finished) {
            ThreadMXBean mx = ManagementFactory.getThreadMXBean();
            long[] ids = mx.findDeadlockedThreads();
            System.out.println("  findDeadlockedThreads: " + (ids == null ? "null" : ids.length + " потока"));
            if (ids != null) for (var info : mx.getThreadInfo(ids)) {
                System.out.println("  поток " + info.getThreadName() + ": " + info.getThreadState() + ", ждёт монитор, которым владеет " + info.getLockOwnerName());
            }
        }
        return finished;
    }

    // ---- пул, который ждёт сам себя
    static void poolWaitsForItself() throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        Runnable parent = () -> {
            try { pool.submit(() -> "дочерняя").get(); } catch (Exception ignored) { }
        };
        Future<?> f1 = pool.submit(parent), f2 = pool.submit(parent);
        try { f1.get(2, TimeUnit.SECONDS); System.out.println("  завершились"); }
        catch (java.util.concurrent.TimeoutException e) { System.out.println("  за 2 с родительские задачи не завершились: пул ждёт сам себя"); }
        ThreadMXBean mx = ManagementFactory.getThreadMXBean();
        long[] dl = mx.findDeadlockedThreads();
        System.out.println("  findDeadlockedThreads: " + (dl == null ? "null" : java.util.Arrays.toString(dl)));
        pool.shutdownNow();
    }

    // ---- взаимная инициализация классов
    static class A { static { try { Thread.sleep(300); } catch (InterruptedException ignored) { } new B(); } }
    static class B { static { try { Thread.sleep(300); } catch (InterruptedException ignored) { } new A(); } }

    static void classInitDeadlock() throws Exception {
        Thread t1 = new Thread(() -> new A(), "init-A");
        Thread t2 = new Thread(() -> new B(), "init-B");
        t1.setDaemon(true); t2.setDaemon(true);
        t1.start(); t2.start();
        Thread.sleep(1500);
        System.out.println("  состояния: init-A=" + t1.getState() + ", init-B=" + t2.getState());
        long[] dl = ManagementFactory.getThreadMXBean().findDeadlockedThreads();
        System.out.println("  findDeadlockedThreads: " + (dl == null ? "null" : java.util.Arrays.toString(dl)));
    }

    /**
     * Запуск: java DeadlockDemo.java <сценарий>, сценарии: bad | good | pool | init.
     * Каждый сценарий запускают в отдельном процессе: застрявшие потоки одного сценария
     * остались бы видны детектору в следующем.
     */
    public static void main(String[] args) throws Exception {
        switch (args[0]) {
            case "bad"  -> System.out.println("transfer по аргументам, завершилось за 5 с: " + runTwoWay(DeadlockDemo::transferBad));
            case "good" -> System.out.println("transfer по id, завершилось за 5 с: " + runTwoWay(DeadlockDemo::transferGood));
            case "pool" -> poolWaitsForItself();
            case "init" -> classInitDeadlock();
            default -> System.out.println("сценарий: bad | good | pool | init");
        }
        System.exit(0);
    }
}
