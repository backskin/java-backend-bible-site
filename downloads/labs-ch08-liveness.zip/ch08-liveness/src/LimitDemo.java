import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

public class LimitDemo {

    static final int LIMIT = 5;

    /** 50 потоков по 200 инкрементов в один ключ: ожидаем 10 000. */
    static int counting(boolean concurrent) throws Exception {
        Map<Long, Integer> plain = new HashMap<>();
        Map<Long, LongAdder> adders = new ConcurrentHashMap<>();
        CountDownLatch start = new CountDownLatch(1);
        Thread[] ts = new Thread[50];
        for (int t = 0; t < ts.length; t++) {
            ts[t] = new Thread(() -> {
                try { start.await(); } catch (InterruptedException e) { return; }
                try {
                    for (int i = 0; i < 200; i++) {
                        if (concurrent) adders.computeIfAbsent(1L, k -> new LongAdder()).increment();
                        else plain.put(1L, plain.getOrDefault(1L, 0) + 1);      // чтение, изменение, запись
                    }
                } catch (Exception ignored) { }                                 // HashMap может падать от гонки
            });
            ts[t].start();
        }
        start.countDown();
        for (Thread t : ts) t.join();
        return concurrent ? adders.get(1L).intValue() : plain.getOrDefault(1L, 0);
    }

    /** 16 потоков одновременно пытаются провести операцию при лимите 5. */
    static int admitted(String mode) throws Exception {
        LongAdder adder = new LongAdder();
        AtomicInteger atomic = new AtomicInteger();
        AtomicInteger admitted = new AtomicInteger();
        CountDownLatch start = new CountDownLatch(1);
        Thread[] ts = new Thread[16];
        for (int t = 0; t < ts.length; t++) {
            ts[t] = new Thread(() -> {
                try { start.await(); } catch (InterruptedException e) { return; }
                switch (mode) {
                    case "check-then-act" -> { if (adder.sum() < LIMIT) { adder.increment(); admitted.incrementAndGet(); } }
                    case "atomic"        -> { if (atomic.incrementAndGet() <= LIMIT) admitted.incrementAndGet(); }
                }
            });
            ts[t].start();
        }
        start.countDown();
        for (Thread t : ts) t.join();
        return admitted.get();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("--- 1. потерянные обновления: 50 потоков x 200 инкрементов (ожидалось 10000)");
        for (int run = 1; run <= 3; run++) System.out.println("HashMap, прогон " + run + ": " + counting(false));
        System.out.println("ConcurrentHashMap + LongAdder:  " + counting(true));

        System.out.println("--- 2. проверка лимита (лимит " + LIMIT + "), 16 потоков, 200 попыток: максимум пропущено");
        for (String mode : new String[]{"check-then-act", "atomic"}) {
            int max = 0, over = 0;
            for (int run = 0; run < 200; run++) { int a = admitted(mode); max = Math.max(max, a); if (a > LIMIT) over++; }
            System.out.println(String.format("%-15s пропущено сверх лимита в %3d прогонах из 200, максимум %d", mode, over, max));
        }
    }
}
