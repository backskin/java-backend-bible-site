import java.util.concurrent.*;

/** scheduleAtFixedRate на одном потоке: задачу с периодом 200 мс задержали на 2 с — что потом. */
public class FixedRateCatchUp {
    public static void main(String[] args) throws Exception {
        ScheduledThreadPoolExecutor s = new ScheduledThreadPoolExecutor(1);
        long t0 = System.nanoTime();
        s.schedule(() -> { try { Thread.sleep(2000); } catch (InterruptedException ignored) { } }, 100, TimeUnit.MILLISECONDS); // «ночной отчёт»
        s.scheduleAtFixedRate(() -> System.out.printf("проверка здоровья на %d мс%n", (System.nanoTime() - t0) / 1_000_000),
                0, 200, TimeUnit.MILLISECONDS);
        Thread.sleep(2900);
        s.shutdownNow();
    }
}
