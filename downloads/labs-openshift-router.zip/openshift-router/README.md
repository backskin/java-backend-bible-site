# Шаблон конфигурации HAProxy роутера OpenShift: значения по умолчанию тайм-аутов, балансировки и заголовков

Справочный стенд к главе 47. `haproxy-config.template` - копия файла `images/router/haproxy/conf/haproxy-config.template` из репозитория `openshift/router` (коммит 6d11db5c51d7, снято 2026-10-28). Глава берет из него значения по умолчанию для таблицы роутера: аргументы `firstMatch` и `env` в строках с `timeout`, `balance`, `cookie`, `setForwardedHeadersDefaultValue`. Роутер конкретного кластера может переопределять их переменными окружения из `IngressController`. Программ нет; файл нужен, чтобы сверять таблицу главы с первоисточником без обращения к GitHub.

## Как пользоваться

```bash
grep -nE 'timeout|balance ' haproxy-config.template | head -40
```

Свежую версию файла: [github.com/openshift/router](https://github.com/openshift/router/blob/master/images/router/haproxy/conf/haproxy-config.template).
