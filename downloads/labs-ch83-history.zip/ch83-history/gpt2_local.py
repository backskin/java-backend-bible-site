"""Локальный запуск GPT-2 (2019) на процессоре: число параметров, скорость генерации, токены русского и английского.

Запуск из корня репозитория: python -I labs/ch83-history/gpt2_local.py
Первый запуск скачивает веса openai-community/gpt2 с Hugging Face (около 550 МБ) в кэш ~/.cache/huggingface.
"""
import platform
import time

import torch
import transformers
from huggingface_hub import model_info
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL = "openai-community/gpt2"


def main() -> None:
    info = model_info(MODEL)
    print(f"модель {MODEL}, ревизия {info.sha}")
    print(f"torch {torch.__version__}, transformers {transformers.__version__}, {platform.processor()}, потоков {torch.get_num_threads()}")

    tok = AutoTokenizer.from_pretrained(MODEL, revision=info.sha)
    model = AutoModelForCausalLM.from_pretrained(MODEL, revision=info.sha)
    model.eval()

    total = sum(p.numel() for p in model.parameters())
    wte = model.transformer.wte.weight.numel()
    wpe = model.transformer.wpe.weight.numel()
    print(f"параметров всего {total:,}; из них таблица токенов {wte:,}, таблица позиций {wpe:,}; без таблиц {total - wte - wpe:,}")
    print(f"словарь {tok.vocab_size} токенов, контекст {model.config.n_positions} токенов, слоев {model.config.n_layer}, голов {model.config.n_head}")

    for text in ["The payment was declined because the card limit was exceeded.",
                 "Платеж отклонен, потому что превышен лимит по карте."]:
        ids = tok.encode(text)
        print(f"{len(text.split())} слов, {len(text.encode('utf-8'))} байт -> {len(ids)} токенов: {text}")

    prompt = "The bank's fraud detection system"
    inputs = tok(prompt, return_tensors="pt")
    for label, kwargs in [("жадный выбор", {"do_sample": False}),
                          ("выборка top_k=40, seed 42", {"do_sample": True, "top_k": 40})]:
        torch.manual_seed(42)
        start = time.perf_counter()
        with torch.no_grad():
            out = model.generate(**inputs, max_new_tokens=60, pad_token_id=tok.eos_token_id, **kwargs)
        elapsed = time.perf_counter() - start
        new = out.shape[1] - inputs["input_ids"].shape[1]
        print(f"\n[{label}] {new} токенов за {elapsed:.2f} с, {new / elapsed:.1f} токенов/с")
        print(tok.decode(out[0], skip_special_tokens=True))


if __name__ == "__main__":
    main()
