import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

/**
 * Считает стоимость одной и той же нагрузки по опубликованным ценам моделей разных лет.
 *
 * <p>Нагрузка - миллион обращений в поддержку, у каждого 400 токенов на входе и 80 на выходе.
 * Цены - доллары за миллион токенов из объявлений Anthropic (Claude 3, 2024; Claude 3.7 Sonnet, 2025;
 * Claude Opus 5.5, 2026). Отдельно показано, во что обходится та же нагрузка, если русский текст
 * занимает в 1,5 раза больше токенов, чем английский.
 *
 * <p>Запуск из корня репозитория: {@code java labs/ch83-history/src/TokenCostLab.java}.
 */
public class TokenCostLab {

    record Price(String model, String date, String in, String out) {
    }

    public static void main(String[] args) {
        long requests = 1_000_000;
        long inTokens = 400;
        long outTokens = 80;
        Price[] prices = {
                new Price("Claude 3 Haiku", "2024-03-04", "0.25", "1.25"),
                new Price("Claude 3 Sonnet", "2024-03-04", "3", "15"),
                new Price("Claude 3 Opus", "2024-03-04", "15", "75"),
                new Price("Claude 3.7 Sonnet", "2025-02-24", "3", "15"),
                new Price("Claude Opus 5.5", "2026-09-22", "4", "20"),
        };
        BigDecimal million = BigDecimal.valueOf(1_000_000);
        System.out.printf(Locale.ROOT, "Нагрузка: %,d запросов по %d токенов на входе и %d на выходе%n", requests, inTokens, outTokens);
        System.out.printf(Locale.ROOT, "%-18s %-11s %8s %8s %12s %14s%n", "модель", "цены от", "$/M вх", "$/M вых", "итого, $", "русский x1.5, $");
        for (Price p : prices) {
            BigDecimal total = cost(requests, inTokens, outTokens, p, million);
            BigDecimal ru = cost(requests, inTokens * 3 / 2, outTokens * 3 / 2, p, million);
            System.out.printf(Locale.ROOT, "%-18s %-11s %8s %8s %12s %14s%n", p.model(), p.date(), p.in(), p.out(),
                    total.setScale(2, RoundingMode.HALF_UP).toPlainString(), ru.setScale(2, RoundingMode.HALF_UP).toPlainString());
        }
    }

    private static BigDecimal cost(long requests, long in, long out, Price p, BigDecimal million) {
        BigDecimal inCost = new BigDecimal(p.in()).multiply(BigDecimal.valueOf(requests * in)).divide(million);
        BigDecimal outCost = new BigDecimal(p.out()).multiply(BigDecimal.valueOf(requests * out)).divide(million);
        return inCost.add(outCost);
    }
}
