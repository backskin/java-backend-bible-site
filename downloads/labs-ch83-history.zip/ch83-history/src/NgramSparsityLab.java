import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Показывает, почему модели n-грамм упираются в нехватку данных.
 *
 * <p>Корпус - главы книги из папки {@code book/}: одна глава откладывается для проверки,
 * остальные служат обучающими данными. Программа печатает закон Ципфа на корпусе,
 * долю n-грамм проверочной главы, которых нет в обучающих данных, и текст,
 * сгенерированный триграммной моделью с фиксированным начальным значением генератора.
 *
 * <p>Запуск из корня репозитория: {@code java labs/ch83-history/src/NgramSparsityLab.java book 31}.
 */
public class NgramSparsityLab {

    private static final Pattern WORD = Pattern.compile("[\\p{IsCyrillic}\\p{IsLatin}]+(?:-[\\p{IsCyrillic}\\p{IsLatin}]+)*");
    private static final Pattern CODE_BLOCK = Pattern.compile("(?s)```.*?```");

    public static void main(String[] args) throws IOException {
        Path bookDir = Path.of(args.length > 0 ? args[0] : "book");
        String heldOut = args.length > 1 ? args[1] : "31";

        List<String> train = new ArrayList<>();
        List<String> test = new ArrayList<>();
        List<Path> chapters;
        try (Stream<Path> files = Files.list(bookDir)) {
            chapters = files.filter(p -> p.getFileName().toString().matches("\\d\\d-.*\\.md"))
                    .filter(p -> !p.getFileName().toString().startsWith("83-"))
                    .sorted().toList();
        }
        for (Path chapter : chapters) {
            List<String> words = words(Files.readString(chapter));
            (chapter.getFileName().toString().startsWith(heldOut + "-") ? test : train).addAll(words);
        }
        System.out.printf(Locale.ROOT, "Глав в обучении: %d, слов в обучении: %d, слов в проверке (глава %s): %d%n",
                chapters.size() - 1, train.size(), heldOut, test.size());

        zipf(train);
        for (int n = 1; n <= 4; n++) {
            unseen(train, test, n);
        }
        generate(train, 42L, 40);
    }

    /** Слова главы без блоков кода, в нижнем регистре. */
    static List<String> words(String markdown) {
        String prose = CODE_BLOCK.matcher(markdown).replaceAll(" ");
        List<String> out = new ArrayList<>();
        Matcher m = WORD.matcher(prose);
        while (m.find()) {
            out.add(m.group().toLowerCase(Locale.ROOT));
        }
        return out;
    }

    static void zipf(List<String> words) {
        Map<String, Integer> freq = new HashMap<>();
        for (String w : words) {
            freq.merge(w, 1, Integer::sum);
        }
        List<Map.Entry<String, Integer>> ranked = new ArrayList<>(freq.entrySet());
        ranked.sort((a, b) -> b.getValue() - a.getValue());
        long once = freq.values().stream().filter(c -> c == 1).count();
        System.out.printf(Locale.ROOT, "%nРазных слов: %d, из них встретились один раз: %d (%.1f %%)%n",
                freq.size(), once, 100.0 * once / freq.size());
        System.out.println("Ранг | слово | частота | частота x ранг");
        for (int rank : new int[] {1, 2, 3, 10, 100, 1000, 10000}) {
            if (rank <= ranked.size()) {
                Map.Entry<String, Integer> e = ranked.get(rank - 1);
                System.out.printf(Locale.ROOT, "%5d | %s | %d | %d%n", rank, e.getKey(), e.getValue(), (long) e.getValue() * rank);
            }
        }
    }

    static void unseen(List<String> train, List<String> test, int n) {
        Map<String, Integer> seen = new HashMap<>();
        for (int i = 0; i + n <= train.size(); i++) {
            seen.merge(String.join(" ", train.subList(i, i + n)), 1, Integer::sum);
        }
        int total = 0;
        int missing = 0;
        for (int i = 0; i + n <= test.size(); i++) {
            total++;
            if (!seen.containsKey(String.join(" ", test.subList(i, i + n)))) {
                missing++;
            }
        }
        System.out.printf(Locale.ROOT, "n=%d: разных n-грамм в обучении %d, в проверке не встречались %d из %d (%.1f %%)%n",
                n, seen.size(), missing, total, 100.0 * missing / total);
    }

    /** Генерация триграммной моделью: следующее слово выбирается по частоте после двух предыдущих. */
    static void generate(List<String> train, long seed, int length) {
        Map<String, Map<String, Integer>> next = new HashMap<>();
        for (int i = 0; i + 2 < train.size(); i++) {
            next.computeIfAbsent(train.get(i) + " " + train.get(i + 1), k -> new HashMap<>())
                    .merge(train.get(i + 2), 1, Integer::sum);
        }
        Random random = new Random(seed);
        String[] state = {"транзакция", "должна"};
        StringBuilder text = new StringBuilder(state[0] + " " + state[1]);
        for (int i = 0; i < length; i++) {
            Map<String, Integer> options = next.get(state[0] + " " + state[1]);
            if (options == null) {
                break;
            }
            String[] keys = options.keySet().toArray(String[]::new);
            Arrays.sort(keys);
            int sum = options.values().stream().mapToInt(Integer::intValue).sum();
            int pick = random.nextInt(sum);
            String chosen = keys[0];
            for (String k : keys) {
                pick -= options.get(k);
                if (pick < 0) {
                    chosen = k;
                    break;
                }
            }
            text.append(' ').append(chosen);
            state = new String[] {state[1], chosen};
        }
        System.out.printf("%nТриграммная модель, начальное значение %d:%n%s%n", seed, text);
    }
}
