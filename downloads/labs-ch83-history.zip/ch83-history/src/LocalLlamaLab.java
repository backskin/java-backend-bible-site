import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Вызывает локальную модель через HTTP API Ollama без библиотек и печатает ответ и скорость.
 *
 * <p>Ollama должна слушать http://127.0.0.1:11434, модель - быть скачана командой {@code ollama pull}.
 * Скорость берется из полей ответа: {@code prompt_eval_count/prompt_eval_duration} - чтение затравки,
 * {@code eval_count/eval_duration} - генерация (длительности в наносекундах).
 *
 * <p>Запуск: {@code java labs/ch83-history/src/LocalLlamaLab.java llama2:7b "затравка" [лимит токенов ответа, по умолчанию 120]}.
 */
public class LocalLlamaLab {

    public static void main(String[] args) throws Exception {
        String model = args.length > 0 ? args[0] : "llama2:7b";
        String prompt = args.length > 1 ? args[1] : "Explain in two sentences what a payment chargeback is.";
        int maxTokens = args.length > 2 ? Integer.parseInt(args[2]) : 120;
        String body = """
                {"model": "%s", "prompt": "%s", "stream": false,
                 "options": {"seed": 42, "temperature": 0, "num_predict": %d}}"""
                .formatted(model, prompt.replace("\\", "\\\\").replace("\"", "\\\""), maxTokens);

        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
        HttpRequest request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:11434/api/generate"))
                .timeout(Duration.ofMinutes(10))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        long start = System.nanoTime();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        double wall = (System.nanoTime() - start) / 1e9;
        String json = response.body();

        System.out.printf(Locale.ROOT, "модель %s, HTTP %d, время запроса %.1f с%n", model, response.statusCode(), wall);
        System.out.println("затравка: " + prompt);
        String thinking = text(json, "thinking");
        if (!thinking.isEmpty()) {
            System.out.printf(Locale.ROOT, "рассуждение (%d символов): %s%n", thinking.length(),
                    thinking.length() > 400 ? thinking.substring(0, 400) + " ..." : thinking);
        }
        System.out.println("ответ: " + text(json, "response"));
        long promptTokens = number(json, "prompt_eval_count");
        long promptNs = number(json, "prompt_eval_duration");
        long outTokens = number(json, "eval_count");
        long outNs = number(json, "eval_duration");
        long loadNs = number(json, "load_duration");
        System.out.printf(Locale.ROOT, "загрузка модели %.1f с; затравка %d токенов, %.1f токенов/с; ответ %d токенов, %.1f токенов/с%n",
                loadNs / 1e9, promptTokens, promptTokens / (promptNs / 1e9), outTokens, outTokens / (outNs / 1e9));
    }

    private static long number(String json, String field) {
        Matcher m = Pattern.compile("\"" + field + "\":(\\d+)").matcher(json);
        return m.find() ? Long.parseLong(m.group(1)) : 0;
    }

    private static String text(String json, String field) {
        Matcher m = Pattern.compile("\"" + field + "\":\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json);
        return m.find() ? m.group(1).replace("\\n", "\n").replace("\\\"", "\"") : "";
    }
}
