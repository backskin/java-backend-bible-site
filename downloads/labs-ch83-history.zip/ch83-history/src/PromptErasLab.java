import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Четыре способа обратиться к модели, по одному на эпоху, на одной локальной модели через HTTP API Ollama.
 *
 * <ol>
 *   <li>2020-2021: сырое продолжение текста с несколькими примерами в затравке ({@code /api/generate}, {@code raw}).</li>
 *   <li>2023: чат с ролями system и user ({@code /api/chat}).</li>
 *   <li>2024: ответ строго по JSON-схеме ({@code format} со схемой).</li>
 *   <li>2025: вызов инструмента: модель просит вызвать функцию, программа отвечает результатом.</li>
 * </ol>
 *
 * <p>Запуск: {@code java labs/ch83-history/src/PromptErasLab.java llama3.1:8b}.
 */
public class PromptErasLab {

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static final String TASK = "Оплата по счету 1532 за аренду офиса, ООО Ромашка, 48 000 руб.";

    public static void main(String[] args) throws Exception {
        String model = args.length > 0 ? args[0] : "llama3.1:8b";
        String options = "\"options\": {\"seed\": 42, \"temperature\": 0, \"num_predict\": 120}";

        System.out.println("== 1. Затравка с примерами (raw completion)");
        String fewShot = """
                Назначение: Перевод собственных средств между счетами => категория: внутренний
                Назначение: Оплата по договору поставки 77, ООО Альфа => категория: поставщик
                Назначение: Заработная плата за октябрь => категория: зарплата
                Назначение: %s => категория:""".formatted(TASK);
        String r1 = post("/api/generate", """
                {"model": "%s", "prompt": "%s", "raw": true, "stream": false, %s}"""
                .formatted(model, json(fewShot), options.replace("120", "8")));
        System.out.println(field(r1, "response").lines().findFirst().orElse("").trim());

        System.out.println("\n== 2. Чат с ролями");
        String r2 = post("/api/chat", """
                {"model": "%s", "stream": false, %s, "messages": [
                 {"role": "system", "content": "Ты классифицируешь назначения платежей. Отвечай одним словом: внутренний, поставщик, аренда или зарплата."},
                 {"role": "user", "content": "%s"}]}""".formatted(model, options, json(TASK)));
        System.out.println(field(r2, "content"));

        System.out.println("\n== 3. Ответ по JSON-схеме");
        String r3 = post("/api/chat", """
                {"model": "%s", "stream": false, %s,
                 "format": {"type": "object", "properties": {
                   "category": {"type": "string", "enum": ["внутренний", "поставщик", "аренда", "зарплата"]},
                   "counterparty": {"type": "string"},
                   "amount_rub": {"type": "integer"}},
                  "required": ["category", "counterparty", "amount_rub"]},
                 "messages": [{"role": "user", "content": "Разбери назначение платежа: %s"}]}"""
                .formatted(model, options, json(TASK)));
        System.out.println(field(r3, "content"));

        System.out.println("\n== 4. Вызов инструмента");
        String tools = """
                "tools": [{"type": "function", "function": {
                  "name": "get_card_limit",
                  "description": "Возвращает дневной лимит по карте в рублях",
                  "parameters": {"type": "object", "properties": {"card_id": {"type": "string"}}, "required": ["card_id"]}}}]""";
        String question = "Какой дневной лимит у карты C-1001?";
        String r4 = post("/api/chat", """
                {"model": "%s", "stream": false, %s, %s,
                 "messages": [{"role": "user", "content": "%s"}]}""".formatted(model, options, tools, json(question)));
        Matcher call = Pattern.compile("\"name\":\"([^\"]+)\",\"arguments\":(\\{[^}]*\\})").matcher(r4);
        if (!call.find()) {
            System.out.println("модель не запросила инструмент: " + field(r4, "content"));
            return;
        }
        System.out.println("модель запросила: " + call.group(1) + " " + call.group(2));
        String toolResult = "{\\\"card_id\\\": \\\"C-1001\\\", \\\"daily_limit_rub\\\": 150000}";
        String r5 = post("/api/chat", """
                {"model": "%s", "stream": false, %s, %s, "messages": [
                 {"role": "user", "content": "%s"},
                 {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": "%s", "arguments": %s}}]},
                 {"role": "tool", "content": "%s"}]}"""
                .formatted(model, options, tools, json(question), call.group(1), call.group(2), toolResult));
        System.out.println("ответ после инструмента: " + field(r5, "content"));
    }

    private static String post(String path, String body) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:11434" + path))
                .timeout(Duration.ofMinutes(5))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        return HTTP.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    private static String json(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    private static String field(String body, String name) {
        Matcher m = Pattern.compile("\"" + name + "\":\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(body);
        return m.find() ? m.group(1).replace("\\n", "\n").replace("\\\"", "\"") : "";
    }
}
