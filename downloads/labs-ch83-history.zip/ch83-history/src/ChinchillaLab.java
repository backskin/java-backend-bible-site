import java.util.Locale;

/**
 * Пересчитывает модели из таблицы 1 статьи Chinchilla (Hoffmann et al., 2022) по двум правилам.
 *
 * <p>Вычисления на обучение оцениваются как C = 6 * N * D (N - параметры, D - токены обучения).
 * Вычислительно-оптимальная модель для того же C по Chinchilla обучается примерно на 20 токенах
 * на параметр: D = 20 * N, откуда N = sqrt(C / 120). Программа печатает, сколько токенов модель
 * получила на параметр и какой размер был бы оптимален при том же бюджете вычислений.
 *
 * <p>Запуск из корня репозитория: {@code java labs/ch83-history/src/ChinchillaLab.java}.
 */
public class ChinchillaLab {

    record Model(String name, double params, double tokens) {
    }

    public static void main(String[] args) {
        Model[] models = {
                new Model("LaMDA", 137e9, 168e9),
                new Model("GPT-3", 175e9, 300e9),
                new Model("Jurassic-1", 178e9, 300e9),
                new Model("Gopher", 280e9, 300e9),
                new Model("MT-NLG 530B", 530e9, 270e9),
                new Model("Chinchilla", 70e9, 1.4e12),
        };
        System.out.printf(Locale.ROOT, "%-12s %8s %8s %10s %8s %10s %12s%n",
                "модель", "N, млрд", "D, млрд", "C, FLOP", "D/N", "N_opt", "D_opt, млрд");
        for (Model m : models) {
            double c = 6 * m.params() * m.tokens();
            double nOpt = Math.sqrt(c / 120);
            double dOpt = 20 * nOpt;
            System.out.printf(Locale.ROOT, "%-12s %8.0f %8.0f %10.2e %8.1f %10.0f %12.0f%n",
                    m.name(), m.params() / 1e9, m.tokens() / 1e9, c, m.tokens() / m.params(), nOpt / 1e9, dOpt / 1e9);
        }
    }
}
