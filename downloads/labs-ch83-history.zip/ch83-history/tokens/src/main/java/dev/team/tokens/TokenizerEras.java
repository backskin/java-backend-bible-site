package dev.team.tokens;

import com.knuddels.jtokkit.Encodings;
import com.knuddels.jtokkit.api.Encoding;
import com.knuddels.jtokkit.api.EncodingRegistry;
import com.knuddels.jtokkit.api.EncodingType;
import com.knuddels.jtokkit.api.IntArrayList;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;

/**
 * Сравнивает четыре поколения словарей токенизаторов OpenAI на одних и тех же текстах.
 *
 * <p>r50k_base - словарь GPT-2 и GPT-3, p50k_base - Codex, cl100k_base - GPT-3.5 и GPT-4,
 * o200k_base - GPT-4o. Для каждого текста печатается число токенов и, для короткой русской
 * фразы и строки кода с отступом в восемь пробелов, то, на какие куски словарь их режет.
 */
public final class TokenizerEras {

    private static final EncodingType[] ERAS = {
            EncodingType.R50K_BASE, EncodingType.P50K_BASE, EncodingType.CL100K_BASE, EncodingType.O200K_BASE};

    private static final Map<String, String> TEXTS = Map.of(
            "en", "The payment was declined because the card limit was exceeded.",
            "ru", "Платеж отклонен, потому что превышен лимит по карте.",
            "java", """
                    public final class LimitService {
                        public boolean allow(long amountMinor, long dailyLimitMinor) {
                            if (amountMinor <= 0) {
                                throw new IllegalArgumentException("amount must be positive");
                            }
                            return amountMinor <= dailyLimitMinor;
                        }
                    }
                    """);

    private TokenizerEras() {
    }

    public static void main(String[] args) {
        EncodingRegistry registry = Encodings.newDefaultEncodingRegistry();
        System.out.printf(Locale.ROOT, "%-12s %8s %8s %8s%n", "словарь", "en", "ru", "java");
        for (EncodingType type : ERAS) {
            Encoding enc = registry.getEncoding(type);
            System.out.printf(Locale.ROOT, "%-12s %8d %8d %8d%n", type.getName(),
                    enc.countTokens(TEXTS.get("en")), enc.countTokens(TEXTS.get("ru")), enc.countTokens(TEXTS.get("java")));
        }
        System.out.println();
        for (String text : new String[] {"Платеж отклонен", "        return"}) {
            for (EncodingType type : ERAS) {
                printPieces(registry.getEncoding(type), text);
            }
        }
    }

    /** Печатает токены текста; токен, который сам по себе не декодируется в символ, помечается как байт. */
    private static void printPieces(Encoding enc, String text) {
        IntArrayList ids = enc.encode(text);
        StringBuilder pieces = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) {
            IntArrayList one = new IntArrayList();
            one.add(ids.get(i));
            String piece = new String(enc.decodeBytes(one), StandardCharsets.UTF_8);
            pieces.append('[').append(piece.contains("�") ? "байт" : piece).append(']');
        }
        System.out.printf(Locale.ROOT, "%-12s %2d токенов: %s%n", enc.getName(), ids.size(), pieces);
    }
}
