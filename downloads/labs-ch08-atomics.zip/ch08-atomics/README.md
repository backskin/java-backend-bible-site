# Атомарные переменные: CAS, проблема ABA, лимит через get и addAndGet, LongAdder и пачки

Стенд к главе 08, раздел 3. Программы в `src/` без зависимостей: `CasDemo` (цикл CAS и `accumulateAndGet` из восьми потоков), `AbaDemo` (подмена ABA на стеке Трайбера без случайности), `CardLimit` (списание 7 копеек из 16 потоков: отдельные `get()` и `addAndGet()` превышают лимит, цикл CAS нет), `AdderBench` (`AtomicLong` против `LongAdder`), `CounterBench` (семь способов считать события), `BatchLimitDemo` (почему пачки не годятся для лимита). Выводы автора - `s03-atomics.txt`, `s03-cardlimit.txt`, `s03-counterbench-jdk21.txt`.

## Что нужно

- Temurin JDK 21.0.10 и 25.0.5 в `~/.jdks` (пути в `run.sh`); одну программу можно запустить любым JDK 21+.

## Запуск

```bash
sh run.sh
```

По одной: `java -Dstdout.encoding=UTF-8 src/CardLimit.java`; `AdderBench` требует `--add-opens java.base/java.util.concurrent.atomic=ALL-UNNAMED`. В IDEA на каждую программу есть конфигурация `java src/<Класс>.java`.

## Что должно получиться

Превышение лимита в `CardLimit` каждый раз разное (у автора 20–62 копейки), цикл CAS всегда останавливается на 999 999. Времена в `AdderBench` и `CounterBench` зависят от числа ядер, порядок вариантов сохраняется.
