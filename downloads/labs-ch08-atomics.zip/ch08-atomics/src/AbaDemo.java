import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicStampedReference;

public class AbaDemo {

    // ---- 1. ABA на одной ссылке, шаги чужих потоков выполняем в том же потоке для воспроизводимости
    static void simple() {
        AtomicReference<String> ref = new AtomicReference<>("A");
        String seen = ref.get();
        ref.set("B"); ref.set("A");                       // другие потоки: A -> B -> A
        System.out.println("AtomicReference: CAS(A -> C) после A->B->A: " + ref.compareAndSet(seen, "C"));

        AtomicStampedReference<String> sref = new AtomicStampedReference<>("A", 0);
        int[] h = new int[1];
        String s = sref.get(h);
        int stamp = h[0];
        sref.compareAndSet("A", "B", sref.getStamp(), sref.getStamp() + 1);
        sref.compareAndSet("B", "A", sref.getStamp(), sref.getStamp() + 1);
        System.out.println("AtomicStampedReference: CAS(A -> C) после A->B->A: " + sref.compareAndSet(s, "C", stamp, stamp + 1)
                + ", версия теперь " + sref.getStamp());
    }

    // ---- 2. неблокирующий стек (стек Трайбера) с переиспользованием узлов
    static final class Node {
        final String name; Node next;
        Node(String name) { this.name = name; }
    }

    static final class Stack {
        final AtomicReference<Node> head = new AtomicReference<>();
        void push(Node n) { Node h; do { h = head.get(); n.next = h; } while (!head.compareAndSet(h, n)); }
        Node pop(Runnable pauseAfterRead) {
            while (true) {
                Node h = head.get();
                if (h == null) return null;
                Node next = h.next;
                if (pauseAfterRead != null) pauseAfterRead.run();   // здесь «вытесняет» планировщик
                if (head.compareAndSet(h, next)) return h;
            }
        }
        String dump() { StringBuilder sb = new StringBuilder("["); for (Node n = head.get(); n != null; n = n.next) sb.append(n.name).append(' '); return sb.append("]").toString(); }
    }

    static void stackAba() throws Exception {
        Stack stack = new Stack();
        Node a = new Node("A"), b = new Node("B"), c = new Node("C");
        stack.push(c); stack.push(b); stack.push(a);                     // вершина A, затем B, затем C
        System.out.println("исходный стек:          " + stack.dump());

        CountDownLatch t1ReadHead = new CountDownLatch(1), t2Done = new CountDownLatch(1);
        Node[] popped = new Node[1];
        Thread t1 = new Thread(() -> popped[0] = stack.pop(() -> {
            t1ReadHead.countDown();                                       // T1 прочитал head=A, next=B
            try { t2Done.await(); } catch (InterruptedException ignored) { }
        }));
        t1.start();
        t1ReadHead.await();

        Node x = stack.pop(null);                                         // T2: снимает A
        Node y = stack.pop(null);                                         // T2: снимает B
        stack.push(a);                                                    // T2: возвращает тот же узел A (у него next = C)
        System.out.println("после действий потока T2: " + stack.dump() + " (снято " + x.name + ", " + y.name + ", A вернули)");
        t2Done.countDown();
        t1.join();
        System.out.println("T1 завершил pop, вернул " + popped[0].name + "; стек: " + stack.dump()
                + "  <-- узел B уже снял поток T2, но он «воскрес» на вершине стека");
    }

    public static void main(String[] args) throws Exception {
        simple();
        stackAba();
    }
}
