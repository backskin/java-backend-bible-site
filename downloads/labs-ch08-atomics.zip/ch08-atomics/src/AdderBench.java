import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

/** Запуск: java --add-opens java.base/java.util.concurrent.atomic=ALL-UNNAMED AdderBench.java */
public class AdderBench {

    static final int PER_THREAD = 5_000_000;

    static double nsPerOp(int threads, Runnable inc) throws Exception {
        Thread[] ts = new Thread[threads];
        long t0 = System.nanoTime();
        for (int t = 0; t < threads; t++) {
            ts[t] = new Thread(() -> { for (int i = 0; i < PER_THREAD; i++) inc.run(); });
            ts[t].start();
        }
        for (Thread t : ts) t.join();
        return (System.nanoTime() - t0) / (double) ((long) threads * PER_THREAD);   // на одну операцию по общему времени
    }

    public static void main(String[] args) throws Exception {
        AtomicLong atomic = new AtomicLong();
        LongAdder adder = new LongAdder();
        for (int warm = 0; warm < 2; warm++) { nsPerOp(4, atomic::incrementAndGet); nsPerOp(4, adder::increment); }   // прогрев
        System.out.println("процессоров: " + Runtime.getRuntime().availableProcessors());
        System.out.println("потоков | AtomicLong, нс/оп | LongAdder, нс/оп");
        for (int threads : new int[]{1, 4, 16}) {
            double a = nsPerOp(threads, atomic::incrementAndGet);
            double l = nsPerOp(threads, adder::increment);
            System.out.printf("%7d | %17.1f | %16.1f%n", threads, a, l);
        }
        Field cells = Class.forName("java.util.concurrent.atomic.Striped64").getDeclaredField("cells");
        cells.setAccessible(true);
        Object[] arr = (Object[]) cells.get(adder);
        System.out.println("ячеек у LongAdder после замера: " + (arr == null ? 0 : arr.length));
        System.out.println("sum() = " + adder.sum() + ", AtomicLong = " + atomic.get());
    }
}
