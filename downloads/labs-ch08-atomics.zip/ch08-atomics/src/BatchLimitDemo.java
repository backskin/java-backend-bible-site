import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.LongSupplier;

/** Запуск без сборки: java BatchLimitDemo.java (JDK 21, зависимостей нет). */
public class BatchLimitDemo {

    static final int LIMIT = 100_000;       // сколько операций разрешено в окне
    static final int THREADS = 16;
    static final int BATCH = 64;

    /** Каждый поток запрашивает разрешения, пока ему не откажут; возвращает, сколько выдано всего. */
    static long run(java.util.function.Supplier<java.util.function.BooleanSupplier> perThreadTryAcquire) throws Exception {
        AtomicLong granted = new AtomicLong();
        Thread[] ts = new Thread[THREADS];
        for (int t = 0; t < THREADS; t++) {
            java.util.function.BooleanSupplier tryAcquire = perThreadTryAcquire.get();
            ts[t] = new Thread(() -> {
                long mine = 0;
                while (tryAcquire.getAsBoolean()) mine++;
                granted.addAndGet(mine);
            });
        }
        for (Thread t : ts) t.start();
        for (Thread t : ts) t.join();
        return granted.get();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("лимит " + LIMIT + ", потоков " + THREADS + ", пачка " + BATCH);

        // A. Одна общая переменная: одно атомарное действие «прибавить и сравнить».
        for (int rep = 1; rep <= 3; rep++) {
            AtomicLong counter = new AtomicLong();
            long granted = run(() -> () -> counter.incrementAndGet() <= LIMIT);
            System.out.println("A. AtomicLong.incrementAndGet() <= лимит:   выдано " + granted + " (перебор " + (granted - LIMIT) + ")");
        }

        // B. «Быстрый» счётчик с проверкой отдельно от записи: LongAdder + check-then-act.
        for (int rep = 1; rep <= 3; rep++) {
            LongAdder adder = new LongAdder();
            long granted = run(() -> () -> {
                if (adder.sum() >= LIMIT) return false;     // проверка...
                adder.increment();                           // ...и запись разнесены: между ними успевают другие
                return true;
            });
            System.out.println("B. LongAdder: sum() < лимит, затем increment(): выдано " + granted + " (перебор " + (granted - LIMIT) + ")");
        }

        // C. Пачки разрешений: поток берёт сразу BATCH разрешений одним getAndAdd и тратит их локально.
        for (int rep = 1; rep <= 3; rep++) {
            AtomicLong reserved = new AtomicLong();
            long granted = run(() -> new java.util.function.BooleanSupplier() {
                long left = 0;                                // свои неиспользованные разрешения
                public boolean getAsBoolean() {
                    if (left == 0) {
                        long start = reserved.getAndAdd(BATCH);
                        left = Math.max(0, Math.min(BATCH, LIMIT - start));
                        if (left == 0) return false;
                    }
                    left--;
                    return true;
                }
            });
            System.out.println("C. пачки по " + BATCH + " разрешений:                выдано " + granted + " (перебор " + (granted - LIMIT) + ")");
        }

        // D. Те же пачки, но часть потоков заканчивает работу раньше и уносит остаток пачки с собой.
        AtomicLong reserved = new AtomicLong();
        AtomicLong used = new AtomicLong();
        Thread[] ts = new Thread[THREADS];
        for (int t = 0; t < THREADS; t++) {
            final int quota = 1_000 + 37 * t;                // каждый поток обрабатывает ограниченное число запросов
            ts[t] = new Thread(() -> {
                long left = 0, mine = 0;
                while (mine < quota) {
                    if (left == 0) {
                        long start = reserved.getAndAdd(BATCH);
                        left = Math.max(0, Math.min(BATCH, LIMIT - start));
                        if (left == 0) break;
                    }
                    left--; mine++;
                }
                used.addAndGet(mine);                         // остаток left пропал вместе с потоком
            });
            ts[t].start();
        }
        for (Thread t : ts) t.join();
        System.out.println("D. потоки ушли раньше: реально выдано " + used.get() + ", а в счётчике зарезервировано " + reserved.get()
                + " (потеряно в недоиспользованных пачках: " + (reserved.get() - used.get()) + ")");
    }
}
