import java.util.SplittableRandom;
import java.util.concurrent.atomic.AtomicLong;

public class CasDemo {

    /** Наибольшая сумма платежа: цикл повторов вокруг compareAndSet. */
    static final class MaxTracker {
        private final AtomicLong max = new AtomicLong(Long.MIN_VALUE);
        final AtomicLong failedCas = new AtomicLong();          // сколько раз проиграли гонку

        void observe(long v) {
            long cur;
            do {
                cur = max.get();
                if (v <= cur) return;                           // менять ничего не надо
                if (!max.compareAndSet(cur, v)) { failedCas.incrementAndGet(); continue; }
                return;
            } while (true);
        }
        long get() { return max.get(); }
    }

    public static void main(String[] args) throws Exception {
        int threads = 8, perThread = 2_000_000;
        MaxTracker tracker = new MaxTracker();
        AtomicLong expected = new AtomicLong(Long.MIN_VALUE);
        Thread[] ts = new Thread[threads];
        for (int t = 0; t < threads; t++) {
            final int seed = t;
            ts[t] = new Thread(() -> {
                SplittableRandom rnd = new SplittableRandom(seed);
                long localMax = Long.MIN_VALUE;
                for (int i = 0; i < perThread; i++) {
                    long v = rnd.nextLong(1_000_000_000L);
                    tracker.observe(v);
                    if (v > localMax) localMax = v;
                }
                expected.accumulateAndGet(localMax, Math::max);   // то же через готовый метод
            });
            ts[t].start();
        }
        for (Thread t : ts) t.join();
        System.out.println("максимум через MaxTracker:          " + tracker.get());
        System.out.println("максимум, посчитанный отдельно:      " + expected.get());
        System.out.println("совпало:                             " + (tracker.get() == expected.get()));
        System.out.println("проигранных гонок CAS из " + (threads * perThread) + " вызовов: " + tracker.failedCas.get());


        // CAS-цикл, который обязан записать каждый раз: проигранных гонок много
        AtomicLong shared = new AtomicLong();
        AtomicLong failures = new AtomicLong();
        Thread[] inc = new Thread[threads];
        for (int t = 0; t < threads; t++) {
            inc[t] = new Thread(() -> {
                long fails = 0;
                for (int i = 0; i < 1_000_000; i++) {
                    long cur;
                    do { cur = shared.get(); } while (!shared.compareAndSet(cur, cur + 1) && ++fails > 0);
                }
                failures.addAndGet(fails);
            });
            inc[t].start();
        }
        for (Thread t : inc) t.join();
        System.out.println("CAS-счётчик: итог " + shared.get() + " (ожидалось " + threads * 1_000_000 + "), проигранных гонок: " + failures.get());

        // одна операция CAS без конкуренции: порядок величины, не замер JMH
        AtomicLong counter = new AtomicLong();
        long t0 = System.nanoTime();
        for (int i = 0; i < 100_000_000; i++) counter.incrementAndGet();
        System.out.printf("incrementAndGet в одном потоке: %.1f нс/операция%n", (System.nanoTime() - t0) / 1e8);
    }
}
