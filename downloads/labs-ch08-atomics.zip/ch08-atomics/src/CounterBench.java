import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;
import java.util.concurrent.atomic.LongAdder;
import java.util.List;
import java.util.function.Supplier;

/** Запуск без сборки: java CounterBench.java (JDK 21, зависимостей нет). */
public class CounterBench {

    static final int OPS_PER_THREAD = 5_000_000;
    static volatile long sink;                       // чтобы JIT не выбросил «полезную работу»

    /** Работа между инкрементами: зависимая цепочка умножений, подбирается по числу итераций. */
    static long work(int iterations) {
        long x = 1;
        for (int i = 0; i < iterations; i++) x = x * 31 + i;
        return x;
    }

    interface Counter {
        /** Один поток вызывает add OPS_PER_THREAD раз; flush вызывается один раз в конце потока. */
        void add(int thread);
        default void flush(int thread) {}
        long total();
    }

    static final class Atomic implements Counter {
        final AtomicLong v = new AtomicLong();
        public void add(int t) { v.incrementAndGet(); }
        public long total() { return v.get(); }
    }

    static final class Adder implements Counter {
        final LongAdder v = new LongAdder();
        public void add(int t) { v.increment(); }
        public long total() { return v.sum(); }
    }

    static final class Locked implements Counter {
        long v;
        public synchronized void add(int t) { v++; }
        public synchronized long total() { return v; }
    }

    /** Пачка: поток копит в локальной переменной и раз в batch событий делает один addAndGet. */
    static final class Batched implements Counter {
        final AtomicLong v = new AtomicLong();
        final long[] local = new long[64 * 16];      // слот потока t лежит в local[t * 16]: свои кэш-линии
        final int batch;
        Batched(int batch) { this.batch = batch; }
        public void add(int t) {
            if (++local[t * 16] == batch) { v.addAndGet(batch); local[t * 16] = 0; }
        }
        public void flush(int t) { v.addAndGet(local[t * 16]); local[t * 16] = 0; }
        public long total() { return v.get(); }
    }

    /** Один писатель на слот: lazySet без CAS; stride = 1 (соседние слоты) или 16 (128 байт). */
    static final class Slots implements Counter {
        final AtomicLongArray a = new AtomicLongArray(64 * 16);
        final int stride;
        Slots(int stride) { this.stride = stride; }
        public void add(int t) { int i = t * stride; a.lazySet(i, a.get(i) + 1); }
        public long total() { long s = 0; for (int i = 0; i < a.length(); i++) s += a.get(i); return s; }
    }

    static double run(int threads, Counter c, int workIters) throws Exception {
        Thread[] ts = new Thread[threads];
        long t0 = System.nanoTime();
        for (int t = 0; t < threads; t++) {
            final int id = t;
            ts[t] = new Thread(() -> {
                long x = 0;
                for (int i = 0; i < OPS_PER_THREAD; i++) {
                    if (workIters > 0) x += work(workIters);
                    c.add(id);
                }
                c.flush(id);
                sink = x;
            });
            ts[t].start();
        }
        for (Thread t : ts) t.join();
        double ns = (System.nanoTime() - t0) / (double) ((long) threads * OPS_PER_THREAD);   // общее время / все операции
        long expected = (long) threads * OPS_PER_THREAD;
        if (c.total() != expected) System.out.println("  ОШИБКА: " + c.total() + " вместо " + expected);
        return ns;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("процессоров: " + Runtime.getRuntime().availableProcessors());
        String[] names = {"AtomicLong", "LongAdder", "synchronized", "пачка 64 + addAndGet", "пачка 1024 + addAndGet",
                "слоты stride=16, lazySet", "слоты stride=1, lazySet"};
        List<Supplier<Counter>> makers = List.of(
                Atomic::new, Adder::new, Locked::new, () -> new Batched(64), () -> new Batched(1024),
                () -> new Slots(16), () -> new Slots(1));
        for (int w = 0; w < 2; w++) for (var m : makers) run(4, m.get(), 0);        // прогрев

        // сколько стоит «работа» между инкрементами (число итераций подобрано под ~100 нс на этом процессоре)
        int iters = 200;
        long t0 = System.nanoTime();
        for (int i = 0; i < 2_000_000; i++) sink += work(iters);
        double nsWork = (System.nanoTime() - t0) / 2e6;
        System.out.printf("работа между инкрементами (iters=%d): %.0f нс%n", iters, nsWork);

        for (int workIters : new int[]{0, iters}) {
            System.out.println(workIters == 0 ? "\n=== только инкремент, без работы (нс на операцию: общее время / все операции)"
                    : "\n=== инкремент + работа примерно " + Math.round(nsWork) + " нс");
            System.out.printf("%-26s %8s %8s %8s%n", "вариант", "1 поток", "4 потока", "16 потоков");
            for (int k = 0; k < makers.size(); k++) {
                StringBuilder row = new StringBuilder(String.format("%-26s", names[k]));
                for (int threads : new int[]{1, 4, 16}) {
                    double best = Double.MAX_VALUE;
                    for (int rep = 0; rep < 3; rep++) best = Math.min(best, run(threads, makers.get(k).get(), workIters));
                    row.append(String.format(" %8.1f", best));
                }
                System.out.println(row);
            }
        }
    }
}
