import java.util.concurrent.atomic.AtomicLong;

/** Суточный лимит карты: проверка и списание раздельно (get + addAndGet) и одним циклом CAS. */
public class CardLimit {
    static final long LIMIT = 1_000_000, AMOUNT = 7;
    static final int THREADS = 16;

    interface Limit { boolean tryAuthorize(long amount); long spent(); }

    static final class Naive implements Limit {
        final AtomicLong spent = new AtomicLong();
        public boolean tryAuthorize(long a) {
            if (spent.get() + a > LIMIT) return false;   // проверка...
            spent.addAndGet(a);                          // ...и списание отдельно
            return true;
        }
        public long spent() { return spent.get(); }
    }

    static final class Cas implements Limit {
        final AtomicLong spent = new AtomicLong();
        public boolean tryAuthorize(long a) {
            long cur;
            do {
                cur = spent.get();
                if (cur + a > LIMIT) return false;
            } while (!spent.compareAndSet(cur, cur + a));
            return true;
        }
        public long spent() { return spent.get(); }
    }

    static void run(String name, Limit l) throws Exception {
        Thread[] ts = new Thread[THREADS];
        for (int i = 0; i < THREADS; i++) { ts[i] = new Thread(() -> { while (l.tryAuthorize(AMOUNT)) { } }); ts[i].start(); }
        for (Thread t : ts) t.join();
        System.out.printf("%-28s списано %,d при лимите %,d (превышение %d)%n", name, l.spent(), LIMIT, Math.max(0, l.spent() - LIMIT));
    }

    public static void main(String[] args) throws Exception {
        System.out.println("java " + System.getProperty("java.version"));
        for (int r = 0; r < 3; r++) { run("get() + addAndGet()", new Naive()); run("цикл compareAndSet", new Cas()); }
    }
}
