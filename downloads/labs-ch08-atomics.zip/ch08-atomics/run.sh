#!/bin/sh
# Опыты раздела 3 главы 8: java файл.java на JDK 21 и 25
J21=~/.jdks/temurin-21.0.10/bin/java; J25=~/.jdks/jdk-25.0.5+8/bin/java
O="-Dstdout.encoding=UTF-8"
for J in $J21 $J25; do
  echo "=== $($J -version 2>&1 | head -1)"
  $J $O src/CasDemo.java
  $J $O src/AbaDemo.java
  $J $O --add-opens java.base/java.util.concurrent.atomic=ALL-UNNAMED src/AdderBench.java
  $J $O src/BatchLimitDemo.java
done > s03-atomics.txt 2>&1
$J21 $O src/CounterBench.java > s03-counterbench-jdk21.txt 2>&1
