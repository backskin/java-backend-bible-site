package dev.team.jpa;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;

/** Реестр переводов СБП: идентификатор операции НСПК уникален. */
@SpringBootApplication
public class RegistryApp {
    public static void main(String[] args) { SpringApplication.run(RegistryApp.class, args); }
}

@Entity
@Table(name = "registry_entry", uniqueConstraints = @UniqueConstraint(columnNames = "nspk_operation_id"))
class RegistryEntry {
    @Id @GeneratedValue Long id;
    @Column(name = "nspk_operation_id", nullable = false) String nspkOperationId;
    @Column(nullable = false) BigDecimal amount;
    @Column(nullable = false) String status;

    protected RegistryEntry() { }
    RegistryEntry(String nspkOperationId, BigDecimal amount, String status) {
        this.nspkOperationId = nspkOperationId; this.amount = amount; this.status = status;
    }
}

interface RegistryRepository extends JpaRepository<RegistryEntry, Long> {
    List<RegistryEntry> findByStatus(String status);
}

@Service
class ReconciliationService {
    private final RegistryRepository repo;
    ReconciliationService(RegistryRepository repo) { this.repo = repo; }
    long unconfirmed() { return repo.findByStatus("SENT").size(); }
}

@RestController
class RegistryController {
    private final ReconciliationService service;
    RegistryController(ReconciliationService service) { this.service = service; }
    @GetMapping("/api/registry/unconfirmed") long unconfirmed() { return service.unconfirmed(); }
}
