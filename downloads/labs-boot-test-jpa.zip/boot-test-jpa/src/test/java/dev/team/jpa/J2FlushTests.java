package dev.team.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.jpa.test.autoconfigure.TestEntityManager;

import java.math.BigDecimal;

/** Нарушение уникальности, которое откат прячет, пока не вызван flush. */
@DataJpaTest
class J2FlushTests {

    @Autowired RegistryRepository repo;
    @Autowired TestEntityManager em;

    @Test
    void duplicateWithoutFlushPasses() {
        repo.save(new RegistryEntry("B20001", BigDecimal.TEN, "SENT"));
        repo.save(new RegistryEntry("B20001", BigDecimal.ONE, "SENT"));
        System.out.println("   ► два save() с одинаковым nspk_operation_id без flush: тест прошёл, ошибки нет");
    }

    @Test
    void duplicateWithFlushFails() {
        repo.save(new RegistryEntry("B20002", BigDecimal.TEN, "SENT"));
        repo.save(new RegistryEntry("B20002", BigDecimal.ONE, "SENT"));
        try {
            em.flush();
            System.out.println("   ► с flush: ошибки нет");
        } catch (RuntimeException e) {
            Throwable t = e; while (t.getCause() != null) t = t.getCause();
            System.out.println("   ► с flush: " + e.getClass().getSimpleName() + " ← " + t.getClass().getSimpleName()
                    + ": " + t.getMessage().split("\n")[0].replaceAll("\\s+", " ").substring(0, Math.min(150, t.getMessage().length())));
        }
    }
}
