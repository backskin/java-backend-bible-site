package dev.team.jpa;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.jpa.test.autoconfigure.TestEntityManager;
import org.springframework.context.ApplicationContext;

import javax.sql.DataSource;
import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/** Слайс JPA: что поднимается, откат транзакции, запрос производного метода. */
@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class J1DataJpaSliceTests {

    @Autowired TestEntityManager em;
    @Autowired RegistryRepository repo;
    @Autowired ApplicationContext ctx;
    @Autowired DataSource ds;

    @Test @Order(1)
    void findsByStatus() throws Exception {
        em.persist(new RegistryEntry("A10001", new BigDecimal("1500.00"), "SENT"));
        em.persist(new RegistryEntry("A10002", new BigDecimal("700.00"), "SENT"));
        em.persist(new RegistryEntry("A10003", new BigDecimal("90.00"), "CONFIRMED"));
        em.flush();
        assertThat(repo.findByStatus("SENT")).hasSize(2);
        try (var c = ds.getConnection()) {
            System.out.println("   ► @DataJpaTest: бинов " + ctx.getBeanDefinitionCount()
                    + "; RegistryController=" + ctx.getBeanNamesForType(RegistryController.class).length
                    + ", ReconciliationService=" + ctx.getBeanNamesForType(ReconciliationService.class).length
                    + "; база " + c.getMetaData().getURL().replaceAll("mem:[0-9a-f-]{36}", "mem:<случайное имя>")
                    + "; SENT найдено " + repo.findByStatus("SENT").size());
        }
    }

    @Test @Order(2)
    void rolledBack() {
        System.out.println("   ► @DataJpaTest, метод 2: записей в реестре " + repo.count());
        assertThat(repo.count()).isZero();
    }
}
