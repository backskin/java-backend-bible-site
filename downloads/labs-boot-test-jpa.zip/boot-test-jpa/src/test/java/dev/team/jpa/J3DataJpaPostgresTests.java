package dev.team.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.testcontainers.postgresql.PostgreSQLContainer;

import javax.sql.DataSource;
import java.math.BigDecimal;

/** Слайс JPA на PostgreSQL из контейнера без replace = NONE; уникальность проверяет настоящая база. */
@DataJpaTest(properties = "spring.jpa.hibernate.ddl-auto=create-drop")
@Import(J3DataJpaPostgresTests.Containers.class)
class J3DataJpaPostgresTests {

    @TestConfiguration(proxyBeanMethods = false)
    static class Containers {
        @Bean @ServiceConnection
        PostgreSQLContainer postgres() { return new PostgreSQLContainer("postgres:17-alpine"); }
    }

    @Autowired RegistryRepository repo;
    @Autowired DataSource ds;

    @Test
    void onPostgres() throws Exception {
        repo.saveAndFlush(new RegistryEntry("C30001", new BigDecimal("15000.00"), "SENT"));
        try (var c = ds.getConnection()) {
            System.out.println("   ► @DataJpaTest + контейнер без replace=NONE: " + c.getMetaData().getDatabaseProductName() + " "
                    + c.getMetaData().getDatabaseProductVersion() + ", SENT найдено " + repo.findByStatus("SENT").size());
        }
        try {
            repo.saveAndFlush(new RegistryEntry("C30001", BigDecimal.ONE, "SENT"));
        } catch (RuntimeException e) {
            Throwable t = e; while (t.getCause() != null) t = t.getCause();
            System.out.println("   ► дубликат на PostgreSQL: " + e.getClass().getSimpleName() + " ← " + t.getMessage().split("\n")[0]);
        }
    }
}
