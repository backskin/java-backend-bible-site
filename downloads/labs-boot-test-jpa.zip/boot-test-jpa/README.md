# Слайс @DataJpaTest: что попадает в контекст, встроенная H2 против PostgreSQL в Testcontainers

Стенд к главе 10, раздел о тестировании. Реестр переводов `RegistryApp` (Spring Boot 4.1.1, Spring Data JPA, Hibernate 7.4) и тесты, которые сравнивают `@DataJpaTest` с `@SpringBootTest`: сколько бинов в контексте, есть ли контроллер и сервис сверки, какая база подставлена (`jdbc:h2:mem:<случайное имя>`), и тот же слайс с `@AutoConfigureTestDatabase(replace = NONE)` на PostgreSQL 17 в контейнере. Вывод автора - `s10-test-jpa.txt`.

## Что нужно

- JDK 21 и Maven; Docker для варианта с PostgreSQL.

## Запуск

```bash
mvn -q test
```

В IDEA есть конфигурации `RegistryApp` и `mvn test`.

## Что должно получиться

`@DataJpaTest`: около 80 бинов, `RegistryController=0`, `ReconciliationService=0`; `@SpringBootTest` поднимает все. Числа в выводе зависят от версии Boot.
