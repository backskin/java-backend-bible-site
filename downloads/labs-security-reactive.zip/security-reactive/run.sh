#!/usr/bin/env bash
# Разд. 11 гл. 13: Spring Security 7.1 в WebFlux. Вывод: s13-reactive.txt, с Hooks.enableAutomaticContextPropagation() — s13-reactive-auto.txt.
set -uo pipefail
cd "$(dirname "$0")"
J="${JAVA:-$HOME/.jdks/temurin-21.0.10/bin/java}"
mvn -q -DskipTests compile dependency:build-classpath -Dmdep.outputFile=cp.txt >/dev/null || exit 1
CP="$(cygpath -w "$PWD/target/classes" 2>/dev/null || echo target/classes);$(cat cp.txt)"
[ "$(uname -o 2>/dev/null)" = "Msys" ] || CP="${CP//;/:}"
"$J" -Dstdout.encoding=UTF-8 -cp "$CP" rx.App 2>&1 | grep -v WARNING > s13-reactive.txt
"$J" -Dstdout.encoding=UTF-8 -cp "$CP" rx.App auto 2>&1 | grep -v WARNING > s13-reactive-auto.txt
cat s13-reactive.txt
