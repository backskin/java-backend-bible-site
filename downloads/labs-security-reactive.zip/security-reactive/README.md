# Spring Security 7.1 в WebFlux: цепочка WebFilter, ReactiveSecurityContextHolder, перенос контекста через context-propagation

Стенд к главе 13, раздел 11. Приложение `rx.App` (Spring Boot 4.1.1, WebFlux на Netty, `@EnableWebFluxSecurity`, HTTP Basic, `MapReactiveUserDetailsService`, `@EnableReactiveMethodSecurity`) печатает девять фильтров бина `SecurityWebFilterChain`, что возвращает `ReactiveSecurityContextHolder.getContext()` в открытом эндпоинте без учетных данных и как контекст виден в `@PreAuthorize` и в `ThreadLocal` после `publishOn`; второй запуск с аргументом `auto` включает `Hooks.enableAutomaticContextPropagation()`. Выводы автора - `s13-reactive.txt`, `s13-reactive-auto.txt`.

## Что нужно

- JDK 21 (`JAVA` в `run.sh`), Maven, bash.

## Запуск

```bash
bash run.sh
```

В IDEA есть конфигурация `App` (аргумент `auto` для второго варианта).

## Что должно получиться

Цепочка от `ServerWebExchangeReactorContextWebFilter` до `AuthorizationWebFilter`, анонимного фильтра в ней нет; без учетных данных `getContext()` дает пустой `Mono`; после `publishOn(boundedElastic)` контекст Reactor видит `alice`, а `SecurityContextHolder` в `ThreadLocal` - `null`; чем отличается прогон с `enableAutomaticContextPropagation`, показывают последние строки двух файлов.
