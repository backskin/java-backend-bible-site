package rx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.Base64;
import java.util.List;
import java.util.Map;

/**
 * Разд. 11 гл. 13: Spring Security 7.1 в WebFlux. Цепочка WebFilter по умолчанию, контекст в Reactor Context,
 * пустой Mono у анонима, access() с AuthorizationContext, @PreAuthorize на Mono и на обычном типе, @PostFilter на Flux,
 * ThreadLocal-холдер внутри реактивной цепочки с автоматической передачей контекста и без неё.
 */
@SpringBootApplication
public class App {

    @RestController
    static class Api {
        final Ledger ledger;
        Api(Ledger ledger) { this.ledger = ledger; }

        @GetMapping("/api/me") Mono<String> me(Mono<Authentication> auth) { return auth.map(a -> "параметр Mono<Authentication>: " + a.getName()); }

        @GetMapping("/public/who") Mono<String> who() {
            return ReactiveSecurityContextHolder.getContext().map(SecurityContext::getAuthentication)
                    .map(a -> a.getClass().getSimpleName() + " " + a.getName())
                    .defaultIfEmpty("пустой Mono: контекста нет");
        }

        @GetMapping("/api/hop") Mono<String> hop() {
            return Mono.just(1).publishOn(Schedulers.boundedElastic())
                    .flatMap(i -> ReactiveSecurityContextHolder.getContext())
                    .map(c -> "после publishOn(boundedElastic) в потоке " + Thread.currentThread().getName().replaceAll("-\\d+$", "-N")
                            + ": " + c.getAuthentication().getName()
                            + "; SecurityContextHolder (ThreadLocal): " + String.valueOf(SecurityContextHolder.getContext().getAuthentication() == null ? null : SecurityContextHolder.getContext().getAuthentication().getName()));
        }

        @GetMapping("/api/limits") Mono<String> limits() { return ledger.limitsMono(); }
        @GetMapping("/api/limits-plain") String limitsPlain() { return ledger.limitsPlain(); }
        @GetMapping("/api/accounts") Flux<String> accounts() { return ledger.accounts(); }
        @GetMapping("/api/noon") Mono<String> noon() { return Mono.just("доступ по правилу access()"); }
    }

    @Service
    static class Ledger {
        @PreAuthorize("hasRole('RISK')") public Mono<String> limitsMono() { return Mono.just("лимиты: 100 000 ₽ в сутки"); }
        @PreAuthorize("hasRole('RISK')") public String limitsPlain() { return "лимиты: 100 000 ₽ в сутки (обычный String)"; }
        @PostFilter("filterObject.endsWith(authentication.name)")
        public Flux<String> accounts() { return Flux.just("40817810…01 alice", "40817810…02 bob", "40702810…03 alice"); }
    }

    @Configuration
    @EnableWebFluxSecurity
    @EnableReactiveMethodSecurity
    static class Config {
        @Bean MapReactiveUserDetailsService users() {
            return new MapReactiveUserDetailsService(
                    User.withUsername("alice").password("{noop}pw").roles("USER").build(),
                    User.withUsername("risk").password("{noop}pw").roles("RISK").build());
        }

        @Bean SecurityWebFilterChain chain(ServerHttpSecurity http) {
            return http
                    .authorizeExchange(ex -> ex
                            .pathMatchers("/public/**").permitAll()
                            .pathMatchers(HttpMethod.GET, "/api/noon").access((auth, ctx) -> auth
                                    .map(a -> a.getAuthorities().stream().anyMatch(g -> g.getAuthority().equals("ROLE_RISK"))
                                            && ctx.getExchange().getRequest().getHeaders().containsHeader("X-Branch"))
                                    .map(AuthorizationDecision::new))
                            .anyExchange().authenticated())
                    .httpBasic(Customizer.withDefaults())
                    .csrf(ServerHttpSecurity.CsrfSpec::disable)
                    .build();
        }
    }

    public static void main(String[] args) {
        boolean auto = List.of(args).contains("auto");
        if (auto) reactor.core.publisher.Hooks.enableAutomaticContextPropagation();
        SpringApplication app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of("server.port", "0", "logging.level.root", "OFF", "spring.main.banner-mode", "off"));
        try (ConfigurableApplicationContext ctx = app.run()) {
            System.out.println("spring-security " + org.springframework.security.core.SpringSecurityCoreVersion.getVersion()
                    + ", Hooks.enableAutomaticContextPropagation: " + (auto ? "включён" : "нет"));
            var chain = ctx.getBean(SecurityWebFilterChain.class);
            System.out.println("цепочка WebFilter: " + String.join(", ", chain.getWebFilters()
                    .map(f -> f.getClass().getSimpleName()).collectList().block()));
            String port = ctx.getEnvironment().getProperty("local.server.port");
            WebClient wc = WebClient.create("http://127.0.0.1:" + port);
            call(wc, "аноним GET /public/who", "/public/who", null, null);
            call(wc, "alice GET /public/who", "/public/who", "alice", null);
            call(wc, "аноним GET /api/me", "/api/me", null, null);
            call(wc, "alice GET /api/me", "/api/me", "alice", null);
            call(wc, "alice GET /api/hop", "/api/hop", "alice", null);
            call(wc, "alice GET /api/limits (Mono)", "/api/limits", "alice", null);
            call(wc, "risk GET /api/limits (Mono)", "/api/limits", "risk", null);
            call(wc, "alice GET /api/limits-plain (String)", "/api/limits-plain", "alice", null);
            call(wc, "risk GET /api/limits-plain (String)", "/api/limits-plain", "risk", null);
            call(wc, "alice GET /api/accounts (@PostFilter)", "/api/accounts", "alice", null);
            call(wc, "risk GET /api/noon без X-Branch", "/api/noon", "risk", null);
            call(wc, "risk GET /api/noon с X-Branch", "/api/noon", "risk", "X-Branch");
            // мост из императивного кода: SecurityContextHolder задан в потоке, дальше Mono на другом потоке
            var alice = new org.springframework.security.authentication.UsernamePasswordAuthenticationToken("alice", null,
                    org.springframework.security.core.authority.AuthorityUtils.createAuthorityList("ROLE_USER"));
            SecurityContextHolder.getContext().setAuthentication(alice);
            String bridged = ReactiveSecurityContextHolder.getContext().map(c -> c.getAuthentication().getName())
                    .subscribeOn(Schedulers.boundedElastic()).defaultIfEmpty("пустой Mono").block();
            String tl = Mono.fromCallable(() -> String.valueOf(SecurityContextHolder.getContext().getAuthentication() == null ? null : SecurityContextHolder.getContext().getAuthentication().getName()))
                    .subscribeOn(Schedulers.boundedElastic()).block();
            String explicit = ReactiveSecurityContextHolder.getContext().map(c -> c.getAuthentication().getName())
                    .subscribeOn(Schedulers.boundedElastic())
                    .contextWrite(ReactiveSecurityContextHolder.withSecurityContext(Mono.just(SecurityContextHolder.getContext())))
                    .defaultIfEmpty("пустой Mono").block();
            System.out.println("то же с contextWrite(withSecurityContext(Mono.just(SecurityContextHolder.getContext()))) → " + explicit);
            SecurityContextHolder.clearContext();
            System.out.println("из потока с SecurityContextHolder=alice: ReactiveSecurityContextHolder в Mono → " + bridged
                    + "; SecurityContextHolder внутри Mono на boundedElastic → " + tl);
            try {   // что именно бросает @PreAuthorize на методе с обычным типом в реактивной безопасности
                var risk = new org.springframework.security.authentication.UsernamePasswordAuthenticationToken("risk", null,
                        org.springframework.security.core.authority.AuthorityUtils.createAuthorityList("ROLE_RISK"));
                Object v = Mono.fromCallable(() -> ctx.getBean(Ledger.class).limitsPlain())
                        .contextWrite(ReactiveSecurityContextHolder.withAuthentication(risk)).block();
                System.out.println("прямой вызов limitsPlain() с ROLE_RISK в Reactor Context → " + v);
            } catch (RuntimeException e) {
                System.out.println("прямой вызов limitsPlain() с ROLE_RISK в Reactor Context → " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
    }

    static void call(WebClient wc, String title, String path, String user, String header) {
        var req = wc.get().uri(path);
        if (user != null) req = req.header("Authorization", "Basic " + Base64.getEncoder().encodeToString((user + ":pw").getBytes()));
        if (header != null) req = req.header(header, "0042");
        String r = req.exchangeToMono(resp -> resp.bodyToMono(String.class).defaultIfEmpty("")
                .map(b -> "HTTP " + resp.statusCode().value() + (b.isEmpty() ? "" : ": " + b.replace("\n", " ").substring(0, Math.min(160, b.length())))))
                .block();
        System.out.printf("%-42s → %s%n", title, r);
    }
}
